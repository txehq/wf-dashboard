# Attribution — ctxrs/ctx

`wf history` and the `wf-history` MCP server run [ctx](https://github.com/ctxrs/ctx), which is
licensed Apache-2.0. [`LICENSE`](LICENSE) is its license text, and it ships in each release's
third-party licence archive.

`wf` does not vendor, compile or modify ctx's source. It installs ctx's upstream release
binaries as published. `wf release build-local --ctx latest` records a release's version, commit
and each platform's asset SHA-256 in `workflow.lock.json`; each machine downloads that asset from
ctxrs/ctx's GitHub release and runs it only after its digest matches both the lock and GitHub's
API. The semantic model and runtime that ctx then downloads for itself come from ctx's own
catalog and carry their own licenses.

`ctx pro`, the upstream's separately-licensed private companion, is out of scope entirely.

[ADR-0006](../../docs/architecture/adr/0006-history-is-ctx.md) records why ctx is installed
rather than reimplemented. [ADR-0005](../../docs/architecture/adr/0005-history-is-implemented-not-forked.md),
which it supersedes, records the reimplementation that came before.
