//! The four commands that used to be separate Go programs.
//!
//! They live behind the same binary now, which is what removes the shell bootstrap: a
//! precompiled `wf` can report its own absence in a way a Go program never could, so the
//! one script WFR-010 carved an exception for has nothing left to do.

use super::emit;
use std::path::{Path, PathBuf};
use wf_core::{envelope::Envelope, envelope::Note, ExitCode, Result};

pub fn guard(
    json: bool,
    fix: bool,
    base_ref: Option<&str>,
    root: &str,
    now: Option<&str>,
) -> Result<ExitCode> {
    let today = match now {
        Some(s) => wf_guard::registry::parse_date(s).ok_or_else(|| {
            wf_core::Error::usage("GUARD-NOW", format!("bad --now {s:?}"))
                .with_zh("`--now` 需要 YYYY-MM-DD 格式的日期。".to_string())
        })?,
        None => time::OffsetDateTime::now_utc().date(),
    };
    let findings = wf_guard::run(Path::new(root), fix, today, base_ref)?;
    let mut env = Envelope::new("guard").result(&findings);
    if !findings.is_empty() {
        env = env.error(Note::new("GUARD", format!("{} finding(s)", findings.len())));
    }
    let f = findings.clone();
    Ok(emit(json, env, move || {
        if f.is_empty() {
            return "guard: clean\n".to_string();
        }
        let mut s = String::new();
        for x in &f {
            s.push_str(&format!("{x}\n"));
        }
        s.push_str(&format!("\nguard: {} finding(s)\n", f.len()));
        s
    }))
}

pub fn readiness(json: bool, args: &crate::flags::ReadinessArgs) -> Result<ExitCode> {
    let checkout = git_root();
    let root = args
        .root
        .as_ref()
        .map(PathBuf::from)
        .unwrap_or_else(|| checkout.clone())
        .canonicalize()?;
    // The shipped profiles: this checkout's, or else the active generation's bundle.
    let plugin_root = checkout
        .join("workflow/readiness")
        .is_dir()
        .then_some(checkout)
        .or_else(|| {
            let paths = wf_core::paths::Paths::resolve().ok()?;
            let db = wf_state::Db::open_read_only(&paths.db()).ok()?;
            let g = db.active_generation().ok()??;
            Some(paths.generation(&g.version).join("bundle")).filter(|d| d.is_dir())
        });
    let agent = args
        .agent
        .as_deref()
        .or_else(|| wf_readiness::components::running_agent(&|key| std::env::var(key).ok()));
    let verdict = wf_readiness::run(&wf_readiness::Options {
        root: &root,
        profile: &args.profile,
        extras: &args.need,
        repair: args.repair,
        force: args.force,
        profile_root: plugin_root.as_deref(),
        cache_dir: None,
        manifest: args.manifest.as_deref().map(Path::new),
        compose: args.compose.as_deref().map(Path::new),
        agent,
        installation: None,
        ttl: args.ttl,
    })?;
    let mut env = Envelope::new("readiness").result(&verdict);
    if !verdict.ready {
        env = env.error(Note::new("NOT-READY", "blocking findings").with_zh(String::new()));
    }
    let rendered = verdict.render_zh();
    Ok(emit(json, env, move || rendered))
}

pub fn obsidian(json: bool, args: &crate::flags::ObsidianArgs) -> Result<ExitCode> {
    let vault = args
        .vault
        .clone()
        .or_else(|| std::env::var("MAGI_VAULT").ok().filter(|s| !s.is_empty()))
        .unwrap_or_else(|| {
            std::env::var("HOME")
                .map(|h| format!("{h}/Projects/Obsidian/TXE"))
                .unwrap_or_default()
        });

    let date = args.date.clone().unwrap_or_else(wf_core::time_fmt::today);
    if wf_guard::registry::parse_date(&date).is_none() {
        return Err(wf_core::Error::usage(
            "OBSIDIAN-DATE",
            "--date requires YYYY-MM-DD",
        ));
    }
    let request = wf_obsidian::Request {
        vault,
        kind: args.kind.clone(),
        product: args.product.clone().unwrap_or_default(),
        feature: args.feature.clone().unwrap_or_default(),
        title: args.title.clone().unwrap_or_default(),
        slug: args.slug.clone().unwrap_or_default(),
        date,
    };
    let path = wf_obsidian::write(&wf_obsidian::WriteOptions {
        request,
        file: args.file.as_deref().map(Path::new),
        ticket: args.ticket.as_deref().unwrap_or_default(),
        url: args.url.as_deref().unwrap_or_default(),
        replace: args.replace,
        dry_run: args.dry_run,
    })?;
    let env = Envelope::new("obsidian")
        .result(serde_json::json!({ "path": path, "dry_run": args.dry_run }));
    Ok(emit(json, env, move || format!("{path}\n")))
}

pub fn publish_artifact(
    json: bool,
    file: &str,
    title: &str,
    kind: Option<&str>,
    id: Option<&str>,
    dry_run: bool,
) -> Result<ExitCode> {
    let url = wf_publish_artifact::publish(&wf_publish_artifact::Options {
        file: Path::new(file),
        title,
        kind,
        id,
        dry_run,
    })?;
    let env = Envelope::new("publish-artifact").result(serde_json::json!({ "url": url }));
    // One line — the URL — and nothing else on success. Callers pipe this.
    Ok(emit(json, env, move || format!("{url}\n")))
}

pub(super) fn git_root() -> PathBuf {
    let Ok(out) = wf_core::proc::run(
        "git",
        &["rev-parse", "--show-toplevel"],
        std::time::Duration::from_secs(10),
    ) else {
        return PathBuf::from(".");
    };
    if out.ok() && !out.stdout.trim().is_empty() {
        PathBuf::from(out.stdout.trim())
    } else {
        PathBuf::from(".")
    }
}

pub fn handover(
    json: bool,
    to: Option<&str>,
    why: Option<&str>,
    ticket: Option<&str>,
    root: &str,
) -> Result<ExitCode> {
    let mut state = wf_handover::gather(Path::new(root))?;
    if let Some(t) = ticket {
        state.ticket = t.to_lowercase();
        wf_handover::drop_blocking(&mut state, "no ticket id");
    }
    let doc = wf_handover::render(
        &state,
        to.unwrap_or(""),
        why.unwrap_or(""),
        &wf_core::time_fmt::today(),
    );
    let mut env = Envelope::new("handover").result(&state);
    for b in &state.blocking {
        env = env.warn(Note::new("BLOCKING", b.clone()));
    }
    // The JSON form is the derived state alone; the human form is the document. Both come
    // from the same gather, so the skeleton can never disagree with the state it reports.
    Ok(emit(json, env, move || doc))
}
