//! Usage tracking: what the agents' own hooks report, kept on this machine.
//!
//! A hook hands `wf hook dispatch` a JSON payload on stdin. [`events_from_hook`] turns it into
//! the events worth keeping — a session starting or ending, a prompt, a tool call, a skill
//! used — and [`tracker::UsageTracker`] records them. Nothing here leaves the machine, and the
//! only prompt text kept is a redacted, shortened copy of a session's first prompt.

pub mod analytics;
pub mod tracker;

use crate::formats::HookEvent;
use serde::{Deserialize, Serialize};
use serde_json::Value;

/// How a skill came to be used.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum SkillSource {
    /// Through the agent's own skill mechanism (Claude Code's `Skill` tool).
    Shared,
    /// A prompt that began with `/<skill>`.
    SlashCommand,
    /// The agent read `…/skills/<name>/SKILL.md` itself — how agents without a skill tool,
    /// Cursor among them, load one.
    CursorRead,
}

impl SkillSource {
    pub fn as_str(self) -> &'static str {
        match self {
            SkillSource::Shared => "shared",
            SkillSource::SlashCommand => "slash-command",
            SkillSource::CursorRead => "cursor-read",
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct SkillUsageEvent {
    pub timestamp: String,
    pub session_id: String,
    pub agent: String,
    pub skill_name: String,
    pub source: SkillSource,
}

#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct SessionEvent {
    pub session_id: String,
    pub agent: String,
    pub timestamp: String,
    /// `cwd`, `source`, `reason` — whatever the hook said about the session.
    #[serde(skip_serializing_if = "Value::is_null")]
    pub metadata: Value,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct ToolUseEvent {
    pub session_id: String,
    pub agent: String,
    pub tool_name: String,
    pub timestamp: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct PromptEvent {
    pub session_id: String,
    pub agent: String,
    pub timestamp: String,
    /// The prompt, which the tracker keeps only as a redacted summary of a session's first.
    pub text: String,
}

/// One event worth recording.
#[derive(Debug, Clone, PartialEq, Serialize)]
pub enum TrackedEvent {
    SessionStart(SessionEvent),
    SessionEnd(SessionEvent),
    /// The agent finished a turn.
    Stop(SessionEvent),
    Prompt(PromptEvent),
    ToolUse(ToolUseEvent),
    Skill(SkillUsageEvent),
}

/// What an invocation knows beyond its payload.
pub struct HookContext<'a> {
    pub agent: &'a str,
    pub event: HookEvent,
    pub now: String,
    /// When the payload names no session: `CLAUDE_SESSION_ID`, then the parent process.
    pub fallback_session: &'a dyn Fn() -> String,
    /// Is this the name of a skill the agent has? A slash command is only a skill if so —
    /// `/clear` is not.
    pub is_skill: &'a dyn Fn(&str) -> bool,
}

/// The events one hook payload carries.
pub fn events_from_hook(ctx: &HookContext<'_>, payload: &Value) -> Vec<TrackedEvent> {
    let text = |key: &str| {
        payload
            .get(key)
            .and_then(Value::as_str)
            .filter(|s| !s.is_empty())
    };
    let session_id = text("session_id")
        .or_else(|| text("sessionId"))
        .or_else(|| text("conversation_id"))
        .map(String::from)
        .unwrap_or_else(|| (ctx.fallback_session)());
    let session = |keys: &[&str]| {
        let metadata: serde_json::Map<String, Value> = keys
            .iter()
            .filter_map(|k| text(k).map(|v| ((*k).to_string(), Value::from(v))))
            .collect();
        SessionEvent {
            session_id: session_id.clone(),
            agent: ctx.agent.to_string(),
            timestamp: ctx.now.clone(),
            metadata: if metadata.is_empty() {
                Value::Null
            } else {
                Value::Object(metadata)
            },
        }
    };
    let skill = |name: String, source| {
        TrackedEvent::Skill(SkillUsageEvent {
            timestamp: ctx.now.clone(),
            session_id: session_id.clone(),
            agent: ctx.agent.to_string(),
            skill_name: name,
            source,
        })
    };
    match ctx.event {
        HookEvent::SessionStart => vec![TrackedEvent::SessionStart(session(&["cwd", "source"]))],
        HookEvent::SessionEnd => vec![TrackedEvent::SessionEnd(session(&["reason"]))],
        HookEvent::Stop => vec![TrackedEvent::Stop(session(&[]))],
        HookEvent::PreToolUse => vec![],
        HookEvent::UserPromptSubmit => {
            let prompt = text("prompt").unwrap_or_default();
            let mut out = vec![TrackedEvent::Prompt(PromptEvent {
                session_id: session_id.clone(),
                agent: ctx.agent.to_string(),
                timestamp: ctx.now.clone(),
                text: prompt.to_string(),
            })];
            if let Some(name) = slash_command(prompt).filter(|n| (ctx.is_skill)(n)) {
                out.push(skill(name, SkillSource::SlashCommand));
            }
            out
        }
        HookEvent::PostToolUse => {
            let Some(raw) = text("tool_name").or_else(|| text("toolName")) else {
                return vec![];
            };
            let tool = normalize_tool(raw);
            let input = payload
                .get("tool_input")
                .or_else(|| payload.get("toolInput"))
                .unwrap_or(&Value::Null);
            let mut out = vec![TrackedEvent::ToolUse(ToolUseEvent {
                session_id: session_id.clone(),
                agent: ctx.agent.to_string(),
                tool_name: tool.clone(),
                timestamp: ctx.now.clone(),
            })];
            let used = match tool.as_str() {
                "Skill" => skill_from_tool_input(input).map(|n| (n, SkillSource::Shared)),
                "Read" => skill_from_read(input).map(|n| (n, SkillSource::CursorRead)),
                _ => None,
            };
            if let Some((name, source)) = used {
                out.push(skill(name, source));
            }
            out
        }
    }
}

/// Everything one hook invocation keeps: its events, and — when it is the end of a turn or
/// of the session — that session's summary, in the database always and in the monthly log
/// once the session is worth keeping. Saved at every turn's end because some agents have no
/// session-end hook; the log entry is updated in place, so it is still one entry.
pub fn record_hook(
    db: &wf_state::Db,
    state_dir: &std::path::Path,
    policies: &crate::policy::Policies,
    ctx: &HookContext<'_>,
    payload: &Value,
) -> wf_core::Result<Option<crate::sessions::SessionSummary>> {
    if !policies.usage.enabled {
        return Ok(None);
    }
    let events = events_from_hook(ctx, payload);
    let mut tracker = tracker::UsageTracker::new(db, state_dir, policies);
    tracker.track(&events)?;
    let Some(session) = events.iter().find_map(|e| match e {
        TrackedEvent::Stop(s) | TrackedEvent::SessionEnd(s) => Some(s.session_id.clone()),
        _ => None,
    }) else {
        return Ok(None);
    };
    let sessions = &policies.sessions;
    if !sessions.enabled || !sessions.auto_collect {
        return Ok(None);
    }
    let rows = db.usage_events(&wf_state::UsageQuery {
        session_id: Some(session.clone()),
        ..Default::default()
    })?;
    let Some(summary) =
        crate::sessions::SessionCollector::new(sessions).collect_session(&session, &rows)
    else {
        return Ok(None);
    };
    db.upsert_session_summary(&summary.to_row())?;
    let mut storage = crate::sessions::SessionStorage::new(&state_dir.join("sessions"));
    if summary.valuable {
        storage.append_monthly_log(&summary)?;
    }
    if let Some(now) = wf_core::time_fmt::parse_rfc3339_millis(&ctx.now) {
        // Daily, gated inside: the first turn's end of a day pays for the retention sweep.
        if tracker.prune(now)? > 0 || matches!(events.last(), Some(TrackedEvent::SessionEnd(_))) {
            storage.prune_logs(sessions.retention_months as usize, now)?;
        }
    }
    Ok(Some(summary))
}

fn slash_command(prompt: &str) -> Option<String> {
    let rest = prompt.trim_start().strip_prefix('/')?;
    let name: String = rest
        .chars()
        .take_while(|c| c.is_ascii_alphanumeric() || "_-:".contains(*c))
        .collect();
    valid_skill_name(&name).then_some(name)
}

fn skill_from_read(input: &Value) -> Option<String> {
    let path = ["file_path", "filePath", "path"]
        .iter()
        .find_map(|k| input.get(k).and_then(Value::as_str))?;
    let lower = path.to_ascii_lowercase();
    if !lower.ends_with("/skill.md") {
        return None;
    }
    let dir = &path[..path.len() - "/SKILL.md".len()];
    let name = dir.rsplit('/').next()?;
    valid_skill_name(name).then(|| name.to_string())
}

/// `^[A-Za-z0-9_\-:.]{1,200}$` — a skill name, and nothing that could smuggle a path.
pub fn valid_skill_name(name: &str) -> bool {
    (1..=200).contains(&name.len())
        && name
            .bytes()
            .all(|b| b.is_ascii_alphanumeric() || b"_-:.".contains(&b))
}

/// The skill a `Skill` tool call names: `skill`, `name`, `skill_name` or `command`, with a
/// `…/<name>/SKILL.md` path or a `/…/<name>` path reduced to the name.
pub fn skill_from_tool_input(input: &Value) -> Option<String> {
    let value = ["skill", "name", "skill_name", "command"]
        .iter()
        .find_map(|k| input.get(k).and_then(Value::as_str))?
        .trim();
    let name = if value.to_ascii_lowercase().ends_with("/skill.md") {
        value[..value.len() - "/SKILL.md".len()]
            .rsplit('/')
            .next()?
    } else if value.starts_with('/') || value.starts_with('~') {
        value.trim_end_matches('/').rsplit('/').next()?
    } else {
        value
    };
    valid_skill_name(name).then(|| name.to_string())
}

/// The canonical tool name: IDE agents report `read_file` where Claude reports `Read`.
pub fn normalize_tool(name: &str) -> String {
    match name {
        "read_file" => "Read",
        "edit_file" | "search_replace" => "Edit",
        "write_file" => "Write",
        "run_terminal_cmd" | "run_terminal_command" => "Bash",
        "grep_search" => "Grep",
        "file_search" => "Glob",
        "list_dir" => "LS",
        "skill" => "Skill",
        "todowrite" => "TodoWrite",
        other => other,
    }
    .to_string()
}

/// A session's first prompt as it may be kept: redacted, whitespace collapsed, 160 characters.
pub fn prompt_summary(text: &str) -> String {
    wf_core::redact::redact(text)
        .split_whitespace()
        .collect::<Vec<_>>()
        .join(" ")
        .chars()
        .take(160)
        .collect()
}

/// Words that mark a prompt as a person correcting the agent (teamai's list).
pub const CORRECTION_KEYWORDS: &[&str] = &[
    "不对",
    "不是",
    "错了",
    "错误",
    "重来",
    "重新",
    "撤销",
    "回退",
    "别这样",
    "不要",
    "wrong",
    "redo",
    "undo",
    "revert",
    "mistake",
    "instead",
    "don't",
    "that's not",
    "not what",
    "違う",
    "ちがう",
    "そうじゃな",
    "そうではな",
    "やり直",
    "やりなおし",
    "間違って",
    "間違え",
    "勝手に",
    "戻して",
];

pub fn is_correction(text: &str) -> bool {
    let lower = text.to_lowercase();
    CORRECTION_KEYWORDS.iter().any(|k| lower.contains(k))
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn ctx<'a>(
        agent: &'a str,
        event: HookEvent,
        skills: &'a dyn Fn(&str) -> bool,
    ) -> HookContext<'a> {
        HookContext {
            agent,
            event,
            now: "2026-09-16T10:00:00.000Z".into(),
            fallback_session: &|| "pid-42".to_string(),
            is_skill: skills,
        }
    }

    fn any_skill(_: &str) -> bool {
        true
    }

    #[test]
    fn a_skill_tool_call_is_a_tool_use_and_a_shared_skill_use() {
        let payload = json!({"session_id": "s1", "hook_event_name": "PostToolUse", "tool_name": "Skill", "tool_input": {"skill": "magi:lfg"}});
        let events = events_from_hook(
            &ctx("claude-code", HookEvent::PostToolUse, &any_skill),
            &payload,
        );
        assert_eq!(
            events,
            vec![
                TrackedEvent::ToolUse(ToolUseEvent {
                    session_id: "s1".into(),
                    agent: "claude-code".into(),
                    tool_name: "Skill".into(),
                    timestamp: "2026-09-16T10:00:00.000Z".into()
                }),
                TrackedEvent::Skill(SkillUsageEvent {
                    timestamp: "2026-09-16T10:00:00.000Z".into(),
                    session_id: "s1".into(),
                    agent: "claude-code".into(),
                    skill_name: "magi:lfg".into(),
                    source: SkillSource::Shared
                }),
            ]
        );
    }

    #[test]
    fn reading_a_skill_file_is_a_cursor_read_of_that_skill() {
        let payload = json!({"conversation_id": "c9", "tool_name": "read_file", "tool_input": {"filePath": "/home/u/.cursor/skills/ic/SKILL.md"}});
        let events = events_from_hook(&ctx("cursor", HookEvent::PostToolUse, &any_skill), &payload);
        assert!(events.contains(&TrackedEvent::ToolUse(ToolUseEvent {
            session_id: "c9".into(),
            agent: "cursor".into(),
            tool_name: "Read".into(),
            timestamp: "2026-09-16T10:00:00.000Z".into()
        })));
        assert!(
            matches!(&events[1], TrackedEvent::Skill(s) if s.skill_name == "ic" && s.source == SkillSource::CursorRead)
        );
        let other = json!({"session_id": "s", "tool_name": "Read", "tool_input": {"file_path": "/repo/README.md"}});
        assert_eq!(
            events_from_hook(
                &ctx("claude-code", HookEvent::PostToolUse, &any_skill),
                &other
            )
            .len(),
            1
        );
    }

    #[test]
    fn a_slash_command_is_a_skill_only_when_the_agent_has_that_skill() {
        let known = |name: &str| name == "lfg";
        let payload = json!({"session_id": "s1", "prompt": "/lfg add dark mode"});
        let events = events_from_hook(
            &ctx("claude-code", HookEvent::UserPromptSubmit, &known),
            &payload,
        );
        assert!(matches!(&events[0], TrackedEvent::Prompt(p) if p.text == "/lfg add dark mode"));
        assert!(
            matches!(&events[1], TrackedEvent::Skill(s) if s.skill_name == "lfg" && s.source == SkillSource::SlashCommand)
        );
        let builtin = json!({"session_id": "s1", "prompt": "/clear"});
        assert_eq!(
            events_from_hook(
                &ctx("claude-code", HookEvent::UserPromptSubmit, &known),
                &builtin
            )
            .len(),
            1
        );
    }

    #[test]
    fn session_boundaries_carry_what_the_hook_said_about_them() {
        let start = json!({"session_id": "s1", "source": "startup", "cwd": "/work"});
        let events = events_from_hook(
            &ctx("claude-code", HookEvent::SessionStart, &any_skill),
            &start,
        );
        assert_eq!(
            events,
            vec![TrackedEvent::SessionStart(SessionEvent {
                session_id: "s1".into(),
                agent: "claude-code".into(),
                timestamp: "2026-09-16T10:00:00.000Z".into(),
                metadata: json!({"cwd": "/work", "source": "startup"})
            })]
        );
        let end = json!({"session_id": "s1", "reason": "logout"});
        assert!(
            matches!(&events_from_hook(&ctx("claude-code", HookEvent::SessionEnd, &any_skill), &end)[0], TrackedEvent::SessionEnd(e) if e.metadata["reason"] == "logout")
        );
        assert!(matches!(
            &events_from_hook(
                &ctx("codex", HookEvent::Stop, &any_skill),
                &json!({"session_id": "s"})
            )[0],
            TrackedEvent::Stop(_)
        ));
        assert!(
            events_from_hook(
                &ctx("codex", HookEvent::PreToolUse, &any_skill),
                &json!({"session_id": "s", "tool_name": "Bash"})
            )
            .is_empty(),
            "before a tool runs nothing has happened yet"
        );
    }

    #[test]
    fn a_payload_without_a_session_uses_the_fallback() {
        let events = events_from_hook(&ctx("zcode", HookEvent::Stop, &any_skill), &json!({}));
        assert!(matches!(&events[0], TrackedEvent::Stop(e) if e.session_id == "pid-42"));
        assert!(
            matches!(&events_from_hook(&ctx("zcode", HookEvent::Stop, &any_skill), &json!("not an object"))[0], TrackedEvent::Stop(e) if e.session_id == "pid-42")
        );
    }

    #[test]
    fn skill_names_are_names_and_paths_reduce_to_names() {
        assert_eq!(
            skill_from_tool_input(&json!({"skill": "lfg"})).as_deref(),
            Some("lfg")
        );
        assert_eq!(
            skill_from_tool_input(&json!({"name": " ic "})).as_deref(),
            Some("ic")
        );
        assert_eq!(
            skill_from_tool_input(&json!({"command": "/home/u/.claude/skills/plan/SKILL.md"}))
                .as_deref(),
            Some("plan")
        );
        assert_eq!(
            skill_from_tool_input(&json!({"skill_name": "~/skills/research"})).as_deref(),
            Some("research")
        );
        assert_eq!(
            skill_from_tool_input(&json!({"skill": "../../etc/passwd x"})),
            None
        );
        assert_eq!(skill_from_tool_input(&json!({})), None);
        assert!(valid_skill_name("magi:ready-for-review"));
        assert!(!valid_skill_name(""));
        assert!(!valid_skill_name("a/b"));
        assert!(!valid_skill_name(&"x".repeat(201)));
    }

    #[test]
    fn tool_names_normalise_across_agents() {
        assert_eq!(normalize_tool("read_file"), "Read");
        assert_eq!(normalize_tool("edit_file"), "Edit");
        assert_eq!(normalize_tool("run_terminal_cmd"), "Bash");
        assert_eq!(normalize_tool("Grep"), "Grep");
    }

    #[test]
    fn a_prompt_summary_is_redacted_collapsed_and_short() {
        let summary = prompt_summary(
            "fix   the build\n\nmy token is ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ and then some",
        );
        assert!(!summary.contains("ghp_ABCD"), "{summary}");
        assert!(
            summary.starts_with("fix the build my token is"),
            "{summary}"
        );
        assert_eq!(prompt_summary(&"长".repeat(500)).chars().count(), 160);
    }

    /// One hook invocation, end to end: its events recorded, and at a turn's end or the
    /// session's the summary kept — in the monthly log only when the session was worth it.
    #[test]
    fn a_hook_records_its_events_and_keeps_the_session_it_ends() {
        let dir = tempfile::tempdir().unwrap();
        let db = wf_state::Db::open_memory().unwrap();
        let policies = crate::policy::Policies::default();
        let known = |name: &str| name == "lfg";
        let hook = |event, payload: Value| {
            record_hook(
                &db,
                dir.path(),
                &policies,
                &ctx("codex", event, &known),
                &payload,
            )
            .unwrap()
        };
        let log = dir.path().join("sessions/2026-09.md");

        assert!(hook(
            HookEvent::UserPromptSubmit,
            json!({"session_id": "s1", "prompt": "/lfg a thing"})
        )
        .is_none());
        let quiet = hook(HookEvent::Stop, json!({"session_id": "s1"})).unwrap();
        assert!(!quiet.valuable && quiet.skills == ["lfg"], "{quiet:?}");
        assert!(!log.exists(), "not worth a log entry yet");

        for tool in ["Bash", "Edit", "Grep"] {
            hook(
                HookEvent::PostToolUse,
                json!({"session_id": "s1", "tool_name": tool}),
            );
        }
        assert!(
            hook(HookEvent::Stop, json!({"session_id": "s1"}))
                .unwrap()
                .valuable
        );
        assert!(std::fs::read_to_string(&log)
            .unwrap()
            .contains("Tools: 3 (3 distinct)"));

        hook(
            HookEvent::PostToolUse,
            json!({"session_id": "s1", "tool_name": "Read"}),
        );
        let ended = hook(
            HookEvent::SessionEnd,
            json!({"session_id": "s1", "reason": "exit"}),
        )
        .unwrap();
        assert!(ended.end.is_some());
        let text = std::fs::read_to_string(&log).unwrap();
        assert_eq!(text.matches("<!-- wf:session s1 -->").count(), 1, "{text}");
        assert!(text.contains("Tools: 4 (4 distinct)"), "{text}");
        let row = db.session_summary("s1").unwrap().unwrap();
        assert_eq!(row.tool_count, 4);
        assert!(row.end_time.is_some());
    }

    #[test]
    fn a_hook_under_a_policy_that_turned_tracking_off_records_nothing() {
        let dir = tempfile::tempdir().unwrap();
        let db = wf_state::Db::open_memory().unwrap();
        let mut policies = crate::policy::Policies::default();
        policies.usage.enabled = false;
        let summary = record_hook(
            &db,
            dir.path(),
            &policies,
            &ctx("codex", HookEvent::Stop, &any_skill),
            &json!({"session_id": "s1"}),
        )
        .unwrap();
        assert!(summary.is_none());
        assert!(db
            .usage_events(&wf_state::UsageQuery::default())
            .unwrap()
            .is_empty());
        assert!(std::fs::read_dir(dir.path()).unwrap().next().is_none());
    }

    #[test]
    fn corrections_are_recognised_in_several_languages() {
        assert!(is_correction("No, that's not what I asked"));
        assert!(is_correction("不对，重新来"));
        assert!(is_correction("Please REVERT that"));
        assert!(!is_correction("great, now add tests"));
    }
}
