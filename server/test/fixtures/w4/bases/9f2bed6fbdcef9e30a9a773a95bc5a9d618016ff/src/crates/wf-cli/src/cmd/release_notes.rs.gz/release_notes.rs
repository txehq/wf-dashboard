//! `wf release-notes` — the derived half only.
//!
//! It prints facts and refuses to write prose. The skill supplies the judgment, which is the
//! half a reader actually wants and the half no command can produce.

use super::emit;
use std::path::PathBuf;
use wf_core::{envelope::Envelope, envelope::Note, Error, ExitCode, Result};

pub fn run(json: bool, from: Option<&str>, to: &str, root: Option<&str>) -> Result<ExitCode> {
    let root: PathBuf = root
        .map(PathBuf::from)
        .unwrap_or_else(super::tools::git_root);

    // Default to the last tag. Stated rather than silently assumed: a range the caller did
    // not choose is the most likely reason a set of notes describes the wrong release.
    let from = match from {
        Some(f) => f.to_string(),
        None => wf_release_notes::previous_tag(&root).ok_or_else(|| {
            Error::usage(
                "RELEASE-NOTES-NO-TAG",
                "no tag to start from — pass --from explicitly",
            )
            .with_zh("仓库没有可用的标签，请用 --from 指定起点。")
        })?,
    };

    let facts = wf_release_notes::gather(&root, &from, to)?;
    let prs = facts.pr_numbers();

    let mut env = Envelope::new("release-notes").result(&facts);
    if !facts.migrations.is_empty() {
        // Surfaced as a warning, not a list item: a migration decides whether the release can
        // be rolled back, and the notes must not let a reader skim past it.
        env = env.warn(Note::new(
            "MIGRATION",
            format!(
                "{} migration file(s) in this range — the release is not freely reversible; \
                 say so in its own section",
                facts.migrations.len()
            ),
        ));
    }
    if facts.tickets.is_empty() {
        env = env.warn(Note::new(
            "NO-TICKETS",
            "no ticket ids found in the range — nothing to record the published page against"
                .to_string(),
        ));
    }

    let text = render(&facts, &prs);
    Ok(emit(json, env, move || text))
}

fn render(facts: &wf_release_notes::Facts, prs: &[u32]) -> String {
    let mut s = format!(
        "{}..{}\n  {} commit(s), {} pull request(s), {} ticket(s)\n",
        facts.from,
        facts.to,
        facts.changes.len(),
        prs.len(),
        facts.tickets.len()
    );
    if !facts.surfaces.is_empty() {
        s.push_str(&format!("  surfaces  {}\n", facts.surfaces.join(", ")));
    }
    if !facts.migrations.is_empty() {
        s.push_str(&format!("  MIGRATIONS ({})\n", facts.migrations.len()));
        for m in &facts.migrations {
            s.push_str(&format!("    {m}\n"));
        }
    }
    if !facts.tickets.is_empty() {
        s.push_str(&format!("  tickets   {}\n", facts.tickets.join(", ")));
    }
    s.push('\n');
    for c in &facts.changes {
        let pr = c.pr.map(|n| format!("#{n}")).unwrap_or_else(|| "—".into());
        s.push_str(&format!("  {:>6}  {}  ({})\n", pr, c.subject, c.author));
    }
    s.push_str(
        "\nThese are facts, not notes. The page says what changed for a reader, what to\n\
         watch, and what did not ship — see the skill.\n",
    );
    s
}
