//! Shared substrate: errors and their exit codes, the JSON envelope every scriptable
//! command speaks, platform paths, content hashing, atomic file replacement, a process
//! runner that never touches a shell, and secret redaction.
//!
//! Nothing here knows about registries, releases or agents. If a type in this crate needs
//! to know what a component is, it belongs one crate up.

pub mod atomic;
pub mod envelope;
pub mod error;
pub mod hash;
pub mod lock;
pub mod paths;
pub mod proc;
pub mod redact;
pub mod time_fmt;
pub mod zh;

pub use error::{Error, ExitCode, Result};

/// The single SemVer for the whole product (D-017). Every rendered manifest reads this.
pub const VERSION: &str = env!("CARGO_PKG_VERSION");

/// Default upstream this build syncs from. Overridable per-invocation with `--repo`.
pub const DEFAULT_REPO: &str = "txehq/txe-workflow";
/// Default branch an installation records when no release channel is in play.
pub const DEFAULT_BRANCH: &str = "main";

/// The GitHub organization everything this workflow resolves lives under.
pub const ORG: &str = "txehq";
/// What [`ORG`] was called until 2026-09-13 (TXE-1927). Comparison-only: the freed name can
/// be registered by anyone, so it must never reach a GitHub lookup. It exists so a value
/// recorded or typed before the rename is read as the org it meant.
pub const FORMER_ORG: &str = "capsohq";

/// `owner` with the former org name read as the current one.
pub fn canonical_owner(owner: &str) -> &str {
    if owner.eq_ignore_ascii_case(FORMER_ORG) {
        ORG
    } else {
        owner
    }
}

/// `owner/name` with the former org name read as the current one; anything else unchanged.
pub fn canonical_repo(repo: &str) -> String {
    match repo.split_once('/') {
        Some((owner, name)) => format!("{}/{name}", canonical_owner(owner)),
        None => repo.to_string(),
    }
}

/// A recorded release source (`github:owner/repo`, bare `owner/repo`, or `local:…`) with
/// the former org name read as the current one; a local source is unchanged.
pub fn canonical_source(spec: &str) -> String {
    match spec.strip_prefix("github:") {
        Some(repo) => format!("github:{}", canonical_repo(repo)),
        None if spec.contains(':') => spec.to_string(),
        None => canonical_repo(spec),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_former_org_is_read_as_the_current_one_and_nothing_else_is() {
        assert_eq!(canonical_repo("capsohq/txe-workflow"), DEFAULT_REPO);
        assert_eq!(canonical_repo("CapsoHQ/tokun-cn"), "txehq/tokun-cn");
        assert_eq!(canonical_repo("txehq/txe"), "txehq/txe");
        assert_eq!(canonical_repo("someone/capsohq"), "someone/capsohq");
        assert_eq!(canonical_repo("capsohq-fork/txe"), "capsohq-fork/txe");
        assert_eq!(canonical_owner("capsohq"), ORG);
        assert_eq!(
            canonical_source("github:capsohq/txe-workflow"),
            "github:txehq/txe-workflow"
        );
        assert_eq!(canonical_source("capsohq/txe-workflow"), DEFAULT_REPO);
        assert_eq!(
            canonical_source("local:/tmp/capsohq/x"),
            "local:/tmp/capsohq/x"
        );
        assert_eq!(canonical_source(""), "");
    }
}
