//! `wf guard` — the CI gate for this repository's documents, rules, skills and release
//! surfaces.
//!
//! Ported from `cmd/docsguard` with every finding code and message preserved, because a CI
//! log people have learned to read is an interface. What is new here is the half the Go
//! version could not have: the component registry, the agent layer's configuration, and the
//! rule that a change to a release surface must move the one version.
//!
//! The generated surfaces are rendered byte-for-byte as the Go implementation rendered
//! them. That is not nostalgia — it is how the migration proved itself: the ported guard
//! produced the same bytes for the same tree, so nothing in `docs/` had to change on the
//! way across.

pub mod registry;
pub mod render;
pub mod rules;

use std::collections::{BTreeMap, BTreeSet};
use std::path::Path;
use wf_core::Result;

pub const REGISTRY_PATH: &str = "docs/index.yaml";
pub const RULES_PATH: &str = "docs/contract/rules.yaml";
pub const SKILLS_DIR: &str = "skills";
pub const RECORD_DIR: &str = "docs/product/features";

/// One violation. Code is stable and greppable; a check that cannot name which file it is
/// unhappy about is a check nobody can act on.
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, serde::Serialize)]
pub struct Finding {
    pub code: String,
    pub path: String,
    pub msg: String,
}

impl std::fmt::Display for Finding {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}  {}: {}", self.code, self.path, self.msg)
    }
}

fn f(code: &str, path: impl Into<String>, msg: impl Into<String>) -> Finding {
    Finding {
        code: code.into(),
        path: path.into(),
        msg: msg.into(),
    }
}

/// Run every check. `now` is injectable so the tests exercise the checker rather than the
/// calendar; the real run uses today, which is what makes a stamp expire.
pub fn run(
    root: &Path,
    fix: bool,
    now: time::Date,
    base_ref: Option<&str>,
) -> Result<Vec<Finding>> {
    let reg = registry::Registry::load(root)?;
    let rules = rules::Rules::load(root)?;
    let component_findings = check_components(root)?;
    let teamai_findings = check_teamai(root)?;

    // Nothing is rendered from a tree whose components or agent configuration do not read:
    // a malformed source is not equivalent to one that renders nothing.
    if fix && component_findings.is_empty() && teamai_findings.is_empty() {
        render::write_generated(root, &reg)?;
    }

    let mut out = Vec::new();
    out.extend(check_doc_set(root, &reg)?);
    out.extend(check_skills(root, &reg)?);
    out.extend(rules::check_rules(root, &rules)?);
    out.extend(rules::check_claims(&rules, &reg.policy, now));
    out.extend(check_stamps(root, &reg, now)?);
    out.extend(check_generated(root, &reg)?);
    out.extend(check_retired_plugin(root));
    out.extend(check_shell(root, &reg.policy)?);
    out.extend(check_command_paths(root)?);
    out.extend(component_findings);
    out.extend(teamai_findings);
    if let Some(base) = base_ref {
        out.extend(check_version_gate(root, base)?);
    }

    out.sort();
    Ok(out)
}

// --- documents --------------------------------------------------------------------

/// The registry and the tree are the same set (WFR-003).
fn check_doc_set(root: &Path, reg: &registry::Registry) -> Result<Vec<Finding>> {
    let on_disk = scan_docs(root)?;
    let mut registered = BTreeSet::new();
    let mut out = Vec::new();
    for d in &reg.docs {
        if !registered.insert(d.path.clone()) {
            out.push(f(
                "IDX003",
                &d.path,
                format!("listed twice in {REGISTRY_PATH}"),
            ));
            continue;
        }
        if !root.join(&d.path).exists() {
            out.push(f(
                "IDX002",
                &d.path,
                format!("registered in {REGISTRY_PATH} but not on disk"),
            ));
        }
        if d.surface != "prose" && d.surface != "generated" {
            out.push(f(
                "IDX004",
                &d.path,
                format!(
                    "surface must be prose or generated, got {}",
                    quote(&d.surface)
                ),
            ));
        }
        if d.stamp != "required" && d.stamp != "none" {
            out.push(f(
                "IDX005",
                &d.path,
                format!("stamp must be required or none, got {}", quote(&d.stamp)),
            ));
        }
        if d.surface == "prose" && d.read_when.trim().is_empty() {
            out.push(f(
                "IDX006",
                &d.path,
                "prose document has no read_when — the router would list it with no trigger",
            ));
        }
    }
    for p in on_disk {
        if !registered.contains(&p) {
            out.push(f(
                "IDX001",
                &p,
                format!("on disk but absent from {REGISTRY_PATH} — an unregistered document is an orphan"),
            ));
        }
    }
    Ok(out)
}

fn scan_docs(root: &Path) -> Result<Vec<String>> {
    let mut out = Vec::new();
    for e in std::fs::read_dir(root)? {
        let e = e?;
        if e.path().is_file() && e.file_name().to_string_lossy().ends_with(".md") {
            out.push(e.file_name().to_string_lossy().into_owned());
        }
    }
    let docs = root.join("docs");
    if docs.is_dir() {
        for e in walkdir::WalkDir::new(&docs)
            .follow_links(false)
            .into_iter()
            .flatten()
        {
            if !e.file_type().is_file() {
                continue;
            }
            let ext = e.path().extension().and_then(|x| x.to_str()).unwrap_or("");
            if ext != "md" && ext != "yaml" {
                continue;
            }
            if let Ok(rel) = e.path().strip_prefix(root) {
                out.push(rel.to_string_lossy().replace('\\', "/"));
            }
        }
    }
    out.sort();
    Ok(out)
}

/// The skills roster, the `skills/` tree and the feature records agree (WFR-002, WFR-008).
fn check_skills(root: &Path, reg: &registry::Registry) -> Result<Vec<Finding>> {
    let node_re = regex::Regex::new(r"^WF-[A-Z]+$").unwrap();
    let mut out = Vec::new();
    let mut rostered: BTreeMap<String, &registry::Skill> = BTreeMap::new();

    for s in &reg.skills {
        if !node_re.is_match(&s.node) {
            out.push(f(
                "SPC001",
                REGISTRY_PATH,
                format!(
                    "skill {}: node {} is not a WF-* code",
                    quote(&s.name),
                    quote(&s.node)
                ),
            ));
        }
        if s.spec.trim().is_empty() {
            out.push(f(
                "SPC002",
                REGISTRY_PATH,
                format!(
                    "skill {} has no spec pointer — its design authority is unrecorded",
                    quote(&s.name)
                ),
            ));
        }
        if s.status != "shipped" && s.status != "planned" {
            out.push(f(
                "SKL004",
                REGISTRY_PATH,
                format!(
                    "skill {}: status must be shipped or planned, got {}",
                    quote(&s.name),
                    quote(&s.status)
                ),
            ));
        }
        if rostered.insert(s.name.clone(), s).is_some() {
            out.push(f(
                "SKL005",
                REGISTRY_PATH,
                format!("skill {} is rostered twice", quote(&s.name)),
            ));
        }

        let skill_file = root.join(SKILLS_DIR).join(&s.name).join("SKILL.md");
        let exists = skill_file.exists();
        if s.status == "shipped" && !exists {
            out.push(f(
                "SKL001",
                format!("{SKILLS_DIR}/{}", s.name),
                "rostered as shipped but has no SKILL.md",
            ));
        }
        if s.status == "planned" && exists {
            out.push(f(
                "SKL001",
                format!("{SKILLS_DIR}/{}", s.name),
                "rostered as planned but SKILL.md exists — the roster is behind the tree",
            ));
        }

        if s.status == "shipped" {
            let record = format!("{RECORD_DIR}/{}.md", s.name);
            if !root.join(&record).exists() {
                out.push(f(
                    "SKL003",
                    &record,
                    format!("shipped skill {} has no feature record", quote(&s.name)),
                ));
            }
            if exists {
                let rel = format!("{SKILLS_DIR}/{}/SKILL.md", s.name);
                match registry::front_matter(&skill_file)? {
                    None => out.push(f(
                        "SKL002",
                        &rel,
                        "no YAML frontmatter — name and description are the catalog source",
                    )),
                    Some(fm) => {
                        let name = fm.get("name").cloned().unwrap_or_default();
                        if name != s.name {
                            out.push(f(
                                "SKL002",
                                &rel,
                                format!(
                                    "frontmatter name {} does not match its directory {}",
                                    quote(&name),
                                    quote(&s.name)
                                ),
                            ));
                        }
                        if fm
                            .get("description")
                            .map(|d| d.trim().is_empty())
                            .unwrap_or(true)
                        {
                            out.push(f("SKL002", &rel, "frontmatter description is empty — a session matches on it to decide whether to invoke the skill"));
                        }
                    }
                }
            }
        }
    }

    if let Ok(entries) = std::fs::read_dir(root.join(SKILLS_DIR)) {
        for e in entries.flatten() {
            if !e.path().is_dir() {
                continue;
            }
            let name = e.file_name().to_string_lossy().into_owned();
            if !rostered.contains_key(&name) {
                out.push(f(
                    "SKL001",
                    format!("{SKILLS_DIR}/{name}"),
                    format!("skill directory is absent from the roster in {REGISTRY_PATH}"),
                ));
            }
        }
    }
    Ok(out)
}

/// A document that must carry `last-verified` carries it, and it is fresh (WFR-005).
fn check_stamps(root: &Path, reg: &registry::Registry, now: time::Date) -> Result<Vec<Finding>> {
    let mut out = Vec::new();
    for d in &reg.docs {
        if d.stamp != "required" {
            continue;
        }
        let full = root.join(&d.path);
        if !full.exists() {
            continue; // already reported by IDX002
        }
        let Some(fm) = registry::front_matter(&full)? else {
            out.push(f(
                "STM001",
                &d.path,
                "stamp required but no last-verified in frontmatter",
            ));
            continue;
        };
        let Some(raw) = fm.get("last-verified").filter(|s| !s.is_empty()) else {
            out.push(f(
                "STM001",
                &d.path,
                "stamp required but no last-verified in frontmatter",
            ));
            continue;
        };
        let Some(when) = registry::parse_date(raw) else {
            out.push(f(
                "STM001",
                &d.path,
                format!("last-verified {} is not YYYY-MM-DD", quote(raw)),
            ));
            continue;
        };
        let age = (now - when).whole_days();
        if age > reg.policy.stamp_max_age_days {
            out.push(f(
                "STM002",
                &d.path,
                format!(
                    "last verified {raw}, {age} days ago (max {}) — re-read it and restamp, or delete it",
                    reg.policy.stamp_max_age_days
                ),
            ));
        }
    }
    Ok(out)
}

/// A generated surface matches what the renderer produces (WFR-004).
fn check_generated(root: &Path, reg: &registry::Registry) -> Result<Vec<Finding>> {
    let want = render::generated(root, reg)?;
    let mut out = Vec::new();
    let mut declared = BTreeSet::new();
    for d in &reg.docs {
        if d.surface != "generated" {
            continue;
        }
        declared.insert(d.path.clone());
        let Some(body) = want.get(&d.path) else {
            out.push(f(
                "GEN002",
                &d.path,
                "declared generated but the guard has no renderer for it",
            ));
            continue;
        };
        let Ok(got) = std::fs::read_to_string(root.join(&d.path)) else {
            continue; // already reported by IDX002
        };
        if &got != body {
            out.push(f(
                "GEN001",
                &d.path,
                "does not match its rendering — run `wf guard --fix` instead of editing it by hand",
            ));
        }
    }
    for p in want.keys() {
        if !declared.contains(p) {
            out.push(f(
                "GEN003",
                p,
                "the guard renders this file but the registry does not declare it generated",
            ));
        }
    }
    Ok(out)
}

/// The plugin package was retired in 2.0 (ADR-0007). Skills, hooks and MCP servers reach
/// every agent through the agent layer; a plugin manifest left in the tree is one a person
/// or a 1.x binary could still install beside them, and every skill would load twice.
fn check_retired_plugin(root: &Path) -> Vec<Finding> {
    ["plugins", ".claude-plugin", ".agents/plugins"]
        .into_iter()
        .filter(|p| root.join(p).exists())
        .map(|p| {
            f(
                "PLG005",
                p,
                "the plugin package was retired in 2.0 — delete it; the agent layer deploys what it carried",
            )
        })
        .collect()
}

/// WFR-010: shell exists here only to bootstrap, and only where the policy allows it.
fn check_shell(root: &Path, p: &registry::Policy) -> Result<Vec<Finding>> {
    let allowed: BTreeSet<&String> = p.shell.allow.iter().collect();
    let mut out = Vec::new();
    for e in walkdir::WalkDir::new(root)
        .follow_links(false)
        .into_iter()
        .filter_entry(|e| {
            let n = e.file_name().to_string_lossy();
            n != ".git" && n != "vendor" && n != "node_modules" && n != "target"
        })
        .flatten()
    {
        if !e.file_type().is_file() {
            continue;
        }
        let Ok(rel) = e.path().strip_prefix(root) else {
            continue;
        };
        let rel = rel.to_string_lossy().replace('\\', "/");
        if !is_shell(e.path()) {
            continue;
        }
        if !allowed.contains(&rel) {
            out.push(f(
                "SHL001",
                &rel,
                "shell script outside the allowlist — WFR-010 keeps shell for bootstrap only; \
                 put the logic in the Rust workspace where it can be tested, or add the path to policy.shell.allow with a reason",
            ));
            continue;
        }
        let lines = std::fs::read(e.path())?
            .iter()
            .filter(|b| **b == b'\n')
            .count() as i64;
        if p.shell.max_lines > 0 && lines > p.shell.max_lines {
            out.push(f(
                "SHL002",
                &rel,
                format!(
                    "{lines} lines, over the {}-line cap for allowlisted shell — a bootstrap that needs this much logic is no longer a bootstrap",
                    p.shell.max_lines
                ),
            ));
        }
    }
    for path in &p.shell.allow {
        if !root.join(path).exists() {
            out.push(f(
                "SHL003",
                path,
                "allowlisted in policy.shell.allow but not on disk",
            ));
        }
    }
    out.sort();
    Ok(out)
}

fn is_shell(path: &Path) -> bool {
    let name = path.to_string_lossy();
    if name.ends_with(".sh") || name.ends_with(".bash") || name.ends_with(".zsh") {
        return true;
    }
    // Deliberately NOT gated on the executable bit: `sh script` runs a file that is not
    // executable, so requiring +x would let anyone past the gate by dropping both the .sh
    // suffix and the mode bit.
    let Ok(bytes) = std::fs::read(path) else {
        return false;
    };
    let head = &bytes[..bytes.len().min(64)];
    if !head.starts_with(b"#!") {
        return false;
    }
    let first = head.split(|b| *b == b'\n').next().unwrap_or(head);
    let first = String::from_utf8_lossy(first);
    ["/sh", "/bash", "/zsh", "/dash", "env sh", "env bash"]
        .iter()
        .any(|s| first.contains(s))
}

/// The subcommands `wf` actually has.
///
/// Held here rather than imported because the CLI depends on this crate, not the other way
/// round. It cannot drift: `wf-cli` has a test that walks clap's own command tree and
/// asserts it matches this list exactly, so adding a subcommand without adding it here
/// fails there.
pub const WF_SUBCOMMANDS: &[&str] = &[
    "install",
    "magi",
    "sync",
    "status",
    "doctor",
    "repair",
    "rollback",
    "uninstall",
    "backup",
    "hook",
    "agents",
    "mcp",
    "usage",
    "sessions",
    "history",
    "deploy-summary",
    "release",
    "release-notes",
    "review-pr",
    "guard",
    "readiness",
    "obsidian",
    "publish-artifact",
    "handover",
];

/// Every command a skill tells a session to run must exist.
///
/// This gate is a measured regression, and it has followed the defect to its new address.
/// Two shipped skills instructed sessions to run a script that had been replaced, and
/// nothing in CI read a skill's own instructions — the only detector was a user getting
/// "No such file or directory". The scripts are gone; the same mistake is now spelled
/// `wf histry search`, so both spellings are checked:
///
/// - CMD001: any `${CLAUDE_PLUGIN_ROOT}/<path>`. Until 2.0 it had to resolve to a file in this
///   repo; since the plugin was retired (ADR-0007) no session has the variable, so every such
///   path fails at the user whether or not the file exists.
/// - CMD002: an `wf <subcommand>` that the binary does not have.
fn check_command_paths(root: &Path) -> Result<Vec<Finding>> {
    let re = regex::Regex::new(
        r#"\$\{CLAUDE_PLUGIN_ROOT\}/([^\s"'`)\\]+)|\$CLAUDE_PLUGIN_ROOT/([^\s"'`)\\]+)"#,
    )
    .unwrap();
    let mut out = Vec::new();
    let skills = root.join(SKILLS_DIR);
    if !skills.is_dir() {
        return Ok(out);
    }
    for e in walkdir::WalkDir::new(&skills)
        .follow_links(false)
        .into_iter()
        .flatten()
    {
        if !e.file_type().is_file() || e.path().extension().and_then(|x| x.to_str()) != Some("md") {
            continue;
        }
        let text = std::fs::read_to_string(e.path())?;
        let rel = e
            .path()
            .strip_prefix(root)
            .unwrap()
            .to_string_lossy()
            .replace('\\', "/");
        let mut seen = BTreeSet::new();
        for (i, line) in text.lines().enumerate() {
            for c in re.captures_iter(line) {
                let raw = c
                    .get(1)
                    .or_else(|| c.get(2))
                    .map(|m| m.as_str())
                    .unwrap_or("");
                let refr = raw.trim_end_matches(['.', ',', ';', ':']);
                if refr.is_empty() || !seen.insert(refr.to_string()) {
                    continue;
                }
                out.push(f(
                    "CMD001",
                    &rel,
                    format!(
                        "line {} instructs a session to use ${{CLAUDE_PLUGIN_ROOT}}/{refr}, but skills are no longer a plugin \
                         and no session has that variable — name the file relative to the skill's own directory",
                        i + 1
                    ),
                ));
            }
        }
    }
    out.extend(check_wf_invocations(root)?);
    out.sort();
    Ok(out)
}

/// CMD002: an `wf <subcommand>` a skill names must be one the binary has.
fn check_wf_invocations(root: &Path) -> Result<Vec<Finding>> {
    let re = regex::Regex::new(r"(?m)^\s*(?:\$ )?wf\s+([a-z][a-z0-9-]*)").unwrap();
    let mut out = Vec::new();
    let skills = root.join(SKILLS_DIR);
    if !skills.is_dir() {
        return Ok(out);
    }
    for e in walkdir::WalkDir::new(&skills)
        .follow_links(false)
        .into_iter()
        .flatten()
    {
        if !e.file_type().is_file() || e.path().extension().and_then(|x| x.to_str()) != Some("md") {
            continue;
        }
        let text = std::fs::read_to_string(e.path())?;
        let rel = e
            .path()
            .strip_prefix(root)
            .unwrap()
            .to_string_lossy()
            .replace('\\', "/");
        let mut seen = BTreeSet::new();
        // Only inside fenced code blocks: prose says "run wf doctor" in sentences, and a
        // guard that fires on English is a guard people turn off.
        let mut fenced = false;
        for (i, line) in text.lines().enumerate() {
            if line.trim_start().starts_with("```") {
                fenced = !fenced;
                continue;
            }
            if !fenced {
                continue;
            }
            for c in re.captures_iter(line) {
                let sub = c[1].to_string();
                if !seen.insert(sub.clone()) {
                    continue;
                }
                if !WF_SUBCOMMANDS.contains(&sub.as_str()) {
                    out.push(f(
                        "CMD002",
                        &rel,
                        format!(
                            "line {} tells a session to run `wf {sub}`, which is not a subcommand —                              a skill that names a command nobody can run fails at the user, not in CI",
                            i + 1
                        ),
                    ));
                }
            }
        }
    }
    Ok(out)
}

/// The component registry validates against the tree.
fn check_components(root: &Path) -> Result<Vec<Finding>> {
    if !root.join("workflow/registry.yaml").exists() {
        return Ok(vec![]);
    }
    let reg = match wf_registry::Registry::load(root) {
        Ok(r) => r,
        Err(e) => return Ok(vec![f("CMP000", "workflow/registry.yaml", e.message)]),
    };
    Ok(wf_registry::validate(&reg, Some(root))
        .into_iter()
        .map(|v| f(&format!("CMP-{}", v.code), v.subject, v.message))
        .collect())
}

/// The TeamAI adapter configuration a release carries, and every resource it names, is what
/// a machine will accept. A machine refuses the whole apply over an invalid `agents.yaml`,
/// `policies.yaml` or `team-config.yaml`, and changes nothing of a kind whose definitions do
/// not read — so each of those is a finding here, before it ships.
fn check_teamai(root: &Path) -> Result<Vec<Finding>> {
    use wf_agents::{policy, registry, team_repo};
    let dir = root.join("workflow/teamai");
    if !dir.is_dir() {
        return Ok(vec![f(
            "TAI001",
            "workflow/teamai",
            "the team configuration directory is missing; without it a release ships no \
             agents.yaml and no policies.yaml"
                .to_string(),
        )]);
    }
    let mut out = Vec::new();
    let mut add = |file: &str, read: Result<Vec<registry::Violation>>| match read {
        Ok(violations) => out.extend(violations.into_iter().map(|v| {
            f(
                &format!("TAI-{}", v.code),
                file,
                format!("{}: {}", v.subject, v.message),
            )
        })),
        Err(e) => out.push(f("TAI000", file, e.message)),
    };
    add(
        registry::AGENTS_FILE,
        registry::AgentRegistry::load(root).map(|r| r.validate()),
    );
    add(
        policy::POLICIES_FILE,
        policy::Policies::load(root).map(|p| p.validate()),
    );
    add(
        team_repo::TEAM_CONFIG_FILE,
        team_repo::TeamConfig::load(root).map(|c| c.validate()),
    );
    // Every scan error too, not only the first configuration finding: one run has to name
    // everything wrong with the tree, or fixing it is one release candidate per defect.
    match team_repo::TeamRepo::open(root) {
        Ok(repo) => {
            for (kind, items) in wf_agents::adapter::Desired::scan(&repo).items {
                if let Err(message) = items {
                    out.push(f("TAI-SCAN", kind.as_str(), message));
                }
            }
        }
        Err(e) => out.push(f("TAI000", team_repo::TEAM_CONFIG_FILE, e.message)),
    }
    Ok(out)
}

/// A change to a release surface must move the one version.
///
/// This is the check TXE-1664 named and nothing implemented: manifests that disagreed were
/// caught, a change that forgot to bump anything was not. The surfaces are exactly the ones
/// a user can observe — skills, the workflow sources, and the executable behaviour.
fn check_version_gate(root: &Path, base_ref: &str) -> Result<Vec<Finding>> {
    let out_ref = wf_core::proc::run(
        "git",
        &[
            "-C",
            &root.to_string_lossy(),
            "merge-base",
            base_ref,
            "HEAD",
        ],
        std::time::Duration::from_secs(30),
    )?;
    if !out_ref.ok() {
        return Ok(vec![f(
            "VER003",
            ".",
            format!("cannot resolve merge base with {base_ref} — the version gate did not run"),
        )]);
    }
    let base = out_ref.stdout.trim().to_string();

    let diff = wf_core::proc::run(
        "git",
        &[
            "-C",
            &root.to_string_lossy(),
            "diff",
            "--name-only",
            &base,
            "HEAD",
        ],
        std::time::Duration::from_secs(30),
    )?;
    if !diff.ok() {
        return Ok(vec![f(
            "VER003",
            ".",
            "cannot diff against the merge base — the version gate did not run",
        )]);
    }
    const SURFACES: [&str; 3] = ["skills/", "workflow/", "crates/"];
    let touched: Vec<&str> = diff
        .stdout
        .lines()
        .map(str::trim)
        .filter(|p| SURFACES.iter().any(|s| p.starts_with(s)))
        .collect();
    if touched.is_empty() {
        return Ok(vec![]);
    }

    let before = wf_core::proc::run(
        "git",
        &[
            "-C",
            &root.to_string_lossy(),
            "show",
            &format!("{base}:Cargo.toml"),
        ],
        std::time::Duration::from_secs(30),
    )?;
    let old = before.ok().then(|| version_in(&before.stdout)).flatten();
    match old {
        Some(old) if old == wf_core::VERSION => Ok(vec![f(
            "VER001",
            "Cargo.toml",
            format!(
                "{} release surface file(s) changed since {base_ref} but the version is still {old} — \
                 every user-observable change moves the one SemVer (first: {})",
                touched.len(),
                touched[0]
            ),
        )]),
        _ => Ok(vec![]),
    }
}

fn version_in(cargo_toml: &str) -> Option<String> {
    let mut in_pkg = false;
    for line in cargo_toml.lines() {
        let t = line.trim();
        if t.starts_with('[') {
            in_pkg = t == "[workspace.package]";
            continue;
        }
        if in_pkg {
            if let Some(v) = t.strip_prefix("version") {
                return Some(
                    v.trim_start_matches([' ', '='])
                        .trim()
                        .trim_matches('"')
                        .to_string(),
                );
            }
        }
    }
    None
}

pub fn quote(s: &str) -> String {
    format!("{s:?}")
}
