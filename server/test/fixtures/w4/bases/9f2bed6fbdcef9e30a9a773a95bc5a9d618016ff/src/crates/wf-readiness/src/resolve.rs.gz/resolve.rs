use std::collections::BTreeMap;
use std::path::{Path, PathBuf};
use std::time::Duration;

/// The environment this process was started in — what the agent's own tool calls see. A
/// tool missing here cannot be run by the session, whatever the developer's terminal shows.
pub const CTX_SESSION: &str = "session";
/// `$SHELL -lc`: what the developer sees when they type the command.
pub const CTX_LOGIN: &str = "login";
/// The POSIX default PATH: what a hook, a cron job or a bare spawned process sees when
/// nothing sources a profile.
pub const CTX_MINIMAL: &str = "minimal";

/// `_PATH_DEFPATH`. Deliberately excludes `/usr/local/bin`: that directory reaches a shell
/// through `/etc/profile`'s path_helper, which a bare spawn never runs.
const MINIMAL_PATH: &str = "/usr/bin:/bin:/usr/sbin:/sbin";

/// Where one binary is found in each context, and by what.
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct Resolution {
    pub bin: String,
    /// context → absolute path, absent when not found.
    pub paths: BTreeMap<String, String>,
    /// homebrew, pyenv, asdf, mise, nvm, rustup, virtualenv, …
    pub manager: String,
    pub shim: bool,
    /// False when the login shell could not be consulted.
    pub login_known: bool,
}

impl Resolution {
    pub fn in_ctx(&self, ctx: &str) -> &str {
        self.paths.get(ctx).map(String::as_str).unwrap_or("")
    }
    pub fn found_in(&self, ctx: &str) -> bool {
        !self.in_ctx(ctx).is_empty()
    }
    /// Do the session and login contexts disagree — either on presence or on which binary
    /// wins? Both matter: a different path means the developer's terminal and the session
    /// are running different builds.
    pub fn diverges(&self) -> bool {
        self.login_known && self.in_ctx(CTX_SESSION) != self.in_ctx(CTX_LOGIN)
    }
}

/// Resolves binaries by stat alone, against PATH strings captured up front.
///
/// The login shell is consulted at most once per run however many tools are checked, which
/// is what keeps the fast path free of process spawns.
pub struct Resolver {
    session_path: String,
    virtual_env: String,
    home: String,
    login: std::cell::RefCell<Option<(String, bool)>>,
    pub spawns: std::cell::Cell<u32>,
}

impl Default for Resolver {
    fn default() -> Self {
        Self::new()
    }
}

impl Resolver {
    pub fn new() -> Self {
        Self {
            session_path: std::env::var("PATH").unwrap_or_default(),
            virtual_env: std::env::var("VIRTUAL_ENV").unwrap_or_default(),
            home: std::env::var("HOME").unwrap_or_default(),
            login: std::cell::RefCell::new(None),
            spawns: std::cell::Cell::new(0),
        }
    }

    pub fn with_paths(session: &str, login: Option<&str>, home: &str) -> Self {
        Self {
            session_path: session.to_string(),
            virtual_env: String::new(),
            home: home.to_string(),
            login: std::cell::RefCell::new(Some(match login {
                Some(l) => (l.to_string(), true),
                None => (String::new(), false),
            })),
            spawns: std::cell::Cell::new(0),
        }
    }

    /// The session-context lookup alone: pure stat, and in particular it never consults the
    /// login shell. The cache's fast path is built on it, which is what lets this promise
    /// that an unchanged machine costs no process spawns at all.
    pub fn resolve_session(&self, bin: &str) -> String {
        look_in(&self.session_path, bin)
    }

    fn login_path(&self) -> (String, bool) {
        if self.login.borrow().is_none() {
            let shell = std::env::var("SHELL").unwrap_or_default();
            let got = if shell.is_empty() {
                (String::new(), false)
            } else {
                self.spawns.set(self.spawns.get() + 1);
                match wf_core::proc::run(
                    &shell,
                    &["-lc", "printf %s \"$PATH\""],
                    Duration::from_secs(10),
                ) {
                    Ok(o) if o.ok() && !o.stdout.trim().is_empty() => {
                        (o.stdout.trim().to_string(), true)
                    }
                    _ => (String::new(), false),
                }
            };
            *self.login.borrow_mut() = Some(got);
        }
        self.login.borrow().clone().unwrap()
    }

    pub fn resolve(&self, bin: &str) -> Resolution {
        let (login_path, login_known) = self.login_path();
        let mut paths = BTreeMap::new();
        paths.insert(CTX_SESSION.to_string(), look_in(&self.session_path, bin));
        if login_known {
            paths.insert(CTX_LOGIN.to_string(), look_in(&login_path, bin));
        }
        paths.insert(CTX_MINIMAL.to_string(), look_in(MINIMAL_PATH, bin));

        let found = if !paths[CTX_SESSION].is_empty() {
            paths[CTX_SESSION].clone()
        } else {
            paths.get(CTX_LOGIN).cloned().unwrap_or_default()
        };
        let (manager, shim) = classify(&found, &self.virtual_env, &self.home);
        Resolution {
            bin: bin.to_string(),
            paths,
            manager,
            shim,
            login_known,
        }
    }
}

/// A PATH search by stat — no process spawned, which is what lets the cached fast path stay
/// honest about "nothing was executed".
fn look_in(path_env: &str, bin: &str) -> String {
    let names = crate::catalog::tool(bin)
        .map(|t| t.binaries)
        .unwrap_or(std::slice::from_ref(&bin));
    for name in names {
        for dir in path_env.split(':') {
            if dir.is_empty() {
                continue;
            }
            let p = PathBuf::from(dir).join(name);
            if is_executable(&p) {
                return p.to_string_lossy().into_owned();
            }
        }
    }
    String::new()
}

#[cfg(unix)]
fn is_executable(p: &Path) -> bool {
    use std::os::unix::fs::PermissionsExt;
    std::fs::metadata(p)
        .map(|m| m.is_file() && m.permissions().mode() & 0o111 != 0)
        .unwrap_or(false)
}
#[cfg(not(unix))]
fn is_executable(p: &Path) -> bool {
    p.is_file()
}

/// Name what installed a binary, from where it sits. Knowing the manager is what turns
/// "install it" into a command somebody can actually run.
fn classify(path: &str, virtual_env: &str, home: &str) -> (String, bool) {
    if path.is_empty() {
        return (String::new(), false);
    }
    if !virtual_env.is_empty() && path.starts_with(virtual_env) {
        return ("virtualenv".into(), false);
    }
    let checks: &[(&str, &str, bool)] = &[
        ("/opt/homebrew/", "homebrew", false),
        ("/usr/local/Cellar/", "homebrew", false),
        ("/home/linuxbrew/", "homebrew", false),
        (".pyenv/shims", "pyenv", true),
        (".pyenv/", "pyenv", false),
        (".rbenv/shims", "rbenv", true),
        (".nvm/", "nvm", false),
        (".asdf/shims", "asdf", true),
        (".asdf/", "asdf", false),
        ("/mise/shims", "mise", true),
        (".local/share/mise", "mise", false),
        (".cargo/bin", "rustup", false),
        (".rustup/", "rustup", false),
        (".volta/", "volta", false),
    ];
    for (needle, manager, shim) in checks {
        if path.contains(needle) {
            return (manager.to_string(), *shim);
        }
    }
    if !home.is_empty() && path.starts_with(&format!("{home}/.local/bin")) {
        return ("user".into(), false);
    }
    if path.starts_with("/usr/bin") || path.starts_with("/bin") {
        return ("system".into(), false);
    }
    (String::new(), false)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn bin_dir(name: &str) -> tempfile::TempDir {
        let d = tempfile::tempdir().unwrap();
        let p = d.path().join(name);
        std::fs::write(&p, "#!/bin/sh\n").unwrap();
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            std::fs::set_permissions(&p, std::fs::Permissions::from_mode(0o755)).unwrap();
        }
        d
    }

    #[test]
    fn a_tool_the_session_cannot_see_is_a_divergence_not_an_absence() {
        let d = bin_dir("weirdtool");
        let r = Resolver::with_paths("/nonexistent", Some(d.path().to_str().unwrap()), "/home/x");
        let res = r.resolve("weirdtool");
        assert!(!res.found_in(CTX_SESSION), "the session cannot run it");
        assert!(res.found_in(CTX_LOGIN), "the developer's terminal can");
        assert!(res.diverges(), "and that difference is the finding");
    }

    #[test]
    fn a_login_shell_that_cannot_be_consulted_is_not_a_divergence() {
        let d = bin_dir("t");
        let r = Resolver::with_paths(d.path().to_str().unwrap(), None, "/home/x");
        let res = r.resolve("t");
        assert!(res.found_in(CTX_SESSION));
        assert!(!res.diverges(), "unknown is not the same as different");
    }

    #[test]
    fn the_minimal_context_excludes_usr_local_bin() {
        assert!(!MINIMAL_PATH.contains("/usr/local/bin"));
    }

    #[test]
    fn session_resolution_spawns_nothing() {
        let d = bin_dir("t");
        let r = Resolver::with_paths(d.path().to_str().unwrap(), Some("/nowhere"), "/home/x");
        assert!(!r.resolve_session("t").is_empty());
        assert_eq!(r.spawns.get(), 0, "the fast path must not spawn");
    }

    #[test]
    fn the_bazelisk_alias_satisfies_the_bazel_requirement() {
        let dir = bin_dir("bazelisk");
        let resolver = Resolver::with_paths(dir.path().to_str().unwrap(), None, "/fixture");
        assert!(resolver.resolve_session("bazel").ends_with("/bazelisk"));
    }

    #[test]
    fn managers_are_named_so_the_fix_can_be_a_command() {
        assert_eq!(
            classify("/opt/homebrew/bin/go", "", "/home/x").0,
            "homebrew"
        );
        assert_eq!(
            classify("/home/x/.pyenv/shims/python", "", "/home/x"),
            ("pyenv".into(), true)
        );
        assert_eq!(
            classify("/home/x/.cargo/bin/cargo", "", "/home/x").0,
            "rustup"
        );
        assert_eq!(
            classify("/home/x/venv/bin/python", "/home/x/venv", "/home/x").0,
            "virtualenv"
        );
        assert_eq!(classify("/usr/bin/git", "", "/home/x").0, "system");
        assert_eq!(classify("", "", "").0, "");
    }
}
