//! One run of the agent layer over a verified generation: which agents it touches, what it
//! does to each inside the caller's transaction, and how an agent is let go.

use crate::adapter::{
    AgentState, ConfigAdapter, Desired, MachineAdapter, TeamAIAdapter, FIRST_PARTY, MACHINE_ID,
};
use crate::policy::Policies;
use crate::registry::{AgentRegistry, AgentSpec};
use crate::team_repo::{TeamRepo, TeamRepoMode};
use serde::Serialize;
use std::collections::BTreeMap;
use std::path::{Path, PathBuf};
use wf_core::{Error, Result};
use wf_state::{AgentRegistration, Db, Transaction};

/// Everything a run needs, read once.
#[derive(Debug, Clone)]
pub struct Context {
    pub bundle_dir: PathBuf,
    pub repo: TeamRepo,
    pub agents: AgentRegistry,
    pub policies: Policies,
    pub home: PathBuf,
    pub wf_binary: PathBuf,
    pub docs_dir: PathBuf,
    /// The root-relocating environment variables this run sees, captured once.
    pub env: BTreeMap<String, String>,
}

impl Context {
    /// A generation's bundle on this machine, located through the process environment.
    pub fn load(bundle_dir: &Path, paths: &wf_core::paths::Paths) -> Result<Self> {
        let mut ctx = Self::new(
            bundle_dir,
            &paths.home,
            paths.binary(),
            paths.state_dir.join("docs"),
            Some(&paths.config_dir.join("agents.yaml")),
            BTreeMap::new(),
        )?;
        let wanted = ctx
            .agents
            .agents()
            .iter()
            .filter_map(|a| a.root_env.clone())
            .chain(["PATH".to_string()]);
        ctx.env = wanted
            .filter_map(|key| {
                std::env::var(&key)
                    .ok()
                    .filter(|v| !v.is_empty())
                    .map(|v| (key, v))
            })
            .collect();
        Ok(ctx)
    }

    /// The same, with every input explicit — what tests and rehearsals use. `env` is the
    /// whole environment the run may see; a missing `PATH` finds no agent binaries.
    pub fn new(
        bundle_dir: &Path,
        home: &Path,
        wf_binary: PathBuf,
        docs_dir: PathBuf,
        overlay: Option<&Path>,
        env: BTreeMap<String, String>,
    ) -> Result<Self> {
        let repo = TeamRepo::open(bundle_dir)?;
        if !matches!(repo.mode(), TeamRepoMode::SelfRepo { .. }) {
            repo.root()?;
        }
        let base = if bundle_dir.join(crate::registry::AGENTS_FILE).is_file() {
            AgentRegistry::load(bundle_dir)?
        } else {
            AgentRegistry::builtin()
        };
        let agents = match overlay.map(std::fs::read_to_string) {
            Some(Ok(text)) => base.with_overlay(&text)?,
            Some(Err(e)) if e.kind() != std::io::ErrorKind::NotFound => return Err(e.into()),
            _ => base,
        };
        refuse_violations("AGENTS-INVALID", "agents.yaml", agents.validate())?;
        let policies = Policies::load(bundle_dir)?;
        refuse_violations("POLICIES-INVALID", "policies.yaml", policies.validate())?;
        refuse_violations(
            "TEAM-CONFIG-INVALID",
            "team-config.yaml",
            repo.config().validate(),
        )?;
        Ok(Self {
            bundle_dir: bundle_dir.to_path_buf(),
            repo,
            agents,
            policies,
            home: home.to_path_buf(),
            wf_binary,
            docs_dir,
            env,
        })
    }

    pub fn adapter(&self, spec: &AgentSpec) -> ConfigAdapter {
        let location = spec.locate(&self.home, &|key| self.env.get(key).cloned());
        ConfigAdapter::new(
            spec.clone(),
            location,
            self.wf_binary.clone(),
            self.policies.clone(),
        )
        .with_search_path(Some(self.env.get("PATH").cloned().unwrap_or_default()))
    }

    pub fn machine(&self) -> MachineAdapter {
        MachineAdapter::new(
            self.docs_dir.clone(),
            self.wf_binary.clone(),
            self.policies.clone(),
        )
    }
}

fn refuse_violations(
    kind: &str,
    file: &str,
    violations: Vec<crate::registry::Violation>,
) -> Result<()> {
    if violations.is_empty() {
        return Ok(());
    }
    let lines: Vec<String> = violations.iter().map(ToString::to_string).collect();
    Err(
        Error::usage(kind, format!("{file}: {}", lines.join("; "))).with_zh(format!(
            "{file} 有 {} 处不合规，wf 没有应用它。运行 `wf guard` 可以看到每一处。",
            lines.len()
        )),
    )
}

/// What one run did to one agent.
#[derive(Debug, Clone, Serialize)]
pub struct AgentOutcome {
    pub agent: String,
    pub installed: bool,
    pub state: AgentState,
    pub applied: Vec<String>,
    /// Native plugin objects from wf 1.x that this run retired.
    #[serde(skip_serializing_if = "Vec::is_empty")]
    pub retired: Vec<String>,
}

#[derive(Debug, Clone, Default, Serialize)]
pub struct RunOutcome {
    pub agents: Vec<AgentOutcome>,
    pub applied: Vec<String>,
    pub warnings: Vec<String>,
}

/// The agents a run touches. An explicit selection (`all`, or ids and aliases) is used as
/// given. Otherwise: an agent with a registration is managed while it is enabled, and one
/// without is managed if it is first-party — Claude Code and Codex, which 1.x always managed,
/// stay managed wherever they appear until a person unregisters them.
pub fn select_agents(
    ctx: &Context,
    db: &Db,
    selection: Option<&str>,
) -> Result<Vec<ConfigAdapter>> {
    let specs: Vec<&AgentSpec> = match selection {
        Some(spec) => ctx.agents.select(spec)?,
        None => {
            let registrations = db.agent_registrations()?;
            ctx.agents
                .agents()
                .iter()
                .filter(
                    |spec| match registrations.iter().find(|r| r.agent_id == spec.id) {
                        Some(r) => r.enabled,
                        None => FIRST_PARTY.contains(&spec.id.as_str()),
                    },
                )
                .collect()
        }
    };
    Ok(specs.into_iter().map(|s| ctx.adapter(s)).collect())
}

/// Record every selected agent that is on this machine as registered. A registration a
/// person disabled stays disabled.
pub fn register_detected(
    ctx: &Context,
    db: &Db,
    adapters: &[ConfigAdapter],
) -> Result<Vec<String>> {
    let _ = ctx;
    let existing = db.agent_registrations()?;
    let now = wf_core::time_fmt::now_utc_millis();
    let mut detected = Vec::new();
    for adapter in adapters {
        let Some(install) = adapter.detect()? else {
            continue;
        };
        let enabled = existing
            .iter()
            .find(|r| r.agent_id == adapter.id())
            .is_none_or(|r| r.enabled);
        db.register_agent(&AgentRegistration {
            agent_id: adapter.id().to_string(),
            display_name: adapter.display_name().to_string(),
            config_root: install.config_root.to_string_lossy().into_owned(),
            binary_path: install.binary.to_string_lossy().into_owned(),
            version: install.version,
            last_detected: Some(now.clone()),
            enabled,
            metadata: serde_json::to_value(adapter.spec())?,
        })?;
        detected.push(adapter.id().to_string());
    }
    Ok(detected)
}

/// Inspect, apply, and — outside a dry run, when there was anything to apply — verify one
/// target inside `tx`. Nothing written means nothing new to read back.
pub(crate) fn converge(
    adapter: &dyn TeamAIAdapter,
    desired: &Desired,
    tx: &mut Transaction<'_>,
) -> Result<(AgentState, Vec<String>)> {
    let owned = tx.managed_resources(adapter.id())?;
    // Read once and used by both passes: a decision cannot change midway through a converge,
    // and reading it twice would let it look as though it had.
    let skipped = tx.db().skipped_mcps()?;
    let planned = adapter.inspect(desired, &owned, &skipped)?;
    let applied = adapter.apply(&planned.changes, tx)?;
    if tx.is_dry_run() || planned.changes.is_empty() {
        return Ok((planned, applied));
    }
    let verified = adapter.verify(desired, &tx.managed_resources(adapter.id())?, &skipped)?;
    Ok((verified, applied))
}

/// Apply the generation to `adapters` and the machine inside `tx`, verifying each agent
/// unless this is a dry run.
pub fn apply(
    ctx: &Context,
    adapters: &[ConfigAdapter],
    tx: &mut Transaction<'_>,
) -> Result<RunOutcome> {
    let desired = Desired::scan(&ctx.repo);
    let native = tx.db().native_receipts()?;
    let mut out = RunOutcome::default();
    for adapter in adapters {
        let Some(install) = adapter.detect()? else {
            out.agents.push(absent(adapter));
            continue;
        };
        let mut retired = Vec::new();
        if FIRST_PARTY.contains(&adapter.id()) {
            match crate::legacy::retire(&native, adapter.id(), &install.config_root, tx) {
                Ok(done) => {
                    retired = done.removed;
                    out.warnings.extend(done.kept.into_iter().map(|why| {
                        format!(
                            "{}: {why}; remove it with the agent's own plugin manager, or its \
                             skills stay beside the ones wf now deploys",
                            adapter.display_name()
                        )
                    }));
                }
                Err(e) => out.warnings.push(format!(
                    "{}: the plugin magi@capsohq that wf 1.x installed could not be retired ({}); \
                     skills now come from wf directly, so remove the plugin with the agent's own plugin manager",
                    adapter.display_name(),
                    e.message
                )),
            }
        }
        let (state, applied) = converge(adapter, &desired, tx)?;
        out.agents.push(AgentOutcome {
            agent: adapter.id().to_string(),
            installed: true,
            state,
            applied,
            retired,
        });
    }
    let machine = ctx.machine();
    let (state, applied) = converge(&machine, &desired, tx)?;
    out.agents.push(AgentOutcome {
        agent: MACHINE_ID.to_string(),
        installed: true,
        state,
        applied,
        retired: vec![],
    });
    let mut applied: Vec<String> = out.agents.iter().flat_map(|a| a.applied.clone()).collect();
    applied.sort();
    applied.dedup();
    out.applied = applied;
    Ok(out)
}

fn absent(adapter: &dyn TeamAIAdapter) -> AgentOutcome {
    AgentOutcome {
        agent: adapter.id().to_string(),
        installed: false,
        state: AgentState {
            agent: adapter.id().to_string(),
            display_name: adapter.display_name().to_string(),
            ..Default::default()
        },
        applied: vec![],
        retired: vec![],
    }
}

/// Converge only `kinds` in one agent — session start's repair of the prompt block, which
/// is cheap enough to run in every terminal because it scans nothing else.
pub fn repair(
    adapter: &ConfigAdapter,
    ctx: &Context,
    kinds: &[crate::resources::ResourceKind],
    tx: &mut Transaction<'_>,
) -> Result<Vec<String>> {
    if adapter.detect()?.is_none() {
        return Ok(vec![]);
    }
    converge(adapter, &Desired::scan_kinds(&ctx.repo, kinds), tx).map(|(_, applied)| applied)
}

/// Read each agent without changing anything.
pub fn inspect(ctx: &Context, adapters: &[ConfigAdapter], db: &Db) -> Result<Vec<AgentOutcome>> {
    let desired = Desired::scan(&ctx.repo);
    let machine = ctx.machine();
    let targets = adapters
        .iter()
        .map(|a| a as &dyn TeamAIAdapter)
        .chain(std::iter::once(&machine as &dyn TeamAIAdapter));
    let skipped = db.skipped_mcps()?;
    let mut out = Vec::new();
    for adapter in targets {
        if adapter.detect()?.is_none() {
            out.push(absent(adapter));
            continue;
        }
        let state = adapter.inspect(
            &desired,
            &db.managed_resources(Some(adapter.id()))?,
            &skipped,
        )?;
        out.push(AgentOutcome {
            agent: adapter.id().to_string(),
            installed: true,
            state,
            applied: vec![],
            retired: vec![],
        });
    }
    Ok(out)
}

/// Remove everything wf owns in one agent, and stop managing it. What a person changed is
/// left where it is.
pub fn retire_agent(adapter: &dyn TeamAIAdapter, tx: &mut Transaction<'_>) -> Result<Vec<String>> {
    let nothing = Desired {
        items: crate::resources::ResourceKind::ALL
            .into_iter()
            .map(|kind| (kind, Ok(vec![])))
            .collect(),
    };
    let owned = tx.managed_resources(adapter.id())?;
    // No skips: retiring wants nothing, so every owned row is an orphan and comes out. A
    // decision about an agent wf no longer manages is not a decision, and `unregister`
    // drops the rows that held it.
    let state = adapter.inspect(&nothing, &owned, &[])?;
    adapter.apply(&state.changes, tx)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::adapter::ObjectStatus;
    use crate::resources::ResourceKind;
    use crate::testing::{Machine, TeamFixture};

    fn context(team: &TeamFixture, m: &Machine) -> Context {
        Context::new(
            team.root(),
            &m.home(),
            m.wf_binary(),
            m.dir.path().join("state/docs"),
            None,
            BTreeMap::new(),
        )
        .unwrap()
    }

    #[test]
    fn a_run_deploys_to_every_selected_agent_on_the_machine_and_skips_the_absent() {
        let team = TeamFixture::new();
        let m = Machine::new();
        std::fs::create_dir_all(m.at(".claude")).unwrap();
        std::fs::create_dir_all(m.at(".cursor")).unwrap();
        let ctx = context(&team, &m);
        let adapters = select_agents(&ctx, &m.db, Some("claude,codex,cursor")).unwrap();
        let mut tx = m.tx(false);
        let outcome = apply(&ctx, &adapters, &mut tx).unwrap();
        tx.commit().unwrap();

        let by_id: BTreeMap<&str, &AgentOutcome> = outcome
            .agents
            .iter()
            .map(|a| (a.agent.as_str(), a))
            .collect();
        assert!(by_id["claude-code"].installed);
        assert!(by_id["cursor"].installed);
        assert!(
            !by_id["codex"].installed,
            "no ~/.codex and no codex binary on this test's PATH"
        );
        assert!(by_id["claude-code"].state.is_current());
        assert!(m.at(".claude/skills/lfg/SKILL.md").is_file());
        assert!(m.at(".cursor/skills/lfg/SKILL.md").is_file());
        assert!(!m.at(".codex").exists(), "an absent agent is not created");
        assert!(by_id[MACHINE_ID].installed);
        assert!(m.dir.path().join("state/docs/runbooks/deploy.md").is_file());
        assert!(outcome.applied.contains(&"capso.skill.lfg".to_string()));

        let again = inspect(&ctx, &adapters, &m.db).unwrap();
        assert!(
            again.iter().all(|a| a.state.changes.is_empty()),
            "{again:#?}"
        );
    }

    #[test]
    fn selection_is_explicit_then_registered_then_first_party() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let ctx = context(&team, &m);
        let ids = |adapters: Vec<ConfigAdapter>| {
            adapters
                .iter()
                .map(|a| a.id().to_string())
                .collect::<Vec<_>>()
        };
        assert_eq!(
            ids(select_agents(&ctx, &m.db, None).unwrap()),
            ["claude-code", "codex"]
        );
        std::fs::create_dir_all(m.at(".cursor")).unwrap();
        std::fs::create_dir_all(m.at(".codex")).unwrap();
        let detected = register_detected(
            &ctx,
            &m.db,
            &select_agents(&ctx, &m.db, Some("all")).unwrap(),
        )
        .unwrap();
        assert_eq!(detected, ["codex", "cursor"]);
        assert_eq!(
            ids(select_agents(&ctx, &m.db, None).unwrap()),
            ["claude-code", "codex", "cursor"],
            "the first-party agents stay managed without a registration, as 1.x managed them — \
             so a Claude Code installed later is picked up"
        );
        m.db.set_agent_enabled("codex", false).unwrap();
        register_detected(
            &ctx,
            &m.db,
            &select_agents(&ctx, &m.db, Some("all")).unwrap(),
        )
        .unwrap();
        assert_eq!(
            ids(select_agents(&ctx, &m.db, None).unwrap()),
            ["claude-code", "cursor"],
            "a disabled registration stays disabled, first-party or not"
        );
        assert_eq!(
            ids(select_agents(&ctx, &m.db, Some("kiro")).unwrap()),
            ["kiro"]
        );
        assert_eq!(
            select_agents(&ctx, &m.db, Some("windsurf"))
                .unwrap_err()
                .code,
            wf_core::ExitCode::Usage
        );
    }

    #[test]
    fn a_registration_keeps_the_spec_it_was_made_from() {
        let team = TeamFixture::new();
        let m = Machine::new();
        std::fs::create_dir_all(m.at(".kiro")).unwrap();
        let ctx = context(&team, &m);
        register_detected(
            &ctx,
            &m.db,
            &select_agents(&ctx, &m.db, Some("kiro")).unwrap(),
        )
        .unwrap();
        let reg = &m.db.agent_registrations().unwrap()[0];
        assert_eq!(reg.agent_id, "kiro");
        assert_eq!(reg.config_root, m.at(".kiro").to_string_lossy());
        assert_eq!(reg.metadata["paths"]["rules"], "steering");
        assert!(reg.last_detected.is_some());
    }

    #[test]
    fn retiring_an_agent_removes_what_wf_owns_there_and_keeps_what_a_person_changed() {
        let team = TeamFixture::new();
        let m = Machine::new();
        m.write(".claude/CLAUDE.md", "mine\n");
        let ctx = context(&team, &m);
        let adapters = select_agents(&ctx, &m.db, Some("claude")).unwrap();
        let mut tx = m.tx(false);
        apply(&ctx, &adapters, &mut tx).unwrap();
        tx.commit().unwrap();
        m.write(".claude/rules/style.md", "my edit\n");

        let mut tx = m.tx(false);
        let removed = retire_agent(&adapters[0], &mut tx).unwrap();
        tx.commit().unwrap();
        assert!(
            removed.contains(&"team.skill.lfg".to_string()),
            "{removed:?}"
        );
        assert!(!m.at(".claude/skills/lfg").exists());
        assert_eq!(m.read(".claude/CLAUDE.md"), "mine\n");
        assert_eq!(m.read(".claude/rules/style.md"), "my edit\n");
        assert!(!m.read(".claude/settings.json").contains("capso-wf"));
        assert!(m
            .db
            .managed_resources(Some("claude-code"))
            .unwrap()
            .is_empty());
    }

    /// A per-machine overlay, or a later bundle, can drop a path an agent used to declare.
    /// What wf already wrote there is still wf's to take back: reading the kinds to walk from
    /// `supported_resources()` alone left the files and the rows behind with nothing left that
    /// could reach them, while the retirement reported success.
    #[test]
    fn an_agent_that_stopped_taking_a_kind_still_gives_back_what_it_holds() {
        let team = TeamFixture::new();
        let m = Machine::new();
        std::fs::create_dir_all(m.at(".cursor")).unwrap();
        let ctx = context(&team, &m);
        let adapters = select_agents(&ctx, &m.db, Some("cursor")).unwrap();
        let mut tx = m.tx(false);
        apply(&ctx, &adapters, &mut tx).unwrap();
        tx.commit().unwrap();
        assert!(m.at(".cursor/rules/security/secrets.mdc").is_file());

        let mut spec = adapters[0].spec().clone();
        spec.paths.rules = None;
        let narrowed = ConfigAdapter::new(
            spec,
            adapters[0].location().clone(),
            m.wf_binary(),
            Policies::default(),
        );
        let mut tx = m.tx(false);
        retire_agent(&narrowed, &mut tx).unwrap();
        tx.commit().unwrap();
        assert!(!m.at(".cursor/rules/security/secrets.mdc").exists());
        assert!(m.db.managed_resources(Some("cursor")).unwrap().is_empty());
    }

    /// Session start repairs the prompt block and nothing else: what it does not scan, it must
    /// neither write nor mistake for something the team repository dropped.
    #[test]
    fn repairing_one_kind_leaves_every_other_kind_exactly_as_it_is() {
        let team = TeamFixture::new();
        let m = Machine::new();
        std::fs::create_dir_all(m.at(".claude")).unwrap();
        let ctx = context(&team, &m);
        let adapters = select_agents(&ctx, &m.db, Some("claude")).unwrap();
        let mut tx = m.tx(false);
        apply(&ctx, &adapters, &mut tx).unwrap();
        tx.commit().unwrap();
        let owned = m.db.managed_resources(Some("claude-code")).unwrap().len();
        m.write(".claude/CLAUDE.md", "mine\n");
        std::fs::remove_dir_all(m.at(".claude/skills/lfg")).unwrap();

        let mut tx = m.tx(false);
        let repaired = repair(&adapters[0], &ctx, &[ResourceKind::Prompt], &mut tx).unwrap();
        tx.commit().unwrap();
        assert_eq!(repaired, ["capso.prompt.global"]);
        assert!(m.read(".claude/CLAUDE.md").starts_with("mine\n"));
        assert!(m.read(".claude/CLAUDE.md").contains("Use /lfg."));
        assert!(
            !m.at(".claude/skills/lfg").exists(),
            "skills are not this repair's business"
        );
        assert_eq!(
            m.db.managed_resources(Some("claude-code")).unwrap().len(),
            owned
        );

        let mut tx = m.tx(false);
        assert!(repair(&adapters[0], &ctx, &[ResourceKind::Prompt], &mut tx)
            .unwrap()
            .is_empty());
        tx.commit().unwrap();
    }

    #[test]
    fn a_dry_run_plans_every_agent_and_writes_nothing() {
        let team = TeamFixture::new();
        let m = Machine::new();
        std::fs::create_dir_all(m.at(".claude")).unwrap();
        let ctx = context(&team, &m);
        let adapters = select_agents(&ctx, &m.db, Some("claude")).unwrap();
        let mut tx = m.tx(true);
        let outcome = apply(&ctx, &adapters, &mut tx).unwrap();
        assert!(!tx.plan.is_empty());
        tx.commit().unwrap();
        assert!(outcome.agents[0]
            .state
            .objects
            .iter()
            .any(|o| o.status == ObjectStatus::Missing));
        assert_eq!(std::fs::read_dir(m.at(".claude")).unwrap().count(), 0);
        assert!(!m.dir.path().join("state/docs").exists());
    }

    #[test]
    fn a_legacy_receipt_whose_manager_cannot_run_is_a_warning_not_a_failed_run() {
        let team = TeamFixture::new();
        let m = Machine::new();
        std::fs::create_dir_all(m.at(".claude")).unwrap();
        m.db.record_native(&wf_state::NativeReceipt {
            agent: "claude-code".into(),
            kind: wf_state::NativeObject::Plugin,
            identity: "magi@capsohq".into(),
            binary: "/nonexistent/claude".into(),
            config_root: m.at(".claude").to_string_lossy().into(),
            source: "/nonexistent/generation".into(),
            version: "1.7.0".into(),
        })
        .unwrap();
        let ctx = context(&team, &m);
        let adapters = select_agents(&ctx, &m.db, Some("claude")).unwrap();
        let mut tx = m.tx(false);
        let outcome = apply(&ctx, &adapters, &mut tx).unwrap();
        tx.commit().unwrap();
        assert!(
            outcome.warnings.iter().any(|w| w.contains("magi")),
            "{:?}",
            outcome.warnings
        );
        assert!(m.at(".claude/skills/lfg/SKILL.md").is_file());
    }

    #[test]
    fn a_generation_without_agents_yaml_uses_the_registry_built_into_wf() {
        let team = TeamFixture::new();
        team.remove("workflow/teamai/agents.yaml");
        let m = Machine::new();
        let ctx = context(&team, &m);
        assert_eq!(ctx.agents, AgentRegistry::builtin());
    }

    #[test]
    fn an_overlay_adds_an_agent_and_a_bad_registry_or_policy_is_refused() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let overlay = m.dir.path().join("agents.yaml");
        std::fs::write(&overlay, "schema_version: 1\nagents:\n  - id: windsurf\n    display_name: Windsurf\n    root: .codeium/windsurf\n    paths:\n      skills: skills\n").unwrap();
        let ctx = Context::new(
            team.root(),
            &m.home(),
            m.wf_binary(),
            m.dir.path().join("docs"),
            Some(&overlay),
            BTreeMap::new(),
        )
        .unwrap();
        assert!(ctx.agents.find("windsurf").is_some());
        std::fs::write(&overlay, "schema_version: 1\nagents:\n  - id: Bad Id\n    display_name: x\n    root: .x\n    paths:\n      skills: skills\n").unwrap();
        let err = Context::new(
            team.root(),
            &m.home(),
            m.wf_binary(),
            m.dir.path().join("docs"),
            Some(&overlay),
            BTreeMap::new(),
        )
        .unwrap_err();
        assert!(err.message.contains("AGT002"), "{}", err.message);
        team.write(
            "workflow/teamai/policies.yaml",
            "schema_version: 1\nusage:\n  storage: remote\n",
        );
        let err = context_err(&team, &m);
        assert!(err.message.contains("POL001"), "{}", err.message);
    }

    fn context_err(team: &TeamFixture, m: &Machine) -> Error {
        Context::new(
            team.root(),
            &m.home(),
            m.wf_binary(),
            m.dir.path().join("docs"),
            None,
            BTreeMap::new(),
        )
        .unwrap_err()
    }

    #[test]
    fn the_environment_a_context_captured_relocates_agent_roots() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let env = BTreeMap::from([(
            "CODEX_HOME".to_string(),
            m.dir
                .path()
                .join("alt-codex")
                .to_string_lossy()
                .into_owned(),
        )]);
        let ctx = Context::new(
            team.root(),
            &m.home(),
            m.wf_binary(),
            m.dir.path().join("docs"),
            None,
            env,
        )
        .unwrap();
        let codex = ctx.adapter(ctx.agents.find("codex").unwrap());
        assert_eq!(codex.location().root, m.dir.path().join("alt-codex"));
    }
}
