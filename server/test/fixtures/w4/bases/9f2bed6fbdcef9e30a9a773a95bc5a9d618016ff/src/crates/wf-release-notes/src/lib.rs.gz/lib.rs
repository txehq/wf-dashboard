//! The derived half of `/release-notes`.
//!
//! This crate answers only the questions a command can answer: which commits are in the
//! range, which pull requests they came from, which tickets they name, whether a migration is
//! included, which surfaces moved. It deliberately produces **no prose**.
//!
//! That split is the point of the node. A list of merged pull-request titles is a changelog —
//! complete, free to generate, and unread. Release notes are the other trade: lossy on
//! purpose, and worth reading. The lossy half is judgment and belongs to whoever is shipping;
//! having a model run `git log` and transcribe the output is where fabrication enters, which
//! is the same reason [[Handover]] derives rather than narrates.

use serde::Serialize;
use std::collections::BTreeSet;
use std::path::Path;
use std::time::Duration;
use wf_core::{Error, Result};

const PROBE: Duration = Duration::from_secs(20);

/// One commit in the range, and what can be read off it.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct Change {
    pub sha: String,
    pub subject: String,
    pub author: String,
    /// The pull request this arrived through, when the subject records one.
    pub pr: Option<u32>,
    /// Ticket ids named anywhere in the commit message.
    pub tickets: Vec<String>,
}

/// Everything the range yields. No judgment, by construction.
#[derive(Debug, Clone, Serialize)]
pub struct Facts {
    pub from: String,
    pub to: String,
    pub changes: Vec<Change>,
    /// Every ticket named across the range, deduplicated and sorted.
    pub tickets: Vec<String>,
    /// Top-level directories touched — a coarse map of what moved.
    pub surfaces: Vec<String>,
    /// Paths in the range that look like schema migrations.
    pub migrations: Vec<String>,
    /// Whether pull-request bodies were read.
    ///
    /// Load-bearing rather than diagnostic. In this organization the closing trailer lives in
    /// the **PR body**, not the commit — measured on this very repository, where PR #20's
    /// commit message names no ticket while its body says `Fixes TXE-1783`. So a commit-only
    /// derivation returns a ticket list that is systematically incomplete, and the Linear
    /// step at the end of this chain is only as complete as that list. When this is false the
    /// reader must be told the list is partial rather than left to assume it is not.
    pub pr_bodies_read: bool,
}

impl Facts {
    pub fn pr_numbers(&self) -> Vec<u32> {
        let mut v: Vec<u32> = self.changes.iter().filter_map(|c| c.pr).collect();
        v.sort_unstable();
        v.dedup();
        v
    }
}

/// Pull a pull-request number out of a commit subject.
///
/// Handles both shapes this organization produces: a squash merge, whose subject ends
/// `… (#20)`, and a true merge commit, `Merge pull request #20 from …`. A repository that
/// squash-merges has no merge commits at all, so reading only the latter would silently
/// return nothing for every repository here.
pub fn pr_from_subject(subject: &str) -> Option<u32> {
    if let Some(rest) = subject.strip_prefix("Merge pull request #") {
        return rest.split_whitespace().next().and_then(|n| n.parse().ok());
    }
    // The trailing `(#N)` a squash merge appends. Taken from the end: a subject may quote an
    // issue number in its own text, and the merge's own number is the last one.
    let close = subject.rfind(')')?;
    let open = subject[..close].rfind("(#")?;
    subject[open + 2..close].parse().ok()
}

/// Ticket ids named in a commit message.
///
/// Deliberately finds the bare id and nothing else — no keyword handling. In this
/// organization a *verb* in front of an id is what moves a ticket, so anything that
/// reconstructs ids for display must not also reconstruct the verb.
pub fn tickets_in(text: &str) -> Vec<String> {
    let bytes = text.as_bytes();
    let mut out = BTreeSet::new();
    let mut i = 0;
    while i < bytes.len() {
        if !bytes[i].is_ascii_alphabetic() {
            i += 1;
            continue;
        }
        let start = i;
        while i < bytes.len() && bytes[i].is_ascii_alphabetic() {
            i += 1;
        }
        // A project key is 2–5 letters, then a hyphen, then digits.
        let key_len = i - start;
        if !(2..=5).contains(&key_len) || i >= bytes.len() || bytes[i] != b'-' {
            continue;
        }
        let digits_start = i + 1;
        let mut j = digits_start;
        while j < bytes.len() && bytes[j].is_ascii_digit() {
            j += 1;
        }
        if j == digits_start {
            continue;
        }
        // Not preceded by a word character, or `TESTXE-1` would yield `TXE-1`.
        if start > 0 && (bytes[start - 1].is_ascii_alphanumeric() || bytes[start - 1] == b'-') {
            i = j;
            continue;
        }
        out.insert(format!(
            "{}-{}",
            text[start..start + key_len].to_uppercase(),
            &text[digits_start..j]
        ));
        i = j;
    }
    out.into_iter().collect()
}

/// Does this path look like a schema migration?
///
/// A migration in a release is a fact about that release's reversibility, so it is surfaced
/// on its own rather than folded into a file list where it can be skimmed past.
pub fn is_migration(path: &str) -> bool {
    let lower = path.to_ascii_lowercase();
    lower
        .split('/')
        .any(|seg| seg == "migrations" || seg == "migration")
        || lower.ends_with(".sql") && lower.contains("migrat")
}

/// Parse `git log` output produced with the exact format [`gather`] requests.
///
/// Split out so the parsing is testable without a repository: NUL-delimited fields and a
/// record separator, because a commit subject may contain anything at all — including the
/// delimiter somebody would otherwise have chosen.
pub fn parse_log(raw: &str) -> Vec<Change> {
    let mut out = Vec::new();
    for record in raw.split('\x1e') {
        let record = record.trim_matches('\n');
        if record.is_empty() {
            continue;
        }
        let mut f = record.split('\x00');
        let (Some(sha), Some(subject), Some(author)) = (f.next(), f.next(), f.next()) else {
            continue;
        };
        let body = f.next().unwrap_or("");
        out.push(Change {
            sha: sha.trim().to_string(),
            subject: subject.to_string(),
            author: author.to_string(),
            pr: pr_from_subject(subject),
            tickets: tickets_in(&format!("{subject}\n{body}")),
        });
    }
    out
}

/// Read the range out of a repository.
pub fn gather(root: &Path, from: &str, to: &str) -> Result<Facts> {
    let raw = git(
        root,
        &[
            "log",
            "--no-merges",
            "--format=%H%x00%s%x00%an%x00%b%x1e",
            &format!("{from}..{to}"),
        ],
    );
    // `--no-merges` is right for a squash-merging repository and would hide everything in one
    // that keeps merge commits, so fall back rather than reporting an empty release.
    let mut changes = parse_log(&raw);
    if changes.is_empty() {
        changes = parse_log(&git(
            root,
            &[
                "log",
                "--format=%H%x00%s%x00%an%x00%b%x1e",
                &format!("{from}..{to}"),
            ],
        ));
    }

    if changes.is_empty() {
        return Err(Error::usage(
            "RELEASE-NOTES-EMPTY-RANGE",
            format!("no commits in {from}..{to} — notes for an empty release train the reader to skip the next set"),
        )
        .with_zh("该区间没有提交，请检查两个 ref 是否正确。"));
    }

    let files = git(root, &["diff", "--name-only", &format!("{from}..{to}")]);
    let mut surfaces = BTreeSet::new();
    let mut migrations = BTreeSet::new();
    for path in files.lines().filter(|l| !l.trim().is_empty()) {
        surfaces.extend(surface_of(path));
        if is_migration(path) {
            migrations.insert(path.to_string());
        }
    }

    // The trailer lives in the PR body in this organization, so a commit-only read misses
    // tickets. Best-effort: `gh` may be absent or unauthenticated, and a release-notes run
    // must still produce its other facts when it is.
    let pr_bodies = pr_bodies(root);
    if let Some(bodies) = &pr_bodies {
        for c in &mut changes {
            let Some(body) = c.pr.and_then(|n| bodies.get(&n)) else {
                continue;
            };
            let mut merged: BTreeSet<String> = c.tickets.iter().cloned().collect();
            merged.extend(tickets_in(body));
            c.tickets = merged.into_iter().collect();
        }
    }

    let mut tickets: BTreeSet<String> = BTreeSet::new();
    for c in &changes {
        tickets.extend(c.tickets.iter().cloned());
    }

    Ok(Facts {
        from: from.to_string(),
        to: to.to_string(),
        changes,
        tickets: tickets.into_iter().collect(),
        surfaces: surfaces.into_iter().collect(),
        migrations: migrations.into_iter().collect(),
        pr_bodies_read: pr_bodies.is_some(),
    })
}

/// The top-level **directory** a changed path sits in, if any.
///
/// A path with no separator is a file at the repository root — `Cargo.lock`, `.gitignore`.
/// Those are not surfaces, and reporting them as such makes the surface list read as though
/// a release touched eleven areas when it touched five.
fn surface_of(path: &str) -> Option<String> {
    let (top, _) = path.split_once('/')?;
    (!top.is_empty()).then(|| top.to_string())
}

/// Bodies of the merged pull requests, keyed by number. `None` when `gh` cannot answer.
fn pr_bodies(root: &Path) -> Option<std::collections::BTreeMap<u32, String>> {
    let raw = match wf_core::proc::run_in(
        "gh",
        &[
            "pr",
            "list",
            "--state",
            "merged",
            "--limit",
            "200",
            "--json",
            "number,body",
        ],
        &[],
        Some(root),
        PROBE,
    ) {
        Ok(o) if o.ok() => o.stdout,
        _ => return None,
    };
    let parsed: Vec<PrRow> = serde_json::from_str(&raw).ok()?;
    Some(parsed.into_iter().map(|r| (r.number, r.body)).collect())
}

#[derive(serde::Deserialize)]
struct PrRow {
    number: u32,
    #[serde(default)]
    body: String,
}

/// The previous release tag, for the default range.
pub fn previous_tag(root: &Path) -> Option<String> {
    let t = git(root, &["describe", "--tags", "--abbrev=0"]);
    (!t.is_empty()).then_some(t)
}

fn git(dir: &Path, args: &[&str]) -> String {
    match wf_core::proc::run_in("git", args, &[], Some(dir), PROBE) {
        Ok(o) if o.ok() => o.stdout.trim_end().to_string(),
        _ => String::new(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_squash_merge_subject_yields_its_pr() {
        assert_eq!(
            pr_from_subject("feat(review-pr): port the rpr review loop (#20)"),
            Some(20)
        );
    }

    #[test]
    fn a_real_merge_commit_yields_its_pr_too() {
        // A repository that squash-merges has no merge commits, and one that does not has
        // nothing else — reading only one shape returns nothing for half the repositories.
        assert_eq!(
            pr_from_subject("Merge pull request #1954 from capsohq/topic"),
            Some(1954)
        );
    }

    #[test]
    fn the_merges_own_number_wins_over_one_quoted_in_the_text() {
        assert_eq!(
            pr_from_subject("fix: revert the change from (#12) that broke it (#31)"),
            Some(31)
        );
    }

    #[test]
    fn a_subject_with_no_pr_yields_none() {
        for s in ["docs: fix a typo", "chore: bump deps (not a pr)", "wip", ""] {
            assert_eq!(pr_from_subject(s), None, "read a PR out of {s:?}");
        }
    }

    #[test]
    fn ticket_ids_are_found_bare_and_uppercased() {
        assert_eq!(
            tickets_in("port the loop\n\nFixes txe-1783 and relates to TXE-1775"),
            vec!["TXE-1775".to_string(), "TXE-1783".to_string()]
        );
    }

    #[test]
    fn a_ticket_id_inside_a_longer_word_is_not_a_ticket() {
        // `TESTXE-1` must not yield `TXE-1`: a wrong id in release notes points a reader at
        // somebody else's work.
        assert!(tickets_in("TESTXE-1 and FOO-BAR").is_empty());
        assert!(
            tickets_in("a-1").is_empty(),
            "one letter is not a project key"
        );
        assert!(tickets_in("TXE-").is_empty(), "no digits is not a ticket");
    }

    #[test]
    fn migrations_are_recognised_wherever_they_sit() {
        for p in [
            "migrations/0001_init.sql",
            "services/api/migrations/0007_add_col.sql",
            "db/migration/v2.sql",
        ] {
            assert!(is_migration(p), "missed {p}");
        }
        for p in [
            "crates/wf-core/src/lib.rs",
            "docs/index.yaml",
            "skills/x.md",
        ] {
            assert!(!is_migration(p), "false positive on {p}");
        }
    }

    #[test]
    fn the_log_parser_survives_a_subject_containing_anything() {
        // Fields are NUL-delimited and records are separated by 0x1e precisely because a
        // subject may contain newlines, pipes, tabs — whatever somebody typed.
        let raw = "abc123\x00feat: a | subject\twith\ttabs (#7)\x00Ann\x00body TXE-9\x1e\
                   def456\x00docs: plain\x00Bo\x00\x1e";
        let changes = parse_log(raw);
        assert_eq!(changes.len(), 2);
        assert_eq!(changes[0].pr, Some(7));
        assert_eq!(changes[0].tickets, vec!["TXE-9".to_string()]);
        assert_eq!(changes[0].author, "Ann");
        assert_eq!(changes[1].pr, None);
        assert!(changes[1].tickets.is_empty());
    }

    #[test]
    fn a_truncated_record_is_dropped_rather_than_half_read() {
        let changes = parse_log("abc\x00only-a-subject\x1e");
        assert!(
            changes.is_empty(),
            "a partial record must not become a change"
        );
    }

    #[test]
    fn a_root_level_file_is_not_a_surface() {
        // `Cargo.lock` and `.gitignore` are files at the root, not areas of the codebase.
        // Counting them made a release look like it touched eleven surfaces instead of five.
        assert_eq!(
            surface_of("crates/wf-core/src/lib.rs"),
            Some("crates".into())
        );
        assert_eq!(surface_of("docs/index.yaml"), Some("docs".into()));
        assert_eq!(surface_of("Cargo.lock"), None);
        assert_eq!(surface_of(".gitignore"), None);
    }

    #[test]
    fn pr_numbers_are_deduplicated_and_ordered() {
        let f = Facts {
            from: "a".into(),
            to: "b".into(),
            changes: parse_log(
                "1\x00x (#9)\x00A\x00\x1e2\x00y (#3)\x00B\x00\x1e3\x00z (#9)\x00C\x00\x1e",
            ),
            tickets: vec![],
            surfaces: vec![],
            migrations: vec![],
            pr_bodies_read: false,
        };
        assert_eq!(f.pr_numbers(), vec![3, 9]);
    }
}
