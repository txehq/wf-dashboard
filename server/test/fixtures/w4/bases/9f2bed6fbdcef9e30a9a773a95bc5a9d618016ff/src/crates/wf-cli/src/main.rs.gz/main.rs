//! `wf` — the one binary.
//!
//! Everything the organization ships to a coding agent is installed, checked, repaired and
//! rolled back from here, and the four tools that used to be separate Go commands are
//! subcommands of it. One binary means one version, and one version means a machine cannot
//! be half-upgraded.

mod cmd;

use wf_cli_flags as flags;

use clap::Parser;
use wf_core::ExitCode;

fn main() {
    let cli = flags::Cli::parse();
    let json = cli.json;
    match cmd::dispatch(cli) {
        Ok(code) => std::process::exit(code.as_i32()),
        Err(e) => {
            // The operator-facing sentence goes to stderr in the register a person can act
            // on; the engineering detail follows it, quietly, for a bug report.
            if json {
                let env = wf_core::envelope::Envelope::new("wf").error(
                    wf_core::envelope::Note::new(e.kind.clone(), e.message.clone())
                        .with_zh(e.zh.clone()),
                );
                println!("{}", env.render());
            } else if !e.zh.is_empty() {
                eprintln!("{}", e.zh);
                eprintln!(
                    "\n（技术细节：{} — {}）",
                    e.kind,
                    wf_core::redact::redact(&e.message)
                );
            } else {
                eprintln!("wf: {}", wf_core::redact::redact(&e.message));
            }
            std::process::exit(e.code.as_i32());
        }
    }
}

pub fn ok(code: ExitCode) -> wf_core::Result<ExitCode> {
    Ok(code)
}
