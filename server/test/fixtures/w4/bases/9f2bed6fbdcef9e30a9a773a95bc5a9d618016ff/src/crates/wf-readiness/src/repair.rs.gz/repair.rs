use crate::{Finding, Requirements, Severity, Tier};
use std::{collections::BTreeMap, path::Path, time::Duration};

/// Execute native argv, never a shell fragment from a manifest. Reversible service steps
/// are automatic; package installs require the caller's explicit --repair flag.
pub(crate) fn apply(
    root: &Path,
    req: &Requirements,
    findings: &[Finding],
    installs: bool,
) -> (u32, bool) {
    let mut changed = false;
    let mut spawns = 0;
    let mut commands: Vec<Vec<String>> = Vec::new();
    let failed = |code: &str| {
        findings
            .iter()
            .any(|f| f.code == code && f.severity == Severity::Fail)
    };
    let daemon_ready = if failed("DOCKER-DOWN") {
        let command: Vec<String> = if cfg!(target_os = "macos") {
            vec!["open".into(), "-a".into(), "Docker".into()]
        } else {
            vec![
                "sudo".into(),
                "-n".into(),
                "systemctl".into(),
                "start".into(),
                "docker".into(),
            ]
        };
        spawns += 1;
        let args = command[1..].iter().map(String::as_str).collect::<Vec<_>>();
        let started =
            wf_core::proc::run_in(&command[0], &args, &[], Some(root), Duration::from_secs(15))
                .is_ok_and(|output| output.ok());
        changed |= started;
        started
            && wait_until(Duration::from_secs(90), |remaining| {
                spawns += 1;
                wf_core::proc::run_in(
                    "docker",
                    &["info", "--format", "{{.ServerVersion}}"],
                    &[],
                    Some(root),
                    remaining.min(Duration::from_secs(3)),
                )
                .is_ok_and(|output| output.ok())
            })
    } else {
        true
    };
    let mut compose = BTreeMap::<String, Vec<String>>::new();
    for service in &req.services {
        if findings
            .iter()
            .any(|f| f.code == "SVC-DOWN" && f.subject == service.name)
        {
            compose
                .entry(service.from.clone())
                .or_default()
                .push(service.name.clone());
        }
    }
    for (file, mut services) in compose {
        if !daemon_ready {
            continue;
        }
        services.sort();
        services.dedup();
        let mut args = vec![
            "docker".into(),
            "compose".into(),
            "-f".into(),
            file,
            "up".into(),
            "-d".into(),
            // Returns once each container runs and passes its healthcheck, so the re-check
            // sees the service it started instead of one still booting.
            "--wait".into(),
        ];
        args.extend(services);
        commands.push(args);
    }
    if installs {
        for finding in findings
            .iter()
            .filter(|f| f.severity == Severity::Fail && f.tier == Some(Tier::Install))
        {
            if finding.fix.chars().any(|c| "|;&$`<>\n\r'\"".contains(c)) {
                continue;
            }
            let args: Vec<String> = finding.fix.split_whitespace().map(str::to_string).collect();
            if args.first().is_some_and(|p| {
                matches!(
                    p.as_str(),
                    "brew"
                        | "apt-get"
                        | "apt"
                        | "dnf"
                        | "yum"
                        | "pacman"
                        | "rustup"
                        | "cargo"
                        | "xcode-select"
                )
            }) {
                commands.push(args);
            }
        }
    }
    for command in commands {
        spawns += 1;
        let args: Vec<_> = command[1..].iter().map(String::as_str).collect();
        changed |= wf_core::proc::run_in(
            &command[0],
            &args,
            &[],
            Some(root),
            Duration::from_secs(600),
        )
        .is_ok_and(|o| o.ok());
    }
    (spawns, changed)
}

fn wait_until(timeout: Duration, mut ready: impl FnMut(Duration) -> bool) -> bool {
    let deadline = std::time::Instant::now() + timeout;
    loop {
        let remaining = deadline.saturating_duration_since(std::time::Instant::now());
        if remaining.is_zero() {
            return false;
        }
        if ready(remaining) {
            return true;
        }
        std::thread::sleep(
            Duration::from_millis(200)
                .min(deadline.saturating_duration_since(std::time::Instant::now())),
        );
    }
}
