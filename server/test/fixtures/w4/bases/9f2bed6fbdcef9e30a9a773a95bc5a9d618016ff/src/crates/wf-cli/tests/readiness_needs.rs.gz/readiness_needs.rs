use std::path::Path;
use std::process::{Command, Output};

/// A repository with an empty consumer profile, laid out like one that keeps its compose
/// files under `deploy/`.
fn repo(files: &[(&str, &str)]) -> tempfile::TempDir {
    let dir = tempfile::tempdir().unwrap();
    let mut all = vec![(
        "workflow/readiness/consumer.yaml",
        "schema_version: 1\nprofile: consumer\nrequirements: []\n",
    )];
    all.extend_from_slice(files);
    for (path, text) in all {
        let path = dir.path().join(path);
        std::fs::create_dir_all(path.parent().unwrap()).unwrap();
        std::fs::write(path, text).unwrap();
    }
    dir
}

/// Run with a PATH holding nothing but, when a test needs it, the machine's own `docker`,
/// so nothing is installed and only the services a test declares can be started.
fn readiness(root: &Path, args: &[&str]) -> Output {
    let bin = root.join("bin");
    std::fs::create_dir_all(&bin).unwrap();
    Command::new(env!("CARGO_BIN_EXE_wf"))
        .current_dir(root)
        .env("PATH", &bin)
        .env("WF_HOME", root.join("state"))
        .env("SHELL", "/bin/sh")
        .args(["readiness", "--force", "--root"])
        .arg(root)
        .args(args)
        .output()
        .unwrap()
}

#[test]
fn a_service_with_no_compose_file_exits_non_zero_and_names_where_it_looked() {
    let dir = repo(&[]);
    let out = readiness(
        dir.path(),
        &["--need", "wf-fixture-orders-db", "--need", "node"],
    );
    let stderr = String::from_utf8_lossy(&out.stderr);
    assert_eq!(out.status.code(), Some(2), "{stderr}");
    for looked in ["compose.yaml", "docker-compose.yml", "deploy/", "--compose"] {
        assert!(stderr.contains(looked), "{looked}: {stderr}");
    }

    let out = readiness(dir.path(), &["--json", "--need", "wf-fixture-orders-db"]);
    assert_eq!(out.status.code(), Some(2));
    let envelope: serde_json::Value = serde_json::from_slice(&out.stdout).unwrap();
    assert_eq!(envelope["ok"], false);
    assert_eq!(envelope["errors"][0]["code"], "READINESS-NEED");
}

#[test]
fn toolchain_needs_run_without_any_compose_file() {
    let dir = repo(&[]);
    let out = readiness(
        dir.path(),
        &[
            "--json", "--need", "node", "--need", "pnpm", "--need", "bazel",
        ],
    );
    let envelope: serde_json::Value = serde_json::from_slice(&out.stdout).unwrap();
    assert!(envelope["errors"]
        .as_array()
        .unwrap()
        .iter()
        .all(|e| e["code"] == "NOT-READY"));
    let subjects: Vec<&str> = envelope["result"]["findings"]
        .as_array()
        .unwrap()
        .iter()
        .map(|f| f["subject"].as_str().unwrap())
        .collect();
    for tool in ["node", "pnpm", "bazel"] {
        assert!(subjects.contains(&tool), "{tool}: {subjects:?}");
    }
    let ready = envelope["result"]["ready"].as_bool().unwrap();
    assert_eq!(out.status.code(), Some(if ready { 0 } else { 1 }));
}

/// Takes down whatever the test's compose project started.
struct Down<'a>(&'a Path);

impl Drop for Down<'_> {
    fn drop(&mut self) {
        // Compose interpolates the file even to take it down; a fixture's required variable
        // needs a value here, whatever the test did with it.
        let out = Command::new("docker")
            .args([
                "compose",
                "-f",
                "deploy/docker-compose.yml",
                "down",
                "--volumes",
                "--timeout",
                "0",
            ])
            .env("WF_FIXTURE_PASSWORD", "down")
            .current_dir(self.0)
            .output()
            .unwrap();
        assert!(
            out.status.success(),
            "{}",
            String::from_utf8_lossy(&out.stderr)
        );
    }
}

/// A pass is not reused once what Compose resolves has changed: the variable the file requires
/// comes from the process environment here, so no file changes when it goes away.
#[test]
#[cfg_attr(target_os = "macos", ignore = "needs a Docker daemon")]
fn a_cached_pass_is_not_reused_when_the_environment_compose_reads_changes() {
    // A project name of its own: every fixture here sits in `deploy/`, and tests run side by
    // side.
    let dir = repo(&[(
        "deploy/docker-compose.yml",
        "name: wf-readiness-cache\nservices:\n  worker:\n    image: alpine:latest\n    command: ['sleep', '600']\n    environment:\n      - PASSWORD=${WF_FIXTURE_PASSWORD:?WF_FIXTURE_PASSWORD is required}\n    healthcheck:\n      test: ['CMD', 'true']\n      interval: 1s\n      start_period: 0s\n",
    )]);
    let _down = Down(dir.path());
    let docker = wf_core::proc::which("docker").expect("docker is needed for this test");
    let bin = dir.path().join("bin");
    std::fs::create_dir_all(&bin).unwrap();
    std::os::unix::fs::symlink(docker, bin.join("docker")).unwrap();
    let run = |password: Option<&str>| -> serde_json::Value {
        let mut command = Command::new(env!("CARGO_BIN_EXE_wf"));
        command
            .current_dir(dir.path())
            .env("PATH", &bin)
            .env("WF_HOME", dir.path().join("state"))
            .env("SHELL", "/bin/sh")
            .env_remove("WF_FIXTURE_PASSWORD")
            .args(["readiness", "--json", "--need", "worker", "--root"])
            .arg(dir.path());
        if let Some(password) = password {
            command.env("WF_FIXTURE_PASSWORD", password);
        }
        let out = command.output().unwrap();
        serde_json::from_slice(&out.stdout)
            .unwrap_or_else(|_| panic!("{}", String::from_utf8_lossy(&out.stderr)))
    };
    let subjects = |envelope: &serde_json::Value, code: &str| -> bool {
        envelope["result"]["findings"]
            .as_array()
            .unwrap()
            .iter()
            .any(|f| f["code"] == code && f["subject"] == "worker")
    };

    let first = run(Some("fixture"));
    assert!(!subjects(&first, "SVC-DOWN"), "{first}");
    let again = run(Some("fixture"));
    assert_eq!(again["result"]["cached"], true, "{again}");

    let unset = run(None);
    assert_eq!(unset["result"]["cached"], false, "{unset}");
    assert!(subjects(&unset, "SVC-CONFIG"), "{unset}");
}

#[test]
#[cfg_attr(target_os = "macos", ignore = "needs a Docker daemon")]
fn a_service_under_deploy_without_a_host_port_is_found_started_and_verified() {
    // sub2api's shape: compose under deploy/ with variants beside it, a required variable
    // the project's .env sets, and a service with a healthcheck and no host port.
    let dir = repo(&[
        (
            "deploy/docker-compose.yml",
            "services:\n  worker:\n    image: alpine:latest\n    command: ['sleep', '600']\n    environment:\n      - PASSWORD=${WF_FIXTURE_PASSWORD:?WF_FIXTURE_PASSWORD is required}\n    healthcheck:\n      test: ['CMD', 'true']\n      interval: 1s\n      start_period: 0s\n",
        ),
        ("deploy/docker-compose.local.yml", "services: {}\n"),
        ("deploy/.env", "WF_FIXTURE_PASSWORD=fixture\n"),
    ]);
    let _down = Down(dir.path());
    let docker = wf_core::proc::which("docker").expect("docker is needed for this test");
    std::fs::create_dir_all(dir.path().join("bin")).unwrap();
    std::os::unix::fs::symlink(docker, dir.path().join("bin/docker")).unwrap();
    let out = readiness(dir.path(), &["--json", "--need", "worker"]);
    let envelope: serde_json::Value = serde_json::from_slice(&out.stdout)
        .unwrap_or_else(|_| panic!("{}", String::from_utf8_lossy(&out.stderr)));
    let result = &envelope["result"];
    assert_eq!(result["repaired"], true, "{envelope}");
    assert!(
        !result["findings"]
            .as_array()
            .unwrap()
            .iter()
            .any(|f| f["subject"] == "worker"),
        "{envelope}"
    );
    let ps = Command::new("docker")
        .args([
            "compose",
            "-f",
            "deploy/docker-compose.yml",
            "ps",
            "--format",
            "{{.Service}} {{.State}} {{.Health}}",
        ])
        .current_dir(dir.path())
        .output()
        .unwrap();
    assert_eq!(
        String::from_utf8_lossy(&ps.stdout).trim(),
        "worker running healthy"
    );
    let ready = result["ready"].as_bool().unwrap();
    assert_eq!(out.status.code(), Some(if ready { 0 } else { 1 }));
}
