use crate::requirements::{version_ge, Requirements};
use crate::resolve::{Resolver, CTX_LOGIN, CTX_MINIMAL, CTX_SESSION};
use serde::Serialize;
use std::time::Duration;
use wf_core::Result;

/// Separates "the session cannot do the work" from "you should know this".
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum Severity {
    /// Blocks: the work cannot proceed on this machine as it stands.
    Fail,
    /// Does not block, but names something that will surprise someone later — a tool the
    /// session can run and the developer's own terminal cannot, for instance.
    Warn,
    /// Context worth carrying into the report: the resolved path, the manager.
    Note,
}

/// How far the checker may go to fix a finding on its own. A property of the blast radius,
/// not of convenience.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum Tier {
    /// Starting a service, pulling an image, creating a directory. Undoing it is one
    /// command, so it runs automatically.
    Reversible,
    /// Adding a toolchain. Runs only on `--repair`, and never by switching a global version
    /// the developer pinned.
    Install,
    /// Anything touching a credential. Printed, never executed.
    Manual,
}

#[derive(Debug, Clone, Serialize)]
pub struct Finding {
    pub code: String,
    pub subject: String,
    pub severity: Severity,
    pub detail: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub fix: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub tier: Option<Tier>,
    /// The operator-facing sentence.
    #[serde(skip_serializing_if = "String::is_empty")]
    pub zh: String,
}

pub const TOOL_MISSING: &str = "TOOL-MISSING";
pub const TOOL_VERSION: &str = "TOOL-VERSION";
pub const TOOL_CONTEXT: &str = "TOOL-CONTEXT";
pub const CRED_MISSING: &str = "CRED-MISSING";
pub const CRED_INVALID: &str = "CRED-INVALID";

/// The artifact: what the coding stage can require, and what the report renders.
#[derive(Debug, Clone, Serialize)]
pub struct Verdict {
    pub ready: bool,
    pub repaired: bool,
    pub cached: bool,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub reason: String,
    pub root: String,
    pub profile: String,
    pub at: String,
    pub findings: Vec<Finding>,
    pub versions: std::collections::BTreeMap<String, String>,
    /// How many processes this run started. Zero on a cache hit is the promise.
    pub spawns: u32,
    pub state_file: String,
}

impl Verdict {
    pub fn render_zh(&self) -> String {
        let mut s = if self.ready {
            "这台机器可以开工。".to_string()
        } else {
            "还差几样东西才能开工。".to_string()
        };
        if self.cached {
            s.push_str("（用的是缓存结果，机器没有变化）");
        }
        s.push('\n');
        for f in &self.findings {
            if f.severity == Severity::Note {
                continue;
            }
            let mark = if f.severity == Severity::Fail {
                "缺"
            } else {
                "注意"
            };
            s.push_str(&format!(
                "  [{mark}] {} — {}\n",
                f.subject,
                if f.zh.is_empty() {
                    f.detail.clone()
                } else {
                    f.zh.clone()
                }
            ));
            if !f.fix.is_empty() {
                s.push_str(&format!("        {}\n", f.fix));
            }
        }
        if self.ready && self.findings.iter().all(|f| f.severity == Severity::Note) {
            s.push_str("  所有需要的工具和凭据都就位了。\n");
        }
        s
    }
}

pub fn check(opt: &crate::Options<'_>, req: &Requirements) -> Result<Verdict> {
    let resolver = Resolver::new();
    let state_path = crate::state::path(opt.root, opt.cache_dir);
    let previous = crate::state::load(&state_path);
    let salt = match previous
        .as_ref()
        .map(|s| s.salt.as_str())
        .filter(|s| !s.is_empty())
    {
        Some(s) => s.to_string(),
        None => crate::state::new_salt()?,
    };
    // Components are read before the fingerprint and are part of it: reading one is a few
    // small files and no process, and a server removed from an agent must not hide behind
    // a cached pass.
    let here;
    let installation = match opt.installation {
        Some(installation) => Some(installation),
        None if req.components.is_empty() => None,
        None => {
            here = crate::components::Installation::here()?;
            here.as_ref()
        }
    };
    let components = crate::components::check(installation, opt.agent, &req.components)?;
    let fingerprint = crate::state::fingerprint(opt.root, req, &resolver, &salt, &components);
    if !opt.force {
        if let Some(prev) = previous {
            if crate::state::reusable(&prev, &fingerprint, req, opt.ttl) {
                return Ok(Verdict {
                    cached: true,
                    spawns: 0,
                    at: prev.at,
                    ..verdict_from(opt, req, prev.findings, prev.versions, false)
                });
            }
        }
    }

    let (mut findings, mut versions) = assess(opt, req, &resolver);
    findings.extend(components.iter().cloned());
    let before = serde_json::to_string(&findings)?;
    let (repair_spawns, ran) = crate::repair::apply(opt.root, req, &findings, opt.repair);
    let mut spawns = resolver.spawns.get() + repair_spawns;
    let mut repaired = false;
    let mut fingerprint = fingerprint;
    if ran {
        // Re-resolve after installation. Reusing the original paths/findings would cache
        // a failed verdict even when the repair succeeded.
        let after = Resolver::new();
        (findings, versions) = assess(opt, req, &after);
        findings.extend(components.iter().cloned());
        spawns += after.spawns.get();
        let next = crate::state::fingerprint(opt.root, req, &after, &salt, &components);
        repaired = next != fingerprint || serde_json::to_string(&findings)? != before;
        fingerprint = next;
    }
    let mut verdict = verdict_from(opt, req, findings, versions, repaired);
    verdict.spawns = spawns;
    let _ = crate::state::save(
        &state_path,
        &crate::state::State {
            salt,
            fingerprint,
            at: verdict.at.clone(),
            findings: verdict.findings.clone(),
            versions: verdict.versions.clone(),
        },
    );
    Ok(verdict)
}

fn assess(
    opt: &crate::Options<'_>,
    req: &Requirements,
    resolver: &Resolver,
) -> (Vec<Finding>, std::collections::BTreeMap<String, String>) {
    let mut findings = Vec::new();
    let mut versions = std::collections::BTreeMap::new();

    for t in &req.tools {
        let failure_severity = if t.optional {
            Severity::Warn
        } else {
            Severity::Fail
        };
        let res = resolver.resolve(&t.id);
        if !res.found_in(CTX_SESSION) && !res.found_in(CTX_LOGIN) {
            findings.push(Finding {
                code: TOOL_MISSING.into(),
                subject: t.id.clone(),
                severity: failure_severity,
                detail: if t.why.is_empty() {
                    format!("{} is not installed", t.id)
                } else {
                    t.why.clone()
                },
                fix: t.install_hint().to_string(),
                tier: Some(Tier::Install),
                zh: format!("还没有安装 {}。{}", t.id, hint_zh(t.install_hint())),
            });
            continue;
        }

        // The divergence that wastes an afternoon: the developer's terminal answers and the
        // session does not, so "it works on my machine" is literally true and useless.
        if res.diverges() {
            let (sess, login) = (res.in_ctx(CTX_SESSION), res.in_ctx(CTX_LOGIN));
            let severity = if sess.is_empty() {
                failure_severity
            } else {
                Severity::Warn
            };
            findings.push(Finding {
                code: TOOL_CONTEXT.into(),
                subject: t.id.clone(),
                severity,
                detail: format!(
                    "session resolves {}, login resolves {}",
                    if sess.is_empty() { "nothing" } else { sess },
                    if login.is_empty() { "nothing" } else { login }
                ),
                fix: format!(
                    "add {} to the PATH the session inherits, e.g. in .claude/settings.json",
                    std::path::Path::new(login).parent().map(|p| p.display().to_string()).unwrap_or_default()
                ),
                tier: Some(Tier::Manual),
                zh: format!(
                    "{} 在你自己的终端里能用，但会话里用不了。把它所在的目录加到会话的 PATH 里就好（例如在 .claude/settings.json 里设置）。",
                    t.id
                ),
            });
            if sess.is_empty() {
                continue;
            }
        }

        let path = if res.found_in(CTX_SESSION) {
            res.in_ctx(CTX_SESSION)
        } else {
            res.in_ctx(CTX_LOGIN)
        };
        if crate::catalog::tool(&t.id).is_some() || !t.min.is_empty() || !t.exact.is_empty() {
            let have = probe_version(&t.id, path, resolver, opt.root);
            versions.insert(t.id.clone(), have.clone());
            if have.is_empty() && t.min.is_empty() && t.exact.is_empty() {
                findings.push(Finding {
                    code: "TOOL-UNKNOWN".into(),
                    subject: t.id.clone(),
                    severity: Severity::Warn,
                    detail: format!("{path} could not report a usable version"),
                    fix: t.install_hint().into(),
                    tier: Some(Tier::Install),
                    zh: String::new(),
                });
                continue;
            }
            if !version_ge(&have, &t.min) || (!t.exact.is_empty() && !version_ge(&t.exact, &have)) {
                let requirement = if t.exact.is_empty() {
                    format!(">={}", t.min)
                } else {
                    format!("={}", t.exact)
                };
                findings.push(Finding {
                    code: TOOL_VERSION.into(),
                    subject: t.id.clone(),
                    severity: failure_severity,
                    detail: format!(
                        "{} is {}, need {}",
                        t.id,
                        if have.is_empty() { "unknown" } else { &have },
                        requirement
                    ),
                    fix: t.install_hint().to_string(),
                    tier: Some(Tier::Install),
                    zh: format!(
                        "{} 的版本是 {}，需要 {}。{}",
                        t.id,
                        if have.is_empty() {
                            "认不出来"
                        } else {
                            &have
                        },
                        requirement,
                        hint_zh(t.install_hint())
                    ),
                });
                continue;
            }
        }
        findings.push(Finding {
            code: "TOOL-OK".into(),
            subject: t.id.clone(),
            severity: Severity::Note,
            detail: format!(
                "{path}{}",
                if res.manager.is_empty() {
                    String::new()
                } else {
                    format!(" ({})", res.manager)
                }
            ),
            fix: String::new(),
            tier: None,
            zh: String::new(),
        });
    }

    findings.extend(
        req.credentials
            .iter()
            .map(|credential| crate::credentials::check(credential, resolver)),
    );
    findings.extend(crate::services::check(opt.root, req, resolver));
    (findings, versions)
}

fn verdict_from(
    opt: &crate::Options<'_>,
    _req: &Requirements,
    findings: Vec<Finding>,
    versions: std::collections::BTreeMap<String, String>,
    repaired: bool,
) -> Verdict {
    Verdict {
        ready: !findings.iter().any(|f| f.severity == Severity::Fail),
        repaired,
        cached: false,
        reason: String::new(),
        root: opt.root.to_string_lossy().into_owned(),
        profile: opt.profile.to_string(),
        at: wf_core::time_fmt::now_rfc3339(),
        findings,
        versions,
        spawns: 0,
        state_file: crate::state::path(opt.root, opt.cache_dir)
            .to_string_lossy()
            .into_owned(),
    }
}

/// Ask a binary its version. Bounded, and a failure is an unknown version rather than an
/// error — some tools have no `--version` at all, and that is not a reason to fail a check.
fn probe_version(id: &str, path: &str, resolver: &Resolver, root: &std::path::Path) -> String {
    resolver.spawns.set(resolver.spawns.get() + 1);
    let args = crate::catalog::tool(id)
        .map(|t| t.version_args)
        .unwrap_or(&["--version"]);
    let Ok(out) = wf_core::proc::run_in(path, args, &[], Some(root), Duration::from_secs(15))
    else {
        return String::new();
    };
    if !out.ok() {
        return String::new();
    }
    let text = if out.stdout.trim().is_empty() {
        out.stderr
    } else {
        out.stdout
    };
    let pattern = regex::Regex::new(r"([0-9]+(?:\.[0-9]+){1,3})").expect("version regex");
    pattern
        .captures(&text)
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
        .unwrap_or_default()
}

fn hint_zh(hint: &str) -> String {
    if hint.is_empty() {
        String::new()
    } else if hint.starts_with("http") {
        format!("安装方法见 {hint}。")
    } else {
        format!("运行 `{hint}` 就能装上。")
    }
}

/// Anything the minimal context cannot see is worth saying once, because that is the
/// context a hook runs in.
pub fn minimal_context_note(resolver: &Resolver, bin: &str) -> Option<Finding> {
    let res = resolver.resolve(bin);
    (res.found_in(CTX_SESSION) && !res.found_in(CTX_MINIMAL)).then(|| Finding {
        code: TOOL_CONTEXT.into(),
        subject: bin.into(),
        severity: Severity::Note,
        detail: "resolves in the session but not in a bare spawned process".into(),
        fix: String::new(),
        tier: None,
        zh: String::new(),
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::Path;

    #[test]
    fn credential_processes_are_included_in_the_spawn_count() {
        use std::os::unix::fs::PermissionsExt;
        let dir = tempfile::tempdir().unwrap();
        let probe = dir.path().join("credential-probe");
        std::fs::write(&probe, "#!/bin/sh\nexit 0\n").unwrap();
        std::fs::set_permissions(&probe, std::fs::Permissions::from_mode(0o755)).unwrap();
        let resolver = Resolver::with_paths("/bin", None, dir.path().to_str().unwrap());
        let req = Requirements {
            credentials: vec![crate::requirements::CredReq {
                id: "fixture".into(),
                probe: vec![probe.to_string_lossy().into_owned()],
                ..Default::default()
            }],
            ..Default::default()
        };
        let (findings, _) = assess(&opts(dir.path(), dir.path(), true), &req, &resolver);
        assert!(findings.iter().any(|finding| finding.code == "CRED-OK"));
        assert_eq!(resolver.spawns.get(), 1);
    }

    #[test]
    fn optional_tools_warn_and_broken_unpinned_tools_are_not_healthy() {
        use std::os::unix::fs::PermissionsExt;
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().to_str().unwrap();
        let empty = dir.path().join("empty");
        std::fs::create_dir(&empty).unwrap();
        let resolver = Resolver::with_paths(empty.to_str().unwrap(), None, path);
        let mut req = Requirements {
            tools: vec![crate::ToolReq {
                id: "rust".into(),
                optional: true,
                ..Default::default()
            }],
            ..Default::default()
        };
        let options = opts(dir.path(), dir.path(), true);
        let (missing, _) = assess(&options, &req, &resolver);
        assert!(missing
            .iter()
            .any(|f| f.code == TOOL_MISSING && f.severity == Severity::Warn));
        let binary = dir.path().join("rustc");
        std::fs::write(&binary, "#!/bin/sh\necho 'rustc 1.97.0'\n").unwrap();
        std::fs::set_permissions(&binary, std::fs::Permissions::from_mode(0o755)).unwrap();
        req.tools[0].min = "1.96.1".into();
        req.tools[0].exact = "1.96.1".into();
        let resolver = Resolver::with_paths(path, None, path);
        let (mismatch, _) = assess(&options, &req, &resolver);
        assert!(mismatch
            .iter()
            .any(|f| f.code == TOOL_VERSION && f.severity == Severity::Warn));
        req.tools[0].min.clear();
        req.tools[0].exact.clear();
        req.tools[0].optional = false;
        std::fs::write(&binary, "#!/bin/sh\nexit 1\n").unwrap();
        let (broken, _) = assess(&options, &req, &resolver);
        assert!(broken.iter().any(|f| f.code == "TOOL-UNKNOWN"));
        assert!(!broken.iter().any(|f| f.code == "TOOL-OK"));
    }

    #[test]
    fn failed_verdicts_are_never_reused() {
        let dir = tempfile::tempdir().unwrap();
        let req = Requirements {
            tools: vec![crate::ToolReq {
                id: "wf-definitely-missing-review-tool".into(),
                ..Default::default()
            }],
            ..Default::default()
        };
        let options = opts(dir.path(), dir.path(), false);
        assert!(!check(&options, &req).unwrap().ready);
        assert!(!check(&options, &req).unwrap().cached);
    }

    #[test]
    fn go_uses_its_version_subcommand() {
        use std::os::unix::fs::PermissionsExt;
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("go");
        std::fs::write(
            &path,
            "#!/bin/sh\n[ \"$1\" = version ] || exit 2\necho 'go version go1.26.1 linux/amd64'\n",
        )
        .unwrap();
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o755)).unwrap();
        let resolver = Resolver::with_paths(
            dir.path().to_str().unwrap(),
            None,
            dir.path().to_str().unwrap(),
        );
        assert_eq!(
            probe_version("go", path.to_str().unwrap(), &resolver, dir.path()),
            "1.26.1"
        );
    }

    #[test]
    fn a_newer_compiler_does_not_satisfy_an_exact_pin() {
        use std::os::unix::fs::PermissionsExt;
        let dir = tempfile::tempdir().unwrap();
        let binary = dir.path().join("rustc");
        std::fs::write(&binary, "#!/bin/sh\necho 'rustc 1.97.0'\n").unwrap();
        std::fs::set_permissions(&binary, std::fs::Permissions::from_mode(0o755)).unwrap();
        let resolver = Resolver::with_paths(
            dir.path().to_str().unwrap(),
            None,
            dir.path().to_str().unwrap(),
        );
        let req = Requirements {
            tools: vec![crate::ToolReq {
                id: "rust".into(),
                min: "1.96.1".into(),
                exact: "1.96.1".into(),
                ..Default::default()
            }],
            ..Default::default()
        };
        let (findings, _) = assess(&opts(dir.path(), dir.path(), true), &req, &resolver);
        assert!(findings
            .iter()
            .any(|f| f.code == TOOL_VERSION && f.detail.contains("=1.96.1")));
    }

    fn opts<'a>(root: &'a Path, cache: &'a Path, force: bool) -> crate::Options<'a> {
        crate::Options {
            root,
            profile: "consumer",
            extras: &[],
            repair: false,
            force,
            profile_root: None,
            cache_dir: Some(cache),
            manifest: None,
            compose: None,
            agent: None,
            installation: None,
            ttl: Duration::from_secs(12 * 3600),
        }
    }

    fn repo_root() -> std::path::PathBuf {
        Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../..")
            .canonicalize()
            .unwrap()
    }

    #[test]
    fn a_second_run_on_an_unchanged_machine_spawns_nothing() {
        let cache = tempfile::tempdir().unwrap();
        let root = repo_root();
        let req = Requirements {
            tools: vec![crate::ToolReq {
                id: "git".into(),
                ..Default::default()
            }],
            ..Default::default()
        };

        let first = check(&opts(&root, cache.path(), true), &req).unwrap();
        assert!(!first.cached);
        let second = check(&opts(&root, cache.path(), false), &req).unwrap();
        assert!(second.cached, "an unchanged machine must hit the cache");
        assert_eq!(second.spawns, 0, "a cache hit must execute nothing");
    }

    #[test]
    fn a_missing_tool_is_a_blocking_finding_with_an_instruction() {
        let cache = tempfile::tempdir().unwrap();
        let root = repo_root();
        let req = Requirements {
            tools: vec![crate::ToolReq {
                id: "definitely-not-a-real-tool".into(),
                ..Default::default()
            }],
            ..Default::default()
        };
        let v = check(&opts(&root, cache.path(), true), &req).unwrap();
        assert!(!v.ready);
        let f = v
            .findings
            .iter()
            .find(|f| f.subject == "definitely-not-a-real-tool")
            .unwrap();
        assert_eq!(f.code, TOOL_MISSING);
        assert_eq!(f.severity, Severity::Fail);
        assert!(
            !f.zh.is_empty(),
            "a failure a person reads needs a sentence they can act on"
        );
    }

    #[test]
    fn the_verdict_renders_something_a_person_can_act_on() {
        let v = Verdict {
            ready: false,
            repaired: false,
            cached: false,
            reason: String::new(),
            root: "/repo".into(),
            profile: "consumer".into(),
            at: "now".into(),
            findings: vec![Finding {
                code: TOOL_MISSING.into(),
                subject: "gh".into(),
                severity: Severity::Fail,
                detail: "missing".into(),
                fix: "brew install gh".into(),
                tier: Some(Tier::Install),
                zh: "还没有安装 gh。运行 `brew install gh` 就能装上。".into(),
            }],
            versions: Default::default(),
            spawns: 1,
            state_file: String::new(),
        };
        let s = v.render_zh();
        assert!(s.contains("还差几样东西"), "{s}");
        assert!(s.contains("brew install gh"), "{s}");
    }
}
