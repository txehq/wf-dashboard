//! Subprocess regressions for lifecycle boundaries. All homes, releases, and executables
//! are disposable; these tests never invoke a user's real agent or credentials.
use serde_json::Value;
use std::{
    collections::BTreeMap,
    path::{Path, PathBuf},
    process::{Command, Output},
};
use wf_release::{
    archive,
    bundle::{self, BuildOptions},
    lock::{BinaryRef, CtxUpstream},
};

struct Machine {
    dir: tempfile::TempDir,
    home: PathBuf,
    claude: PathBuf,
    codex: PathBuf,
    path: String,
    dist: PathBuf,
}
impl Machine {
    fn new() -> Self {
        let dir = tempfile::tempdir().unwrap();
        let bin = dir.path().join("fakebin");
        std::fs::create_dir(&bin).unwrap();
        for name in ["claude", "codex"] {
            executable(&bin.join(name),&format!("#!/bin/sh\nif [ \"$1\" = --version ]; then echo '{name} 9.0.0'; else echo usage; fi\n"),0o755);
        }
        let machine = Self {
            home: dir.path().join("wf"),
            claude: dir.path().join("claude"),
            codex: dir.path().join("codex"),
            dist: dir.path().join("dist"),
            path: format!("{}:/usr/bin:/bin", bin.display()),
            dir,
        };
        machine.build("1.0.0");
        machine
    }
    fn build(&self, version: &str) {
        self.build_from(
            &Path::new(env!("CARGO_MANIFEST_DIR")).join("../.."),
            version,
        )
    }
    /// Build a release that pins `ctx` as this platform's ctx, with the asset beside it the
    /// way a local release carries its own files. Returns the pinned digest.
    fn build_pinned(&self, version: &str, ctx: &str) -> String {
        std::fs::create_dir_all(&self.dist).unwrap();
        std::fs::write(self.dist.join("ctx-fake"), ctx).unwrap();
        let sha256 = wf_core::hash::sha256_bytes(ctx.as_bytes());
        self.build_with(
            &Path::new(env!("CARGO_MANIFEST_DIR")).join("../.."),
            version,
            Some(CtxUpstream {
                version: "9.9.9".into(),
                binaries: vec![BinaryRef {
                    target: wf_core::paths::target_triple().into(),
                    asset: "ctx-fake".into(),
                    sha256: sha256.clone(),
                }],
                ..CtxUpstream::none()
            }),
        );
        sha256
    }
    /// Build a release of `version` from an arbitrary tree, so a test can produce two
    /// different bundles that claim the same version.
    fn build_from(&self, root: &Path, version: &str) {
        self.build_with(root, version, None)
    }
    fn build_with(&self, root: &Path, version: &str, ctx: Option<CtxUpstream>) {
        let source = self.dir.path().join("binary");
        std::fs::create_dir_all(&source).unwrap();
        executable(
            &source.join("wf"),
            &format!("#!/bin/sh\necho 'wf {version}'\n"),
            0o755,
        );
        let archive = self.dir.path().join("binary.tar.gz");
        archive::build_tar_gz(&source, &archive).unwrap();
        bundle::build(&BuildOptions {
            root,
            out: &self.dist,
            version,
            source_commit: "a".repeat(40),
            binaries: vec![(wf_core::paths::target_triple().into(), archive)],
            ctx,
        })
        .unwrap();
    }
    fn command(&self, args: &[&str]) -> Command {
        self.command_of(Path::new(env!("CARGO_BIN_EXE_wf")), args)
    }
    /// The same isolated environment around another `wf` — an earlier release's, say.
    fn command_of(&self, program: &Path, args: &[&str]) -> Command {
        let mut command = Command::new(program);
        command
            .args(args)
            .env("HOME", self.dir.path())
            .env("WF_HOME", &self.home)
            .env("CLAUDE_CONFIG_DIR", &self.claude)
            .env("CODEX_HOME", &self.codex)
            .env("PATH", &self.path)
            .env_remove("WF_SOURCE")
            .env_remove("WF_CHANNEL")
            .env_remove("WF_REPO")
            .env_remove("WF_BRANCH")
            .current_dir(self.dir.path());
        command
    }
    fn run(&self, args: &[&str]) -> Output {
        self.command(args).output().unwrap()
    }
    fn install(&self, extra: &[&str]) -> Output {
        let source = format!("local:{}", self.dist.display());
        let mut args = vec!["install", "--source", &source, "--json"];
        args.extend(extra);
        self.run(&args)
    }
    /// The same install without `--json`. The closing "next steps" list is part of the human
    /// rendering only, so it is unreachable from the envelope every other test reads.
    fn install_human(&self) -> String {
        let source = format!("local:{}", self.dist.display());
        let out = self.run(&["install", "--source", &source]);
        assert!(
            out.status.success(),
            "stdout: {}\nstderr: {}",
            String::from_utf8_lossy(&out.stdout),
            String::from_utf8_lossy(&out.stderr)
        );
        String::from_utf8_lossy(&out.stdout).into_owned()
    }
    fn ok(out: Output) -> Value {
        assert!(
            out.status.success(),
            "stdout: {}\nstderr: {}",
            String::from_utf8_lossy(&out.stdout),
            String::from_utf8_lossy(&out.stderr)
        );
        serde_json::from_slice(&out.stdout).unwrap()
    }
    fn db(&self) -> wf_state::Db {
        wf_state::Db::open(&self.home.join("state/state.sqlite3")).unwrap()
    }
    /// Run a hook the way an agent does: its payload on stdin.
    fn hook(&self, args: &[&str], payload: &Value) -> Output {
        use std::io::Write;
        let mut child = self
            .command(args)
            .stdin(std::process::Stdio::piped())
            .stdout(std::process::Stdio::piped())
            .stderr(std::process::Stdio::piped())
            .spawn()
            .unwrap();
        child
            .stdin
            .take()
            .unwrap()
            .write_all(payload.to_string().as_bytes())
            .unwrap();
        child.wait_with_output().unwrap()
    }
    fn read(&self, path: &Path) -> String {
        std::fs::read_to_string(path).unwrap_or_default()
    }
}

/// A stand-in ctx: it logs every invocation, one line each, and answers the questions
/// convergence asks. `hands_off` is whether it knows upstream's daemon handoff; a
/// `<log>.setup-fails` file beside its log makes `setup` fail.
fn fake_ctx(log: &Path, version: &str, hands_off: bool) -> String {
    let daemon = if hands_off {
        r#"echo '{"ok":true,"scope":"installation","installation_quiescent":true,"supervisor_removed":true,"owner_lock_released":true,"endpoint_released":true,"coordination_state_removed":true,"binary_retained":true,"schema":2}'"#
    } else {
        r#"echo "error: unrecognized subcommand 'disable'" >&2; exit 2"#
    };
    let log = log.display();
    format!(
        "#!/bin/sh\necho \"$@\" >> \"{log}\"\ncase \"$1\" in\n  --version) echo 'ctx {version}' ;;\n  daemon) {daemon} ;;\n  setup) [ -e \"{log}.setup-fails\" ] && exit 1 ;;\nesac\nexit 0\n"
    )
}
fn calls(log: &Path) -> Vec<String> {
    std::fs::read_to_string(log)
        .unwrap_or_default()
        .lines()
        .map(str::to_string)
        .collect()
}
fn codes(notes: &Value) -> Vec<String> {
    notes
        .as_array()
        .into_iter()
        .flatten()
        .filter_map(|n| n["code"].as_str())
        .map(str::to_string)
        .collect()
}
fn wait_for(what: &str, mut done: impl FnMut() -> bool) {
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(30);
    while !done() {
        assert!(std::time::Instant::now() < deadline, "timed out: {what}");
        std::thread::sleep(std::time::Duration::from_millis(50));
    }
}
fn executable(path: &Path, body: &str, mode: u32) {
    use std::os::unix::fs::PermissionsExt;
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).unwrap();
    }
    std::fs::write(path, body).unwrap();
    std::fs::set_permissions(path, std::fs::Permissions::from_mode(mode)).unwrap();
}
fn snapshot(root: &Path) -> BTreeMap<PathBuf, Vec<u8>> {
    let mut result = BTreeMap::new();
    if !root.exists() {
        return result;
    }
    for item in std::fs::read_dir(root).unwrap() {
        let item = item.unwrap();
        let path = item.path();
        if item.file_type().unwrap().is_dir() {
            result.extend(snapshot(&path));
        } else if item.file_type().unwrap().is_symlink() {
            result.insert(
                path.clone(),
                std::fs::read_link(path)
                    .unwrap()
                    .as_os_str()
                    .as_encoded_bytes()
                    .to_vec(),
            );
        } else {
            result.insert(path.clone(), std::fs::read(path).unwrap());
        }
    }
    result
}

#[test]
fn dry_runs_leave_no_state_and_do_not_move_local_assets() {
    let m = Machine::new();
    let release = snapshot(&m.dist);
    let plan = Machine::ok(m.install(&["--dry-run"]));
    assert!(!m.home.exists(), "dry-run initialized wf state");
    assert!(
        !m.claude.exists() && !m.codex.exists(),
        "dry-run created agent configuration"
    );
    assert_eq!(
        release,
        snapshot(&m.dist),
        "staging moved an asset out of the local source"
    );
    assert!(!plan["result"]["plan"].as_array().unwrap().is_empty());
    Machine::ok(m.install(&[]));
    assert_eq!(
        release,
        snapshot(&m.dist),
        "real staging moved a local source asset"
    );
    let before = snapshot(&m.home);
    Machine::ok(m.run(&["repair", "--dry-run", "--json"]));
    Machine::ok(m.run(&["sync", "--dry-run", "--force", "--json"]));
    Machine::ok(m.run(&["uninstall", "--dry-run", "--json"]));
    let after = snapshot(&m.home);
    let changed = before
        .keys()
        .chain(after.keys())
        .filter(|key| before.get(*key) != after.get(*key))
        .collect::<Vec<_>>();
    assert!(
        changed.is_empty(),
        "an installed dry-run mutated state: {changed:?}"
    );
}

/// A write that fails after the binary was replaced undoes everything the apply did. An
/// unreadable file is not such a failure — it is reported and left alone — so the failure
/// here is a file where the skills directory has to be.
#[test]
fn a_later_apply_failure_restores_binary_modes_and_leaves_no_receipts() {
    use std::os::unix::fs::PermissionsExt;
    let m = Machine::new();
    let binary = m.home.join("bin/wf");
    executable(&binary, "#!/bin/sh\necho 'wf 0.9.0'\n", 0o751);
    let old = std::fs::read(&binary).unwrap();
    std::fs::create_dir_all(&m.claude).unwrap();
    std::fs::write(m.claude.join("CLAUDE.md"), "user\r\n\r\n").unwrap();
    std::fs::write(m.claude.join("skills"), "not a directory").unwrap();
    std::fs::create_dir_all(&m.codex).unwrap();
    std::fs::write(m.codex.join("AGENTS.override.md"), [0xff]).unwrap();
    let out = m.install(&[]);
    assert!(
        !out.status.success(),
        "a rolled back install reported success"
    );
    assert_eq!(std::fs::read(&binary).unwrap(), old);
    assert_eq!(
        std::fs::metadata(&binary).unwrap().permissions().mode() & 0o777,
        0o751
    );
    assert_eq!(
        std::fs::read(m.claude.join("CLAUDE.md")).unwrap(),
        b"user\r\n\r\n"
    );
    assert!(m.db().receipts().unwrap().is_empty());
    assert!(m.db().installation().unwrap().is_none());
    assert!(m.db().active_generation().unwrap().is_none());
}

#[test]
fn publication_failure_keeps_undo_live_until_activation_finishes() {
    let m = Machine::new();
    std::fs::create_dir_all(m.home.join("state/active")).unwrap(); // publication cannot replace a user's directory
    let out = m.install(&[]);
    assert!(!out.status.success(), "invalid active link was ignored");
    assert!(!m.home.join("bin/wf").exists(), "binary escaped rollback");
    assert!(
        !m.claude.join("CLAUDE.md").exists(),
        "prompt escaped rollback"
    );
    assert!(
        !m.codex.join("hooks.json").exists(),
        "hook escaped rollback"
    );
    assert!(m.db().active_generation().unwrap().is_none());
    assert!(m.db().receipts().unwrap().is_empty());
}

#[test]
fn uninstall_removes_only_owned_objects_and_preserves_the_executable() {
    let m = Machine::new();
    std::fs::create_dir_all(&m.claude).unwrap();
    std::fs::write(m.claude.join("CLAUDE.md"), "user\r\n\r\n\r\n").unwrap();
    std::fs::create_dir_all(&m.codex).unwrap();
    let user=serde_json::json!({"hooks":{"SessionStart":[{"matcher":"startup","hooks":[{"type":"command","command":"echo user"}]}]}}).to_string();
    std::fs::write(m.codex.join("hooks.json"), &user).unwrap();
    std::fs::write(
        m.codex.join("config.toml"),
        "# mine\n[mcp_servers.personal]\ncommand = \"npx\"\n",
    )
    .unwrap();
    Machine::ok(m.install(&[]));
    assert!(m.claude.join("skills/lfg/SKILL.md").is_file());
    let binary = std::fs::read(m.home.join("bin/wf")).unwrap();
    Machine::ok(m.run(&["uninstall", "--yes", "--json"]));
    assert_eq!(std::fs::read(m.home.join("bin/wf")).unwrap(), binary);
    assert!(!m.claude.join("skills/lfg").exists());
    assert!(!m
        .read(&m.claude.join(".claude.json"))
        .contains("wf-history"));
    assert!(!m.read(&m.claude.join("settings.json")).contains("capso-wf"));
    assert_eq!(
        m.read(&m.codex.join("config.toml")),
        "# mine\n[mcp_servers.personal]\ncommand = \"npx\"\n",
        "a person's own servers and comments stay byte for byte"
    );
    assert!(m.db().managed_resources(None).unwrap().is_empty());
    assert_eq!(
        std::fs::read(m.claude.join("CLAUDE.md")).unwrap(),
        b"user\r\n\r\n\r\n"
    );
    let hooks: Value =
        serde_json::from_slice(&std::fs::read(m.codex.join("hooks.json")).unwrap()).unwrap();
    assert_eq!(hooks, serde_json::from_str::<Value>(&user).unwrap());
    assert!(m.db().active_generation().unwrap().is_none());
    assert!(m.db().receipts().unwrap().is_empty());
    assert!(m.db().installation().unwrap().is_none());
    Machine::ok(m.run(&["uninstall", "--yes", "--json"]));
}

#[test]
fn lifecycle_writers_respect_a_lock_held_by_another_process() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    let _guard = wf_core::lock::Guard::try_exclusive(&m.home.join("state/wf.lock")).unwrap();
    let original = snapshot(&m.claude);
    let mut child = m
        .command(&["repair", "--json"])
        .stdout(std::process::Stdio::null())
        .stderr(std::process::Stdio::null())
        .spawn()
        .unwrap();
    std::thread::sleep(std::time::Duration::from_millis(150));
    assert!(
        child.try_wait().unwrap().is_none(),
        "repair ignored the lifecycle lock"
    );
    assert_eq!(original, snapshot(&m.claude));
    drop(_guard);
    assert!(child.wait().unwrap().success());
}

/// The hook and `wf doctor` have to answer the credential question the same way.
///
/// They did not, up to 1.6.0: doctor recomputed it and reported a native Linear server as
/// carrying the capability, while the hook read the row written at install time and repeated
/// "capso.mcp.linear is missing its credential" in every terminal for as long as nobody ran a
/// full sync. The first real install found it; this is the machine that reproduces it.
///
/// The rows are written here rather than earned: neither shipped MCP declares a reference, so a
/// real install records no `credential_missing` row at all. What is under test is the hook's
/// *reading* of a row, which is exactly where the two answers diverged.
///
/// Both arms are load-bearing. Neither shipped MCP declares a reference, so `capso.mcp.linear`
/// is a row the hook can re-answer as satisfied and must drop. The control is a component it
/// *cannot* re-answer, whose row has to survive: without it this test would pass just as well
/// against a hook that had stopped printing credential warnings altogether.
#[test]
fn session_start_re_asks_a_stale_credential_row_rather_than_reprinting_it() {
    const RE_ANSWERABLE: &str = "capso.mcp.linear";
    // A skill carries no credential block, so the re-check cannot answer for it and leaves the
    // stored row standing — the deliberate direction to fail in.
    const CONTROL: &str = "capso.skill.acceptance";

    let m = Machine::new();
    Machine::ok(m.install(&[]));
    for agent in ["claude-code", "codex"] {
        for id in [RE_ANSWERABLE, CONTROL] {
            m.db()
                .set_component(
                    id,
                    agent,
                    wf_state::ComponentState::CredentialMissing,
                    "",
                    "",
                    &format!("{id}: credential missing"),
                )
                .unwrap();
        }
    }

    let before = m.run(&["hook", "session-start", "--agent", "claude"]);
    let before = String::from_utf8_lossy(&before.stdout).into_owned();
    assert!(
        before.contains(CONTROL),
        "a row the hook cannot re-answer must stand, or this test proves nothing: {before}"
    );
    assert!(
        !before.contains(RE_ANSWERABLE),
        "a component that declares no reference has no credential to be missing: {before}"
    );

    // The same question, asked as the other agent. The rows are per agent and the filter is
    // `row_agent == agent`, so without this arm a hook that answered for Claude Code whatever
    // it was asked would pass.
    let codex = m.run(&["hook", "session-start", "--agent", "codex"]);
    let codex = String::from_utf8_lossy(&codex.stdout).into_owned();
    assert!(
        codex.contains(CONTROL),
        "a row the hook cannot re-answer must stand for Codex too: {codex}"
    );
    assert!(
        !codex.contains(RE_ANSWERABLE),
        "the re-check must run for the requesting agent, not only for Claude Code: {codex}"
    );
}

/// `unverified` is reportable without being a fault.
///
/// `/install`'s acceptance criterion is a strict `wf doctor` returning `ok: true`, and both
/// shipped MCPs are `agent-oauth` — so every machine carries components whose login this
/// binary cannot observe. A state that counted as a finding would fail that criterion on every
/// machine, and the only way out would be to report `current` for something nobody checked
/// (txe-workflow#40).
///
/// It asserts that rather than `ok` itself: the release is a local build and nobody trusts the
/// Codex double's dispatcher, so this harness's strict doctor always has findings of its own.
/// What `unverified` controls is whether it adds one, which is what the criterion turns on.
#[test]
fn an_unverified_component_is_never_a_doctor_finding() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    // The install recorded these already; written again so the rows under test do not depend
    // on it. Flip `ComponentState::Unverified` out of `is_healthy` and they become findings,
    // which is the regression this exists to catch.
    for agent in ["claude-code", "codex"] {
        m.db()
            .set_component(
                "capso.mcp.linear",
                agent,
                wf_state::ComponentState::Unverified,
                "",
                "",
                "capso.mcp.linear: login not observed",
            )
            .unwrap();
    }

    let out = m.run(&["doctor", "--json", "--strict"]);
    let text = String::from_utf8_lossy(&out.stdout).into_owned();
    let doc: Value = serde_json::from_str(&text).unwrap_or_else(|e| panic!("{e}: {text}"));
    let states: Vec<&str> = doc["result"]["status"]["components"]
        .as_array()
        .expect("the doctor reported no components at all")
        .iter()
        .filter(|r| r["id"] == "capso.mcp.linear")
        .filter_map(|r| r["state"].as_str())
        .collect();
    assert!(
        !states.is_empty(),
        "the rows under test are absent, so nothing below asserts anything: {text}"
    );
    assert!(
        states.iter().all(|s| *s == "unverified"),
        "an unobserved login must never read as in place: {states:?}"
    );
    let findings = doc["result"]["findings"]
        .as_array()
        .expect("the doctor reported no findings key");
    // Non-empty on this harness, and that is the point: `all` over an empty list is true, and
    // this assertion has to be able to fail.
    assert!(
        !findings.is_empty(),
        "a strict doctor on a test double should have found the drift it cannot repair: {text}"
    );
    assert!(
        findings.iter().all(|x| x["code"] != "capso.mcp.linear"),
        "an unverified component is not a finding: {text}"
    );
}

/// A rollback leaves behind no component state the release it rolls back to cannot read.
///
/// `ComponentState`'s vocabulary only ever grows, and `parse` turns a word an older `wf` does
/// not know into `Blocked` — a session-stopping verdict about a component that is fine. The
/// rows are written by the binary running the rollback, which is the *new* one, and read by
/// the binary it just installed, which is the old one. Both shipped MCPs carry `unverified` on
/// every machine, so the command someone runs *because* something is already wrong is exactly
/// the one that must not hand back four rows the older release misreads.
#[test]
fn a_rollback_leaves_no_component_state_an_older_release_cannot_read() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    assert!(
        !m.db().components().unwrap().is_empty(),
        "the install recorded no component state, so nothing below proves anything"
    );
    m.build("2.0.0");
    Machine::ok(m.install(&[]));
    assert!(
        !m.db().components().unwrap().is_empty(),
        "the upgrade recorded no component state"
    );

    // Not `Machine::ok`: a rollback that degrades anything on these doubles exits non-zero, and
    // that degradation is the agent's, not the transaction's — what matters here is that the
    // generation was published, which is when the component states are written.
    let out = m.run(&["rollback", "--to", "1.0.0", "--json"]);
    let doc: Value = serde_json::from_slice(&out.stdout).unwrap();
    assert!(
        !doc["result"]["rolled_back"].as_bool().unwrap_or(true),
        "the rollback did not apply, so nothing below is about state words: {doc}"
    );
    let left = m.db().components().unwrap();
    assert!(
        left.is_empty(),
        "a rollback left rows in the vocabulary of the release it rolled away from: {left:?}"
    );
    // And the next sync under the older binary records its own, rather than reading a marker
    // that says this version has already been applied.
    assert_eq!(
        m.db().meta("last_applied_version").unwrap().as_deref(),
        Some("1.0.0")
    );
}

/// The session-start hook stays silent about a login nobody observed.
///
/// Deliberate, and the opposite of the test above: `credential_missing` names something the
/// person can set, `unverified` names something they may already have done and cannot act on
/// from a terminal banner. An unanswerable line in every terminal is noise, so it belongs to
/// `wf doctor`, which someone runs on purpose.
///
/// The row is on a *skill*, which carries no credential block, so the hook's re-check cannot
/// answer for it. That is what makes this test able to fail: on an MCP the re-check drops the
/// row for an unrelated reason — it declares no reference — and a hook widened to print
/// `unverified` would stay just as silent.
#[test]
fn session_start_says_nothing_about_an_unverified_login() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    m.db()
        .set_component(
            "capso.skill.acceptance",
            "claude-code",
            wf_state::ComponentState::Unverified,
            "",
            "",
            "capso.skill.acceptance: login not observed",
        )
        .unwrap();
    // The control: the same unanswerable shape in the one state the hook does surface, so
    // silence above is about the state and not about the hook having stopped reporting.
    m.db()
        .set_component(
            "capso.skill.readiness",
            "claude-code",
            wf_state::ComponentState::CredentialMissing,
            "",
            "",
            "capso.skill.readiness: credential missing",
        )
        .unwrap();

    let out = m.run(&["hook", "session-start", "--agent", "claude"]);
    let out = String::from_utf8_lossy(&out.stdout).into_owned();
    assert!(
        out.contains("capso.skill.readiness"),
        "the hook must still surface an actionable row: {out}"
    );
    assert!(
        !out.contains("capso.skill.acceptance"),
        "an unobserved login is not a session-start banner: {out}"
    );
}

/// `wf install`'s closing report is about the servers `wf` installed, and nothing else.
///
/// WFR-016: `wf` manages `capso-linear` and `capso-rackspace-spot` in each managed agent's own
/// MCP configuration, and does not create, log into, repair or narrate a server somebody put in their
/// own configuration — not one they added, not one their account carries, not one pointing at
/// the same service.
///
/// The `.claude.json` below is the machine that makes the difference visible: a second Linear
/// server beside the bridge, either of which can be the broken one. A report that names the
/// one `wf` cannot check sends the operator to the wrong server.
#[test]
fn the_install_report_names_only_the_servers_this_workflow_manages() {
    let m = Machine::new();
    std::fs::create_dir_all(&m.claude).unwrap();
    std::fs::write(
        m.claude.join(".claude.json"),
        r#"{"mcpServers":{"linear":{"type":"http","url":"https://mcp.linear.app/mcp"}}}"#,
    )
    .unwrap();

    let out = m.install_human();
    let step = out
        .lines()
        .find(|l| l.contains("capso.mcp.linear"))
        .unwrap_or_else(|| panic!("no next step for capso.mcp.linear: {out}"));
    assert!(
        step.contains("浏览器登录 mcp.linear.app"),
        "the bridge's own login is the step, and it is missing: {step}"
    );
    // Nothing anywhere in the report creates, logs into or names a server wf does not manage.
    for forbidden in ["mcp add", "mcp login", "将使用", "自带的"] {
        assert!(
            !out.contains(forbidden),
            "the install report reaches past what wf manages ({forbidden:?}): {out}"
        );
    }
    // The entry that answered the host comparison is called `linear`. Ours is `capso-linear`,
    // which contains it, so the check is for the other key standing on its own (WFR-018).
    let bare_linear = out
        .split("capso-linear")
        .collect::<Vec<_>>()
        .join("")
        .contains("\"linear\"");
    assert!(
        !bare_linear,
        "the report named the entry that answered, not just ours: {out}"
    );
}

/// A machine whose Claude Code already holds somebody else's connection to Linear — the
/// fixture the whole feature exists for. The entry is theirs: another key, a remote transport,
/// a header nobody should ever see in a report.
fn machine_already_reaching_linear() -> Machine {
    let m = Machine::new();
    std::fs::create_dir_all(&m.claude).unwrap();
    std::fs::write(
        m.claude.join(".claude.json"),
        r#"{"numStartups":7,"mcpServers":{"linear":{"type":"http","url":"https://mcp.linear.app/mcp","headers":{"Authorization":"Bearer sk-live-DO-NOT-PRINT"}}}}"#,
    )
    .unwrap();
    m
}

/// TXE-2105: before anything is written, `wf` can say that this machine already reaches the
/// service — and says nothing whatever about the entry that reaches it.
#[test]
fn the_survey_names_our_servers_and_nothing_of_the_entry_that_answered() {
    let m = machine_already_reaching_linear();
    let out = Machine::ok(m.install(&["--dry-run"]));
    let candidates = out["result"]["mcp"]["candidates"]
        .as_array()
        .unwrap_or_else(|| panic!("no candidates in the install result: {out}"));
    assert_eq!(candidates.len(), 1, "{out}");
    let c = &candidates[0];
    assert_eq!(c["component_id"], "capso.mcp.linear");
    assert_eq!(c["agent"], "claude-code");
    assert_eq!(c["name"], "capso-linear");
    assert_eq!(c["hosts"][0], "mcp.linear.app");
    assert_eq!(c["by"], "host");

    let printed = out.to_string();
    for forbidden in [
        "sk-live-DO-NOT-PRINT",
        "Authorization",
        "\"linear\"",
        "numStartups",
    ] {
        assert!(
            !printed.contains(forbidden),
            "{forbidden:?} reached the envelope: {printed}"
        );
    }
}

/// The comparison is by service, not by name: a machine holding our key under a different
/// endpoint is still occupied, and one holding nothing of ours is not occupied at all.
#[test]
fn the_survey_answers_by_service_and_by_name_separately() {
    // Our key, holding something that does not reach Linear: a name collision, reported as one.
    let m = Machine::new();
    std::fs::create_dir_all(&m.claude).unwrap();
    std::fs::write(
        m.claude.join(".claude.json"),
        r#"{"mcpServers":{"capso-linear":{"command":"uvx","args":["-y","something-else"]}}}"#,
    )
    .unwrap();
    let out = Machine::ok(m.install(&["--dry-run"]));
    let c = &out["result"]["mcp"]["candidates"][0];
    assert_eq!(c["component_id"], "capso.mcp.linear");
    assert_eq!(c["by"], "key", "{out}");

    // A clean machine is asked nothing about being occupied.
    let clean = Machine::new();
    let out = Machine::ok(clean.install(&["--dry-run"]));
    assert_eq!(
        out["result"]["mcp"]["candidates"].as_array().map(Vec::len),
        Some(0),
        "{out}"
    );
}

#[test]
fn a_survey_before_the_first_install_reads_the_release_without_writing_state() {
    let m = machine_already_reaching_linear();
    let before = std::fs::read(m.claude.join(".claude.json")).unwrap();
    let source = format!("local:{}", m.dist.display());
    let out = m.run(&["mcp", "survey", "--source", &source, "--json"]);
    let doc = Machine::ok(out);
    assert_eq!(doc["result"]["candidates"].as_array().unwrap().len(), 1);
    assert_eq!(doc["result"]["candidates"][0]["by"], "host");
    assert!(!m.home.exists(), "a survey created installation state");
    assert_eq!(
        before,
        std::fs::read(m.claude.join(".claude.json")).unwrap()
    );
}

#[test]
fn a_real_install_reports_the_pre_write_document_and_repeat_install_is_quiet() {
    let m = Machine::new();
    let first = Machine::ok(m.install(&[]));
    assert_eq!(first["result"]["mcp"]["candidates"], serde_json::json!([]));
    assert!(std::fs::read_to_string(m.claude.join(".claude.json"))
        .unwrap()
        .contains("capso-linear"));
    let again = Machine::ok(m.install(&[]));
    assert_eq!(again["result"]["mcp"]["candidates"], serde_json::json!([]));
    assert!(!again.to_string().contains("MCP-ALREADY-CONNECTED"));

    let duplicate = machine_already_reaching_linear();
    let out = Machine::ok(duplicate.install(&[]));
    assert_eq!(
        out["result"]["mcp"]["candidates"].as_array().unwrap().len(),
        1
    );
    assert_eq!(out["result"]["mcp"]["candidates"][0]["by"], "host");
}

#[test]
fn survey_parse_errors_fail_without_exposing_the_document() {
    let m = Machine::new();
    std::fs::create_dir_all(&m.codex).unwrap();
    std::fs::write(
        m.codex.join("config.toml"),
        "[mcp_servers.private_server]\nheaders = secret_value_DO_NOT_PRINT\n",
    )
    .unwrap();
    let source = format!("local:{}", m.dist.display());
    for args in [
        vec![
            "mcp", "survey", "--source", &source, "--agent", "codex", "--json",
        ],
        vec!["mcp", "survey", "--source", &source, "--agent", "codex"],
        vec!["install", "--source", &source, "--agent", "codex", "--json"],
    ] {
        let out = m.run(&args);
        assert!(!out.status.success());
        let text = format!(
            "{}{}",
            String::from_utf8_lossy(&out.stdout),
            String::from_utf8_lossy(&out.stderr)
        );
        assert!(text.contains("MCP-SURVEY-CONFIG"), "{text}");
        for forbidden in ["private_server", "secret_value_DO_NOT_PRINT", "headers"] {
            assert!(!text.contains(forbidden), "{text}");
        }
    }
}

#[test]
fn dry_run_and_name_collisions_have_accurate_human_output() {
    let m = machine_already_reaching_linear();
    let source = format!("local:{}", m.dist.display());
    let dry = m.run(&["install", "--source", &source, "--dry-run"]);
    assert!(dry.status.success());
    // Both streams, because that is what a person at a terminal reads: the headline is
    // stdout and every warning is stderr, the way `emit` writes them in human mode.
    let text = format!(
        "{}{}",
        String::from_utf8_lossy(&dry.stdout),
        String::from_utf8_lossy(&dry.stderr)
    );
    assert!(text.contains("可能产生重复连接"), "{text}");
    // Ours is named; the entry that answered is not, whatever it is called (WFR-016).
    assert!(text.contains("capso-linear"), "{text}");
    assert!(!text.contains("sk-live-DO-NOT-PRINT"), "{text}");
    std::fs::write(
        m.claude.join(".claude.json"),
        r#"{"mcpServers":{"capso-linear":{"command":"uvx","args":["other"]}}}"#,
    )
    .unwrap();
    let survey = m.run(&[
        "mcp",
        "survey",
        "--source",
        &source,
        "--agent",
        "claude-code",
    ]);
    assert!(survey.status.success());
    let text = String::from_utf8_lossy(&survey.stdout);
    assert!(text.contains("同名条目已存在"), "{text}");
    assert!(!text.contains("mcp.linear.app"), "{text}");
}

/// ADR-0006: ctx arrives the way upstream documents an unmanaged install, and `wf history`
/// is that ctx with nothing in between.
#[test]
fn ctx_installs_in_upstreams_order_and_wf_history_is_ctx() {
    use std::os::unix::fs::PermissionsExt;
    let m = Machine::new();
    let log = m.dir.path().join("ctx.log");
    let sha = m.build_pinned("1.0.0", &fake_ctx(&log, "9.9.9", true));
    // What the reimplementation left on a machine: 1.5 GB on the first one measured.
    std::fs::create_dir_all(m.home.join("state/history")).unwrap();
    std::fs::write(m.home.join("state/history/history.sqlite3"), b"old index").unwrap();

    let out = Machine::ok(m.install(&[]));
    assert_eq!(out["result"]["ctx"]["state"], "installed", "{out}");
    let ctx = m.home.join("bin/ctx");
    assert_eq!(wf_core::hash::sha256_file(&ctx).unwrap(), sha);
    assert_eq!(
        std::fs::metadata(&ctx).unwrap().permissions().mode() & 0o777,
        0o755
    );
    assert_eq!(
        calls(&log),
        [
            "--version",
            "--version",
            "index mode auto",
            "setup --format json",
            "semantic enable"
        ]
    );
    assert!(
        !m.home.join("state/history").exists(),
        "the old index stayed"
    );
    // A local build pins no runtime, so the key says so.
    assert_eq!(
        m.db().meta("ctx_current").unwrap().as_deref(),
        Some(format!("{sha}:-").as_str())
    );

    for args in [
        &["history", "search", "needle", "--format", "json"][..],
        &["history", "--help"],
    ] {
        assert!(m.run(args).status.success(), "wf {args:?}");
    }
    assert_eq!(calls(&log)[5..], ["search needle --format json", "--help"]);

    let doctor: Value = serde_json::from_slice(&m.run(&["doctor", "--json"]).stdout).unwrap();
    assert!(
        !codes(&doctor["result"]["findings"]).contains(&"capso.ctx.binary".to_string()),
        "{doctor}"
    );
    // Deleting a daemon's binary without its handoff would crash-loop the daemon.
    Machine::ok(m.run(&["uninstall", "--yes", "--json"]));
    assert_eq!(wf_core::hash::sha256_file(&ctx).unwrap(), sha);
}

#[test]
fn a_ctx_that_does_not_hash_to_its_pin_is_never_run() {
    let m = Machine::new();
    let log = m.dir.path().join("ctx.log");
    m.build_pinned("1.0.0", &fake_ctx(&log, "9.9.9", true));
    std::fs::write(m.dist.join("ctx-fake"), fake_ctx(&log, "6.6.6", true)).unwrap();

    let out = Machine::ok(m.install(&[]));
    assert!(
        codes(&out["warnings"]).contains(&"CTX-INTEGRITY".to_string()),
        "{out}"
    );
    assert!(
        m.db().active_generation().unwrap().is_some(),
        "a ctx refusal undid the release"
    );
    assert!(!log.exists(), "a ctx that failed its digest was executed");
    assert!(!m.home.join("bin/ctx").exists());
    assert!(m
        .db()
        .meta("ctx_error")
        .unwrap()
        .unwrap()
        .starts_with("CTX-INTEGRITY"));
    // A recorded refusal is a blocked row, so neither `wf status` nor `wf doctor` can call
    // this machine healthy while its history is not the ctx this release pins.
    let doctor: Value = serde_json::from_slice(&m.run(&["doctor", "--json"]).stdout).unwrap();
    assert!(
        codes(&doctor["result"]["findings"]).contains(&"capso.ctx.binary".to_string()),
        "{doctor}"
    );
    let status: Value = serde_json::from_slice(&m.run(&["status", "--json"]).stdout).unwrap();
    assert!(
        status["result"]["components"]
            .as_array()
            .unwrap()
            .iter()
            .any(|c| c["id"] == "capso.ctx.binary" && c["state"] == "blocked"),
        "{status}"
    );
}

/// The pinned runtime lands where ctx's loader looks; a runtime deleted after convergence is
/// named by `wf status`, and `wf install` puts it back.
#[test]
fn a_runtime_is_installed_and_one_deleted_later_is_noticed_and_restored() {
    let m = Machine::new();
    let log = m.dir.path().join("ctx.log");
    let target = wf_core::paths::target_triple().to_string();
    let (platform, library) = (
        wf_release::ctx::runtime_platform_for(&target).unwrap(),
        wf_release::ctx::runtime_library_for(&target).unwrap(),
    );
    let sidecar = m.dir.path().join("sidecar");
    std::fs::create_dir_all(sidecar.join("lib")).unwrap();
    std::fs::write(sidecar.join("VERSION_NUMBER"), "1.27.0\n").unwrap();
    std::fs::write(sidecar.join("lib").join(library), b"\x7fELF").unwrap();
    std::fs::create_dir_all(&m.dist).unwrap();
    let runtime_archive = m.dist.join("ctx-runtime.tar.gz");
    archive::build_tar_gz(&sidecar, &runtime_archive).unwrap();

    let ctx = fake_ctx(&log, "9.9.9", true);
    std::fs::write(m.dist.join("ctx-fake"), &ctx).unwrap();
    m.build_with(
        &Path::new(env!("CARGO_MANIFEST_DIR")).join("../.."),
        "1.0.0",
        Some(CtxUpstream {
            version: "9.9.9".into(),
            binaries: vec![BinaryRef {
                target: target.clone(),
                asset: "ctx-fake".into(),
                sha256: wf_core::hash::sha256_bytes(ctx.as_bytes()),
            }],
            runtimes: vec![BinaryRef {
                target,
                asset: "ctx-runtime.tar.gz".into(),
                sha256: wf_core::hash::sha256_file(&runtime_archive).unwrap(),
            }],
            ..CtxUpstream::none()
        }),
    );

    let out = Machine::ok(m.install(&[]));
    assert_eq!(out["result"]["ctx"]["state"], "installed", "{out}");
    let runtime = m.home.join("bin/onnxruntime/1.27.0").join(platform);
    assert!(runtime.join("lib").join(library).is_file());
    let notes = |m: &Machine| -> Vec<String> {
        let status: Value = serde_json::from_slice(&m.run(&["status", "--json"]).stdout).unwrap();
        status["result"]["warnings"]
            .as_array()
            .unwrap()
            .iter()
            .filter_map(|w| w.as_str().map(str::to_string))
            .filter(|w| w.contains("运行库"))
            .collect()
    };
    assert!(notes(&m).is_empty(), "{:?}", notes(&m));

    std::fs::remove_dir_all(&runtime).unwrap();
    assert_eq!(notes(&m).len(), 1, "a deleted runtime went unnoticed");

    Machine::ok(m.install(&[]));
    assert!(runtime.join("lib").join(library).is_file());
    assert!(notes(&m).is_empty(), "{:?}", notes(&m));

    // Bytes that are not the verified archive's are noticed as well, and replaced by a sync
    // with nothing else to do.
    std::fs::write(runtime.join("lib").join(library), b"something else").unwrap();
    assert_eq!(notes(&m).len(), 1, "a changed runtime went unnoticed");
    let source = format!("local:{}", m.dist.display());
    Machine::ok(m.run(&["sync", "--source", &source, "--json"]));
    assert_eq!(
        std::fs::read(runtime.join("lib").join(library)).unwrap(),
        b"\x7fELF"
    );
    assert!(notes(&m).is_empty(), "{:?}", notes(&m));
}

/// Nothing is put in place until the binary is: a runtime that verifies, with a binary that
/// does not, leaves the running ctx and the runtime it loads exactly as they were.
#[test]
fn a_binary_that_fails_its_digest_leaves_the_runtime_in_place_alone() {
    let m = Machine::new();
    let (old_log, new_log) = (m.dir.path().join("old.log"), m.dir.path().join("new.log"));
    let target = wf_core::paths::target_triple().to_string();
    let (platform, library) = (
        wf_release::ctx::runtime_platform_for(&target).unwrap(),
        wf_release::ctx::runtime_library_for(&target).unwrap(),
    );
    let sidecar = m.dir.path().join("sidecar");
    std::fs::create_dir_all(sidecar.join("lib")).unwrap();
    std::fs::write(sidecar.join("VERSION_NUMBER"), "1.27.0\n").unwrap();
    std::fs::write(sidecar.join("lib").join(library), b"the new runtime").unwrap();
    std::fs::create_dir_all(&m.dist).unwrap();
    let runtime_archive = m.dist.join("ctx-runtime.tar.gz");
    archive::build_tar_gz(&sidecar, &runtime_archive).unwrap();
    let new_ctx = fake_ctx(&new_log, "9.9.9", true);
    std::fs::write(m.dist.join("ctx-fake"), b"not the pinned binary").unwrap();
    m.build_with(
        &Path::new(env!("CARGO_MANIFEST_DIR")).join("../.."),
        "1.0.0",
        Some(CtxUpstream {
            version: "9.9.9".into(),
            binaries: vec![BinaryRef {
                target: target.clone(),
                asset: "ctx-fake".into(),
                sha256: wf_core::hash::sha256_bytes(new_ctx.as_bytes()),
            }],
            runtimes: vec![BinaryRef {
                target,
                asset: "ctx-runtime.tar.gz".into(),
                sha256: wf_core::hash::sha256_file(&runtime_archive).unwrap(),
            }],
            ..CtxUpstream::none()
        }),
    );
    let ctx = m.home.join("bin/ctx");
    executable(&ctx, &fake_ctx(&old_log, "1.1.1", true), 0o755);
    let old_runtime = m
        .home
        .join("bin/onnxruntime/1.27.0")
        .join(platform)
        .join("lib")
        .join(library);
    std::fs::create_dir_all(old_runtime.parent().unwrap()).unwrap();
    std::fs::write(&old_runtime, b"the runtime the running ctx loads").unwrap();

    let out = Machine::ok(m.install(&[]));
    assert!(
        codes(&out["warnings"]).contains(&"CTX-INTEGRITY".to_string()),
        "{out}"
    );
    assert_eq!(
        std::fs::read(&old_runtime).unwrap(),
        b"the runtime the running ctx loads"
    );
    assert!(calls(&old_log).is_empty(), "{:?}", calls(&old_log));
    assert!(std::fs::read_to_string(&ctx).unwrap().contains("1.1.1"));
    let left: Vec<_> = std::fs::read_dir(m.home.join("bin/onnxruntime"))
        .unwrap()
        .map(|e| e.unwrap().file_name())
        .collect();
    assert_eq!(
        left,
        vec![std::ffi::OsString::from("1.27.0")],
        "staging left behind"
    );
}

/// The runtime's destination is ours or the convergence refuses it: a link there would point
/// the removal pass at another directory's files.
#[test]
fn a_runtime_destination_that_is_a_symlink_is_refused_and_its_target_untouched() {
    let m = Machine::new();
    let log = m.dir.path().join("ctx.log");
    let target = wf_core::paths::target_triple().to_string();
    let platform = wf_release::ctx::runtime_platform_for(&target).unwrap();
    let library = wf_release::ctx::runtime_library_for(&target).unwrap();
    let sidecar = m.dir.path().join("sidecar");
    std::fs::create_dir_all(sidecar.join("lib")).unwrap();
    std::fs::write(sidecar.join("VERSION_NUMBER"), "1.27.0\n").unwrap();
    std::fs::write(sidecar.join("lib").join(library), b"the new runtime").unwrap();
    std::fs::create_dir_all(&m.dist).unwrap();
    let runtime_archive = m.dist.join("ctx-runtime.tar.gz");
    archive::build_tar_gz(&sidecar, &runtime_archive).unwrap();
    let ctx = fake_ctx(&log, "9.9.9", true);
    std::fs::write(m.dist.join("ctx-fake"), &ctx).unwrap();
    m.build_with(
        &Path::new(env!("CARGO_MANIFEST_DIR")).join("../.."),
        "1.0.0",
        Some(CtxUpstream {
            version: "9.9.9".into(),
            binaries: vec![BinaryRef {
                target: target.clone(),
                asset: "ctx-fake".into(),
                sha256: wf_core::hash::sha256_bytes(ctx.as_bytes()),
            }],
            runtimes: vec![BinaryRef {
                target,
                asset: "ctx-runtime.tar.gz".into(),
                sha256: wf_core::hash::sha256_file(&runtime_archive).unwrap(),
            }],
            ..CtxUpstream::none()
        }),
    );
    // Somebody else's directory, with the platform destination pointing at it.
    let theirs = m.dir.path().join("documents");
    std::fs::create_dir_all(&theirs).unwrap();
    std::fs::write(theirs.join("notes.txt"), b"not wf's to delete").unwrap();
    let version_dir = m.home.join("bin/onnxruntime/1.27.0");
    std::fs::create_dir_all(&version_dir).unwrap();
    std::os::unix::fs::symlink(&theirs, version_dir.join(platform)).unwrap();

    let out = Machine::ok(m.install(&[]));
    assert!(
        codes(&out["warnings"]).contains(&"MANAGED-SYMLINK".to_string()),
        "{out}"
    );
    assert_eq!(
        std::fs::read_to_string(theirs.join("notes.txt")).unwrap(),
        "not wf's to delete"
    );
    assert_eq!(
        std::fs::read_dir(&theirs).unwrap().count(),
        1,
        "the convergence wrote into somebody else's directory"
    );
    assert!(m
        .db()
        .meta("ctx_runtime")
        .unwrap()
        .unwrap_or_default()
        .is_empty());
}

/// A release pinning `ctx` as this platform's ctx and a runtime archive holding `files`
/// (paths relative to the sidecar's top, `{library}` standing for this platform's library
/// name). Returns the runtime's platform directory under `bin/onnxruntime/1.27.0/`.
fn build_with_runtime(m: &Machine, ctx: &str, files: &[(&str, &[u8])]) -> PathBuf {
    let target = wf_core::paths::target_triple().to_string();
    let platform = wf_release::ctx::runtime_platform_for(&target).unwrap();
    let library = wf_release::ctx::runtime_library_for(&target).unwrap();
    let sidecar = m.dir.path().join("sidecar");
    std::fs::create_dir_all(&sidecar).unwrap();
    for (name, bytes) in files {
        let path = sidecar.join(name.replace("{library}", library));
        std::fs::create_dir_all(path.parent().unwrap()).unwrap();
        std::fs::write(path, bytes).unwrap();
    }
    std::fs::create_dir_all(&m.dist).unwrap();
    let runtime_archive = m.dist.join("ctx-runtime.tar.gz");
    archive::build_tar_gz(&sidecar, &runtime_archive).unwrap();
    std::fs::write(m.dist.join("ctx-fake"), ctx).unwrap();
    m.build_with(
        &Path::new(env!("CARGO_MANIFEST_DIR")).join("../.."),
        "1.0.0",
        Some(CtxUpstream {
            version: "9.9.9".into(),
            binaries: vec![BinaryRef {
                target: target.clone(),
                asset: "ctx-fake".into(),
                sha256: wf_core::hash::sha256_bytes(ctx.as_bytes()),
            }],
            runtimes: vec![BinaryRef {
                target,
                asset: "ctx-runtime.tar.gz".into(),
                sha256: wf_core::hash::sha256_file(&runtime_archive).unwrap(),
            }],
            ..CtxUpstream::none()
        }),
    );
    m.home.join("bin/onnxruntime/1.27.0").join(platform)
}

/// Every file under `dir`, relative, with its bytes: a tree compared whole.
fn tree_of(dir: &Path) -> Vec<(String, Vec<u8>)> {
    let mut out: Vec<(String, Vec<u8>)> = walkdir::WalkDir::new(dir)
        .into_iter()
        .map(|e| e.unwrap())
        .filter(|e| e.file_type().is_file())
        .map(|e| {
            (
                e.path()
                    .strip_prefix(dir)
                    .unwrap()
                    .to_string_lossy()
                    .into_owned(),
                std::fs::read(e.path()).unwrap(),
            )
        })
        .collect();
    out.sort();
    out
}

/// The binary and the runtime are one transaction: a binary that fails its check after the
/// runtime was swapped in rolls both back — the old binary, the old runtime tree whole, no
/// staging left — and the old ctx's daemon is given its setup back.
#[test]
fn a_binary_that_fails_after_the_runtime_swap_rolls_both_back() {
    let m = Machine::new();
    let old_log = m.dir.path().join("old.log");
    // Reports the pinned version while it is staged and another once it is in place, so the
    // check after the write is what fails.
    let new_ctx =
        "#!/bin/sh\ncase \"$0\" in */bin/ctx) echo 'ctx 0.0.0' ;; *) echo 'ctx 9.9.9' ;; esac\n";
    let dest = build_with_runtime(
        &m,
        new_ctx,
        &[
            ("VERSION_NUMBER", b"1.27.0\n"),
            ("LICENSE", b"MIT"),
            ("lib/{library}", b"the new runtime"),
        ],
    );
    let ctx = m.home.join("bin/ctx");
    let old_ctx = fake_ctx(&old_log, "1.1.1", true);
    executable(&ctx, &old_ctx, 0o755);
    std::fs::create_dir_all(dest.join("lib")).unwrap();
    std::fs::write(dest.join("VERSION_NUMBER"), "the old runtime's version\n").unwrap();
    std::fs::write(
        dest.join("lib/old-only"),
        "a file the new runtime does not carry",
    )
    .unwrap();
    let before = tree_of(&dest);

    let out = Machine::ok(m.install(&[]));
    assert!(
        codes(&out["warnings"]).contains(&"CTX-VERSION".to_string()),
        "{out}"
    );
    assert_eq!(
        std::fs::read_to_string(&ctx).unwrap(),
        old_ctx,
        "the binary stayed replaced"
    );
    assert_eq!(
        tree_of(&dest),
        before,
        "the old runtime did not come back whole"
    );
    let left: Vec<_> = std::fs::read_dir(m.home.join("bin/onnxruntime"))
        .unwrap()
        .map(|e| e.unwrap().file_name())
        .collect();
    assert_eq!(
        left,
        vec![std::ffi::OsString::from("1.27.0")],
        "staging left behind"
    );
    assert_eq!(
        calls(&old_log),
        [
            "daemon disable --prepare-uninstall --format=json",
            "index mode auto"
        ],
        "the old daemon was not given back"
    );
    assert!(m
        .db()
        .meta("ctx_runtime")
        .unwrap()
        .unwrap_or_default()
        .is_empty());
}

/// The setup runs before the commit: when it fails after the swap, the new daemon is handed
/// off, the previous binary and the previous runtime tree come back whole, and the previous
/// daemon is given its setup back.
#[test]
fn a_setup_that_fails_after_the_swap_puts_the_previous_installation_back() {
    let m = Machine::new();
    let (old_log, new_log) = (m.dir.path().join("old.log"), m.dir.path().join("new.log"));
    std::fs::write(format!("{}.setup-fails", new_log.display()), "").unwrap();
    let dest = build_with_runtime(
        &m,
        &fake_ctx(&new_log, "9.9.9", true),
        &[
            ("VERSION_NUMBER", b"1.27.0\n"),
            ("LICENSE", b"MIT"),
            ("lib/{library}", b"the new runtime"),
        ],
    );
    let ctx = m.home.join("bin/ctx");
    let old_ctx = fake_ctx(&old_log, "1.1.1", true);
    executable(&ctx, &old_ctx, 0o755);
    std::fs::create_dir_all(dest.join("lib")).unwrap();
    std::fs::write(dest.join("VERSION_NUMBER"), "the old runtime's version\n").unwrap();
    std::fs::write(
        dest.join("lib/old-only"),
        "a file the new runtime does not carry",
    )
    .unwrap();
    let before = tree_of(&dest);

    let out = Machine::ok(m.install(&[]));
    assert!(
        codes(&out["warnings"]).contains(&"CTX-SETUP".to_string()),
        "{out}"
    );
    assert_eq!(std::fs::read_to_string(&ctx).unwrap(), old_ctx);
    assert_eq!(
        tree_of(&dest),
        before,
        "the old runtime did not come back whole"
    );
    assert!(!m.home.join("bin/onnxruntime/.previous").exists());
    let new_calls = calls(&new_log);
    assert!(
        new_calls.contains(&"setup --format json".to_string()),
        "{new_calls:?}"
    );
    assert_eq!(
        new_calls.last().map(String::as_str),
        Some("daemon disable --prepare-uninstall --format=json"),
        "the new daemon was not handed off before the rollback"
    );
    assert_eq!(
        calls(&old_log),
        [
            "daemon disable --prepare-uninstall --format=json",
            "index mode auto"
        ]
    );
    assert!(m
        .db()
        .meta("ctx_runtime")
        .unwrap()
        .unwrap_or_default()
        .is_empty());
}

/// A release that pins no runtime — one from before runtimes were pinned, reached by a
/// rollback — leaves none it never verified where ctx loads it.
#[test]
fn a_release_that_pins_no_runtime_moves_the_recorded_one_out_of_the_loaders_way() {
    let m = Machine::new();
    let log = m.dir.path().join("ctx.log");
    let ctx = fake_ctx(&log, "9.9.9", true);
    let dest = build_with_runtime(
        &m,
        &ctx,
        &[
            ("VERSION_NUMBER", b"1.27.0\n"),
            ("lib/{library}", b"the runtime"),
        ],
    );
    Machine::ok(m.install(&[]));
    assert!(dest.is_dir());
    assert!(!m
        .db()
        .meta("ctx_runtime")
        .unwrap()
        .unwrap_or_default()
        .is_empty());

    m.build_with(
        &Path::new(env!("CARGO_MANIFEST_DIR")).join("../.."),
        "1.0.1",
        Some(CtxUpstream {
            version: "9.9.9".into(),
            binaries: vec![BinaryRef {
                target: wf_core::paths::target_triple().into(),
                asset: "ctx-fake".into(),
                sha256: wf_core::hash::sha256_bytes(ctx.as_bytes()),
            }],
            ..CtxUpstream::none()
        }),
    );
    let out = Machine::ok(m.install(&[]));
    assert_eq!(out["result"]["ctx"]["state"], "installed", "{out}");
    assert!(
        !dest.exists(),
        "a runtime this release never pinned stayed where ctx loads it"
    );
    assert!(!m.home.join("bin/onnxruntime/.previous").exists());
    assert!(m
        .db()
        .meta("ctx_runtime")
        .unwrap()
        .unwrap_or_default()
        .is_empty());
}

/// An update killed between its swap and its commit leaves the committed runtime in
/// `.previous` and an uncommitted tree in its place; the next convergence reads the record and
/// puts the committed one back. A leftover the record does not name is removed.
#[test]
fn an_interrupted_update_is_finished_from_the_record_the_next_time() {
    let m = Machine::new();
    let log = m.dir.path().join("ctx.log");
    let dest = build_with_runtime(
        &m,
        &fake_ctx(&log, "9.9.9", true),
        &[
            ("VERSION_NUMBER", b"1.27.0\n"),
            ("lib/{library}", b"the committed runtime"),
        ],
    );
    Machine::ok(m.install(&[]));
    let committed = tree_of(&dest);
    let library = wf_release::ctx::runtime_library_for(wf_core::paths::target_triple()).unwrap();
    let displaced = m
        .home
        .join("bin/onnxruntime/.previous/1.27.0")
        .join(dest.file_name().unwrap());

    std::fs::create_dir_all(displaced.parent().unwrap()).unwrap();
    std::fs::rename(&dest, &displaced).unwrap();
    // Only the tree that went back carries this: a fresh expansion of the archive would not.
    std::fs::write(displaced.join("recovered"), "this tree went back").unwrap();
    std::fs::create_dir_all(dest.join("lib")).unwrap();
    std::fs::write(dest.join("lib").join(library), "never committed").unwrap();
    Machine::ok(m.install(&[]));
    let mut expected = committed.clone();
    expected.push(("recovered".to_string(), b"this tree went back".to_vec()));
    expected.sort();
    assert_eq!(
        tree_of(&dest),
        expected,
        "the committed runtime did not go back"
    );
    assert!(!m.home.join("bin/onnxruntime/.previous").exists());
    std::fs::remove_file(dest.join("recovered")).unwrap();

    std::fs::create_dir_all(displaced.join("lib")).unwrap();
    std::fs::write(displaced.join("lib").join(library), "an older runtime").unwrap();
    Machine::ok(m.install(&[]));
    assert_eq!(tree_of(&dest), committed);
    assert!(!m.home.join("bin/onnxruntime/.previous").exists());
}

/// The runtime root is checked before the archive is expanded into it: a root that is a link
/// is refused, and nothing is ever staged in the directory it points at.
#[test]
fn a_runtime_root_that_is_a_symlink_is_refused_before_anything_is_staged() {
    let m = Machine::new();
    let log = m.dir.path().join("ctx.log");
    build_with_runtime(
        &m,
        &fake_ctx(&log, "9.9.9", true),
        &[
            ("VERSION_NUMBER", b"1.27.0\n"),
            ("lib/{library}", b"the new runtime"),
        ],
    );
    let theirs = m.dir.path().join("theirs");
    std::fs::create_dir_all(&theirs).unwrap();
    std::fs::write(theirs.join("notes.txt"), "not wf's to write into").unwrap();
    std::fs::create_dir_all(m.home.join("bin")).unwrap();
    std::os::unix::fs::symlink(&theirs, m.home.join("bin/onnxruntime")).unwrap();

    let out = Machine::ok(m.install(&[]));
    assert!(
        codes(&out["warnings"]).contains(&"MANAGED-SYMLINK".to_string()),
        "{out}"
    );
    assert_eq!(
        tree_of(&theirs),
        vec![("notes.txt".to_string(), b"not wf's to write into".to_vec())]
    );
    assert_eq!(
        std::fs::read_dir(&theirs).unwrap().count(),
        1,
        "something was staged through the link"
    );
}

/// The runtime goes in whole, so a layout change between two archives converges: a directory
/// the old runtime had where the new one has a file, and a file where it has a directory.
#[test]
fn a_runtime_whose_layout_changed_replaces_the_old_tree_whole() {
    let m = Machine::new();
    let log = m.dir.path().join("ctx.log");
    let dest = build_with_runtime(
        &m,
        &fake_ctx(&log, "9.9.9", true),
        &[
            ("VERSION_NUMBER", b"1.27.0\n"),
            ("LICENSE", b"MIT"),
            ("lib/{library}", b"the new runtime"),
        ],
    );
    std::fs::create_dir_all(dest.join("LICENSE")).unwrap();
    std::fs::write(dest.join("LICENSE/old"), "was a directory").unwrap();
    std::fs::write(dest.join("lib"), "was a file").unwrap();

    let out = Machine::ok(m.install(&[]));
    assert_eq!(out["result"]["ctx"]["state"], "installed", "{out}");
    let library = wf_release::ctx::runtime_library_for(wf_core::paths::target_triple()).unwrap();
    assert_eq!(
        tree_of(&dest),
        vec![
            ("LICENSE".to_string(), b"MIT".to_vec()),
            ("VERSION_NUMBER".to_string(), b"1.27.0\n".to_vec()),
            (format!("lib/{library}"), b"the new runtime".to_vec()),
        ]
    );
}

/// A bind mount inside the old runtime is somebody else's directory: the convergence refuses
/// before anything moves, and what is under the mount is untouched. Run in a user and mount
/// namespace of its own (`unshare -rm`), where an unprivileged process may bind-mount — which
/// a Linux host allows and a CI container does not, so it is run by name with `--ignored`.
/// The mount detector itself runs everywhere, against real mounts
/// (`wf_core::paths::tests::a_mount_root_is_told_from_a_plain_directory`).
#[test]
#[ignore = "needs an unprivileged mount namespace (`unshare -rm`) on Linux"]
fn a_bind_mount_inside_the_old_runtime_is_refused_and_left_alone() {
    let m = Machine::new();
    let log = m.dir.path().join("ctx.log");
    let dest = build_with_runtime(
        &m,
        &fake_ctx(&log, "9.9.9", true),
        &[
            ("VERSION_NUMBER", b"1.27.0\n"),
            ("lib/{library}", b"the new runtime"),
        ],
    );
    let theirs = m.dir.path().join("theirs");
    std::fs::create_dir_all(&theirs).unwrap();
    std::fs::write(theirs.join("notes.txt"), "not wf's to delete").unwrap();
    std::fs::create_dir_all(dest.join("lib")).unwrap();
    std::fs::write(dest.join("VERSION_NUMBER"), "the old runtime's version\n").unwrap();

    let source = format!("local:{}", m.dist.display());
    let wf = env!("CARGO_BIN_EXE_wf");
    let lib = dest.join("lib");
    let out = m
        .command_of(
            Path::new("unshare"),
            &[
                "-rm",
                "sh",
                "-c",
                "mount --bind \"$1\" \"$2\" && shift 2 && exec \"$@\"",
                "sh",
                theirs.to_str().unwrap(),
                lib.to_str().unwrap(),
                wf,
                "install",
                "--source",
                &source,
                "--json",
            ],
        )
        .output()
        .unwrap();
    let envelope: Value = serde_json::from_slice(&out.stdout)
        .unwrap_or_else(|_| panic!("{}", String::from_utf8_lossy(&out.stderr)));
    let warnings = envelope["warnings"].to_string();
    assert!(warnings.contains("is a mount point"), "{envelope}");
    assert_eq!(
        std::fs::read_to_string(theirs.join("notes.txt")).unwrap(),
        "not wf's to delete"
    );
    assert_eq!(std::fs::read_dir(&theirs).unwrap().count(), 1);
    assert_eq!(
        std::fs::read_to_string(dest.join("VERSION_NUMBER")).unwrap(),
        "the old runtime's version\n"
    );
}

/// `wf doctor` asks ctx about itself only when its bytes are the ones the release pinned: a
/// ctx replaced after install is reported and never run.
#[test]
fn doctor_never_runs_a_ctx_that_is_not_the_pinned_bytes() {
    let m = Machine::new();
    let log = m.dir.path().join("ctx.log");
    m.build_pinned("1.0.0", &fake_ctx(&log, "9.9.9", true));
    Machine::ok(m.install(&[]));

    let tampered = m.dir.path().join("tampered.log");
    executable(
        &m.home.join("bin/ctx"),
        &format!("#!/bin/sh\necho \"$@\" >> \"{}\"\n", tampered.display()),
        0o755,
    );
    let doctor: Value = serde_json::from_slice(&m.run(&["doctor", "--json"]).stdout).unwrap();
    assert!(
        !tampered.exists(),
        "wf doctor ran a ctx the release did not pin"
    );
    assert!(
        doctor["result"]["findings"]
            .as_array()
            .unwrap()
            .iter()
            .any(|f| f["zh"]
                .as_str()
                .unwrap_or_default()
                .contains("不是这个版本锁定的 ctx")),
        "{doctor}"
    );
}

/// The runtime converges before the daemon is touched: an archive that fails its digest
/// leaves the ctx already here running as it was, never handed off and never replaced.
#[test]
fn a_runtime_that_fails_its_digest_leaves_the_running_ctx_alone() {
    let m = Machine::new();
    let (old_log, new_log) = (m.dir.path().join("old.log"), m.dir.path().join("new.log"));
    let new_ctx = fake_ctx(&new_log, "9.9.9", true);
    std::fs::create_dir_all(&m.dist).unwrap();
    std::fs::write(m.dist.join("ctx-fake"), &new_ctx).unwrap();
    std::fs::write(m.dist.join("ctx-runtime.tar.gz"), b"not the pinned archive").unwrap();
    let target = wf_core::paths::target_triple().to_string();
    m.build_with(
        &Path::new(env!("CARGO_MANIFEST_DIR")).join("../.."),
        "1.0.0",
        Some(CtxUpstream {
            version: "9.9.9".into(),
            binaries: vec![BinaryRef {
                target: target.clone(),
                asset: "ctx-fake".into(),
                sha256: wf_core::hash::sha256_bytes(new_ctx.as_bytes()),
            }],
            runtimes: vec![BinaryRef {
                target,
                asset: "ctx-runtime.tar.gz".into(),
                sha256: "0".repeat(64),
            }],
            ..CtxUpstream::none()
        }),
    );
    let ctx = m.home.join("bin/ctx");
    executable(&ctx, &fake_ctx(&old_log, "1.1.1", true), 0o755);

    let out = Machine::ok(m.install(&[]));
    assert!(
        codes(&out["warnings"]).contains(&"CTX-INTEGRITY".to_string()),
        "{out}"
    );
    assert!(
        calls(&old_log).is_empty(),
        "the running ctx was handed off: {:?}",
        calls(&old_log)
    );
    assert!(!new_log.exists(), "the new ctx ran");
    assert!(std::fs::read_to_string(&ctx).unwrap().contains("1.1.1"));
}

/// A ctx with a daemon that does not report a quiescent handoff keeps its binary: replacing
/// it anyway would orphan a live daemon, so it stays until the person stops that daemon.
#[test]
fn a_ctx_that_cannot_hand_off_its_daemon_stays_until_it_can() {
    let m = Machine::new();
    let (old_log, new_log) = (m.dir.path().join("old.log"), m.dir.path().join("new.log"));
    let sha = m.build_pinned("1.0.0", &fake_ctx(&new_log, "9.9.9", true));
    let ctx = m.home.join("bin/ctx");
    executable(&ctx, &fake_ctx(&old_log, "1.1.1", false), 0o755);
    let marker = m.home.join("bin/ctx.install.json");
    std::fs::write(&marker, r#"{"manager":"ctx-hosted-installer"}"#).unwrap();

    let out = Machine::ok(m.install(&[]));
    assert!(
        codes(&out["warnings"]).contains(&"CTX-HANDOFF".to_string()),
        "{out}"
    );
    assert!(m.db().active_generation().unwrap().is_some());
    assert_eq!(
        calls(&old_log),
        ["daemon disable --prepare-uninstall --format=json"]
    );
    assert_eq!(
        calls(&new_log),
        ["--version"],
        "the new ctx ran past its check"
    );
    assert!(std::fs::read_to_string(&ctx).unwrap().contains("1.1.1"));
    assert!(marker.exists());

    executable(&ctx, &fake_ctx(&old_log, "1.1.1", true), 0o755);
    let out = Machine::ok(m.install(&[]));
    assert_eq!(out["result"]["ctx"]["state"], "installed", "{out}");
    assert_eq!(wf_core::hash::sha256_file(&ctx).unwrap(), sha);
    assert!(
        !marker.exists(),
        "a marker for a binary that is gone stayed"
    );
    assert_eq!(
        calls(&new_log)[1..],
        [
            "--version",
            "--version",
            "index mode auto",
            "setup --format json",
            "semantic enable"
        ]
    );
    let backups = snapshot(&m.home.join("state/backups"));
    for kept in ["1.1.1", "ctx-hosted-installer"] {
        assert!(
            backups
                .values()
                .any(|b| String::from_utf8_lossy(b).contains(kept)),
            "no backup holds {kept}"
        );
    }
}

/// A release applied by the previous `wf`, or a ctx setup that failed, is finished by the
/// hook's background worker, which starts at most hourly and never once ctx is current.
#[test]
fn session_start_converges_ctx_in_the_background_at_most_hourly() {
    let m = Machine::new();
    let log = m.dir.path().join("ctx.log");
    let sha = m.build_pinned("1.0.0", &fake_ctx(&log, "9.9.9", true));
    let fails = PathBuf::from(format!("{}.setup-fails", log.display()));
    std::fs::write(&fails, "").unwrap();
    let out = Machine::ok(m.install(&[]));
    assert!(
        codes(&out["warnings"]).contains(&"CTX-SETUP".to_string()),
        "{out}"
    );

    let marker = m.home.join("state/ctx.pid");
    let setups = || {
        calls(&log)
            .iter()
            .filter(|c| c.starts_with("setup"))
            .count()
    };
    let worker_gone = || {
        let text = std::fs::read_to_string(&marker).unwrap_or_default();
        let pid = text.split(':').next().unwrap_or("0").parse().unwrap_or(0);
        !wf_core::proc::process_alive(pid)
    };
    Machine::ok(m.run(&["hook", "session-start", "--agent", "claude"]));
    wait_for("a background attempt", || setups() == 2 && worker_gone());
    let first = std::fs::read(&marker).unwrap();
    Machine::ok(m.run(&["hook", "session-start", "--agent", "claude"]));
    assert_eq!(
        first,
        std::fs::read(&marker).unwrap(),
        "retried within the hour"
    );

    std::fs::remove_file(&fails).unwrap();
    std::fs::write(&marker, "0:0").unwrap(); // an hour has passed
    Machine::ok(m.run(&["hook", "session-start", "--agent", "claude"]));
    wait_for("convergence", || {
        m.db().meta("ctx_current").unwrap().as_deref() == Some(format!("{sha}:-").as_str())
    });
    wait_for("the worker to exit", worker_gone);
    std::fs::write(&marker, "0:0").unwrap();
    Machine::ok(m.run(&["hook", "session-start", "--agent", "claude"]));
    assert_eq!(
        std::fs::read(&marker).unwrap(),
        b"0:0",
        "a converged machine scheduled ctx again"
    );
}

#[test]
fn a_ctx_already_on_path_is_used_and_never_shadowed() {
    let m = Machine::new();
    let out = m.run(&["history", "status"]);
    assert!(!out.status.success());
    assert!(
        String::from_utf8_lossy(&out.stderr).contains("wf install"),
        "{}",
        String::from_utf8_lossy(&out.stderr)
    );

    let brew = m.dir.path().join("brew.log");
    executable(
        &m.dir.path().join("fakebin/ctx"),
        &fake_ctx(&brew, "1.4.6", true),
        0o755,
    );
    m.build_pinned(
        "1.0.0",
        &fake_ctx(&m.dir.path().join("ctx.log"), "9.9.9", true),
    );
    let out = Machine::ok(m.install(&[]));
    assert!(
        codes(&out["warnings"]).contains(&"CTX-FOREIGN".to_string()),
        "{out}"
    );
    assert!(!m.home.join("bin/ctx").exists());
    assert!(m.run(&["history", "status"]).status.success());
    assert_eq!(calls(&brew), ["status"]);
}

/// The real agents read what the agent layer wrote: Codex parses its MCP table and Claude
/// Code lists the server, from isolated homes.
#[test]
#[ignore = "requires installed Claude Code and Codex; uses isolated homes and local releases"]
fn real_agents_read_the_servers_wf_deployed() {
    let mut m = Machine::new();
    m.path = std::env::var("PATH").unwrap();
    for agent in ["claude", "codex"] {
        assert!(
            wf_core::proc::which(agent).is_some(),
            "install {agent} to run native contract tests"
        );
    }
    std::fs::create_dir_all(&m.claude).unwrap();
    std::fs::create_dir_all(&m.codex).unwrap();
    Machine::ok(m.install(&[]));
    for (agent, args) in [
        ("codex", vec!["mcp", "list", "--json"]),
        ("claude", vec!["mcp", "get", "wf-history"]),
    ] {
        let out = Command::new(wf_core::proc::which(agent).unwrap())
            .args(&args)
            .env("HOME", m.dir.path())
            .env("CLAUDE_CONFIG_DIR", &m.claude)
            .env("CODEX_HOME", &m.codex)
            .env("CI", "1")
            .current_dir(m.dir.path())
            .output()
            .unwrap();
        let text = String::from_utf8_lossy(&out.stdout);
        assert!(
            text.contains("wf-history") && text.contains(&*m.home.join("bin/wf").to_string_lossy()),
            "{agent}: {text}\n{}",
            String::from_utf8_lossy(&out.stderr)
        );
    }
}

#[test]
fn an_old_remote_check_cannot_overwrite_a_new_installation_source() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    m.db()
        .record_installation(
            &wf_state::Installation {
                channel: "stable".into(),
                version: "1.0.0".into(),
                repo: "source/a".into(),
                branch: "main".into(),
                source: "github:source/a".into(),
            },
            "github-release",
            wf_core::paths::target_triple(),
        )
        .unwrap();
    let entered = m.dir.path().join("entered");
    let resume = m.dir.path().join("resume");
    executable(&m.dir.path().join("fakebin/gh"),&format!("#!/bin/sh\ntouch '{}'\nwhile [ ! -e '{}' ]; do sleep 0.01; done\necho '[{{\"tag_name\":\"v3.0.0\",\"draft\":false,\"prerelease\":false,\"immutable\":true}}]'\n",entered.display(),resume.display()),0o755);
    // Captured rather than discarded: "remote check did not start" with the hook's own
    // output thrown away is a failure message that tells whoever hits it nothing.
    let hook_out = m.dir.path().join("hook.out");
    let mut hook = m
        .command(&["hook", "session-start", "--agent", "claude"])
        .stdout(std::fs::File::create(&hook_out).unwrap())
        .stderr(std::fs::File::create(m.dir.path().join("hook.err")).unwrap())
        .spawn()
        .unwrap();
    // Generous on purpose. This deadline is not a budget — it is only waiting for the hook
    // to reach its remote check, and what the test proves is the *ordering* that follows.
    // At two seconds it flaked roughly one run in three: a debug build opening a database
    // and spawning a subprocess is measuring the machine, and a timing assertion nobody
    // trusts is worse than none.
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(60);
    // Two ways this can go, and the property under test holds either way.
    //
    // The interesting one is the interleaving: the hook is inside its remote check when a
    // newer release is installed underneath it, and its answer must not win. The other is
    // that the hook's own two-second network deadline expires first — a hard ceiling in
    // `session_start`, not a policy a bundle can raise — and it keeps the last known good
    // generation instead. That is the same property arriving by a different route, and
    // under parallel load on a busy machine it is the route actually taken, because a
    // subprocess can take longer than two seconds just to reach its first command.
    //
    // Waiting only for `entered` made this a race against process startup that the test
    // lost roughly one run in three. Waiting for either outcome loses nothing: both are
    // asserted below.
    let interleaved = loop {
        if entered.exists() {
            break true;
        }
        if hook.try_wait().unwrap().is_some() {
            break false;
        }
        assert!(
            std::time::Instant::now() < deadline,
            "the hook neither reached its remote check nor exited.\n  stdout: {}\n  stderr: {}",
            std::fs::read_to_string(&hook_out)
                .unwrap_or_default()
                .trim(),
            std::fs::read_to_string(m.dir.path().join("hook.err"))
                .unwrap_or_default()
                .trim(),
        );
        std::thread::sleep(std::time::Duration::from_millis(5));
    };

    m.build("2.0.0");
    Machine::ok(m.install(&[]));
    std::fs::write(&resume, "go").unwrap();
    assert!(
        hook.wait().unwrap().success(),
        "a session start must never fail"
    );
    if !interleaved {
        // The deadline expired. The hook must have said so and changed nothing.
        let said = std::fs::read_to_string(&hook_out).unwrap_or_default();
        assert!(
            said.contains("超时") || said.contains("timed out"),
            "a remote check that did not run should say why: {said}"
        );
    }
    assert_eq!(
        m.db().active_generation().unwrap().unwrap().version,
        "2.0.0"
    );
    assert_ne!(
        m.db().meta("desired_version").unwrap().as_deref(),
        Some("3.0.0")
    );
    assert!(
        !m.home.join("state/updater.pid").exists(),
        "obsolete source launched an updater"
    );
}

#[test]
fn background_sync_waits_for_the_dispatcher_to_release_the_lifecycle_lock() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    let guard = wf_core::lock::Guard::try_exclusive(&m.home.join("state/wf.lock")).unwrap();
    let mut child = m
        .command(&["sync", "--from-hook", "--offline"])
        .stdout(std::process::Stdio::null())
        .stderr(std::process::Stdio::null())
        .spawn()
        .unwrap();
    std::thread::sleep(std::time::Duration::from_millis(150));
    assert!(
        child.try_wait().unwrap().is_none(),
        "background sync exited while its dispatcher still held the lock"
    );
    drop(guard);
    assert!(child.wait().unwrap().success());
}

/// Copy a source tree, minus the parts a release never reads.
fn copy_tree(src: &Path, dst: &Path) {
    for entry in std::fs::read_dir(src).unwrap() {
        let entry = entry.unwrap();
        let name = entry.file_name();
        if matches!(name.to_str(), Some("target") | Some(".git")) {
            continue;
        }
        let to = dst.join(&name);
        if entry.file_type().unwrap().is_dir() {
            std::fs::create_dir_all(&to).unwrap();
            copy_tree(&entry.path(), &to);
        } else {
            std::fs::copy(entry.path(), &to).unwrap();
        }
    }
}

/// A `local:` source rewritten in place under one version is refused, not silently reused.
///
/// A generation directory is named for its version, so a version already staged is reused
/// instead of fetched again — sound only while one version means one set of bytes. A local
/// source is a directory somebody can rewrite, and during development they do. Reusing the
/// stale generation there applied the old bundle and printed a success line over it, which
/// is the one outcome an operator cannot detect. Refusing is the answer that cannot corrupt
/// an active generation, which every later apply and repair copies from.
#[test]
fn a_local_source_rebuilt_under_one_version_is_refused_rather_than_reused() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));

    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
    let rebuilt = m.dir.path().join("rebuilt-root");
    std::fs::create_dir_all(&rebuilt).unwrap();
    copy_tree(&root, &rebuilt);
    // Same version, different bytes — exactly what a re-cut release looks like.
    let skill = rebuilt.join("skills/decide/SKILL.md");
    let mut text = std::fs::read_to_string(&skill).unwrap();
    text.push_str("\nAn extra line, so the bundle digest differs.\n");
    std::fs::write(&skill, text).unwrap();
    m.build_from(&rebuilt, "1.0.0");

    let source = format!("local:{}", m.dist.display());
    let out = m.run(&["sync", "--source", &source, "--force", "--json"]);
    let v: Value = serde_json::from_slice(&out.stdout).unwrap();
    let warnings = v["warnings"].as_array().cloned().unwrap_or_default();
    let said = warnings
        .iter()
        .filter_map(|w| w["zh"].as_str())
        .collect::<Vec<_>>()
        .join("\n");
    assert!(
        said.contains("GENERATION-CONTENT"),
        "a rebuilt bundle under the same version should be refused and say why, got: {said}"
    );
    assert!(
        !v["result"]["changed"].as_bool().unwrap_or(true),
        "nothing should have been applied"
    );
}

/// Every detected agent gets the same resources in its own format: skills copied, the
/// session-start and usage hooks with the installed binary's absolute path, the wf-history
/// MCP server (ADR-0006) and the organization prompt — and nothing of the retired plugin.
#[test]
fn install_deploys_every_resource_into_every_detected_agent() {
    let m = Machine::new();
    std::fs::create_dir_all(&m.claude).unwrap();
    std::fs::create_dir_all(&m.codex).unwrap();
    std::fs::create_dir_all(m.dir.path().join(".cursor")).unwrap();
    std::fs::create_dir_all(m.dir.path().join(".kiro")).unwrap();
    std::fs::create_dir_all(m.dir.path().join(".openclaw")).unwrap();
    let out = Machine::ok(m.install(&[]));
    let wf = m.home.join("bin/wf").to_string_lossy().into_owned();
    let cursor = m.dir.path().join(".cursor");

    for root in [&m.claude, &m.codex, &cursor] {
        assert!(
            root.join("skills/lfg/SKILL.md").is_file(),
            "{}",
            root.display()
        );
        assert!(
            root.join("skills/history/SKILL.md").is_file(),
            "{}",
            root.display()
        );
    }
    let claude_mcp: Value = serde_json::from_str(&m.read(&m.claude.join(".claude.json"))).unwrap();
    assert_eq!(
        claude_mcp["mcpServers"]["wf-history"]["command"],
        wf.as_str()
    );
    let codex_config: toml::Value = toml::from_str(&m.read(&m.codex.join("config.toml"))).unwrap();
    assert_eq!(
        codex_config["mcp_servers"]["wf-history"]["command"].as_str(),
        Some(wf.as_str())
    );
    let cursor_mcp: Value = serde_json::from_str(&m.read(&cursor.join("mcp.json"))).unwrap();
    assert_eq!(
        cursor_mcp["mcpServers"]["wf-history"]["command"],
        wf.as_str()
    );

    let settings = m.read(&m.claude.join("settings.json"));
    assert!(
        settings.contains(&format!("{wf} hook session-start --agent claude")),
        "{settings}"
    );
    assert!(
        settings.contains("hook dispatch --event PostToolUse"),
        "{settings}"
    );
    // The document is written pretty-printed, so this is the spacing it has. A bare marker
    // check would pass for a relative `wf`, a path from an earlier generation, or the wrong
    // `--agent`, leaving Codex the one agent whose argv nothing verifies.
    let codex_hooks = m.read(&m.codex.join("hooks.json"));
    assert!(
        codex_hooks.contains(&format!(
            r#""command": "{wf} hook session-start --agent codex""#
        )),
        "{codex_hooks}"
    );
    assert!(codex_hooks.contains(r#""statusMessage": "capso-wf-bootstrap""#));
    assert!(m
        .read(&cursor.join("hooks.json"))
        .contains("hook session-start --agent cursor"));

    // The organization prompt reaches every agent that reads one, whole — the managed block in
    // an instructions file, or Kiro's steering file.
    let prompt = std::fs::read_to_string(
        Path::new(env!("CARGO_MANIFEST_DIR")).join("../../workflow/prompts/capso-global.md"),
    )
    .unwrap();
    for file in [
        m.claude.join("CLAUDE.md"),
        m.codex.join("AGENTS.md"),
        m.dir.path().join(".kiro/steering/capso-global.md"),
        m.dir.path().join(".openclaw/workspace/AGENTS.md"),
    ] {
        assert!(
            m.read(&file).contains(prompt.trim_end()),
            "{} does not carry the whole prompt",
            file.display()
        );
    }
    let bundle = m.home.join("state/active/bundle");
    assert!(
        !bundle.join(".claude-plugin").exists()
            && !bundle.join("plugins/magi/.claude-plugin").exists()
            && !bundle.join("plugins/magi/.codex-plugin").exists(),
        "the release carries no plugin package, only the skill trees 1.x hashes"
    );
    assert!(m.db().native_receipts().unwrap().is_empty(), "{out}");

    let agents = Machine::ok(m.run(&["agents", "--json"]));
    let managed: Vec<&str> = agents["result"]
        .as_array()
        .unwrap()
        .iter()
        .filter(|a| a["managed"] == true)
        .map(|a| a["id"].as_str().unwrap())
        .collect();
    assert_eq!(
        managed,
        ["claude-code", "codex", "cursor", "kiro", "openclaw"],
        "{agents}"
    );
    let repair = Machine::ok(m.run(&["repair", "--json"]));
    assert!(
        repair["result"]["applied"].as_array().unwrap().is_empty(),
        "a second apply changes nothing: {repair}"
    );
}

/// The usage hooks record into the machine's own database, and a session worth keeping
/// lands in the month's log; a dispatch never prints anything into the agent.
#[test]
fn usage_hooks_record_sessions_that_wf_usage_and_wf_sessions_report() {
    let m = Machine::new();
    std::fs::create_dir_all(&m.claude).unwrap();
    Machine::ok(m.install(&[]));
    let dispatch = |event: &str, payload: Value| {
        let out = m.hook(
            &["hook", "dispatch", "--agent", "claude", "--event", event],
            &payload,
        );
        assert!(out.status.success());
        assert!(
            out.stdout.is_empty(),
            "{}",
            String::from_utf8_lossy(&out.stdout)
        );
    };
    dispatch(
        "UserPromptSubmit",
        serde_json::json!({"session_id": "s-1", "prompt": "/lfg add dark mode", "cwd": "/work"}),
    );
    for tool in ["Bash", "Edit", "Grep"] {
        dispatch(
            "PostToolUse",
            serde_json::json!({"session_id": "s-1", "tool_name": tool, "tool_input": {}}),
        );
    }
    dispatch("Stop", serde_json::json!({"session_id": "s-1"}));

    let usage = Machine::ok(m.run(&["usage", "--json"]));
    assert_eq!(usage["result"]["sessions"], 1, "{usage}");
    assert_eq!(usage["result"]["skills"][0]["key"], "lfg", "{usage}");
    assert_eq!(
        usage["result"]["agents"][0]["key"], "claude-code",
        "{usage}"
    );

    let sessions = Machine::ok(m.run(&["sessions", "--json"]));
    assert_eq!(sessions["result"][0]["session_id"], "s-1", "{sessions}");
    assert_eq!(sessions["result"][0]["valuable"], true, "{sessions}");
    let logs: Vec<PathBuf> = std::fs::read_dir(m.home.join("state/sessions"))
        .unwrap()
        .map(|e| e.unwrap().path())
        .filter(|p| p.extension().is_some_and(|x| x == "md"))
        .collect();
    assert_eq!(logs.len(), 1);
    assert!(m.read(&logs[0]).contains("<!-- wf:session s-1 -->"));

    let shown = Machine::ok(m.run(&["sessions", "show", "s-1", "--json"]));
    assert_eq!(shown["result"]["tool_total"], 3, "{shown}");
    let unknown = m.run(&["sessions", "show", "nope", "--json"]);
    assert!(!unknown.status.success());
}

/// A person decides which agents wf manages; an agent let go keeps nothing of wf's, and
/// later applies leave it alone until it is registered again.
#[test]
fn an_unregistered_agent_is_cleared_and_left_alone_until_registered_again() {
    let m = Machine::new();
    std::fs::create_dir_all(&m.claude).unwrap();
    let cursor = m.dir.path().join(".cursor");
    std::fs::create_dir_all(&cursor).unwrap();
    Machine::ok(m.install(&[]));
    assert!(cursor.join("skills/lfg/SKILL.md").is_file());

    Machine::ok(m.run(&["agents", "unregister", "cursor", "--json"]));
    assert!(!cursor.join("skills/lfg").exists());
    assert!(!m.read(&cursor.join("mcp.json")).contains("wf-history"));
    Machine::ok(m.run(&["repair", "--json"]));
    assert!(
        !cursor.join("skills/lfg").exists(),
        "repair brought back an unregistered agent"
    );
    assert!(m.claude.join("skills/lfg/SKILL.md").is_file());

    Machine::ok(m.run(&["agent", "register", "cursor", "--json"]));
    assert!(cursor.join("skills/lfg/SKILL.md").is_file());
    let absent = m.run(&["agents", "register", "kiro", "--json"]);
    assert!(!absent.status.success(), "kiro is not on this machine");
    for many in ["all", "claude,cursor"] {
        let out = m.run(&["agents", "unregister", many, "--json"]);
        assert!(!out.status.success(), "{many} names more than one agent");
    }
    assert!(
        m.claude.join("skills/lfg/SKILL.md").is_file()
            && cursor.join("skills/lfg/SKILL.md").is_file(),
        "a refused selection changed nothing"
    );
}

/// The updater that installs a new binary is the previous binary, which knows nothing of
/// what the new one manages. The new one notices and applies the generation itself.
#[test]
fn a_generation_the_running_binary_did_not_apply_is_applied_again() {
    let m = Machine::new();
    std::fs::create_dir_all(&m.claude).unwrap();
    Machine::ok(m.install(&[]));
    std::fs::remove_dir_all(m.claude.join("skills/lfg")).unwrap();

    // Already on this version: a sync has nothing to do.
    Machine::ok(m.run(&["sync", "--json"]));
    assert!(!m.claude.join("skills/lfg").exists());

    m.db().set_meta("last_applied_binary", "1.7.0-old").unwrap();
    let session = m.run(&["hook", "session-start", "--agent", "claude"]);
    assert!(session.status.success());
    assert!(
        m.home.join("state/reapply.pid").is_file(),
        "no background apply was started"
    );
    wait_for("the background apply", || {
        m.claude.join("skills/lfg/SKILL.md").is_file()
    });
    wait_for("the background apply to record itself", || {
        m.db().meta("last_applied_binary").unwrap().as_deref() == Some(wf_core::VERSION)
    });

    std::fs::remove_dir_all(m.claude.join("skills/lfg")).unwrap();
    m.db().set_meta("last_applied_binary", "1.7.0-old").unwrap();
    Machine::ok(m.run(&["sync", "--json"]));
    assert!(
        m.claude.join("skills/lfg/SKILL.md").is_file(),
        "sync applied again"
    );
}

/// ADR-0007's crossover, with the real previous release. A machine on it takes this release
/// through its own updater — which knows nothing of the agent layer and hashes the skill trees
/// 1.x kept under `plugins/magi/` — and this release's binary then applies the generation
/// itself at the next session start. Run with the previous release's assets downloaded:
///
/// `gh release download v1.7.0 -R txehq/txe-workflow -D <dir>` for this platform's binary
/// archive, `workflow.lock.json` and the bundle, then
/// `WF_PREVIOUS_RELEASE=<dir> cargo test --release -p wf-cli --test lifecycle_regressions previous_release -- --ignored`.
#[test]
#[ignore = "needs an earlier release's assets in WF_PREVIOUS_RELEASE; run with --release"]
fn a_machine_on_the_previous_release_crosses_over_to_this_one() {
    let previous =
        PathBuf::from(std::env::var("WF_PREVIOUS_RELEASE").expect("set WF_PREVIOUS_RELEASE"));
    let m = Machine::new();
    std::fs::create_dir_all(&m.claude).unwrap();
    std::fs::create_dir_all(&m.codex).unwrap();

    // The previous release, installed by its own binary.
    let archive = std::fs::read_dir(&previous)
        .unwrap()
        .map(|e| e.unwrap().path())
        .find(|p| {
            p.file_name().unwrap().to_string_lossy().starts_with("wf-v")
                && p.to_string_lossy()
                    .contains(wf_core::paths::target_triple())
        })
        .expect("the previous release's binary archive for this platform");
    let old = m.dir.path().join("previous-binary");
    archive::extract_tar_gz(&archive, &old, archive::Limits::default()).unwrap();
    let installed = Machine::ok(
        m.command_of(
            &old.join("wf"),
            &[
                "install",
                "--source",
                &format!("local:{}", previous.display()),
                "--json",
            ],
        )
        .output()
        .unwrap(),
    );
    let before = installed["result"]["active_version"]
        .as_str()
        .unwrap()
        .to_string();
    assert_ne!(before, wf_core::VERSION);

    // This release, with this build's real binary in it.
    let dist = m.dir.path().join("this-release");
    let binary = m.dir.path().join("this-binary");
    std::fs::create_dir_all(&binary).unwrap();
    std::fs::copy(env!("CARGO_BIN_EXE_wf"), binary.join("wf")).unwrap();
    let packed = m.dir.path().join("this-binary.tar.gz");
    archive::build_tar_gz(&binary, &packed).unwrap();
    bundle::build(&BuildOptions {
        root: &Path::new(env!("CARGO_MANIFEST_DIR")).join("../.."),
        out: &dist,
        version: wf_core::VERSION,
        source_commit: "b".repeat(40),
        binaries: vec![(wf_core::paths::target_triple().into(), packed)],
        ctx: None,
    })
    .unwrap();

    // The previous binary applies it: the commit that used to fail on the missing skill trees.
    let wf = m.home.join("bin/wf");
    let synced = Machine::ok(
        m.command_of(
            &wf,
            &[
                "sync",
                "--source",
                &format!("local:{}", dist.display()),
                "--force",
                "--json",
            ],
        )
        .output()
        .unwrap(),
    );
    assert_eq!(
        synced["result"]["active_version"],
        wf_core::VERSION,
        "{synced}"
    );
    assert_eq!(synced["result"]["rolled_back"], false, "{synced}");
    let version = m.command_of(&wf, &["--version"]).output().unwrap();
    assert!(String::from_utf8_lossy(&version.stdout).contains(wf_core::VERSION));
    if before.starts_with("1.") {
        assert!(
            !m.claude.join("skills/lfg").exists(),
            "a 1.x binary deploys no skills"
        );
    }

    // This binary's first session start applies the generation beside the session.
    let session = m
        .command_of(&wf, &["hook", "session-start", "--agent", "claude"])
        .output()
        .unwrap();
    assert!(session.status.success());
    wait_for("the new binary to apply the generation", || {
        m.db().meta("last_applied_binary").unwrap().as_deref() == Some(wf_core::VERSION)
    });
    assert!(m.claude.join("skills/lfg/SKILL.md").is_file());
    assert!(m.codex.join("skills/lfg/SKILL.md").is_file());
    let claude_md = m.read(&m.claude.join("CLAUDE.md"));
    assert_eq!(
        claude_md
            .matches("wf:managed-begin id=capso.global")
            .count(),
        1,
        "the previous release's block is adopted, not duplicated: {claude_md}"
    );
    let hooks = m.read(&m.codex.join("hooks.json"));
    assert_eq!(
        hooks.matches("capso-wf-bootstrap").count(),
        1,
        "the Codex dispatcher is adopted, not duplicated: {hooks}"
    );
    assert!(hooks.contains(&format!(
        r#""command": "{} hook session-start --agent codex""#,
        wf.display()
    )));
}

/// Asking Codex whether it trusts the dispatcher starts Codex's app server, which can take
/// seconds. That question is answered before the commit, never inside it: the commit holds the
/// state database's write lock, and every usage hook in every running session waits on it.
#[test]
fn a_slow_codex_does_not_stall_hooks_while_an_apply_runs() {
    let m = Machine::new();
    std::fs::create_dir_all(&m.claude).unwrap();
    std::fs::create_dir_all(&m.codex).unwrap();
    Machine::ok(m.install(&[]));
    let asked = m.dir.path().join("app-server.asked");
    executable(
        &m.dir.path().join("fakebin/codex"),
        &format!(
            "#!/bin/sh\ncase \"$1\" in\n  --version) echo 'codex 9.0.0' ;;\n  app-server) touch '{}'; sleep 4 ;;\n  *) echo usage ;;\nesac\n",
            asked.display()
        ),
        0o755,
    );
    let mut repair = m
        .command(&["repair", "--json"])
        .stdout(std::process::Stdio::null())
        .stderr(std::process::Stdio::null())
        .spawn()
        .unwrap();
    wait_for("the apply to ask Codex", || asked.exists());
    let started = std::time::Instant::now();
    let out = m.hook(
        &[
            "hook",
            "dispatch",
            "--agent",
            "claude",
            "--event",
            "PostToolUse",
        ],
        &serde_json::json!({"session_id": "s-slow", "tool_name": "Bash"}),
    );
    let took = started.elapsed();
    assert!(out.status.success());
    assert!(
        took < std::time::Duration::from_secs(2),
        "a hook waited {took:?} on an apply asking Codex"
    );
    assert!(repair.wait().unwrap().success());
    assert_eq!(
        m.db()
            .usage_events(&wf_state::UsageQuery {
                session_id: Some("s-slow".into()),
                ..Default::default()
            })
            .unwrap()
            .len(),
        1
    );
}

// --- TXE-2106: a declined MCP server, and every command that has to respect it -----------

/// One decision, recorded the way `wf mcp skip` will record it. Written straight into the
/// state database because the commands that write it are the next ticket; every reader under
/// test here is the one shipping now.
fn decline(m: &Machine, agent: &str) {
    m.db()
        .record_skipped_mcp(&wf_state::SkippedMcp {
            agent_id: agent.into(),
            component_id: "capso.mcp.linear".into(),
            skipped_at: "2026-09-18T10:30:00.000Z".into(),
            reason: "already connected through my own server".into(),
            host: "mcp.linear.app".into(),
            source: "user".into(),
        })
        .unwrap();
}

/// `status` and `doctor` exit non-zero whenever the machine is not perfect, and this harness
/// never is: nobody trusts the Codex double's dispatcher. The envelope is still the answer,
/// so these tests read it rather than asserting on the exit code, which is about something
/// else entirely.
fn envelope(out: &Output) -> Value {
    let text = String::from_utf8_lossy(&out.stdout).into_owned();
    serde_json::from_str(&text).unwrap_or_else(|e| panic!("{e}: {text}"))
}

fn linear_rows(doc: &Value) -> Vec<&Value> {
    doc["result"]["status"]["components"]
        .as_array()
        .map(|rows| {
            rows.iter()
                .filter(|r| r["id"] == "capso.mcp.linear")
                .collect()
        })
        .unwrap_or_default()
}

/// The decision outlives every command that rewrites component state.
///
/// `apply` deletes every `components` row for an agent before writing the run's own back
/// (`engine.rs`), which is exactly why the decision cannot live there. A `--force` sync is the
/// hard case: it re-applies a version already active, so it walks the whole write path.
#[test]
fn a_declined_server_survives_sync_force_sync_and_repair() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    decline(&m, "claude-code");
    let source = format!("local:{}", m.dist.display());
    for args in [
        vec!["sync", "--source", &source, "--json"],
        vec!["sync", "--source", &source, "--force", "--json"],
        vec!["repair", "--json"],
    ] {
        let out = m.run(&args);
        assert!(
            out.status.success(),
            "{args:?}: {:?}",
            String::from_utf8_lossy(&out.stderr)
        );
        let rows = m.db().skipped_mcps().unwrap();
        assert_eq!(rows.len(), 1, "the decision did not survive {args:?}");
        assert_eq!(rows[0].component_id, "capso.mcp.linear");
        assert_eq!(rows[0].reason, "already connected through my own server");
    }
}

/// Declining a server that is already installed must not delete it.
///
/// The orphan sweep removes every owned row the run did not ask for, so a decision that
/// dropped the item out of `wanted` would make the next sync delete an installation the
/// person chose to keep — worse than the duplicate this feature exists to avoid.
#[test]
fn declining_an_installed_server_leaves_it_alone_and_raises_no_orphan() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    let before = std::fs::read_to_string(m.claude.join(".claude.json")).unwrap();
    assert!(
        before.contains("capso-linear"),
        "the fixture never installed it: {before}"
    );

    decline(&m, "claude-code");
    let source = format!("local:{}", m.dist.display());
    Machine::ok(m.run(&["sync", "--source", &source, "--force", "--json"]));

    let after = std::fs::read_to_string(m.claude.join(".claude.json")).unwrap();
    assert!(
        after.contains("capso-linear"),
        "a decision deleted what was already installed: {after}"
    );
    let text = envelope(&m.run(&["doctor", "--json"])).to_string();
    assert!(
        !text.contains("RESOURCE-ORPHAN"),
        "the kept entry was reported as an orphan: {text}"
    );
}

/// The criterion the whole feature turns on: after a decision, nothing warns, ever again.
#[test]
fn a_strict_doctor_is_ok_on_a_machine_with_a_decline_and_never_names_it() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    decline(&m, "claude-code");
    decline(&m, "codex");

    let out = m.run(&["doctor", "--json", "--strict"]);
    let text = String::from_utf8_lossy(&out.stdout).into_owned();
    let doc: Value = serde_json::from_str(&text).unwrap_or_else(|e| panic!("{e}: {text}"));
    let findings = doc["result"]["findings"]
        .as_array()
        .expect("no findings key");
    assert!(
        findings
            .iter()
            .all(|f| { f["code"] != "capso.mcp.linear" && f["subject"] != "capso.mcp.linear" }),
        "a declined server became a finding: {text}"
    );
    for row in linear_rows(&doc) {
        assert_eq!(row["state"], "current", "{text}");
        assert!(
            row["skipped_at"].is_string(),
            "the row lost its timestamp: {text}"
        );
    }
}

/// A decision is a settled object, so the readiness count does not move.
#[test]
fn agents_status_counts_the_same_before_and_after_a_decline() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    let counts = |m: &Machine| -> Vec<(String, u64, u64)> {
        let doc = envelope(&m.run(&["status", "--json"]));
        doc["result"]["agents"]
            .as_array()
            .unwrap()
            .iter()
            .map(|a| {
                (
                    a["agent"].as_str().unwrap_or_default().to_string(),
                    a["current"].as_u64().unwrap_or_default(),
                    a["total"].as_u64().unwrap_or_default(),
                )
            })
            .collect()
    };
    let before = counts(&m);
    decline(&m, "claude-code");
    assert_eq!(before, counts(&m), "a decision moved the readiness count");
}

/// Both shipped MCPs are `agent-oauth`. A declined one has nothing of ours to log into, so
/// naming a browser page for it would be the first of exactly the prompts a decision ends.
#[test]
fn a_declined_oauth_server_asks_for_no_login_and_is_never_unverified() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    decline(&m, "claude-code");
    decline(&m, "codex");

    // The "接下来" list is part of the human rendering and reaches no envelope, so this has
    // to read the human output — against the JSON it would compare against `null` and pass
    // without testing anything.
    let steps = m.install_human();
    assert!(
        steps.contains("接下来"),
        "the fixture produced no next-steps list, so nothing below asserts anything: {steps}"
    );
    assert!(
        !steps.contains("mcp.linear.app"),
        "a declined server still asked for a login: {steps}"
    );

    let doc = envelope(&m.run(&["doctor", "--json"]));
    for row in linear_rows(&doc) {
        assert_ne!(
            row["state"], "unverified",
            "a declined server reported as installed-but-unchecked: {doc}"
        );
    }
}

/// A person who asks is told; the point is that it reads as a decision, not a fault.
#[test]
fn doctor_lists_a_declined_server_under_what_it_did_not_check() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    decline(&m, "claude-code");

    let out = m.run(&["doctor"]);
    let text = format!(
        "{}{}",
        String::from_utf8_lossy(&out.stdout),
        String::from_utf8_lossy(&out.stderr)
    );
    assert!(text.contains("没有检查，你要求不装的"), "{text}");
    assert!(text.contains("capso.mcp.linear"), "{text}");
    assert!(text.contains("2026-09-18"), "the date is missing: {text}");
    assert!(
        text.contains("wf mcp unskip"),
        "no way back is offered: {text}"
    );
    // Only claude-code declined it, so codex's Linear is still a legitimate `unverified`
    // row. What must not appear anywhere a person is asked to act is the declined pair.
    let declined_row = "capso.mcp.linear（claude-code）";
    let needs = text.split("需要处理：").nth(1).unwrap_or_default();
    let needs = needs.split("\n\n").next().unwrap_or_default();
    assert!(
        !needs.contains("capso.mcp.linear"),
        "a decision was listed as something to deal with: {text}"
    );
    let unverified = text
        .split("装好了，但这里看不出登录状态：")
        .nth(1)
        .unwrap_or_default();
    let unverified = unverified.split("\n\n").next().unwrap_or_default();
    assert!(
        !unverified.contains(declined_row),
        "a declined server was offered a login to complete: {text}"
    );
}

/// Session start is the one place a person did not ask. It stays silent.
#[test]
fn a_session_start_says_nothing_about_a_declined_server() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    decline(&m, "claude-code");
    let out = m.run(&["hook", "session-start", "--agent", "claude"]);
    let text = format!(
        "{}{}",
        String::from_utf8_lossy(&out.stdout),
        String::from_utf8_lossy(&out.stderr)
    );
    assert!(out.status.success(), "{text}");
    assert!(
        !text.contains("capso.mcp.linear") && !text.contains("mcp.linear.app"),
        "a session start brought up a settled decision: {text}"
    );
}

/// Removing the installation, or the agent, removes the decisions made about it. A decision
/// about a machine wf no longer writes to would otherwise come back to life on reinstall.
#[test]
fn uninstall_and_unregister_leave_no_decision_behind() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    decline(&m, "claude-code");
    decline(&m, "codex");
    Machine::ok(m.run(&["agents", "unregister", "codex", "--json"]));
    let rows = m.db().skipped_mcps().unwrap();
    assert_eq!(rows.len(), 1, "unregister left a decision behind: {rows:?}");
    assert_eq!(rows[0].agent_id, "claude-code");

    Machine::ok(m.run(&["uninstall", "--yes", "--json"]));
    assert!(
        m.db().skipped_mcps().unwrap().is_empty(),
        "uninstall left a decision behind"
    );
}

/// The browser login is a fact about the machine, not about one agent: the credential is
/// kept once and shared. So declining a server in *one* agent must not silence the login
/// step for the copy still installed in another — the person would be left with a server
/// that never works and nothing telling them why.
#[test]
fn declining_in_one_agent_keeps_the_login_step_for_the_agent_that_has_it() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    decline(&m, "claude-code");
    let steps = m.install_human();
    assert!(
        steps.contains("mcp.linear.app"),
        "Codex still has capso-linear and still needs the login: {steps}"
    );
}

// --- TXE-2107: the person is asked, the answer is written, and one command puts it back ---

/// `wf mcp skip`, the way `/install` calls it after somebody says "leave mine".
fn skip_cmd(m: &Machine, component: &str, agent: Option<&str>) -> Output {
    let mut args = vec!["mcp", "skip", component];
    if let Some(a) = agent {
        args.extend(["--agent", a]);
    }
    args.extend([
        "--host",
        "mcp.linear.app",
        "--reason",
        "我自己已经连了",
        "--json",
    ]);
    m.run(&args)
}

fn skipped_components(m: &Machine) -> Vec<(String, String)> {
    m.db()
        .skipped_mcps()
        .unwrap()
        .into_iter()
        .map(|s| (s.agent_id, s.component_id))
        .collect()
}

/// A rehearsal writes nothing. The command that governs every later run is the one somebody
/// most wants to try first.
#[test]
fn skipping_as_a_dry_run_changes_no_state() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    let out = Machine::ok(m.run(&[
        "mcp",
        "skip",
        "capso.mcp.linear",
        "--agent",
        "claude-code",
        "--dry-run",
        "--json",
    ]));
    assert_eq!(out["result"]["dry_run"], true);
    assert_eq!(out["result"]["agents"][0], "claude-code");
    assert!(
        skipped_components(&m).is_empty(),
        "a dry run recorded a decision"
    );
}

/// The decision is per agent, and naming one must not reach the other.
#[test]
fn a_decision_for_one_agent_leaves_the_other_agents_installation_alone() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    Machine::ok(skip_cmd(&m, "capso.mcp.linear", Some("claude-code")));
    assert_eq!(
        skipped_components(&m),
        vec![("claude-code".to_string(), "capso.mcp.linear".to_string())]
    );

    let source = format!("local:{}", m.dist.display());
    Machine::ok(m.run(&["sync", "--source", &source, "--force", "--json"]));
    let codex = std::fs::read_to_string(m.codex.join("config.toml")).unwrap();
    assert!(
        codex.contains("capso-linear"),
        "a decision about Claude Code removed Codex's server: {codex}"
    );
}

/// Undoing puts it back — through `wf repair`, which is the command that actually installs.
/// `wf sync` on a version already active returns before it checks a single object, so the
/// undo has to name the one that does.
#[test]
fn undoing_a_decision_puts_the_component_back_on_the_next_repair() {
    let m = Machine::new();
    // Decided before the install, the way `/install` asks. Deciding afterwards deliberately
    // leaves an existing installation alone, so it could never show this.
    Machine::ok(skip_cmd(&m, "capso.mcp.linear", Some("claude-code")));
    Machine::ok(m.install(&[]));

    // Never written, because the decision was already there.
    let doc = std::fs::read_to_string(m.claude.join(".claude.json")).unwrap();
    let before: Value = serde_json::from_str(&doc).unwrap();
    assert!(
        before["mcpServers"]["capso-linear"].is_null(),
        "a declined server was installed anyway: {doc}"
    );

    let undone = Machine::ok(m.run(&["mcp", "unskip", "capso.mcp.linear", "--json"]));
    assert_eq!(undone["result"]["undone"], 1);
    assert_eq!(undone["result"]["next"], "wf repair");
    assert!(skipped_components(&m).is_empty());

    let repaired = Machine::ok(m.run(&["repair", "--json"]));
    let applied = repaired["result"]["applied"].to_string();
    assert!(
        applied.contains("capso.mcp.linear"),
        "repair did not put the component back: {applied}"
    );
    let doc = std::fs::read_to_string(m.claude.join(".claude.json")).unwrap();
    let after: Value = serde_json::from_str(&doc).unwrap();
    assert!(
        !after["mcpServers"]["capso-linear"].is_null(),
        "the server is still missing after a repair: {doc}"
    );
}

/// Undoing something nobody decided is not an error, and installs nothing.
#[test]
fn undoing_a_decision_nobody_made_says_so_and_does_nothing() {
    let m = Machine::new();
    Machine::ok(m.install(&[]));
    let out = Machine::ok(m.run(&["mcp", "unskip", "capso.mcp.linear", "--json"]));
    assert_eq!(out["result"]["undone"], 0);
    assert!(out["result"]["next"].is_null());
}

/// The decision stands on its own. Even with the connection that prompted it gone from the
/// document, nothing reinstalls the server and nothing mentions it — the signed-off rule is
/// that a record stands until a person removes it.
#[test]
fn a_decision_stands_after_the_other_connection_disappears() {
    let m = machine_already_reaching_linear();
    Machine::ok(m.install(&[]));
    Machine::ok(skip_cmd(&m, "capso.mcp.linear", Some("claude-code")));

    // The person deletes their own connection. wf is not watching for that.
    std::fs::write(m.claude.join(".claude.json"), r#"{"mcpServers":{}}"#).unwrap();

    let source = format!("local:{}", m.dist.display());
    for args in [
        vec!["sync", "--source", &source, "--json"],
        vec!["repair", "--json"],
        vec!["install", "--source", &source, "--json"],
    ] {
        let out = m.run(&args);
        let text = format!(
            "{}{}",
            String::from_utf8_lossy(&out.stdout),
            String::from_utf8_lossy(&out.stderr)
        );
        let doc = std::fs::read_to_string(m.claude.join(".claude.json")).unwrap();
        let parsed: Value = serde_json::from_str(&doc).unwrap();
        assert!(
            parsed["mcpServers"]["capso-linear"].is_null(),
            "{args:?} installed a component the person declined: {doc}"
        );
        assert!(
            !text.contains("MCP-ALREADY-CONNECTED"),
            "{args:?} warned about a settled decision: {text}"
        );
    }
    assert_eq!(skipped_components(&m).len(), 1);
}

/// `/install`'s flow, end to end: survey, a mixed answer, then install. One server is
/// declined for one agent and installed for the other, and the survey says so next time so
/// nobody is asked twice.
#[test]
fn the_install_flow_asks_once_per_agent_and_a_mixed_answer_is_honoured() {
    let m = machine_already_reaching_linear();
    let source = format!("local:{}", m.dist.display());

    // 1. What would a person be asked about?
    let survey = Machine::ok(m.run(&[
        "mcp", "survey", "--source", &source, "--agent", "all", "--json",
    ]));
    let asked: Vec<(String, String)> = survey["result"]["candidates"]
        .as_array()
        .unwrap()
        .iter()
        .map(|c| {
            (
                c["agent"].as_str().unwrap().to_string(),
                c["component_id"].as_str().unwrap().to_string(),
            )
        })
        .collect();
    assert!(
        asked.contains(&("claude-code".into(), "capso.mcp.linear".into())),
        "the person would never have been asked: {asked:?}"
    );
    assert!(
        survey["result"]["skipped"].as_array().unwrap().is_empty(),
        "nothing has been decided yet"
    );

    // 2. They answer "leave mine" for Claude Code, and say nothing about Codex.
    Machine::ok(skip_cmd(&m, "capso.mcp.linear", Some("claude-code")));

    // 3. The install proceeds.
    Machine::ok(m.install(&[]));
    let claude: Value =
        serde_json::from_str(&std::fs::read_to_string(m.claude.join(".claude.json")).unwrap())
            .unwrap();
    assert!(
        claude["mcpServers"]["capso-linear"].is_null(),
        "the declined server was installed into Claude Code anyway"
    );
    assert!(
        !claude["mcpServers"]["capso-rackspace-spot"].is_null(),
        "declining one server stopped another from being installed"
    );
    let codex = std::fs::read_to_string(m.codex.join("config.toml")).unwrap();
    assert!(
        codex.contains("capso-linear"),
        "Codex was never asked about, so it should have been installed: {codex}"
    );

    // 4. Asked again? No: the decision is carried in the survey.
    let again = Machine::ok(m.run(&[
        "mcp", "survey", "--source", &source, "--agent", "all", "--json",
    ]));
    let decided: Vec<String> = again["result"]["skipped"]
        .as_array()
        .unwrap()
        .iter()
        .map(|s| s["agent_id"].as_str().unwrap().to_string())
        .collect();
    assert_eq!(decided, vec!["claude-code"], "{again}");
}

/// Nobody answering is not a decision. The install completes and the report still carries the
/// warning, so the person can decide later.
#[test]
fn nobody_answering_installs_everything_and_keeps_the_warning() {
    let m = machine_already_reaching_linear();
    let out = Machine::ok(m.install(&[]));
    let warnings = out["warnings"].to_string();
    assert!(
        warnings.contains("MCP-ALREADY-CONNECTED"),
        "the warning a person decides from is missing: {warnings}"
    );
    let claude: Value =
        serde_json::from_str(&std::fs::read_to_string(m.claude.join(".claude.json")).unwrap())
            .unwrap();
    assert!(
        !claude["mcpServers"]["capso-linear"].is_null(),
        "an unanswered question skipped the install"
    );
    assert!(
        skipped_components(&m).is_empty(),
        "a decision was recorded on somebody's behalf"
    );
}
