//! The derived half of `/deploy-summary`: what a change is, and whether it is on staging.
//!
//! The reader is a **stakeholder**, not an operator — somebody who wants to know whether the
//! thing they asked for is done and where to look at it. So this derives the change and its
//! deployment state, and deliberately does not derive image digests, replica counts or restart
//! histories. Those make the on-call document, which is a useful artifact and the wrong one
//! here; an earlier version of this crate produced it by mistake.
//!
//! The one piece of engineering rigour the node keeps is the question the reader is actually
//! asking:
//!
//! > **A merged pull request is not a running change.** Whether it is live is answered against
//! > the environment, never against the merge or a green pipeline — from
//! > `2026-06-17-shipped-not-live.md`, where every defect passed merge-green and failed at
//! > *does it actually work*.
//!
//! Hence three states, never inferred into one another: on staging, merged but not there yet,
//! or unknown because the environment could not be read. The third must never render as either
//! of the first two — an unreadable environment produces no evidence of the change, and no
//! evidence reads exactly like "not deployed".

use serde::{Deserialize, Serialize};
use std::path::Path;
use std::time::Duration;
use wf_core::{Error, Result};

const PROBE: Duration = Duration::from_secs(30);

/// One merged change, as a stakeholder brief needs it.
#[derive(Debug, Clone, Serialize)]
pub struct Change {
    pub number: u32,
    pub title: String,
    pub author: String,
    pub url: String,
    pub merged_at: String,
    /// The commit the merge produced — the identity looked for in the environment.
    pub merge_commit: String,
    pub tickets: Vec<String>,
    pub files_changed: usize,
    pub additions: u32,
    pub deletions: u32,
    /// The author's own description, so the brief can be written from what they said rather
    /// than reverse-engineered from a diff.
    pub body: String,
}

/// Whether the change is actually running.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
#[serde(tag = "state", rename_all = "kebab-case")]
pub enum Deployment {
    /// Found running, with the evidence that says so.
    OnStaging { evidence: String },
    /// The environment was read, and this change is not in it.
    NotYet { checked: String },
    /// The environment could not be read. **Not** the same as not deployed.
    Unknown { why: String },
}

impl Deployment {
    /// One sentence for the page — the honest form of each state.
    pub fn sentence(&self) -> String {
        match self {
            Deployment::OnStaging { evidence } => format!("Running on staging ({evidence})."),
            Deployment::NotYet { checked } => format!(
                "Merged, but not yet running on staging — {checked} was read and does not \
                 carry it."
            ),
            Deployment::Unknown { why } => format!(
                "Merged. Whether it is running on staging is UNKNOWN — the environment could \
                 not be read ({why}). That is not the same as 'not deployed'."
            ),
        }
    }

    pub fn is_known(&self) -> bool {
        !matches!(self, Deployment::Unknown { .. })
    }
}

/// Everything the brief is written from.
#[derive(Debug, Clone, Serialize)]
pub struct Brief {
    pub changes: Vec<Change>,
    pub environment: String,
    pub deployment: Deployment,
    /// Carried onto the page: a reader who does not know what went unexamined assumes all of
    /// it was examined.
    pub unchecked: Vec<String>,
}

impl Brief {
    /// Every ticket across the changes, deduplicated — what the Linear write records against.
    pub fn tickets(&self) -> Vec<String> {
        let mut t: Vec<String> = self
            .changes
            .iter()
            .flat_map(|c| c.tickets.iter().cloned())
            .collect();
        t.sort();
        t.dedup();
        t
    }
}

/// Ticket ids named in text. Bare ids only — a *verb* in front of an id is what moves a ticket
/// here, so anything reconstructing ids for display must not reconstruct the verb.
pub fn tickets_in(text: &str) -> Vec<String> {
    wf_release_notes::tickets_in(text)
}

/// Does a running image reference carry this commit?
///
/// The link between a merge and a running container is the **image tag**, where the convention
/// is to tag with the commit. A product that does not tag that way makes the link invisible
/// here, which is why the brief always names what it read rather than asserting a negative on
/// its own authority.
pub fn image_carries_commit(image: &str, commit: &str) -> bool {
    // Seven hex characters is the shortest abbreviation git itself will print. Anything
    // shorter is not distinctive enough to assert a match on.
    if commit.len() < 7 || image.is_empty() {
        return false;
    }
    let image = image.to_ascii_lowercase();
    let commit = commit.to_ascii_lowercase();
    [commit.len(), 12, 10, 8, 7]
        .into_iter()
        .filter(|len| *len <= commit.len())
        .any(|len| image.contains(&commit[..len]))
}

/// Read the pull requests from GitHub.
pub fn changes(root: &Path, prs: &[u32]) -> Result<Vec<Change>> {
    let mut out = Vec::new();
    for n in prs {
        let raw = gh(
            root,
            &[
                "pr",
                "view",
                &n.to_string(),
                "--json",
                "number,title,author,url,mergedAt,mergeCommit,body,files,additions,deletions",
            ],
        )?;
        out.push(parse_pr(&raw, *n)?);
    }
    Ok(out)
}

/// Turn one `gh pr view --json …` response into a [`Change`].
///
/// Separated from the call so both refusals — unparseable, and not merged — are testable
/// without a network round trip.
pub fn parse_pr(raw: &str, number: u32) -> Result<Change> {
    let v: PrJson = serde_json::from_str(raw).map_err(|e| {
        Error::failure(
            "DEPLOY-SUMMARY-PR-UNPARSEABLE",
            format!("gh returned something unexpected for #{number}: {e}"),
        )
    })?;
    let (Some(merged_at), Some(merge_commit)) = (v.merged_at, v.merge_commit) else {
        return Err(Error::usage(
            "DEPLOY-SUMMARY-NOT-MERGED",
            format!("#{number} is not merged — a deploy summary describes a change that shipped"),
        )
        .with_zh("该 PR 尚未合并，无法生成部署摘要。"));
    };
    Ok(Change {
        number: v.number,
        tickets: tickets_in(&format!("{}\n{}", v.title, v.body)),
        title: v.title,
        author: v.author.unwrap_or_default().login,
        url: v.url,
        merged_at,
        merge_commit: merge_commit.oid,
        files_changed: v.files.len(),
        additions: v.additions,
        deletions: v.deletions,
        body: v.body,
    })
}

/// Ask the environment whether these changes are running.
///
/// Every failure to read produces [`Deployment::Unknown`], never `NotYet`. That is the whole
/// discipline: a failed read returns no matching image, and no matching image is exactly what a
/// genuinely undeployed change returns.
pub fn deployment(root: &Path, context: &str, namespace: &str, changes: &[Change]) -> Deployment {
    let raw = match kubectl(root, context, namespace) {
        Ok(r) => r,
        Err(e) => {
            return Deployment::Unknown {
                why: e
                    .message
                    .lines()
                    .next()
                    .unwrap_or("read failed")
                    .to_string(),
            }
        }
    };
    let images = match parse_images(&raw) {
        Ok(i) => i,
        Err(e) => return Deployment::Unknown { why: e.message },
    };
    for c in changes {
        for img in &images {
            if image_carries_commit(img, &c.merge_commit) {
                return Deployment::OnStaging {
                    evidence: format!("#{} is in the running image {img}", c.number),
                };
            }
        }
    }
    Deployment::NotYet {
        checked: format!("{context}/{namespace} ({} running image(s))", images.len()),
    }
}

const REC: char = '\x1e';
const SUB: char = '\x1f';
const IMAGE_PATH: &str = "{range .items[*]}{range .status.containerStatuses[*]}{.image}{\"\\x1f\"}{.imageID}{\"\\x1e\"}{end}{end}";

/// Every image reference running in the namespace.
///
/// A projection rather than `-o json`: on a real cluster the full object list was 625 KiB —
/// mostly `managedFields` this never reads — against a shared 256 KiB capture cap, so the read
/// came back a truncated document. The same fields projected are 8.6 KiB.
pub fn parse_images(raw: &str) -> Result<Vec<String>> {
    let trimmed = raw.trim_end_matches(['\n', '\r']);
    if !trimmed.is_empty() && !trimmed.ends_with(REC) {
        // A truncated read yields fewer images, and fewer images is precisely how a shipped
        // change comes to look unshipped.
        return Err(Error::failure(
            "DEPLOY-SUMMARY-TRUNCATED",
            format!(
                "the environment read was cut off mid-record ({} bytes) — a partial read would \
                 report a shipped change as missing",
                raw.len()
            ),
        )
        .with_zh("集群数据读取被截断，结果不可信。"));
    }
    Ok(trimmed
        .split(REC)
        .flat_map(|rec| rec.split(SUB))
        .map(str::trim)
        .filter(|s| !s.is_empty())
        .map(str::to_string)
        .collect())
}

fn kubectl(root: &Path, context: &str, namespace: &str) -> Result<String> {
    let output = format!("-o=jsonpath={IMAGE_PATH}");
    let mut args = vec!["--context", context, "get", "pods"];
    if namespace == "*" {
        args.push("-A");
    } else {
        args.extend(["-n", namespace]);
    }
    args.extend([output.as_str(), "--request-timeout=25s"]);
    match wf_core::proc::run_in("kubectl", &args, &[], Some(root), PROBE) {
        Ok(o) if o.ok() => Ok(o.stdout),
        Ok(o) => Err(Error::failure(
            "DEPLOY-SUMMARY-UNREACHABLE",
            o.stderr
                .lines()
                .next()
                .unwrap_or("kubectl reported no error output")
                .trim()
                .to_string(),
        )),
        Err(e) => Err(Error::failure(
            "DEPLOY-SUMMARY-NO-KUBECTL",
            format!("kubectl could not be run: {e}"),
        )),
    }
}

fn gh(root: &Path, args: &[&str]) -> Result<String> {
    match wf_core::proc::run_in("gh", args, &[], Some(root), PROBE) {
        Ok(o) if o.ok() => Ok(o.stdout),
        Ok(o) => Err(Error::failure(
            "DEPLOY-SUMMARY-GH",
            o.stderr
                .lines()
                .next()
                .unwrap_or("gh reported no error output")
                .trim()
                .to_string(),
        )
        .with_zh("无法读取 GitHub，请检查 gh 是否已登录。")),
        Err(e) => Err(Error::failure(
            "DEPLOY-SUMMARY-NO-GH",
            format!("gh could not be run: {e}"),
        )),
    }
}

#[derive(Deserialize)]
struct PrJson {
    number: u32,
    #[serde(default)]
    title: String,
    #[serde(default)]
    author: Option<Author>,
    #[serde(default)]
    url: String,
    // `null` on an open pull request. `#[serde(default)]` does not cover an explicit null for
    // a struct, so an open PR failed as an unparseable response instead of reaching the clear
    // "not merged" refusal below.
    #[serde(rename = "mergedAt", default)]
    merged_at: Option<String>,
    #[serde(rename = "mergeCommit", default)]
    merge_commit: Option<Oid>,
    #[serde(default)]
    body: String,
    #[serde(default)]
    files: Vec<serde_json::Value>,
    #[serde(default)]
    additions: u32,
    #[serde(default)]
    deletions: u32,
}
#[derive(Deserialize, Default)]
struct Author {
    #[serde(default)]
    login: String,
}
#[derive(Deserialize, Default)]
struct Oid {
    #[serde(default)]
    oid: String,
}

#[cfg(test)]
mod tests {
    use super::*;

    fn change(number: u32, tickets: &[&str]) -> Change {
        Change {
            number,
            title: "t".into(),
            author: "a".into(),
            url: "u".into(),
            merged_at: "2026-09-07T00:00:00Z".into(),
            merge_commit: "86ba507a08e8f1c2d3e4f5a6b7c8d9e0a1b2c3d4".into(),
            tickets: tickets.iter().map(|t| t.to_string()).collect(),
            files_changed: 1,
            additions: 1,
            deletions: 0,
            body: String::new(),
        }
    }

    const SHA: &str = "86ba507a08e8f1c2d3e4f5a6b7c8d9e0a1b2c3d4";

    #[test]
    fn an_image_tagged_with_the_commit_is_recognised() {
        for img in [
            "registry/app:86ba507a08e8f1c2d3e4f5a6b7c8d9e0a1b2c3d4",
            "registry/app:86ba507a08e8",
            "registry/app:sha-86ba507",
            "registry/app:v2-86ba507a",
            "registry/app@sha256:x",
        ]
        .iter()
        .take(4)
        {
            assert!(image_carries_commit(img, SHA), "missed {img}");
        }
    }

    #[test]
    fn an_unrelated_image_is_not_a_match() {
        // The positive control's other half: a matcher that says yes to everything would pass
        // the test above and be useless.
        for img in [
            "registry/app:v1.2.3",
            "registry/app:latest",
            "registry/app:aaaaaaa",
            "",
        ] {
            assert!(!image_carries_commit(img, SHA), "false match on {img}");
        }
    }

    #[test]
    fn a_commit_too_short_to_be_distinctive_never_matches() {
        // Seven hex characters is the shortest git itself prints; below that a "match" is
        // coincidence, and a coincidence here tells a stakeholder their change is live.
        assert!(!image_carries_commit("registry/app:abc", "abc"));
        assert!(!image_carries_commit("registry/app:ab", "ab"));
    }

    #[test]
    fn an_open_pull_request_is_refused_clearly_not_as_a_parse_error() {
        // `gh` returns `null` for mergedAt and mergeCommit on an open PR, and `#[serde(default)]`
        // does not cover an explicit null for a struct — so this first surfaced as
        // "gh returned something unexpected", exit 1, which tells the caller nothing about what
        // is actually wrong.
        let open = r#"{"number":23,"title":"t","author":{"login":"a"},"url":"u",
                       "mergedAt":null,"mergeCommit":null,"body":"","files":[],
                       "additions":0,"deletions":0}"#;
        let err = parse_pr(open, 23).unwrap_err();
        assert_eq!(err.kind, "DEPLOY-SUMMARY-NOT-MERGED");
        assert_eq!(err.code, wf_core::ExitCode::Usage);
    }

    #[test]
    fn a_merged_pull_request_parses_with_its_tickets() {
        // The positive control: the refusal above must not be firing on everything.
        let merged = r#"{"number":20,"title":"feat: port the loop","author":{"login":"connorwang"},
                         "url":"https://example/20","mergedAt":"2026-09-07T12:39:35Z",
                         "mergeCommit":{"oid":"86ba507a08e8f1c2d3e4f5a6b7c8d9e0a1b2c3d4"},
                         "body":"Fixes TXE-1783","files":[{},{}],"additions":5,"deletions":1}"#;
        let c = parse_pr(merged, 20).unwrap();
        assert_eq!(c.number, 20);
        assert_eq!(c.author, "connorwang");
        assert_eq!(c.tickets, vec!["TXE-1783".to_string()]);
        assert_eq!(c.files_changed, 2);
        assert!(c.merge_commit.starts_with("86ba507"));
    }

    #[test]
    fn an_unreadable_environment_is_unknown_and_not_undeployed() {
        // The load-bearing distinction of the whole node. A failed read finds no matching
        // image, and no matching image is exactly what a genuinely undeployed change looks
        // like — so the difference has to be carried explicitly, in words, onto the page.
        let u = Deployment::Unknown {
            why: "EOF from the API server".into(),
        };
        assert!(!u.is_known());
        assert!(u.sentence().contains("UNKNOWN"));
        assert!(
            u.sentence().contains("not the same as 'not deployed'"),
            "the page must say so outright rather than leave it to the reader"
        );
    }

    #[test]
    fn the_three_states_read_differently() {
        let on = Deployment::OnStaging {
            evidence: "#20 is in the running image registry/app:86ba507".into(),
        };
        let not = Deployment::NotYet {
            checked: "ctx/ns (4 running image(s))".into(),
        };
        assert!(on.is_known() && not.is_known());
        assert!(on.sentence().starts_with("Running on staging"));
        assert!(not.sentence().contains("not yet running"));
        assert_ne!(on.sentence(), not.sentence());
    }

    #[test]
    fn a_truncated_environment_read_is_an_error_not_a_missing_change() {
        let cut = "registry/app:abc\x1fregistry/app@sha256:d\x1eregistry/other";
        let err = parse_images(cut).unwrap_err();
        assert_eq!(err.kind, "DEPLOY-SUMMARY-TRUNCATED");
        // Positive control: the same data, whole, parses into all three.
        let whole = format!("{cut}:v1\x1e");
        assert_eq!(parse_images(&whole).unwrap().len(), 3);
    }

    #[test]
    fn an_empty_environment_read_is_not_a_truncated_one() {
        assert!(parse_images("").unwrap().is_empty());
    }

    #[test]
    fn tickets_are_collected_across_changes_and_deduplicated() {
        let brief = Brief {
            changes: vec![change(1, &["TXE-2", "TXE-1"]), change(2, &["TXE-1"])],
            environment: "ctx/ns".into(),
            deployment: Deployment::NotYet {
                checked: "ctx/ns".into(),
            },
            unchecked: vec![],
        };
        assert_eq!(brief.tickets(), vec!["TXE-1".to_string(), "TXE-2".into()]);
    }
}
