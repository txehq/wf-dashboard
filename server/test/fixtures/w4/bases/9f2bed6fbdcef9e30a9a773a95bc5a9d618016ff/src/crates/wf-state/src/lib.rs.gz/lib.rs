//! The local record: what is installed, what was changed, and how to put it back.
//!
//! Everything `wf` does to a machine passes through this crate, and the reason is one
//! sentence: every organization resource is mandatory, so `wf` will eventually overwrite
//! something a person wrote by hand. An overwrite with a receipt and a backup is a
//! maintenance tool. An overwrite without one is a tool people uninstall.

pub mod backup;
pub mod db;
pub mod schema_v2;
pub mod tx;

pub use db::{
    ComponentState, Db, DriftKind, Generation, GenerationStatus, Installation, NativeObject,
    NativeReceipt, OwnershipReceipt,
};
pub use schema_v2::{
    AgentRegistration, GroupCount, KnownSkill, ManagedResource, SessionSummaryRow, SkippedMcp,
    TeamRepoState, UsageEventRow, UsageGroup, UsageQuery,
};
pub use tx::{Transaction, TxOutcome};
