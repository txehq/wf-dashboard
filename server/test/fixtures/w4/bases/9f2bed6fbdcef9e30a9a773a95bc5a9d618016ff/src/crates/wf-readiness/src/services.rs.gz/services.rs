use crate::requirements::ServiceReq;
use crate::{Finding, Requirements, Resolver, Severity, Tier};
use std::{
    collections::BTreeMap,
    net::{SocketAddr, TcpStream},
    path::Path,
    time::Duration,
};

/// A service is ready when the work can use it. One Compose publishes on this machine is
/// probed at its host address; one it publishes nowhere is reachable only on the compose
/// network, so its container must be running and, when it declares a healthcheck, healthy.
pub(crate) fn check(root: &Path, req: &Requirements, resolver: &Resolver) -> Vec<Finding> {
    if req.services.is_empty() {
        return vec![];
    }
    let mut findings = Vec::new();
    resolver.spawns.set(resolver.spawns.get() + 1);
    let docker = resolver.resolve_session("docker");
    let daemon = !docker.is_empty()
        && wf_core::proc::run_in(
            &docker,
            &["info", "--format", "{{.ServerVersion}}"],
            &[],
            Some(root),
            Duration::from_secs(3),
        )
        .is_ok_and(|o| o.ok());
    if !daemon {
        findings.push(Finding {
            code: "DOCKER-DOWN".into(),
            subject: "docker".into(),
            severity: Severity::Fail,
            detail: "Docker daemon is not reachable.".into(),
            fix: if cfg!(target_os = "macos") {
                "open -a Docker"
            } else {
                "sudo -n systemctl start docker"
            }
            .into(),
            tier: Some(Tier::Reversible),
            zh: String::new(),
        });
    }
    let mut files = BTreeMap::<&str, Vec<&ServiceReq>>::new();
    for service in &req.services {
        files.entry(&service.from).or_default().push(service);
    }
    for (file, services) in files {
        resolver.spawns.set(resolver.spawns.get() + 1);
        let model = if docker.is_empty() {
            Err("docker is not installed".to_string())
        } else {
            crate::compose::model(&docker, root, file)
        };
        let model = match model {
            Ok(model) => model,
            Err(why) => {
                let dir = Path::new(file)
                    .parent()
                    .map(|d| d.to_string_lossy().into_owned())
                    .filter(|d| !d.is_empty())
                    .unwrap_or_else(|| ".".into());
                findings.extend(services.iter().map(|service| Finding {
                    code: "SVC-CONFIG".into(),
                    subject: service.name.clone(),
                    severity: Severity::Fail,
                    detail: format!("docker compose cannot load {file}: {why}"),
                    fix: format!("set the variables {file} requires, e.g. in {dir}/.env"),
                    tier: Some(Tier::Manual),
                    zh: format!(
                        "docker compose 读不了 {file}：{why}。把它需要的变量设置好（例如写在 {dir}/.env 里），再运行一次。"
                    ),
                }));
                continue;
            }
        };
        for service in services {
            let definition = &model["services"][service.name.as_str()];
            let down = match crate::compose::published(definition) {
                Some((host, port)) => {
                    let address = SocketAddr::from((host, port));
                    TcpStream::connect_timeout(&address, Duration::from_millis(400))
                        .is_err()
                        .then(|| format!("{} is not reachable at {address}.", service.name))
                }
                None if !daemon => Some(format!(
                    "{} publishes no host port, and its container cannot be read while Docker is down.",
                    service.name
                )),
                None => {
                    resolver.spawns.set(resolver.spawns.get() + 1);
                    container_down(&docker, root, file, &service.name)
                }
            };
            if let Some(detail) = down {
                findings.push(Finding {
                    code: "SVC-DOWN".into(),
                    subject: service.name.clone(),
                    severity: Severity::Fail,
                    detail,
                    fix: format!(
                        "docker compose -f '{}' up -d --wait '{}'",
                        service.from.replace('\'', "'\\''"),
                        service.name.replace('\'', "'\\''")
                    ),
                    tier: Some(Tier::Reversible),
                    zh: String::new(),
                });
            }
        }
    }
    findings
}

/// Why a service reachable only on the compose network is not usable, or `None` when its
/// container runs and any healthcheck it declares passes.
fn container_down(docker: &str, root: &Path, file: &str, name: &str) -> Option<String> {
    let rows = match crate::compose::containers(docker, root, file, name) {
        Ok(rows) => rows,
        Err(why) => return Some(format!("docker compose cannot list {name}: {why}")),
    };
    let usable = |row: &serde_json::Value| {
        row["State"] == "running" && matches!(row["Health"].as_str().unwrap_or(""), "" | "healthy")
    };
    if rows.iter().any(usable) {
        return None;
    }
    let states: Vec<String> = rows
        .iter()
        .map(|row| {
            let state = row["State"].as_str().unwrap_or("unknown");
            match row["Health"].as_str().unwrap_or("") {
                "" => state.to_string(),
                health => format!("{state}, {health}"),
            }
        })
        .collect();
    Some(if states.is_empty() {
        format!("{name} publishes no host port and has no container.")
    } else {
        format!(
            "{name} publishes no host port and its container is {}.",
            states.join("; ")
        )
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A compose project in a disposable directory, taken down with everything it started.
    struct Project {
        dir: tempfile::TempDir,
    }

    impl Project {
        fn new(files: &[(&str, &str)]) -> Self {
            let dir = tempfile::tempdir().unwrap();
            for (path, text) in files {
                std::fs::write(dir.path().join(path), text).unwrap();
            }
            Self { dir }
        }

        fn root(&self) -> &Path {
            self.dir.path()
        }

        fn req(&self, name: &str) -> Requirements {
            Requirements {
                services: vec![ServiceReq {
                    name: name.into(),
                    from: "compose.yaml".into(),
                }],
                ..Default::default()
            }
        }

        fn check(&self, name: &str) -> Vec<Finding> {
            check(self.root(), &self.req(name), &Resolver::new())
                .into_iter()
                .filter(|f| f.subject == name)
                .collect()
        }
    }

    impl Drop for Project {
        fn drop(&mut self) {
            let out = std::process::Command::new("docker")
                .args([
                    "compose",
                    "-f",
                    "compose.yaml",
                    "down",
                    "--volumes",
                    "--timeout",
                    "0",
                ])
                .current_dir(self.dir.path())
                .output()
                .unwrap();
            assert!(
                out.status.success(),
                "{}",
                String::from_utf8_lossy(&out.stderr)
            );
        }
    }

    // These run real Compose projects, so they run where Docker is: Linux CI and any
    // developer machine with it. GitHub's macOS runners have none; `--ignored` runs them on a
    // Mac that does.
    #[test]
    #[cfg_attr(target_os = "macos", ignore = "needs a Docker daemon")]
    fn a_published_port_is_probed_where_compose_interpolates_it() {
        let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        let port = listener.local_addr().unwrap().port();
        let project = Project::new(&[(
            "compose.yaml",
            &format!(
                "services:\n  db:\n    image: alpine:latest\n    ports: ['${{WF_FIXTURE_UNSET_HOST:-127.0.0.1}}:${{WF_FIXTURE_UNSET_PORT:-{port}}}:5432']\n"
            ),
        )]);
        assert!(project.check("db").is_empty(), "{:?}", project.check("db"));
        drop(listener);
        let down = project.check("db");
        assert_eq!(down[0].code, "SVC-DOWN");
        assert!(
            down[0].detail.contains(&format!("127.0.0.1:{port}")),
            "{}",
            down[0].detail
        );
    }

    #[test]
    #[cfg_attr(target_os = "macos", ignore = "needs a Docker daemon")]
    fn a_required_variable_compose_cannot_resolve_is_named_until_the_env_file_sets_it() {
        let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        let port = listener.local_addr().unwrap().port();
        let project = Project::new(&[(
            "compose.yaml",
            &format!(
                "services:\n  db:\n    image: alpine:latest\n    environment:\n      - PASSWORD=${{WF_FIXTURE_PASSWORD:?WF_FIXTURE_PASSWORD is required}}\n    ports: ['127.0.0.1:{port}:5432']\n"
            ),
        )]);
        let found = project.check("db");
        assert_eq!(found[0].code, "SVC-CONFIG", "{found:?}");
        assert!(
            found[0].detail.contains("WF_FIXTURE_PASSWORD is required"),
            "{}",
            found[0].detail
        );
        assert_eq!(
            found[0].fix,
            "set the variables compose.yaml requires, e.g. in ./.env"
        );
        std::fs::write(project.root().join(".env"), "WF_FIXTURE_PASSWORD=fixture\n").unwrap();
        assert!(project.check("db").is_empty(), "{:?}", project.check("db"));
    }

    #[test]
    #[cfg_attr(target_os = "macos", ignore = "needs a Docker daemon")]
    fn a_service_without_a_host_port_is_its_running_healthy_container() {
        // sub2api's postgres shape: no `ports`, a healthcheck, reachable only in the network.
        let project = Project::new(&[(
            "compose.yaml",
            "services:\n  worker:\n    image: alpine:latest\n    command: ['sleep', '600']\n    healthcheck:\n      test: ['CMD', 'true']\n      interval: 1s\n      start_period: 0s\n",
        )]);
        let down = project.check("worker");
        assert_eq!(down.len(), 1, "{down:?}");
        assert_eq!(down[0].code, "SVC-DOWN");
        assert!(
            down[0].detail.contains("has no container"),
            "{}",
            down[0].detail
        );
        assert_eq!(
            down[0].fix,
            "docker compose -f 'compose.yaml' up -d --wait 'worker'"
        );

        // The reversible tier runs the fix itself, and `--wait` returns once it is healthy.
        let req = project.req("worker");
        let (_, changed) = crate::repair::apply(project.root(), &req, &down, false);
        assert!(changed, "the repair did not start the service");
        assert!(
            project.check("worker").is_empty(),
            "{:?}",
            project.check("worker")
        );

        let stop = std::process::Command::new("docker")
            .args([
                "compose",
                "-f",
                "compose.yaml",
                "stop",
                "--timeout",
                "0",
                "worker",
            ])
            .current_dir(project.root())
            .output()
            .unwrap();
        assert!(stop.status.success());
        let stopped = project.check("worker");
        assert!(
            stopped[0].detail.contains("exited"),
            "{}",
            stopped[0].detail
        );
    }
}
