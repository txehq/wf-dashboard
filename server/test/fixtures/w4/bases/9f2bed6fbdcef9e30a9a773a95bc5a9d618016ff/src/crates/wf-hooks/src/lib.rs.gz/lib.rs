//! The hook side: the policy the fixed dispatcher reads, and the shape of what it emits.
//!
//! The dispatcher's argv is frozen because Codex binds trust to it. Everything a release
//! wants to vary is here, in a file inside the already-verified bundle.

use serde::{Deserialize, Serialize};
use std::path::Path;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Policy {
    pub schema_version: u32,
    pub budgets: Budgets,
    pub context: ContextPolicy,
    #[serde(default)]
    pub repair: RepairPolicy,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct Budgets {
    pub fast_path_p95_ms: u64,
    pub remote_wait_ms: u64,
    pub remote_check_interval_s: i64,
    pub stale_warn_after_days: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ContextPolicy {
    pub include: Vec<String>,
    pub max_bytes: usize,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct RepairPolicy {
    #[serde(default)]
    pub inline: Vec<String>,
    #[serde(default)]
    pub deferred: Vec<String>,
}

impl Default for Policy {
    /// The values a machine uses when it has no verified bundle yet — a first run, or a
    /// machine whose generations are all unusable. They are the same numbers the shipped
    /// policy carries, so a first session behaves like every later one.
    fn default() -> Self {
        Self {
            schema_version: 1,
            budgets: Budgets {
                fast_path_p95_ms: 100,
                remote_wait_ms: 2000,
                remote_check_interval_s: 900,
                stale_warn_after_days: 7,
            },
            context: ContextPolicy {
                include: vec![
                    "active_version".into(),
                    "desired_version".into(),
                    "reload_required".into(),
                    "credential_missing".into(),
                    "stale_age".into(),
                    "repair_command".into(),
                ],
                max_bytes: 2048,
            },
            repair: RepairPolicy {
                inline: vec!["prompt-block".into()],
                deferred: vec![
                    "skill".into(),
                    "mcp".into(),
                    "hook-policy".into(),
                    "readiness-profile".into(),
                ],
            },
        }
    }
}

impl Policy {
    /// Load the policy from a generation, falling back to the defaults.
    ///
    /// A malformed policy inside a verified bundle is a contradiction — the bundle's digest
    /// matched — so the fallback here is for the case that actually happens: no generation
    /// yet. Either way a session start must not fail because a YAML file is unhappy.
    pub fn load(bundle_dir: &Path) -> Self {
        let p = bundle_dir.join("workflow/hooks/policies/session-start.yaml");
        std::fs::read_to_string(p)
            .ok()
            .and_then(|s| serde_yaml_ng::from_str(&s).ok())
            .unwrap_or_default()
    }
}

/// What a SessionStart hook returns. Claude and Codex read different fields; both read
/// `additionalContext`, so one struct serves both and each gets the extras it understands.
#[derive(Debug, Clone, Serialize)]
pub struct HookOutput {
    #[serde(rename = "hookSpecificOutput")]
    pub hook_specific_output: HookSpecific,
    /// Claude only. Set only when a skill file this process directly wrote is already in
    /// place — claiming a reload that has not happened is worse than not asking for one.
    #[serde(rename = "reloadSkills", skip_serializing_if = "Option::is_none")]
    pub reload_skills: Option<bool>,
}

#[derive(Debug, Clone, Serialize)]
pub struct HookSpecific {
    #[serde(rename = "hookEventName")]
    pub hook_event_name: String,
    #[serde(rename = "additionalContext")]
    pub additional_context: String,
}

impl HookOutput {
    pub fn new(context: String, reload_skills: Option<bool>) -> Self {
        Self {
            hook_specific_output: HookSpecific {
                hook_event_name: "SessionStart".into(),
                additional_context: context,
            },
            reload_skills,
        }
    }

    pub fn render(&self) -> String {
        // Redacted on the way out: this string goes into a model's context.
        wf_core::redact::redact(&serde_json::to_string(self).unwrap_or_default())
    }
}

/// Trim the context to the policy's byte budget on a line boundary, so a truncated message
/// is still a whole sentence.
pub fn fit(lines: &[String], max_bytes: usize) -> String {
    let mut out = String::new();
    for l in lines {
        if out.len() + l.len() + 1 > max_bytes {
            break;
        }
        if !out.is_empty() {
            out.push('\n');
        }
        out.push_str(l);
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_shipped_policy_parses() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
        let p: Policy = serde_yaml_ng::from_str(
            &std::fs::read_to_string(root.join("workflow/hooks/policies/session-start.yaml"))
                .unwrap(),
        )
        .expect("the shipped policy parses");
        assert_eq!(p.budgets.fast_path_p95_ms, 100);
        assert_eq!(p.budgets.remote_wait_ms, 2000);
        assert_eq!(p.budgets.remote_check_interval_s, 900);
    }

    #[test]
    fn a_missing_policy_falls_back_rather_than_failing_a_session() {
        let d = tempfile::tempdir().unwrap();
        let p = Policy::load(d.path());
        assert_eq!(p.budgets.remote_check_interval_s, 900);
    }

    #[test]
    fn context_is_trimmed_on_a_line_boundary() {
        let lines = vec!["a".repeat(30), "b".repeat(30), "c".repeat(30)];
        let out = fit(&lines, 70);
        assert!(out.len() <= 70);
        assert!(
            !out.contains('c'),
            "a partial line is not a sentence: {out}"
        );
        assert_eq!(out.lines().count(), 2);
    }

    #[test]
    fn hook_output_redacts_before_it_reaches_a_model() {
        let o = HookOutput::new("token gho_AAAAAAAABBBBBBBBCCCCCCCC leaked".into(), None);
        let s = o.render();
        assert!(!s.contains("gho_AAAA"), "{s}");
    }

    #[test]
    fn reload_skills_is_absent_unless_asked_for() {
        let s = HookOutput::new("hi".into(), None).render();
        assert!(!s.contains("reloadSkills"), "{s}");
        let s = HookOutput::new("hi".into(), Some(true)).render();
        assert!(s.contains("\"reloadSkills\":true"), "{s}");
    }
}
