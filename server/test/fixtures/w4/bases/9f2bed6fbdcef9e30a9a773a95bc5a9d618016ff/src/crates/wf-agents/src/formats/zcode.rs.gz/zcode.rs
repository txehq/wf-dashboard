//! ZCode: hooks live under `hooks.events` in its shared `cli/config.json`, as process
//! handlers with an argv — no shell between ZCode and `wf` at all.
//!
//! `hooks.enabled` is the person's switch and stays theirs: it governs their handlers as
//! much as `wf`'s, and one `wf` turned on would leave a dormant handler of theirs running
//! every turn. `wf` reports it instead ([`super::HOOKS_DISABLED`]).

use super::{json_doc, owned_identity, HookEntry, HookEvent, HookFormatAdapter};
use serde_json::{json, Value};
use std::path::Path;
use wf_core::{Error, Result};

pub struct ZcodeHooks;

fn shape(path: &Path) -> Error {
    Error::conflict(
        "HOOKS-SHAPE",
        format!("{} has an unexpected hooks shape", path.display()),
    )
}

fn handler_identity(event: HookEvent, handler: &Value) -> Option<String> {
    if handler["type"] != "process" {
        return None;
    }
    let mut argv = vec![handler["command"].as_str()?.to_string()];
    argv.extend(
        handler["args"]
            .as_array()?
            .iter()
            .map(|a| a.as_str().map(String::from))
            .collect::<Option<Vec<_>>>()?,
    );
    owned_identity(event, Some(&argv), None)
}

/// Each handler of ours in a group, as the group [`HookFormatAdapter::render_hook`] writes for
/// it. Ownership is per handler: a person may add their own handler to a group `wf` wrote, and
/// that handler stays theirs.
fn owned_handlers(event: HookEvent, group: &Value) -> Vec<(String, Value)> {
    let Some(handlers) = group["hooks"].as_array() else {
        return vec![];
    };
    handlers
        .iter()
        .filter_map(|h| {
            let id = handler_identity(event, h)?;
            let mut alone = serde_json::Map::new();
            alone.insert("hooks".into(), json!([h]));
            if let Some(m) = group.get("matcher") {
                alone.insert("matcher".into(), m.clone());
            }
            Some((id, Value::Object(alone)))
        })
        .collect()
}

/// Take the handler with `identity` out of every group, dropping a group only when that left
/// it empty. Returns the position of the first group it was taken from.
fn take_handler(event: HookEvent, list: &mut Vec<Value>, identity: &str) -> Option<usize> {
    let mut position = None;
    let mut kept = Vec::with_capacity(list.len());
    for mut group in std::mem::take(list) {
        let handlers = group["hooks"].as_array_mut().expect("checked by groups()");
        let before = handlers.len();
        handlers.retain(|h| handler_identity(event, h).as_deref() != Some(identity));
        let removed = handlers.len() != before;
        if removed && position.is_none() {
            position = Some(kept.len());
        }
        if !(removed && handlers.is_empty()) {
            kept.push(group);
        }
    }
    *list = kept;
    position
}

/// `hooks.events.<key>`, checked, creating the path when `create`.
fn groups<'a>(doc: &'a mut Value, key: &str, path: &Path) -> Result<&'a mut Vec<Value>> {
    let hooks = doc
        .as_object_mut()
        .ok_or_else(|| shape(path))?
        .entry("hooks")
        .or_insert_with(|| json!({}))
        .as_object_mut()
        .ok_or_else(|| shape(path))?;
    let list = hooks
        .entry("events")
        .or_insert_with(|| json!({}))
        .as_object_mut()
        .ok_or_else(|| shape(path))?
        .entry(key.to_string())
        .or_insert_with(|| json!([]))
        .as_array_mut()
        .ok_or_else(|| shape(path))?;
    if list.iter().any(|g| !g["hooks"].is_array()) {
        return Err(shape(path));
    }
    Ok(list)
}

impl HookFormatAdapter for ZcodeHooks {
    fn supports(&self, event: HookEvent) -> bool {
        matches!(
            event,
            HookEvent::SessionStart
                | HookEvent::Stop
                | HookEvent::PostToolUse
                | HookEvent::UserPromptSubmit
        )
    }
    fn dormant(&self, text: &str) -> Option<String> {
        if serde_json::from_str::<Value>(text).ok()?["hooks"]["enabled"] == true {
            return None;
        }
        Some(
            "ZCode runs config-file hooks only when hooks.enabled is true; \
             set it to run what wf installed"
                .into(),
        )
    }
    fn render_hook(&self, entry: &HookEntry) -> Value {
        let mut handler = serde_json::Map::new();
        handler.insert("type".into(), "process".into());
        handler.insert("command".into(), entry.argv[0].clone().into());
        handler.insert("args".into(), entry.argv[1..].to_vec().into());
        if let Some(t) = entry.timeout_secs {
            handler.insert("timeoutMs".into(), (t * 1000).into());
        }
        let mut group = serde_json::Map::new();
        group.insert("hooks".into(), json!([handler]));
        if let Some(m) = &entry.matcher {
            group.insert("matcher".into(), m.clone().into());
        }
        Value::Object(group)
    }
    fn parse_hooks(&self, text: &str, path: &Path) -> Result<Vec<(String, Value)>> {
        let doc = json_doc::parse_object(text, path)?;
        let Some(events) = doc["hooks"].get("events") else {
            return Ok(vec![]);
        };
        let events = events.as_object().ok_or_else(|| shape(path))?;
        let mut out = Vec::new();
        for (key, list) in events {
            let Some(event) = HookEvent::parse(key) else {
                continue;
            };
            for g in list.as_array().ok_or_else(|| shape(path))? {
                out.extend(owned_handlers(event, g));
            }
        }
        Ok(out)
    }
    fn upsert(&self, text: &str, entry: &HookEntry, path: &Path) -> Result<String> {
        let mut doc = json_doc::parse_object(text, path)?;
        let identity = entry.identity();
        let wanted = self.render_hook(entry);
        let list = groups(&mut doc, entry.event.as_str(), path)?;
        let at = take_handler(entry.event, list, &identity).unwrap_or(list.len());
        list.insert(at.min(list.len()), wanted);
        json_doc::render_if_changed(text, &doc, path)
    }
    fn remove(&self, text: &str, identity: &str, path: &Path) -> Result<String> {
        let Some(event) = identity
            .split_once('/')
            .and_then(|(e, _)| HookEvent::parse(e))
        else {
            return Ok(text.to_string());
        };
        let mut doc = json_doc::parse_object(text, path)?;
        if doc["hooks"]["events"].get(event.as_str()).is_none() {
            return Ok(text.to_string());
        }
        let list = groups(&mut doc, event.as_str(), path)?;
        if take_handler(event, list, identity).is_some() && list.is_empty() {
            doc["hooks"]["events"]
                .as_object_mut()
                .expect("checked above")
                .shift_remove(event.as_str());
        }
        json_doc::render_if_changed(text, &doc, path)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn p() -> &'static Path {
        Path::new("/home/a/.zcode/cli/config.json")
    }

    fn usage(event: HookEvent) -> HookEntry {
        HookEntry {
            event,
            matcher: Some("Skill".into()),
            argv: [
                "/x/wf",
                "hook",
                "dispatch",
                "--event",
                event.as_str(),
                "--agent",
                "zcode",
            ]
            .map(String::from)
            .to_vec(),
            timeout_secs: Some(10),
        }
    }

    /// ZCode leaves config-file hooks off unless `hooks.enabled` says otherwise, so `wf` turns
    /// them on where nobody has decided — and keeps a person's explicit `false`, which also
    /// governs their own hooks.
    #[test]
    fn hooks_are_switched_on_only_where_nobody_switched_them_off() {
        let off = r#"{"hooks": {"enabled": false, "events": {}}}"#;
        let text = ZcodeHooks
            .upsert(off, &usage(HookEvent::Stop), p())
            .unwrap();
        let doc: Value = serde_json::from_str(&text).unwrap();
        assert_eq!(doc["hooks"]["enabled"], false);
        assert!(doc["hooks"]["events"]["Stop"].is_array());
    }

    /// A handler a person adds to a group `wf` wrote is theirs: an update keeps it, and so does
    /// removal.
    #[test]
    fn a_persons_handler_in_a_group_wf_wrote_survives_update_and_removal() {
        let ours = ZcodeHooks
            .upsert("{}", &usage(HookEvent::Stop), p())
            .unwrap();
        let mut doc: Value = serde_json::from_str(&ours).unwrap();
        doc["hooks"]["events"]["Stop"][0]["hooks"]
            .as_array_mut()
            .unwrap()
            .push(json!({"type": "process", "command": "notify-send", "args": ["done"]}));
        let shared = serde_json::to_string_pretty(&doc).unwrap();
        let parsed = ZcodeHooks.parse_hooks(&shared, p()).unwrap();
        assert_eq!(parsed.len(), 1);
        assert_eq!(
            parsed[0].1,
            ZcodeHooks.render_hook(&usage(HookEvent::Stop)),
            "ours is intact, so it reads as in place"
        );
        let mut changed = usage(HookEvent::Stop);
        changed.timeout_secs = Some(20);
        let updated = ZcodeHooks.upsert(&shared, &changed, p()).unwrap();
        assert!(updated.contains("notify-send"), "{updated}");
        assert!(updated.contains("20000"), "{updated}");
        assert_eq!(ZcodeHooks.upsert(&updated, &changed, p()).unwrap(), updated);
        let removed = ZcodeHooks
            .remove(&updated, "Stop/capso-wf-usage", p())
            .unwrap();
        assert!(removed.contains("notify-send"), "{removed}");
        assert!(!removed.contains("--event"), "{removed}");
    }

    #[test]
    fn handlers_are_processes_with_an_argv_and_the_switch_stays_the_persons() {
        let user = r#"{"plugins": {"official": true}, "hooks": {"events": {}}}"#;
        let text = ZcodeHooks
            .upsert(user, &usage(HookEvent::PostToolUse), p())
            .unwrap();
        let doc: Value = serde_json::from_str(&text).unwrap();
        assert_eq!(doc["plugins"]["official"], true);
        assert_eq!(doc["hooks"].get("enabled"), None);
        assert!(ZcodeHooks.dormant(&text).is_some());
        assert!(ZcodeHooks
            .dormant(r#"{"hooks": {"enabled": true}}"#)
            .is_none());
        assert_eq!(
            doc["hooks"]["events"]["PostToolUse"],
            json!([{"hooks": [{"type": "process", "command": "/x/wf", "args": ["hook", "dispatch", "--event", "PostToolUse", "--agent", "zcode"], "timeoutMs": 10000}], "matcher": "Skill"}])
        );
        assert_eq!(
            ZcodeHooks
                .upsert(&text, &usage(HookEvent::PostToolUse), p())
                .unwrap(),
            text
        );
        assert_eq!(
            ZcodeHooks.parse_hooks(&text, p()).unwrap()[0].0,
            "PostToolUse/capso-wf-usage"
        );
    }

    #[test]
    fn removal_takes_only_ours() {
        let user = r#"{"hooks": {"enabled": true, "events": {"Stop": [{"hooks": [{"type": "process", "command": "notify-send", "args": ["done"]}]}]}}}"#;
        let with = ZcodeHooks
            .upsert(user, &usage(HookEvent::Stop), p())
            .unwrap();
        let without = ZcodeHooks
            .remove(&with, "Stop/capso-wf-usage", p())
            .unwrap();
        assert_eq!(
            serde_json::from_str::<Value>(&without).unwrap(),
            serde_json::from_str::<Value>(user).unwrap()
        );
    }

    #[test]
    fn zcode_takes_the_four_events_teamai_proved() {
        for e in [
            HookEvent::SessionStart,
            HookEvent::Stop,
            HookEvent::PostToolUse,
            HookEvent::UserPromptSubmit,
        ] {
            assert!(ZcodeHooks.supports(e));
        }
        assert!(!ZcodeHooks.supports(HookEvent::SessionEnd));
    }
}
