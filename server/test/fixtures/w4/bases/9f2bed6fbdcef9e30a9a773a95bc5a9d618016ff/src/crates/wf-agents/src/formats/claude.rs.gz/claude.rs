//! Claude Code: hooks in `settings.json`, MCP servers in `.claude.json`.
//!
//! The hook document shape is shared with Codex (`hooks.<Event>[] = {matcher?, hooks: [..]}`),
//! so the document surgery lives here and [`super::codex`] adds only what Codex needs on
//! top of it: its legacy flat handler and its trust-sensitive definition.

use super::{
    json_doc, owned_identity, shell_words, Document, HookEntry, HookEvent, HookFormatAdapter,
    McpDef, McpFormatAdapter, McpTransport,
};
use serde_json::{json, Map, Value};
use std::path::Path;
use wf_core::{Error, Result};

pub struct ClaudeHooks;

/// The native handler: `{type, command, statusMessage, timeout?}`, in that key order — the
/// Codex dispatcher's trust fingerprint is these exact bytes.
pub fn handler(entry: &HookEntry) -> Value {
    let mut h = Map::new();
    h.insert("type".into(), "command".into());
    h.insert("command".into(), entry.command().into());
    h.insert("statusMessage".into(), entry.marker().into());
    if let Some(t) = entry.timeout_secs {
        h.insert("timeout".into(), t.into());
    }
    Value::Object(h)
}

/// The handler as [`parse_grouped`] reports it: with its group's matcher folded in, so a
/// changed matcher is a changed hook.
pub(crate) fn native(entry: &HookEntry) -> Value {
    let mut value = handler(entry);
    if let Some(m) = &entry.matcher {
        value["matcher"] = m.clone().into();
    }
    value
}

fn group(entry: &HookEntry) -> Value {
    let mut g = Map::new();
    if let Some(m) = &entry.matcher {
        g.insert("matcher".into(), m.clone().into());
    }
    g.insert("hooks".into(), json!([handler(entry)]));
    Value::Object(g)
}

fn shape(path: &Path) -> Error {
    Error::conflict(
        "HOOKS-SHAPE",
        format!("{} has an unexpected hooks shape", path.display()),
    )
    .with_zh(format!(
        "{} 里的 hooks 结构不是 wf 认识的样子，wf 没有改动它。",
        path.display()
    ))
}

/// wf 1.x wrote the Codex dispatcher as a flat object straight in the event list.
fn legacy_identity(event: HookEvent, group: &Value) -> Option<String> {
    let flat = group.get("hooks").is_none()
        && (group["description"] == super::MARKER_BOOTSTRAP
            || group["statusMessage"] == super::MARKER_BOOTSTRAP);
    flat.then(|| format!("{}/{}", event.as_str(), super::MARKER_BOOTSTRAP))
}

fn handler_identity(event: HookEvent, handler: &Value) -> Option<String> {
    let argv = handler["command"].as_str().and_then(shell_words);
    owned_identity(event, argv.as_deref(), handler["statusMessage"].as_str())
}

/// The event list under `key`, checked to be groups of handlers.
fn checked_groups<'a>(
    hooks: &'a mut Map<String, Value>,
    key: &str,
    path: &Path,
    legacy: bool,
) -> Result<&'a mut Vec<Value>> {
    let event = HookEvent::parse(key);
    let groups = hooks
        .entry(key.to_string())
        .or_insert_with(|| json!([]))
        .as_array_mut()
        .ok_or_else(|| shape(path))?;
    for g in groups.iter() {
        let legacy_flat = legacy && event.is_some_and(|e| legacy_identity(e, g).is_some());
        if !legacy_flat && !g.get("hooks").is_some_and(Value::is_array) {
            return Err(shape(path));
        }
    }
    Ok(groups)
}

fn hooks_object<'a>(doc: &'a mut Value, path: &Path) -> Result<&'a mut Map<String, Value>> {
    doc.as_object_mut()
        .ok_or_else(|| shape(path))?
        .entry("hooks")
        .or_insert_with(|| json!({}))
        .as_object_mut()
        .ok_or_else(|| shape(path))
}

/// Upsert into a Claude-shaped hook document. `legacy` also treats a flat handler object
/// directly in the event list as ours (the shape wf 1.x wrote into Codex).
pub(crate) fn upsert_grouped(
    text: &str,
    entry: &HookEntry,
    path: &Path,
    legacy: bool,
) -> Result<String> {
    let mut doc = json_doc::parse_object(text, path)?;
    let identity = entry.identity();
    let wanted = group(entry);
    let key = entry.event.as_str();
    let groups = checked_groups(hooks_object(&mut doc, path)?, key, path, legacy)?;
    let mut placed = false;
    let mut i = 0;
    while i < groups.len() {
        if legacy && legacy_identity(entry.event, &groups[i]).as_deref() == Some(&identity) {
            if placed {
                groups.remove(i);
            } else {
                groups[i] = wanted.clone();
                placed = true;
                i += 1;
            }
            continue;
        }
        // `checked_groups` lets a legacy flat group through, and one whose identity is not
        // the one being upserted arrives here: a conflict to report, not a panic.
        let Some(handlers) = groups[i].get_mut("hooks").and_then(Value::as_array_mut) else {
            return Err(shape(path));
        };
        let ours: Vec<usize> = handlers
            .iter()
            .enumerate()
            .filter(|(_, h)| handler_identity(entry.event, h).as_deref() == Some(&identity))
            .map(|(j, _)| j)
            .collect();
        if ours.is_empty() {
            i += 1;
        } else if ours.len() == handlers.len() && !placed {
            groups[i] = wanted.clone();
            placed = true;
            i += 1;
        } else {
            for j in ours.into_iter().rev() {
                handlers.remove(j);
            }
            if handlers.is_empty() {
                groups.remove(i);
            } else {
                i += 1;
            }
        }
    }
    if !placed {
        groups.push(wanted);
    }
    json_doc::render_if_changed(text, &doc, path)
}

pub(crate) fn remove_grouped(
    text: &str,
    identity: &str,
    path: &Path,
    legacy: bool,
) -> Result<String> {
    let Some(event) = identity
        .split_once('/')
        .and_then(|(e, _)| HookEvent::parse(e))
    else {
        return Ok(text.to_string());
    };
    let mut doc = json_doc::parse_object(text, path)?;
    if doc.get("hooks").is_none() {
        return Ok(text.to_string());
    }
    let hooks = hooks_object(&mut doc, path)?;
    let keys: Vec<String> = hooks
        .keys()
        .filter(|k| HookEvent::parse(k) == Some(event))
        .cloned()
        .collect();
    let mut emptied = false;
    for key in keys {
        let groups = checked_groups(hooks, &key, path, legacy)?;
        let mut removed = false;
        groups.retain_mut(|g| {
            if legacy && legacy_identity(event, g).as_deref() == Some(identity) {
                removed = true;
                return false;
            }
            let Some(handlers) = g.get_mut("hooks").and_then(Value::as_array_mut) else {
                return true;
            };
            let before = handlers.len();
            handlers.retain(|h| handler_identity(event, h).as_deref() != Some(identity));
            if handlers.len() == before {
                return true;
            }
            removed = true;
            !handlers.is_empty()
        });
        if removed && groups.is_empty() {
            hooks.shift_remove(&key);
            emptied = hooks.is_empty();
        }
    }
    if emptied {
        // The `hooks` object was ours to create; an empty one says nothing a person wrote.
        doc.as_object_mut()
            .expect("parsed object")
            .shift_remove("hooks");
    }
    json_doc::render_if_changed(text, &doc, path)
}

pub(crate) fn parse_grouped(text: &str, path: &Path, legacy: bool) -> Result<Vec<(String, Value)>> {
    let mut doc = json_doc::parse_object(text, path)?;
    if doc.get("hooks").is_none() {
        return Ok(vec![]);
    }
    let hooks = hooks_object(&mut doc, path)?;
    let keys: Vec<String> = hooks.keys().cloned().collect();
    let mut out = Vec::new();
    for key in keys {
        let Some(event) = HookEvent::parse(&key) else {
            continue;
        };
        for g in checked_groups(hooks, &key, path, legacy)?.iter() {
            if legacy {
                if let Some(id) = legacy_identity(event, g) {
                    out.push((id, g.clone()));
                    continue;
                }
            }
            for h in g["hooks"].as_array().into_iter().flatten() {
                if let Some(id) = handler_identity(event, h) {
                    let mut native = h.clone();
                    if let Some(m) = g.get("matcher") {
                        native["matcher"] = m.clone();
                    }
                    out.push((id, native));
                }
            }
        }
    }
    Ok(out)
}

impl HookFormatAdapter for ClaudeHooks {
    fn supports(&self, _event: HookEvent) -> bool {
        true
    }
    fn marks_handlers(&self) -> bool {
        true
    }
    fn render_hook(&self, entry: &HookEntry) -> Value {
        native(entry)
    }
    fn parse_hooks(&self, text: &str, path: &Path) -> Result<Vec<(String, Value)>> {
        parse_grouped(text, path, false)
    }
    fn upsert(&self, text: &str, entry: &HookEntry, path: &Path) -> Result<String> {
        upsert_grouped(text, entry, path, false)
    }
    fn remove(&self, text: &str, identity: &str, path: &Path) -> Result<String> {
        remove_grouped(text, identity, path, false)
    }
}

pub struct ClaudeMcp;

impl McpFormatAdapter for ClaudeMcp {
    fn document(&self) -> Document {
        Document::Json
    }
    fn keys(&self, name: &str) -> Vec<String> {
        vec!["mcpServers".into(), name.into()]
    }
    fn render_server(&self, def: &McpDef) -> Result<Option<Value>> {
        let mut s = Map::new();
        match def.transport {
            McpTransport::Stdio => {
                s.insert("type".into(), "stdio".into());
                s.insert("command".into(), def.command.clone().into());
                s.insert("args".into(), def.args.clone().into());
                let env = super::stdio_env(def, |k| format!("${{{k}}}"));
                if !env.is_empty() {
                    s.insert("env".into(), Value::Object(env));
                }
            }
            McpTransport::Http | McpTransport::Sse => {
                let kind = if def.transport == McpTransport::Http {
                    "http"
                } else {
                    "sse"
                };
                s.insert("type".into(), kind.into());
                s.insert("url".into(), def.url.clone().into());
                if !def.headers.is_empty() {
                    s.insert("headers".into(), json!(def.headers));
                }
            }
        }
        Ok(Some(Value::Object(s)))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn p() -> &'static Path {
        Path::new("/home/a/.claude/settings.json")
    }

    fn entry(event: HookEvent, words: &[&str]) -> HookEntry {
        HookEntry {
            event,
            matcher: None,
            argv: words.iter().map(|w| w.to_string()).collect(),
            timeout_secs: None,
        }
    }

    fn bootstrap() -> HookEntry {
        entry(
            HookEvent::SessionStart,
            &[
                "/home/a/.local/bin/wf",
                "hook",
                "session-start",
                "--agent",
                "claude",
            ],
        )
    }

    fn usage(event: HookEvent) -> HookEntry {
        HookEntry {
            timeout_secs: Some(10),
            ..entry(
                event,
                &[
                    "/home/a/.local/bin/wf",
                    "hook",
                    "dispatch",
                    "--event",
                    event.as_str(),
                    "--agent",
                    "claude",
                ],
            )
        }
    }

    const USER: &str = r#"{
  "theme": "dark",
  "hooks": {
    "SessionStart": [
      {"matcher": "startup", "hooks": [{"type": "command", "command": "echo mine"}]}
    ],
    "Stop": [
      {"hooks": [{"type": "command", "command": "say done"}]}
    ]
  }
}"#;

    #[test]
    fn the_handler_is_the_exact_shape_codex_trust_is_bound_to() {
        assert_eq!(
            serde_json::to_string(&handler(&bootstrap())).unwrap(),
            r#"{"type":"command","command":"/home/a/.local/bin/wf hook session-start --agent claude","statusMessage":"capso-wf-bootstrap"}"#
        );
        assert_eq!(handler(&usage(HookEvent::Stop))["timeout"], 10);
    }

    #[test]
    fn upserting_adds_one_group_and_leaves_every_user_handler_alone() {
        let once = ClaudeHooks.upsert(USER, &bootstrap(), p()).unwrap();
        let doc: Value = serde_json::from_str(&once).unwrap();
        assert_eq!(doc["theme"], "dark");
        let groups = doc["hooks"]["SessionStart"].as_array().unwrap();
        assert_eq!(groups.len(), 2);
        assert_eq!(groups[0]["hooks"][0]["command"], "echo mine");
        assert_eq!(groups[1], json!({"hooks": [handler(&bootstrap())]}));
        // Idempotent to the byte.
        assert_eq!(ClaudeHooks.upsert(&once, &bootstrap(), p()).unwrap(), once);
        // And the user's Stop hook is still there after ours joins it.
        let both = ClaudeHooks
            .upsert(&once, &usage(HookEvent::Stop), p())
            .unwrap();
        let doc: Value = serde_json::from_str(&both).unwrap();
        assert_eq!(doc["hooks"]["Stop"][0]["hooks"][0]["command"], "say done");
        assert_eq!(
            doc["hooks"]["Stop"][1]["hooks"][0]["statusMessage"],
            "capso-wf-usage"
        );
    }

    #[test]
    fn a_changed_definition_replaces_ours_in_place() {
        let once = ClaudeHooks
            .upsert("", &usage(HookEvent::PostToolUse), p())
            .unwrap();
        let mut moved = usage(HookEvent::PostToolUse);
        moved.argv[0] = "/opt/wf/bin/wf".into();
        let twice = ClaudeHooks.upsert(&once, &moved, p()).unwrap();
        let doc: Value = serde_json::from_str(&twice).unwrap();
        let groups = doc["hooks"]["PostToolUse"].as_array().unwrap();
        assert_eq!(groups.len(), 1, "replaced, not duplicated: {twice}");
        assert!(groups[0]["hooks"][0]["command"]
            .as_str()
            .unwrap()
            .starts_with("/opt/wf/bin/wf "));
    }

    #[test]
    fn a_matcher_is_part_of_the_group() {
        let mut e = usage(HookEvent::PostToolUse);
        e.matcher = Some("Skill".into());
        let text = ClaudeHooks.upsert("", &e, p()).unwrap();
        let doc: Value = serde_json::from_str(&text).unwrap();
        assert_eq!(doc["hooks"]["PostToolUse"][0]["matcher"], "Skill");
    }

    #[test]
    fn removing_ours_gives_the_user_document_back() {
        let with = ClaudeHooks.upsert(USER, &bootstrap(), p()).unwrap();
        let with = ClaudeHooks
            .upsert(&with, &usage(HookEvent::PostToolUse), p())
            .unwrap();
        let without = ClaudeHooks
            .remove(&with, "SessionStart/capso-wf-bootstrap", p())
            .unwrap();
        let without = ClaudeHooks
            .remove(&without, "PostToolUse/capso-wf-usage", p())
            .unwrap();
        assert_eq!(
            serde_json::from_str::<Value>(&without).unwrap(),
            serde_json::from_str::<Value>(USER).unwrap()
        );
        // Removing what is not there is not a change.
        assert_eq!(
            ClaudeHooks
                .remove(USER, "Stop/capso-wf-usage", p())
                .unwrap(),
            USER
        );
    }

    #[test]
    fn a_handler_sharing_a_group_with_a_user_handler_leaves_the_user_handler() {
        let shared = json!({"hooks": {"Stop": [{"hooks": [
            {"type": "command", "command": "say done"},
            handler(&usage(HookEvent::Stop)),
        ]}]}})
        .to_string();
        let text = ClaudeHooks
            .remove(&shared, "Stop/capso-wf-usage", p())
            .unwrap();
        let doc: Value = serde_json::from_str(&text).unwrap();
        assert_eq!(
            doc["hooks"]["Stop"],
            json!([{"hooks": [{"type": "command", "command": "say done"}]}])
        );
    }

    #[test]
    fn ours_are_found_by_marker_or_by_command_and_nothing_else_is() {
        let with = ClaudeHooks.upsert(USER, &bootstrap(), p()).unwrap();
        let with = ClaudeHooks
            .upsert(&with, &usage(HookEvent::Stop), p())
            .unwrap();
        let mut found: Vec<String> = ClaudeHooks
            .parse_hooks(&with, p())
            .unwrap()
            .into_iter()
            .map(|(id, _)| id)
            .collect();
        found.sort();
        assert_eq!(
            found,
            ["SessionStart/capso-wf-bootstrap", "Stop/capso-wf-usage"]
        );
        // wf 1.x wrote the plugin dispatcher with a bare `wf` and the same marker.
        let legacy = json!({"hooks": {"SessionStart": [{"hooks": [
            {"type": "command", "command": "wf hook session-start --agent claude", "statusMessage": "capso-wf-bootstrap"}
        ]}]}})
        .to_string();
        assert_eq!(ClaudeHooks.parse_hooks(&legacy, p()).unwrap().len(), 1);
    }

    #[test]
    fn a_document_that_is_not_hooks_shaped_is_refused_not_rewritten() {
        for bad in [
            "{broken",
            "[]",
            r#"{"hooks": []}"#,
            r#"{"hooks": {"Stop": "no"}}"#,
            r#"{"hooks": {"Stop": [{"hooks": "no"}]}}"#,
        ] {
            let err = ClaudeHooks
                .upsert(bad, &usage(HookEvent::Stop), p())
                .unwrap_err();
            assert_eq!(err.code, wf_core::ExitCode::Conflict, "{bad}");
        }
    }

    #[test]
    fn claude_takes_every_canonical_event() {
        for e in HookEvent::ALL {
            assert!(ClaudeHooks.supports(e));
        }
    }

    fn linear() -> McpDef {
        McpDef {
            schema_version: 1,
            name: "capso-linear".into(),
            description: String::new(),
            transport: McpTransport::Stdio,
            command: Some("npx".into()),
            args: vec![
                "-y".into(),
                "mcp-remote".into(),
                "https://mcp.linear.app/sse".into(),
            ],
            url: None,
            env_references: vec!["LINEAR_API_TOKEN".into()],
            headers: Default::default(),
            startup_timeout_sec: None,
            component: None,
        }
    }

    /// A server the registry handed on carries its component in its environment, beside
    /// the references it forwards.
    #[test]
    fn an_installed_stdio_server_carries_its_component_in_its_environment() {
        let installed = McpDef {
            component: Some("capso.mcp.linear".into()),
            ..linear()
        };
        assert_eq!(
            ClaudeMcp.render_server(&installed).unwrap().unwrap()["env"],
            json!({
                "LINEAR_API_TOKEN": "${LINEAR_API_TOKEN}",
                "WF_MCP_COMPONENT": "capso.mcp.linear"
            })
        );
    }

    /// Claude Code has one startup limit for every server, `MCP_TIMEOUT` in its environment,
    /// and no key for it in a server's entry: the entry is the same with a limit or without.
    #[test]
    fn a_startup_limit_has_no_key_in_a_claude_entry() {
        let slow = McpDef {
            startup_timeout_sec: Some(120),
            ..linear()
        };
        assert_eq!(
            ClaudeMcp.render_server(&slow).unwrap(),
            ClaudeMcp.render_server(&linear()).unwrap()
        );
    }

    #[test]
    fn mcp_servers_render_with_a_type_and_references_the_agent_expands() {
        assert_eq!(
            ClaudeMcp.render_server(&linear()).unwrap(),
            Some(json!({
                "type": "stdio",
                "command": "npx",
                "args": ["-y", "mcp-remote", "https://mcp.linear.app/sse"],
                "env": {"LINEAR_API_TOKEN": "${LINEAR_API_TOKEN}"}
            }))
        );
        let http = McpDef {
            transport: McpTransport::Http,
            command: None,
            args: vec![],
            url: Some("https://mcp.linear.app/mcp".into()),
            env_references: vec![],
            headers: [(
                "Authorization".to_string(),
                "Bearer ${LINEAR_API_TOKEN}".to_string(),
            )]
            .into(),
            ..linear()
        };
        assert_eq!(
            ClaudeMcp.render_server(&http).unwrap(),
            Some(json!({
                "type": "http",
                "url": "https://mcp.linear.app/mcp",
                "headers": {"Authorization": "Bearer ${LINEAR_API_TOKEN}"}
            }))
        );
        let bare = McpDef {
            env_references: vec![],
            args: vec![],
            ..linear()
        };
        assert_eq!(
            ClaudeMcp.render_server(&bare).unwrap(),
            Some(json!({"type": "stdio", "command": "npx", "args": []}))
        );
        assert_eq!(ClaudeMcp.keys("x"), ["mcpServers", "x"]);
    }
}
