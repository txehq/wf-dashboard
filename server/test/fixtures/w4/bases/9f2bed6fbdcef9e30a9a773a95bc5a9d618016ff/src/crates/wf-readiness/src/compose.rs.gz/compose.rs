//! What a compose file means, as Docker Compose itself reads it.
//!
//! The YAML is never read here: interpolation (`${VAR:-default}`, `${VAR:?message}`, the
//! project's `.env`), `extends`, `include` and profiles are all part of the format, and only
//! Compose applies them the way `docker compose up` will. Every question goes to
//! `docker compose -f <file> … --format json`, run in the repository root so a relative file
//! resolves the way the printed fix command does.

use std::collections::BTreeSet;
use std::path::Path;
use std::time::Duration;
use wf_core::{Error, Result};

const TIMEOUT: Duration = Duration::from_secs(30);

fn compose(docker: &str, root: &Path, file: &str, args: &[&str]) -> Result<wf_core::proc::Output> {
    // Every profile is active, so a service behind one is still a service; `up` enables a
    // service's profile on its own when the service is named.
    let mut argv = vec!["compose", "-f", file, "--profile", "*"];
    argv.extend_from_slice(args);
    wf_core::proc::run_in(docker, &argv, &[], Some(root), TIMEOUT)
}

/// The services `file` defines, without interpolation: which names are services does not
/// depend on a variable, and a variable nobody has set yet must not hide the answer.
pub(crate) fn service_names(root: &Path, file: &str) -> Result<BTreeSet<String>> {
    let out = compose(
        "docker",
        root,
        file,
        &["config", "--no-interpolate", "--format", "json"],
    )
    .map_err(|e| {
        Error::usage(
            "READINESS-SERVICE",
            format!("reading {file} needs docker compose: {}", e.message),
        )
        .with_zh(format!(
            "读取 {file} 需要 docker compose，但它运行不了：{}",
            e.message
        ))
    })?;
    if !out.ok() {
        return Err(Error::usage(
            "READINESS-SERVICE",
            format!("docker compose cannot read {file}: {}", out.stderr.trim()),
        ));
    }
    let model: serde_json::Value = serde_json::from_str(&out.stdout)?;
    Ok(model["services"]
        .as_object()
        .map(|services| services.keys().cloned().collect())
        .unwrap_or_default())
}

/// The fully interpolated model, or Compose's own words for why there is none — most often
/// a required variable the project's `.env` does not set yet.
pub(crate) fn model(
    docker: &str,
    root: &Path,
    file: &str,
) -> std::result::Result<serde_json::Value, String> {
    let out =
        compose(docker, root, file, &["config", "--format", "json"]).map_err(|e| e.message)?;
    if !out.ok() {
        return Err(out.stderr.trim().to_string());
    }
    serde_json::from_str(&out.stdout).map_err(|e| e.to_string())
}

/// Where a service is published on this machine: the host address (the loopback of the same
/// address family when it is bound to every interface of it) and the first published port.
pub(crate) fn published(service: &serde_json::Value) -> Option<(std::net::IpAddr, u16)> {
    service["ports"].as_array()?.iter().find_map(|port| {
        let published = &port["published"];
        let number = published
            .as_u64()
            .map(|n| n.to_string())
            .or_else(|| published.as_str().map(str::to_string))?
            .parse::<u16>()
            .ok()
            .filter(|n| *n != 0)?;
        let host = match port["host_ip"].as_str().unwrap_or_default() {
            "" | "0.0.0.0" => std::net::IpAddr::from(std::net::Ipv4Addr::LOCALHOST),
            "::" => std::net::IpAddr::from(std::net::Ipv6Addr::LOCALHOST),
            ip => ip.parse().ok()?,
        };
        Some((host, number))
    })
}

/// The service's containers, as `docker compose ps --all` reports them.
pub(crate) fn containers(
    docker: &str,
    root: &Path,
    file: &str,
    service: &str,
) -> std::result::Result<Vec<serde_json::Value>, String> {
    let out = compose(
        docker,
        root,
        file,
        &["ps", "--all", "--format", "json", service],
    )
    .map_err(|e| e.message)?;
    if !out.ok() {
        return Err(out.stderr.trim().to_string());
    }
    // One object per line in current Compose, one array in older releases.
    let mut rows = Vec::new();
    for value in serde_json::Deserializer::from_str(&out.stdout).into_iter::<serde_json::Value>() {
        match value.map_err(|e| e.to_string())? {
            serde_json::Value::Array(items) => rows.extend(items),
            row => rows.push(row),
        }
    }
    Ok(rows
        .into_iter()
        .filter(|row| row["Service"] == service)
        .collect())
}

#[cfg(test)]
mod tests {
    use super::published;
    use serde_json::json;
    use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};

    /// The shapes `docker compose config --format json` gives a published port.
    #[test]
    fn a_wildcard_is_probed_on_the_loopback_of_its_own_family() {
        let port = |host_ip: &str| json!({"ports": [{"target": 5432, "published": "5432", "host_ip": host_ip}]});
        assert_eq!(
            published(&port("")),
            Some((IpAddr::V4(Ipv4Addr::LOCALHOST), 5432))
        );
        assert_eq!(
            published(&port("0.0.0.0")),
            Some((IpAddr::V4(Ipv4Addr::LOCALHOST), 5432))
        );
        assert_eq!(
            published(&port("::")),
            Some((IpAddr::V6(Ipv6Addr::LOCALHOST), 5432))
        );
        assert_eq!(
            published(&port("127.0.0.2")),
            Some((IpAddr::V4(Ipv4Addr::new(127, 0, 0, 2)), 5432))
        );
        assert_eq!(published(&json!({"ports": [{"target": 5432}]})), None);
    }
}
