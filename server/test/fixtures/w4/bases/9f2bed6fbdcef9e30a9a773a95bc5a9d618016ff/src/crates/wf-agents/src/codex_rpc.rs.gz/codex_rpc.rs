//! Codex's public configuration and hook-state API (`codex app-server`). No model turn is
//! created and no hook trust decision is written; Codex keeps ownership of both.

use serde_json::{json, Value};
use std::path::Path;
use wf_core::{Error, Result};

pub struct Client {
    process: wf_core::proc::JsonLineProcess,
    next_id: u64,
}

impl Client {
    pub fn connect(binary: &Path, config_root: &Path) -> Result<Self> {
        let root = config_root.to_string_lossy();
        let process = wf_core::proc::JsonLineProcess::spawn(
            &binary.to_string_lossy(),
            &["app-server"],
            &[("CODEX_HOME", root.as_ref()), ("CI", "1")],
            Path::new("/"),
            std::time::Duration::from_secs(8),
        )?;
        let mut client = Self {
            process,
            next_id: 0,
        };
        client.call(
            "initialize",
            json!({"clientInfo":{"name":"wf","version":wf_core::VERSION},"capabilities":{"experimentalApi":true}}),
        )?;
        client
            .process
            .send(&json!({"method":"initialized","params":{}}))?;
        Ok(client)
    }

    pub fn call(&mut self, method: &str, params: Value) -> Result<Value> {
        self.next_id += 1;
        let id = self.next_id;
        self.process
            .send(&json!({"id":id,"method":method,"params":params}))?;
        loop {
            let value = self.process.receive()?;
            if value["id"] != id {
                continue;
            }
            if let Some(error) = value.get("error") {
                if error["data"]["config_write_error_code"] == "configVersionConflict" {
                    return Err(Error::conflict(
                        "CODEX-CONFIG-CONFLICT",
                        "Codex configuration changed during the operation",
                    ));
                }
                return Err(Error::failure(
                    "CODEX-RPC",
                    format!("Codex rejected {method}"),
                ));
            }
            return value
                .get("result")
                .cloned()
                .ok_or_else(|| Error::failure("CODEX-RPC", "Codex returned no result"));
        }
    }

    /// Used only to put a retired plugin back when the transaction that removed it rolls back.
    pub fn set_plugin_enabled(&mut self, identity: &str, enabled: bool) -> Result<()> {
        for _ in 0..3 {
            let config = self.call("config/read", json!({"includeLayers":true}))?;
            let layer = config["layers"]
                .as_array()
                .and_then(|layers| layers.iter().find(|l| l["name"]["type"] == "user"))
                .ok_or_else(|| {
                    Error::failure(
                        "CODEX-CONFIG",
                        "Codex returned no writable user configuration layer",
                    )
                })?;
            let result = self.call(
                "config/value/write",
                json!({"keyPath":format!("plugins.{identity}.enabled"),"value":enabled,
                    "mergeStrategy":"upsert","filePath":layer["name"]["file"],"expectedVersion":layer["version"]}),
            );
            match result {
                Ok(_) => return Ok(()),
                Err(e) if e.code == wf_core::ExitCode::Conflict => continue,
                Err(e) => return Err(e),
            }
        }
        Err(Error::conflict(
            "CODEX-CONFIG-CONFLICT",
            "Codex configuration keeps changing; retry the operation",
        ))
    }
}

/// Codex's own verdict on the dispatcher `handler` in `hooks_path`, or `None` when Codex is
/// not reachable or does not report exactly one matching handler.
pub fn hook_trusted(
    binary: &Path,
    config_root: &Path,
    handler: &Value,
    hooks_path: &Path,
) -> Option<bool> {
    let mut client = Client::connect(binary, config_root).ok()?;
    let result = client.call("hooks/list", json!({"cwds":["/"]})).ok()?;
    crate::formats::codex::trust_for_handler(&result, handler, hooks_path)
}
