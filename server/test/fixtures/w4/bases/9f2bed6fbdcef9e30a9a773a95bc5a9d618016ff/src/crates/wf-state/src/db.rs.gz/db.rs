use rusqlite::{params, Connection, OptionalExtension};
use serde::{Deserialize, Serialize};
use std::path::Path;
use wf_core::{Error, Result};

/// The state a component can be in. Exactly one at a time, and each names a different
/// action — these are not severity levels, they are answers to "what do I do now".
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ComponentState {
    /// Hash, configuration and enablement all match the active release.
    Current,
    /// Verified and on disk, not yet activated.
    Staged,
    /// A newer release exists; this session has not switched to it.
    UpdatePending,
    /// The files are new; the running session loaded the old ones.
    ReloadRequired,
    /// The definition is right; the credential it references has no value.
    /// A degraded capability, never a reason to fail a session start.
    CredentialMissing,
    /// Installed, and whether it can authenticate was not observed here.
    ///
    /// The shape this exists for is `credentials.mode: agent-oauth`: the server logs in
    /// through a browser and holds the token itself, so there is no reference to read and no
    /// credential store this may open. Until 1.7.1 that was reported as `current`, which read
    /// as "in place and fine" for a component nobody had checked — on the machine that found
    /// it, every Linear server was unusable and the doctor said `current` (txe-workflow#40).
    /// Healthy, like `credential_missing`: not knowing is not a reason to fail a session.
    Unverified,
    /// The organization's object was modified, deleted or disabled.
    Drifted,
    /// An unmanaged object of the same name was backed up and replaced.
    ConflictReplaced,
    /// Past the remote-check freshness window, still inside the last-known-good window.
    Stale,
    /// No usable last known good, or the active generation failed local verification.
    Blocked,
    /// This agent, platform or version is outside the release's range.
    Unsupported,
}

impl ComponentState {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Current => "current",
            Self::Staged => "staged",
            Self::UpdatePending => "update_pending",
            Self::ReloadRequired => "reload_required",
            Self::CredentialMissing => "credential_missing",
            Self::Unverified => "unverified",
            Self::Drifted => "drifted",
            Self::ConflictReplaced => "conflict_replaced",
            Self::Stale => "stale",
            Self::Blocked => "blocked",
            Self::Unsupported => "unsupported",
        }
    }
    pub fn parse(s: &str) -> Self {
        match s {
            "current" => Self::Current,
            "staged" => Self::Staged,
            "update_pending" => Self::UpdatePending,
            "reload_required" => Self::ReloadRequired,
            "credential_missing" => Self::CredentialMissing,
            "unverified" => Self::Unverified,
            "drifted" => Self::Drifted,
            "conflict_replaced" => Self::ConflictReplaced,
            "stale" => Self::Stale,
            "unsupported" => Self::Unsupported,
            _ => Self::Blocked,
        }
    }
    /// Does this state stop a session from being useful? `credential_missing` deliberately
    /// does not: a missing credential degrades one MCP server, and blocking a session over it
    /// would be a worse outcome than the missing capability. `unverified` does not either,
    /// for a stronger reason — it is not a claim that anything is wrong, only that this
    /// machine did not look.
    pub fn is_healthy(self) -> bool {
        matches!(
            self,
            Self::Current
                | Self::CredentialMissing
                | Self::Unverified
                | Self::ReloadRequired
                | Self::UpdatePending
                | Self::Staged
        )
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum GenerationStatus {
    Staged,
    Active,
    /// Superseded but verified — the fallback an offline or failed update returns to.
    LastKnownGood,
    /// Failed verification or rollback; never activated again.
    Rejected,
}

impl GenerationStatus {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Staged => "staged",
            Self::Active => "active",
            Self::LastKnownGood => "last_known_good",
            Self::Rejected => "rejected",
        }
    }
    pub fn parse(s: &str) -> Self {
        match s {
            "staged" => Self::Staged,
            "active" => Self::Active,
            "last_known_good" => Self::LastKnownGood,
            _ => Self::Rejected,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Generation {
    pub version: String,
    pub tag: String,
    pub source_commit: String,
    pub status: GenerationStatus,
    pub activated_at: Option<i64>,
    pub source: String,
    pub attested: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OwnershipReceipt {
    pub id: i64,
    pub path: String,
    /// The object inside the file we own — a managed block id, an MCP server key. Empty
    /// when we own the whole file.
    pub object_id: String,
    pub component_id: String,
    pub before_sha256: String,
    pub after_sha256: String,
    pub release_version: String,
    pub backup_id: Option<String>,
    pub at: i64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum NativeObject {
    Marketplace,
    Plugin,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NativeReceipt {
    pub agent: String,
    pub kind: NativeObject,
    pub identity: String,
    pub binary: String,
    pub config_root: String,
    pub source: String,
    pub version: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum DriftKind {
    Deleted,
    Modified,
    Disabled,
    NameConflict,
    ParseFailure,
    CredentialMissing,
}

impl DriftKind {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Deleted => "deleted",
            Self::Modified => "modified",
            Self::Disabled => "disabled",
            Self::NameConflict => "name_conflict",
            Self::ParseFailure => "parse_failure",
            Self::CredentialMissing => "credential_missing",
        }
    }
}

/// What this machine recorded at install time, so a later `wf sync` with no flags goes
/// back to where it came from rather than to the build's defaults.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Installation {
    pub channel: String,
    pub version: String,
    pub repo: String,
    pub branch: String,
    pub source: String,
}

pub struct Db {
    conn: Connection,
    _snapshot: Option<tempfile::TempDir>,
    /// Did this connection run the agent-layer migration? A read-only snapshot deliberately
    /// does not, and one taken of a database an older `wf` wrote has none of its tables.
    agents_ready: bool,
}

/// Schema version. A database from a newer `wf` is left alone rather than migrated
/// backwards — the newer binary is the one that knows how to read it.
const SCHEMA: i64 = 1;

/// The agent layer's tables are additive, so [`SCHEMA`] deliberately stays where it is and
/// an older binary can still read the file. Their own counter says whether the migration has
/// run, so its eleven DDL statements are not re-checked by every per-tool-call hook.
///
/// The counter is a level, not a flag: a database left at 2 by an earlier release takes 003
/// alone, and one at 0 takes both in order. Writing it as a single `if` worked only while
/// there was one migration to run.
pub(crate) const AGENTS_SCHEMA: i64 = 3;
const AGENTS_SCHEMA_KEY: &str = "agents_schema";

impl Db {
    pub fn open(path: &Path) -> Result<Self> {
        if let Some(p) = path.parent() {
            std::fs::create_dir_all(p)?;
        }
        let conn = Connection::open(path).map_err(sql)?;
        Self::init(conn)
    }

    pub fn open_memory() -> Result<Self> {
        Self::init(Connection::open_in_memory().map_err(sql)?)
    }

    /// Planning and source selection must not initialize or migrate persistent state.
    pub fn open_read_only(path: &Path) -> Result<Self> {
        if !path.is_file() {
            return Self::open_memory();
        }
        // SQLite may create or modify WAL/SHM files even for a read-only connection.
        // Plan against a private snapshot, including an uncheckpointed WAL, and retry
        // if a writer changed either source file while it was copied.
        for _ in 0..3 {
            let snapshot = tempfile::tempdir()?;
            let target = snapshot.path().join("state.sqlite3");
            let wal = path.with_file_name(format!(
                "{}-wal",
                path.file_name()
                    .expect("database filename")
                    .to_string_lossy()
            ));
            let stamp = |p: &Path| {
                std::fs::metadata(p)
                    .ok()
                    .map(|m| (m.len(), m.modified().ok()))
            };
            let before = (stamp(path), stamp(&wal));
            std::fs::copy(path, &target)?;
            if before.1.is_some() {
                std::fs::copy(&wal, target.with_file_name("state.sqlite3-wal"))?;
            }
            if before != (stamp(path), stamp(&wal)) {
                continue;
            }
            let conn =
                Connection::open_with_flags(&target, rusqlite::OpenFlags::SQLITE_OPEN_READ_ONLY)
                    .map_err(sql)?;
            return Ok(Self {
                conn,
                _snapshot: Some(snapshot),
                agents_ready: false,
            });
        }
        Err(Error::conflict(
            "STATE-BUSY",
            "state changed while preparing the read-only snapshot; retry the plan",
        ))
    }

    fn init(conn: Connection) -> Result<Self> {
        conn.busy_timeout(std::time::Duration::from_secs(5))
            .map_err(sql)?;
        // WAL so a reader (a session start) is never blocked by a writer (the updater).
        conn.pragma_update(None, "journal_mode", "WAL")
            .map_err(sql)?;
        conn.pragma_update(None, "synchronous", "FULL")
            .map_err(sql)?;
        conn.pragma_update(None, "foreign_keys", "ON")
            .map_err(sql)?;
        conn.execute_batch(
            r#"
            CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);

            CREATE TABLE IF NOT EXISTS installations (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                channel TEXT NOT NULL,
                version TEXT NOT NULL,
                method TEXT NOT NULL,
                platform TEXT NOT NULL,
                repo TEXT NOT NULL DEFAULT '',
                branch TEXT NOT NULL DEFAULT '',
                source TEXT NOT NULL DEFAULT '',
                first_installed_at INTEGER NOT NULL,
                last_healthy_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS agents (
                agent TEXT PRIMARY KEY,
                binary_path TEXT NOT NULL DEFAULT '',
                version TEXT NOT NULL DEFAULT '',
                config_root TEXT NOT NULL DEFAULT '',
                capabilities TEXT NOT NULL DEFAULT '{}',
                seen_at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS generations (
                version TEXT PRIMARY KEY,
                tag TEXT NOT NULL DEFAULT '',
                source_commit TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL,
                activated_at INTEGER,
                source TEXT NOT NULL DEFAULT '',
                attested INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS components (
                component_id TEXT NOT NULL,
                agent TEXT NOT NULL,
                desired_sha256 TEXT NOT NULL DEFAULT '',
                installed_sha256 TEXT NOT NULL DEFAULT '',
                state TEXT NOT NULL,
                detail TEXT NOT NULL DEFAULT '',
                updated_at INTEGER NOT NULL,
                PRIMARY KEY (component_id, agent)
            );

            CREATE TABLE IF NOT EXISTS ownership_receipts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                path TEXT NOT NULL,
                object_id TEXT NOT NULL DEFAULT '',
                component_id TEXT NOT NULL,
                before_sha256 TEXT NOT NULL DEFAULT '',
                after_sha256 TEXT NOT NULL DEFAULT '',
                release_version TEXT NOT NULL,
                backup_id TEXT,
                at INTEGER NOT NULL
            );
            CREATE INDEX IF NOT EXISTS ownership_by_path ON ownership_receipts(path);

            CREATE TABLE IF NOT EXISTS native_receipts (
                agent TEXT NOT NULL,
                config_root TEXT NOT NULL,
                kind TEXT NOT NULL,
                identity TEXT NOT NULL,
                payload TEXT NOT NULL,
                PRIMARY KEY(agent,config_root,kind,identity)
            );

            CREATE TABLE IF NOT EXISTS sync_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                trigger TEXT NOT NULL,
                phase TEXT NOT NULL,
                started_at INTEGER NOT NULL,
                ended_at INTEGER,
                result TEXT NOT NULL DEFAULT '',
                error_class TEXT NOT NULL DEFAULT '',
                changed INTEGER NOT NULL DEFAULT 0,
                duration_ms INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS drift_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                component_id TEXT NOT NULL,
                agent TEXT NOT NULL DEFAULT '',
                kind TEXT NOT NULL,
                detail TEXT NOT NULL DEFAULT '',
                repaired INTEGER NOT NULL DEFAULT 0,
                at INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS backups (
                backup_id TEXT PRIMARY KEY,
                transaction_id TEXT NOT NULL,
                original_path TEXT NOT NULL,
                backup_path TEXT NOT NULL,
                sha256 TEXT NOT NULL,
                restored_at INTEGER,
                at INTEGER NOT NULL
            );
            CREATE INDEX IF NOT EXISTS backups_by_tx ON backups(transaction_id);

            CREATE TABLE IF NOT EXISTS remote_checks (
                source TEXT PRIMARY KEY,
                last_checked INTEGER NOT NULL,
                last_success INTEGER NOT NULL DEFAULT 0,
                release_id TEXT NOT NULL DEFAULT '',
                next_due INTEGER NOT NULL,
                failures INTEGER NOT NULL DEFAULT 0
            );
            "#,
        )
        .map_err(sql)?;

        let recorded: Option<String> = conn
            .query_row(
                "SELECT value FROM meta WHERE key = ?1",
                params![AGENTS_SCHEMA_KEY],
                |r| r.get(0),
            )
            .optional()
            .map_err(sql)?;
        let agents_schema: i64 = match &recorded {
            Some(value) => value.parse().map_err(|_| {
                Error::failure(
                    "STATE-SCHEMA",
                    format!("meta.{AGENTS_SCHEMA_KEY} is {value:?}, which is not a version"),
                )
            })?,
            None => 0,
        };
        // Each level from where this database is to where this binary needs it, in order. The
        // statements are all `IF NOT EXISTS`, so a level that has already run is harmless to
        // repeat — which is what makes an interrupted upgrade safe to finish next time.
        for (level, ddl) in [
            (2, crate::schema_v2::MIGRATION_002),
            (3, crate::schema_v2::MIGRATION_003),
        ] {
            if agents_schema < level {
                conn.execute_batch(ddl).map_err(sql)?;
            }
        }
        if agents_schema < AGENTS_SCHEMA {
            conn.execute(
                "INSERT INTO meta(key, value) VALUES(?1, ?2) ON CONFLICT(key) DO UPDATE SET value = ?2",
                params![AGENTS_SCHEMA_KEY, AGENTS_SCHEMA.to_string()],
            )
            .map_err(sql)?;
        }

        let has_root:i64=conn.query_row("SELECT COUNT(*) FROM pragma_table_info('native_receipts') WHERE name='config_root'",[],|row|row.get(0)).map_err(sql)?;
        if has_root == 0 {
            conn.execute_batch("BEGIN IMMEDIATE;
                ALTER TABLE native_receipts RENAME TO native_receipts_v0;
                CREATE TABLE native_receipts(agent TEXT NOT NULL, config_root TEXT NOT NULL, kind TEXT NOT NULL, identity TEXT NOT NULL, payload TEXT NOT NULL, PRIMARY KEY(agent,config_root,kind,identity));
                INSERT INTO native_receipts SELECT agent,json_extract(payload,'$.config_root'),kind,identity,payload FROM native_receipts_v0;
                DROP TABLE native_receipts_v0; COMMIT;").map_err(sql)?;
        }
        let db = Self {
            conn,
            _snapshot: None,
            agents_ready: true,
        };
        match db.meta("schema")? {
            None => db.set_meta("schema", &SCHEMA.to_string())?,
            Some(v) => {
                let found: i64 = v.parse().unwrap_or(0);
                if found > SCHEMA {
                    return Err(Error::unsupported(
                        "STATE-SCHEMA",
                        format!(
                            "state database is schema {found}; this build understands {SCHEMA}"
                        ),
                    )
                    .with_zh("本机的记录是更新版本的 wf 写的。请先升级 wf 再运行。".to_string()));
                }
            }
        }
        Ok(db)
    }

    pub(crate) fn agents_ready(&self) -> bool {
        self.agents_ready
    }

    pub fn meta(&self, key: &str) -> Result<Option<String>> {
        self.conn
            .query_row("SELECT value FROM meta WHERE key = ?1", params![key], |r| {
                r.get(0)
            })
            .optional()
            .map_err(sql)
    }

    pub fn set_meta(&self, key: &str, value: &str) -> Result<()> {
        self.conn
            .execute(
                "INSERT INTO meta(key, value) VALUES(?1, ?2) ON CONFLICT(key) DO UPDATE SET value = ?2",
                params![key, value],
            )
            .map_err(sql)?;
        Ok(())
    }

    // --- generations ------------------------------------------------------------

    pub fn record_generation(&self, g: &Generation) -> Result<()> {
        self.conn
            .execute(
                "INSERT INTO generations(version, tag, source_commit, status, activated_at, source, attested)
                 VALUES(?1,?2,?3,?4,?5,?6,?7)
                 ON CONFLICT(version) DO UPDATE SET
                   tag=?2, source_commit=?3, status=?4, activated_at=?5, source=?6, attested=?7",
                params![
                    g.version, g.tag, g.source_commit, g.status.as_str(),
                    g.activated_at, g.source, g.attested as i64
                ],
            )
            .map_err(sql)?;
        Ok(())
    }

    /// Make one generation active. The previous active becomes the last known good, which
    /// is what an offline machine or a failed update falls back to.
    pub fn activate(&self, version: &str) -> Result<()> {
        self.conn
            .execute_batch("SAVEPOINT wf_activate")
            .map_err(sql)?;
        let result = (|| -> Result<()> {
            self.conn.execute(
            "UPDATE generations SET status='last_known_good' WHERE status='active' AND version <> ?1",
            params![version],
        )
        .map_err(sql)?;
            let updated = self
                .conn
                .execute(
                    "UPDATE generations SET status='active', activated_at=?2 WHERE version=?1",
                    params![version, wf_core::time_fmt::now_unix()],
                )
                .map_err(sql)?;
            if updated != 1 {
                return Err(Error::failure("GENERATION-MISSING", version));
            }
            Ok(())
        })();
        if result.is_err() {
            let _ = self.conn.execute_batch("ROLLBACK TO wf_activate");
        }
        self.conn
            .execute_batch("RELEASE wf_activate")
            .map_err(sql)?;
        result
    }

    pub fn active_generation(&self) -> Result<Option<Generation>> {
        self.one_generation("SELECT version,tag,source_commit,status,activated_at,source,attested FROM generations WHERE status='active' LIMIT 1")
    }

    pub fn last_known_good(&self) -> Result<Option<Generation>> {
        self.one_generation(
            "SELECT version,tag,source_commit,status,activated_at,source,attested FROM generations
             WHERE status IN ('active','last_known_good') ORDER BY activated_at DESC LIMIT 1",
        )
    }

    fn one_generation(&self, sql_text: &str) -> Result<Option<Generation>> {
        self.conn
            .query_row(sql_text, [], |r| {
                Ok(Generation {
                    version: r.get(0)?,
                    tag: r.get(1)?,
                    source_commit: r.get(2)?,
                    status: GenerationStatus::parse(&r.get::<_, String>(3)?),
                    activated_at: r.get(4)?,
                    source: wf_core::canonical_source(&r.get::<_, String>(5)?),
                    attested: r.get::<_, i64>(6)? != 0,
                })
            })
            .optional()
            .map_err(sql)
    }

    pub fn generations(&self) -> Result<Vec<Generation>> {
        let mut st = self
            .conn
            .prepare("SELECT version,tag,source_commit,status,activated_at,source,attested FROM generations ORDER BY activated_at DESC NULLS LAST, version DESC")
            .map_err(sql)?;
        let rows = st
            .query_map([], |r| {
                Ok(Generation {
                    version: r.get(0)?,
                    tag: r.get(1)?,
                    source_commit: r.get(2)?,
                    status: GenerationStatus::parse(&r.get::<_, String>(3)?),
                    activated_at: r.get(4)?,
                    source: wf_core::canonical_source(&r.get::<_, String>(5)?),
                    attested: r.get::<_, i64>(6)? != 0,
                })
            })
            .map_err(sql)?;
        rows.collect::<std::result::Result<Vec<_>, _>>()
            .map_err(sql)
    }

    // --- components -------------------------------------------------------------

    pub fn set_component(
        &self,
        component_id: &str,
        agent: &str,
        state: ComponentState,
        desired: &str,
        installed: &str,
        detail: &str,
    ) -> Result<()> {
        self.conn
            .execute(
                "INSERT INTO components(component_id, agent, desired_sha256, installed_sha256, state, detail, updated_at)
                 VALUES(?1,?2,?3,?4,?5,?6,?7)
                 ON CONFLICT(component_id, agent) DO UPDATE SET
                   desired_sha256=?3, installed_sha256=?4, state=?5, detail=?6, updated_at=?7",
                params![component_id, agent, desired, installed, state.as_str(), detail, wf_core::time_fmt::now_unix()],
            )
            .map_err(sql)?;
        Ok(())
    }

    pub fn components(&self) -> Result<Vec<(String, String, ComponentState, String)>> {
        let mut st = self
            .conn
            .prepare("SELECT component_id, agent, state, detail FROM components ORDER BY component_id, agent")
            .map_err(sql)?;
        let rows = st
            .query_map([], |r| {
                Ok((
                    r.get::<_, String>(0)?,
                    r.get::<_, String>(1)?,
                    ComponentState::parse(&r.get::<_, String>(2)?),
                    r.get::<_, String>(3)?,
                ))
            })
            .map_err(sql)?;
        rows.collect::<std::result::Result<Vec<_>, _>>()
            .map_err(sql)
    }

    /// Forget every recorded component state, leaving receipts and generations alone.
    ///
    /// The case this exists for is control passing to an *older* release. The vocabulary in
    /// [`ComponentState`] only ever grows, and `parse` turns a word it does not know into
    /// `Blocked` — a session-stopping verdict about a component that is fine. Silence is the
    /// honest thing for a binary on its way out to leave behind; the release taking over
    /// records its own states on its next sync.
    pub fn forget_components(&self) -> Result<()> {
        self.conn
            .execute("DELETE FROM components", [])
            .map_err(sql)?;
        Ok(())
    }

    /// Forget one agent's recorded states before an apply records them afresh, so a component
    /// that left the registry does not linger in `wf status`.
    pub fn forget_components_of(&self, agent: &str) -> Result<()> {
        self.conn
            .execute("DELETE FROM components WHERE agent=?1", params![agent])
            .map_err(sql)?;
        Ok(())
    }

    // --- receipts, drift, runs ---------------------------------------------------

    pub fn add_receipt(&self, r: &OwnershipReceipt) -> Result<i64> {
        self.conn
            .execute(
                "INSERT INTO ownership_receipts(path,object_id,component_id,before_sha256,after_sha256,release_version,backup_id,at)
                 VALUES(?1,?2,?3,?4,?5,?6,?7,?8)",
                params![r.path, r.object_id, r.component_id, r.before_sha256, r.after_sha256, r.release_version, r.backup_id, r.at],
            )
            .map_err(sql)?;
        Ok(self.conn.last_insert_rowid())
    }

    pub fn receipts(&self) -> Result<Vec<OwnershipReceipt>> {
        let mut st = self
            .conn
            .prepare("SELECT id,path,object_id,component_id,before_sha256,after_sha256,release_version,backup_id,at FROM ownership_receipts ORDER BY at DESC, id DESC")
            .map_err(sql)?;
        let rows = st
            .query_map([], |r| {
                Ok(OwnershipReceipt {
                    id: r.get(0)?,
                    path: r.get(1)?,
                    object_id: r.get(2)?,
                    component_id: r.get(3)?,
                    before_sha256: r.get(4)?,
                    after_sha256: r.get(5)?,
                    release_version: r.get(6)?,
                    backup_id: r.get(7)?,
                    at: r.get(8)?,
                })
            })
            .map_err(sql)?;
        rows.collect::<std::result::Result<Vec<_>, _>>()
            .map_err(sql)
    }

    /// Do we own this path? Used before an overwrite: an object we have never written is
    /// somebody else's, and gets backed up before we touch it.
    pub fn owns(&self, path: &str, object_id: &str) -> Result<bool> {
        let n: i64 = self
            .conn
            .query_row(
                "SELECT COUNT(*) FROM ownership_receipts WHERE path=?1 AND object_id=?2",
                params![path, object_id],
                |r| r.get(0),
            )
            .map_err(sql)?;
        Ok(n > 0)
    }

    pub fn native_receipts(&self) -> Result<Vec<NativeReceipt>> {
        let exists: i64 = self
            .conn
            .query_row(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='native_receipts'",
                [],
                |r| r.get(0),
            )
            .map_err(sql)?;
        if exists == 0 {
            return Ok(vec![]);
        }
        let mut statement = self
            .conn
            .prepare("SELECT payload FROM native_receipts ORDER BY agent,kind,identity")
            .map_err(sql)?;
        let rows = statement
            .query_map([], |r| r.get::<_, String>(0))
            .map_err(sql)?;
        rows.map(|row| serde_json::from_str(&row.map_err(sql)?).map_err(Error::from))
            .collect()
    }

    pub fn record_native(&self, receipt: &NativeReceipt) -> Result<()> {
        let mut receipt = receipt.clone();
        receipt.config_root = native_root(&receipt.config_root)?;
        let kind = serde_json::to_string(&receipt.kind)?;
        self.conn.execute("INSERT INTO native_receipts(agent,config_root,kind,identity,payload) VALUES(?1,?2,?3,?4,?5) ON CONFLICT(agent,config_root,kind,identity) DO UPDATE SET payload=excluded.payload",
            params![receipt.agent,receipt.config_root,kind,receipt.identity,serde_json::to_string(&receipt)?]).map_err(sql)?;
        Ok(())
    }

    /// Forget one native object: it was removed through its own manager.
    pub fn delete_native(&self, receipt: &NativeReceipt) -> Result<()> {
        let root = native_root(&receipt.config_root)?;
        let kind = serde_json::to_string(&receipt.kind)?;
        self.conn
            .execute(
                "DELETE FROM native_receipts WHERE agent=?1 AND config_root=?2 AND kind=?3 AND identity=?4",
                params![receipt.agent, root, kind, receipt.identity],
            )
            .map_err(sql)?;
        Ok(())
    }

    pub fn clear_installation(&self) -> Result<()> {
        self.conn.execute_batch("DELETE FROM installations; DELETE FROM ownership_receipts; DELETE FROM native_receipts; DELETE FROM components; DELETE FROM drift_events; DELETE FROM remote_checks; DELETE FROM meta WHERE key IN ('desired_version','last_applied_version','last_applied_binary'); DELETE FROM managed_resources; DELETE FROM agent_registry; DELETE FROM team_repo_state; DELETE FROM skipped_mcps; UPDATE generations SET status='staged' WHERE status='active';").map_err(sql)?;
        Ok(())
    }

    pub fn record_drift(
        &self,
        component_id: &str,
        agent: &str,
        kind: DriftKind,
        detail: &str,
    ) -> Result<()> {
        self.conn
            .execute(
                "INSERT INTO drift_events(component_id, agent, kind, detail, at) VALUES(?1,?2,?3,?4,?5)",
                params![component_id, agent, kind.as_str(), detail, wf_core::time_fmt::now_unix()],
            )
            .map_err(sql)?;
        Ok(())
    }

    pub fn drift_count(&self) -> Result<i64> {
        self.conn
            .query_row(
                "SELECT COUNT(*) FROM drift_events WHERE repaired = 0",
                [],
                |r| r.get(0),
            )
            .map_err(sql)
    }

    pub fn mark_drift_repaired(&self, component_id: &str) -> Result<()> {
        self.conn
            .execute(
                "UPDATE drift_events SET repaired=1 WHERE component_id=?1",
                params![component_id],
            )
            .map_err(sql)?;
        Ok(())
    }

    pub fn start_run(&self, trigger: &str) -> Result<i64> {
        self.conn
            .execute(
                "INSERT INTO sync_runs(trigger, phase, started_at) VALUES(?1,'started',?2)",
                params![trigger, wf_core::time_fmt::now_unix()],
            )
            .map_err(sql)?;
        Ok(self.conn.last_insert_rowid())
    }

    pub fn end_run(
        &self,
        id: i64,
        result: &str,
        error_class: &str,
        changed: bool,
        duration_ms: u64,
    ) -> Result<()> {
        self.conn
            .execute(
                "UPDATE sync_runs SET phase='ended', ended_at=?2, result=?3, error_class=?4, changed=?5, duration_ms=?6 WHERE id=?1",
                params![id, wf_core::time_fmt::now_unix(), result, error_class, changed as i64, duration_ms as i64],
            )
            .map_err(sql)?;
        Ok(())
    }

    // --- remote check scheduling --------------------------------------------------

    /// Is a remote check due for this source?
    ///
    /// This is the single gate that keeps twenty simultaneous session starts from making
    /// twenty API calls. It is a read of one row and nothing else, because it runs on the
    /// fast path where the budget is a hundred milliseconds for everything.
    pub fn remote_due(&self, source: &str, now: i64) -> Result<bool> {
        let claimed=self.conn.execute(
            "INSERT INTO remote_checks(source,last_checked,last_success,release_id,next_due,failures) VALUES(?1,?2,0,'',?3,0)
             ON CONFLICT(source) DO UPDATE SET next_due=?3,last_checked=?2 WHERE remote_checks.next_due<=?2",
            params![source,now,now.saturating_add(900)]).map_err(sql)?;
        Ok(claimed == 1)
    }

    pub fn note_remote_check(
        &self,
        source: &str,
        ok: bool,
        release_id: &str,
        interval_s: i64,
    ) -> Result<()> {
        let now = wf_core::time_fmt::now_unix();
        // A failure backs off, but never past four times the interval: a machine that was
        // offline for a week should still check promptly once it is back.
        let failures: i64 = self
            .conn
            .query_row(
                "SELECT failures FROM remote_checks WHERE source=?1",
                params![source],
                |r| r.get(0),
            )
            .optional()
            .map_err(sql)?
            .unwrap_or(0);
        let failures = if ok { 0 } else { (failures + 1).min(4) };
        let backoff = interval_s * (1 << failures.min(2));
        self.conn
            .execute(
                "INSERT INTO remote_checks(source, last_checked, last_success, release_id, next_due, failures)
                 VALUES(?1,?2,?3,?4,?5,?6)
                 ON CONFLICT(source) DO UPDATE SET last_checked=?2, last_success=MAX(last_success,?3), release_id=?4, next_due=?5, failures=?6",
                params![source, now, if ok { now } else { 0 }, release_id, now + backoff, failures],
            )
            .map_err(sql)?;
        Ok(())
    }

    /// Seconds since the last *successful* remote check, or None if there has never been
    /// one. This is what the staleness warning is measured against — a run of failed checks
    /// must not look like freshness.
    pub fn stale_age(&self, source: &str) -> Result<Option<i64>> {
        let last: Option<i64> = self
            .conn
            .query_row(
                "SELECT last_success FROM remote_checks WHERE source=?1",
                params![source],
                |r| r.get(0),
            )
            .optional()
            .map_err(sql)?;
        Ok(match last {
            Some(t) if t > 0 => Some(wf_core::time_fmt::now_unix() - t),
            _ => None,
        })
    }

    // --- installation -------------------------------------------------------------

    /// Record what this machine installed and where it came from.
    ///
    /// Taking the record as a value rather than as seven positional arguments is not
    /// tidiness: `source` was added after the fact, and with a positional list that is a
    /// silent shift of every argument after it.
    pub fn record_installation(
        &self,
        rec: &Installation,
        method: &str,
        platform: &str,
    ) -> Result<()> {
        let now = wf_core::time_fmt::now_unix();
        self.conn
            .execute(
                "INSERT INTO installations(id, channel, version, method, platform, repo, branch, source, first_installed_at, last_healthy_at)
                 VALUES(1,?1,?2,?3,?4,?5,?6,?7,?8,?8)
                 ON CONFLICT(id) DO UPDATE SET channel=?1, version=?2, method=?3, platform=?4, repo=?5, branch=?6, source=?7, last_healthy_at=?8",
                params![rec.channel, rec.version, method, platform, rec.repo, rec.branch, rec.source, now],
            )
            .map_err(sql)?;
        Ok(())
    }

    /// The record as this build reads it. A machine installed before the org rename
    /// (TXE-1927) holds the former owner in `repo` and `source`; it is read as the current org
    /// here, once, so the options, the hook's source-consistency check and `status` all see
    /// the same value instead of each comparing against the raw row. The row itself is
    /// rewritten by the next install that applies. Generation sources are read the same way,
    /// for the same reason: every stored source is compared against the resolved one.
    pub fn installation(&self) -> Result<Option<Installation>> {
        self.conn
            .query_row(
                "SELECT channel, version, repo, branch, source FROM installations WHERE id=1",
                [],
                |r| {
                    Ok(Installation {
                        channel: r.get(0)?,
                        version: r.get(1)?,
                        repo: wf_core::canonical_repo(&r.get::<_, String>(2)?),
                        branch: r.get(3)?,
                        source: wf_core::canonical_source(&r.get::<_, String>(4)?),
                    })
                },
            )
            .optional()
            .map_err(sql)
    }

    pub fn record_agent(
        &self,
        agent: &str,
        binary: &str,
        version: &str,
        config_root: &str,
        caps: &str,
    ) -> Result<()> {
        self.conn
            .execute(
                "INSERT INTO agents(agent, binary_path, version, config_root, capabilities, seen_at)
                 VALUES(?1,?2,?3,?4,?5,?6)
                 ON CONFLICT(agent) DO UPDATE SET binary_path=?2, version=?3, config_root=?4, capabilities=?5, seen_at=?6",
                params![agent, binary, version, config_root, caps, wf_core::time_fmt::now_unix()],
            )
            .map_err(sql)?;
        Ok(())
    }

    pub(crate) fn conn(&self) -> &Connection {
        &self.conn
    }
}

pub(crate) fn native_root(root: &str) -> Result<String> {
    let path = Path::new(root);
    let absolute = path.canonicalize().or_else(|_| std::path::absolute(path))?;
    let mut normalized = std::path::PathBuf::new();
    for component in absolute.components() {
        match component {
            std::path::Component::ParentDir => {
                normalized.pop();
            }
            std::path::Component::CurDir => {}
            component => normalized.push(component.as_os_str()),
        }
    }
    Ok(normalized.to_string_lossy().into_owned())
}

pub(crate) fn sql(e: rusqlite::Error) -> Error {
    Error::failure("STATE-SQL", e.to_string())
        .with_zh("本机的记录文件读写出错了。可以运行 `wf doctor` 看看详细情况。".to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn an_installation_recorded_before_the_org_rename_reads_as_the_current_org() {
        let db = Db::open_memory().unwrap();
        db.record_installation(
            &Installation {
                channel: "stable".into(),
                version: "1.5.2".into(),
                repo: "capsohq/txe-workflow".into(),
                branch: "main".into(),
                source: "github:capsohq/txe-workflow".into(),
            },
            "github-release",
            "aarch64-apple-darwin",
        )
        .unwrap();
        let rec = db.installation().unwrap().unwrap();
        // Both halves of the hook's source-consistency check must agree with what the
        // options resolve to, or an old machine discards every remote result it fetches.
        assert_eq!(rec.repo, wf_core::DEFAULT_REPO);
        assert_eq!(rec.source, format!("github:{}", wf_core::DEFAULT_REPO));

        // A generation staged by a pre-rename binary: staging the same version again from
        // the resolved source must not read as "a different source".
        db.record_generation(&Generation {
            version: "1.5.2".into(),
            tag: "v1.5.2".into(),
            source_commit: String::new(),
            status: GenerationStatus::Staged,
            activated_at: None,
            source: "github:capsohq/txe-workflow".into(),
            attested: true,
        })
        .unwrap();
        db.activate("1.5.2").unwrap();
        assert_eq!(db.generations().unwrap()[0].source, rec.source);
        assert_eq!(db.active_generation().unwrap().unwrap().source, rec.source);
    }

    #[test]
    fn a_due_remote_check_is_claimed_before_the_network_result_arrives() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("state.sqlite3");
        let first = Db::open(&path).unwrap();
        let second = Db::open(&path).unwrap();
        let now = wf_core::time_fmt::now_unix();
        assert!(first.remote_due("fixture", now).unwrap());
        assert!(!second.remote_due("fixture", now).unwrap());
    }

    #[test]
    fn activation_demotes_the_previous_generation_to_last_known_good() {
        let db = Db::open_memory().unwrap();
        for v in ["1.0.0", "1.1.0"] {
            db.record_generation(&Generation {
                version: v.into(),
                tag: format!("v{v}"),
                source_commit: String::new(),
                status: GenerationStatus::Staged,
                activated_at: None,
                source: "local".into(),
                attested: false,
            })
            .unwrap();
        }
        db.activate("1.0.0").unwrap();
        assert_eq!(db.active_generation().unwrap().unwrap().version, "1.0.0");
        db.activate("1.1.0").unwrap();
        assert_eq!(db.active_generation().unwrap().unwrap().version, "1.1.0");
        let gens = db.generations().unwrap();
        let old = gens.iter().find(|g| g.version == "1.0.0").unwrap();
        assert_eq!(
            old.status,
            GenerationStatus::LastKnownGood,
            "the old active is the fallback"
        );
    }

    #[test]
    fn remote_checks_are_rate_limited_and_back_off_on_failure() {
        let db = Db::open_memory().unwrap();
        let now = wf_core::time_fmt::now_unix();
        assert!(
            db.remote_due("github:x", now).unwrap(),
            "never checked means due"
        );
        db.note_remote_check("github:x", true, "v1", 900).unwrap();
        assert!(
            !db.remote_due("github:x", now).unwrap(),
            "inside the window"
        );
        assert!(
            db.remote_due("github:x", now + 901).unwrap(),
            "past the window"
        );

        db.note_remote_check("github:x", false, "", 900).unwrap();
        assert!(
            !db.remote_due("github:x", now + 901).unwrap(),
            "a failure backs off further"
        );
        // A run of failures must not look like freshness.
        assert!(db.stale_age("github:x").unwrap().is_some());
    }

    #[test]
    fn a_never_successful_source_has_no_stale_age_rather_than_a_fresh_one() {
        let db = Db::open_memory().unwrap();
        db.note_remote_check("github:x", false, "", 900).unwrap();
        assert_eq!(db.stale_age("github:x").unwrap(), None);
    }

    #[test]
    fn ownership_is_per_object_not_per_file() {
        let db = Db::open_memory().unwrap();
        db.add_receipt(&OwnershipReceipt {
            id: 0,
            path: "/home/x/.claude/CLAUDE.md".into(),
            object_id: "capso.global".into(),
            component_id: "capso.prompt.global".into(),
            before_sha256: "a".into(),
            after_sha256: "b".into(),
            release_version: "1.0.0".into(),
            backup_id: None,
            at: 0,
        })
        .unwrap();
        assert!(db
            .owns("/home/x/.claude/CLAUDE.md", "capso.global")
            .unwrap());
        assert!(
            !db.owns("/home/x/.claude/CLAUDE.md", "someone.elses.block")
                .unwrap(),
            "owning one block in a file must not imply owning the file"
        );
    }

    #[test]
    fn credential_missing_is_healthy_and_blocked_is_not() {
        assert!(ComponentState::CredentialMissing.is_healthy());
        assert!(!ComponentState::Blocked.is_healthy());
        assert!(!ComponentState::Drifted.is_healthy());
    }

    /// `unverified` degrades nothing and blocks nothing: it is the absence of an observation,
    /// not a fault. It must also survive the round trip, or a state written by one release
    /// comes back as `blocked` in the next — `parse` falls back to `Blocked` by design, which
    /// turns an unknown word into a session-stopping verdict.
    #[test]
    fn unverified_is_healthy_and_round_trips() {
        assert!(ComponentState::Unverified.is_healthy());
        assert_eq!(ComponentState::Unverified.as_str(), "unverified");
        assert_eq!(
            ComponentState::parse(ComponentState::Unverified.as_str()),
            ComponentState::Unverified
        );
    }
}
