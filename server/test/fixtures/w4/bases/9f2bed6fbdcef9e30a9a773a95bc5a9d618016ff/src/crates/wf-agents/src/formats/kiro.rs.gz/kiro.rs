//! Kiro: a hook file of `wf`'s own under `hooks/`, MCP servers in `settings/mcp.json`.
//!
//! Kiro reads every `hooks/*.json`, so `wf` needs no surgery on a shared file: it owns one
//! file whole. When the last handler leaves, the rendered document is empty and the file
//! goes with it.

use super::{
    json_doc, owned_identity, shell_words, Document, HookEntry, HookEvent, HookFormatAdapter,
    McpDef, McpFormatAdapter, McpTransport,
};
use serde_json::{json, Value};
use std::path::Path;
use wf_core::{Error, Result};

pub struct KiroHooks;

fn shape(path: &Path) -> Error {
    Error::conflict(
        "HOOKS-SHAPE",
        format!("{} is not a Kiro hook file", path.display()),
    )
}

/// The marker behind the `name` [`KiroHooks::render_hook`] writes. Usage first: every usage
/// name also opens with the bootstrap prefix.
fn marker_of_name(name: &str) -> Option<&'static str> {
    if name.starts_with("capso-wf-usage-") {
        Some(super::MARKER_USAGE)
    } else if name.starts_with("capso-wf-") {
        Some(super::MARKER_BOOTSTRAP)
    } else {
        None
    }
}

fn identity_of(entry: &Value) -> Option<String> {
    let event = HookEvent::parse(entry["trigger"].as_str()?)?;
    let argv = entry["action"]["command"].as_str().and_then(shell_words);
    let marker = entry["name"].as_str().and_then(marker_of_name);
    owned_identity(event, argv.as_deref(), marker)
}

fn kebab(event: HookEvent) -> String {
    let mut out = String::new();
    for (i, c) in event.as_str().chars().enumerate() {
        if c.is_ascii_uppercase() && i > 0 {
            out.push('-');
        }
        out.push(c.to_ascii_lowercase());
    }
    out
}

/// The document and its hook list, both checked; a missing document starts empty.
fn document(text: &str, path: &Path) -> Result<Value> {
    let doc = if text.trim().is_empty() {
        json!({"version": "v1", "hooks": []})
    } else {
        json_doc::parse_object(text, path)?
    };
    if !doc["hooks"].is_array() {
        return Err(shape(path));
    }
    Ok(doc)
}

impl HookFormatAdapter for KiroHooks {
    fn supports(&self, event: HookEvent) -> bool {
        event != HookEvent::SessionEnd
    }
    fn marks_handlers(&self) -> bool {
        true
    }
    fn render_hook(&self, entry: &HookEntry) -> Value {
        let name = if entry.marker() == super::MARKER_BOOTSTRAP {
            format!("capso-wf-{}", kebab(entry.event))
        } else {
            format!("capso-wf-usage-{}", kebab(entry.event))
        };
        let mut e = serde_json::Map::new();
        e.insert("name".into(), name.into());
        e.insert("trigger".into(), entry.event.as_str().into());
        if let Some(m) = &entry.matcher {
            e.insert("matcher".into(), m.clone().into());
        }
        e.insert(
            "action".into(),
            json!({"type": "command", "command": entry.command()}),
        );
        if let Some(t) = entry.timeout_secs {
            e.insert("timeout".into(), t.into());
        }
        e.insert("enabled".into(), true.into());
        Value::Object(e)
    }
    fn parse_hooks(&self, text: &str, path: &Path) -> Result<Vec<(String, Value)>> {
        if text.trim().is_empty() {
            return Ok(vec![]);
        }
        let doc = document(text, path)?;
        Ok(doc["hooks"]
            .as_array()
            .expect("checked")
            .iter()
            .filter_map(|e| identity_of(e).map(|id| (id, e.clone())))
            .collect())
    }
    fn upsert(&self, text: &str, entry: &HookEntry, path: &Path) -> Result<String> {
        let mut doc = document(text, path)?;
        let identity = entry.identity();
        let wanted = self.render_hook(entry);
        let list = doc["hooks"].as_array_mut().expect("checked");
        let mut placed = false;
        list.retain_mut(|e| {
            if identity_of(e).as_deref() != Some(&identity) {
                return true;
            }
            if placed {
                return false;
            }
            *e = wanted.clone();
            placed = true;
            true
        });
        if !placed {
            list.push(wanted);
        }
        if text.trim().is_empty() {
            return Ok(json_doc::render(&doc));
        }
        json_doc::render_if_changed(text, &doc, path)
    }
    /// An empty string when nothing is left: the file is `wf`'s and goes.
    fn remove(&self, text: &str, identity: &str, path: &Path) -> Result<String> {
        if text.trim().is_empty() {
            return Ok(String::new());
        }
        let mut doc = document(text, path)?;
        let list = doc["hooks"].as_array_mut().expect("checked");
        list.retain(|e| identity_of(e).as_deref() != Some(identity));
        if list.is_empty() {
            return Ok(String::new());
        }
        json_doc::render_if_changed(text, &doc, path)
    }
}

pub struct KiroMcp;

impl McpFormatAdapter for KiroMcp {
    fn document(&self) -> Document {
        Document::Json
    }
    fn keys(&self, name: &str) -> Vec<String> {
        vec!["mcpServers".into(), name.into()]
    }
    fn render_server(&self, def: &McpDef) -> Result<Option<Value>> {
        let mut s = serde_json::Map::new();
        match def.transport {
            McpTransport::Stdio => {
                s.insert("command".into(), def.command.clone().into());
                s.insert("args".into(), def.args.clone().into());
                let env = super::stdio_env(def, |k| format!("${{{k}}}"));
                if !env.is_empty() {
                    s.insert("env".into(), Value::Object(env));
                }
            }
            McpTransport::Http | McpTransport::Sse => {
                s.insert("url".into(), def.url.clone().into());
                if !def.headers.is_empty() {
                    s.insert("headers".into(), json!(def.headers));
                }
            }
        }
        Ok(Some(Value::Object(s)))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn p() -> &'static Path {
        Path::new("/home/a/.kiro/hooks/capso-wf.json")
    }

    fn entry(event: HookEvent, words: &[&str]) -> HookEntry {
        HookEntry {
            event,
            matcher: None,
            argv: words.iter().map(|w| w.to_string()).collect(),
            timeout_secs: Some(10),
        }
    }

    fn bootstrap() -> HookEntry {
        entry(
            HookEvent::SessionStart,
            &["/x/wf", "hook", "session-start", "--agent", "kiro"],
        )
    }

    fn usage(event: HookEvent) -> HookEntry {
        entry(
            event,
            &[
                "/x/wf",
                "hook",
                "dispatch",
                "--event",
                event.as_str(),
                "--agent",
                "kiro",
            ],
        )
    }

    #[test]
    fn kiro_triggers_are_the_canonical_names_it_has() {
        for e in [
            HookEvent::SessionStart,
            HookEvent::UserPromptSubmit,
            HookEvent::PreToolUse,
            HookEvent::PostToolUse,
            HookEvent::Stop,
        ] {
            assert!(KiroHooks.supports(e), "{e:?}");
        }
        assert!(!KiroHooks.supports(HookEvent::SessionEnd));
    }

    #[test]
    fn a_hook_file_is_version_one_with_named_enabled_entries() {
        let text = KiroHooks.upsert("", &bootstrap(), p()).unwrap();
        let doc: Value = serde_json::from_str(&text).unwrap();
        assert_eq!(doc["version"], "v1");
        assert_eq!(
            doc["hooks"][0],
            json!({
                "name": "capso-wf-session-start",
                "trigger": "SessionStart",
                "action": {"type": "command", "command": "/x/wf hook session-start --agent kiro"},
                "timeout": 10,
                "enabled": true
            })
        );
        assert_eq!(KiroHooks.upsert(&text, &bootstrap(), p()).unwrap(), text);
    }

    #[test]
    fn handlers_are_replaced_by_identity_and_the_file_empties_when_the_last_goes() {
        let one = KiroHooks.upsert("", &bootstrap(), p()).unwrap();
        let two = KiroHooks
            .upsert(&one, &usage(HookEvent::Stop), p())
            .unwrap();
        let mut moved = usage(HookEvent::Stop);
        moved.argv[0] = "/y/wf".into();
        let replaced = KiroHooks.upsert(&two, &moved, p()).unwrap();
        let doc: Value = serde_json::from_str(&replaced).unwrap();
        assert_eq!(doc["hooks"].as_array().unwrap().len(), 2);
        assert_eq!(KiroHooks.parse_hooks(&replaced, p()).unwrap().len(), 2);
        let less = KiroHooks
            .remove(&replaced, "Stop/capso-wf-usage", p())
            .unwrap();
        assert_eq!(
            serde_json::from_str::<Value>(&less).unwrap(),
            serde_json::from_str::<Value>(&one).unwrap()
        );
        assert_eq!(
            KiroHooks
                .remove(&less, "SessionStart/capso-wf-bootstrap", p())
                .unwrap(),
            ""
        );
    }

    #[test]
    fn mcp_servers_are_claude_shaped_without_a_type() {
        let def = McpDef {
            schema_version: 1,
            name: "capso-linear".into(),
            description: String::new(),
            transport: McpTransport::Stdio,
            command: Some("npx".into()),
            args: vec!["-y".into()],
            url: None,
            env_references: vec!["LINEAR_API_TOKEN".into()],
            headers: Default::default(),
            startup_timeout_sec: None,
            component: Some("capso.mcp.linear".into()),
        };
        assert_eq!(
            KiroMcp.render_server(&def).unwrap(),
            Some(
                json!({"command": "npx", "args": ["-y"], "env": {"LINEAR_API_TOKEN": "${LINEAR_API_TOKEN}", "WF_MCP_COMPONENT": "capso.mcp.linear"}})
            )
        );
        let remote = McpDef {
            transport: McpTransport::Sse,
            command: None,
            args: vec![],
            url: Some("https://mcp.spot.rackspace.com/mcp".into()),
            env_references: vec![],
            ..def
        };
        assert_eq!(
            KiroMcp.render_server(&remote).unwrap(),
            Some(json!({"url": "https://mcp.spot.rackspace.com/mcp"}))
        );
    }
}
