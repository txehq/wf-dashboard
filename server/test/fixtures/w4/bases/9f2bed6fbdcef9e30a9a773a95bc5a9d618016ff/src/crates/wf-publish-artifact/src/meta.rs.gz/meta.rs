use crate::parse::{instance_from, repo_from, ticket_from, Kind};
use serde::Serialize;
use std::path::Path;
use std::time::Duration;

/// The provenance recorded with every artifact.
///
/// A struct rather than 24 positional arguments handed to a `python3 -c` one-liner, which is
/// what the shell version did. Inserting a field in the wrong position there shifted every
/// value after it, silently — a class of defect that cannot occur here.
///
/// Everything in this struct is visible to anyone who can read the index. Publish nothing
/// you would not show the team.
#[derive(Debug, Clone, Default, Serialize)]
pub struct Meta {
    #[serde(skip_serializing_if = "String::is_empty")]
    pub session: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub instance: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub workspace: String,
    #[serde(rename = "session_id", skip_serializing_if = "String::is_empty")]
    pub session_id: String,

    #[serde(rename = "git_name", skip_serializing_if = "String::is_empty")]
    pub git_name: String,
    #[serde(rename = "git_email", skip_serializing_if = "String::is_empty")]
    pub git_email: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub repo: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub branch: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub sha: String,
    #[serde(rename = "base_sha", skip_serializing_if = "String::is_empty")]
    pub base_sha: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub ticket: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub pr: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub dirty: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub changed: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub ahead: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub behind: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub worktree: String,
    #[serde(rename = "git_root", skip_serializing_if = "String::is_empty")]
    pub git_root: String,

    #[serde(skip_serializing_if = "String::is_empty")]
    pub host: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub user: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub kind: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub bytes: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub sha256: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub tool: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub via: String,
}

const PROBE: Duration = Duration::from_secs(6);

/// Gather provenance. Every external command is bounded and non-fatal: metadata must never
/// block or slow a publish.
pub fn collect(file: &Path, kind: Kind, size: u64) -> Meta {
    let mut m = Meta {
        kind: kind.as_str().into(),
        bytes: size.to_string(),
        tool: "wf publish-artifact".into(),
        via: env("ARTIFACT_VIA"),
        user: env("USER"),
        host: run("hostname", &["-s"]),
        ..Default::default()
    };

    m.instance = instance_from(&env("CLAUDE_CONFIG_DIR"));
    m.session_id = env("CLAUDE_CODE_SESSION_ID");
    if std::env::var_os("TMUX").is_some() {
        m.workspace = run("tmux", &["display-message", "-p", "#S"]);
    }
    if m.workspace.is_empty() && !m.session_id.is_empty() {
        m.workspace = format!("s{}", first_n(&m.session_id, 6));
    }
    m.session = env("CLAUDE_SESSION_LABEL");
    if m.session.is_empty() {
        m.session = m.instance.clone();
        if !m.workspace.is_empty() {
            m.session = format!("{}-{}", m.session, m.workspace);
        }
    }

    if run("git", &["rev-parse", "--is-inside-work-tree"]) == "true" {
        m.git_root = run("git", &["rev-parse", "--show-toplevel"]);
        m.branch = run("git", &["rev-parse", "--abbrev-ref", "HEAD"]);
        m.sha = run("git", &["rev-parse", "--short", "HEAD"]);
        m.git_name = run("git", &["config", "user.name"]);
        m.git_email = run("git", &["config", "user.email"]);
        m.repo = repo_from(&run("git", &["remote", "get-url", "origin"]));
        m.ticket = ticket_from(&m.branch);
        m.ahead = run("git", &["rev-list", "--count", "@{upstream}..HEAD"]);
        m.behind = run("git", &["rev-list", "--count", "HEAD..origin/main"]);
        m.base_sha = first_n(&run("git", &["merge-base", "HEAD", "origin/main"]), 9);

        let status = run("git", &["status", "--porcelain"]);
        m.dirty = "0".into();
        m.changed = "0".into();
        if !status.is_empty() {
            m.dirty = "1".into();
            m.changed = status.lines().count().to_string();
        }
        // A worktree's .git is a file pointing at the real directory, not a directory.
        let dot_git = Path::new(&m.git_root).join(".git");
        m.worktree = if dot_git.is_file() {
            "1".into()
        } else {
            "0".into()
        };
    }

    // The PR number is the strongest join key into review and CI data, so it is worth one
    // bounded network call — and worth nothing if it delays the publish.
    if !m.branch.is_empty() {
        let pr = run(
            "gh",
            &[
                "pr",
                "list",
                "--head",
                &m.branch,
                "--state",
                "open",
                "--json",
                "number",
                "--jq",
                ".[0].number",
            ],
        );
        if !pr.is_empty() && pr != "null" {
            m.pr = pr;
        }
    }
    m.sha256 = first_n(&wf_core::hash::sha256_file(file).unwrap_or_default(), 16);
    m
}

/// Run a command and return its trimmed stdout, or "" for any failure.
///
/// Provenance is best-effort by design: a missing `gh`, a detached HEAD or no upstream must
/// all degrade to an absent field rather than a failed publish.
fn run(name: &str, args: &[&str]) -> String {
    match wf_core::proc::run(name, args, PROBE) {
        Ok(o) if o.ok() => o.stdout.trim().to_string(),
        _ => String::new(),
    }
}

fn env(k: &str) -> String {
    std::env::var(k).unwrap_or_default()
}

fn first_n(s: &str, n: usize) -> String {
    s.chars().take(n).collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn provenance_never_fails_even_outside_a_git_checkout() {
        let d = tempfile::tempdir().unwrap();
        let f = d.path().join("x.html");
        std::fs::write(&f, "<p>x</p>").unwrap();
        let m = collect(&f, Kind::Page, 8);
        assert_eq!(m.kind, "page");
        assert_eq!(m.bytes, "8");
        assert_eq!(m.sha256.len(), 16);
    }

    #[test]
    fn absent_fields_are_omitted_rather_than_serialised_empty() {
        let m = Meta {
            kind: "page".into(),
            ..Default::default()
        };
        let s = serde_json::to_string(&m).unwrap();
        assert_eq!(s, r#"{"kind":"page"}"#);
    }
}
