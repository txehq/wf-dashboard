//! The one number the session-start design is shaped by.
//!
//! Every terminal a person opens runs `wf hook session-start`. The budget for the path
//! where nothing has changed is a tenth of a second at p95, and it is easy to lose without
//! noticing: this test caught the fast path spawning `claude --version` and
//! `claude plugin --help` for capability probing it did not need, which cost 274 ms — nearly
//! three times the whole budget, on every terminal.
//!
//! It measures the real binary in a subprocess, because that is what a hook actually runs;
//! an in-process measurement would miss process start, which is a third of the number.

use std::path::PathBuf;
use std::process::Command;
use std::time::Instant;

const BUDGET_P95_MS: u128 = 100;
const RUNS: usize = 30;

/// One test at a time. These are wall-clock measurements, and the tests in this file load the
/// machine themselves — twenty concurrent session starts, four hundred thousand rows written —
/// so measured side by side they time each other, not the session start.
static SERIAL: std::sync::Mutex<()> = std::sync::Mutex::new(());

fn serial() -> std::sync::MutexGuard<'static, ()> {
    SERIAL
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}

fn isolated() -> tempfile::TempDir {
    let d = tempfile::tempdir().unwrap();
    for sub in ["home", "claude", "codex"] {
        std::fs::create_dir_all(d.path().join(sub)).unwrap();
    }
    d
}

fn run_hook(dir: &std::path::Path, agent: &str) -> (std::process::Output, u128) {
    let started = Instant::now();
    let out = Command::new(env!("CARGO_BIN_EXE_wf"))
        .args(["hook", "session-start", "--agent", agent])
        .env("HOME", dir)
        .env("WF_HOME", dir.join("home"))
        .env("CLAUDE_CONFIG_DIR", dir.join("claude"))
        .env("CODEX_HOME", dir.join("codex"))
        // Offline by construction: the fast path must not be measured with a network call
        // in it, and must not make one anyway.
        .env(
            "WF_SOURCE",
            format!("local:{}", dir.join("nonexistent-dist").display()),
        )
        .output()
        .expect("the hook runs");
    (out, started.elapsed().as_millis())
}

/// A machine with nothing installed still gets a valid answer, quickly, and is told what to
/// do about it.
#[test]
fn an_uninstalled_machine_gets_an_instruction_not_an_error() {
    let _serial = serial();
    let d = isolated();
    let (out, _) = run_hook(d.path(), "claude");
    assert!(
        out.status.success(),
        "a session start must never fail: {out:?}"
    );
    let stdout = String::from_utf8_lossy(&out.stdout);
    let v: serde_json::Value = serde_json::from_str(stdout.trim()).expect("valid JSON on stdout");
    let ctx = v["hookSpecificOutput"]["additionalContext"]
        .as_str()
        .unwrap();
    assert!(ctx.contains("wf install"), "{ctx}");
}

/// The budget, measured at p95 over thirty runs of the real binary.
#[test]
fn the_no_change_path_stays_inside_its_budget() {
    let _serial = serial();
    let d = isolated();
    // Warm: the first run creates directories and the database.
    for _ in 0..3 {
        run_hook(d.path(), "claude");
    }
    let mut samples: Vec<u128> = (0..RUNS).map(|_| run_hook(d.path(), "claude").1).collect();
    samples.sort_unstable();
    let p95 = samples[(RUNS as f64 * 0.95) as usize - 1];
    let median = samples[RUNS / 2];
    assert!(
        p95 <= BUDGET_P95_MS,
        "session start p95 is {p95}ms, over the {BUDGET_P95_MS}ms budget (median {median}ms). \
         The usual cause is something on this path spawning a process — detecting an agent \
         costs three."
    );
}

/// Whatever goes wrong, a session start exits 0 with parseable JSON. A person whose
/// terminal will not open because the workflow manager had a bad day is the one outcome
/// this design does not tolerate.
#[test]
fn a_hook_never_fails_a_session() {
    let _serial = serial();
    let d = isolated();
    // A state directory that is a file, not a directory: everything downstream of it fails.
    std::fs::remove_dir_all(d.path().join("home")).unwrap();
    std::fs::write(d.path().join("home"), "not a directory").unwrap();
    for agent in ["claude", "codex", "nonsense"] {
        let (out, _) = run_hook(d.path(), agent);
        assert!(
            out.status.success(),
            "{agent}: exited {:?}",
            out.status.code()
        );
        let stdout = String::from_utf8_lossy(&out.stdout);
        serde_json::from_str::<serde_json::Value>(stdout.trim())
            .unwrap_or_else(|e| panic!("{agent}: stdout was not JSON ({e}): {stdout}"));
    }
}

/// Twenty terminals opening at once produce one updater, not twenty.
#[test]
fn concurrent_session_starts_do_not_multiply() {
    let _serial = serial();
    let d = isolated();
    run_hook(d.path(), "claude");
    let dir: PathBuf = d.path().to_path_buf();
    let handles: Vec<_> = (0..20)
        .map(|_| {
            let dir = dir.clone();
            std::thread::spawn(move || run_hook(&dir, "claude").0.status.success())
        })
        .collect();
    for h in handles {
        assert!(h.join().unwrap(), "a concurrent session start failed");
    }
    // At most one updater marker exists, and it names one process.
    let marker = dir.join("home/state/updater.pid");
    if let Ok(text) = std::fs::read_to_string(&marker) {
        assert_eq!(
            text.matches(':').count(),
            1,
            "more than one updater was recorded: {text}"
        );
    }
}

/// The same budget on a machine with a release installed, which is the path every terminal
/// takes: the generation's agent configuration read, the session recorded, the prompt block
/// checked through the agent layer.
#[test]
fn an_installed_machine_stays_inside_the_budget() {
    let _serial = serial();
    let d = installed();
    assert_inside_budget(d.path());
}

/// Usage rows accumulate for the retention window in the same database the hook reads its
/// installation from. Reading it must not cost in proportion to that history: a read-only
/// snapshot copies the whole file, which put a heavy user's session start over budget.
#[test]
fn a_long_usage_history_does_not_slow_the_session_start() {
    let _serial = serial();
    let d = installed();
    let db = rusqlite::Connection::open(d.path().join("home/state/state.sqlite3")).unwrap();
    db.execute_batch(
        "WITH RECURSIVE n(i) AS (SELECT 1 UNION ALL SELECT i + 1 FROM n LIMIT 400000)
         INSERT INTO usage_events(timestamp, session_id, agent, event_type, tool_name, metadata)
         SELECT printf('2026-09-%02dT10:00:00.000Z', 1 + i % 15), 'history-' || (i / 50),
                'claude-code', 'tool', 'Bash', '{\"note\":\"' || hex(randomblob(40)) || '\"}'
         FROM n;
         PRAGMA wal_checkpoint(TRUNCATE);",
    )
    .unwrap();
    drop(db);
    assert_inside_budget(d.path());
}

fn installed() -> tempfile::TempDir {
    let d = isolated();
    let dist = d.path().join("nonexistent-dist");
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
    wf_release::bundle::build(&wf_release::bundle::BuildOptions {
        root: &root,
        out: &dist,
        version: "1.0.0",
        source_commit: "a".repeat(40),
        binaries: vec![],
        ctx: None,
    })
    .unwrap();
    let install = Command::new(env!("CARGO_BIN_EXE_wf"))
        .args([
            "install",
            "--source",
            &format!("local:{}", dist.display()),
            "--agent",
            "claude,codex",
        ])
        .env("HOME", d.path())
        .env("WF_HOME", d.path().join("home"))
        .env("CLAUDE_CONFIG_DIR", d.path().join("claude"))
        .env("CODEX_HOME", d.path().join("codex"))
        .env("PATH", "/usr/bin:/bin")
        .output()
        .unwrap();
    assert!(install.status.success(), "{install:?}");
    d
}

fn assert_inside_budget(dir: &std::path::Path) {
    let d = dir;
    for _ in 0..3 {
        run_hook(d, "claude");
    }
    let mut samples: Vec<u128> = (0..RUNS).map(|_| run_hook(d, "claude").1).collect();
    samples.sort_unstable();
    let p95 = samples[(RUNS as f64 * 0.95) as usize - 1];
    let (out, _) = run_hook(d, "claude");
    let journal = std::fs::read_to_string(d.join("home/state/journal.log")).unwrap_or_default();
    assert!(out.status.success());
    assert!(
        p95 <= BUDGET_P95_MS,
        "installed session start p95 is {p95}ms, over the {BUDGET_P95_MS}ms budget: {samples:?}\n{}",
        journal.lines().last().unwrap_or_default()
    );
}
