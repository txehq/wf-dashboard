//! Retiring the native plugin that wf 1.x installed.
//!
//! Until 2.0, skills reached Claude Code and Codex as the `magi` plugin, registered from a
//! verified generation through each agent's own plugin manager. The resource layer copies
//! skills into the agents' skill directories instead, so a machine that kept the plugin would
//! carry every skill twice. On its first apply, wf removes the plugin and its marketplace —
//! **only** the ones it holds a native receipt for, through the agent's public commands,
//! verified by reading the manager back — and registers a compensation that reinstalls them
//! if the transaction does not commit. A plugin somebody installed by hand is not wf's and is
//! reported, not removed.

use serde_json::Value;
use std::path::{Path, PathBuf};
use std::time::Duration;
use wf_core::{Error, Result};
use wf_registry::Agent;
use wf_state::{NativeObject, NativeReceipt, Transaction};

#[derive(Clone, Debug)]
pub struct Manager {
    pub agent: Agent,
    pub binary: String,
    pub config_root: String,
    pub plugin: String,
    pub marketplace: String,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Plugin {
    pub version: String,
    pub enabled: bool,
    pub path: PathBuf,
}

#[derive(Clone, Debug, Default)]
pub struct Inventory {
    pub registered: bool,
    pub source: Option<PathBuf>,
    pub plugin: Option<Plugin>,
    pub other_plugins: usize,
}

impl Manager {
    pub fn from_receipt(receipt: &NativeReceipt) -> Result<Self> {
        let agent = Agent::parse(&receipt.agent)
            .ok_or_else(|| Error::unsupported("NATIVE-AGENT", "unknown receipt agent"))?;
        let (plugin, marketplace) = if receipt.kind == NativeObject::Plugin {
            receipt
                .identity
                .split_once('@')
                .ok_or_else(|| Error::failure("NATIVE-RECEIPT", "invalid plugin identity"))?
        } else {
            ("magi", receipt.identity.as_str())
        };
        Ok(Self {
            agent,
            binary: receipt.binary.clone(),
            config_root: receipt.config_root.clone(),
            plugin: plugin.into(),
            marketplace: marketplace.into(),
        })
    }

    fn identity(&self) -> String {
        format!("{}@{}", self.plugin, self.marketplace)
    }

    fn run(&self, args: &[&str]) -> Result<wf_core::proc::Output> {
        let key = match self.agent {
            Agent::ClaudeCode => "CLAUDE_CONFIG_DIR",
            Agent::Codex => "CODEX_HOME",
        };
        let output = wf_core::proc::run_in(
            &self.binary,
            args,
            &[
                (key, &self.config_root),
                ("CI", "1"),
                ("CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC", "1"),
            ],
            Some(Path::new("/")),
            Duration::from_secs(60),
        )?;
        if !output.ok() {
            return Err(Error::failure(
                "NATIVE-COMMAND",
                format!(
                    "{} {} failed",
                    self.agent.as_str(),
                    args.iter().take(3).copied().collect::<Vec<_>>().join(" ")
                ),
            ));
        }
        Ok(output)
    }

    pub fn inventory(&self) -> Result<Inventory> {
        if !Path::new(&self.config_root).is_dir() {
            return Ok(Inventory::default());
        }
        let plugins = self.run(&["plugin", "list", "--json"])?;
        let markets = self.run(&["plugin", "marketplace", "list", "--json"])?;
        let plugins: Value = serde_json::from_str(&plugins.stdout)
            .map_err(|_| Error::failure("NATIVE-STATE", "native plugin list was not JSON"))?;
        let markets: Value = serde_json::from_str(&markets.stdout)
            .map_err(|_| Error::failure("NATIVE-STATE", "native marketplace list was not JSON"))?;
        let plugin_rows = match self.agent {
            Agent::ClaudeCode => plugins.as_array(),
            Agent::Codex => plugins["installed"].as_array(),
        }
        .ok_or_else(|| Error::failure("NATIVE-STATE", "unexpected native plugin list"))?;
        let market_rows = match self.agent {
            Agent::ClaudeCode => markets.as_array(),
            Agent::Codex => markets["marketplaces"].as_array(),
        }
        .ok_or_else(|| Error::failure("NATIVE-STATE", "unexpected marketplace list"))?;
        let mut state = Inventory::default();
        for row in plugin_rows {
            if self.agent == Agent::ClaudeCode && row["scope"].as_str() != Some("user") {
                continue;
            }
            if self.agent == Agent::Codex && row["installed"].as_bool() != Some(true) {
                continue;
            }
            let id = row[if self.agent == Agent::ClaudeCode {
                "id"
            } else {
                "pluginId"
            }]
            .as_str()
            .unwrap_or_default();
            if id == self.identity() {
                let version = row["version"].as_str().unwrap_or_default().to_string();
                let path = row["installPath"]
                    .as_str()
                    .map(PathBuf::from)
                    .unwrap_or_else(|| {
                        Path::new(&self.config_root)
                            .join("plugins/cache")
                            .join(&self.marketplace)
                            .join(&self.plugin)
                            .join(&version)
                    });
                state.plugin = Some(Plugin {
                    version,
                    enabled: row["enabled"].as_bool().unwrap_or(false),
                    path,
                });
            } else if id.ends_with(&format!("@{}", self.marketplace)) {
                state.other_plugins += 1;
            }
        }
        if let Some(row) = market_rows.iter().find(|r| r["name"] == self.marketplace) {
            state.registered = true;
            let source = match self.agent {
                Agent::ClaudeCode if row["source"] == "directory" => row["path"].as_str(),
                Agent::Codex if row["marketplaceSource"]["sourceType"] == "local" => {
                    row["marketplaceSource"]["source"].as_str()
                }
                _ => None,
            };
            state.source = source.map(PathBuf::from);
        }
        Ok(state)
    }

    fn add_marketplace(&self, source: &Path) -> Result<()> {
        let source = source.to_string_lossy();
        let mut args = vec!["plugin", "marketplace", "add", source.as_ref()];
        if self.agent == Agent::ClaudeCode {
            args.extend(["--scope", "user"]);
        }
        self.run(&args)?;
        Ok(())
    }

    fn remove_marketplace(&self) -> Result<()> {
        self.run(&["plugin", "marketplace", "remove", &self.marketplace])?;
        Ok(())
    }

    fn install_plugin(&self) -> Result<()> {
        let identity = self.identity();
        let verb = if self.agent == Agent::ClaudeCode {
            "install"
        } else {
            "add"
        };
        let mut args = vec!["plugin", verb, &identity];
        if self.agent == Agent::ClaudeCode {
            args.extend(["--scope", "user"]);
        }
        self.run(&args)?;
        Ok(())
    }

    fn remove_plugin(&self) -> Result<()> {
        let identity = self.identity();
        let verb = if self.agent == Agent::ClaudeCode {
            "uninstall"
        } else {
            "remove"
        };
        let mut args = vec!["plugin", verb, &identity];
        if self.agent == Agent::ClaudeCode {
            args.extend(["--scope", "user"]);
        }
        self.run(&args)?;
        Ok(())
    }

    fn set_enabled(&self, enabled: bool) -> Result<()> {
        if self.agent == Agent::Codex {
            return crate::codex_rpc::Client::connect(
                Path::new(&self.binary),
                Path::new(&self.config_root),
            )?
            .set_plugin_enabled(&self.identity(), enabled);
        }
        self.run(&[
            "plugin",
            if enabled { "enable" } else { "disable" },
            &self.identity(),
            "--scope",
            "user",
        ])?;
        Ok(())
    }

    /// Put this plugin and its registration back as `before` had them, through the public
    /// manager, and check the result rather than the exit status.
    pub fn restore(&self, before: &Inventory) -> Result<()> {
        let current = self.inventory()?;
        if current.plugin == before.plugin
            && current.registered == before.registered
            && same_path(current.source.as_deref(), before.source.as_deref())
        {
            return Ok(());
        }
        if current.plugin.is_some() {
            self.remove_plugin()?;
        }
        if !same_path(current.source.as_deref(), before.source.as_deref())
            || current.registered != before.registered
        {
            if current.registered && (self.agent == Agent::Codex || !before.registered) {
                if current.other_plugins > 0 {
                    return Err(Error::conflict(
                        "NATIVE-SHARED",
                        "marketplace is now used by other plugins",
                    ));
                }
                self.remove_marketplace()?;
            }
            if let Some(source) = &before.source {
                self.add_marketplace(source)?;
            } else if before.registered {
                return Err(Error::conflict(
                    "NATIVE-SOURCE",
                    "original marketplace source cannot be reconstructed",
                ));
            }
        }
        if let Some(plugin) = &before.plugin {
            self.install_plugin()?;
            if !plugin.enabled {
                self.set_enabled(false)?;
            }
        }
        let after = self.inventory()?;
        if after.plugin.as_ref().map(|p| (&p.version, p.enabled))
            != before.plugin.as_ref().map(|p| (&p.version, p.enabled))
            || after.registered != before.registered
            || !same_path(after.source.as_deref(), before.source.as_deref())
        {
            return Err(Error::failure(
                "NATIVE-RESTORE",
                "native manager did not restore the previous plugin state",
            ));
        }
        Ok(())
    }

    /// Remove the object a receipt names, if it is still the object the receipt names.
    pub fn remove_owned(
        &self,
        receipt: &NativeReceipt,
        tx: &mut Transaction<'_>,
    ) -> Result<Retirement> {
        let kind = receipt.kind;
        let before = self.inventory()?;
        // A person may have replaced the registration since; that is no longer our object —
        // and the 1.x plugin it installs is still on this machine.
        if before.registered
            && !same_path(before.source.as_deref(), Some(Path::new(&receipt.source)))
        {
            return Ok(Retirement::Kept(format!(
                "{} is registered from somewhere else now, so wf did not remove it",
                self.identity()
            )));
        }
        if (kind == NativeObject::Plugin && before.plugin.is_none())
            || (kind == NativeObject::Marketplace && !before.registered)
        {
            return Ok(Retirement::Absent);
        }
        // A registration somebody else's plugin now uses stays.
        if kind == NativeObject::Marketplace
            && (before.plugin.is_some() || before.other_plugins > 0)
        {
            return Ok(Retirement::Kept(format!(
                "{} still has plugins on it, so wf left the marketplace registered",
                self.identity()
            )));
        }
        tx.note_plan(
            "capso.plugin",
            "remove owned native object",
            &self.identity(),
            "",
        );
        if tx.is_dry_run() {
            return Ok(Retirement::Removed);
        }
        let manager = self.clone();
        let previous = before.clone();
        tx.native_restore("capso.plugin", move || manager.restore(&previous));
        match kind {
            NativeObject::Plugin => self.remove_plugin()?,
            NativeObject::Marketplace => self.remove_marketplace()?,
        }
        let after = self.inventory()?;
        if (kind == NativeObject::Plugin && after.plugin.is_some())
            || (kind == NativeObject::Marketplace && after.registered)
        {
            return Err(Error::failure(
                "NATIVE-UNINSTALL",
                "native manager did not remove the owned object",
            ));
        }
        Ok(Retirement::Removed)
    }
}

/// What became of one 1.x receipt. The difference matters: a receipt forgotten while its
/// object is still installed leaves every skill on the machine twice, with nothing left that
/// records who owns the second copy.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Retirement {
    Removed,
    Absent,
    Kept(String),
}

fn same_path(a: Option<&Path>, b: Option<&Path>) -> bool {
    match (a, b) {
        (None, None) => true,
        (Some(a), Some(b)) => {
            a == b
                || a.canonicalize()
                    .ok()
                    .zip(b.canonicalize().ok())
                    .is_some_and(|(a, b)| a == b)
        }
        _ => false,
    }
}

/// Retire every native object wf owns for one agent at one configuration root: plugins first,
/// then the registrations they came from. Receipts are forgotten when the transaction commits.
/// Returns what was removed, for the plan and the report.
pub fn retire(
    receipts: &[NativeReceipt],
    agent: &str,
    config_root: &Path,
    tx: &mut Transaction<'_>,
) -> Result<Retired> {
    let mine: Vec<&NativeReceipt> = receipts
        .iter()
        .filter(|r| {
            r.agent == agent && same_path(Some(Path::new(&r.config_root)), Some(config_root))
        })
        .collect();
    let mut out = Retired::default();
    for (kind, label) in [
        (NativeObject::Plugin, "plugin"),
        (NativeObject::Marketplace, "marketplace"),
    ] {
        for receipt in mine.iter().filter(|r| r.kind == kind) {
            match Manager::from_receipt(receipt)?.remove_owned(receipt, tx)? {
                Retirement::Removed => {
                    out.removed.push(format!("{label} {}", receipt.identity));
                    tx.forget_native((*receipt).clone());
                }
                // Gone already: the receipt names nothing.
                Retirement::Absent => tx.forget_native((*receipt).clone()),
                // Still installed. The receipt is wf's only record of it, so it stays.
                Retirement::Kept(why) => out.kept.push(why),
            }
        }
    }
    Ok(out)
}

/// What one agent's 1.x receipts came to.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Retired {
    pub removed: Vec<String>,
    /// Objects wf installed, still on the machine, and no longer wf's to take.
    pub kept: Vec<String>,
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A stand-in `claude` whose plugin manager state is two files, and which logs every call.
    fn fake_claude(dir: &Path, source: &Path) -> PathBuf {
        let state = dir.join("state");
        std::fs::create_dir_all(&state).unwrap();
        std::fs::write(state.join("plugin"), "").unwrap();
        std::fs::write(state.join("market"), "").unwrap();
        std::fs::create_dir_all(dir.join("bin")).unwrap();
        let bin = dir.join("bin/claude");
        std::fs::write(
            &bin,
            format!(
                r#"#!/bin/sh
state="{state}"
echo "$*" >> "$state/calls"
case "$*" in
  "plugin list --json")
    if [ -f "$state/plugin" ]; then echo '[{{"id":"magi@capsohq","scope":"user","version":"1.7.0","enabled":true,"installPath":"/x"}}]'; else echo '[]'; fi ;;
  "plugin marketplace list --json")
    if [ -f "$state/market" ]; then echo '[{{"name":"capsohq","source":"directory","path":"{source}"}}]'; else echo '[]'; fi ;;
  "plugin uninstall magi@capsohq --scope user") rm -f "$state/plugin" ;;
  "plugin marketplace remove capsohq") rm -f "$state/market" ;;
  "plugin marketplace add {source} --scope user") touch "$state/market" ;;
  "plugin install magi@capsohq --scope user") touch "$state/plugin" ;;
  *) echo "unexpected: $*" >&2; exit 1 ;;
esac
"#,
                state = state.display(),
                source = source.display()
            ),
        )
        .unwrap();
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(&bin, std::fs::Permissions::from_mode(0o755)).unwrap();
        bin
    }

    fn receipts(bin: &Path, root: &Path, source: &Path) -> Vec<NativeReceipt> {
        [
            (NativeObject::Marketplace, "capsohq"),
            (NativeObject::Plugin, "magi@capsohq"),
        ]
        .into_iter()
        .map(|(kind, identity)| NativeReceipt {
            agent: "claude-code".into(),
            kind,
            identity: identity.into(),
            binary: bin.to_string_lossy().into(),
            config_root: root.to_string_lossy().into(),
            source: source.to_string_lossy().into(),
            version: "1.7.0".into(),
        })
        .collect()
    }

    #[cfg(unix)]
    #[test]
    fn an_owned_plugin_and_its_marketplace_are_retired_and_forgotten_on_commit() {
        let dir = tempfile::tempdir().unwrap();
        let root = dir.path().join("claude");
        std::fs::create_dir_all(&root).unwrap();
        let source = dir.path().join("generation-1.7.0");
        std::fs::create_dir_all(&source).unwrap();
        let bin = fake_claude(dir.path(), &source);
        let db = wf_state::Db::open_memory().unwrap();
        let owned = receipts(&bin, &root, &source);
        for r in &owned {
            db.record_native(r).unwrap();
        }
        let mut tx = wf_state::Transaction::begin(&db, dir.path().join("backups"), "2.0.0", false);
        let removed = retire(&owned, "claude-code", &root, &mut tx).unwrap();
        assert_eq!(
            removed.removed,
            ["plugin magi@capsohq", "marketplace capsohq"],
            "plugin before its registration"
        );
        assert!(removed.kept.is_empty());
        assert!(!dir.path().join("state/plugin").exists());
        assert!(!dir.path().join("state/market").exists());
        assert_eq!(
            db.native_receipts().unwrap().len(),
            2,
            "not forgotten before commit"
        );
        tx.commit().unwrap();
        assert!(db.native_receipts().unwrap().is_empty());
    }

    #[cfg(unix)]
    #[test]
    fn a_rolled_back_retirement_reinstalls_the_plugin() {
        let dir = tempfile::tempdir().unwrap();
        let root = dir.path().join("claude");
        std::fs::create_dir_all(&root).unwrap();
        let source = dir.path().join("generation-1.7.0");
        std::fs::create_dir_all(&source).unwrap();
        let bin = fake_claude(dir.path(), &source);
        let db = wf_state::Db::open_memory().unwrap();
        let owned = receipts(&bin, &root, &source);
        for r in &owned {
            db.record_native(r).unwrap();
        }
        let mut tx = wf_state::Transaction::begin(&db, dir.path().join("backups"), "2.0.0", false);
        retire(&owned, "claude-code", &root, &mut tx).unwrap();
        let out = tx.rollback();
        assert!(
            out.manual_followups.is_empty(),
            "{:?}",
            out.manual_followups
        );
        assert!(
            dir.path().join("state/plugin").exists(),
            "the plugin came back"
        );
        assert!(
            dir.path().join("state/market").exists(),
            "and so did its registration"
        );
        assert_eq!(db.native_receipts().unwrap().len(), 2);
    }

    #[cfg(unix)]
    #[test]
    fn a_registration_somebody_replaced_is_not_ours_to_remove() {
        let dir = tempfile::tempdir().unwrap();
        let root = dir.path().join("claude");
        std::fs::create_dir_all(&root).unwrap();
        let theirs = dir.path().join("their-marketplace");
        std::fs::create_dir_all(&theirs).unwrap();
        let bin = fake_claude(dir.path(), &theirs);
        let ours = dir.path().join("generation-1.7.0");
        std::fs::create_dir_all(&ours).unwrap();
        let db = wf_state::Db::open_memory().unwrap();
        let owned = receipts(&bin, &root, &ours);
        for r in &owned {
            db.record_native(r).unwrap();
        }
        let mut tx = wf_state::Transaction::begin(&db, dir.path().join("backups"), "2.0.0", false);
        let removed = retire(&owned, "claude-code", &root, &mut tx).unwrap();
        assert!(removed.removed.is_empty());
        assert_eq!(removed.kept.len(), 2, "both refusals are reported");
        assert!(dir.path().join("state/plugin").exists());
        // The plugin is still installed, so wf keeps the only record that it put it there.
        tx.commit().unwrap();
        assert_eq!(db.native_receipts().unwrap().len(), 2);
    }

    #[test]
    fn receipts_for_another_agent_or_root_are_left_alone() {
        let dir = tempfile::tempdir().unwrap();
        let db = wf_state::Db::open_memory().unwrap();
        let owned = receipts(
            Path::new("/nonexistent/claude"),
            &dir.path().join("a"),
            dir.path(),
        );
        let mut tx = wf_state::Transaction::begin(&db, dir.path().join("backups"), "2.0.0", false);
        assert_eq!(
            retire(&owned, "codex", &dir.path().join("a"), &mut tx).unwrap(),
            Retired::default()
        );
        assert_eq!(
            retire(&owned, "claude-code", &dir.path().join("b"), &mut tx).unwrap(),
            Retired::default()
        );
    }
}
