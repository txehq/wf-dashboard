//! Credential material never enters a finding or serialized requirement. Only a salted
//! digest reaches the cache; provider responses are reduced to status and capabilities.
use crate::check::{Finding, Severity, Tier};
use crate::requirements::CredReq;
use std::time::Duration;

pub(crate) fn material(req: &CredReq) -> Option<String> {
    let defaults: &[&str] = match req.id.as_str() {
        "github" | "gh" => &["GH_TOKEN", "GITHUB_TOKEN"],
        "cloudflare" => &["CLOUDFLARE_API_TOKEN", "CF_API_TOKEN"],
        "harbor" => &["HARBOR_PASSWORD"],
        _ => &[],
    };
    let names: Vec<&str> = if req.env.is_empty() {
        defaults.to_vec()
    } else {
        req.env.iter().map(String::as_str).collect()
    };
    for name in names {
        if let Ok(value) = std::env::var(name) {
            if !value.trim().is_empty() {
                return Some(value.trim().into());
            }
        }
    }
    if req.id == "engapp-artifacts" {
        let path = std::path::PathBuf::from(std::env::var_os("HOME")?)
            .join(".config/engapp-artifacts/env");
        let text = std::fs::read_to_string(path).ok()?;
        for line in text.lines() {
            let line = line.trim().strip_prefix("export ").unwrap_or(line.trim());
            if let Some((key, value)) = line.split_once('=') {
                if key.trim() == "CF_ACCESS_CLIENT_SECRET" {
                    let value = value.trim().trim_matches(['\"', '\'']);
                    if !value.is_empty() {
                        return Some(value.into());
                    }
                }
            }
        }
    }
    None
}

fn finding(req: &CredReq, code: &str, severity: Severity, detail: impl Into<String>) -> Finding {
    let detail = detail.into();
    Finding {
        code: code.into(),
        subject: req.id.clone(),
        severity,
        zh: detail.clone(),
        detail,
        fix: if code == "CRED-MISSING" || code == "CRED-INVALID" {
            match req.id.as_str() {
                "github" | "gh" => "gh auth login".into(),
                _ => req.zh_missing.clone(),
            }
        } else {
            String::new()
        },
        tier: (severity != Severity::Note).then_some(Tier::Manual),
    }
}

pub(crate) fn check(req: &CredReq, resolver: &crate::Resolver) -> Finding {
    let token = material(req);
    match req.id.as_str() {
        "github" | "gh" => {
            if let Some(token) = token {
                return http_check(req, &token, "https://api.github.com/user");
            }
            // gh's native credential store may be a keychain. Ask its API client rather
            // than printing or exporting the keychain's secret into this process.
            resolver.spawns.set(resolver.spawns.get() + 1);
            let output =
                wf_core::proc::run("gh", &["api", "--include", "user"], Duration::from_secs(8));
            match output {
                Ok(output) => {
                    let status = output
                        .stdout
                        .lines()
                        .find(|l| l.starts_with("HTTP/"))
                        .and_then(|l| l.split_whitespace().nth(1))
                        .and_then(|s| s.parse().ok())
                        .unwrap_or(if output.ok() { 200 } else { 0 });
                    let scopes = output.stdout.lines().find_map(|l| {
                        l.split_once(':')
                            .filter(|(key, _)| key.eq_ignore_ascii_case("x-oauth-scopes"))
                            .map(|(_, v)| v.trim())
                    });
                    github_verdict(req, status, scopes)
                }
                Err(_) => finding(
                    req,
                    "CRED-MISSING",
                    Severity::Fail,
                    "No GitHub credential could be verified. Run gh auth login.",
                ),
            }
        }
        "cloudflare" => match token {
            Some(token) => http_check(
                req,
                &token,
                "https://api.cloudflare.com/client/v4/user/tokens/verify",
            ),
            None => finding(
                req,
                "CRED-MISSING",
                Severity::Fail,
                "Set CLOUDFLARE_API_TOKEN or CF_API_TOKEN.",
            ),
        },
        _ => {
            if !req.probe.is_empty() {
                resolver.spawns.set(resolver.spawns.get() + 1);
                let args: Vec<_> = req.probe.iter().skip(1).map(String::as_str).collect();
                if !wf_core::proc::run(&req.probe[0], &args, Duration::from_secs(8))
                    .is_ok_and(|o| o.ok())
                {
                    return finding(
                        req,
                        "CRED-INVALID",
                        Severity::Fail,
                        "The configured credential probe failed.",
                    );
                }
            } else if token.is_none() {
                return finding(
                    req,
                    "CRED-MISSING",
                    Severity::Fail,
                    format!("No credential found for {}.", req.id),
                );
            }
            if !req.capabilities.is_empty() {
                finding(req,"CRED-OPAQUE",Severity::Warn,format!("Credential is present; capabilities {} cannot be introspected for this provider.",req.capabilities.join(", ")))
            } else {
                finding(
                    req,
                    "CRED-OK",
                    Severity::Note,
                    "Credential is present or its configured probe succeeded.",
                )
            }
        }
    }
}

fn http_check(req: &CredReq, token: &str, url: &str) -> Finding {
    let agent: ureq::Agent = ureq::Agent::config_builder()
        .timeout_global(Some(Duration::from_secs(8)))
        .http_status_as_error(false)
        .max_redirects(0)
        .build()
        .into();
    let response = agent
        .get(url)
        .header("Authorization", &format!("Bearer {token}"))
        .header("Accept", "application/json")
        .call();
    let Ok(mut response) = response else {
        return finding(
            req,
            "CRED-OPAQUE",
            Severity::Warn,
            "Provider could not be reached; credential capabilities remain unverified.",
        );
    };
    let status = response.status().as_u16();
    if req.id == "github" || req.id == "gh" {
        return github_verdict(
            req,
            status,
            response
                .headers()
                .get("x-oauth-scopes")
                .and_then(|h| h.to_str().ok()),
        );
    }
    let value = response
        .body_mut()
        .with_config()
        .limit(65_536)
        .read_to_string()
        .ok()
        .and_then(|s| serde_json::from_str::<serde_json::Value>(&s).ok());
    if status != 200
        || !value
            .as_ref()
            .is_some_and(|v| v["success"] == true && v["result"]["status"] == "active")
    {
        return finding(
            req,
            "CRED-INVALID",
            Severity::Fail,
            "Cloudflare did not verify an active token.",
        );
    }
    if req.capabilities.is_empty() {
        finding(
            req,
            "CRED-OK",
            Severity::Note,
            "Cloudflare token is active.",
        )
    } else {
        finding(
            req,
            "CRED-OPAQUE",
            Severity::Warn,
            "Cloudflare verified token status, but does not disclose the requested permissions.",
        )
    }
}

fn github_verdict(req: &CredReq, status: u16, scopes: Option<&str>) -> Finding {
    if status == 401 || status == 403 {
        return finding(
            req,
            "CRED-INVALID",
            Severity::Fail,
            "GitHub rejected the credential.",
        );
    }
    if status != 200 {
        return finding(
            req,
            "CRED-OPAQUE",
            Severity::Warn,
            "GitHub did not return a verifiable credential response.",
        );
    }
    let Some(scopes) = scopes else {
        return if req.capabilities.is_empty() {
            finding(
                req,
                "CRED-OK",
                Severity::Note,
                "GitHub authenticated the credential.",
            )
        } else {
            finding(req,"CRED-OPAQUE",Severity::Warn,"GitHub authenticated the credential but disclosed no scope list; requested capabilities remain unverified.")
        };
    };
    let scopes: std::collections::HashSet<_> = scopes.split(',').map(str::trim).collect();
    let missing: Vec<_> = req
        .capabilities
        .iter()
        .filter(|cap| {
            if scopes.contains(cap.as_str()) {
                return false;
            }
            ![
                (
                    "repo",
                    &[
                        "repo:status",
                        "repo_deployment",
                        "public_repo",
                        "repo:invite",
                        "security_events",
                    ][..],
                ),
                ("write:packages", &["read:packages"][..]),
                ("admin:org", &["write:org", "read:org"][..]),
                ("write:org", &["read:org"][..]),
            ]
            .iter()
            .any(|(parent, children)| scopes.contains(parent) && children.contains(&cap.as_str()))
        })
        .cloned()
        .collect();
    if missing.is_empty() {
        finding(
            req,
            "CRED-OK",
            Severity::Note,
            "GitHub authenticated the credential and its required scopes.",
        )
    } else {
        let mut result = finding(
            req,
            "CRED-SCOPE",
            Severity::Fail,
            format!("GitHub token lacks {}.", missing.join(", ")),
        );
        result.fix = format!("gh auth refresh -s {}", missing.join(","));
        result
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn github_capabilities_are_proved_not_assumed() {
        let req = CredReq {
            id: "github".into(),
            capabilities: vec!["repo".into(), "workflow".into()],
            ..Default::default()
        };
        assert_eq!(
            github_verdict(&req, 200, Some("repo, workflow")).code,
            "CRED-OK"
        );
        assert_eq!(github_verdict(&req, 200, Some("repo")).code, "CRED-SCOPE");
        assert_eq!(github_verdict(&req, 200, Some("")).code, "CRED-SCOPE");
        assert_eq!(github_verdict(&req, 200, None).code, "CRED-OPAQUE");
        assert_eq!(github_verdict(&req, 401, None).code, "CRED-INVALID");
        assert_eq!(github_verdict(&req, 503, None).code, "CRED-OPAQUE");
    }
    #[test]
    fn github_scope_implications_are_respected() {
        let req = CredReq {
            id: "github".into(),
            capabilities: vec![
                "repo:status".into(),
                "read:packages".into(),
                "read:org".into(),
            ],
            ..Default::default()
        };
        assert_eq!(
            github_verdict(&req, 200, Some("repo, write:packages, admin:org")).code,
            "CRED-OK"
        );
    }
}
