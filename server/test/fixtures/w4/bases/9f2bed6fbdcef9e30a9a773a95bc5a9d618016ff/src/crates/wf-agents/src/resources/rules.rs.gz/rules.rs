//! Rules: `rules/**/*.md` in the team repository, written in each agent's rule format —
//! as authored for Claude, `.mdc` for Cursor, steering documents for Kiro.
//!
//! A rule is seeded, not imposed: once a person edits their copy it is theirs, and only a rule
//! the policy lists as enforced is restored over the edit.

use super::object::{Rendered, Shape};
use super::{files_under, ResourceHandler, ResourceItem, ResourceKind, ResourceMetadata};
use crate::formats::render_rule;
use crate::{adapter::TeamAIAdapter, registry::PathKind, team_repo::TeamRepo};
use wf_core::{Error, Result};

pub struct RulesHandler;

impl ResourceHandler for RulesHandler {
    fn kind(&self) -> ResourceKind {
        ResourceKind::Rule
    }

    fn scan_registry(&self, repo: &TeamRepo) -> Result<Vec<ResourceItem>> {
        let Some(dir) = repo.resource_dir(ResourceKind::Rule)? else {
            return Ok(vec![]);
        };
        let mut out = Vec::new();
        for rel in files_under(&dir)? {
            let Some(id) = rel.strip_suffix(".md") else {
                continue;
            };
            if id.split('/').any(|s| s.starts_with('.')) {
                return Err(Error::usage(
                    "RULE-NAME",
                    format!("{rel}: a rule name may not start with '.'"),
                ));
            }
            let source = dir.join(&rel);
            let bytes = std::fs::read(&source)?;
            if std::str::from_utf8(&bytes).is_err() {
                return Err(Error::usage(
                    "RULE-UTF8",
                    format!("{rel} is not UTF-8 text"),
                ));
            }
            out.push(ResourceItem {
                id: id.to_string(),
                name: id.to_string(),
                kind: ResourceKind::Rule,
                version: None,
                source,
                metadata: ResourceMetadata {
                    content_hash: wf_core::hash::sha256_bytes(&bytes),
                    ..Default::default()
                },
            });
        }
        Ok(out)
    }

    fn render(&self, item: &ResourceItem, agent: &dyn TeamAIAdapter) -> Result<Option<Rendered>> {
        let (Some(format), Some(dir)) = (agent.formats().rule, agent.path(PathKind::Rules)) else {
            return Ok(None);
        };
        let text = std::fs::read_to_string(&item.source)?;
        let (ext, rendered) = render_rule(format, &text);
        Ok(Some(Rendered::File {
            path: dir.join(format!("{}.{ext}", item.id)),
            bytes: rendered.into_bytes(),
        }))
    }

    fn shape(&self, agent: &dyn TeamAIAdapter) -> Option<Shape> {
        agent.path(PathKind::Rules)?;
        self.stored_shape(agent)
    }

    fn stored_shape(&self, agent: &dyn TeamAIAdapter) -> Option<Shape> {
        agent.formats().rule?;
        Some(Shape::File)
    }
}
