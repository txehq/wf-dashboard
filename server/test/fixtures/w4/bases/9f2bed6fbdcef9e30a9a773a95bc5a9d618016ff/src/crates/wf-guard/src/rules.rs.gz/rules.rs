use crate::{f, quote, Finding, RULES_PATH};
use serde::Deserialize;
use std::collections::{BTreeMap, BTreeSet};
use std::path::Path;
use wf_core::Result;

/// `docs/contract/rules.yaml` — the rule and claim registry.
#[derive(Debug, Deserialize)]
pub struct Rules {
    #[serde(default)]
    pub version: u32,
    #[serde(default)]
    pub rules: Vec<Rule>,
    #[serde(default)]
    pub claims: Vec<Claim>,
}

#[derive(Debug, Deserialize)]
pub struct Rule {
    pub id: String,
    #[serde(default)]
    pub summary: String,
    #[serde(default)]
    pub home: String,
    #[serde(default)]
    pub origin: String,
    /// A rule replaced by a later decision keeps its row and its history; what it loses is
    /// its power to constrain. Recording that is the difference between a rule that was
    /// reconsidered and one that was quietly deleted.
    #[serde(default)]
    pub superseded_by: String,
}

#[derive(Debug, Deserialize)]
pub struct Claim {
    pub id: String,
    #[serde(default)]
    pub statement: String,
    #[serde(default)]
    pub verified: String,
    #[serde(default)]
    pub recipe: String,
}

impl Rules {
    pub fn load(root: &Path) -> Result<Self> {
        let p = root.join(RULES_PATH);
        let text = std::fs::read_to_string(&p)
            .map_err(|e| wf_core::Error::usage("GUARD-RULES", format!("{}: {e}", p.display())))?;
        serde_yaml_ng::from_str(&text)
            .map_err(|e| wf_core::Error::usage("GUARD-RULES", format!("{}: {e}", p.display())))
    }
}

/// Every rule resolves to a heading in its declared home.
pub fn check_rules(root: &Path, rules: &Rules) -> Result<Vec<Finding>> {
    let rule_re = regex::Regex::new(r"^WFR-\d{3}$").unwrap();
    let mut out = Vec::new();
    let mut seen = BTreeSet::new();
    let mut cache: BTreeMap<String, BTreeSet<String>> = BTreeMap::new();

    for r in &rules.rules {
        if !rule_re.is_match(&r.id) {
            out.push(f(
                "RUL002",
                RULES_PATH,
                format!("rule id {} is not of the form WFR-NNN", quote(&r.id)),
            ));
        }
        if !seen.insert(r.id.clone()) {
            out.push(f(
                "RUL003",
                RULES_PATH,
                format!("rule id {} is declared twice", quote(&r.id)),
            ));
        }
        let Some((file, anchor)) = r.home.split_once('#') else {
            out.push(f(
                "RUL001",
                RULES_PATH,
                format!(
                    "{}: home {} is not of the form <file>#<anchor>",
                    r.id,
                    quote(&r.home)
                ),
            ));
            continue;
        };
        if file.is_empty() || anchor.is_empty() {
            out.push(f(
                "RUL001",
                RULES_PATH,
                format!(
                    "{}: home {} is not of the form <file>#<anchor>",
                    r.id,
                    quote(&r.home)
                ),
            ));
            continue;
        }
        if !cache.contains_key(file) {
            match crate::registry::anchors(&root.join(file)) {
                Ok(a) => {
                    cache.insert(file.to_string(), a);
                }
                Err(_) => {
                    out.push(f(
                        "RUL001",
                        file,
                        format!("{}: home file cannot be read", r.id),
                    ));
                    cache.insert(file.to_string(), BTreeSet::new());
                    continue;
                }
            }
        }
        if !cache[file].contains(anchor) {
            out.push(f(
                "RUL001",
                file,
                format!(
                    "{}: no heading resolves anchor #{anchor} — the rule has lost its home",
                    r.id
                ),
            ));
        }
        // A supersession has to name something.
        if !r.superseded_by.is_empty()
            && !r.superseded_by.starts_with("ADR-")
            && !rule_re.is_match(&r.superseded_by)
        {
            out.push(f(
                "RUL004",
                RULES_PATH,
                format!(
                    "{}: superseded_by {} names neither an ADR nor a rule",
                    r.id,
                    quote(&r.superseded_by)
                ),
            ));
        }
    }
    Ok(out)
}

/// A behavioural claim expires. WFR-005's sharper sibling: a claim about how something
/// outside this repository behaves is a measurement, and measurements go stale faster than
/// prose does.
pub fn check_claims(rules: &Rules, p: &crate::registry::Policy, now: time::Date) -> Vec<Finding> {
    let mut out = Vec::new();
    for c in &rules.claims {
        if c.recipe.trim().is_empty() {
            out.push(f(
                "CLM002",
                RULES_PATH,
                format!(
                    "{}: no re-verification recipe — a claim nobody can re-measure is folklore",
                    c.id
                ),
            ));
        }
        let Some(d) = crate::registry::parse_date(&c.verified) else {
            out.push(f(
                "CLM001",
                RULES_PATH,
                format!(
                    "{}: verified date {} is not YYYY-MM-DD",
                    c.id,
                    quote(&c.verified)
                ),
            ));
            continue;
        };
        let age = (now - d).whole_days();
        if age > p.claim_max_age_days {
            out.push(f(
                "CLM001",
                RULES_PATH,
                format!(
                    "{}: verified {}, {age} days ago (max {}) — re-run its recipe or drop the claim",
                    c.id, c.verified, p.claim_max_age_days
                ),
            ));
        }
    }
    out
}
