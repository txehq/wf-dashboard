use crate::status::{AgentRow, ComponentRow, Status};
use serde::Serialize;
use std::path::{Path, PathBuf};
use std::time::Duration;
use wf_agents::adapter::{Desired, ObjectStatus, TeamAIAdapter, MACHINE_ID};
use wf_agents::engine::{AgentOutcome, Context, RunOutcome};
use wf_agents::resources::ResourceKind;
use wf_agents::{Finding, Severity};
use wf_core::{Error, Result};
use wf_registry::{Kind, Registry};
use wf_release::{bundle, source::ReleaseSource, Channel, Lock};
use wf_state::{
    ComponentState, Db, DriftKind, Generation, GenerationStatus, SkippedMcp, Transaction,
};

#[derive(Debug, Clone)]
pub struct Options {
    pub repo: String,
    pub branch: String,
    pub channel: Channel,
    pub source: ReleaseSource,
    pub dry_run: bool,
    /// Skip the network entirely and work from what is already on the machine.
    pub offline: bool,
    /// Check the remote even if one is not due. `wf sync` from a person means "now".
    pub force: bool,
    /// Which agents to touch: `all`, or ids and aliases. `None` means the agents this
    /// machine has registered — or, before any registration exists, the first-party two.
    pub agents: Option<String>,
    /// Wall-clock ceiling for anything that touches the network.
    pub remote_timeout: Duration,
}

impl Options {
    pub fn defaults() -> Self {
        Self {
            repo: wf_core::DEFAULT_REPO.to_string(),
            branch: wf_core::DEFAULT_BRANCH.to_string(),
            channel: Channel::Stable,
            source: ReleaseSource::GitHub {
                repo: wf_core::DEFAULT_REPO.to_string(),
                branch: wf_core::DEFAULT_BRANCH.to_string(),
            },
            dry_run: false,
            offline: false,
            force: false,
            agents: None,
            remote_timeout: Duration::from_secs(60),
        }
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct SyncOutcome {
    pub changed: bool,
    /// Components the agent's own manager did not bring current. The rest of the sync
    /// still applied; these are retryable.
    #[serde(skip_serializing_if = "Vec::is_empty", default)]
    pub degraded: Vec<String>,
    pub active_version: String,
    pub desired_version: String,
    pub applied: Vec<String>,
    pub backups: Vec<String>,
    pub rolled_back: bool,
    pub dry_run: bool,
    pub plan: Vec<wf_state::tx::PlanStep>,
    pub warnings: Vec<String>,
    pub followups: Vec<String>,
    /// What each agent looked like when the apply finished.
    #[serde(skip_serializing_if = "Vec::is_empty", default)]
    pub agents: Vec<AgentOutcome>,
    /// Servers this machine already reached **before this apply wrote anything**. Read out
    /// of the generation about to be applied, against the documents as they stood, so the
    /// answer cannot be contaminated by what the same run is in the middle of writing.
    #[serde(skip_serializing_if = "Vec::is_empty", default)]
    pub candidates: Vec<wf_agents::resources::mcp::Candidate>,
}

pub struct Engine {
    pub paths: wf_core::paths::Paths,
    pub db: Db,
    pub opts: Options,
    staged_plans: std::cell::RefCell<Vec<tempfile::TempDir>>,
}

/// The binary that last applied a generation. A binary that finds an older one there knows
/// its own logic has not run yet — the updater that installed it was the previous binary.
pub const META_LAST_APPLIED_BINARY: &str = "last_applied_binary";

impl Engine {
    pub fn open(opts: Options) -> Result<Self> {
        let paths = wf_core::paths::Paths::resolve()?;
        let db = if opts.dry_run {
            Db::open_read_only(&paths.db())?
        } else {
            paths.ensure_dirs()?;
            Db::open(&paths.db())?
        };
        Ok(Self {
            paths,
            db,
            opts,
            staged_plans: Default::default(),
        })
    }

    /// The directory holding the currently active generation's expanded bundle.
    pub fn active_bundle_dir(&self) -> Option<PathBuf> {
        let g = self.db.active_generation().ok().flatten()?;
        let d = self.paths.generation(&g.version).join("bundle");
        d.is_dir().then_some(d)
    }

    fn registry_of(&self, bundle_dir: &std::path::Path) -> Result<Registry> {
        Registry::load(bundle_dir)
    }

    fn source_key(&self) -> String {
        self.opts.source.describe()
    }

    /// Every lifecycle writer shares this lock. Hook writers use a nonblocking attempt.
    pub fn lifecycle_lock(&self, from_hook: bool) -> Result<Option<wf_core::lock::Guard>> {
        if self.opts.dry_run {
            return Ok(None);
        }
        let guard = if from_hook {
            wf_core::lock::Guard::try_exclusive(&self.paths.lock_file())
        } else {
            wf_core::lock::Guard::exclusive_within(&self.paths.lock_file(), 30_000)
        };
        guard.map(Some)
    }

    pub fn remote_key(&self) -> String {
        format!(
            "{}:{}:{}",
            self.source_key(),
            self.opts.branch,
            self.opts.channel.as_str()
        )
    }

    /// Call only while holding the lifecycle lock, after validating a hook's source.
    pub fn record_remote_result(&self, desired: Option<&wf_release::ReleaseRef>) -> Result<()> {
        if self.opts.dry_run || self.opts.offline {
            return Ok(());
        }
        self.db.note_remote_check(
            &self.remote_key(),
            desired.is_some(),
            desired.map(|r| r.tag.as_str()).unwrap_or(""),
            900,
        )
    }

    pub fn source_still_current(&self) -> Result<bool> {
        Ok(self.db.installation()?.is_some_and(|record| {
            record.source == self.source_key()
                && record.channel == self.opts.channel.as_str()
                && record.branch == self.opts.branch
        }))
    }

    // --- resolve and stage --------------------------------------------------------

    /// Ask the remote what the newest release is, under a deadline.
    ///
    /// Any failure returns `Ok(None)` with a warning rather than an error: a session start
    /// that fails because GitHub is slow is a worse outcome than one running last week's
    /// skills. Only integrity failures propagate, and they never reach here.
    pub fn resolve_desired(&self) -> (Option<wf_release::ReleaseRef>, Vec<String>) {
        let mut warnings = Vec::new();
        if self.opts.offline {
            return (None, warnings);
        }
        match bundle::resolve(
            &self.opts.source,
            self.opts.channel,
            self.opts.remote_timeout,
        ) {
            Ok(Some(r)) => (Some(r), warnings),
            Ok(None) => {
                warnings.push(wf_core::zh::no_release(
                    &self.opts.repo,
                    self.opts.channel.as_str(),
                ));
                (None, warnings)
            }
            Err(e) => {
                warnings.push(if e.zh.is_empty() {
                    e.message.clone()
                } else {
                    e.zh.clone()
                });
                (None, warnings)
            }
        }
    }

    /// Download, verify and stage a release into its generation directory.
    ///
    /// The generation directory is built under a staging name and renamed into place, so a
    /// crash mid-download cannot leave a directory that looks like a complete generation.
    pub fn stage(&self, rel: &wf_release::ReleaseRef) -> Result<(Lock, PathBuf)> {
        validate_version_path(&rel.version)?;
        let final_dir = self.paths.generation(&rel.version);
        if final_dir.exists() {
            let lock = self.verify_generation(&rel.version, &final_dir)?;
            if self
                .db
                .generations()?
                .iter()
                .any(|g| g.version == rel.version && g.source != self.source_key())
            {
                return Err(Error::conflict(
                    "GENERATION-SOURCE",
                    "this version is already staged from a different source",
                ));
            }
            // A generation directory is named for its version, so a version already staged
            // is reused rather than fetched again. That is only sound while a version means
            // one set of bytes. A `local:` source is a directory somebody can rewrite in
            // place — during development they do, rebuilding the same version with
            // different content — and reusing the stale generation there reported a
            // successful update while quietly applying the old bundle. A published GitHub
            // release cannot change under us, so the question is only worth asking, and
            // only cheap to ask, here: it is one file read of the source's own lock.
            if let ReleaseSource::Local { dir } = &self.opts.source {
                if let Ok((_, offered)) = wf_release::source::resolve_local(dir) {
                    if offered.bundle.sha256 != lock.bundle.sha256 {
                        return Err(Error::conflict(
                            "GENERATION-CONTENT",
                            "this version is already staged from different content",
                        )
                        .with_zh(format!(
                            "本地源里的 {} 和已经装好的那一份内容不一样，没有改动任何东西。\n  请把版本号往上加一位再重新构建一次。",
                            rel.version
                        )));
                    }
                }
            }
            return Ok((lock, final_dir));
        }
        let work = if self.opts.dry_run {
            tempfile::tempdir()?
        } else {
            tempfile::Builder::new()
                .prefix("release-")
                .tempdir_in(self.paths.staging())?
        };
        let fetched = bundle::fetch(rel, work.path(), self.opts.remote_timeout)?;
        let staged = work.path().join("generation");
        std::fs::create_dir(&staged)?;
        std::fs::rename(&fetched.bundle_dir, staged.join("bundle"))?;
        wf_core::atomic::write_file(
            &staged.join("workflow.lock.json"),
            fetched.lock.render().as_bytes(),
        )?;
        // Local sources belong to the caller. Copy an asset rather than moving it out of
        // the release directory (which also made a second install fail).
        if let Some(binary) = &fetched.binary {
            std::fs::copy(binary, staged.join("wf-binary.tar.gz"))?;
        }
        if self.opts.dry_run {
            self.staged_plans.borrow_mut().push(work);
            return Ok((fetched.lock, staged));
        }
        std::fs::rename(&staged, &final_dir)?;
        wf_core::atomic::sync_dir(final_dir.parent().expect("generation parent"))?;
        self.db.record_generation(&Generation {
            version: rel.version.clone(),
            tag: rel.tag.clone(),
            source_commit: fetched.lock.source_commit.clone(),
            status: GenerationStatus::Staged,
            activated_at: None,
            source: self.source_key(),
            attested: fetched.attested,
        })?;
        Ok((fetched.lock, final_dir))
    }

    fn verify_generation(&self, version: &str, dir: &Path) -> Result<Lock> {
        validate_version_path(version)?;
        let lock = Lock::parse(&std::fs::read_to_string(dir.join("workflow.lock.json"))?)?;
        if lock.release_version != version
            || wf_core::hash::tree_digest(&dir.join("bundle"))? != lock.bundle.tree_sha256
        {
            return Err(Error::integrity(
                "GENERATION-INTEGRITY",
                "staged generation does not match its lock",
            ));
        }
        let asset = dir.join("wf-binary.tar.gz");
        match lock.binary_for(wf_core::paths::target_triple()) {
            Some(binary)
                if !asset.is_file() || wf_core::hash::sha256_file(&asset)? != binary.sha256 =>
            {
                return Err(Error::integrity(
                    "BINARY-INTEGRITY",
                    "staged binary is missing or differs from its lock",
                ))
            }
            None if asset.exists() => {
                return Err(Error::integrity(
                    "BINARY-UNDECLARED",
                    "staged binary is not covered by the lock",
                ))
            }
            _ => {}
        }
        Ok(lock)
    }

    /// The agent layer's view of a generation on this machine.
    pub fn context(&self, bundle_dir: &Path) -> Result<Context> {
        Context::load(bundle_dir, &self.paths)
    }

    /// Keep file and native compensations alive through publication of the active
    /// generation, installation record, ownership receipts and resource rows.
    pub fn apply(&self, version: &str, generation_dir: &Path) -> Result<SyncOutcome> {
        self.apply_generation(version, generation_dir, false)
    }

    /// The same application, preceded by the one question only a first install asks: what
    /// this machine already reaches for each server we are about to write. Update, repair
    /// and rollback go through `apply` and ask nothing, so a connection that appeared after
    /// the install cannot quietly change what a later run does.
    pub fn install(&self, version: &str, generation_dir: &Path) -> Result<SyncOutcome> {
        self.apply_generation(version, generation_dir, true)
    }

    fn apply_generation(
        &self,
        version: &str,
        generation_dir: &Path,
        survey: bool,
    ) -> Result<SyncOutcome> {
        let lock = self.verify_generation(version, generation_dir)?;
        let bundle_dir = generation_dir.join("bundle");
        refuse_pre_agents_generation(version, &bundle_dir)?;
        let registry = self.registry_of(&bundle_dir)?;
        let ctx = self.context(&bundle_dir)?;
        let adapters =
            wf_agents::engine::select_agents(&ctx, &self.db, self.opts.agents.as_deref())?;
        let mut tx = Transaction::begin(&self.db, self.paths.backups(), version, self.opts.dry_run);
        let mut run = RunOutcome::default();
        // Asked before the first write: what this machine already reaches for each server we
        // are about to install. The answer is the same on a dry run, which is what makes it
        // testable without building a release.
        let candidates = if survey {
            wf_agents::resources::mcp::candidates(&Desired::scan(&ctx.repo), &adapters, &self.db)?
        } else {
            Vec::new()
        };
        let attempt = (|| -> Result<()> {
            self.prepare_binary(&lock, generation_dir, &mut tx)?;
            run = wf_agents::engine::apply(&ctx, &adapters, &mut tx)?;
            Ok(())
        })();
        let plan = tx.plan.clone();
        let mut warnings = tx.warnings.clone();
        warnings.extend(run.warnings.clone());
        if let Err(error) = attempt {
            warnings.push(error.message);
            let out = tx.rollback();
            return Ok(SyncOutcome {
                changed: false,
                degraded: vec![],
                active_version: self
                    .db
                    .active_generation()?
                    .map(|g| g.version)
                    .unwrap_or_default(),
                desired_version: version.into(),
                applied: vec![],
                backups: out.backups,
                rolled_back: true,
                dry_run: self.opts.dry_run,
                plan,
                warnings,
                followups: out.manual_followups,
                agents: vec![],
                candidates,
            });
        }
        let degraded: Vec<String> = run
            .agents
            .iter()
            .flat_map(|a| a.state.objects.iter())
            .filter(|o| matches!(o.status, ObjectStatus::Conflict | ObjectStatus::Blocked))
            .map(|o| o.component_id.clone())
            .collect();
        // Worked out before the commit: asking Codex about trust starts its app server, and the
        // commit holds the database's write lock, which every hook in every session waits on.
        let states = if self.opts.dry_run {
            vec![]
        } else {
            self.component_states(&registry, &bundle_dir, &ctx, &run)?
        };
        let out = tx.commit_with(|tx| {
            self.db.activate(version)?;
            self.db.set_meta("desired_version", version)?;
            // What ctx this release pins, for the session-start check that converges it
            // separately (crate::ctx). Empty means "pins nothing": nothing to converge.
            self.db.set_meta(
                crate::ctx::DESIRED,
                &crate::ctx::desired_key(&lock.ctx_upstream, wf_core::paths::target_triple())
                    .unwrap_or_default(),
            )?;
            tx.swap_symlink(&self.paths.active_link(), Some(generation_dir))?;
            // Control passing to an older release: its binary is the one that reads these rows.
            // `ComponentState`'s vocabulary only ever grows, and `parse` turns a word an older
            // `wf` does not know into `Blocked` — a session-stopping verdict about a component
            // that is fine, reached by the command someone runs *because* something is already
            // wrong. Leave silence instead; the release taking over records its own.
            let downgrade = self
                .db
                .meta("last_applied_version")?
                .as_deref()
                .and_then(wf_release::lock::semver_triple)
                .zip(wf_release::lock::semver_triple(version))
                .is_some_and(|(was, now)| now < was);
            if downgrade {
                self.db.forget_components()?;
            } else {
                for outcome in run.agents.iter().filter(|a| a.installed) {
                    self.db.forget_components_of(&outcome.agent)?;
                }
                for row in &states {
                    self.set_state(&row.id, &row.agent, row.state, &row.hash, &row.detail)?;
                }
            }
            self.db.set_meta("last_applied_version", version)?;
            self.db
                .set_meta(META_LAST_APPLIED_BINARY, wf_core::VERSION)?;
            wf_agents::engine::register_detected(&ctx, &self.db, &adapters)?;
            self.db.record_team_repo_state(&wf_state::TeamRepoState {
                mode: ctx.repo.config().team.repo_mode.as_str().to_string(),
                remote_url: None,
                last_pull_rev: None,
                last_pull_time: None,
                last_sync_time: Some(wf_core::time_fmt::now_utc_millis()),
                metadata: serde_json::json!({"version": version}),
            })?;
            self.db.record_installation(
                &wf_state::Installation {
                    channel: self.opts.channel.as_str().into(),
                    version: version.into(),
                    repo: self.opts.repo.clone(),
                    branch: self.opts.branch.clone(),
                    source: self.source_key(),
                },
                if self.opts.source.is_local() {
                    "local"
                } else {
                    "github-release"
                },
                wf_core::paths::target_triple(),
            )?;
            Ok(())
        })?;
        let mut applied = run.applied.clone();
        applied.extend(out.applied);
        applied.sort();
        applied.dedup();
        let mut degraded = degraded;
        degraded.sort();
        degraded.dedup();
        Ok(SyncOutcome {
            changed: !applied.is_empty() || run.agents.iter().any(|a| !a.retired.is_empty()),
            degraded,
            active_version: version.into(),
            desired_version: version.into(),
            applied,
            backups: out.backups,
            rolled_back: false,
            dry_run: self.opts.dry_run,
            plan,
            warnings,
            followups: out.manual_followups,
            agents: run.agents,
            candidates,
        })
    }

    fn prepare_binary(
        &self,
        lock: &Lock,
        generation_dir: &Path,
        tx: &mut Transaction<'_>,
    ) -> Result<()> {
        if lock.binary_for(wf_core::paths::target_triple()).is_none() {
            return Ok(());
        }
        let asset = generation_dir.join("wf-binary.tar.gz");
        let staging = tempfile::tempdir()?;
        let unpacked = staging.path().join("binary");
        wf_release::archive::extract_tar_gz(
            &asset,
            &unpacked,
            wf_release::archive::Limits {
                max_files: 4,
                max_file_bytes: 128 * 1024 * 1024,
                max_total_bytes: 256 * 1024 * 1024,
            },
        )?;
        let candidate = unpacked.join("wf");
        if !candidate.is_file() {
            return Err(Error::integrity(
                "BINARY-SHAPE",
                "binary archive contains no wf executable",
            ));
        }
        let installed = self.paths.binary();
        let bytes = std::fs::read(&candidate)?;
        if installed.is_file()
            && wf_core::hash::sha256_file(&installed)? == wf_core::hash::sha256_bytes(&bytes)
        {
            return Ok(());
        }
        // A plan may validate hostile archives, but must never execute their contents.
        if tx.is_dry_run() {
            tx.note_plan(
                "capso.wf.binary",
                "replace verified binary",
                &installed.to_string_lossy(),
                &lock.release_version,
            );
            return Ok(());
        }
        set_executable(&candidate)?;
        if running_version(&candidate)? != lock.release_version {
            return Err(Error::integrity(
                "BINARY-VERSION-MISMATCH",
                "candidate binary disagrees with its release version",
            ));
        }
        tx.ensure_directory(&self.paths.bin_dir)?;
        tx.write_file("capso.wf.binary", "", &installed, &bytes)?;
        set_executable(&installed)?;
        if running_version(&installed)? != lock.release_version {
            return Err(Error::integrity(
                "BINARY-POST-VERIFY",
                "installed binary disagrees with its release version",
            ));
        }
        Ok(())
    }

    /// For every agent the run touched, the state of every registry component and team
    /// resource that reaches it.
    fn component_states(
        &self,
        reg: &Registry,
        bundle_dir: &Path,
        ctx: &Context,
        run: &RunOutcome,
    ) -> Result<Vec<StateRow>> {
        let mut rows = Vec::new();
        let skipped = self.db.skipped_mcps()?;
        for outcome in run.agents.iter().filter(|a| a.installed) {
            let adapter = ctx.agents.find(&outcome.agent).map(|s| ctx.adapter(s));
            for component in &reg.components {
                let Some(state) = component_state(component, outcome, adapter.as_ref(), &skipped)?
                else {
                    continue;
                };
                rows.push(StateRow {
                    id: component.id.clone(),
                    agent: outcome.agent.clone(),
                    state: state.state,
                    hash: source_hash(component, bundle_dir)?,
                    detail: state.detail,
                });
            }
            for object in team_objects(outcome) {
                let (state, detail) = object_state(&[object]);
                rows.push(StateRow {
                    id: object.component_id.clone(),
                    agent: outcome.agent.clone(),
                    state,
                    hash: String::new(),
                    detail,
                });
            }
        }
        Ok(rows)
    }

    fn set_state(
        &self,
        id: &str,
        agent: &str,
        state: ComponentState,
        hash: &str,
        detail: &str,
    ) -> Result<()> {
        // The files are in place for both: what `unverified` withholds is the login, not the
        // installation. A drift is repaired once the files are back, whatever the login says.
        let in_place = matches!(state, ComponentState::Current | ComponentState::Unverified);
        let installed = if in_place { hash } else { "" };
        self.db
            .set_component(id, agent, state, hash, installed, detail)?;
        if state == ComponentState::Drifted {
            self.db
                .record_drift(id, agent, DriftKind::Modified, detail)?;
        } else if in_place {
            self.db.mark_drift_repaired(id)?;
        }
        Ok(())
    }

    // --- status --------------------------------------------------------------------

    pub fn status(&self) -> Result<Status> {
        let active = self.db.active_generation()?;
        let active_version = active
            .as_ref()
            .map(|g| g.version.clone())
            .unwrap_or_default();
        let attested = active.as_ref().map(|g| g.attested).unwrap_or(false);
        let source = active
            .as_ref()
            .map(|g| g.source.clone())
            .unwrap_or_else(|| self.source_key());

        let policy = self
            .active_bundle_dir()
            .map(|d| wf_hooks::Policy::load(&d))
            .unwrap_or_default();
        let stale_seconds = self.db.stale_age(&self.remote_key())?;
        let stale = stale_seconds.is_none_or(|s| s > policy.budgets.stale_warn_after_days * 86_400);

        let mut warnings = Vec::new();
        if !attested && !active_version.is_empty() {
            warnings.push(
                "当前这个版本是从本地构建安装的，没有经过 GitHub 的发布校验。正式使用前请安装正式版本。".to_string(),
            );
        }
        if stale && !active_version.is_empty() {
            let days = stale_seconds.map(|s| s / 86_400).unwrap_or(0);
            warnings.push(wf_core::zh::stale_too_long(days));
        }

        let mut agents = Vec::new();
        let mut components: Vec<ComponentRow> = Vec::new();
        if let Some(bd) = self.active_bundle_dir() {
            match self.context(&bd) {
                Ok(ctx) => {
                    let registry = self.registry_of(&bd)?;
                    let adapters = wf_agents::engine::select_agents(
                        &ctx,
                        &self.db,
                        self.opts.agents.as_deref(),
                    )?;
                    let skipped = self.db.skipped_mcps()?;
                    for outcome in wf_agents::engine::inspect(&ctx, &adapters, &self.db)? {
                        let adapter = ctx.agents.find(&outcome.agent).map(|s| ctx.adapter(s));
                        let mut hook_trusted = None;
                        if outcome.installed {
                            for component in &registry.components {
                                let Some(state) = component_state(
                                    component,
                                    &outcome,
                                    adapter.as_ref(),
                                    &skipped,
                                )?
                                else {
                                    continue;
                                };
                                if state.trusted.is_some() {
                                    hook_trusted = state.trusted;
                                }
                                // Anything unhealthy, and separately anything a person
                                // declined — the second is `current` and so would never
                                // reach this list on state alone, but somebody asking
                                // `wf doctor` what is on their machine is owed the line.
                                if state.state != ComponentState::Current
                                    || state.skipped_at.is_some()
                                {
                                    components.push(ComponentRow {
                                        id: component.id.clone(),
                                        kind: component.kind.as_str().into(),
                                        agent: outcome.agent.clone(),
                                        state: state.state.as_str().into(),
                                        detail: state.detail,
                                        zh: state.zh,
                                        skipped_at: state.skipped_at,
                                    });
                                }
                            }
                            for object in team_objects(&outcome) {
                                let (state, detail) = object_state(&[object]);
                                if state != ComponentState::Current {
                                    components.push(ComponentRow {
                                        id: object.component_id.clone(),
                                        kind: object.kind.as_str().into(),
                                        agent: outcome.agent.clone(),
                                        state: state.as_str().into(),
                                        detail,
                                        zh: String::new(),
                                        skipped_at: None,
                                    });
                                }
                            }
                            for finding in outcome
                                .state
                                .findings
                                .iter()
                                .filter(|f| f.code == "RESOURCE-SCAN")
                            {
                                components.push(ComponentRow {
                                    id: format!("team.{}", finding.subject),
                                    kind: finding.subject.clone(),
                                    agent: outcome.agent.clone(),
                                    state: ComponentState::Blocked.as_str().into(),
                                    detail: finding.message.clone(),
                                    zh: finding.zh.clone(),
                                    skipped_at: None,
                                });
                            }
                        }
                        if outcome.agent == MACHINE_ID {
                            continue;
                        }
                        let objects = &outcome.state.objects;
                        agents.push(AgentRow {
                            agent: outcome.agent.clone(),
                            display_name: outcome.state.display_name.clone(),
                            installed: outcome.installed,
                            current: objects.iter().filter(|o| o.status.is_settled()).count(),
                            total: objects.len(),
                            effective_prompt_file: objects
                                .iter()
                                .find(|o| o.kind == ResourceKind::Prompt)
                                .and_then(|o| o.placement.as_deref())
                                .map(|p| {
                                    wf_agents::resources::object::Placement::parse(p)
                                        .path
                                        .to_string_lossy()
                                        .into_owned()
                                })
                                .unwrap_or_default(),
                            hook_trusted,
                        });
                    }
                }
                Err(e) => warnings.push(if e.zh.is_empty() { e.message } else { e.zh }),
            }
        }

        // Recorded states from the last apply, for components nothing reported on. A row for
        // an agent outside this run's `--agent` selection is not this run's answer: folding
        // it in would let a fault recorded against one agent decide the verdict about another.
        let selected = |agent: &str| {
            self.opts.agents.is_none() || agents.iter().any(|a: &AgentRow| a.agent == agent)
        };
        for (id, agent, state, detail) in self.db.components()? {
            if !selected(&agent)
                || components.iter().any(|c| c.id == id && c.agent == agent)
                || agents
                    .iter()
                    .any(|a: &AgentRow| a.agent == agent && a.installed)
            {
                continue;
            }
            components.push(ComponentRow {
                id,
                kind: String::new(),
                agent,
                state: state.as_str().into(),
                detail,
                zh: String::new(),
                skipped_at: None,
            });
        }
        // ctx is the machine's, not an agent's, and the agent layer never reports on it. A
        // recorded failure is a row, so the verdict above it cannot read 一切正常 while every
        // session's history search is broken; a convergence under way is a line of its own.
        match self.ctx_state()? {
            Some((ComponentState::Blocked, zh)) => components.push(ComponentRow {
                id: crate::ctx::COMPONENT.into(),
                kind: "binary".into(),
                agent: MACHINE_ID.into(),
                state: ComponentState::Blocked.as_str().into(),
                detail: String::new(),
                zh,
                skipped_at: None,
            }),
            Some((_, zh)) => warnings.push(zh),
            None => {}
        }
        components.sort_by(|a, b| {
            (a.id.as_str(), a.agent.as_str()).cmp(&(b.id.as_str(), b.agent.as_str()))
        });

        let store = wf_state::backup::Store::new(&self.db, self.paths.backups());
        let backups = store.list().map(|v| v.len()).unwrap_or(0);

        let healthy = !active_version.is_empty()
            && components
                .iter()
                .all(|c| ComponentState::parse(&c.state).is_healthy());

        let (channel, repo, branch) = match self.db.installation()? {
            Some(rec) => (rec.channel, rec.repo, rec.branch),
            None => (
                self.opts.channel.as_str().to_string(),
                self.opts.repo.clone(),
                self.opts.branch.clone(),
            ),
        };

        Ok(Status {
            active_version: active_version.clone(),
            desired_version: self.db.meta("desired_version")?.unwrap_or(active_version),
            channel,
            source,
            repo,
            branch,
            attested,
            platform: wf_core::paths::target_triple().into(),
            stale_seconds,
            stale,
            reload_required: false,
            healthy,
            agents,
            components,
            warnings,
            backups,
        })
    }
}

/// A generation from before the agent layer carries the plugin package and no TeamAI
/// configuration. Applying it would leave a machine with copied skills *and* a plugin — the
/// 1.x binary that reads it re-installs the plugin — so it is refused by name.
fn refuse_pre_agents_generation(version: &str, bundle_dir: &Path) -> Result<()> {
    if bundle_dir.join("plugins/magi").is_dir() && !bundle_dir.join("workflow/teamai").is_dir() {
        return Err(Error::unsupported(
            "GENERATION-PREDATES-AGENTS",
            format!(
                "{version} delivers skills as a plugin; applying it over the agent layer would install every skill twice"
            ),
        )
        .with_zh(format!(
            "{version} 是 2.0 之前用插件分发技能的版本，不能从 2.0 起的版本直接回退过去。需要的话先运行 `wf uninstall --yes`，再单独安装那个版本。"
        )));
    }
    Ok(())
}

/// One row `apply` records, worked out before the commit.
struct StateRow {
    id: String,
    agent: String,
    state: ComponentState,
    hash: String,
    detail: String,
}

/// One component's recorded state for one agent, and what status says about it.
struct StateOfComponent {
    state: ComponentState,
    detail: String,
    zh: String,
    /// Codex's verdict on the session-start dispatcher, when this is it.
    trusted: Option<bool>,
    /// When a person declined this server, if they did. The state beside it is `current` —
    /// the machine is as they asked — and this is what lets `doctor` say so in its own words
    /// instead of reporting an installation that is not there.
    skipped_at: Option<String>,
}

/// The objects that came from the team repository rather than the registry.
fn team_objects(outcome: &AgentOutcome) -> impl Iterator<Item = &wf_agents::ObjectState> {
    outcome
        .state
        .objects
        .iter()
        .filter(|o| o.component_id.starts_with("team."))
}

/// The worst standing among a component's objects.
fn object_state(objects: &[&wf_agents::ObjectState]) -> (ComponentState, String) {
    let mut out = (ComponentState::Current, String::new());
    for o in objects {
        let state = match o.status {
            // A declined server is current: the machine is exactly as the person asked for
            // it. What sets it apart from the rest of `current` is the skip row, which is
            // what `doctor` reads to give it its own line rather than claiming it is
            // installed. Keeping it inside this vocabulary is deliberate — an older `wf`
            // reading these rows turns a word it does not know into `Blocked`, which would
            // stop a session over a component nobody has a problem with.
            ObjectStatus::Current
            | ObjectStatus::Kept
            | ObjectStatus::Skipped
            | ObjectStatus::SkippedByUser => ComponentState::Current,
            ObjectStatus::Missing
            | ObjectStatus::Outdated
            | ObjectStatus::Drifted
            | ObjectStatus::Stale => ComponentState::Drifted,
            ObjectStatus::Conflict | ObjectStatus::Blocked => ComponentState::Blocked,
        };
        let rank = |s: ComponentState| match s {
            ComponentState::Blocked => 2,
            ComponentState::Drifted => 1,
            _ => 0,
        };
        if rank(state) > rank(out.0) {
            let detail = if o.detail.is_empty() {
                format!("{} is {}", o.id, o.status.as_str())
            } else {
                o.detail.clone()
            };
            out = (state, detail);
        }
    }
    out
}

fn component_state(
    component: &wf_registry::Component,
    outcome: &AgentOutcome,
    adapter: Option<&wf_agents::ConfigAdapter>,
    skipped: &[SkippedMcp],
) -> Result<Option<StateOfComponent>> {
    let objects: Vec<&wf_agents::ObjectState> = outcome
        .state
        .objects
        .iter()
        .filter(|o| o.component_id == component.id)
        .collect();
    let targeted = component
        .targets
        .iter()
        .any(|t| t.agent().as_str() == outcome.agent);
    let (state, detail) = if objects.is_empty() {
        let bundle_only = matches!(component.kind, Kind::HookPolicy | Kind::ReadinessProfile);
        if !(bundle_only && targeted) {
            return Ok(None);
        }
        (ComponentState::Current, String::new())
    } else {
        object_state(&objects)
    };
    let mut out = StateOfComponent {
        state,
        detail,
        zh: conflict_zh(outcome, &component.id),
        trusted: None,
        skipped_at: objects
            .iter()
            .any(|o| o.status == ObjectStatus::SkippedByUser)
            .then(|| {
                skipped
                    .iter()
                    .find(|s| s.agent_id == outcome.agent && s.component_id == component.id)
                    .map(|s| s.skipped_at.clone())
            })
            .flatten(),
    };
    let Some(adapter) = adapter else {
        return Ok(Some(out));
    };
    if out.state != ComponentState::Current {
        return Ok(Some(out));
    }
    // A server the person declined is never asked about its credentials. There is nothing of
    // ours installed to log into, so `unverified` would be true in the narrowest sense and
    // wrong in every way that matters: it puts the component in the doctor's "installed,
    // login not observed" list and hands over a browser page to visit, for a server this
    // machine deliberately does not have.
    if objects
        .iter()
        .any(|o| o.status == ObjectStatus::SkippedByUser)
    {
        return Ok(Some(out));
    }
    // Only a component whose objects are in place reaches this: where they are not, that
    // drift is both the real fault and the one with a repair, and "installed, login not
    // observed" beside it would name a browser page as the fix for what `wf repair` fixes.
    if let (Kind::Mcp, Some(credentials)) = (component.kind, &component.credentials) {
        use wf_agents::credentials::{credential_status, CredentialStatus};
        match credential_status(credentials) {
            CredentialStatus::Satisfied => {}
            CredentialStatus::Missing(missing) => {
                out.state = ComponentState::CredentialMissing;
                out.detail = format!("{}: {} is not set", component.id, missing.join(", "));
                out.zh = wf_core::zh::credential_missing(&component.id, &missing.join("、"));
            }
            // `wf` opens no credential store, so the most it can say is what it installed. This
            // names the one server this component *is*, and the one thing that settles it.
            CredentialStatus::LoginUnverified => {
                let host = if credentials.login_host.is_empty() {
                    "its provider"
                } else {
                    credentials.login_host.as_str()
                };
                out.state = ComponentState::Unverified;
                out.detail = format!(
                    "{}: logs in to {host} through a browser and holds the token itself, per machine and shared between agents; whether it is logged in was not observed",
                    component.id
                );
                out.zh = wf_core::zh::login_unverified(&component.id, host);
            }
        }
    }
    let bootstrap =
        component.kind == Kind::HookDispatcher && component.arguments == ["hook", "session-start"];
    if bootstrap && adapter.id() == "codex" {
        let trusted = codex_trust(adapter, &objects);
        out.trusted = Some(trusted == Some(true));
        if trusted != Some(true) {
            out.state = ComponentState::Blocked;
            out.detail = "dispatcher trust is unconfirmed; inspect /hooks in Codex".into();
            out.zh = wf_core::zh::codex_hook_untrusted();
        }
    }
    Ok(Some(out))
}

/// The Chinese sentence a conflict finding carries, for status.
fn conflict_zh(outcome: &AgentOutcome, component: &str) -> String {
    outcome
        .state
        .findings
        .iter()
        .find(|f: &&Finding| f.subject == component && f.severity == Severity::Error)
        .map(|f| f.zh.clone())
        .unwrap_or_default()
}

/// Ask Codex whether it trusts the dispatcher that is in place. Only Codex can answer, and
/// asking it spawns its app server, so this runs on apply and status, never at session start.
fn codex_trust(
    adapter: &wf_agents::ConfigAdapter,
    objects: &[&wf_agents::ObjectState],
) -> Option<bool> {
    let install = adapter.detect().ok().flatten()?;
    if install.binary.as_os_str().is_empty() {
        return None;
    }
    let placement = objects.first()?.placement.as_deref()?;
    let hooks_path = wf_agents::resources::object::Placement::parse(placement).path;
    let entry = wf_agents::formats::HookEntry {
        event: wf_agents::formats::HookEvent::SessionStart,
        matcher: None,
        argv: vec![
            adapter.wf_binary().to_string_lossy().into_owned(),
            "hook".into(),
            "session-start".into(),
            "--agent".into(),
            adapter.hook_name().into(),
        ],
        timeout_secs: None,
    };
    let handler = wf_agents::formats::get_hook_format(wf_agents::formats::HookFormat::Codex)
        .render_hook(&entry);
    wf_agents::codex_rpc::hook_trusted(&install.binary, &install.config_root, &handler, &hooks_path)
}

fn source_hash(component: &wf_registry::Component, bundle_dir: &Path) -> Result<String> {
    let Some(source) = component.source.as_deref() else {
        return Ok(String::new());
    };
    let path = bundle_dir.join(source);
    if path.is_dir() {
        wf_core::hash::tree_digest(&path)
    } else if path.is_file() {
        wf_core::hash::sha256_file(&path)
    } else {
        Ok(String::new())
    }
}

/// Ask a binary its version. Used on a candidate before it is installed and on the
/// installed one afterwards, which is why it takes a path rather than reading a constant.
pub(crate) fn running_version(bin: &Path) -> Result<String> {
    let out = wf_core::proc::run(
        &bin.to_string_lossy(),
        &["--version"],
        std::time::Duration::from_secs(20),
    )?;
    if !out.ok() {
        // Say what was observed, not just that it went wrong. This error rolls an install
        // back, and "could not be run" alone cannot distinguish a binary for the wrong
        // architecture from one that timed out from one that exited non-zero with a reason on
        // stderr — which is the difference between a broken release and a loaded machine.
        return Err(Error::failure(
            "BINARY-UNRUNNABLE",
            format!(
                "{} could not be run ({}){}",
                bin.display(),
                if out.timed_out {
                    "timed out".to_string()
                } else {
                    format!("exit {:?}", out.status)
                },
                if out.stderr.trim().is_empty() {
                    String::new()
                } else {
                    format!(": {}", out.stderr.trim())
                }
            ),
        ));
    }
    Ok(out
        .stdout
        .split_whitespace()
        .find(|w| w.chars().next().is_some_and(|c| c.is_ascii_digit()))
        .unwrap_or("")
        .to_string())
}

#[cfg(unix)]
pub(crate) fn set_executable(p: &Path) -> Result<()> {
    use std::os::unix::fs::PermissionsExt;
    std::fs::set_permissions(p, std::fs::Permissions::from_mode(0o755))?;
    Ok(())
}

#[cfg(not(unix))]
pub(crate) fn set_executable(_p: &Path) -> Result<()> {
    Ok(())
}

fn validate_version_path(version: &str) -> Result<()> {
    if !version.starts_with(|c: char| c.is_ascii_digit())
        || !version
            .bytes()
            .all(|c| c.is_ascii_alphanumeric() || b".-".contains(&c))
    {
        return Err(Error::usage(
            "VERSION",
            "expected a release version, not a path",
        ));
    }
    Ok(())
}
