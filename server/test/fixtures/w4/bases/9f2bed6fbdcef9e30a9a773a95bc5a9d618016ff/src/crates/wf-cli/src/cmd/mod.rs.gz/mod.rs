//! Subcommand dispatch. Each module owns one verb and returns an exit code; the shared
//! plumbing — resolving remote flags, printing an envelope — lives here so no subcommand
//! invents its own.

pub mod backup;
pub mod deploy_summary;
pub mod history;
pub mod hook;
pub mod install;
pub mod magi;
pub mod mcp;
pub mod release;
pub mod release_notes;
pub mod review_pr;
pub mod status;
pub mod tools;
pub mod usage;

use crate::flags::{Cli, Command, RemoteArgs};
use wf_core::{envelope::Envelope, ExitCode, Result};
use wf_release::{source::ReleaseSource, Channel};
use wf_sync::Options;

/// Turn the shared remote flags into engine options.
///
/// Precedence, highest first: the flag, the environment variable clap already folded into
/// it, what this machine recorded at install time, and finally the build's own defaults.
/// A machine installed from a fork keeps talking to that fork without anybody re-typing it.
/// This reads one row, so the database is read where it is. A read-only snapshot copies the
/// whole file first, and usage history makes that file grow with every tool call — a cost
/// every `wf status` and every session start would otherwise pay before printing anything.
/// The snapshot is for planning against a state that cannot move underneath it; every caller
/// here goes on to open the database read-write anyway.
pub fn options(remote: &RemoteArgs) -> Result<Options> {
    let paths = wf_core::paths::Paths::resolve()?;
    let db = paths.db();
    let record = if db.is_file() {
        wf_state::Db::open(&db)?.installation()?
    } else {
        None
    };
    options_from_record(remote, record)
}

pub use options as hook_options;

fn options_from_record(
    remote: &RemoteArgs,
    record: Option<wf_state::Installation>,
) -> Result<Options> {
    let mut o = Options::defaults();
    if let Some(rec) = &record {
        if !rec.repo.is_empty() {
            o.repo = rec.repo.clone();
        }
        if !rec.branch.is_empty() {
            o.branch = rec.branch.clone();
        }
        if let Some(channel) = Channel::parse(&rec.channel) {
            o.channel = channel;
        }
    }
    if let Some(repo) = &remote.repo {
        o.repo = repo.clone();
    }
    if let Some(branch) = &remote.branch {
        o.branch = branch.clone();
    }
    if let Some(channel) = &remote.channel {
        o.channel = Channel::parse(channel)
            .ok_or_else(|| wf_core::Error::usage("CHANNEL", "expected stable or canary"))?;
    }
    let source = remote.source.as_deref().or_else(|| {
        if remote.repo.is_some() {
            None
        } else {
            record
                .as_ref()
                .map(|r| r.source.as_str())
                .filter(|s| !s.is_empty())
        }
    });
    o.source = match source {
        Some(spec) => ReleaseSource::parse(spec, &o.repo, &o.branch)?,
        None => ReleaseSource::GitHub {
            repo: o.repo.clone(),
            branch: o.branch.clone(),
        },
    };
    // A machine installed before the org rename recorded the old slug, and nothing else will
    // ever rewrite it: read it as the org it meant, before anything asks GitHub (TXE-1927).
    o.repo = wf_core::canonical_repo(&o.repo);
    match &mut o.source {
        ReleaseSource::GitHub { repo, .. } => {
            *repo = wf_core::canonical_repo(repo);
            o.repo = repo.clone();
        }
        ReleaseSource::Local { dir } => *dir = std::path::absolute(&*dir)?,
    }
    Ok(o)
}

/// The active generation's agent-layer context, or `None` before anything is installed.
pub fn active_context(
    paths: &wf_core::paths::Paths,
    db: &wf_state::Db,
) -> Result<Option<wf_agents::engine::Context>> {
    let Some(g) = db.active_generation()? else {
        return Ok(None);
    };
    let dir = paths.generation(&g.version).join("bundle");
    if !dir.is_dir() {
        return Ok(None);
    }
    wf_agents::engine::Context::load(&dir, paths).map(Some)
}

/// Print an envelope or a human rendering, and pick the exit code from `ok`.
pub fn emit(json: bool, env: Envelope, human: impl FnOnce() -> String) -> ExitCode {
    if json {
        println!("{}", env.render());
    } else {
        let text = human();
        if !text.is_empty() {
            print!("{text}");
            if !text.ends_with('\n') {
                println!();
            }
        }
        for w in &env.warnings {
            eprintln!(
                "{}",
                if w.zh.is_empty() {
                    w.message.clone()
                } else {
                    w.zh.clone()
                }
            );
        }
        for e in &env.errors {
            eprintln!(
                "{}",
                if e.zh.is_empty() {
                    e.message.clone()
                } else {
                    e.zh.clone()
                }
            );
        }
    }
    if env.ok {
        ExitCode::Ok
    } else {
        ExitCode::Failure
    }
}

pub fn dispatch(cli: Cli) -> Result<ExitCode> {
    let json = cli.json;
    match cli.command {
        Command::Install {
            remote,
            agent,
            dry_run,
        } => install::install(json, &remote, &agent, dry_run),
        Command::Sync {
            remote,
            force,
            offline,
            dry_run,
            from_hook,
            agent,
        } => install::sync(
            json,
            &remote,
            install::SyncFlags {
                force,
                offline,
                dry_run,
                from_hook,
                agent,
            },
        ),
        Command::Status { remote } => status::status(json, &remote),
        Command::Doctor { remote, strict } => status::doctor(json, &remote, strict),
        Command::Repair {
            remote,
            component,
            agent,
            dry_run,
        } => install::repair(
            json,
            &remote,
            component.as_deref(),
            agent.as_deref(),
            dry_run,
        ),
        Command::Rollback {
            remote,
            to,
            dry_run,
        } => install::rollback(json, &remote, to.as_deref(), dry_run),
        Command::Uninstall { dry_run, yes } => install::uninstall(json, dry_run, yes),
        Command::Backup(c) => backup::run(json, c),
        Command::Hook(c) => hook::run(json, c),
        Command::Agents { cmd } => {
            status::agents(json, cmd.unwrap_or(crate::flags::AgentsCmd::List))
        }
        Command::Mcp(cmd) => mcp::run(json, cmd),
        Command::Usage {
            since,
            agent,
            limit,
        } => usage::usage(json, &since, agent.as_deref(), limit),
        Command::Sessions { cmd } => usage::sessions(
            json,
            cmd.unwrap_or(crate::flags::SessionsCmd::List {
                limit: 20,
                agent: None,
            }),
        ),
        Command::History { args } => history::run(args),
        Command::Release(c) => release::run(json, c),
        Command::ReviewPr(c) => review_pr::run(json, c),
        Command::Magi(c) => magi::run(json, c),
        Command::ReleaseNotes { from, to, root } => {
            release_notes::run(json, from.as_deref(), &to, root.as_deref())
        }
        Command::DeploySummary {
            prs,
            context,
            namespace,
            production,
        } => deploy_summary::run(json, &prs, context.as_deref(), &namespace, production),
        Command::Guard {
            fix,
            base_ref,
            root,
            now,
        } => tools::guard(json, fix, base_ref.as_deref(), &root, now.as_deref()),
        Command::Readiness(args) => tools::readiness(json, &args),
        Command::Obsidian(args) => tools::obsidian(json, &args),
        Command::Handover {
            to,
            why,
            ticket,
            root,
        } => tools::handover(
            json,
            to.as_deref(),
            why.as_deref(),
            ticket.as_deref(),
            &root,
        ),
        Command::PublishArtifact {
            file,
            title,
            kind,
            id,
            dry_run,
        } => tools::publish_artifact(json, &file, &title, kind.as_deref(), id.as_deref(), dry_run),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn omitted_channel_preserves_installation_and_repo_override_wins() {
        let record = wf_state::Installation {
            channel: "canary".into(),
            repo: "old/repo".into(),
            branch: "release/canary".into(),
            version: "1.0.0-rc.1".into(),
            source: "github:old/repo".into(),
        };
        let options = options_from_record(&RemoteArgs::default(), Some(record.clone())).unwrap();
        assert_eq!(options.channel, Channel::Canary);
        let remote = RemoteArgs {
            repo: Some("new/fork".into()),
            ..Default::default()
        };
        let options = options_from_record(&remote, Some(record.clone())).unwrap();
        assert_eq!(options.source.describe(), "github:new/fork");
        let remote = RemoteArgs {
            channel: Some("stable".into()),
            ..Default::default()
        };
        assert_eq!(
            options_from_record(&remote, Some(record)).unwrap().channel,
            Channel::Stable
        );
    }

    #[test]
    fn a_record_from_before_the_org_rename_never_reaches_github_under_the_old_org() {
        let record = wf_state::Installation {
            channel: "stable".into(),
            repo: "capsohq/txe-workflow".into(),
            branch: "main".into(),
            version: "1.5.2".into(),
            source: "github:capsohq/txe-workflow".into(),
        };
        let options = options_from_record(&RemoteArgs::default(), Some(record.clone())).unwrap();
        assert_eq!(options.repo, wf_core::DEFAULT_REPO);
        assert_eq!(options.source.describe(), "github:txehq/txe-workflow");

        let bare = wf_state::Installation {
            source: String::new(),
            ..record
        };
        let options = options_from_record(&RemoteArgs::default(), Some(bare)).unwrap();
        assert_eq!(options.source.describe(), "github:txehq/txe-workflow");

        // A flag copied from a pre-rename README is read the same way.
        let remote = RemoteArgs {
            repo: Some("capsohq/txe-workflow".into()),
            ..Default::default()
        };
        let options = options_from_record(&remote, None).unwrap();
        assert_eq!(options.source.describe(), "github:txehq/txe-workflow");
    }
}
