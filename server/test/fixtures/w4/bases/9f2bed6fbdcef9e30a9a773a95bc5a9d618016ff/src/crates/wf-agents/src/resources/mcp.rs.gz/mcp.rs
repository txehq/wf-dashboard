//! MCP servers: one named key in each agent's MCP document, gated by the MCP policy.
//!
//! Definitions carry references, never values (D-018), and they reach every format still as
//! references — `${VAR}` where the agent expands it, a variable *name* where it does not.
//! Nothing here resolves a secret, so nothing here can write one.

use super::object::{Rendered, Shape};
use super::{
    registry_payload, ResourceHandler, ResourceItem, ResourceKind, ResourceMetadata,
    POLICY_REFUSED, POLICY_SKIP,
};
use crate::formats::{get_mcp_format, json_doc, McpDef, McpTransport, Occupied};
use crate::{
    adapter::{ConfigAdapter, Desired, TeamAIAdapter},
    registry::PathKind,
    team_repo::TeamRepo,
};
use serde::Serialize;
use wf_core::{Error, Result};

pub struct McpHandler;

impl ResourceHandler for McpHandler {
    fn kind(&self) -> ResourceKind {
        ResourceKind::Mcp
    }

    fn scan_registry(&self, repo: &TeamRepo) -> Result<Vec<ResourceItem>> {
        let root = repo.root()?;
        let registry = repo.registry()?;
        let mut out: Vec<ResourceItem> = Vec::new();
        for c in registry.of_kind(wf_registry::Kind::Mcp) {
            let Some(source) = c.source.as_deref() else {
                continue;
            };
            let path = root.join(source);
            let text = std::fs::read_to_string(&path)
                .map_err(|e| Error::from(e).with_zh(format!("找不到 {source}。")))?;
            let mut def = McpDef::parse(&text, &path)?;
            def.startup_timeout_sec = c.startup_timeout_sec;
            def.component = Some(c.id.clone());
            def.validate()?;
            if out.iter().any(|i| i.id == def.name) {
                return Err(Error::usage(
                    "MCP-DUPLICATE",
                    format!("{}: server name {} is declared twice", c.id, def.name),
                ));
            }
            let value = serde_json::to_value(&def)?;
            let mut payload = registry_payload(c);
            payload.insert("def".into(), value.clone());
            out.push(ResourceItem {
                id: def.name.clone(),
                name: def.name.clone(),
                kind: ResourceKind::Mcp,
                version: None,
                source: path,
                metadata: ResourceMetadata {
                    content_hash: json_doc::canonical_hash(&value),
                    component_id: Some(c.id.clone()),
                    placement: None,
                    payload: payload.into(),
                },
            });
        }
        Ok(out)
    }

    fn render(&self, item: &ResourceItem, agent: &dyn TeamAIAdapter) -> Result<Option<Rendered>> {
        let (Some(format), Some(path)) = (agent.formats().mcp, agent.path(PathKind::Mcp)) else {
            return Ok(None);
        };
        let mut def: McpDef = serde_json::from_value(item.metadata.payload["def"].clone())?;
        let policy = &agent.policies().mcp;
        if def.transport == McpTransport::Stdio {
            let command = def.command.as_deref().unwrap_or_default();
            if command == "wf" {
                // `wf` is the binary enforcing this policy. Like a hook's, it is resolved to
                // the installed path — an agent does not start servers with a login `PATH` —
                // and never refused by the allowlist that governs third-party launchers.
                def.command = Some(agent.wf_binary().to_string_lossy().into_owned());
            } else if !policy.command_allowed(command) {
                return Err(refused(
                    &def,
                    format!("command {command:?} is not in mcp.allowed_commands"),
                ));
            }
        }
        for host in def.hosts() {
            if !policy.host_allowed(&host) {
                return Err(refused(
                    &def,
                    format!("host {host} is not in mcp.allowed_hosts"),
                ));
            }
        }
        if def.transport != McpTransport::Stdio
            && def
                .url
                .as_deref()
                .and_then(crate::formats::url_host)
                .is_none()
        {
            return Err(refused(&def, "the url has no host wf can check".into()));
        }
        if !policy.auto_apply {
            return Err(Error::usage(
                POLICY_SKIP,
                format!(
                    "{}: mcp.auto_apply is off; the server is left as it is",
                    def.name
                ),
            ));
        }
        let adapter = get_mcp_format(format);
        Ok(adapter.render_server(&def)?.map(|value| Rendered::Key {
            path,
            document: adapter.document(),
            keys: adapter.keys(&def.name),
            value,
        }))
    }

    fn shape(&self, agent: &dyn TeamAIAdapter) -> Option<Shape> {
        agent.path(PathKind::Mcp)?;
        self.stored_shape(agent)
    }

    fn stored_shape(&self, agent: &dyn TeamAIAdapter) -> Option<Shape> {
        let format = agent.formats().mcp?;
        Some(Shape::Key(get_mcp_format(format).document()))
    }
}

fn refused(def: &McpDef, why: String) -> Error {
    Error::usage(POLICY_REFUSED, format!("{}: {why}", def.name)).with_zh(format!(
        "MCP 服务 {} 不符合团队策略（{why}），没有写入。",
        def.name
    ))
}

/// One of ours that this machine already reaches, or whose key is already taken.
///
/// `name` and `hosts` are both **ours** — the definition we would write, named the way we
/// name it. What the entry that answered is called never leaves `wf-agents`: a person is
/// told that the service is already connected, and asked what to do about it (WFR-016).
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct Candidate {
    pub component_id: String,
    pub agent: String,
    pub name: String,
    pub hosts: Vec<String>,
    /// Which half of the comparison answered: our host was reached, or our key was taken.
    pub by: Occupied,
}

/// What every agent on this machine already reaches, before anything is written.
///
/// A document nobody can read is an error rather than an empty answer, and the diagnostic
/// names the agent and the path to its configuration — never a word of what the document
/// holds (WFR-016).
pub fn candidates(
    desired: &Desired,
    adapters: &[ConfigAdapter],
    db: &wf_state::Db,
) -> Result<Vec<Candidate>> {
    let Some(items) = desired.items.get(&ResourceKind::Mcp) else {
        return Ok(Vec::new());
    };
    let items = items.as_ref().map_err(|_| {
        Error::usage(
            "MCP-SURVEY-DEFINITION",
            "cannot read the release MCP definitions",
        )
    })?;
    let pairs = items
        .iter()
        .map(|item| {
            let def: McpDef = serde_json::from_value(item.metadata.payload["def"].clone())
                .map_err(|_| {
                    Error::usage("MCP-SURVEY-DEFINITION", "invalid release MCP definition")
                })?;
            Ok((item.component_id(), def))
        })
        .collect::<Result<Vec<_>>>()?;
    if pairs.is_empty() {
        return Ok(Vec::new());
    }
    let mut out: Vec<Candidate> = Vec::new();
    for adapter in adapters {
        let (Some(format), Some(path)) = (adapter.formats().mcp, adapter.path(PathKind::Mcp))
        else {
            continue;
        };
        let targets: Vec<&McpDef> = pairs.iter().map(|(_, def)| def).collect();
        let failure = || {
            Error::usage(
                "MCP-SURVEY-CONFIG",
                format!(
                    "{}: cannot read or parse MCP configuration at {}",
                    adapter.id(),
                    path.display()
                ),
            )
            .with_zh(format!(
                "无法读取或解析 {} 的 MCP 配置：{}。请检查文件格式和读取权限。",
                adapter.id(),
                path.display()
            ))
        };
        let text = wf_core::paths::read_text_or_empty(&path).map_err(|_| failure())?;
        for hit in get_mcp_format(format)
            .occupied(&text, &targets)
            .map_err(|_| failure())?
        {
            let (component_id, def) = pairs
                .iter()
                .find(|(_, def)| def.name == hit.component)
                .expect("occupancy identifies a requested definition");
            if hit.by == Occupied::Key
                && db
                    .managed_resource(adapter.id(), "mcp", &def.name)?
                    .is_some()
            {
                continue;
            }
            out.push(Candidate {
                component_id: component_id.clone(),
                agent: adapter.id().to_string(),
                name: def.name.clone(),
                hosts: def.hosts(),
                by: hit.by,
            });
        }
    }
    out.sort_by(|a, b| (&a.component_id, &a.agent).cmp(&(&b.component_id, &b.agent)));
    out.dedup();
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::policy::Policies;
    use crate::testing::{Machine, TeamFixture};

    /// An agent with no MCP document of its own is not asked and does not appear. OpenClaw
    /// declares none, and this is the only place that decides so for this question.
    #[test]
    fn an_agent_with_no_mcp_document_is_never_a_candidate() {
        let team = TeamFixture::new();
        let machine = Machine::new();
        // The same document OpenClaw would hold, if it had one: the point is that nothing
        // reads it.
        machine.write(
            ".openclaw/workspace/AGENTS.md",
            r#"{"mcpServers":{"linear":{"url":"https://mcp.linear.app/mcp"}}}"#,
        );
        let adapters = vec![
            machine.adapter(&team, "openclaw", Policies::default()),
            machine.adapter(&team, "claude-code", Policies::default()),
        ];
        machine.write(
            ".claude.json",
            r#"{"mcpServers":{"linear":{"type":"http","url":"https://mcp.linear.app/mcp"}}}"#,
        );
        let desired = Desired::scan(&team.repo());
        let candidates = candidates(&desired, &adapters, &machine.db).unwrap();
        assert_eq!(
            candidates
                .iter()
                .map(|c| (c.component_id.as_str(), c.agent.as_str()))
                .collect::<Vec<_>>(),
            vec![("capso.mcp.linear", "claude-code")],
            "openclaw has no MCP document and must not appear"
        );
    }

    #[test]
    fn an_unreadable_document_fails_the_survey() {
        let team = TeamFixture::new();
        let machine = Machine::new();
        machine.write(".claude.json", "{ this is not json");
        let adapters = vec![machine.adapter(&team, "claude-code", Policies::default())];
        let desired = Desired::scan(&team.repo());
        let error = candidates(&desired, &adapters, &machine.db).unwrap_err();
        assert_eq!(error.kind, "MCP-SURVEY-CONFIG");
        assert!(error.message.contains(".claude.json"));
    }
}
