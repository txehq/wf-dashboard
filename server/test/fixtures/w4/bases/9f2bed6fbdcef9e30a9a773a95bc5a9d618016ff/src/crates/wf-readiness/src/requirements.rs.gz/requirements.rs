use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use wf_core::{Error, Result};

/// What this repo needs of a machine, assembled from three sources in this order, where the
/// later ones never restate the earlier:
///
/// - **derived** — from the file that already owns the fact (`Cargo.toml`, `go.mod`, …)
/// - **declared** — a readiness profile, for what no file states (credentials, unpinned tools)
/// - **ticket** — extras this one task needs
///
/// A version that lives in `Cargo.toml` must never be copied into a profile: the copy is a
/// drift surface, and the drift is silent until a build fails for a reason nobody checked.
#[derive(Debug, Clone, Default, Serialize)]
pub struct Requirements {
    pub tools: Vec<ToolReq>,
    pub credentials: Vec<CredReq>,
    pub services: Vec<ServiceReq>,
    /// Registry components `wf` must have put into the agent running the check
    /// (`capso.mcp.linear`).
    pub components: Vec<String>,
    /// The files the requirements were read from, with their content hashes — the
    /// fingerprint's first input.
    pub sources: Vec<SourceFile>,
}

#[derive(Debug, Clone, Default, Serialize)]
pub struct ToolReq {
    /// The binary name, which is also the id.
    pub id: String,
    pub min: String,
    pub exact: String,
    /// Provenance, shown in the report: "Cargo.toml".
    pub from: String,
    pub why: String,
    pub install_darwin: String,
    pub install_linux: String,
    pub optional: bool,
}

impl ToolReq {
    pub fn install_hint(&self) -> &str {
        if cfg!(target_os = "macos") {
            &self.install_darwin
        } else {
            &self.install_linux
        }
    }
}

#[derive(Debug, Clone, Default, Serialize)]
pub struct CredReq {
    pub id: String,
    /// The variables that may carry the credential, in preference order. The value is never
    /// stored or printed — only whether one is present.
    pub env: Vec<String>,
    /// A command that proves the credential works, rather than merely exists.
    pub probe: Vec<String>,
    pub zh_missing: String,
    pub capabilities: Vec<String>,
    pub allow_probe: bool,
}

/// A compose service the work needs. How it is reached — a published port, or only its
/// container — is Compose's answer at check time, after interpolation.
#[derive(Debug, Clone, Default, Serialize)]
pub struct ServiceReq {
    pub name: String,
    /// The compose file that defines it, relative to the repository root.
    pub from: String,
}

#[derive(Debug, Clone, Serialize)]
pub struct SourceFile {
    pub path: String,
    pub hash: String,
}

// --- the declared half: a readiness profile -----------------------------------------

#[derive(Debug, Deserialize)]
struct Profile {
    #[serde(default)]
    schema_version: u32,
    #[serde(default)]
    profile: String,
    /// A profile may build on another, so `maintainer` does not restate `consumer`.
    #[serde(default)]
    extends: String,
    #[serde(default)]
    requirements: Vec<ProfileReq>,
}

#[derive(Debug, Deserialize)]
struct ProfileReq {
    tool: String,
    #[serde(default)]
    version: String,
    #[serde(default)]
    why: String,
    #[serde(default)]
    install: Install,
    #[serde(default)]
    optional: bool,
    #[serde(default)]
    credential: Option<ProfileCred>,
}

#[derive(Debug, Default, Deserialize)]
struct Install {
    #[serde(default)]
    darwin: String,
    #[serde(default)]
    linux: String,
}

#[derive(Debug, Deserialize)]
struct ProfileCred {
    #[serde(default)]
    probe: Vec<String>,
    #[serde(default)]
    zh_missing: String,
    #[serde(default)]
    env: Vec<String>,
}

pub fn load(
    root: &Path,
    profile: &str,
    extras: &[String],
    profile_root: Option<&Path>,
    manifest: Option<&Path>,
    compose: Option<&Path>,
) -> Result<Requirements> {
    let mut req = Requirements::default();
    let mut chain = vec![profile.to_string()];
    let mut guard = 0;

    while let Some(name) = chain.pop() {
        guard += 1;
        if guard > 8 {
            return Err(Error::usage(
                "READINESS-PROFILE-CYCLE",
                "profile extends itself",
            ));
        }
        let path = find_profile(root, &name, profile_root).ok_or_else(|| {
            Error::usage(
                "READINESS-PROFILE",
                format!("no readiness profile {name:?}"),
            )
            .with_zh(format!(
                "找不到名为 `{name}` 的检查清单。可用的一般是 consumer 和 maintainer。"
            ))
        })?;
        let text = std::fs::read_to_string(&path)?;
        let p: Profile = serde_yaml_ng::from_str(&text)
            .map_err(|e| Error::usage("READINESS-PROFILE", format!("{}: {e}", path.display())))?;
        if p.schema_version != 1 {
            return Err(Error::unsupported(
                "READINESS-PROFILE-SCHEMA",
                format!(
                    "{}: schema_version {} is not 1",
                    path.display(),
                    p.schema_version
                ),
            ));
        }
        req.sources.push(SourceFile {
            path: path.to_string_lossy().into_owned(),
            hash: wf_core::hash::sha256_bytes(text.as_bytes()),
        });
        for r in p.requirements {
            if let Some(c) = &r.credential {
                req.credentials.push(CredReq {
                    id: r.tool.clone(),
                    env: c.env.clone(),
                    probe: c.probe.clone(),
                    zh_missing: c.zh_missing.clone(),
                    ..Default::default()
                });
            }
            req.tools.push(ToolReq {
                id: r.tool,
                min: r.version.trim_start_matches(">=").to_string(),
                from: p.profile.clone(),
                why: r.why,
                install_darwin: r.install.darwin,
                install_linux: r.install.linux,
                optional: r.optional,
                exact: String::new(),
            });
        }
        if !p.extends.is_empty() {
            chain.push(p.extends);
        }
    }

    // The derived half: a version that already lives in a file is read from that file, and
    // never copied into a profile.
    req.tools.extend(derived(root, &mut req.sources));

    let path = crate::manifest::resolve(root, profile_root, manifest);
    crate::manifest::load_into(&mut req, root, path.as_deref(), extras, compose)?;
    let mut tools = std::collections::BTreeMap::<String, ToolReq>::new();
    for mut t in std::mem::take(&mut req.tools) {
        t.id = crate::catalog::canonical(&t.id).into();
        if let Some(known) = crate::catalog::tool(&t.id) {
            if t.install_darwin.is_empty() {
                t.install_darwin = known.darwin.into();
            }
            if t.install_linux.is_empty() {
                t.install_linux = known.linux.into();
            }
        }
        if t.id == "rust" && !t.exact.is_empty() {
            t.install_darwin = format!("rustup toolchain install {}", t.exact);
            t.install_linux = t.install_darwin.clone();
        }
        if let Some(previous) = tools.get_mut(&t.id) {
            previous.optional &= t.optional;
            if !t.exact.is_empty() {
                if !previous.exact.is_empty() && previous.exact != t.exact {
                    return Err(Error::usage(
                        "READINESS-PIN",
                        format!("conflicting pins for {}", t.id),
                    ));
                }
                previous.exact = t.exact;
                previous.from = t.from;
                previous.install_darwin = t.install_darwin;
                previous.install_linux = t.install_linux;
            }
            if version_ge(&t.min, &previous.min) {
                previous.min = t.min;
            }
        } else {
            tools.insert(t.id.clone(), t);
        }
    }
    req.tools = tools.into_values().collect();
    for tool in &req.tools {
        if !tool.exact.is_empty() && !version_ge(&tool.exact, &tool.min) {
            return Err(Error::usage(
                "READINESS-PIN",
                format!(
                    "{} pins {}, below required minimum {}",
                    tool.id, tool.exact, tool.min
                ),
            ));
        }
    }
    let mut credentials = std::collections::BTreeMap::<String, CredReq>::new();
    for mut c in std::mem::take(&mut req.credentials) {
        if c.id == "gh" {
            c.id = "github".into();
        }
        if let Some(previous) = credentials.get_mut(&c.id) {
            previous.env.extend(c.env);
            previous.capabilities.extend(c.capabilities);
            previous.allow_probe |= c.allow_probe;
            if !c.probe.is_empty() {
                previous.probe = c.probe;
            }
        } else {
            credentials.insert(c.id.clone(), c);
        }
    }
    req.credentials = credentials.into_values().collect();
    req.components.sort();
    req.components.dedup();
    req.sources.sort_by(|a, b| a.path.cmp(&b.path));
    req.sources.dedup_by(|a, b| a.path == b.path);
    Ok(req)
}

fn find_profile(root: &Path, name: &str, profile_root: Option<&Path>) -> Option<PathBuf> {
    let mut candidates = vec![root.join(format!("workflow/readiness/{name}.yaml"))];
    if let Some(p) = profile_root {
        candidates.push(p.join(format!("workflow/readiness/{name}.yaml")));
    }
    if let Ok(paths) = wf_core::paths::Paths::resolve() {
        candidates.push(
            paths
                .active_link()
                .join(format!("bundle/workflow/readiness/{name}.yaml")),
        );
    }
    candidates.into_iter().find(|p| p.is_file())
}

/// Requirements read from the file that already pins them.
fn derived(root: &Path, sources: &mut Vec<SourceFile>) -> Vec<ToolReq> {
    let mut out = Vec::new();
    for (file, id) in [
        ("go.mod", "go"),
        ("rust-toolchain.toml", "rust"),
        ("rust-toolchain", "rust"),
        (".bazelversion", "bazel"),
        (".python-version", "python"),
        (".nvmrc", "node"),
    ] {
        if out
            .iter()
            .any(|t: &ToolReq| t.id == id && !t.exact.is_empty())
        {
            continue;
        }
        if let Ok((tool, source)) = derive_version(root, file, id) {
            out.push(tool);
            sources.push(source);
        }
    }
    if let Ok(text) = std::fs::read_to_string(root.join(".tool-versions")) {
        for line in text.lines() {
            let Some(id) = line
                .split_whitespace()
                .next()
                .map(crate::catalog::canonical)
            else {
                continue;
            };
            if crate::catalog::tool(id).is_none()
                || out.iter().any(|t| t.id == id && !t.exact.is_empty())
            {
                continue;
            }
            if let Ok((tool, source)) = derive_version(root, ".tool-versions", id) {
                out.push(tool);
                sources.push(source);
            }
        }
    }
    out
}

pub(crate) fn derive_version(root: &Path, file: &str, id: &str) -> Result<(ToolReq, SourceFile)> {
    let text = std::fs::read_to_string(root.join(file))?;
    let name = Path::new(file)
        .file_name()
        .and_then(|s| s.to_str())
        .unwrap_or_default();
    let version = match name {
        "go.mod" => text
            .lines()
            .find_map(|l| l.trim().strip_prefix("go "))
            .map(str::trim)
            .map(str::to_string),
        "rust-toolchain.toml" => {
            let value: toml::Value =
                toml::from_str(&text).map_err(|e| Error::usage("READINESS-PIN", e.to_string()))?;
            value["toolchain"]
                .get("channel")
                .and_then(|v| v.as_str())
                .map(str::to_string)
        }
        "rust-toolchain" if text.trim_start().starts_with('[') => {
            let value: toml::Value =
                toml::from_str(&text).map_err(|e| Error::usage("READINESS-PIN", e.to_string()))?;
            value["toolchain"]
                .get("channel")
                .and_then(|v| v.as_str())
                .map(str::to_string)
        }
        "rust-toolchain" | ".bazelversion" | ".python-version" | ".nvmrc" => {
            text.split_whitespace().next().map(str::to_string)
        }
        ".tool-versions" => text.lines().find_map(|line| {
            let mut fields = line.split_whitespace();
            (crate::catalog::canonical(fields.next()?) == id)
                .then(|| fields.next().map(str::to_string))
                .flatten()
        }),
        _ => None,
    }
    .map(|v| v.trim_start_matches('v').to_string())
    .filter(|v| v.chars().next().is_some_and(|c| c.is_ascii_digit()))
    .ok_or_else(|| {
        Error::usage(
            "READINESS-PIN",
            format!("{file}: no numeric version for {id}"),
        )
    })?;
    let source = SourceFile {
        path: root.join(file).to_string_lossy().into_owned(),
        hash: wf_core::hash::sha256_bytes(text.as_bytes()),
    };
    Ok((
        ToolReq {
            id: id.into(),
            min: version.clone(),
            exact: if name == "go.mod" {
                String::new()
            } else {
                version
            },
            from: file.into(),
            ..Default::default()
        },
        source,
    ))
}

/// Compare two dotted versions. An empty minimum is satisfied by anything.
pub fn version_ge(have: &str, want: &str) -> bool {
    if want.is_empty() {
        return true;
    }
    if have.is_empty() {
        return false;
    }
    let parse = |s: &str| -> Option<Vec<u64>> {
        s.trim()
            .trim_start_matches('v')
            .split('.')
            .map(|p| {
                p.chars()
                    .take_while(char::is_ascii_digit)
                    .collect::<String>()
                    .parse()
                    .ok()
            })
            .collect()
    };
    let (Some(h), Some(w)) = (parse(have), parse(want)) else {
        return false;
    };
    for i in 0..h.len().max(w.len()) {
        let a = h.get(i).copied().unwrap_or(0);
        let b = w.get(i).copied().unwrap_or(0);
        match a.cmp(&b) {
            std::cmp::Ordering::Greater => return true,
            std::cmp::Ordering::Less => return false,
            std::cmp::Ordering::Equal => {}
        }
    }
    true
}

/// The ticket half. A known toolchain, a tool the manifest declares, and a name carrying a
/// version are tool requirements and never consult compose. Every other name is returned
/// for the compose file to claim as a service; one it does not claim is a tool again only if
/// it resolves on the session PATH (see `manifest::load_into`).
pub(crate) fn ticket_needs(req: &mut Requirements, extras: &[String]) -> Vec<String> {
    let mut services = Vec::new();
    for e in extras {
        let (id, min) = match e.split_once(">=") {
            Some((a, b)) => (a.trim().to_string(), b.trim().to_string()),
            None => (e.trim().to_string(), String::new()),
        };
        if id.is_empty() {
            continue;
        }
        let id = crate::catalog::canonical(&id).to_string();
        if min.is_empty()
            && crate::catalog::tool(&id).is_none()
            && !req.tools.iter().any(|t| t.id == id)
        {
            services.push(id);
            continue;
        }
        req.tools.push(ToolReq {
            id,
            min,
            from: "--need".into(),
            ..Default::default()
        });
    }

    services
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_ticket_promotes_a_manifest_custom_tool_instead_of_requesting_a_service() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(
            dir.path().join("readiness.yaml"),
            "version: 1\ntoolchains:\n  - id: review-tool\n    optional: true\n",
        )
        .unwrap();
        let profiles = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
        let req = load(
            dir.path(),
            "consumer",
            &["review-tool".into()],
            Some(&profiles),
            None,
            None,
        )
        .unwrap();
        assert!(req.services.is_empty());
        assert!(req
            .tools
            .iter()
            .any(|tool| tool.id == "review-tool" && !tool.optional));
    }

    #[test]
    #[cfg_attr(target_os = "macos", ignore = "needs Docker Compose")]
    fn repo_manifest_keeps_services_components_and_capabilities() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::create_dir_all(dir.path().join("workflow/readiness")).unwrap();
        std::fs::write(
            dir.path().join("workflow/readiness/consumer.yaml"),
            "schema_version: 1\nprofile: consumer\nrequirements: []\n",
        )
        .unwrap();
        std::fs::write(dir.path().join("readiness.yaml"), "version: 1\nservices:\n  need: [postgres]\ncredentials:\n  - id: github\n    capabilities: [repo, workflow]\ncomponents: [capso.mcp.linear]\n").unwrap();
        std::fs::write(dir.path().join("compose.yaml"), "services:\n  postgres:\n    image: postgres:16\n    ports: ['55432:5432']\n  unrequested:\n    image: ignored\n    ports: ['1111:1111']\n").unwrap();
        let req = load(dir.path(), "consumer", &[], None, None, None).unwrap();
        let value = serde_json::to_value(req).unwrap();
        assert_eq!(value["services"][0]["name"], "postgres");
        assert_eq!(value["services"][0]["from"], "compose.yaml");
        assert_eq!(value["services"].as_array().unwrap().len(), 1);
        assert_eq!(value["components"][0], "capso.mcp.linear");
        assert_eq!(value["credentials"][0]["capabilities"][1], "workflow");
    }

    #[test]
    fn all_standard_toolchain_pin_files_are_derived() {
        let dir = tempfile::tempdir().unwrap();
        for (file, text) in [
            (".bazelversion", "8.2.0"),
            (".python-version", "3.12.1"),
            (".nvmrc", "v22.1.0"),
            ("rust-toolchain.toml", "[toolchain]\nchannel = \"1.96.1\"\n"),
        ] {
            std::fs::write(dir.path().join(file), text).unwrap();
        }
        let tools = derived(dir.path(), &mut vec![]);
        let values = serde_json::to_value(tools).unwrap();
        for (id, exact) in [
            ("bazel", "8.2.0"),
            ("python", "3.12.1"),
            ("node", "22.1.0"),
            ("rust", "1.96.1"),
        ] {
            assert!(
                values
                    .as_array()
                    .unwrap()
                    .iter()
                    .any(|t| t["id"] == id && t["exact"] == exact),
                "missing pin {id}"
            );
        }
    }

    #[test]
    fn versions_compare_across_differing_lengths() {
        assert!(version_ge("1.26.1", "1.26"));
        assert!(version_ge("1.96.1", "1.85"));
        assert!(!version_ge("1.23.2", "1.25"));
        assert!(version_ge("1.25", "1.25.0"));
        assert!(
            version_ge("anything", ""),
            "an empty minimum is satisfied by anything"
        );
        assert!(!version_ge("", "1.0"));
    }

    #[test]
    fn a_derived_requirement_reads_the_file_that_pins_it() {
        let d = tempfile::tempdir().unwrap();
        std::fs::write(
            d.path().join("rust-toolchain.toml"),
            "[toolchain]\nchannel = \"1.96.1\"\n",
        )
        .unwrap();
        std::fs::write(d.path().join("go.mod"), "module x\n\ngo 1.25\n").unwrap();
        let mut sources = Vec::new();
        let got = derived(d.path(), &mut sources);
        let cargo = got.iter().find(|t| t.id == "rust").unwrap();
        assert_eq!(cargo.min, "1.96.1");
        assert_eq!(cargo.from, "rust-toolchain.toml");
        assert_eq!(got.iter().find(|t| t.id == "go").unwrap().min, "1.25");
        assert_eq!(sources.len(), 2, "every source is fingerprinted");
    }

    #[test]
    fn a_requirement_whose_file_is_gone_is_gone() {
        let d = tempfile::tempdir().unwrap();
        let mut sources = Vec::new();
        assert!(derived(d.path(), &mut sources).is_empty());
    }

    #[test]
    fn the_shipped_profiles_load_and_maintainer_extends_consumer() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
        let consumer = load(&root, "consumer", &[], None, None, None).unwrap();
        assert!(consumer.tools.iter().any(|t| t.id == "gh"));
        let maintainer = load(&root, "maintainer", &[], None, None, None).unwrap();
        assert!(
            maintainer.tools.iter().any(|t| t.id == "gh"),
            "maintainer inherits consumer"
        );
        assert!(maintainer.tools.iter().any(|t| t.id == "docker"));
    }

    #[test]
    fn a_ticket_extra_joins_the_requirements() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
        let req = load(
            &root,
            "consumer",
            &["bazel".into(), "go>=1.26".into()],
            None,
            None,
            None,
        )
        .unwrap();
        assert!(req.tools.iter().any(|t| t.id == "bazel"));
        let go = req.tools.iter().find(|t| t.id == "go").unwrap();
        assert!(
            version_ge(&go.min, "1.26"),
            "the strictest minimum wins, got {}",
            go.min
        );
    }
}
