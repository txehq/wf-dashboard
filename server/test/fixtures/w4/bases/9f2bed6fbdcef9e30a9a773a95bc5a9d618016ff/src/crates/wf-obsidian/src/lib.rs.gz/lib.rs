//! `wf obsidian` — file a document at its standard home and leave the vault navigable.
//!
//! Ported from `cmd/obsidian`. Three behaviours are preserved exactly because each one was
//! a decision rather than an implementation detail:
//!
//! - **The kind table is closed.** An unrecognised kind is refused rather than filed
//!   somewhere plausible; inventing a location is how a vault grows a second home for the
//!   same thing.
//! - **A product folder is never created.** A typo would otherwise mint `Project Tokun2`
//!   and file a document into a product nobody has.
//! - **The folder index is rendered from disk, never maintained.** Every hand-kept index
//!   eventually becomes a list of things that used to be there, because additions get
//!   remembered and removals do not.

pub mod frontmatter;
pub mod index;
pub mod layout;

pub use frontmatter::Frontmatter;
pub use layout::{resolve, Kind, Request, Scope, Target};

use std::path::Path;
use wf_core::{Error, Result};

pub struct WriteOptions<'a> {
    pub request: Request,
    pub file: Option<&'a Path>,
    pub ticket: &'a str,
    pub url: &'a str,
    pub replace: bool,
    pub dry_run: bool,
}

/// File the document. Returns the path it was written to.
pub fn write(opt: &WriteOptions<'_>) -> Result<String> {
    let target = resolve(&opt.request)?;
    if opt.dry_run {
        return Ok(target.path.to_string_lossy().into_owned());
    }

    let file = opt.file.ok_or_else(|| {
        Error::usage("OBSIDIAN-NO-FILE", "--file is required")
            .with_zh("要归档哪个文件？用 `--file` 指定一下。".to_string())
    })?;
    let source = std::fs::read_to_string(file).map_err(|e| {
        Error::from(e).with_zh(format!("读不到 {}。请确认路径对不对。", file.display()))
    })?;

    let existing = std::fs::read_to_string(&target.path).unwrap_or_default();
    if target.path.exists() && !opt.replace {
        // The cost of a lost draft is unbounded; the cost of one more flag is a flag.
        return Err(Error::failure(
            "OBSIDIAN-EXISTS",
            format!("{} already exists", target.path.display()),
        )
        .with_zh(format!(
            "{} 已经有内容了。确认要覆盖的话，加上 `--replace` 再运行一次。",
            target.path.display()
        )));
    }

    // The incoming document's own frontmatter wins over the file's, and both lose to the
    // flags — but only where the flags actually said something.
    let (old_fm, _) = frontmatter::split(&existing);
    let (new_fm, body) = frontmatter::split(&source);
    let merged = old_fm.merge(&new_fm).merge(&Frontmatter::from_pairs(&[
        ("kind", target.kind.name),
        (
            "product",
            opt.request.product.trim_start_matches("Project "),
        ),
        ("feature", &feature_field(&target, &opt.request)),
        ("ticket", opt.ticket),
        ("published", opt.url),
        ("updated", &opt.request.date),
    ]));

    std::fs::create_dir_all(&target.dir)?;
    wf_core::atomic::write_file(
        &target.path,
        format!("{}{body}", merged.render()).as_bytes(),
    )?;

    // Regenerate the folder's index so it describes what is now there, including anything
    // removed since the last write.
    if let Some(fd) = &target.feature_dir {
        index::write_index(fd)?;
    }
    Ok(target.path.to_string_lossy().into_owned())
}

fn feature_field(target: &Target, r: &Request) -> String {
    if target.kind.scope != Scope::Feature {
        return String::new();
    }
    layout::slugify(&r.feature)
}
