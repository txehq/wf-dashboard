//! Cursor: `hooks.json` with camelCase events, `mcp.json` with `${env:VAR}` references.

use super::{
    json_doc, owned_identity, shell_words, Document, HookEntry, HookEvent, HookFormatAdapter,
    McpDef, McpFormatAdapter, McpTransport,
};
use serde_json::{json, Value};
use std::path::Path;
use wf_core::{Error, Result};

pub struct CursorHooks;

/// The four events Cursor's hooks expose under a name `wf` can map.
pub fn event_key(event: HookEvent) -> Option<&'static str> {
    match event {
        HookEvent::SessionStart => Some("sessionStart"),
        HookEvent::Stop => Some("stop"),
        HookEvent::PostToolUse => Some("postToolUse"),
        HookEvent::UserPromptSubmit => Some("beforeSubmitPrompt"),
        HookEvent::SessionEnd | HookEvent::PreToolUse => None,
    }
}

fn event_of(key: &str) -> Option<HookEvent> {
    HookEvent::ALL
        .into_iter()
        .find(|e| event_key(*e) == Some(key))
}

fn shape(path: &Path) -> Error {
    Error::conflict(
        "HOOKS-SHAPE",
        format!("{} has an unexpected hooks shape", path.display()),
    )
}

fn identity_of(event: HookEvent, entry: &Value) -> Option<String> {
    let argv = entry["command"].as_str().and_then(shell_words);
    owned_identity(event, argv.as_deref(), None)
}

/// The document's hooks object, and the list under one event, both checked, created as
/// `wf` establishes its own handler.
fn entries<'a>(doc: &'a mut Value, key: &str, path: &Path) -> Result<&'a mut Vec<Value>> {
    let obj = doc.as_object_mut().ok_or_else(|| shape(path))?;
    if !obj.contains_key("version") {
        obj.insert("version".into(), 1.into());
    }
    obj.entry("hooks")
        .or_insert_with(|| json!({}))
        .as_object_mut()
        .ok_or_else(|| shape(path))?
        .entry(key.to_string())
        .or_insert_with(|| json!([]))
        .as_array_mut()
        .ok_or_else(|| shape(path))
}

/// The same list, read-only: a removal creates nothing on its way out, least of all a
/// schema key pinning somebody's file to a version `wf` chose.
fn existing_entries<'a>(doc: &'a mut Value, key: &str, path: &Path) -> Result<&'a mut Vec<Value>> {
    doc.get_mut("hooks")
        .and_then(|h| h.get_mut(key))
        .ok_or_else(|| shape(path))?
        .as_array_mut()
        .ok_or_else(|| shape(path))
}

impl HookFormatAdapter for CursorHooks {
    fn supports(&self, event: HookEvent) -> bool {
        event_key(event).is_some()
    }
    fn render_hook(&self, entry: &HookEntry) -> Value {
        let mut e = serde_json::Map::new();
        e.insert("command".into(), entry.command().into());
        if let Some(t) = entry.timeout_secs {
            e.insert("timeout".into(), t.into());
        }
        if let Some(m) = &entry.matcher {
            e.insert("matcher".into(), m.clone().into());
        }
        Value::Object(e)
    }
    fn parse_hooks(&self, text: &str, path: &Path) -> Result<Vec<(String, Value)>> {
        let doc = json_doc::parse_object(text, path)?;
        let Some(hooks) = doc.get("hooks") else {
            return Ok(vec![]);
        };
        let hooks = hooks.as_object().ok_or_else(|| shape(path))?;
        let mut out = Vec::new();
        for (key, list) in hooks {
            let Some(event) = event_of(key) else { continue };
            for entry in list.as_array().ok_or_else(|| shape(path))? {
                if let Some(id) = identity_of(event, entry) {
                    out.push((id, entry.clone()));
                }
            }
        }
        Ok(out)
    }
    fn upsert(&self, text: &str, entry: &HookEntry, path: &Path) -> Result<String> {
        let key = event_key(entry.event).ok_or_else(|| {
            Error::unsupported(
                "HOOK-EVENT",
                format!("Cursor has no {} hook", entry.event.as_str()),
            )
        })?;
        let mut doc = if text.trim().is_empty() {
            json!({"version": 1, "hooks": {}})
        } else {
            json_doc::parse_object(text, path)?
        };
        let identity = entry.identity();
        let wanted = self.render_hook(entry);
        let list = entries(&mut doc, key, path)?;
        let mut placed = false;
        list.retain_mut(|e| {
            if identity_of(entry.event, e).as_deref() != Some(&identity) {
                return true;
            }
            if placed {
                return false;
            }
            *e = wanted.clone();
            placed = true;
            true
        });
        if !placed {
            list.push(wanted);
        }
        json_doc::render_if_changed(text, &doc, path)
    }
    fn remove(&self, text: &str, identity: &str, path: &Path) -> Result<String> {
        let Some(key) = identity
            .split_once('/')
            .and_then(|(e, _)| HookEvent::parse(e))
            .and_then(event_key)
        else {
            return Ok(text.to_string());
        };
        let mut doc = json_doc::parse_object(text, path)?;
        let present = doc.get("hooks").and_then(|h| h.get(key)).is_some();
        if !present {
            return Ok(text.to_string());
        }
        let event = event_of(key).expect("mapped above");
        let list = existing_entries(&mut doc, key, path)?;
        let before = list.len();
        list.retain(|e| identity_of(event, e).as_deref() != Some(identity));
        if list.len() != before && list.is_empty() {
            doc["hooks"]
                .as_object_mut()
                .expect("checked above")
                .shift_remove(key);
        }
        json_doc::render_if_changed(text, &doc, path)
    }
}

pub struct CursorMcp;

impl McpFormatAdapter for CursorMcp {
    fn document(&self) -> Document {
        Document::Json
    }
    fn keys(&self, name: &str) -> Vec<String> {
        vec!["mcpServers".into(), name.into()]
    }
    fn render_server(&self, def: &McpDef) -> Result<Option<Value>> {
        let cursor_ref = |value: &str| value.replace("${env:", "${").replace("${", "${env:");
        let mut s = serde_json::Map::new();
        match def.transport {
            McpTransport::Stdio => {
                s.insert("command".into(), def.command.clone().into());
                s.insert("args".into(), def.args.clone().into());
                let env = super::stdio_env(def, |k| format!("${{env:{k}}}"));
                if !env.is_empty() {
                    s.insert("env".into(), Value::Object(env));
                }
            }
            McpTransport::Http | McpTransport::Sse => {
                s.insert("url".into(), def.url.clone().into());
                if !def.headers.is_empty() {
                    let headers: serde_json::Map<String, Value> = def
                        .headers
                        .iter()
                        .map(|(k, v)| (k.clone(), cursor_ref(v).into()))
                        .collect();
                    s.insert("headers".into(), Value::Object(headers));
                }
            }
        }
        Ok(Some(Value::Object(s)))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn p() -> &'static Path {
        Path::new("/home/a/.cursor/hooks.json")
    }

    fn usage(event: HookEvent) -> HookEntry {
        HookEntry {
            event,
            matcher: None,
            argv: [
                "/home/a/.local/bin/wf",
                "hook",
                "dispatch",
                "--event",
                event.as_str(),
                "--agent",
                "cursor",
            ]
            .map(String::from)
            .to_vec(),
            timeout_secs: Some(10),
        }
    }

    #[test]
    fn cursor_maps_four_events_and_refuses_the_rest() {
        assert_eq!(event_key(HookEvent::SessionStart), Some("sessionStart"));
        assert_eq!(event_key(HookEvent::Stop), Some("stop"));
        assert_eq!(event_key(HookEvent::PostToolUse), Some("postToolUse"));
        assert_eq!(
            event_key(HookEvent::UserPromptSubmit),
            Some("beforeSubmitPrompt")
        );
        assert!(!CursorHooks.supports(HookEvent::SessionEnd));
        assert!(!CursorHooks.supports(HookEvent::PreToolUse));
    }

    #[test]
    fn a_new_document_is_version_one_and_entries_carry_no_marker_field() {
        let text = CursorHooks
            .upsert("", &usage(HookEvent::Stop), p())
            .unwrap();
        let doc: Value = serde_json::from_str(&text).unwrap();
        assert_eq!(doc["version"], 1);
        assert_eq!(
            doc["hooks"]["stop"],
            json!([{"command": "/home/a/.local/bin/wf hook dispatch --event Stop --agent cursor", "timeout": 10}])
        );
        assert_eq!(
            CursorHooks
                .upsert(&text, &usage(HookEvent::Stop), p())
                .unwrap(),
            text
        );
    }

    #[test]
    fn user_entries_survive_and_removal_restores_the_document() {
        let user = r#"{"version": 1, "hooks": {"stop": [{"command": "afplay done.aiff"}], "afterFileEdit": [{"command": "prettier"}]}}"#;
        let with = CursorHooks
            .upsert(user, &usage(HookEvent::Stop), p())
            .unwrap();
        let with = CursorHooks
            .upsert(&with, &usage(HookEvent::PostToolUse), p())
            .unwrap();
        let mut ids: Vec<String> = CursorHooks
            .parse_hooks(&with, p())
            .unwrap()
            .into_iter()
            .map(|(i, _)| i)
            .collect();
        ids.sort();
        assert_eq!(ids, ["PostToolUse/capso-wf-usage", "Stop/capso-wf-usage"]);
        let without = CursorHooks
            .remove(&with, "Stop/capso-wf-usage", p())
            .unwrap();
        let without = CursorHooks
            .remove(&without, "PostToolUse/capso-wf-usage", p())
            .unwrap();
        assert_eq!(
            serde_json::from_str::<Value>(&without).unwrap(),
            serde_json::from_str::<Value>(user).unwrap()
        );
    }

    /// Establishing wf's own handler may create the schema key; taking it back out may not.
    /// A removal that pinned somebody's file to a hook schema wf chose would be a change wf
    /// made on its way to leaving.
    #[test]
    fn removal_creates_nothing_on_its_way_out() {
        let user = r#"{"hooks": {"stop": [{"command": "afplay done.aiff"}]}}"#;
        let with = CursorHooks
            .upsert(user, &usage(HookEvent::Stop), p())
            .unwrap();
        assert_eq!(serde_json::from_str::<Value>(&with).unwrap()["version"], 1);
        let without = CursorHooks
            .remove(&with, "Stop/capso-wf-usage", p())
            .unwrap();
        assert!(serde_json::from_str::<Value>(&without).unwrap()["version"].is_number());
        // And a document wf never wrote into comes back byte for byte.
        assert_eq!(
            CursorHooks
                .remove(user, "PostToolUse/capso-wf-usage", p())
                .unwrap(),
            user
        );
    }

    #[test]
    fn a_matcher_rides_on_the_entry() {
        let mut e = usage(HookEvent::PostToolUse);
        e.matcher = Some("Skill".into());
        assert_eq!(CursorHooks.render_hook(&e)["matcher"], "Skill");
    }

    #[test]
    fn a_malformed_document_is_refused() {
        for bad in ["{", r#"{"hooks": []}"#, r#"{"hooks": {"stop": {}}}"#] {
            assert!(
                CursorHooks
                    .upsert(bad, &usage(HookEvent::Stop), p())
                    .is_err(),
                "{bad}"
            );
        }
    }

    #[test]
    fn mcp_references_use_cursors_env_prefix() {
        let def = McpDef {
            schema_version: 1,
            name: "capso-linear".into(),
            description: String::new(),
            transport: McpTransport::Stdio,
            command: Some("npx".into()),
            args: vec!["-y".into(), "mcp-remote".into()],
            url: None,
            env_references: vec!["LINEAR_API_TOKEN".into()],
            headers: Default::default(),
            startup_timeout_sec: None,
            component: Some("capso.mcp.linear".into()),
        };
        assert_eq!(
            CursorMcp.render_server(&def).unwrap(),
            Some(
                json!({"command": "npx", "args": ["-y", "mcp-remote"], "env": {"LINEAR_API_TOKEN": "${env:LINEAR_API_TOKEN}", "WF_MCP_COMPONENT": "capso.mcp.linear"}})
            )
        );
        let http = McpDef {
            transport: McpTransport::Http,
            command: None,
            args: vec![],
            url: Some("https://mcp.linear.app/mcp".into()),
            env_references: vec![],
            headers: [(
                "Authorization".to_string(),
                "Bearer ${LINEAR_API_TOKEN}".to_string(),
            )]
            .into(),
            ..def
        };
        assert_eq!(
            CursorMcp.render_server(&http).unwrap(),
            Some(
                json!({"url": "https://mcp.linear.app/mcp", "headers": {"Authorization": "Bearer ${env:LINEAR_API_TOKEN}"}})
            )
        );
    }
}
