//! Codex: hooks in `hooks.json`, MCP servers in `config.toml`, role files in `agents/`.
//!
//! Two things make Codex different from Claude, and both are about not creating work for a
//! person. Codex binds a hook's trust to its exact definition (CLM-003), so the dispatcher
//! handler must render to the same bytes release after release. And Codex expands nothing:
//! an environment value is forwarded by *name* (`env_vars`, `bearer_token_env_var`), never
//! by a `${VAR}` string that would reach the server literally.

use super::{
    claude, Document, HookEntry, HookEvent, HookFormatAdapter, McpDef, McpFormatAdapter,
    McpTransport,
};
use serde_json::{json, Value};
use std::path::{Path, PathBuf};
use wf_core::{Error, Result};

/// Codex's default instruction budget. A longer effective file is truncated, and the half
/// that goes is the half after the organization block — which is why the block is prepended.
pub const PROJECT_DOC_MAX_BYTES: usize = 32 * 1024;

pub struct CodexHooks;

impl HookFormatAdapter for CodexHooks {
    fn supports(&self, _event: HookEvent) -> bool {
        true
    }
    fn marks_handlers(&self) -> bool {
        true
    }
    fn render_hook(&self, entry: &HookEntry) -> Value {
        claude::native(entry)
    }
    fn parse_hooks(&self, text: &str, path: &Path) -> Result<Vec<(String, Value)>> {
        claude::parse_grouped(text, path, true)
    }
    fn upsert(&self, text: &str, entry: &HookEntry, path: &Path) -> Result<String> {
        claude::upsert_grouped(text, entry, path, true)
    }
    fn remove(&self, text: &str, identity: &str, path: &Path) -> Result<String> {
        claude::remove_grouped(text, identity, path, true)
    }
}

/// The instructions file this Codex actually reads: `AGENTS.override.md` when it has content,
/// `AGENTS.md` otherwise. A read failure is not evidence the override is absent.
pub fn effective_prompt_file(root: &Path) -> Result<PathBuf> {
    let over = root.join("AGENTS.override.md");
    if !wf_core::paths::read_text_or_empty(&over)?.trim().is_empty() {
        Ok(over)
    } else {
        Ok(root.join("AGENTS.md"))
    }
}

/// The other one of the pair — where a stale copy of the block must not be left behind.
pub fn shadow_prompt_file(root: &Path, effective: &Path) -> PathBuf {
    root.join(if effective.ends_with("AGENTS.override.md") {
        "AGENTS.md"
    } else {
        "AGENTS.override.md"
    })
}

/// Codex's own verdict on our handler, from `hooks/list`. `None` when Codex does not report
/// exactly one matching handler: an ambiguous answer is not a trusted one.
pub fn trust_for_handler(result: &Value, handler: &Value, hooks_path: &Path) -> Option<bool> {
    let rows = result["data"].as_array()?;
    let mut matches = rows
        .iter()
        .filter_map(|row| row["hooks"].as_array())
        .flatten()
        .filter(|entry| {
            entry["eventName"] == "sessionStart"
                && entry["handlerType"] == "command"
                && entry["command"] == handler["command"]
                && entry["statusMessage"] == handler["statusMessage"]
                && entry["source"] == "user"
                && entry["sourcePath"].as_str() == hooks_path.to_str()
        });
    let entry = matches.next()?;
    if matches.next().is_some() {
        return None;
    }
    match entry["trustStatus"].as_str() {
        Some("trusted") => Some(true),
        Some("untrusted") => Some(false),
        _ => None,
    }
}

pub struct CodexMcp;

impl McpFormatAdapter for CodexMcp {
    fn document(&self) -> Document {
        Document::Toml
    }
    fn keys(&self, name: &str) -> Vec<String> {
        vec!["mcp_servers".into(), name.into()]
    }
    fn render_server(&self, def: &McpDef) -> Result<Option<Value>> {
        let mut s = serde_json::Map::new();
        match def.transport {
            McpTransport::Sse => return Ok(None),
            McpTransport::Stdio => {
                s.insert("command".into(), def.command.clone().into());
                s.insert("args".into(), def.args.clone().into());
                if !def.env_references.is_empty() {
                    s.insert("env_vars".into(), def.env_references.clone().into());
                }
                // Not a credential: the component id, so the bridge can be told apart as ours.
                if let Some(component) = &def.component {
                    s.insert(
                        "env".into(),
                        json!({ super::COMPONENT_ENV: component.clone() }),
                    );
                }
            }
            McpTransport::Http => {
                s.insert("url".into(), def.url.clone().into());
                let mut from_env = serde_json::Map::new();
                let mut literal = serde_json::Map::new();
                for (name, value) in &def.headers {
                    let whole_ref = value
                        .strip_prefix("${")
                        .and_then(|v| v.strip_suffix('}'))
                        .filter(|v| super::env_name(v));
                    let bearer_ref = value
                        .strip_prefix("Bearer ${")
                        .and_then(|v| v.strip_suffix('}'))
                        .filter(|v| super::env_name(v));
                    if let (true, Some(var)) =
                        (name.eq_ignore_ascii_case("authorization"), bearer_ref)
                    {
                        s.insert("bearer_token_env_var".into(), var.into());
                    } else if let Some(var) = whole_ref {
                        from_env.insert(name.clone(), var.into());
                    } else if value.contains("${") {
                        return Err(Error::usage(
                            "MCP-CODEX-HEADER",
                            format!(
                                "{}: header {name} embeds a reference Codex cannot expand; make the whole value ${{NAME}}",
                                def.name
                            ),
                        ));
                    } else {
                        literal.insert(name.clone(), value.clone().into());
                    }
                }
                if !from_env.is_empty() {
                    s.insert("env_http_headers".into(), Value::Object(from_env));
                }
                if !literal.is_empty() {
                    s.insert("http_headers".into(), Value::Object(literal));
                }
            }
        }
        // Codex waits 30 s for a server to start and then leaves it out of the session
        // without a message (txe-workflow#50); a slow one says how long it needs.
        if let Some(seconds) = def.startup_timeout_sec {
            s.insert("startup_timeout_sec".into(), seconds.into());
        }
        Ok(Some(json!(s)))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn p() -> &'static Path {
        Path::new("/tmp/codex/hooks.json")
    }

    fn bootstrap(binary: &str) -> HookEntry {
        HookEntry {
            event: HookEvent::SessionStart,
            matcher: None,
            argv: [binary, "hook", "session-start", "--agent", "codex"]
                .map(String::from)
                .to_vec(),
            timeout_secs: None,
        }
    }

    /// CLM-003: a definition that moves per release un-trusts itself. This is the byte string
    /// wf 1.x wrote into every Codex `hooks.json`; changing it asks every person to re-trust.
    #[test]
    fn the_dispatcher_renders_to_the_bytes_codex_already_trusts() {
        assert_eq!(
            serde_json::to_string(&CodexHooks.render_hook(&bootstrap("/home/u/.local/bin/wf")))
                .unwrap(),
            r#"{"type":"command","command":"/home/u/.local/bin/wf hook session-start --agent codex","statusMessage":"capso-wf-bootstrap"}"#
        );
    }

    #[test]
    fn owned_handler_is_nested_unique_and_removable_without_siblings() {
        let entry = bootstrap("/home/a person's/bin/wf");
        let user = json!({"hooks":{"SessionStart":[{"matcher":"startup","hooks":[{"type":"command","command":"echo user"}]}],"Stop":[{"hooks":[{"type":"command","command":"echo stop"}]}]}}).to_string();
        let once = CodexHooks.upsert(&user, &entry, p()).unwrap();
        assert_eq!(once, CodexHooks.upsert(&once, &entry, p()).unwrap());
        let parsed: Value = serde_json::from_str(&once).unwrap();
        assert_eq!(
            parsed["hooks"]["SessionStart"][1]["hooks"][0]["type"],
            "command"
        );
        let removed: Value =
            serde_json::from_str(&CodexHooks.remove(&once, &entry.identity(), p()).unwrap())
                .unwrap();
        assert_eq!(removed, serde_json::from_str::<Value>(&user).unwrap());
    }

    #[test]
    fn replacing_the_legacy_flat_handler_preserves_other_handlers_in_the_same_group() {
        let text = r#"{"hooks":{"SessionStart":[{"description":"capso-wf-bootstrap","argv":["wf"]},{"matcher":"startup","hooks":[{"statusMessage":"capso-wf-bootstrap","command":"old"},{"command":"user","type":"command"}]}]}}"#;
        let removed: Value = serde_json::from_str(
            &CodexHooks
                .remove(text, "SessionStart/capso-wf-bootstrap", p())
                .unwrap(),
        )
        .unwrap();
        assert_eq!(
            removed["hooks"]["SessionStart"],
            json!([{"matcher":"startup","hooks":[{"command":"user","type":"command"}]}])
        );
    }

    #[test]
    fn malformed_hooks_are_refused() {
        for body in ["{broken", "[]", r#"{"hooks":{"SessionStart":"bad"}}"#] {
            assert!(
                CodexHooks.upsert(body, &bootstrap("/bin/wf"), p()).is_err(),
                "{body}"
            );
        }
    }

    #[test]
    fn override_read_failure_is_not_absence() {
        let temp = tempfile::tempdir().unwrap();
        assert!(effective_prompt_file(temp.path())
            .unwrap()
            .ends_with("AGENTS.md"));
        let path = temp.path().join("AGENTS.override.md");
        std::fs::write(&path, " \n").unwrap();
        assert!(effective_prompt_file(temp.path())
            .unwrap()
            .ends_with("AGENTS.md"));
        std::fs::write(&path, "user override").unwrap();
        assert_eq!(effective_prompt_file(temp.path()).unwrap(), path);
        assert_eq!(
            shadow_prompt_file(temp.path(), &path),
            temp.path().join("AGENTS.md")
        );
        assert_eq!(
            shadow_prompt_file(temp.path(), &temp.path().join("AGENTS.md")),
            path
        );
        std::fs::write(&path, [0xff]).unwrap();
        assert!(effective_prompt_file(temp.path()).is_err());
    }

    #[test]
    fn trust_comes_from_the_exact_native_handler() {
        let handler = CodexHooks.render_hook(&bootstrap("/bin/wf"));
        let mut result = json!({"data":[{"hooks":[{"eventName":"sessionStart","handlerType":"command","command":handler["command"],"statusMessage":handler["statusMessage"],"source":"user","sourcePath":"/tmp/codex/hooks.json","trustStatus":"untrusted"}]}]});
        assert_eq!(trust_for_handler(&result, &handler, p()), Some(false));
        result["data"][0]["hooks"][0]["trustStatus"] = json!("trusted");
        assert_eq!(trust_for_handler(&result, &handler, p()), Some(true));
        let twice = result["data"][0]["hooks"][0].clone();
        result["data"][0]["hooks"]
            .as_array_mut()
            .unwrap()
            .push(twice);
        assert_eq!(
            trust_for_handler(&result, &handler, p()),
            None,
            "ambiguous is not trusted"
        );
        result["data"][0]["hooks"].as_array_mut().unwrap().pop();
        result["data"][0]["hooks"][0]["command"] = json!("different");
        assert_eq!(trust_for_handler(&result, &handler, p()), None);
    }

    #[test]
    fn codex_hooks_cover_every_canonical_event() {
        for e in HookEvent::ALL {
            assert!(CodexHooks.supports(e));
        }
    }

    fn linear() -> McpDef {
        McpDef {
            schema_version: 1,
            name: "capso-linear".into(),
            description: String::new(),
            transport: McpTransport::Stdio,
            command: Some("npx".into()),
            args: vec![
                "-y".into(),
                "mcp-remote".into(),
                "https://mcp.linear.app/sse".into(),
            ],
            url: None,
            env_references: vec!["LINEAR_API_TOKEN".into()],
            headers: Default::default(),
            startup_timeout_sec: None,
            component: None,
        }
    }

    /// The component is a literal in the server's own `env` table; the credential stays
    /// forwarded by name.
    #[test]
    fn an_installed_stdio_server_carries_its_component_in_its_environment() {
        let installed = McpDef {
            component: Some("capso.mcp.linear".into()),
            ..linear()
        };
        let rendered = CodexMcp.render_server(&installed).unwrap().unwrap();
        assert_eq!(
            rendered["env"],
            json!({"WF_MCP_COMPONENT": "capso.mcp.linear"})
        );
        assert_eq!(rendered["env_vars"], json!(["LINEAR_API_TOKEN"]));
    }

    /// The limit reaches the server's own table, where Codex reads it, and a definition
    /// without one leaves Codex's default alone.
    #[test]
    fn a_slow_server_carries_its_startup_limit_into_its_own_table() {
        let slow = McpDef {
            startup_timeout_sec: Some(120),
            env_references: vec![],
            ..linear()
        };
        let rendered = CodexMcp.render_server(&slow).unwrap().unwrap();
        assert_eq!(rendered["startup_timeout_sec"], json!(120));
        assert!(CodexMcp
            .render_server(&linear())
            .unwrap()
            .unwrap()
            .get("startup_timeout_sec")
            .is_none());
    }

    #[test]
    fn a_stdio_server_forwards_its_environment_by_name() {
        assert_eq!(
            CodexMcp.render_server(&linear()).unwrap(),
            Some(json!({
                "command": "npx",
                "args": ["-y", "mcp-remote", "https://mcp.linear.app/sse"],
                "env_vars": ["LINEAR_API_TOKEN"]
            }))
        );
        let bare = McpDef {
            env_references: vec![],
            ..linear()
        };
        assert!(CodexMcp
            .render_server(&bare)
            .unwrap()
            .unwrap()
            .get("env_vars")
            .is_none());
    }

    #[test]
    fn an_http_server_maps_each_header_to_what_codex_can_read() {
        let http = McpDef {
            transport: McpTransport::Http,
            command: None,
            args: vec![],
            url: Some("https://mcp.linear.app/mcp".into()),
            env_references: vec![],
            headers: [
                (
                    "Authorization".to_string(),
                    "Bearer ${LINEAR_API_TOKEN}".to_string(),
                ),
                ("X-Team".to_string(), "${TEAM_HEADER}".to_string()),
                ("X-Client".to_string(), "wf".to_string()),
            ]
            .into(),
            ..linear()
        };
        assert_eq!(
            CodexMcp.render_server(&http).unwrap(),
            Some(json!({
                "url": "https://mcp.linear.app/mcp",
                "bearer_token_env_var": "LINEAR_API_TOKEN",
                "env_http_headers": {"X-Team": "TEAM_HEADER"},
                "http_headers": {"X-Client": "wf"}
            }))
        );
        let embedded = McpDef {
            headers: [("X-Key".to_string(), "prefix-${KEY}".to_string())].into(),
            ..http.clone()
        };
        let err = CodexMcp.render_server(&embedded).unwrap_err();
        assert!(err.message.contains("X-Key"), "{}", err.message);
        let sse = McpDef {
            transport: McpTransport::Sse,
            ..http
        };
        assert_eq!(
            CodexMcp.render_server(&sse).unwrap(),
            None,
            "Codex has no SSE transport"
        );
    }
}
