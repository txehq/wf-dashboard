use super::{emit, options};
use crate::flags::RemoteArgs;
use serde::Serialize;
use wf_agents::adapter::{ConfigAdapter, TeamAIAdapter};
use wf_core::{envelope::Envelope, envelope::Note, ExitCode, Result};
use wf_release::source::ReleaseSource;
use wf_state::{ComponentState, Db, NativeObject, Transaction};
use wf_sync::{CtxReport, Engine, SyncOutcome};

/// First install.
///
/// The order is deliberate: refuse an unsupported platform before anything is downloaded,
/// check the login before a download fails halfway, then stage, apply and verify. The last
/// step is the slow one — ctx, the local history — and it is last so that an interrupted
/// install still leaves a working workflow.
pub fn install(json: bool, remote: &RemoteArgs, agent: &str, dry_run: bool) -> Result<ExitCode> {
    if !wf_core::paths::platform_supported() {
        return Err(wf_core::Error::unsupported(
            "PLATFORM-UNSUPPORTED",
            format!(
                "{} is not a supported target",
                wf_core::paths::target_triple()
            ),
        )
        .with_zh(wf_core::zh::unsupported_platform(
            wf_core::paths::target_triple(),
        )));
    }

    // A misspelt agent fails here, before anything is downloaded.
    wf_agents::registry::AgentRegistry::builtin().select(agent)?;
    let mut opts = options(remote)?;
    opts.agents = Some(agent.to_string());
    opts.dry_run = dry_run;
    opts.force = true;

    // Fail early and in the operator's language, before anything is downloaded.
    if let ReleaseSource::GitHub { repo, .. } = &opts.source {
        wf_release::github::Gh::new(repo.clone()).preflight()?;
    }

    let engine = Engine::open(opts.clone())?;
    let guard = engine.lifecycle_lock(false)?;
    let (desired, warnings) = engine.resolve_desired();
    engine.record_remote_result(desired.as_ref())?;
    let Some(rel) = desired else {
        let mut env = Envelope::new("install").error(
            Note::new("NO-RELEASE", "no installable release on this channel")
                .with_zh(wf_core::zh::no_release(&opts.repo, opts.channel.as_str())),
        );
        for w in warnings {
            env = env.warn(Note::new("REMOTE", w.clone()).with_zh(w));
        }
        return Ok(emit(json, env, String::new));
    };

    let (lock, dir) = engine.stage(&rel)?;
    if !lock.supports_platform(wf_core::paths::target_triple()) {
        return Err(wf_core::Error::unsupported(
            "PLATFORM-UNSUPPORTED",
            format!(
                "release {} does not carry {}",
                rel.version,
                wf_core::paths::target_triple()
            ),
        )
        .with_zh(wf_core::zh::unsupported_platform(
            wf_core::paths::target_triple(),
        )));
    }

    let outcome = engine.install(&rel.version, &dir)?;
    let replaced_binary = outcome.applied.iter().any(|id| id == "capso.wf.binary");

    // The slow step, last, outside the lifecycle lock, and never fatal: an install whose ctx
    // failed is a working install with one capability missing, the machine records which,
    // and the next session start tries again.
    drop(guard);
    let ctx = (!outcome.rolled_back).then(|| engine.converge_ctx(&lock, true, false));
    let ctx_note = ctx_line(ctx.as_ref());

    // Asked before the closure, which is `move`, and only when there is something to say.
    //
    // `binary().exists()` is the half this first shipped without. A release built without
    // `--with-binary` installs the workflow and no executable, and the notice still
    // announced where wf had been put — naming a directory that does not contain it and
    // handing over a PATH line that would fix nothing.
    let path_hint = (!dry_run && !outcome.rolled_back)
        .then(|| {
            let paths = &engine.paths;
            let var = std::env::var("PATH").unwrap_or_default();
            (paths.binary().exists() && !paths.bin_dir_on_path(&var))
                .then(|| paths.bin_dir.display().to_string())
        })
        .flatten();

    // Derived from what this machine has, not from a fixed list — see `next_steps`.
    let next = if dry_run || outcome.rolled_back {
        Vec::new()
    } else {
        next_steps(&engine)
    };

    let mut env = with_ctx(outcome_envelope("install", &outcome), ctx.as_ref());
    // What this machine already reached, read before the first write. It goes in the result
    // whether or not anything was written, because the person about to be asked is reading
    // this document, not the machine.
    let candidates = outcome.candidates.clone();
    env.result["mcp"] = serde_json::json!({ "candidates": candidates });
    if candidates
        .iter()
        .any(|c| c.by == wf_agents::formats::Occupied::Host)
    {
        // One line, and it names only our own servers. A person whose machine now reaches
        // the same service twice needs to know it happened.
        let names: Vec<String> = {
            let mut seen: Vec<String> = Vec::new();
            for c in candidates
                .iter()
                .filter(|c| c.by == wf_agents::formats::Occupied::Host)
            {
                if !seen.contains(&c.name) {
                    seen.push(c.name.clone());
                }
            }
            seen
        };
        env = env.warn(
            Note::new(
                "MCP-ALREADY-CONNECTED",
                format!(
                    "An existing connection reaches the published service for {}. Installing the wf-managed entry can create another connection.",
                    names.join(", ")
                ),
            )
            .with_zh(format!(
                "检测到 {} 发布的服务已有连接。安装 wf 管理的条目可能产生重复连接。",
                names.join("、")
            )),
        );
    }
    for w in outcome.warnings.iter().chain(warnings.iter()) {
        env = env.warn(Note::new("INSTALL", w.clone()).with_zh(w.clone()));
    }
    let version = rel.version.clone();
    Ok(emit(json, env, move || {
        let mut s = if dry_run {
            format!("演练完成，什么都没有改动。将要安装的是 {version}。\n")
        } else if outcome.rolled_back {
            // Reporting an install that did not happen as one that did is the single worst
            // thing this command can do: the operator walks away and finds out later.
            format!("安装没有成功，已尝试还原先前状态（目标版本是 {version}）。\n")
        } else {
            format!("已安装 {version}。\n")
        };
        for step in &outcome.plan {
            s.push_str(&format!("  {:<44} {}\n", step.action, step.path));
        }
        if replaced_binary {
            s.push_str("wf 自身也更新到了这个版本。\n");
        }
        if let Some(line) = &ctx_note {
            s.push_str(&format!("{line}\n"));
        }
        if let Some(dir) = &path_hint {
            // Said before "接下来", because the next step is to type `wf`.
            s.push_str(&format!(
                "\n还差一步：wf 装在 {dir}，但你的终端暂时找不到它。\n\
                 把这行加到 ~/.zshrc（或 ~/.bashrc）的末尾，然后新开一个终端：\n  \
                 export PATH=\"{dir}:$PATH\"\n"
            ));
        }
        if !next.is_empty() {
            s.push_str("\n接下来：\n");
            for (i, step) in next.iter().enumerate() {
                s.push_str(&format!("  {}. {step}\n", i + 1));
            }
        }
        s
    }))
}

/// What the person does after the install, derived from what this machine actually has.
///
/// The first version of this list was fixed text, and fixed text is wrong on most machines:
/// a laptop without Codex has no hook to trust, and a component that declares no reference has
/// no token to set. Each line here is printed only when its condition
/// was observed by the verify that just ran, and the list ends with the two doors into the
/// workflow — the sentence people actually came for.
fn next_steps(engine: &Engine) -> Vec<String> {
    let mut steps = Vec::new();
    let rows = engine.db.components().unwrap_or_default();

    // Codex binds trust to the exact hook definition and only a person can grant it. wf
    // reads that decision and never writes it, so this is the one step that stays manual.
    let codex_hook_blocked = rows.iter().any(|(id, agent, state, _)| {
        id == "capso.hook.session-start" && agent == "codex" && *state == ComponentState::Blocked
    });
    if codex_hook_blocked {
        steps.push(
            "在 Codex 里输入 `/hooks`，确认并信任那个启动钩子（只需要做一次；这一步 wf 不会、也不能替你完成）。"
                .to_string(),
        );
    }

    // Credentials, asked the way `wf doctor` and the session-start hook ask them — one rule,
    // three callers, so the three cannot disagree on the same machine.
    //
    // The only login this list names belongs to a server this install just put in place, and
    // the only command it gives is one the person runs against their own shell. A connection
    // they hold to the same service is theirs (WFR-016): naming it here would send them to a
    // server `wf` can neither check nor repair.
    if let Some(bundle) = engine.active_bundle_dir() {
        if let Ok(registry) = wf_registry::Registry::load(&bundle) {
            // A server declined everywhere has nothing of ours to log into, and naming a
            // browser page for it would be the first of exactly the prompts a decision ends.
            //
            // Declined *somewhere* is a different thing. The credential is kept once and
            // shared by every agent, so one copy left in Codex still has to be logged into;
            // suppressing on any single decision would leave that copy permanently unusable
            // with nothing on the machine saying why.
            let declined = engine.db.skipped_mcps().unwrap_or_default();
            for component in registry.of_kind(wf_registry::Kind::Mcp) {
                let Some(cred) = &component.credentials else {
                    continue;
                };
                let carrying: Vec<&String> = rows
                    .iter()
                    .filter(|(id, ..)| id == &component.id)
                    .map(|(_, agent, ..)| agent)
                    .collect();
                let declined_everywhere = !carrying.is_empty()
                    && carrying.iter().all(|agent| {
                        declined
                            .iter()
                            .any(|s| s.component_id == component.id && &&s.agent_id == agent)
                    });
                if declined_everywhere {
                    continue;
                }
                match wf_agents::credentials::credential_status(cred) {
                    wf_agents::credentials::CredentialStatus::Satisfied => {}
                    wf_agents::credentials::CredentialStatus::LoginUnverified => {
                        let host = if cred.login_host.is_empty() {
                            "服务方"
                        } else {
                            cred.login_host.as_str()
                        };
                        steps.push(format!(
                            "{} 第一次用到时会打开浏览器登录 {host}，按提示完成授权即可。\
                             凭据存在本机、各个 agent 共用同一份；wf 看不到有没有登录过，\
                             要确认就发一次真实的只读调用。",
                            component.id
                        ));
                    }
                    wf_agents::credentials::CredentialStatus::Missing(names) => {
                        steps.push(format!(
                            "{} 还缺少 {}。把它加到 shell 配置（例如 ~/.zshrc）里，然后重开一个终端。",
                            component.id,
                            names.join("、")
                        ));
                    }
                }
            }
        }
    }

    steps.push("新开一个会话，然后运行 `wf doctor` 确认一切就绪。".to_string());
    steps.push(
        "开始工作：做架构、规划和拆票从 `/lfg` 进入；领一张票开始实现从 `/ic` 进入。".to_string(),
    );
    steps
}

/// What `wf sync` was asked to do.
pub struct SyncFlags {
    pub force: bool,
    pub offline: bool,
    pub dry_run: bool,
    pub from_hook: bool,
    pub agent: Option<String>,
}

/// Bring the machine to the current release.
pub fn sync(json: bool, remote: &RemoteArgs, flags: SyncFlags) -> Result<ExitCode> {
    let SyncFlags {
        force,
        offline,
        dry_run,
        from_hook,
        agent,
    } = flags;
    let mut opts = options(remote)?;
    opts.force = force;
    opts.offline = offline;
    opts.dry_run = dry_run;
    opts.agents = agent;

    let engine = Engine::open(opts.clone())?;
    // The detached worker may start before its dispatcher releases the lock. Unlike the
    // foreground hook, this finite process can wait for that handoff without delaying a session.
    let guard = match engine.lifecycle_lock(false) {
        Ok(guard) => guard,
        Err(_) if from_hook => return Ok(ExitCode::Ok),
        Err(error) => return Err(error),
    };
    if from_hook && !engine.source_still_current()? {
        return Ok(ExitCode::Ok);
    }
    let run = if dry_run {
        None
    } else {
        Some(
            engine
                .db
                .start_run(if from_hook { "hook" } else { "cli" })?,
        )
    };

    let started = std::time::Instant::now();

    let (desired, mut warnings) = engine.resolve_desired();
    engine.record_remote_result(desired.as_ref())?;
    let active = engine.db.active_generation()?;

    // Set when an update was attempted and refused, so the headline cannot contradict the
    // warning printed directly beneath it.
    let mut update_failed = false;
    let outcome = match desired {
        Some(rel) => {
            if !dry_run {
                engine.db.set_meta("desired_version", &rel.version)?;
            }
            // Already on it, and applied by this binary. A version the previous binary applied
            // has not had this one's agent layer run over it yet.
            let already = active
                .as_ref()
                .map(|g| g.version == rel.version)
                .unwrap_or(false)
                && engine
                    .db
                    .meta(wf_sync::engine::META_LAST_APPLIED_BINARY)?
                    .as_deref()
                    == Some(wf_core::VERSION);
            if already && !force {
                SyncOutcome {
                    changed: false,
                    degraded: vec![],
                    active_version: rel.version.clone(),
                    desired_version: rel.version,
                    applied: vec![],
                    backups: vec![],
                    rolled_back: false,
                    dry_run,
                    plan: vec![],
                    warnings: warnings.clone(),
                    followups: vec![],
                    agents: vec![],
                    candidates: vec![],
                }
            } else {
                match engine.stage(&rel) {
                    Ok((_, dir)) => engine.apply(&rel.version, &dir)?,
                    Err(e) if e.code == wf_core::ExitCode::Integrity => return Err(e),
                    Err(e) => {
                        // Anything short of an integrity failure keeps the last known good.
                        update_failed = true;
                        warnings.push(lkg_message(&engine, &e));
                        keep_lkg(&engine, dry_run, warnings.clone())?
                    }
                }
            }
        }
        None => keep_lkg(&engine, dry_run, warnings.clone())?,
    };

    if let Some(run) = run {
        engine.db.end_run(
            run,
            if outcome.rolled_back {
                "rolled_back"
            } else {
                "ok"
            },
            "",
            outcome.changed,
            started.elapsed().as_millis() as u64,
        )?;
    }

    // ctx converges after the release and outside the lifecycle lock: another project's
    // binary downloading must not hold up a person's `wf install`, and a ctx failure never
    // undoes the update above. From the hook, the machine record is the whole report.
    // `--offline` means no network, and converging may need to download ctx.
    drop(guard);
    let ctx = match (
        outcome.rolled_back || offline,
        engine.active_lock().ok().flatten(),
    ) {
        (false, Some(lock)) => Some(engine.converge_ctx(&lock, force, from_hook)),
        _ => None,
    };

    if from_hook {
        return Ok(ExitCode::Ok);
    }

    let mut env = with_ctx(outcome_envelope("sync", &outcome), ctx.as_ref());
    for w in &outcome.warnings {
        env = env.warn(Note::new("SYNC", w.clone()).with_zh(w.clone()));
    }
    let o = outcome.clone();
    let ctx_note = ctx_line(ctx.as_ref());
    Ok(emit(json, env, move || {
        let mut s = headline(&o, update_failed);
        if let Some(line) = &ctx_note {
            s.push_str(&format!("{line}\n"));
        }
        s
    }))
}

/// The first line `wf sync` prints.
fn headline(o: &SyncOutcome, update_failed: bool) -> String {
    if o.dry_run {
        let mut s = String::from("演练完成，什么都没有改动。\n");
        if o.plan.is_empty() {
            s.push_str("  已经是最新的，不需要任何改动。\n");
        }
        for step in &o.plan {
            s.push_str(&format!("  {:<44} {}\n", step.action, step.path));
        }
        s
    } else if o.rolled_back {
        "这次更新没有成功，已尝试还原先前状态，请查看报告中的后续处理项。\n".to_string()
    } else if o.changed {
        format!("已更新到 {}。\n", o.active_version)
    } else if update_failed && o.desired_version == o.active_version {
        // Refused while already on that version: there is no second version to name.
        format!("这次没能更新，现在还是 {}。\n", o.active_version)
    } else if !o.desired_version.is_empty() && o.desired_version != o.active_version {
        // An update was wanted and did not happen. Saying 已经是最新的 here told the
        // operator the opposite of what the accompanying warning said, and the headline
        // is the half most people read.
        format!(
            "没能更新到 {}，现在还是 {}。\n",
            o.desired_version, o.active_version
        )
    } else {
        format!("已经是最新的（{}）。\n", o.active_version)
    }
}

/// What a person is told about ctx after an install or a sync. Failures are not here: they
/// travel as warnings, which carry the fix.
fn ctx_line(ctx: Option<&Result<CtxReport>>) -> Option<String> {
    match ctx? {
        Ok(CtxReport::Installed { version, .. }) => Some(format!(
            "本机历史检索 ctx {version} 已就位：命令行用 `wf history`，agent 里用 wf-history MCP 工具。语义索引会在后台建立。"
        )),
        Ok(CtxReport::WouldInstall { version }) => {
            Some(format!("将安装本机历史检索 ctx {version}。"))
        }
        Ok(CtxReport::Busy) => {
            Some("另一个进程正在安装 ctx，稍后运行 `wf doctor` 看结果。".to_string())
        }
        Ok(CtxReport::Current { .. } | CtxReport::NotPinned) | Err(_) => None,
    }
}

/// Put the ctx outcome into an envelope: the report in `result.ctx`, a failure as a warning.
fn with_ctx(mut env: Envelope, ctx: Option<&Result<CtxReport>>) -> Envelope {
    match ctx {
        Some(Ok(report)) => {
            env.result["ctx"] = serde_json::to_value(report).unwrap_or_default();
            env
        }
        Some(Err(e)) => env.warn(Note::new(e.kind.clone(), e.message.clone()).with_zh(
            if e.zh.is_empty() {
                wf_sync::ctx::zh(&e.kind)
            } else {
                e.zh.clone()
            },
        )),
        None => env,
    }
}

/// What to tell someone whose update did not land.
///
/// The friendly sentence and the engineering one both have to survive: the first is what
/// the person acts on, the second is what they send the team. Dropping the error — which
/// this did whenever a last-known-good existed — left `--json` reporting `ok: true` with
/// an empty `errors` array and a cause that no longer existed anywhere, which is how a
/// same-version staging refusal came to read as a network outage.
///
/// The detail is redacted on the way out, like every other path that prints an error.
fn lkg_message(engine: &Engine, e: &wf_core::Error) -> String {
    let detail = format!(
        "（技术细节：{} — {}）",
        e.kind,
        wf_core::redact::redact(&e.message)
    );
    match engine.db.last_known_good().ok().flatten() {
        // An error that carries its own Chinese carries a remedy with it, and that beats
        // the generic line — which would otherwise promise an automatic retry for a
        // failure no retry can clear.
        Some(g) if !e.zh.is_empty() => {
            format!(
                "{}\n{}\n{detail}",
                e.zh,
                wf_core::zh::still_using(&g.version)
            )
        }
        Some(g) => format!(
            "{}\n{detail}",
            wf_core::zh::update_failed_using_lkg(&g.version)
        ),
        None if e.zh.is_empty() => wf_core::redact::redact(&e.message),
        None => format!("{}\n{detail}", e.zh),
    }
}

fn keep_lkg(engine: &Engine, dry_run: bool, warnings: Vec<String>) -> Result<SyncOutcome> {
    let g = engine.db.last_known_good()?;
    Ok(SyncOutcome {
        changed: false,
        degraded: vec![],
        active_version: g.as_ref().map(|g| g.version.clone()).unwrap_or_default(),
        desired_version: engine.db.meta("desired_version")?.unwrap_or_default(),
        applied: vec![],
        backups: vec![],
        rolled_back: false,
        dry_run,
        plan: vec![],
        warnings,
        followups: vec![],
        agents: vec![],
        candidates: vec![],
    })
}

/// Put the organization's version back where it has drifted.
pub fn repair(
    json: bool,
    remote: &RemoteArgs,
    component: Option<&str>,
    agent: Option<&str>,
    dry_run: bool,
) -> Result<ExitCode> {
    let mut opts = options(remote)?;
    opts.dry_run = dry_run;
    opts.agents = agent.map(String::from);
    opts.offline = true; // Repair works from what is here; sync is what fetches.
    let engine = Engine::open(opts)?;
    let _guard = engine.lifecycle_lock(false)?;

    let Some(g) = engine.db.active_generation()? else {
        return Err(
            wf_core::Error::failure("NOT-INSTALLED", "nothing is installed")
                .with_zh("这台机器还没有安装。先运行一次 `wf install`。".to_string()),
        );
    };
    let dir = engine.paths.generation(&g.version);
    let outcome = engine.apply(&g.version, &dir)?;
    if !dry_run && !outcome.rolled_back && outcome.degraded.is_empty() {
        if let Some(c) = component {
            engine.db.mark_drift_repaired(c)?;
        }
    }

    let mut env = outcome_envelope("repair", &outcome);
    for w in &outcome.warnings {
        env = env.warn(Note::new("REPAIR", w.clone()).with_zh(w.clone()));
    }
    let o = outcome.clone();
    Ok(emit(json, env, move || {
        if o.dry_run {
            let mut s = String::from("演练完成，什么都没有改动。将要修复：\n");
            if o.plan.is_empty() {
                s.push_str("  没有发现需要修复的东西。\n");
            }
            for step in &o.plan {
                s.push_str(&format!("  {:<44} {}\n", step.action, step.path));
            }
            s
        } else if o.rolled_back {
            "修复未完成，已尝试还原先前状态。\n".to_string()
        } else if o.applied.is_empty() {
            "检查完毕，没有发现需要修复的东西。\n".to_string()
        } else {
            let mut s = format!("已修复 {} 项：\n", o.applied.len());
            for a in &o.applied {
                s.push_str(&format!("  {a}\n"));
            }
            if !o.backups.is_empty() {
                s.push_str(&format!(
                    "\n改动之前的内容都已备份（{} 份）。运行 `wf backup list` 可以看到，想还原用 `wf backup restore <编号>`。\n",
                    o.backups.len()
                ));
            }
            s
        }
    }))
}

/// Return the machine to an earlier release.
pub fn rollback(
    json: bool,
    remote: &RemoteArgs,
    to: Option<&str>,
    dry_run: bool,
) -> Result<ExitCode> {
    let mut opts = options(remote)?;
    opts.dry_run = dry_run;
    opts.offline = true;
    let engine = Engine::open(opts)?;
    let _guard = engine.lifecycle_lock(false)?;

    let target = match to {
        Some(v) => v.to_string(),
        None => engine
            .db
            .generations()?
            .into_iter()
            .find(|g| g.status == wf_state::GenerationStatus::LastKnownGood)
            .map(|g| g.version)
            .ok_or_else(|| {
                wf_core::Error::failure("NO-LKG", "no earlier generation to roll back to")
                    .with_zh("没有可以回退的旧版本——这台机器只安装过一个版本。".to_string())
            })?,
    };
    let dir = engine.paths.generation(&target);
    if !dir.join("bundle/workflow/registry.yaml").is_file() {
        return Err(wf_core::Error::failure(
            "GENERATION-MISSING",
            format!("{target} is not on this machine"),
        )
        .with_zh(format!(
            "这台机器上没有 {target} 的副本，没法回退到它。运行 `wf status` 看看有哪些版本。"
        )));
    }
    let outcome = engine.apply(&target, &dir)?;
    let mut env = outcome_envelope("rollback", &outcome);
    if !outcome.degraded.is_empty() {
        env = env.error(Note::new(
            "ROLLBACK-DEGRADED",
            "some native components could not reach the requested version",
        ));
    }
    let t = target.clone();
    let o = outcome.clone();
    Ok(emit(json, env, move || {
        if o.dry_run {
            format!("演练完成，什么都没有改动。将要回退到 {t}。\n")
        } else if o.rolled_back || !o.degraded.is_empty() {
            format!("回退到 {t} 未完整完成，请查看警告并运行 wf doctor。\n")
        } else {
            format!("已回退到 {t}。\n")
        }
    }))
}

/// Remove what we installed, and only what we own: every object the agent layer recorded,
/// the plugin a 1.x release installed, and the files that release left receipts for.
pub fn uninstall(json: bool, dry_run: bool, yes: bool) -> Result<ExitCode> {
    if !yes && !dry_run {
        return Err(wf_core::Error::usage("CONFIRM", "uninstall needs --yes").with_zh(
            "卸载会改动各个 coding agent 的配置。确认要继续的话，加上 `--yes` 再运行一次；\n  想先看看会动哪些东西，用 `wf uninstall --dry-run`。"
                .to_string(),
        ));
    }
    let paths = wf_core::paths::Paths::resolve()?;
    let db = if dry_run {
        Db::open_read_only(&paths.db())?
    } else {
        Db::open(&paths.db())?
    };
    let _guard = if dry_run {
        None
    } else {
        Some(wf_core::lock::Guard::exclusive_within(
            &paths.lock_file(),
            30_000,
        )?)
    };
    let version = db
        .active_generation()?
        .map(|g| g.version)
        .unwrap_or_default();
    let (agents, machine) = owners(&paths, &db)?;
    let mut tx = Transaction::begin(&db, paths.backups(), &version, dry_run);
    let mut removed = Vec::new();
    let mut warnings = Vec::new();

    // What the agent layer owns, agent by agent. What a person changed stays where it is.
    let owning: std::collections::BTreeSet<String> = db
        .managed_resources(None)?
        .into_iter()
        .map(|r| r.agent_id)
        .collect();
    for id in &owning {
        let adapter: &dyn TeamAIAdapter = if id == wf_agents::adapter::MACHINE_ID {
            &machine
        } else if let Some(a) = agents.iter().find(|a| a.id() == id) {
            a
        } else {
            warnings.push(format!(
                "{id}: wf no longer knows this agent, so what it put there was left in place"
            ));
            continue;
        };
        for component in wf_agents::engine::retire_agent(adapter, &mut tx)? {
            removed.push(format!("remove {component} from {id}"));
        }
    }

    // A 1.x release's plugin and marketplace, which only their receipts know about.
    let native = db.native_receipts()?;
    for kind in [NativeObject::Plugin, NativeObject::Marketplace] {
        for receipt in native.iter().filter(|r| r.kind == kind) {
            match wf_agents::legacy::Manager::from_receipt(receipt)?
                .remove_owned(receipt, &mut tx)?
            {
                wf_agents::legacy::Retirement::Removed => {
                    removed.push(format!("remove {} {}", receipt.agent, receipt.identity))
                }
                wf_agents::legacy::Retirement::Absent => {}
                wf_agents::legacy::Retirement::Kept(why) => warnings.push(why),
            }
        }
    }

    // A 1.x release's own files, on a machine the agent layer has not adopted yet.
    for receipt in db.receipts()? {
        use wf_agents::resources::object::{erase, Placement, Shape};
        // The installed executables remain: `wf` for backup restoration after uninstall, and
        // ctx because deleting a daemon's binary without its handoff crash-loops the daemon.
        if receipt.component_id == "capso.wf.binary"
            || receipt.component_id == wf_sync::ctx::COMPONENT
        {
            continue;
        }
        let path = std::path::PathBuf::from(&receipt.path);
        let (shape, object) = match receipt.object_id.as_str() {
            // wf 1.x put the block in Claude's CLAUDE.md and in one of Codex's pair. Which
            // of the pair Codex read may have changed since, so both are cleaned.
            "capso.global" => (
                Shape::Block {
                    shadows: match path.parent() {
                        Some(dir) if path.file_name().is_some_and(is_codex_prompt) => {
                            vec![dir.join("AGENTS.md"), dir.join("AGENTS.override.md")]
                        }
                        _ => vec![],
                    },
                },
                "capso.global",
            ),
            LEGACY_CODEX_HOOK => (
                Shape::Hook(wf_agents::formats::HookFormat::Codex),
                "SessionStart/capso-wf-bootstrap",
            ),
            _ => continue,
        };
        let placement = Placement {
            path,
            object: Some(object.into()),
        };
        if erase(shape, &placement, &receipt.component_id, &mut tx)? {
            removed.push(format!("remove {object} from {}", receipt.path));
        }
    }
    tx.commit_with(|tx| {
        tx.swap_symlink(&paths.active_link(), None)?;
        tx.clear_installation()
    })?;

    let mut env = Envelope::new("uninstall")
        .result(serde_json::json!({ "removed": removed, "dry_run": dry_run }));
    for w in warnings {
        env = env.warn(Note::new("UNINSTALL", w.clone()).with_zh(w));
    }
    let r = removed.clone();
    let ctx_left = paths.bin_dir.join("ctx").is_file();
    Ok(emit(json, env, move || {
        let mut s = if dry_run {
            String::from("演练完成，什么都没有改动。将要处理：\n")
        } else {
            String::from("已卸载。处理了：\n")
        };
        for line in &r {
            s.push_str(&format!("  {line}\n"));
        }
        s.push_str("\n你自己的技能、MCP 配置和历史记录都没有动过。\n");
        if !dry_run {
            s.push_str("`wf` 本身还在 ~/.local/bin/wf，不需要的话可以直接删掉。\n");
            if ctx_left {
                s.push_str(
                    "ctx 也还在 ~/.local/bin/ctx，它的后台索引照常运行，数据在 ~/.ctx。不需要的话，先运行 `ctx daemon disable --prepare-uninstall --format=json`，成功之后再删掉它。\n",
                );
            }
        }
        s
    }))
}

/// The receipt object a 1.x release wrote for its Codex session-start dispatcher.
const LEGACY_CODEX_HOOK: &str = "hooks.SessionStart[capso-wf-bootstrap]";

/// One of the two instructions files Codex reads.
fn is_codex_prompt(name: &std::ffi::OsStr) -> bool {
    name == "AGENTS.md" || name == "AGENTS.override.md"
}

/// Every agent wf knows on this machine, and the machine itself: from the active
/// generation's configuration, or the registry built into this binary.
fn owners(
    paths: &wf_core::paths::Paths,
    db: &Db,
) -> Result<(Vec<ConfigAdapter>, wf_agents::adapter::MachineAdapter)> {
    match super::active_context(paths, db)? {
        Some(ctx) => Ok((
            ctx.agents.agents().iter().map(|s| ctx.adapter(s)).collect(),
            ctx.machine(),
        )),
        None => {
            let policies = wf_agents::policy::Policies::default();
            Ok((
                wf_agents::registry::AgentRegistry::builtin()
                    .agents()
                    .iter()
                    .map(|s| {
                        ConfigAdapter::here(
                            s.clone(),
                            &paths.home,
                            paths.binary(),
                            policies.clone(),
                        )
                    })
                    .collect(),
                wf_agents::adapter::MachineAdapter::new(
                    paths.state_dir.join("docs"),
                    paths.binary(),
                    policies,
                ),
            ))
        }
    }
}

/// One line of `wf agents`.
#[derive(Debug, Clone, Serialize)]
pub struct AgentListRow {
    pub id: String,
    pub display_name: String,
    pub installed: bool,
    /// Registered and enabled, registered and disabled, or never registered.
    pub managed: Option<bool>,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub version: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub config_root: String,
}

/// Every agent wf knows, as this machine has it. `probe` asks each installed agent its
/// version, which runs its binary.
pub fn agent_rows(probe: bool) -> Result<Vec<AgentListRow>> {
    let paths = wf_core::paths::Paths::resolve()?;
    let db = Db::open_read_only(&paths.db())?;
    let registrations = db.agent_registrations()?;
    let (agents, _) = owners(&paths, &db)?;
    let mut rows = Vec::new();
    for adapter in &agents {
        let install = adapter.detect()?;
        let version = match &install {
            Some(install) if probe => wf_agents::adapter::probe_version(adapter.spec(), install),
            _ => String::new(),
        };
        rows.push(AgentListRow {
            id: adapter.id().to_string(),
            display_name: adapter.display_name().to_string(),
            installed: install.is_some(),
            managed: registrations
                .iter()
                .find(|r| r.agent_id == adapter.id())
                .map(|r| r.enabled)
                .or_else(|| {
                    wf_agents::adapter::FIRST_PARTY
                        .contains(&adapter.id())
                        .then_some(true)
                }),
            version,
            config_root: install
                .map(|i| i.config_root.to_string_lossy().into_owned())
                .unwrap_or_default(),
        });
    }
    Ok(rows)
}

/// The engine, the lock and the active generation's context, for a change to which agents
/// wf manages. Offline: registering an agent deploys what this machine already has.
fn managing(dry_run: bool) -> Result<(Engine, wf_agents::engine::Context, String)> {
    let mut opts = options(&RemoteArgs::default())?;
    opts.dry_run = dry_run;
    opts.offline = true;
    let engine = Engine::open(opts)?;
    let Some(g) = engine.db.active_generation()? else {
        return Err(
            wf_core::Error::failure("NOT-INSTALLED", "nothing is installed")
                .with_zh("这台机器还没有安装。先运行一次 `wf install`。".to_string()),
        );
    };
    let ctx = engine.context(&engine.paths.generation(&g.version).join("bundle"))?;
    Ok((engine, ctx, g.version))
}

/// The one agent a registration change names. `all` and lists are refused rather than cut to
/// their first entry: registering is a decision about one agent at a time.
fn one_agent(ctx: &wf_agents::engine::Context, name: &str) -> Result<wf_agents::AgentSpec> {
    match ctx.agents.select(name)?.as_slice() {
        [one] => Ok((*one).clone()),
        _ => Err(
            wf_core::Error::usage("AGENT-ONE", format!("{name}: name exactly one agent")).with_zh(
                format!(
            "`{name}` 不是单个 agent。一次只登记或取消一个，比如 `wf agents register cursor`。"
        ),
            ),
        ),
    }
}

/// Start managing an agent, and deploy the team's resources into it.
pub fn register(json: bool, name: &str, dry_run: bool) -> Result<ExitCode> {
    let (mut engine, ctx, version) = managing(dry_run)?;
    let _guard = engine.lifecycle_lock(false)?;
    let spec = one_agent(&ctx, name)?;
    if ctx.adapter(&spec).detect()?.is_none() {
        return Err(wf_core::Error::failure(
            "AGENT-ABSENT",
            format!("{} is not on this machine", spec.id),
        )
        .with_zh(format!(
            "这台机器上没有找到 {}。先装好它，再运行 `wf agents register {}`。",
            spec.display_name, spec.id
        )));
    }
    if !dry_run {
        engine.db.set_agent_enabled(&spec.id, true)?;
    }
    engine.opts.agents = Some(spec.id.clone());
    let outcome = engine.apply(&version, &engine.paths.generation(&version))?;
    let env = outcome_envelope("agents register", &outcome);
    let display = spec.display_name.clone();
    Ok(emit(json, env, move || {
        if outcome.dry_run {
            format!("演练完成，什么都没有改动。将要把团队资源装进 {display}。\n")
        } else if outcome.rolled_back {
            format!("没能把团队资源装进 {display}，已还原。运行 `wf doctor` 看原因。\n")
        } else {
            format!("{display} 现在由 wf 管理，团队的技能、规则、钩子和 MCP 都已装好。新开一个会话即可生效。\n")
        }
    }))
}

/// Stop managing an agent, and remove what wf put there.
pub fn unregister(json: bool, name: &str, dry_run: bool) -> Result<ExitCode> {
    let (engine, ctx, version) = managing(dry_run)?;
    let _guard = engine.lifecycle_lock(false)?;
    let spec = one_agent(&ctx, name)?;
    let adapter = ctx.adapter(&spec);
    let mut tx = Transaction::begin(&engine.db, engine.paths.backups(), &version, dry_run);
    let removed = wf_agents::engine::retire_agent(&adapter, &mut tx)?;
    tx.commit_with(|_| {
        // A decision about what not to install into this agent means nothing once wf stops
        // writing to it, and leaving the row would quietly decline the server again if the
        // agent were ever registered back.
        engine.db.forget_skipped_mcps_of(&spec.id)?;
        if engine.db.set_agent_enabled(&spec.id, false)? {
            engine.db.forget_components_of(&spec.id)?;
        } else {
            engine.db.register_agent(&wf_state::AgentRegistration {
                agent_id: spec.id.clone(),
                display_name: spec.display_name.clone(),
                config_root: adapter.location().root.to_string_lossy().into_owned(),
                binary_path: String::new(),
                version: String::new(),
                last_detected: None,
                enabled: false,
                metadata: serde_json::to_value(&spec)?,
            })?;
        }
        Ok(())
    })?;
    let env = Envelope::new("agents unregister").result(serde_json::json!({
        "agent": spec.id,
        "removed": removed,
        "dry_run": dry_run,
    }));
    let display = spec.display_name.clone();
    Ok(emit(json, env, move || {
        if dry_run {
            format!(
                "演练完成，什么都没有改动。将从 {display} 移除 {} 项。\n",
                removed.len()
            )
        } else {
            format!(
                "{display} 不再由 wf 管理，移除了 wf 放进去的 {} 项；你自己改过的都留着。想重新管理就运行 `wf agents register {}`。\n",
                removed.len(),
                spec.id
            )
        }
    }))
}

fn outcome_envelope(command: &str, outcome: &SyncOutcome) -> Envelope {
    let mut envelope = Envelope::new(command).result(outcome);
    if outcome.rolled_back {
        envelope = envelope.error(Note::new(
            "ROLLED-BACK",
            "operation did not complete; previous state was restored where possible",
        ));
    }
    for followup in &outcome.followups {
        envelope = envelope.error(Note::new("ROLLBACK-INCOMPLETE", followup.clone()));
    }
    envelope
}
