//! The team repository: where resources come from.
//!
//! This release implements one mode. **Self-repo** reads the verified generation of this
//! repository itself — `workflow/registry.yaml` for skills, MCP servers, hooks and the prompt
//! block, and the directories `workflow/teamai/team-config.yaml` names for rules, subagents,
//! environment and documents. The Git and HTTP modes of the teamai design are declared so the
//! configuration vocabulary is complete, and every operation on them refuses by name rather
//! than half-working: a pull that silently did nothing would read as "up to date".

use crate::resources::{handler, ResourceItem, ResourceKind};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use wf_core::{Error, Result};

pub const TEAM_CONFIG_FILE: &str = "workflow/teamai/team-config.yaml";
pub const SCHEMA_VERSION: u32 = 1;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TeamConfig {
    pub schema_version: u32,
    pub team: TeamInfo,
    #[serde(default)]
    pub self_repo: SelfRepoConfig,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub git_repo: Option<GitRepoConfig>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub http_backend: Option<HttpBackendConfig>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TeamInfo {
    pub name: String,
    pub repo_mode: RepoMode,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum RepoMode {
    SelfRepo,
    Git,
    Http,
}

impl RepoMode {
    pub fn as_str(self) -> &'static str {
        match self {
            RepoMode::SelfRepo => "self-repo",
            RepoMode::Git => "git",
            RepoMode::Http => "http",
        }
    }
}

#[derive(Debug, Clone, Default, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SelfRepoConfig {
    #[serde(default)]
    pub resources: ResourceDirs,
}

/// Directories, relative to the repository root, holding the resource kinds the component
/// registry does not list. An absent directory is an empty set, not an error.
#[derive(Debug, Clone, Default, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ResourceDirs {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub rules: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub docs: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub env: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub agents: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct GitRepoConfig {
    pub remote: String,
    pub local_path: String,
    pub branch: String,
    #[serde(default)]
    pub auto_pull: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub pull_interval: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct HttpBackendConfig {
    pub endpoint: String,
    /// The environment variable holding the token — a name, never the token.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub token_env: Option<String>,
    #[serde(default)]
    pub auto_sync: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub sync_interval: Option<String>,
}

impl Default for TeamConfig {
    /// What a generation that predates the file means: this repository, no extra resources.
    fn default() -> Self {
        Self {
            schema_version: SCHEMA_VERSION,
            team: TeamInfo {
                name: String::new(),
                repo_mode: RepoMode::SelfRepo,
            },
            self_repo: SelfRepoConfig::default(),
            git_repo: None,
            http_backend: None,
        }
    }
}

impl TeamConfig {
    pub fn parse(yaml: &str) -> Result<Self> {
        let config: TeamConfig = serde_yaml_ng::from_str(yaml).map_err(|e| {
            Error::usage("TEAM-CONFIG-PARSE", format!("team-config.yaml: {e}"))
                .with_zh("team-config.yaml 读不下来，可能是格式写错了。")
        })?;
        if config.schema_version != SCHEMA_VERSION {
            return Err(Error::unsupported(
                "TEAM-CONFIG-SCHEMA",
                format!(
                    "team-config.yaml declares schema_version {} but this build understands {SCHEMA_VERSION}",
                    config.schema_version
                ),
            ));
        }
        Ok(config)
    }

    pub fn load(root: &Path) -> Result<Self> {
        match std::fs::read_to_string(root.join(TEAM_CONFIG_FILE)) {
            Ok(text) => Self::parse(&text),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(Self::default()),
            Err(e) => Err(e.into()),
        }
    }

    pub fn validate(&self) -> Vec<crate::registry::Violation> {
        let mut out = Vec::new();
        let r = &self.self_repo.resources;
        for (kind, dir) in [
            ("rules", &r.rules),
            ("docs", &r.docs),
            ("env", &r.env),
            ("agents", &r.agents),
        ] {
            if let Some(dir) = dir {
                let inside = !dir.is_empty()
                    && !dir.starts_with('/')
                    && !dir.contains('\\')
                    && dir
                        .split('/')
                        .all(|s| !s.is_empty() && s != "." && s != "..");
                if !inside {
                    out.push(crate::registry::Violation {
                        code: "TEAM001",
                        subject: format!("self_repo.resources.{kind}"),
                        message: format!(
                            "{dir:?} must be a relative directory inside the repository"
                        ),
                    });
                }
            }
        }
        if let Some(name) = self
            .http_backend
            .as_ref()
            .and_then(|h| h.token_env.as_ref())
        {
            if !crate::formats::env_name(name) || wf_core::redact::looks_like_secret(name) {
                out.push(crate::registry::Violation {
                    code: "TEAM002",
                    subject: "http_backend.token_env".into(),
                    message:
                        "must name the environment variable holding the token, never the token"
                            .into(),
                });
            }
        }
        out
    }
}

fn unsupported(mode: RepoMode, what: &str) -> Error {
    Error::unsupported(
        "TEAM-REPO-MODE",
        format!(
            "team repository mode {} cannot {what} in this release; only self-repo is implemented",
            mode.as_str()
        ),
    )
    .with_zh(format!(
        "团队仓库的 {} 模式在这个版本里还没有实现，目前只支持 self-repo。",
        mode.as_str()
    ))
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TeamRepoMode {
    /// This repository's own verified generation (implemented).
    SelfRepo { workflow_root: PathBuf },
    /// A cloned team repository (declared; refused).
    GitRepo {
        remote_url: String,
        local_path: PathBuf,
        branch: String,
    },
    /// A team backend over HTTP (declared; refused).
    HttpBackend {
        endpoint: String,
        token: Option<String>,
    },
}

#[derive(Debug, Clone, PartialEq)]
pub enum PullResult {
    NoChange {
        rev: String,
    },
    Changed {
        changes: Vec<ResourceItem>,
        new_rev: String,
    },
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PushResult {
    Success,
}

#[derive(Debug, Clone)]
pub struct TeamRepo {
    mode: TeamRepoMode,
    config: TeamConfig,
}

impl TeamRepo {
    /// Self-repo mode over `workflow_root`, whatever its configuration says about mode.
    pub fn new_self_repo(workflow_root: PathBuf) -> Result<Self> {
        let config = TeamConfig::load(&workflow_root)?;
        Ok(Self {
            mode: TeamRepoMode::SelfRepo { workflow_root },
            config,
        })
    }

    /// The mode the root's configuration declares.
    pub fn open(root: &Path) -> Result<Self> {
        let config = TeamConfig::load(root)?;
        let mode = match config.team.repo_mode {
            RepoMode::SelfRepo => TeamRepoMode::SelfRepo {
                workflow_root: root.to_path_buf(),
            },
            RepoMode::Git => {
                let git = config.git_repo.clone().ok_or_else(|| {
                    Error::usage(
                        "TEAM-CONFIG",
                        "repo_mode is git but git_repo is not configured",
                    )
                })?;
                TeamRepoMode::GitRepo {
                    remote_url: git.remote,
                    local_path: PathBuf::from(git.local_path),
                    branch: git.branch,
                }
            }
            RepoMode::Http => {
                let http = config.http_backend.clone().ok_or_else(|| {
                    Error::usage(
                        "TEAM-CONFIG",
                        "repo_mode is http but http_backend is not configured",
                    )
                })?;
                TeamRepoMode::HttpBackend {
                    endpoint: http.endpoint,
                    token: None,
                }
            }
        };
        Ok(Self { mode, config })
    }

    fn mode_kind(&self) -> RepoMode {
        match self.mode {
            TeamRepoMode::SelfRepo { .. } => RepoMode::SelfRepo,
            TeamRepoMode::GitRepo { .. } => RepoMode::Git,
            TeamRepoMode::HttpBackend { .. } => RepoMode::Http,
        }
    }

    pub fn mode(&self) -> &TeamRepoMode {
        &self.mode
    }

    pub fn config(&self) -> &TeamConfig {
        &self.config
    }

    /// Re-read the configuration from the repository.
    pub fn load_config(&self) -> Result<TeamConfig> {
        TeamConfig::load(self.root()?)
    }

    /// The repository root; only self-repo mode has one in this release.
    pub fn root(&self) -> Result<&Path> {
        match &self.mode {
            TeamRepoMode::SelfRepo { workflow_root } => Ok(workflow_root),
            _ => Err(unsupported(self.mode_kind(), "be read")),
        }
    }

    pub fn registry(&self) -> Result<wf_registry::Registry> {
        wf_registry::Registry::load(self.root()?)
    }

    /// The directory holding a directory-sourced kind, when the configuration names one.
    pub fn resource_dir(&self, kind: ResourceKind) -> Result<Option<PathBuf>> {
        let dirs = &self.config.self_repo.resources;
        let dir = match kind {
            ResourceKind::Rule => &dirs.rules,
            ResourceKind::Doc => &dirs.docs,
            ResourceKind::Env => &dirs.env,
            ResourceKind::Agent => &dirs.agents,
            _ => return Ok(None),
        };
        dir.as_ref()
            .map(|d| self.root().map(|r| r.join(d)))
            .transpose()
    }

    pub fn scan_resources(&self, kind: ResourceKind) -> Result<Vec<ResourceItem>> {
        self.root()?;
        handler(kind).scan_registry(self)
    }

    /// Every resource, and whether any changed since `last_rev`.
    pub fn pull(&self, last_rev: Option<&str>) -> Result<PullResult> {
        self.root()?;
        let mut changes = Vec::new();
        for kind in ResourceKind::ALL {
            changes.extend(self.scan_resources(kind)?);
        }
        // The revision is the content, not a commit: a generation carries no Git history.
        let mut lines: Vec<String> = changes
            .iter()
            .map(|i| {
                format!(
                    "{}\t{}\t{}\n",
                    i.kind.as_str(),
                    i.id,
                    i.metadata.content_hash
                )
            })
            .collect();
        lines.sort();
        let rev = wf_core::hash::sha256_bytes(lines.concat().as_bytes());
        if last_rev == Some(rev.as_str()) {
            return Ok(PullResult::NoChange { rev });
        }
        Ok(PullResult::Changed {
            changes,
            new_rev: rev,
        })
    }

    /// Publishing local resources back to the team is a later phase of the design.
    pub fn push(&self, items: &[ResourceItem]) -> Result<PushResult> {
        let _ = items;
        Err(Error::unsupported(
            "TEAM-REPO-PUSH",
            format!(
                "pushing resources to a {} team repository is not part of this release",
                self.mode_kind().as_str()
            ),
        )
        .with_zh("把本地资源推回团队仓库还不在这个版本里。"))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const CONFIG: &str = r#"
schema_version: 1
team:
  name: TXE
  repo_mode: self-repo
self_repo:
  resources:
    rules: workflow/rules
    docs: workflow/docs
    env: workflow/env
    agents: workflow/agents
git_repo:
  remote: git@github.com:txehq/team-resources.git
  local_path: ~/.wf/team-repo
  branch: main
  auto_pull: true
  pull_interval: 900s
http_backend:
  endpoint: https://team-api.txehq.com
  token_env: WF_TEAM_TOKEN
  auto_sync: true
  sync_interval: 300s
"#;

    fn repo_root() -> PathBuf {
        Path::new(env!("CARGO_MANIFEST_DIR")).join("../..")
    }

    #[test]
    fn the_shipped_configuration_parses_validates_and_is_self_repo() {
        let config = TeamConfig::load(&repo_root()).unwrap();
        assert_eq!(config.validate(), vec![]);
        assert_eq!(config.team.repo_mode, RepoMode::SelfRepo);
        let repo = TeamRepo::open(&repo_root()).unwrap();
        assert!(matches!(repo.mode(), TeamRepoMode::SelfRepo { .. }));
        // The shipped registry resolves through it.
        assert!(repo
            .registry()
            .unwrap()
            .component("capso.skill.lfg")
            .is_some());
    }

    #[test]
    fn the_full_vocabulary_parses_including_the_reserved_modes() {
        let config = TeamConfig::parse(CONFIG).unwrap();
        assert_eq!(config.validate(), vec![]);
        assert_eq!(config.git_repo.unwrap().branch, "main");
        assert_eq!(
            config.http_backend.unwrap().token_env.as_deref(),
            Some("WF_TEAM_TOKEN")
        );
        assert!(TeamConfig::parse(
            &CONFIG.replace("auto_pull: true", "auto_pull: true\n  secret: x")
        )
        .is_err());
        assert_eq!(
            TeamConfig::parse(&CONFIG.replace("schema_version: 1", "schema_version: 9"))
                .unwrap_err()
                .code,
            wf_core::ExitCode::Unsupported
        );
    }

    #[test]
    fn resource_directories_stay_inside_the_repository() {
        for bad in ["/etc", "../outside", "workflow/../../x", ""] {
            let config = TeamConfig::parse(
                &CONFIG.replace("rules: workflow/rules", &format!("rules: \"{bad}\"")),
            )
            .unwrap();
            assert!(
                config.validate().iter().any(|v| v.code == "TEAM001"),
                "{bad:?}"
            );
        }
    }

    #[test]
    fn a_token_value_in_the_configuration_is_refused() {
        let config = TeamConfig::parse(&CONFIG.replace(
            "token_env: WF_TEAM_TOKEN",
            "token_env: ghp_ABCDEFGHIJKLMNOPQRSTUVWX",
        ))
        .unwrap();
        assert!(config.validate().iter().any(|v| v.code == "TEAM002"));
    }

    #[test]
    fn a_generation_without_the_file_is_self_repo_with_no_extra_resources() {
        let dir = tempfile::tempdir().unwrap();
        assert_eq!(TeamConfig::load(dir.path()).unwrap(), TeamConfig::default());
        let repo = TeamRepo::open(dir.path()).unwrap();
        assert_eq!(repo.resource_dir(ResourceKind::Rule).unwrap(), None);
    }

    #[test]
    fn resource_directories_resolve_under_the_root_for_their_kinds_only() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::create_dir_all(dir.path().join("workflow/teamai")).unwrap();
        std::fs::write(dir.path().join(TEAM_CONFIG_FILE), CONFIG).unwrap();
        let repo = TeamRepo::open(dir.path()).unwrap();
        assert_eq!(
            repo.resource_dir(ResourceKind::Rule).unwrap(),
            Some(dir.path().join("workflow/rules"))
        );
        assert_eq!(
            repo.resource_dir(ResourceKind::Doc).unwrap(),
            Some(dir.path().join("workflow/docs"))
        );
        assert_eq!(
            repo.resource_dir(ResourceKind::Env).unwrap(),
            Some(dir.path().join("workflow/env"))
        );
        assert_eq!(
            repo.resource_dir(ResourceKind::Agent).unwrap(),
            Some(dir.path().join("workflow/agents"))
        );
        assert_eq!(
            repo.resource_dir(ResourceKind::Skill).unwrap(),
            None,
            "skills come from the registry"
        );
        assert_eq!(repo.load_config().unwrap(), repo.config().clone());
    }

    #[test]
    fn the_reserved_modes_refuse_every_operation_by_name() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::create_dir_all(dir.path().join("workflow/teamai")).unwrap();
        for (mode, word) in [("git", "git"), ("http", "http")] {
            std::fs::write(
                dir.path().join(TEAM_CONFIG_FILE),
                CONFIG.replace("repo_mode: self-repo", &format!("repo_mode: {mode}")),
            )
            .unwrap();
            let repo = TeamRepo::open(dir.path()).unwrap();
            for err in [
                repo.root().unwrap_err(),
                repo.pull(None).unwrap_err(),
                repo.scan_resources(ResourceKind::Skill).unwrap_err(),
            ] {
                assert_eq!(err.code, wf_core::ExitCode::Unsupported);
                assert!(err.message.contains(word), "{}", err.message);
            }
        }
        let git = TeamRepo::open(dir.path()).unwrap();
        assert!(
            matches!(git.mode(), TeamRepoMode::HttpBackend { token: None, .. }),
            "a token is read at use, never stored"
        );
    }

    #[test]
    fn push_is_a_later_phase_in_every_mode() {
        let repo = TeamRepo::new_self_repo(repo_root()).unwrap();
        let err = repo.push(&[]).unwrap_err();
        assert_eq!(err.code, wf_core::ExitCode::Unsupported);
    }
}
