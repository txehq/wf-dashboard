//! The sync engine: the state machine, and the session-start path that drives it.
//!
//! Everything in here is shaped by one number. A session start runs this code on every
//! terminal a person opens, and the budget for the no-change path is a tenth of a second.
//! That rules out the obvious implementations — walking the generation tree, hashing
//! components, asking an agent for its version, touching the network — and leaves a design
//! where the fast path reads three rows out of SQLite and returns.
//!
//! The second shape is failure. A machine that cannot reach GitHub, whose login expired, or
//! whose disk filled halfway through an update, still has to start a session. So every
//! failure here resolves to "keep the last known good generation and say so", and the only
//! thing that ever stops is an integrity check.

pub mod ctx;
pub mod engine;
pub mod session;
pub mod status;

pub use ctx::CtxReport;
pub use engine::{Engine, Options, SyncOutcome};
pub use session::session_start;
pub use status::{ComponentRow, Status};
