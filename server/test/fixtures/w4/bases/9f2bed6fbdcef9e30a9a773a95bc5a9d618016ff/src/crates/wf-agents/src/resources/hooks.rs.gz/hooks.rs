//! Hooks: the registry's hook dispatchers, written as native handlers in each agent's format.
//!
//! A dispatcher is an argv, never a shell string (REG011), and its argument list is stable
//! across releases because Codex binds trust to the definition (CLM-003). `executable: wf`
//! becomes the installed binary's absolute path; the agent's own name is appended as
//! `--agent`, which is how one dispatcher serves every agent.

use super::object::{Rendered, Shape};
use super::{
    registry_payload, ResourceHandler, ResourceItem, ResourceKind, ResourceMetadata,
    POLICY_REFUSED, POLICY_SKIP,
};
use crate::formats::{get_hook_format, json_doc, openclaw, HookEntry, HookEvent, HookFormat};
use crate::{adapter::TeamAIAdapter, registry::PathKind, team_repo::TeamRepo};
use wf_core::{Error, Result};

pub struct HooksHandler;

impl ResourceHandler for HooksHandler {
    fn kind(&self) -> ResourceKind {
        ResourceKind::Hook
    }

    fn scan_registry(&self, repo: &TeamRepo) -> Result<Vec<ResourceItem>> {
        let registry = repo.registry()?;
        let mut out = Vec::new();
        // Where each handler lands in a hook document: its event and its marker. Two
        // dispatchers with one identity would replace each other on every apply.
        let mut identities: Vec<(String, String)> = Vec::new();
        for c in registry.of_kind(wf_registry::Kind::HookDispatcher) {
            let event_text = c.event.clone().unwrap_or_default();
            let event = HookEvent::parse(&event_text).ok_or_else(|| {
                Error::usage(
                    "HOOK-EVENT",
                    format!("{}: event {event_text:?} is not one wf knows", c.id),
                )
            })?;
            let mut argv = vec![c.executable.clone().unwrap_or_default()];
            argv.extend(c.arguments.iter().cloned());
            let identity = HookEntry {
                event,
                matcher: None,
                argv,
                timeout_secs: None,
            }
            .identity();
            if let Some((other, _)) = identities.iter().find(|(_, id)| *id == identity) {
                return Err(Error::usage(
                    "HOOK-DUPLICATE",
                    format!(
                        "{} and {other} are both a {identity} dispatcher; an agent's hook document holds one",
                        c.id
                    ),
                ));
            }
            identities.push((c.id.clone(), identity));
            let mut payload = registry_payload(c);
            payload.insert("event".into(), event.as_str().into());
            payload.insert(
                "executable".into(),
                c.executable.clone().unwrap_or_default().into(),
            );
            payload.insert("arguments".into(), c.arguments.clone().into());
            let hashed = serde_json::Value::Object(payload.clone());
            out.push(ResourceItem {
                id: c.id.clone(),
                name: c.id.clone(),
                kind: ResourceKind::Hook,
                version: None,
                source: repo.root()?.join("workflow/registry.yaml"),
                metadata: ResourceMetadata {
                    content_hash: json_doc::canonical_hash(&hashed),
                    component_id: Some(c.id.clone()),
                    placement: None,
                    payload: payload.into(),
                },
            });
        }
        Ok(out)
    }

    fn render(&self, item: &ResourceItem, agent: &dyn TeamAIAdapter) -> Result<Option<Rendered>> {
        let (Some(format), Some(path)) = (agent.formats().hook, agent.path(PathKind::Hooks)) else {
            return Ok(None);
        };
        let payload = &item.metadata.payload;
        let Some(event) = payload["event"].as_str().and_then(HookEvent::parse) else {
            return Ok(None);
        };
        if !get_hook_format(format).supports(event) {
            return Ok(None);
        }
        let executable = payload["executable"].as_str().unwrap_or_default();
        let arguments: Vec<String> = serde_json::from_value(payload["arguments"].clone())?;
        let policy = &agent.policies().hooks;
        if executable != "wf" && policy.require_team_scripts {
            return Err(Error::usage(
                POLICY_REFUSED,
                format!(
                    "{}: hooks.require_team_scripts allows only handlers that run wf",
                    item.id
                ),
            ));
        }
        if executable != "wf" && !get_hook_format(format).marks_handlers() {
            return Err(Error::usage(
                POLICY_REFUSED,
                format!(
                    "{}: {} hook documents carry no field for wf's marker, so a handler that \
                     runs {executable} rather than wf could not be found again — it would be \
                     appended once per sync and never verify",
                    item.id,
                    agent.display_name()
                ),
            ));
        }
        let bootstrap = arguments.first().map(String::as_str) == Some("hook")
            && arguments.get(1).map(String::as_str) == Some("session-start");
        if !policy.auto_apply && !bootstrap {
            return Err(Error::usage(
                POLICY_SKIP,
                format!(
                    "{}: hooks.auto_apply is off; the handler is left as it is",
                    item.id
                ),
            ));
        }
        let mut argv = vec![if executable == "wf" {
            agent.wf_binary().to_string_lossy().into_owned()
        } else {
            executable.to_string()
        }];
        argv.extend(arguments);
        argv.extend(["--agent".to_string(), agent.hook_name().to_string()]);
        let path = if format == HookFormat::Openclaw {
            path.join(openclaw::HOOK_NAME)
        } else {
            path
        };
        Ok(Some(Rendered::Hook {
            path,
            format,
            entry: HookEntry {
                event,
                matcher: None,
                argv,
                timeout_secs: None,
            },
        }))
    }

    fn shape(&self, agent: &dyn TeamAIAdapter) -> Option<Shape> {
        agent.path(PathKind::Hooks)?;
        self.stored_shape(agent)
    }

    fn stored_shape(&self, agent: &dyn TeamAIAdapter) -> Option<Shape> {
        Some(Shape::Hook(agent.formats().hook?))
    }

    fn marker_owned(&self) -> bool {
        true
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::testing::{TeamFixture, REGISTRY};

    /// A hook document holds one `wf` dispatcher of each kind per event; two on one event
    /// would overwrite each other on every apply and never verify. The registry says so
    /// before a machine does: the kind does not read, so nothing of it changes anywhere.
    #[test]
    fn two_dispatchers_on_one_event_do_not_read() {
        let team = TeamFixture::new();
        team.write(
            "workflow/registry.yaml",
            &format!(
                "{}  - id: capso.hook.team.post-tool-use\n    kind: hook-dispatcher\n    required: true\n    event: PostToolUse\n    executable: wf\n    arguments: [hook, dispatch, --event, PostToolUse]\n    trust_contract: stable-definition\n    targets: [claude-code, codex]\n",
                REGISTRY.trim_start()
            ),
        );
        let err = HooksHandler.scan_registry(&team.repo()).unwrap_err();
        assert_eq!(err.kind, "HOOK-DUPLICATE", "{}", err.message);
        assert!(
            err.message.contains("capso.hook.usage.post-tool-use"),
            "{}",
            err.message
        );
    }

    /// Cursor, ZCode and OpenClaw hook entries carry no field for wf's marker, so a handler
    /// is wf's again only by its `wf hook …` argv. One running anything else could not be
    /// found in the document afterwards: every sync appended another copy while `verify`
    /// reported it had never landed.
    #[test]
    fn a_handler_a_format_could_not_recognise_again_is_refused_rather_than_written() {
        let team = TeamFixture::new();
        let m = crate::testing::Machine::new();
        let mut policies = crate::policy::Policies::default();
        policies.hooks.require_team_scripts = false;
        let item = ResourceItem {
            id: "capso.hook.team.notify".into(),
            name: "capso.hook.team.notify".into(),
            kind: ResourceKind::Hook,
            version: None,
            source: Default::default(),
            metadata: ResourceMetadata {
                content_hash: String::new(),
                component_id: Some("capso.hook.team.notify".into()),
                placement: None,
                payload: serde_json::json!({
                    "event": "Stop",
                    "executable": "/opt/txe/bin/notify",
                    "arguments": ["--now"],
                }),
            },
        };
        for (agent, refused) in [("cursor", true), ("claude-code", false)] {
            let adapter = m.adapter(&team, agent, policies.clone());
            let rendered = HooksHandler.render(&item, &adapter);
            assert_eq!(rendered.is_err(), refused, "{agent}: {rendered:?}");
            if refused {
                assert_eq!(rendered.unwrap_err().kind, POLICY_REFUSED);
            }
        }
    }
}
