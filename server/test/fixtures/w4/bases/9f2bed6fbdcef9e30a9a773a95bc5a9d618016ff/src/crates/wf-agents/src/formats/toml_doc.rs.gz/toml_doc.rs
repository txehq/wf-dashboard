//! Key-level surgery on a TOML document a person also edits — Codex's `config.toml`.
//!
//! Edits go through `toml_edit`, so comments, blank lines and the order of everything `wf`
//! does not own come out as they went in. teamai spliced text with a regular expression and
//! lost the comment above the next table on every replace; this cannot, because it never
//! treats the document as text.
//!
//! Values are exchanged as JSON so a hash of a TOML object and of the JSON object it was
//! rendered from agree.

use serde_json::Value;
use std::path::Path;
use toml_edit::{DocumentMut, Item, Table, TableLike};
use wf_core::{Error, Result};

pub fn parse(text: &str, path: &Path) -> Result<DocumentMut> {
    text.parse::<DocumentMut>().map_err(|e| {
        Error::conflict(
            "TOML-PARSE",
            format!("{} cannot be merged: {e}", path.display()),
        )
        .with_zh(format!(
            "{} 不是合法的 TOML，wf 没有改动它。请先修好这个文件再运行一次。",
            path.display()
        ))
    })
}

/// The value at a dotted table path, as JSON.
pub fn get(doc: &DocumentMut, keys: &[String]) -> Option<Value> {
    let item = keys
        .iter()
        .try_fold(doc.as_item(), |item, key| item.get(key.as_str()))?;
    item_to_json(item)
}

/// Set `keys` to `value`. The parent chain becomes (implicit) standard tables; an object value
/// under a standard table becomes a standard table of its own, and objects nested inside it
/// become inline tables. An existing parent that is not a table is a conflict.
pub fn set(doc: &mut DocumentMut, keys: &[String], value: &Value, path: &Path) -> Result<()> {
    if get(doc, keys).as_ref() == Some(value) {
        return Ok(()); // Already so: keep its formatting and its place.
    }
    let conflict = || {
        Error::conflict(
            "TOML-SHAPE",
            format!(
                "{}: {} is inside something that is not a table",
                path.display(),
                keys.join(".")
            ),
        )
    };
    let Some((last, parents)) = keys.split_last() else {
        return Err(conflict());
    };
    let mut table: &mut dyn TableLike = doc.as_table_mut();
    let mut standard = true;
    for key in parents {
        if !table.contains_key(key) {
            let mut fresh = Table::new();
            fresh.set_implicit(true);
            table.insert(key, Item::Table(fresh));
        }
        let item = table.get_mut(key).expect("present or just inserted");
        standard = item.is_table();
        table = item.as_table_like_mut().ok_or_else(conflict)?;
    }
    let item = if standard && value.is_object() {
        let mut fresh = json_to_table(value)?;
        // Keep a replaced table where it was; put a new one after everything a person wrote.
        let position = table
            .get(last)
            .and_then(Item::as_table)
            .and_then(Table::position)
            .unwrap_or(isize::MAX);
        fresh.set_position(position);
        Item::Table(fresh)
    } else {
        Item::Value(json_to_value(value).ok_or_else(conflict)?)
    };
    table.insert(last, item);
    Ok(())
}

pub fn remove(doc: &mut DocumentMut, keys: &[String]) -> bool {
    let Some((last, parents)) = keys.split_last() else {
        return false;
    };
    let mut table: &mut dyn TableLike = doc.as_table_mut();
    for key in parents {
        match table.get_mut(key).and_then(Item::as_table_like_mut) {
            Some(next) => table = next,
            None => return false,
        }
    }
    table.remove(last).is_some()
}

/// `original` when the document is unchanged, the new text otherwise.
pub fn render_if_changed(original: &str, doc: &DocumentMut) -> String {
    let text = doc.to_string();
    let same = text == original
        || original
            .parse::<DocumentMut>()
            .is_ok_and(|before| item_to_json(before.as_item()) == item_to_json(doc.as_item()));
    if same {
        original.to_string()
    } else {
        text
    }
}

fn item_to_json(item: &Item) -> Option<Value> {
    match item {
        Item::None => None,
        Item::Value(v) => Some(value_to_json(v)),
        Item::Table(t) => Some(Value::Object(
            t.iter()
                .filter_map(|(k, v)| item_to_json(v).map(|v| (k.to_string(), v)))
                .collect(),
        )),
        Item::ArrayOfTables(a) => Some(Value::Array(
            a.iter()
                .map(|t| item_to_json(&Item::Table(t.clone())).unwrap_or(Value::Null))
                .collect(),
        )),
    }
}

fn value_to_json(value: &toml_edit::Value) -> Value {
    match value {
        toml_edit::Value::String(s) => Value::String(s.value().clone()),
        toml_edit::Value::Integer(i) => Value::from(*i.value()),
        toml_edit::Value::Float(f) => serde_json::Number::from_f64(*f.value())
            .map(Value::Number)
            .unwrap_or(Value::Null),
        toml_edit::Value::Boolean(b) => Value::Bool(*b.value()),
        toml_edit::Value::Datetime(d) => Value::String(d.value().to_string()),
        toml_edit::Value::Array(a) => Value::Array(a.iter().map(value_to_json).collect()),
        toml_edit::Value::InlineTable(t) => Value::Object(
            t.iter()
                .map(|(k, v)| (k.to_string(), value_to_json(v)))
                .collect(),
        ),
    }
}

/// TOML has no null: a null inside an object is an absent key, and a null anywhere else has
/// no spelling at all.
fn json_to_value(value: &Value) -> Option<toml_edit::Value> {
    Some(match value {
        Value::Null => return None,
        Value::Bool(b) => (*b).into(),
        Value::Number(n) => match n.as_i64() {
            Some(i) => i.into(),
            None => n.as_f64()?.into(),
        },
        Value::String(s) => s.as_str().into(),
        Value::Array(items) => {
            let mut array = toml_edit::Array::new();
            for item in items {
                array.push(json_to_value(item)?);
            }
            toml_edit::Value::Array(array)
        }
        Value::Object(map) => {
            let mut inline = toml_edit::InlineTable::new();
            for (k, v) in map {
                if !v.is_null() {
                    inline.insert(k, json_to_value(v)?);
                }
            }
            toml_edit::Value::InlineTable(inline)
        }
    })
}

fn json_to_table(value: &Value) -> Result<Table> {
    let mut table = Table::new();
    for (k, v) in value.as_object().into_iter().flatten() {
        if v.is_null() {
            continue;
        }
        let v = json_to_value(v)
            .ok_or_else(|| Error::usage("TOML-VALUE", format!("{k} has no TOML spelling")))?;
        table.insert(k, Item::Value(v));
    }
    Ok(table)
}

#[cfg(test)]
mod tests {
    use super::*;
    use proptest::prelude::*;

    fn keys(k: &[&str]) -> Vec<String> {
        k.iter().map(|s| s.to_string()).collect()
    }

    fn p() -> &'static Path {
        Path::new("/x/config.toml")
    }

    const USER: &str = r#"# my codex settings
model = "gpt-5"   # the one I like

[mcp_servers.mine]
command = "uvx"   # keep this comment
args = ["my-server"]

# history tuning
[history]
persistence = "save-all"
"#;

    #[test]
    fn a_server_table_is_added_without_touching_a_byte_of_the_rest() {
        let mut doc = parse(USER, p()).unwrap();
        let server = serde_json::json!({
            "command": "npx",
            "args": ["-y", "mcp-remote", "https://mcp.linear.app/sse"],
            "env_vars": ["LINEAR_API_TOKEN"],
        });
        set(
            &mut doc,
            &keys(&["mcp_servers", "capso-linear"]),
            &server,
            p(),
        )
        .unwrap();
        let text = render_if_changed(USER, &doc);
        assert!(
            text.starts_with(USER.trim_end_matches('\n')),
            "user bytes moved:\n{text}"
        );
        assert!(text.contains("[mcp_servers.capso-linear]"), "{text}");
        assert!(text.contains("env_vars = [\"LINEAR_API_TOKEN\"]"), "{text}");
        let reparsed = parse(&text, p()).unwrap();
        assert_eq!(
            get(&reparsed, &keys(&["mcp_servers", "capso-linear"])),
            Some(server)
        );
        assert_eq!(
            get(&reparsed, &keys(&["mcp_servers", "mine", "command"])),
            Some(serde_json::json!("uvx"))
        );
    }

    #[test]
    fn removing_our_table_restores_the_original_document() {
        let mut doc = parse(USER, p()).unwrap();
        let k = keys(&["mcp_servers", "capso-linear"]);
        set(
            &mut doc,
            &k,
            &serde_json::json!({"command": "npx", "args": []}),
            p(),
        )
        .unwrap();
        let with = render_if_changed(USER, &doc);
        let mut doc = parse(&with, p()).unwrap();
        assert!(remove(&mut doc, &k));
        assert!(!remove(&mut doc, &k));
        assert_eq!(render_if_changed(&with, &doc), USER);
    }

    #[test]
    fn a_nested_value_under_an_existing_table_keeps_the_table_and_its_comment() {
        let text = "[shell_environment_policy]\n# inherit what I have\ninherit = \"all\"\n";
        let mut doc = parse(text, p()).unwrap();
        set(
            &mut doc,
            &keys(&["shell_environment_policy", "set", "TEAM"]),
            &serde_json::json!("txe"),
            p(),
        )
        .unwrap();
        let out = render_if_changed(text, &doc);
        assert!(
            out.contains("# inherit what I have\ninherit = \"all\""),
            "{out}"
        );
        let re = parse(&out, p()).unwrap();
        assert_eq!(
            get(&re, &keys(&["shell_environment_policy", "set", "TEAM"])),
            Some(serde_json::json!("txe"))
        );
    }

    #[test]
    fn an_unparseable_document_or_a_scalar_in_the_way_is_a_conflict() {
        assert_eq!(
            parse("model = ", p()).unwrap_err().code,
            wf_core::ExitCode::Conflict
        );
        let mut doc = parse("mcp_servers = 3\n", p()).unwrap();
        assert_eq!(
            set(
                &mut doc,
                &keys(&["mcp_servers", "x"]),
                &serde_json::json!({}),
                p()
            )
            .unwrap_err()
            .code,
            wf_core::ExitCode::Conflict
        );
    }

    #[test]
    fn setting_what_is_already_there_is_not_a_change() {
        let mut doc = parse(USER, p()).unwrap();
        set(
            &mut doc,
            &keys(&["mcp_servers", "mine"]),
            &serde_json::json!({"command": "uvx", "args": ["my-server"]}),
            p(),
        )
        .unwrap();
        assert_eq!(render_if_changed(USER, &doc), USER);
    }

    proptest! {
        /// Whatever tables a person has, adding and removing ours gives their document back.
        #[test]
        fn user_tables_survive_our_table_coming_and_going(
            tables in prop::collection::btree_map("[a-z]{1,6}", prop::collection::btree_map("[a-z]{1,4}", "[a-z0-9 ]{0,8}", 1..4), 0..4),
            comment in "[a-z ]{0,20}",
        ) {
            let mut text = format!("# {comment}\n");
            for (name, kv) in &tables {
                text.push_str(&format!("\n[{name}]\n"));
                for (k, v) in kv {
                    text.push_str(&format!("{k} = \"{v}\"\n"));
                }
            }
            let k = keys(&["mcp_servers", "capso-wf"]);
            let mut doc = parse(&text, p()).unwrap();
            prop_assume!(get(&doc, &keys(&["mcp_servers"])).is_none());
            set(&mut doc, &k, &serde_json::json!({"command": "wf", "args": ["x"]}), p()).unwrap();
            let with = render_if_changed(&text, &doc);
            let mut doc = parse(&with, p()).unwrap();
            prop_assert!(remove(&mut doc, &k));
            let _ = keys(&["mcp_servers"]);
            doc.remove("mcp_servers");
            prop_assert_eq!(render_if_changed(&with, &doc), text);
        }
    }
}
