//! How an MCP component's credential stands on this machine.
//!
//! One rule, three callers: `wf doctor`, `wf install`'s closing report and the session-start
//! hook all ask this and get the same answer. Every answer is local — an environment reference
//! this process can read, or nothing at all — which is what makes it affordable on the
//! session-start path. What is *not* local is whether a browser login was ever completed, so
//! one of the answers is that nobody looked.
//!
//! The question is asked about this component's own server and no other. A connection someone
//! else configured for the same service has its own login and its own owner (WFR-016); it is
//! not read here and does not reach the answer. Nor is any agent's configuration: the agent
//! layer reads those documents to place and verify `wf`'s own objects, never to answer this.

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CredentialStatus {
    /// Every reference the block declares has a value. The only outcome this machine
    /// observed for itself.
    Satisfied,
    /// Installed, and whether it can authenticate was not observed.
    ///
    /// The server this workflow installs is an `mcp-remote` bridge: it logs in through a
    /// browser and keeps the token in its own store, keyed by service URL under
    /// `~/.mcp-auth`. That store is per *machine*, not per agent, so one login serves every
    /// agent — which is also why several rows for one component can describe a single login.
    ///
    /// Distinct from `Satisfied` on purpose. A block with nothing to check is not a block that
    /// checked out: collapsing the two reports a capability as in place for a component nobody
    /// looked at, and not knowing has to be its own answer (txe-workflow#40).
    LoginUnverified,
    /// These references are not set.
    Missing(Vec<String>),
}

/// Ask the question above for one credential block.
///
/// Reads the environment and nothing else. It never opens a credential store and never opens
/// an agent's configuration: whether a login happened belongs to whoever owns that server, and
/// guessing at it from the outside is how a capability gets claimed that nobody has.
///
/// Order matters. The reference check answers only for a block that declares a reference; an
/// `agent-oauth` block declares none, and has to reach the mode below rather than fall out of
/// an emptiness test as satisfied.
pub fn credential_status(credentials: &wf_registry::Credentials) -> CredentialStatus {
    let missing: Vec<String> = credentials
        .references
        .iter()
        .filter(|r| std::env::var_os(r).is_none_or(|v| v.is_empty()))
        .cloned()
        .collect();
    if !missing.is_empty() {
        return CredentialStatus::Missing(missing);
    }
    // Nothing missing, and nothing to read either: for `agent-oauth` that is the point — the
    // login is a browser page and a token store this process does not open. A reference that
    // has a value is the one route this machine can confirm by itself.
    if credentials.references.is_empty()
        && credentials.mode == wf_registry::CREDENTIAL_MODE_AGENT_OAUTH
    {
        CredentialStatus::LoginUnverified
    } else {
        CredentialStatus::Satisfied
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn credentials(mode: &str, references: &[&str], login_host: &str) -> wf_registry::Credentials {
        wf_registry::Credentials {
            mode: mode.to_string(),
            references: references.iter().map(|s| s.to_string()).collect(),
            values_forbidden: true,
            login_host: login_host.to_string(),
        }
    }

    /// `PATH` stands in for "a reference that is set", so no test mutates the environment,
    /// which is process-wide and shared with every other test in this binary.
    #[test]
    fn a_reference_that_is_set_satisfies_and_one_that_is_not_is_missing_by_name() {
        assert_eq!(
            credential_status(&credentials("environment", &["PATH"], "")),
            CredentialStatus::Satisfied
        );
        assert_eq!(
            credential_status(&credentials(
                "environment",
                &["WF_TEST_ABSENT_REFERENCE"],
                ""
            )),
            CredentialStatus::Missing(vec!["WF_TEST_ABSENT_REFERENCE".into()])
        );
    }

    /// The `agent-oauth` shape: a login this component's own server holds, with no environment
    /// name at all. There is nothing here that can be checked, and that is a different answer
    /// from being satisfied (txe-workflow#40).
    #[test]
    fn an_oauth_only_credential_reports_that_nobody_looked() {
        assert_eq!(
            credential_status(&credentials(
                wf_registry::CREDENTIAL_MODE_AGENT_OAUTH,
                &[],
                "mcp.spot.rackspace.com"
            )),
            CredentialStatus::LoginUnverified
        );
    }

    /// Both shipped MCPs are `agent-oauth`, so neither can report itself in place. Pinning this
    /// to the shipped registry is what stops the next edit from quietly restoring `current`
    /// for a capability this machine has not observed.
    #[test]
    fn no_shipped_mcp_reports_itself_satisfied() {
        let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
        let registry = wf_registry::Registry::load(&root).unwrap();
        let with_credentials: Vec<_> = registry
            .of_kind(wf_registry::Kind::Mcp)
            .filter_map(|c| Some((c.id.as_str(), c.credentials.as_ref()?)))
            .collect();
        assert!(
            !with_credentials.is_empty(),
            "the registry ships no MCP with a credential block"
        );
        for (id, credentials) in with_credentials {
            assert_eq!(
                credential_status(credentials),
                CredentialStatus::LoginUnverified,
                "{id}"
            );
        }
    }
}
