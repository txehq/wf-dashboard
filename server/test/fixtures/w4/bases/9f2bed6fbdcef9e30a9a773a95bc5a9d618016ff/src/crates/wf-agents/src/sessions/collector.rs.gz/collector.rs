//! The session collector: one session's events folded into a summary.

use crate::policy::SessionsPolicy;
use serde::Serialize;
use wf_state::{SessionSummaryRow, UsageEventRow};

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct SessionSummary {
    pub session_id: String,
    /// When the session started (its first event).
    pub timestamp: String,
    /// When it ended, if its agent said so.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub end: Option<String>,
    pub agent: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub cwd: Option<String>,
    pub prompts: usize,
    pub tool_total: usize,
    pub distinct_tools: usize,
    /// Most used first, at most eight.
    pub top_tools: Vec<(String, usize)>,
    /// In order of first use.
    pub skills: Vec<String>,
    /// Prompts that corrected the agent.
    pub intervention_count: usize,
    pub valuable: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub first_prompt_redacted: Option<String>,
}

impl SessionSummary {
    pub fn to_row(&self) -> SessionSummaryRow {
        SessionSummaryRow {
            session_id: self.session_id.clone(),
            agent: self.agent.clone(),
            start_time: self.timestamp.clone(),
            end_time: self.end.clone(),
            tool_count: self.tool_total as i64,
            intervention_count: self.intervention_count as i64,
            valuable: self.valuable,
            first_prompt_redacted: self.first_prompt_redacted.clone(),
            metadata: serde_json::json!({
                "cwd": self.cwd,
                "prompts": self.prompts,
                "distinct_tools": self.distinct_tools,
                "top_tools": self.top_tools,
                "skills": self.skills,
            }),
        }
    }

    pub fn from_row(row: &SessionSummaryRow) -> Self {
        let m = &row.metadata;
        Self {
            session_id: row.session_id.clone(),
            timestamp: row.start_time.clone(),
            end: row.end_time.clone(),
            agent: row.agent.clone(),
            cwd: m["cwd"].as_str().map(String::from),
            prompts: m["prompts"].as_u64().unwrap_or(0) as usize,
            tool_total: row.tool_count.max(0) as usize,
            distinct_tools: m["distinct_tools"].as_u64().unwrap_or(0) as usize,
            top_tools: serde_json::from_value(m["top_tools"].clone()).unwrap_or_default(),
            skills: serde_json::from_value(m["skills"].clone()).unwrap_or_default(),
            intervention_count: row.intervention_count.max(0) as usize,
            valuable: row.valuable,
            first_prompt_redacted: row.first_prompt_redacted.clone(),
        }
    }
}

pub struct SessionCollector<'a> {
    policy: &'a SessionsPolicy,
}

impl<'a> SessionCollector<'a> {
    pub fn new(policy: &'a SessionsPolicy) -> Self {
        Self { policy }
    }

    /// The summary of `session_id` from `events`, or `None` when it has no events.
    pub fn collect_session(
        &self,
        session_id: &str,
        events: &[UsageEventRow],
    ) -> Option<SessionSummary> {
        let mut mine: Vec<&UsageEventRow> = events
            .iter()
            .filter(|e| e.session_id == session_id)
            .collect();
        if mine.is_empty() {
            return None;
        }
        mine.sort_by(|a, b| (a.timestamp.as_str(), a.id).cmp(&(b.timestamp.as_str(), b.id)));
        let of = |kind: &'static str| mine.iter().filter(move |e| e.event_type == kind);
        let mut tools: Vec<(String, usize)> = Vec::new();
        for name in of("tool").filter_map(|e| e.tool_name.clone()) {
            match tools.iter_mut().find(|(n, _)| *n == name) {
                Some(slot) => slot.1 += 1,
                None => tools.push((name, 1)),
            }
        }
        let tool_total = tools.iter().map(|(_, n)| n).sum();
        let distinct_tools = tools.len();
        tools.sort_by(|a, b| b.1.cmp(&a.1).then_with(|| a.0.cmp(&b.0)));
        tools.truncate(8);
        let mut skills: Vec<String> = Vec::new();
        for name in of("skill").filter_map(|e| e.skill_name.clone()) {
            if !skills.contains(&name) {
                skills.push(name);
            }
        }
        let intervention_count = of("prompt")
            .filter(|e| e.metadata["correction"].as_bool() == Some(true))
            .count();
        Some(SessionSummary {
            session_id: session_id.to_string(),
            timestamp: mine[0].timestamp.clone(),
            end: of("session_end").next_back().map(|e| e.timestamp.clone()),
            agent: mine[0].agent.clone(),
            cwd: of("session_start").find_map(|e| e.metadata["cwd"].as_str().map(String::from)),
            prompts: of("prompt").count(),
            tool_total,
            distinct_tools,
            top_tools: tools,
            skills,
            intervention_count,
            valuable: self.policy.is_valuable(distinct_tools, intervention_count),
            first_prompt_redacted: of("prompt")
                .find_map(|e| e.metadata["summary"].as_str().map(String::from)),
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn event(
        at: &str,
        kind: &str,
        name: Option<&str>,
        metadata: serde_json::Value,
    ) -> UsageEventRow {
        UsageEventRow {
            id: 0,
            timestamp: at.into(),
            session_id: "s1".into(),
            agent: "claude-code".into(),
            event_type: kind.into(),
            skill_name: (kind == "skill").then(|| name.unwrap().to_string()),
            tool_name: (kind == "tool").then(|| name.unwrap().to_string()),
            source: None,
            metadata,
        }
    }

    fn session() -> Vec<UsageEventRow> {
        vec![
            event(
                "2026-09-16T10:00:00.000Z",
                "session_start",
                None,
                json!({"cwd": "/work/app"}),
            ),
            event(
                "2026-09-16T10:00:01.000Z",
                "prompt",
                None,
                json!({"summary": "fix the flaky test", "correction": false}),
            ),
            event(
                "2026-09-16T10:00:02.000Z",
                "skill",
                Some("lfg"),
                json!(null),
            ),
            event(
                "2026-09-16T10:00:03.000Z",
                "tool",
                Some("Edit"),
                json!(null),
            ),
            event(
                "2026-09-16T10:00:04.000Z",
                "tool",
                Some("Bash"),
                json!(null),
            ),
            event(
                "2026-09-16T10:00:05.000Z",
                "tool",
                Some("Edit"),
                json!(null),
            ),
            event(
                "2026-09-16T10:00:06.000Z",
                "prompt",
                None,
                json!({"correction": true}),
            ),
            event(
                "2026-09-16T10:00:07.000Z",
                "tool",
                Some("Read"),
                json!(null),
            ),
            event("2026-09-16T10:00:08.000Z", "skill", Some("ic"), json!(null)),
            event(
                "2026-09-16T10:00:09.000Z",
                "skill",
                Some("lfg"),
                json!(null),
            ),
            event(
                "2026-09-16T10:10:00.000Z",
                "session_end",
                None,
                json!({"reason": "logout"}),
            ),
        ]
    }

    #[test]
    fn a_session_folds_into_counts_tools_skills_and_its_first_ask() {
        let policy = SessionsPolicy::default();
        let summary = SessionCollector::new(&policy)
            .collect_session("s1", &session())
            .unwrap();
        assert_eq!(
            summary,
            SessionSummary {
                session_id: "s1".into(),
                timestamp: "2026-09-16T10:00:00.000Z".into(),
                end: Some("2026-09-16T10:10:00.000Z".into()),
                agent: "claude-code".into(),
                cwd: Some("/work/app".into()),
                prompts: 2,
                tool_total: 4,
                distinct_tools: 3,
                top_tools: vec![("Edit".into(), 2), ("Bash".into(), 1), ("Read".into(), 1)],
                skills: vec!["lfg".into(), "ic".into()],
                intervention_count: 1,
                valuable: true,
                first_prompt_redacted: Some("fix the flaky test".into()),
            }
        );
    }

    #[test]
    fn value_needs_enough_distinct_tools_or_an_intervention() {
        let policy = SessionsPolicy::default();
        let quiet: Vec<UsageEventRow> = session()
            .into_iter()
            .filter(|e| {
                e.tool_name.as_deref() != Some("Read")
                    && !e.metadata["correction"].as_bool().unwrap_or(false)
            })
            .collect();
        let summary = SessionCollector::new(&policy)
            .collect_session("s1", &quiet)
            .unwrap();
        assert_eq!(summary.distinct_tools, 2);
        assert!(!summary.valuable);
        assert_eq!(summary.end.as_deref(), Some("2026-09-16T10:10:00.000Z"));
    }

    #[test]
    fn events_of_other_sessions_and_an_unknown_session_are_ignored() {
        let policy = SessionsPolicy::default();
        let mut events = session();
        let mut other = events[3].clone();
        other.session_id = "s2".into();
        events.push(other);
        let collector = SessionCollector::new(&policy);
        assert_eq!(
            collector.collect_session("s1", &events).unwrap().tool_total,
            4
        );
        assert_eq!(collector.collect_session("nope", &events), None);
        let open: Vec<UsageEventRow> = session()
            .into_iter()
            .filter(|e| e.event_type != "session_end")
            .collect();
        assert_eq!(collector.collect_session("s1", &open).unwrap().end, None);
    }

    #[test]
    fn a_summary_round_trips_through_its_database_row() {
        let policy = SessionsPolicy::default();
        let summary = SessionCollector::new(&policy)
            .collect_session("s1", &session())
            .unwrap();
        let row = summary.to_row();
        assert_eq!(row.tool_count, 4);
        assert_eq!(row.intervention_count, 1);
        assert!(row.valuable);
        assert_eq!(SessionSummary::from_row(&row), summary);
    }
}
