//! The session-start path, and the dispatcher every other hook event goes through.
//!
//! This runs on every terminal a person opens, so its shape is dictated by a budget rather
//! than by what would be tidy: **p95 under 100 ms when nothing has changed**. That means the
//! fast path reads a handful of SQLite rows and the generation's small agent configuration,
//! repairs the one thing that is cheap and local (the prompt block), and returns. It does not
//! hash a tree, does not run an agent's binary, and does not touch the network unless a
//! rate-limited timer says a check is due.
//!
//! When a check is due, the remote call runs under a hard 2-second wall clock and its result
//! is *scheduling*, not work: if something newer exists, a separate finite process is
//! started to fetch it and this one returns. Nothing a session start does waits on a
//! download, a full apply, or an index rebuild.

use crate::engine::{Engine, Options, META_LAST_APPLIED_BINARY};
use serde_json::Value;
use std::time::{Duration, Instant};
use wf_agents::engine::Context;
use wf_agents::formats::HookEvent;
use wf_agents::resources::ResourceKind;
use wf_agents::usage::HookContext;
use wf_core::Result;
use wf_hooks::{fit, HookOutput, Policy};

/// What the hook decided, kept for the journal and for tests that assert the fast path
/// really was fast and really did not call out.
#[derive(Debug, Clone, serde::Serialize)]
pub struct SessionReport {
    pub agent: String,
    pub took_ms: u64,
    pub path: &'static str,
    pub remote_checked: bool,
    pub updater_spawned: bool,
    pub context: String,
}

/// Run the session-start hook for one agent, named the way its hook names it (`claude`,
/// `codex`, `cursor`, …). `payload` is what the agent passed on stdin, or null.
pub fn session_start(
    agent: &str,
    opts: Options,
    payload: &Value,
) -> Result<(HookOutput, SessionReport)> {
    let started = Instant::now();
    let mut engine = Engine::open(opts)?;
    let bundle = engine.active_bundle_dir();
    let policy = bundle.as_deref().map(Policy::load).unwrap_or_default();

    let mut lines: Vec<String> = Vec::new();
    let mut remote_checked = false;
    let mut updater_spawned = false;
    let mut path = "fast";

    let active = engine.db.active_generation()?;
    let active_version = active
        .as_ref()
        .map(|g| g.version.clone())
        .unwrap_or_default();

    if active.is_none() {
        // Nothing installed yet. Say the one thing that helps and stop; a session start is
        // not the place to run a first install.
        lines.push(
            "这台机器还没有安装团队的工作流。在终端里运行一次 `wf install` 就可以了。".to_string(),
        );
        return finish(Decision {
            agent: agent.to_string(),
            started,
            path: "uninstalled",
            remote_checked,
            updater_spawned,
            lines,
            policy: &policy,
        });
    }

    // Which agent is asking, where its files are, what the team's policy says: the
    // generation's own small configuration, read once.
    let ctx = match bundle.as_deref().map(|d| engine.context(d)) {
        Some(Ok(ctx)) => Some(ctx),
        Some(Err(e)) => {
            lines.push(if e.zh.is_empty() { e.message } else { e.zh });
            None
        }
        None => None,
    };
    let agent_id = ctx
        .as_ref()
        .and_then(|c| c.agents.find(agent))
        .map_or_else(|| agent.to_string(), |s| s.id.clone());

    if let Some(ctx) = &ctx {
        let hook = HookContext {
            agent: &agent_id,
            event: HookEvent::SessionStart,
            now: wf_core::time_fmt::now_utc_millis(),
            fallback_session: &fallback_session,
            is_skill: &|_| false,
        };
        // Never at the cost of the session: a usage row that did not land is a gap in a
        // chart, and a session start that failed is a person who cannot work.
        let _ = wf_agents::usage::record_hook(
            &engine.db,
            &engine.paths.state_dir,
            &ctx.policies,
            &hook,
            payload,
        );
    }

    if engine.db.meta(META_LAST_APPLIED_BINARY)?.as_deref() != Some(wf_core::VERSION) {
        // This binary has not applied the active generation itself: the updater that
        // installed it was the previous binary, which knows nothing of what this one
        // manages. A full apply is not a session-start job, so it runs beside the session.
        if spawn_background(&engine, "reapply", 900, &with_remote(&engine, &["repair"])) {
            updater_spawned = true;
            path = "reapply";
        }
    } else if let Some(ctx) = &ctx {
        // The cheap local repair: the prompt block, through the same handler an apply uses.
        match repair_prompt_inline(&engine, ctx, agent) {
            Ok(true) => path = "repaired",
            Ok(false) => {}
            Err(e) => lines.push(if e.zh.is_empty() { e.message } else { e.zh }),
        }
    }

    // Is a remote check due? One row, one comparison. This is the gate that keeps twenty
    // simultaneous session starts from making twenty API calls.
    let now = wf_core::time_fmt::now_unix();
    let due = !engine.opts.offline && engine.db.remote_due(&engine.remote_key(), now)?;
    if due {
        path = "remote";
        remote_checked = true;
        let deadline = Duration::from_millis(policy.budgets.remote_wait_ms.min(2_000));
        // The same engine, with a shorter leash. Opening a second one would mean a second
        // SQLite connection and a second set of directory creations on the path whose whole
        // budget is a tenth of a second.
        let saved = engine.opts.remote_timeout;
        engine.opts.remote_timeout = deadline;
        let (desired, warnings) = engine.resolve_desired();
        engine.opts.remote_timeout = saved;
        for w in warnings {
            lines.push(w);
        }
        if let Ok(_guard) = engine.lifecycle_lock(true) {
            // A person may have changed the source while the remote check was waiting.
            // Publish only against the installation that requested this check.
            if engine.source_still_current()? {
                engine.record_remote_result(desired.as_ref())?;
                if let Some(rel) = desired {
                    let active = engine
                        .db
                        .active_generation()?
                        .map(|g| g.version)
                        .unwrap_or_default();
                    engine.db.set_meta("desired_version", &rel.version)?;
                    if rel.version != active {
                        lines.push(wf_core::zh::reload_required(&active, &rel.version));
                        updater_spawned |= spawn_updater(&engine, "updater", 0);
                    }
                }
            }
        }
    } else if let Some(desired) = engine.db.meta("desired_version")? {
        if !desired.is_empty() && desired != active_version {
            lines.push(wf_core::zh::reload_required(&active_version, &desired));
        }
    }

    // Staleness and credentials, from rows already written by the last full sync.
    let stale = engine.db.stale_age(&engine.remote_key())?;
    if let Some(secs) = stale {
        let days = secs / 86_400;
        if days >= policy.budgets.stale_warn_after_days {
            lines.push(wf_core::zh::stale_too_long(days));
        }
    }
    // `credential_missing` and nothing else. `unverified` is excluded on purpose: it says this
    // machine did not look at whether a browser login happened, which the person cannot act on
    // and may well have done already — printing it here would put an unanswerable line in every
    // terminal, which is the failure 1.6.1 removed. It belongs to `wf doctor`, which someone
    // runs on purpose (txe-workflow#40).
    for (id, row_agent, state, _) in engine.db.components()? {
        if row_agent == agent_id && state == wf_state::ComponentState::CredentialMissing {
            // The row was written by the last full sync. A person who set the reference
            // afterwards has the capability, and `wf doctor` says so — so ask the same question
            // again here rather than repeating a stale warning in every terminal.
            if credential_now_satisfied(ctx.as_ref(), &id) {
                continue;
            }
            lines.push(format!(
                "{id} 缺少所需的凭据，这一项暂时用不了；其它功能不受影响。"
            ));
        }
    }

    // ctx converges apart from the release that pins it (crate::ctx): an update applied by
    // the previous `wf`, a download that failed, a handoff still waiting on a person. Two
    // rows decide, and the updater that does the work starts at most hourly.
    if !engine.opts.offline && !updater_spawned && ctx_pending(&engine)? {
        updater_spawned = spawn_updater(&engine, "ctx", 3_600);
    }
    finish(Decision {
        agent: agent_id,
        started,
        path,
        remote_checked,
        updater_spawned,
        lines,
        policy: &policy,
    })
}

/// Every hook event but session start: record what the team's policy says to record. Never
/// an error a hook can see — the caller prints nothing either way.
pub fn dispatch(agent: &str, event: &str, payload: &Value) -> Result<()> {
    let Some(event) = HookEvent::parse(event) else {
        return Ok(());
    };
    let engine = Engine::open(Options::defaults())?;
    let Some(bundle) = engine.active_bundle_dir() else {
        return Ok(());
    };
    let ctx = engine.context(&bundle)?;
    let spec = ctx.agents.find(agent);
    let agent_id = spec.map_or(agent, |s| s.id.as_str());
    let skills = spec.and_then(|s| {
        use wf_agents::adapter::TeamAIAdapter;
        ctx.adapter(s).skills_path()
    });
    let is_skill = |name: &str| {
        skills
            .as_ref()
            .is_some_and(|dir| dir.join(name).join("SKILL.md").is_file())
    };
    let hook = HookContext {
        agent: agent_id,
        event,
        now: wf_core::time_fmt::now_utc_millis(),
        fallback_session: &fallback_session,
        is_skill: &is_skill,
    };
    wf_agents::usage::record_hook(
        &engine.db,
        &engine.paths.state_dir,
        &ctx.policies,
        &hook,
        payload,
    )?;
    Ok(())
}

/// The session a payload that names none belongs to: Claude's variable, then the agent
/// process that ran the hook.
fn fallback_session() -> String {
    std::env::var("CLAUDE_SESSION_ID")
        .ok()
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| format!("pid-{}", parent_pid()))
}

#[cfg(unix)]
fn parent_pid() -> u32 {
    std::os::unix::process::parent_id()
}

#[cfg(not(unix))]
fn parent_pid() -> u32 {
    std::process::id()
}

/// Is the credential behind this component satisfied *now*, whatever the stored row says?
///
/// Same rule as `wf doctor`: [`wf_agents::credentials::credential_status`], which reads the
/// environment and nothing else. Anything this cannot answer — no configuration, no such
/// component, no credential block — leaves the stored row standing, because suppressing a
/// warning on a missing answer is the wrong direction to fail in.
///
/// Note what "not `Missing`" covers: `LoginUnverified` is also not missing, so a stale row for
/// a component that declares no reference is dropped here. That is deliberate — there is no
/// variable for the person to set — but it is not evidence that a login was found, and
/// `/install-manager` says so where an operator might read the silence that way.
fn credential_now_satisfied(ctx: Option<&Context>, id: &str) -> bool {
    let Some(ctx) = ctx else {
        return false;
    };
    let Ok(registry) = ctx.repo.registry() else {
        return false;
    };
    let Some(component) = registry.components.iter().find(|c| c.id == id) else {
        return false;
    };
    let Some(credentials) = &component.credentials else {
        return false;
    };
    !matches!(
        wf_agents::credentials::credential_status(credentials),
        wf_agents::credentials::CredentialStatus::Missing(_)
    )
}

/// What the hook decided, before it is rendered. Grouped rather than passed as eight
/// arguments so that adding a field is one edit rather than three call sites.
struct Decision<'a> {
    agent: String,
    started: Instant,
    path: &'static str,
    remote_checked: bool,
    updater_spawned: bool,
    lines: Vec<String>,
    policy: &'a Policy,
}

fn finish(d: Decision<'_>) -> Result<(HookOutput, SessionReport)> {
    let context = fit(&d.lines, d.policy.context.max_bytes);
    let out = HookOutput::new(context.clone(), None);
    Ok((
        out,
        SessionReport {
            agent: d.agent,
            took_ms: d.started.elapsed().as_millis() as u64,
            path: d.path,
            remote_checked: d.remote_checked,
            updater_spawned: d.updater_spawned,
            context,
        },
    ))
}

/// Bring the organization block in this agent's instructions back, if it has drifted.
///
/// Deliberately not a full sync: the agent layer scans the prompt component and nothing
/// else, and writes at most one file. Everything that costs more — skills, hooks, MCP — is
/// an apply's job.
fn repair_prompt_inline(engine: &Engine, ctx: &Context, agent: &str) -> Result<bool> {
    let _guard = match engine.lifecycle_lock(true) {
        Ok(guard) => guard,
        Err(error) if error.code == wf_core::ExitCode::Conflict => return Ok(false),
        Err(error) => return Err(error),
    };
    // Resolve the active generation after taking the lock; a concurrent sync may have
    // switched it since the session read its configuration.
    let Some(generation) = engine.db.active_generation()? else {
        return Ok(false);
    };
    if engine.paths.generation(&generation.version).join("bundle") != ctx.bundle_dir {
        return Ok(false);
    }
    let Some(spec) = ctx.agents.find(agent) else {
        return Ok(false);
    };
    // Even here — the cheapest repair there is — the write goes through a transaction, so
    // the person's file is backed up and the change leaves a receipt.
    let mut tx = wf_state::Transaction::begin(
        &engine.db,
        engine.paths.backups(),
        &generation.version,
        false,
    );
    let repaired =
        wf_agents::engine::repair(&ctx.adapter(spec), ctx, &[ResourceKind::Prompt], &mut tx)?;
    tx.commit()?;
    Ok(!repaired.is_empty())
}

/// The remote a spawned command must use: the one this installation was made from.
fn with_remote(engine: &Engine, command: &[&str]) -> Vec<String> {
    let mut args: Vec<String> = command.iter().map(|s| s.to_string()).collect();
    args.extend([
        "--json".into(),
        "--source".into(),
        engine.opts.source.describe(),
        "--repo".into(),
        engine.opts.repo.clone(),
        "--branch".into(),
        engine.opts.branch.clone(),
        "--channel".into(),
        engine.opts.channel.as_str().into(),
    ]);
    args
}

/// Start one finite updater, or find that another session already did.
///
/// The lock is the deduplication: twenty terminals opening at once produce twenty attempts
/// and one process. The updater is not a daemon — it takes the lock, does the work, and
/// exits — and nothing here waits for it.
fn spawn_updater(engine: &Engine, name: &str, interval: i64) -> bool {
    spawn_background(
        engine,
        name,
        interval,
        &with_remote(engine, &["sync", "--from-hook"]),
    )
}

/// Does the active release pin a ctx this machine has not finished converging on, and can
/// an unattended run still finish the job? Absent `ctx_desired` means the release was applied
/// by a `wf` that predates ctx, so ask. A refusal that only a person can lift is a terminal
/// state for the `wf` that recorded it: scheduling an hourly networked sync against it would
/// repeat forever. A newer `wf` gets one attempt, because it may know how to lift it.
fn ctx_pending(engine: &Engine) -> Result<bool> {
    if let Some(error) = engine.db.meta(crate::ctx::ERROR)?.filter(|e| !e.is_empty()) {
        let recorded_here =
            engine.db.meta(crate::ctx::ERROR_BY)?.as_deref() == Some(wf_core::VERSION);
        if recorded_here
            && crate::ctx::NEEDS_A_PERSON
                .iter()
                .any(|kind| error.starts_with(kind))
        {
            return Ok(false);
        }
    }
    let current = engine.db.meta(crate::ctx::CURRENT)?.unwrap_or_default();
    Ok(engine
        .db
        .meta(crate::ctx::DESIRED)?
        .is_none_or(|desired| desired != current))
}

/// Serialize the check and publication of a child PID. A live child suppresses duplicate
/// starts; a crashed child can be retried after the scheduling interval.
fn spawn_background(engine: &Engine, name: &str, interval: i64, args: &[String]) -> bool {
    let marker = engine.paths.state_dir.join(format!("{name}.pid"));
    let Ok(_guard) = wf_core::lock::Guard::try_exclusive(
        &engine.paths.state_dir.join(format!("{name}.spawn.lock")),
    ) else {
        return false;
    };
    if let Ok(text) = std::fs::read_to_string(&marker) {
        if let Some((pid, at)) = text.trim().split_once(':') {
            if let (Ok(pid), Ok(at)) = (pid.parse::<u32>(), at.parse::<i64>()) {
                let age = wf_core::time_fmt::now_unix().saturating_sub(at);
                if age < interval || (age < 600 && wf_core::proc::process_alive(pid)) {
                    return false;
                }
            }
        }
    }
    let exe = std::env::current_exe().unwrap_or_else(|_| engine.paths.binary());
    let child = std::process::Command::new(exe)
        .args(args)
        .stdin(std::process::Stdio::null())
        .stdout(std::process::Stdio::null())
        .stderr(std::process::Stdio::null())
        .spawn();
    let Ok(mut child) = child else { return false };
    let record = format!("{}:{}", child.id(), wf_core::time_fmt::now_unix());
    if wf_core::atomic::write_file(&marker, record.as_bytes()).is_err() {
        let _ = child.kill();
        let _ = child.wait();
        return false;
    }
    true
}
