//! Skills: a directory per skill, copied whole into each agent's skills directory.
//!
//! The registry lists them (`kind: skill`); the bytes are `skills/<name>/` in the team
//! repository, or `plugins/magi/skills/<name>/` in a generation built before the plugin was
//! retired, which is where those generations carried them.

use super::object::{tree_hash, Rendered, Shape};
use super::{registry_payload, ResourceHandler, ResourceItem, ResourceKind, ResourceMetadata};
use crate::{adapter::TeamAIAdapter, registry::PathKind, team_repo::TeamRepo};
use std::path::{Path, PathBuf};
use wf_core::{Error, Result};

pub struct SkillsHandler;

/// Where a registry skill's bytes are in a generation of either layout.
pub fn skill_source(root: &Path, source: &str) -> PathBuf {
    let current = root.join(source);
    if current.is_dir() {
        return current;
    }
    let legacy = root.join("plugins/magi").join(source);
    if legacy.is_dir() {
        legacy
    } else {
        current
    }
}

impl ResourceHandler for SkillsHandler {
    fn kind(&self) -> ResourceKind {
        ResourceKind::Skill
    }

    fn scan_registry(&self, repo: &TeamRepo) -> Result<Vec<ResourceItem>> {
        let root = repo.root()?;
        let registry = repo.registry()?;
        let mut out = Vec::new();
        for c in registry.of_kind(wf_registry::Kind::Skill) {
            let (Some(source), Some(name)) =
                (c.source.as_deref(), wf_registry::Registry::skill_name(c))
            else {
                continue;
            };
            let dir = skill_source(root, source);
            if !dir.join("SKILL.md").is_file() {
                return Err(Error::usage(
                    "SKILL-MISSING",
                    format!("{}: {} has no SKILL.md", c.id, dir.display()),
                ));
            }
            out.push(ResourceItem {
                id: name.to_string(),
                name: name.to_string(),
                kind: ResourceKind::Skill,
                version: None,
                metadata: ResourceMetadata {
                    content_hash: tree_hash(&dir)?,
                    component_id: Some(c.id.clone()),
                    placement: None,
                    payload: registry_payload(c).into(),
                },
                source: dir,
            });
        }
        Ok(out)
    }

    fn render(&self, item: &ResourceItem, agent: &dyn TeamAIAdapter) -> Result<Option<Rendered>> {
        Ok(agent.path(PathKind::Skills).map(|dir| Rendered::Tree {
            path: dir.join(&item.id),
            source: item.source.clone(),
            hash: item.metadata.content_hash.clone(),
        }))
    }

    fn shape(&self, agent: &dyn TeamAIAdapter) -> Option<Shape> {
        agent.path(PathKind::Skills).map(|_| Shape::Tree)
    }

    fn stored_shape(&self, _agent: &dyn TeamAIAdapter) -> Option<Shape> {
        Some(Shape::Tree)
    }
}
