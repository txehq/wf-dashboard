//! Schema 2 — the tables behind the agent management layer (`wf-agents`).
//!
//! The migration is additive (see `migrations/002_agents_tables.sql`), so every reader here
//! has to survive a database that does not have these tables yet: a read-only snapshot of a
//! database last written by an older `wf` is exactly that, and "no such table" is not an
//! answer anybody can act on. Reads of a missing table are empty; every write states the
//! other half through [`Db::require_agents_tables`], so a connection that never ran the
//! migration is refused before it is used rather than mid-transaction.

use crate::db::{sql, Db};
use rusqlite::{params, OptionalExtension, Row};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use wf_core::Result;

pub(crate) const MIGRATION_002: &str = include_str!("migrations/002_agents_tables.sql");
pub(crate) const MIGRATION_003: &str = include_str!("migrations/003_skipped_mcps.sql");

/// One MCP server a person told wf not to install into one agent.
///
/// `host` is **ours** — the host our own definition publishes, kept so a diagnostic can say
/// which service the decision was about. Nothing describing the connection that prompted the
/// question is here, and nothing may be added: not its name, not its transport, not its
/// credentials (WFR-016, WFR-018).
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SkippedMcp {
    pub agent_id: String,
    /// The registry's component id — `capso.mcp.linear`. Everything else about a component
    /// is keyed this way, so joining needs no translation step to get wrong.
    pub component_id: String,
    pub skipped_at: String,
    pub reason: String,
    pub host: String,
    /// Who recorded it: `user` when a person said so, `install` when the install flow did.
    pub source: String,
}

/// One object wf deployed into one agent and still owns.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ManagedResource {
    pub agent_id: String,
    pub resource_kind: String,
    pub resource_id: String,
    pub source_path: String,
    pub deployed_path: String,
    pub content_hash: String,
    pub deployed_at: String,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct UsageEventRow {
    #[serde(default)]
    pub id: i64,
    pub timestamp: String,
    pub session_id: String,
    pub agent: String,
    pub event_type: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub skill_name: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tool_name: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub source: Option<String>,
    #[serde(default, skip_serializing_if = "Value::is_null")]
    pub metadata: Value,
}

/// Which usage events a query covers. Every field narrows; the default is everything.
#[derive(Debug, Clone, Default)]
pub struct UsageQuery {
    pub agent: Option<String>,
    pub session_id: Option<String>,
    pub event_type: Option<String>,
    /// Inclusive lower bound, in the fixed-width UTC text the table stores.
    pub since: Option<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UsageGroup {
    Skill,
    Tool,
    Agent,
    EventType,
    Session,
    /// The UTC calendar day, `YYYY-MM-DD`.
    Day,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct GroupCount {
    pub key: String,
    pub count: i64,
    pub last_seen: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct KnownSkill {
    pub skill_name: String,
    pub first_seen: String,
    pub last_used: String,
    pub use_count: i64,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SessionSummaryRow {
    pub session_id: String,
    pub agent: String,
    pub start_time: String,
    #[serde(default)]
    pub end_time: Option<String>,
    pub tool_count: i64,
    pub intervention_count: i64,
    pub valuable: bool,
    #[serde(default)]
    pub first_prompt_redacted: Option<String>,
    #[serde(default, skip_serializing_if = "Value::is_null")]
    pub metadata: Value,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct AgentRegistration {
    pub agent_id: String,
    pub display_name: String,
    pub config_root: String,
    pub binary_path: String,
    pub version: String,
    #[serde(default)]
    pub last_detected: Option<String>,
    pub enabled: bool,
    #[serde(default, skip_serializing_if = "Value::is_null")]
    pub metadata: Value,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TeamRepoState {
    pub mode: String,
    #[serde(default)]
    pub remote_url: Option<String>,
    #[serde(default)]
    pub last_pull_rev: Option<String>,
    #[serde(default)]
    pub last_pull_time: Option<String>,
    #[serde(default)]
    pub last_sync_time: Option<String>,
    #[serde(default, skip_serializing_if = "Value::is_null")]
    pub metadata: Value,
}

impl Db {
    /// The invariant this module's writes rest on, stated where they are rather than left
    /// to whichever caller happened to hand over the connection. A snapshot taken for
    /// planning never ran the migration, so a write through one is a defect, not a
    /// "no such table" the transaction discovers after the files are already on disk.
    pub(crate) fn require_agents_tables(&self) -> Result<()> {
        if self.agents_ready() {
            return Ok(());
        }
        Err(wf_core::Error::failure(
            "STATE-READ-ONLY",
            "this state connection never ran the agent-layer migration; it cannot be written to",
        ))
    }

    pub(crate) fn has_table(&self, name: &str) -> Result<bool> {
        let n: i64 = self
            .conn()
            .query_row(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?1",
                params![name],
                |r| r.get(0),
            )
            .map_err(sql)?;
        Ok(n > 0)
    }

    // --- managed resources -----------------------------------------------------------

    pub fn managed_resources(&self, agent: Option<&str>) -> Result<Vec<ManagedResource>> {
        if !self.has_table("managed_resources")? {
            return Ok(vec![]);
        }
        let mut st = self
            .conn()
            .prepare(
                "SELECT agent_id,resource_kind,resource_id,source_path,deployed_path,content_hash,deployed_at
                 FROM managed_resources WHERE (?1 IS NULL OR agent_id=?1)
                 ORDER BY agent_id,resource_kind,resource_id",
            )
            .map_err(sql)?;
        let rows = st.query_map(params![agent], resource_row).map_err(sql)?;
        rows.collect::<std::result::Result<Vec<_>, _>>()
            .map_err(sql)
    }

    pub fn managed_resource(
        &self,
        agent: &str,
        kind: &str,
        id: &str,
    ) -> Result<Option<ManagedResource>> {
        if !self.has_table("managed_resources")? {
            return Ok(None);
        }
        self.conn()
            .query_row(
                "SELECT agent_id,resource_kind,resource_id,source_path,deployed_path,content_hash,deployed_at
                 FROM managed_resources WHERE agent_id=?1 AND resource_kind=?2 AND resource_id=?3",
                params![agent, kind, id],
                resource_row,
            )
            .optional()
            .map_err(sql)
    }

    pub fn upsert_managed_resource(&self, resource: &ManagedResource) -> Result<()> {
        self.require_agents_tables()?;
        self.conn()
            .execute(
                "INSERT INTO managed_resources(agent_id,resource_kind,resource_id,source_path,deployed_path,content_hash,deployed_at)
                 VALUES(?1,?2,?3,?4,?5,?6,?7)
                 ON CONFLICT(agent_id,resource_kind,resource_id) DO UPDATE SET
                   source_path=?4, deployed_path=?5, content_hash=?6, deployed_at=?7",
                params![
                    resource.agent_id,
                    resource.resource_kind,
                    resource.resource_id,
                    resource.source_path,
                    resource.deployed_path,
                    resource.content_hash,
                    resource.deployed_at
                ],
            )
            .map_err(sql)?;
        Ok(())
    }

    pub fn delete_managed_resource(&self, agent: &str, kind: &str, id: &str) -> Result<()> {
        self.require_agents_tables()?;
        self.conn()
            .execute(
                "DELETE FROM managed_resources WHERE agent_id=?1 AND resource_kind=?2 AND resource_id=?3",
                params![agent, kind, id],
            )
            .map_err(sql)?;
        Ok(())
    }

    // --- declined MCP servers ------------------------------------------------------------

    /// Every server a person told this machine not to install, per agent.
    ///
    /// Empty on a database that predates the table, which is the same answer as "nobody has
    /// declined anything" and is exactly right: a reader that cannot see the decisions must
    /// behave as though none were made, never fail.
    pub fn skipped_mcps(&self) -> Result<Vec<SkippedMcp>> {
        if !self.has_table("skipped_mcps")? {
            return Ok(vec![]);
        }
        let mut st = self
            .conn()
            .prepare(
                "SELECT agent_id,component_id,skipped_at,reason,host,source
                 FROM skipped_mcps ORDER BY agent_id,component_id",
            )
            .map_err(sql)?;
        let rows = st.query_map([], skipped_row).map_err(sql)?;
        rows.collect::<std::result::Result<Vec<_>, _>>()
            .map_err(sql)
    }

    /// Record one decision. Re-deciding the same server on the same agent replaces the row,
    /// so the timestamp is always when the person last said it.
    pub fn record_skipped_mcp(&self, row: &SkippedMcp) -> Result<()> {
        self.require_agents_tables()?;
        self.conn()
            .execute(
                "INSERT INTO skipped_mcps(agent_id,component_id,skipped_at,reason,host,source)
                 VALUES(?1,?2,?3,?4,?5,?6)
                 ON CONFLICT(agent_id,component_id) DO UPDATE SET
                   skipped_at=?3, reason=?4, host=?5, source=?6",
                params![
                    row.agent_id,
                    row.component_id,
                    row.skipped_at,
                    row.reason,
                    row.host,
                    row.source
                ],
            )
            .map_err(sql)?;
        Ok(())
    }

    /// Undo the decision. `agent` of `None` undoes it everywhere, which is what a person
    /// means by "actually, do install that one" without naming an agent. Returns how many
    /// decisions were undone, so a command can say nothing was there to undo.
    pub fn forget_skipped_mcp(&self, component_id: &str, agent: Option<&str>) -> Result<usize> {
        self.require_agents_tables()?;
        let n = self
            .conn()
            .execute(
                "DELETE FROM skipped_mcps WHERE component_id=?1 AND (?2 IS NULL OR agent_id=?2)",
                params![component_id, agent],
            )
            .map_err(sql)?;
        Ok(n)
    }

    /// Every decision made about one agent, dropped. Used when that agent stops being
    /// managed: a decision about a machine wf no longer writes to is not a decision.
    pub fn forget_skipped_mcps_of(&self, agent: &str) -> Result<()> {
        self.require_agents_tables()?;
        self.conn()
            .execute("DELETE FROM skipped_mcps WHERE agent_id=?1", params![agent])
            .map_err(sql)?;
        Ok(())
    }

    // --- usage -------------------------------------------------------------------------

    pub fn insert_usage_event(&self, event: &UsageEventRow) -> Result<i64> {
        self.require_agents_tables()?;
        self.conn()
            .execute(
                "INSERT INTO usage_events(timestamp,session_id,agent,event_type,skill_name,tool_name,source,metadata)
                 VALUES(?1,?2,?3,?4,?5,?6,?7,?8)",
                params![
                    event.timestamp,
                    event.session_id,
                    event.agent,
                    event.event_type,
                    event.skill_name,
                    event.tool_name,
                    event.source,
                    json_text(&event.metadata)
                ],
            )
            .map_err(sql)?;
        Ok(self.conn().last_insert_rowid())
    }

    /// Oldest first.
    pub fn usage_events(&self, query: &UsageQuery) -> Result<Vec<UsageEventRow>> {
        if !self.has_table("usage_events")? {
            return Ok(vec![]);
        }
        let mut st = self
            .conn()
            .prepare(&format!(
                "SELECT id,timestamp,session_id,agent,event_type,skill_name,tool_name,source,metadata
                 FROM usage_events WHERE {USAGE_FILTER} ORDER BY timestamp, id"
            ))
            .map_err(sql)?;
        let rows = st
            .query_map(usage_params(query), |r| {
                Ok(UsageEventRow {
                    id: r.get(0)?,
                    timestamp: r.get(1)?,
                    session_id: r.get(2)?,
                    agent: r.get(3)?,
                    event_type: r.get(4)?,
                    skill_name: r.get(5)?,
                    tool_name: r.get(6)?,
                    source: r.get(7)?,
                    metadata: json_value(r.get(8)?),
                })
            })
            .map_err(sql)?;
        rows.collect::<std::result::Result<Vec<_>, _>>()
            .map_err(sql)
    }

    /// Counts per group key, most frequent first, then by key.
    pub fn usage_grouped(
        &self,
        query: &UsageQuery,
        by: UsageGroup,
        limit: usize,
    ) -> Result<Vec<GroupCount>> {
        if !self.has_table("usage_events")? {
            return Ok(vec![]);
        }
        // A fixed vocabulary of column expressions, never text from the caller.
        let key = match by {
            UsageGroup::Skill => "skill_name",
            UsageGroup::Tool => "tool_name",
            UsageGroup::Agent => "agent",
            UsageGroup::EventType => "event_type",
            UsageGroup::Session => "session_id",
            UsageGroup::Day => "substr(timestamp, 1, 10)",
        };
        let mut st = self
            .conn()
            .prepare(&format!(
                "SELECT {key} AS k, COUNT(*) AS n, MAX(timestamp) FROM usage_events
                 WHERE {USAGE_FILTER} AND {key} IS NOT NULL AND {key} <> ''
                 GROUP BY k ORDER BY n DESC, k LIMIT ?5"
            ))
            .map_err(sql)?;
        let mut values = usage_params(query).to_vec();
        let limit = i64::try_from(limit).unwrap_or(i64::MAX);
        values.push(rusqlite::types::Value::Integer(limit));
        let rows = st
            .query_map(rusqlite::params_from_iter(values), |r| {
                Ok(GroupCount {
                    key: r.get(0)?,
                    count: r.get(1)?,
                    last_seen: r.get(2)?,
                })
            })
            .map_err(sql)?;
        rows.collect::<std::result::Result<Vec<_>, _>>()
            .map_err(sql)
    }

    /// The session of the most recent event, optionally for one agent.
    pub fn latest_session_id(&self, agent: Option<&str>) -> Result<Option<String>> {
        if !self.has_table("usage_events")? {
            return Ok(None);
        }
        self.conn()
            .query_row(
                "SELECT session_id FROM usage_events WHERE (?1 IS NULL OR agent=?1)
                 ORDER BY timestamp DESC, id DESC LIMIT 1",
                params![agent],
                |r| r.get(0),
            )
            .optional()
            .map_err(sql)
    }

    /// Delete events strictly older than `before`. Returns how many went.
    pub fn prune_usage_events(&self, before: &str) -> Result<usize> {
        if !self.has_table("usage_events")? {
            return Ok(0);
        }
        self.conn()
            .execute(
                "DELETE FROM usage_events WHERE timestamp < ?1",
                params![before],
            )
            .map_err(sql)
    }

    pub fn touch_known_skill(&self, name: &str, at: &str) -> Result<()> {
        self.require_agents_tables()?;
        self.conn()
            .execute(
                "INSERT INTO known_skills(skill_name,first_seen,last_used,use_count) VALUES(?1,?2,?2,1)
                 ON CONFLICT(skill_name) DO UPDATE SET
                   last_used=MAX(last_used, ?2), first_seen=MIN(first_seen, ?2), use_count=use_count+1",
                params![name, at],
            )
            .map_err(sql)?;
        Ok(())
    }

    /// Alphabetical.
    pub fn known_skills(&self) -> Result<Vec<KnownSkill>> {
        if !self.has_table("known_skills")? {
            return Ok(vec![]);
        }
        let mut st = self
            .conn()
            .prepare("SELECT skill_name,first_seen,last_used,use_count FROM known_skills ORDER BY skill_name")
            .map_err(sql)?;
        let rows = st
            .query_map([], |r| {
                Ok(KnownSkill {
                    skill_name: r.get(0)?,
                    first_seen: r.get(1)?,
                    last_used: r.get(2)?,
                    use_count: r.get(3)?,
                })
            })
            .map_err(sql)?;
        rows.collect::<std::result::Result<Vec<_>, _>>()
            .map_err(sql)
    }

    // --- sessions ----------------------------------------------------------------------

    pub fn upsert_session_summary(&self, summary: &SessionSummaryRow) -> Result<()> {
        self.require_agents_tables()?;
        self.conn()
            .execute(
                "INSERT INTO session_summaries(session_id,agent,start_time,end_time,tool_count,intervention_count,valuable,first_prompt_redacted,metadata)
                 VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9)
                 ON CONFLICT(session_id) DO UPDATE SET
                   agent=?2, start_time=?3, end_time=?4, tool_count=?5, intervention_count=?6,
                   valuable=?7, first_prompt_redacted=?8, metadata=?9",
                params![
                    summary.session_id,
                    summary.agent,
                    summary.start_time,
                    summary.end_time,
                    summary.tool_count,
                    summary.intervention_count,
                    summary.valuable,
                    summary.first_prompt_redacted,
                    json_text(&summary.metadata)
                ],
            )
            .map_err(sql)?;
        Ok(())
    }

    pub fn session_summary(&self, session_id: &str) -> Result<Option<SessionSummaryRow>> {
        if !self.has_table("session_summaries")? {
            return Ok(None);
        }
        self.conn()
            .query_row(
                &format!("SELECT {SUMMARY_COLUMNS} FROM session_summaries WHERE session_id=?1"),
                params![session_id],
                summary_row,
            )
            .optional()
            .map_err(sql)
    }

    /// Newest start first.
    pub fn session_summaries(
        &self,
        agent: Option<&str>,
        limit: usize,
    ) -> Result<Vec<SessionSummaryRow>> {
        if !self.has_table("session_summaries")? {
            return Ok(vec![]);
        }
        let mut st = self
            .conn()
            .prepare(&format!(
                "SELECT {SUMMARY_COLUMNS} FROM session_summaries WHERE (?1 IS NULL OR agent=?1)
                 ORDER BY start_time DESC, session_id LIMIT ?2"
            ))
            .map_err(sql)?;
        let limit = i64::try_from(limit).unwrap_or(i64::MAX);
        let rows = st
            .query_map(params![agent, limit], summary_row)
            .map_err(sql)?;
        rows.collect::<std::result::Result<Vec<_>, _>>()
            .map_err(sql)
    }

    // --- agent registry ----------------------------------------------------------------

    pub fn register_agent(&self, registration: &AgentRegistration) -> Result<()> {
        self.require_agents_tables()?;
        self.conn()
            .execute(
                "INSERT INTO agent_registry(agent_id,display_name,config_root,binary_path,version,last_detected,enabled,metadata)
                 VALUES(?1,?2,?3,?4,?5,?6,?7,?8)
                 ON CONFLICT(agent_id) DO UPDATE SET
                   display_name=?2, config_root=?3, binary_path=?4, version=?5, last_detected=?6, enabled=?7, metadata=?8",
                params![
                    registration.agent_id,
                    registration.display_name,
                    registration.config_root,
                    registration.binary_path,
                    registration.version,
                    registration.last_detected,
                    registration.enabled,
                    json_text(&registration.metadata)
                ],
            )
            .map_err(sql)?;
        Ok(())
    }

    /// Alphabetical by id.
    pub fn agent_registrations(&self) -> Result<Vec<AgentRegistration>> {
        if !self.has_table("agent_registry")? {
            return Ok(vec![]);
        }
        let mut st = self
            .conn()
            .prepare(
                "SELECT agent_id,display_name,config_root,binary_path,version,last_detected,enabled,metadata
                 FROM agent_registry ORDER BY agent_id",
            )
            .map_err(sql)?;
        let rows = st
            .query_map([], |r| {
                Ok(AgentRegistration {
                    agent_id: r.get(0)?,
                    display_name: r.get(1)?,
                    config_root: r.get::<_, Option<String>>(2)?.unwrap_or_default(),
                    binary_path: r.get::<_, Option<String>>(3)?.unwrap_or_default(),
                    version: r.get::<_, Option<String>>(4)?.unwrap_or_default(),
                    last_detected: r.get(5)?,
                    enabled: r.get(6)?,
                    metadata: json_value(r.get(7)?),
                })
            })
            .map_err(sql)?;
        rows.collect::<std::result::Result<Vec<_>, _>>()
            .map_err(sql)
    }

    /// Returns false when no such agent is registered.
    pub fn set_agent_enabled(&self, agent_id: &str, enabled: bool) -> Result<bool> {
        if !self.has_table("agent_registry")? {
            return Ok(false);
        }
        let n = self
            .conn()
            .execute(
                "UPDATE agent_registry SET enabled=?2 WHERE agent_id=?1",
                params![agent_id, enabled],
            )
            .map_err(sql)?;
        Ok(n == 1)
    }

    // --- team repository ----------------------------------------------------------------

    pub fn team_repo_state(&self) -> Result<Option<TeamRepoState>> {
        if !self.has_table("team_repo_state")? {
            return Ok(None);
        }
        self.conn()
            .query_row(
                "SELECT mode,remote_url,last_pull_rev,last_pull_time,last_sync_time,metadata
                 FROM team_repo_state WHERE id=1",
                [],
                |r| {
                    Ok(TeamRepoState {
                        mode: r.get(0)?,
                        remote_url: r.get(1)?,
                        last_pull_rev: r.get(2)?,
                        last_pull_time: r.get(3)?,
                        last_sync_time: r.get(4)?,
                        metadata: json_value(r.get(5)?),
                    })
                },
            )
            .optional()
            .map_err(sql)
    }

    pub fn record_team_repo_state(&self, state: &TeamRepoState) -> Result<()> {
        self.require_agents_tables()?;
        self.conn()
            .execute(
                "INSERT INTO team_repo_state(id,mode,remote_url,last_pull_rev,last_pull_time,last_sync_time,metadata)
                 VALUES(1,?1,?2,?3,?4,?5,?6)
                 ON CONFLICT(id) DO UPDATE SET
                   mode=?1, remote_url=?2, last_pull_rev=?3, last_pull_time=?4, last_sync_time=?5, metadata=?6",
                params![
                    state.mode,
                    state.remote_url,
                    state.last_pull_rev,
                    state.last_pull_time,
                    state.last_sync_time,
                    json_text(&state.metadata)
                ],
            )
            .map_err(sql)?;
        Ok(())
    }
}

/// The shared WHERE clause for usage queries; `?1`..`?4` bind [`usage_params`].
const USAGE_FILTER: &str = "(?1 IS NULL OR agent=?1) AND (?2 IS NULL OR session_id=?2)
     AND (?3 IS NULL OR event_type=?3) AND (?4 IS NULL OR timestamp>=?4)";

fn usage_params(query: &UsageQuery) -> [rusqlite::types::Value; 4] {
    let text = |v: &Option<String>| match v {
        Some(s) => rusqlite::types::Value::Text(s.clone()),
        None => rusqlite::types::Value::Null,
    };
    [
        text(&query.agent),
        text(&query.session_id),
        text(&query.event_type),
        text(&query.since),
    ]
}

const SUMMARY_COLUMNS: &str = "session_id,agent,start_time,end_time,tool_count,intervention_count,valuable,first_prompt_redacted,metadata";

fn summary_row(r: &Row<'_>) -> rusqlite::Result<SessionSummaryRow> {
    Ok(SessionSummaryRow {
        session_id: r.get(0)?,
        agent: r.get(1)?,
        start_time: r.get(2)?,
        end_time: r.get(3)?,
        tool_count: r.get(4)?,
        intervention_count: r.get(5)?,
        valuable: r.get(6)?,
        first_prompt_redacted: r.get(7)?,
        metadata: json_value(r.get(8)?),
    })
}

fn resource_row(r: &Row<'_>) -> rusqlite::Result<ManagedResource> {
    Ok(ManagedResource {
        agent_id: r.get(0)?,
        resource_kind: r.get(1)?,
        resource_id: r.get(2)?,
        source_path: r.get::<_, Option<String>>(3)?.unwrap_or_default(),
        deployed_path: r.get(4)?,
        content_hash: r.get::<_, Option<String>>(5)?.unwrap_or_default(),
        deployed_at: r.get(6)?,
    })
}

fn skipped_row(r: &Row<'_>) -> rusqlite::Result<SkippedMcp> {
    Ok(SkippedMcp {
        agent_id: r.get(0)?,
        component_id: r.get(1)?,
        skipped_at: r.get(2)?,
        reason: r.get::<_, Option<String>>(3)?.unwrap_or_default(),
        host: r.get::<_, Option<String>>(4)?.unwrap_or_default(),
        source: r.get(5)?,
    })
}

fn json_text(value: &Value) -> Option<String> {
    (!value.is_null()).then(|| value.to_string())
}

/// A metadata column that does not parse reads as absent: it is descriptive, and a row that
/// cannot be listed because of it is worse than a row listed without it.
fn json_value(text: Option<String>) -> Value {
    text.and_then(|t| serde_json::from_str(&t).ok())
        .unwrap_or(Value::Null)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{Transaction, TxOutcome};

    fn event(at: &str, session: &str, agent: &str, kind: &str) -> UsageEventRow {
        UsageEventRow {
            id: 0,
            timestamp: at.into(),
            session_id: session.into(),
            agent: agent.into(),
            event_type: kind.into(),
            skill_name: None,
            tool_name: None,
            source: None,
            metadata: Value::Null,
        }
    }

    fn resource(agent: &str, kind: &str, id: &str, hash: &str) -> ManagedResource {
        ManagedResource {
            agent_id: agent.into(),
            resource_kind: kind.into(),
            resource_id: id.into(),
            source_path: format!("skills/{id}"),
            deployed_path: format!("/home/x/.{agent}/skills/{id}"),
            content_hash: hash.into(),
            deployed_at: "2026-09-16T10:00:00.000Z".into(),
        }
    }

    /// A database as `wf` 1.7.0 left it: the old schema, and none of the new tables.
    fn pre_migration_database(path: &std::path::Path) {
        let conn = rusqlite::Connection::open(path).unwrap();
        conn.execute_batch(
            "CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
             INSERT INTO meta(key, value) VALUES('schema', '1');
             CREATE TABLE ownership_receipts (id INTEGER PRIMARY KEY AUTOINCREMENT, path TEXT NOT NULL,
               object_id TEXT NOT NULL DEFAULT '', component_id TEXT NOT NULL, before_sha256 TEXT NOT NULL DEFAULT '',
               after_sha256 TEXT NOT NULL DEFAULT '', release_version TEXT NOT NULL, backup_id TEXT, at INTEGER NOT NULL);",
        )
        .unwrap();
    }

    /// A database an earlier release left at agents-schema 2: every 002 table present, the
    /// counter recorded, and 003's table absent. The shape a real machine upgrades from.
    fn agents_schema_2_database(path: &std::path::Path) {
        let conn = rusqlite::Connection::open(path).unwrap();
        conn.execute_batch(MIGRATION_002).unwrap();
        conn.execute_batch(
            "CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
             INSERT OR REPLACE INTO meta(key, value) VALUES('schema', '1');
             INSERT OR REPLACE INTO meta(key, value) VALUES('agents_schema', '2');",
        )
        .unwrap();
    }

    /// The counter is a level, not a flag. A database already at 2 takes 003 and only 003;
    /// one at 0 takes both. Written as a single `if`, the first case silently did nothing and
    /// the table never appeared on any machine that had ever run an earlier release.
    #[test]
    fn a_database_left_at_the_previous_level_gains_only_the_new_table() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("state.sqlite3");
        agents_schema_2_database(&path);
        let db = Db::open(&path).unwrap();
        assert!(db.has_table("skipped_mcps").unwrap());
        assert_eq!(db.meta("agents_schema").unwrap().as_deref(), Some("3"));
        db.record_skipped_mcp(&skip("claude-code", "capso.mcp.linear"))
            .unwrap();
        assert_eq!(db.skipped_mcps().unwrap().len(), 1);
    }

    /// Opening twice must not disturb what is there, and the refusal version stays at 1 so an
    /// older binary can still be handed this file by `wf rollback`.
    #[test]
    fn the_skip_migration_is_additive_and_repeatable() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("state.sqlite3");
        pre_migration_database(&path);
        for _ in 0..3 {
            let db = Db::open(&path).unwrap();
            assert!(db.has_table("skipped_mcps").unwrap());
            assert_eq!(db.meta("schema").unwrap().as_deref(), Some("1"));
            db.record_skipped_mcp(&skip("claude-code", "capso.mcp.linear"))
                .unwrap();
        }
        // Re-running the migration cannot duplicate a decision, and re-deciding replaces it.
        let db = Db::open(&path).unwrap();
        assert_eq!(db.skipped_mcps().unwrap().len(), 1);
    }

    /// Down and back up: an older binary opens the file, writes through its own tables, and
    /// the newer one still finds the decision where it left it. `wf rollback` is this test.
    #[test]
    fn a_decision_survives_an_older_binary_opening_the_same_file() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("state.sqlite3");
        let db = Db::open(&path).unwrap();
        db.record_skipped_mcp(&skip("claude-code", "capso.mcp.linear"))
            .unwrap();
        drop(db);

        // An older binary knows nothing of `skipped_mcps`; it neither reads nor drops it.
        let older = rusqlite::Connection::open(&path).unwrap();
        older
            .execute_batch("UPDATE meta SET value='2' WHERE key='agents_schema';")
            .unwrap();
        drop(older);

        let db = Db::open(&path).unwrap();
        let rows = db.skipped_mcps().unwrap();
        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0].component_id, "capso.mcp.linear");
        assert_eq!(rows[0].reason, "mine is already there");
    }

    /// Reading is never a reason to fail. A snapshot taken for planning never migrated, so it
    /// cannot see the table — and "nobody has declined anything" is the right answer for a
    /// reader that cannot see the decisions, where an error would stop a dry run dead.
    #[test]
    fn decisions_read_empty_on_a_database_that_has_no_such_table() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("state.sqlite3");
        pre_migration_database(&path);
        let db = Db::open_read_only(&path).unwrap();
        assert!(db.skipped_mcps().unwrap().is_empty());
        // Writing through it is the half that must refuse, and say which half it is.
        assert_eq!(
            db.record_skipped_mcp(&skip("claude-code", "capso.mcp.linear"))
                .unwrap_err()
                .kind,
            "STATE-READ-ONLY"
        );
        assert_eq!(
            db.forget_skipped_mcp("capso.mcp.linear", None)
                .unwrap_err()
                .kind,
            "STATE-READ-ONLY"
        );
    }

    /// Undoing without naming an agent undoes it everywhere; naming one leaves the others.
    #[test]
    fn undoing_a_decision_is_per_agent_or_everywhere() {
        let db = Db::open_memory().unwrap();
        for agent in ["claude-code", "codex"] {
            db.record_skipped_mcp(&skip(agent, "capso.mcp.linear"))
                .unwrap();
            db.record_skipped_mcp(&skip(agent, "capso.mcp.rackspace-spot"))
                .unwrap();
        }
        assert_eq!(
            db.forget_skipped_mcp("capso.mcp.linear", Some("codex"))
                .unwrap(),
            1
        );
        assert_eq!(db.skipped_mcps().unwrap().len(), 3);
        assert_eq!(db.forget_skipped_mcp("capso.mcp.linear", None).unwrap(), 1);
        assert_eq!(db.forget_skipped_mcp("capso.mcp.linear", None).unwrap(), 0);

        db.forget_skipped_mcps_of("claude-code").unwrap();
        let left = db.skipped_mcps().unwrap();
        assert_eq!(left.len(), 1);
        assert_eq!(left[0].agent_id, "codex");
    }

    /// A decision is part of the installation, so removing the installation removes it.
    #[test]
    fn clearing_the_installation_clears_the_decisions() {
        let db = Db::open_memory().unwrap();
        db.record_skipped_mcp(&skip("claude-code", "capso.mcp.linear"))
            .unwrap();
        db.clear_installation().unwrap();
        assert!(db.skipped_mcps().unwrap().is_empty());
    }

    fn skip(agent: &str, component: &str) -> SkippedMcp {
        SkippedMcp {
            agent_id: agent.into(),
            component_id: component.into(),
            skipped_at: "2026-09-18T10:30:00.000Z".into(),
            reason: "mine is already there".into(),
            host: "mcp.linear.app".into(),
            source: "user".into(),
        }
    }

    #[test]
    fn the_migration_is_additive_and_leaves_the_refusal_version_alone() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("state.sqlite3");
        for _ in 0..2 {
            let db = Db::open(&path).unwrap();
            for table in [
                "usage_events",
                "known_skills",
                "session_summaries",
                "agent_registry",
                "managed_resources",
                "team_repo_state",
                "remote_commands",
                "skipped_mcps",
            ] {
                assert!(db.has_table(table).unwrap(), "{table} was not created");
            }
            // An older binary refuses a database whose schema is newer than it understands;
            // additive tables must not trip that, or `wf rollback` bricks the machine.
            assert_eq!(db.meta("schema").unwrap().as_deref(), Some("1"));
            // Its own counter records the level it reached, so the DDL is not re-checked by
            // every per-tool-call hook. Read from the constant: a migration that moves the
            // level and forgets this assertion is the one that must fail here.
            assert_eq!(
                db.meta("agents_schema").unwrap().as_deref(),
                Some(crate::db::AGENTS_SCHEMA.to_string().as_str())
            );
        }
    }

    /// The invariant this module's doc states, held where the writes are rather than by a
    /// dry-run flag two crates away: a snapshot taken for planning never ran the migration,
    /// and a write through one would fail after the files were already on disk.
    #[test]
    fn a_connection_that_never_migrated_refuses_a_write() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("state.sqlite3");
        pre_migration_database(&path);
        let db = Db::open_read_only(&path).unwrap();
        assert_eq!(
            db.upsert_managed_resource(&resource("claude-code", "skill", "lfg", "a"))
                .unwrap_err()
                .kind,
            "STATE-READ-ONLY"
        );
        assert_eq!(
            db.delete_managed_resource("claude-code", "skill", "lfg")
                .unwrap_err()
                .kind,
            "STATE-READ-ONLY"
        );
        assert_eq!(
            db.touch_known_skill("lfg", "2026-09-17T10:00:00.000Z")
                .unwrap_err()
                .kind,
            "STATE-READ-ONLY"
        );
    }

    #[test]
    fn a_database_written_by_an_older_wf_gains_the_tables_when_opened() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("state.sqlite3");
        pre_migration_database(&path);
        let db = Db::open(&path).unwrap();
        db.upsert_managed_resource(&resource("claude-code", "skill", "lfg", "a"))
            .unwrap();
        assert_eq!(db.managed_resources(None).unwrap().len(), 1);
    }

    #[test]
    fn a_read_only_snapshot_of_an_older_database_reads_empty_rather_than_failing() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("state.sqlite3");
        pre_migration_database(&path);
        let db = Db::open_read_only(&path).unwrap();
        assert!(db.managed_resources(None).unwrap().is_empty());
        assert!(db
            .managed_resource("claude-code", "skill", "lfg")
            .unwrap()
            .is_none());
        assert!(db.usage_events(&UsageQuery::default()).unwrap().is_empty());
        assert!(db
            .usage_grouped(&UsageQuery::default(), UsageGroup::Skill, 10)
            .unwrap()
            .is_empty());
        assert!(db.known_skills().unwrap().is_empty());
        assert!(db.session_summaries(None, 10).unwrap().is_empty());
        assert!(db.session_summary("s").unwrap().is_none());
        assert!(db.latest_session_id(None).unwrap().is_none());
        assert!(db.agent_registrations().unwrap().is_empty());
        assert!(db.team_repo_state().unwrap().is_none());
    }

    #[test]
    fn a_managed_resource_is_one_row_per_agent_kind_and_id() {
        let db = Db::open_memory().unwrap();
        db.upsert_managed_resource(&resource("claude-code", "skill", "lfg", "a"))
            .unwrap();
        db.upsert_managed_resource(&resource("claude-code", "skill", "lfg", "b"))
            .unwrap();
        db.upsert_managed_resource(&resource("codex", "skill", "lfg", "a"))
            .unwrap();
        db.upsert_managed_resource(&resource("codex", "rule", "lfg", "a"))
            .unwrap();
        assert_eq!(db.managed_resources(None).unwrap().len(), 3);
        let claude = db.managed_resources(Some("claude-code")).unwrap();
        assert_eq!(claude.len(), 1);
        assert_eq!(claude[0].content_hash, "b", "an upsert replaces the hash");
        assert_eq!(
            db.managed_resource("codex", "rule", "lfg").unwrap(),
            Some(resource("codex", "rule", "lfg", "a"))
        );
        db.delete_managed_resource("codex", "rule", "lfg").unwrap();
        assert!(db
            .managed_resource("codex", "rule", "lfg")
            .unwrap()
            .is_none());
        // Deleting what is not there is not an error: removal is idempotent.
        db.delete_managed_resource("codex", "rule", "lfg").unwrap();
    }

    #[test]
    fn usage_events_round_trip_and_narrow_by_agent_session_type_and_time() {
        let db = Db::open_memory().unwrap();
        let mut skill = event("2026-09-16T10:00:01.000Z", "s1", "claude-code", "skill");
        skill.skill_name = Some("lfg".into());
        skill.source = Some("skill-tool".into());
        skill.metadata = serde_json::json!({"cwd": "/work"});
        let id = db.insert_usage_event(&skill).unwrap();
        assert!(id > 0);
        let mut tool = event("2026-09-16T10:00:02.000Z", "s1", "claude-code", "tool");
        tool.tool_name = Some("Edit".into());
        db.insert_usage_event(&tool).unwrap();
        db.insert_usage_event(&event(
            "2026-09-15T09:00:00.000Z",
            "s0",
            "codex",
            "session_start",
        ))
        .unwrap();

        let all = db.usage_events(&UsageQuery::default()).unwrap();
        assert_eq!(all.len(), 3);
        assert_eq!(all[0].session_id, "s0", "oldest first");
        let round = all.iter().find(|e| e.event_type == "skill").unwrap();
        assert_eq!(round.skill_name.as_deref(), Some("lfg"));
        assert_eq!(round.metadata["cwd"], "/work");

        let q = |agent: Option<&str>,
                 session: Option<&str>,
                 kind: Option<&str>,
                 since: Option<&str>| UsageQuery {
            agent: agent.map(Into::into),
            session_id: session.map(Into::into),
            event_type: kind.map(Into::into),
            since: since.map(Into::into),
        };
        assert_eq!(
            db.usage_events(&q(Some("codex"), None, None, None))
                .unwrap()
                .len(),
            1
        );
        assert_eq!(
            db.usage_events(&q(None, Some("s1"), None, None))
                .unwrap()
                .len(),
            2
        );
        assert_eq!(
            db.usage_events(&q(None, None, Some("tool"), None))
                .unwrap()
                .len(),
            1
        );
        assert_eq!(
            db.usage_events(&q(None, None, None, Some("2026-09-16T10:00:01.000Z")))
                .unwrap()
                .len(),
            2,
            "since is inclusive"
        );
        assert_eq!(db.latest_session_id(None).unwrap().as_deref(), Some("s1"));
        assert_eq!(
            db.latest_session_id(Some("codex")).unwrap().as_deref(),
            Some("s0")
        );
    }

    #[test]
    fn grouped_usage_counts_most_frequent_first_with_the_last_time_seen() {
        let db = Db::open_memory().unwrap();
        for (at, name) in [
            ("2026-09-14T08:00:00.000Z", "plan"),
            ("2026-09-16T08:00:00.000Z", "lfg"),
            ("2026-09-16T09:00:00.000Z", "lfg"),
            ("2026-09-15T09:00:00.000Z", "ic"),
        ] {
            let mut e = event(at, "s", "claude-code", "skill");
            e.skill_name = Some(name.into());
            db.insert_usage_event(&e).unwrap();
        }
        let mut t = event("2026-09-16T09:30:00.000Z", "s", "codex", "tool");
        t.tool_name = Some("Bash".into());
        db.insert_usage_event(&t).unwrap();

        let skills = db
            .usage_grouped(&UsageQuery::default(), UsageGroup::Skill, 10)
            .unwrap();
        assert_eq!(
            skills,
            vec![
                GroupCount {
                    key: "lfg".into(),
                    count: 2,
                    last_seen: "2026-09-16T09:00:00.000Z".into()
                },
                GroupCount {
                    key: "ic".into(),
                    count: 1,
                    last_seen: "2026-09-15T09:00:00.000Z".into()
                },
                GroupCount {
                    key: "plan".into(),
                    count: 1,
                    last_seen: "2026-09-14T08:00:00.000Z".into()
                },
            ],
            "rows without a skill name do not form a group"
        );
        assert_eq!(
            db.usage_grouped(&UsageQuery::default(), UsageGroup::Skill, 1)
                .unwrap()
                .len(),
            1
        );
        let days = db
            .usage_grouped(&UsageQuery::default(), UsageGroup::Day, 10)
            .unwrap();
        assert_eq!(days[0].key, "2026-09-16");
        assert_eq!(days[0].count, 3);
        let agents = db
            .usage_grouped(&UsageQuery::default(), UsageGroup::Agent, 10)
            .unwrap();
        assert_eq!(
            agents[0],
            GroupCount {
                key: "claude-code".into(),
                count: 4,
                last_seen: "2026-09-16T09:00:00.000Z".into()
            }
        );
        let tools = db
            .usage_grouped(&UsageQuery::default(), UsageGroup::Tool, 10)
            .unwrap();
        assert_eq!(tools.len(), 1);
        let kinds = db
            .usage_grouped(&UsageQuery::default(), UsageGroup::EventType, 10)
            .unwrap();
        assert_eq!(kinds[0].key, "skill");
        let sessions = db
            .usage_grouped(&UsageQuery::default(), UsageGroup::Session, 10)
            .unwrap();
        assert_eq!(sessions[0].count, 5);
    }

    #[test]
    fn pruning_removes_only_events_older_than_the_cutoff() {
        let db = Db::open_memory().unwrap();
        for at in [
            "2026-06-01T00:00:00.000Z",
            "2026-09-01T00:00:00.000Z",
            "2026-09-16T00:00:00.000Z",
        ] {
            db.insert_usage_event(&event(at, "s", "codex", "tool"))
                .unwrap();
        }
        assert_eq!(
            db.prune_usage_events("2026-09-01T00:00:00.000Z").unwrap(),
            1
        );
        assert_eq!(db.usage_events(&UsageQuery::default()).unwrap().len(), 2);
        assert_eq!(
            db.prune_usage_events("2026-09-01T00:00:00.000Z").unwrap(),
            0
        );
    }

    #[test]
    fn a_known_skill_keeps_its_first_sighting_and_counts_every_use() {
        let db = Db::open_memory().unwrap();
        db.touch_known_skill("lfg", "2026-09-10T00:00:00.000Z")
            .unwrap();
        db.touch_known_skill("ic", "2026-09-11T00:00:00.000Z")
            .unwrap();
        db.touch_known_skill("lfg", "2026-09-12T00:00:00.000Z")
            .unwrap();
        assert_eq!(
            db.known_skills().unwrap(),
            vec![
                KnownSkill {
                    skill_name: "ic".into(),
                    first_seen: "2026-09-11T00:00:00.000Z".into(),
                    last_used: "2026-09-11T00:00:00.000Z".into(),
                    use_count: 1
                },
                KnownSkill {
                    skill_name: "lfg".into(),
                    first_seen: "2026-09-10T00:00:00.000Z".into(),
                    last_used: "2026-09-12T00:00:00.000Z".into(),
                    use_count: 2
                },
            ]
        );
    }

    #[test]
    fn a_session_summary_is_replaced_in_place_and_listed_newest_first() {
        let db = Db::open_memory().unwrap();
        let mut first = SessionSummaryRow {
            session_id: "s1".into(),
            agent: "claude-code".into(),
            start_time: "2026-09-15T10:00:00.000Z".into(),
            end_time: None,
            tool_count: 1,
            intervention_count: 0,
            valuable: false,
            first_prompt_redacted: Some("fix the build".into()),
            metadata: serde_json::json!({"distinct_tools": 1}),
        };
        db.upsert_session_summary(&first).unwrap();
        first.tool_count = 9;
        first.valuable = true;
        first.end_time = Some("2026-09-15T11:00:00.000Z".into());
        db.upsert_session_summary(&first).unwrap();
        let second = SessionSummaryRow {
            session_id: "s2".into(),
            agent: "codex".into(),
            start_time: "2026-09-16T10:00:00.000Z".into(),
            end_time: None,
            tool_count: 0,
            intervention_count: 0,
            valuable: false,
            first_prompt_redacted: None,
            metadata: Value::Null,
        };
        db.upsert_session_summary(&second).unwrap();

        assert_eq!(db.session_summary("s1").unwrap(), Some(first.clone()));
        let listed = db.session_summaries(None, 10).unwrap();
        assert_eq!(
            listed
                .iter()
                .map(|s| s.session_id.as_str())
                .collect::<Vec<_>>(),
            ["s2", "s1"]
        );
        assert_eq!(
            db.session_summaries(Some("claude-code"), 10).unwrap(),
            vec![first]
        );
        assert_eq!(db.session_summaries(None, 1).unwrap().len(), 1);
    }

    #[test]
    fn an_agent_registration_is_upserted_and_can_be_disabled() {
        let db = Db::open_memory().unwrap();
        let mut cursor = AgentRegistration {
            agent_id: "cursor".into(),
            display_name: "Cursor".into(),
            config_root: "/home/x/.cursor".into(),
            binary_path: String::new(),
            version: String::new(),
            last_detected: Some("2026-09-16T10:00:00.000Z".into()),
            enabled: true,
            metadata: serde_json::json!({"paths": {"skills": "skills"}}),
        };
        db.register_agent(&cursor).unwrap();
        cursor.version = "1.2.3".into();
        db.register_agent(&cursor).unwrap();
        let claude = AgentRegistration {
            agent_id: "claude-code".into(),
            display_name: "Claude Code".into(),
            config_root: "/home/x/.claude".into(),
            binary_path: "/usr/bin/claude".into(),
            version: "2.1.0".into(),
            last_detected: None,
            enabled: true,
            metadata: Value::Null,
        };
        db.register_agent(&claude).unwrap();
        assert_eq!(
            db.agent_registrations().unwrap(),
            vec![claude, cursor.clone()]
        );
        assert!(db.set_agent_enabled("cursor", false).unwrap());
        assert!(!db.agent_registrations().unwrap()[1].enabled);
        assert!(!db.set_agent_enabled("windsurf", false).unwrap());
    }

    #[test]
    fn the_team_repository_state_is_one_row() {
        let db = Db::open_memory().unwrap();
        let mut state = TeamRepoState {
            mode: "self-repo".into(),
            remote_url: None,
            last_pull_rev: Some("abc".into()),
            last_pull_time: Some("2026-09-16T10:00:00.000Z".into()),
            last_sync_time: None,
            metadata: Value::Null,
        };
        db.record_team_repo_state(&state).unwrap();
        state.last_pull_rev = Some("def".into());
        db.record_team_repo_state(&state).unwrap();
        assert_eq!(db.team_repo_state().unwrap(), Some(state));
    }

    #[test]
    fn resource_rows_are_published_by_commit_and_never_by_a_rollback() {
        let dir = tempfile::tempdir().unwrap();
        let db = Db::open_memory().unwrap();

        let mut tx = Transaction::begin(&db, dir.path().join("backups"), "2.0.0", false);
        tx.record_resource(resource("claude-code", "skill", "lfg", "a"));
        // Visible to the rest of the same transaction before it commits…
        assert!(tx
            .managed_resource("claude-code", "skill", "lfg")
            .unwrap()
            .is_some());
        // …and to nobody else.
        assert!(db
            .managed_resource("claude-code", "skill", "lfg")
            .unwrap()
            .is_none());
        tx.rollback();
        assert!(db.managed_resources(None).unwrap().is_empty());

        let mut tx = Transaction::begin(&db, dir.path().join("backups"), "2.0.0", false);
        tx.record_resource(resource("claude-code", "skill", "lfg", "a"));
        tx.record_resource(resource("claude-code", "skill", "ic", "a"));
        let _: TxOutcome = tx.commit().unwrap();
        assert_eq!(db.managed_resources(None).unwrap().len(), 2);

        let mut tx = Transaction::begin(&db, dir.path().join("backups"), "2.0.0", false);
        tx.forget_resource("claude-code", "skill", "ic");
        tx.record_resource(resource("claude-code", "skill", "plan", "b"));
        tx.record_resource(resource("codex", "skill", "plan", "b"));
        assert!(tx
            .managed_resource("claude-code", "skill", "ic")
            .unwrap()
            .is_none());
        let mut pending: Vec<String> = tx
            .managed_resources("claude-code")
            .unwrap()
            .into_iter()
            .map(|r| r.resource_id)
            .collect();
        pending.sort();
        assert_eq!(
            pending,
            ["lfg", "plan"],
            "the pending view is per agent, deletes applied"
        );
        tx.forget_resource("claude-code", "skill", "plan");
        tx.forget_resource("codex", "skill", "plan");
        tx.commit().unwrap();
        assert_eq!(db.managed_resources(None).unwrap().len(), 1);
    }

    #[test]
    fn a_dry_run_records_no_resource_rows() {
        let dir = tempfile::tempdir().unwrap();
        let db = Db::open_memory().unwrap();
        let mut tx = Transaction::begin(&db, dir.path().join("backups"), "2.0.0", true);
        tx.record_resource(resource("codex", "mcp", "capso-linear", "a"));
        tx.commit().unwrap();
        assert!(db.managed_resources(None).unwrap().is_empty());
    }

    #[test]
    fn clearing_an_installation_forgets_what_it_owned_and_keeps_local_history() {
        let db = Db::open_memory().unwrap();
        db.upsert_managed_resource(&resource("codex", "skill", "lfg", "a"))
            .unwrap();
        db.record_team_repo_state(&TeamRepoState {
            mode: "self-repo".into(),
            remote_url: None,
            last_pull_rev: None,
            last_pull_time: None,
            last_sync_time: None,
            metadata: Value::Null,
        })
        .unwrap();
        db.register_agent(&AgentRegistration {
            agent_id: "codex".into(),
            display_name: "Codex CLI".into(),
            config_root: String::new(),
            binary_path: String::new(),
            version: String::new(),
            last_detected: None,
            enabled: true,
            metadata: Value::Null,
        })
        .unwrap();
        db.insert_usage_event(&event("2026-09-16T10:00:00.000Z", "s", "codex", "tool"))
            .unwrap();
        db.touch_known_skill("lfg", "2026-09-16T10:00:00.000Z")
            .unwrap();

        db.clear_installation().unwrap();
        assert!(db.managed_resources(None).unwrap().is_empty());
        assert!(db.team_repo_state().unwrap().is_none());
        assert!(db.agent_registrations().unwrap().is_empty());
        // The person's own usage history is theirs, not the installation's.
        assert_eq!(db.usage_events(&UsageQuery::default()).unwrap().len(), 1);
        assert_eq!(db.known_skills().unwrap().len(), 1);
    }
}
