//! Provisioning for the `/review-pr` detector.
//!
//! The detector itself is Python and ships with the skill; this crate exists because every
//! path in a supervised job is machine-specific, and a launchd job whose interpreter does not
//! exist fails at load and then is simply not there.
//!
//! What this crate does *not* own: reviewing. It writes a plist, loads it, and reports what
//! the supervisor says. The review-only authority boundary lives in the skill contract and in
//! the detector, and nothing here may widen it.

use serde::Serialize;
use std::path::{Path, PathBuf};
use wf_core::{Error, Result};
use wf_readiness::{Resolver, CTX_LOGIN, CTX_MINIMAL, CTX_SESSION};

/// Label prefix for jobs this crate owns.
///
/// Deliberately distinct from the `com.openai.rpr-monitor.*` jobs that predate the port, so
/// installing here can never overwrite one — see [`legacy_label`], which turns that same
/// distinctness into a refusal rather than a silent second poller.
pub const LABEL_PREFIX: &str = "com.capso.wf.review-pr";

/// The pre-port label prefix. Still running on at least one machine.
pub const LEGACY_LABEL_PREFIX: &str = "com.openai.rpr-monitor";

/// One supervised detector, for one repository.
///
/// One process per repository is the detector's own isolation boundary — leases, circuits and
/// the SQLite database are all per state directory — so provisioning keeps it rather than
/// inventing a multiplexed job that would have to re-derive that isolation.
#[derive(Debug, Clone, Serialize)]
pub struct Job {
    pub repo: String,
    pub owner: String,
    pub name: String,
    pub label: String,
    pub state_dir: PathBuf,
    pub plist: PathBuf,
    pub stdout_log: PathBuf,
    pub stderr_log: PathBuf,
}

impl Job {
    /// Derive every path for `owner/repo`.
    ///
    /// `home` is a parameter rather than read from the environment so the derivation is
    /// testable without touching a real home directory.
    pub fn new(repo: &str, home: &Path) -> Result<Self> {
        let (owner, name) = split_repo(repo)?;
        let slug = format!("{owner}_{name}");
        Ok(Self {
            // What the detector polls is resolved against GitHub, so it is the current org's
            // name even when typed with the former one. The label and paths keep the spelling
            // given, so a job installed under that spelling can still be found and removed.
            repo: wf_core::canonical_repo(repo),
            owner: owner.clone(),
            name: name.clone(),
            label: format!("{LABEL_PREFIX}.{owner}-{name}"),
            state_dir: home
                .join("Library/Application Support/Capso/ReviewPR")
                .join(&slug),
            plist: home
                .join("Library/LaunchAgents")
                .join(format!("{LABEL_PREFIX}.{owner}-{name}.plist")),
            stdout_log: home
                .join("Library/Logs")
                .join(format!("wf-review-pr-{slug}.log")),
            stderr_log: home
                .join("Library/Logs")
                .join(format!("wf-review-pr-{slug}.error.log")),
        })
    }

    /// The pre-port job label for the same repository, whose presence must block an install.
    pub fn legacy_label(&self) -> String {
        format!("{LEGACY_LABEL_PREFIX}.{}-{}", self.owner, self.name)
    }

    /// Every other job that may already be polling this repository, and must block an install:
    /// the pre-port job, plus both jobs under the org's other name — a monitor installed
    /// under `capsohq/x` and one under `txehq/x` poll the same repository (TXE-1927).
    pub fn conflicting_labels(&self) -> Vec<String> {
        let mut out = vec![self.legacy_label()];
        let other = if self.owner.eq_ignore_ascii_case(wf_core::ORG) {
            Some(wf_core::FORMER_ORG)
        } else if self.owner.eq_ignore_ascii_case(wf_core::FORMER_ORG) {
            Some(wf_core::ORG)
        } else {
            None
        };
        if let Some(owner) = other {
            out.push(format!("{LEGACY_LABEL_PREFIX}.{owner}-{}", self.name));
            out.push(format!("{LABEL_PREFIX}.{owner}-{}", self.name));
        }
        out
    }
}

/// `owner/name`, rejected early rather than baked into a label and a path.
fn split_repo(repo: &str) -> Result<(String, String)> {
    let mut parts = repo.splitn(2, '/');
    let owner = parts.next().unwrap_or_default();
    let name = parts.next().unwrap_or_default();
    let ok = |s: &str| {
        !s.is_empty()
            && s.chars()
                .all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_' || c == '.')
    };
    if !ok(owner) || !ok(name) {
        return Err(Error::usage(
            "REVIEW-PR-REPO-INVALID",
            format!("expected OWNER/REPO, got {repo:?}"),
        )
        .with_zh("请使用 OWNER/REPO 的形式，例如 txehq/tokun-cn。"));
    }
    Ok((owner.to_string(), name.to_string()))
}

/// The absolute `uv`, `gh`, `codex` and `node` a supervised job runs.
#[derive(Debug, Clone, Serialize)]
pub struct Tools {
    /// Runs the detector with the dependencies its inline script metadata declares.
    pub uv: String,
    pub gh: String,
    /// The detector launches review workers with it.
    pub codex: String,
    /// Runs `codex` when npm installed it: npm's `codex` starts with `#!/usr/bin/env node`.
    pub node: String,
}

/// Resolve the four binaries the job runs.
///
/// **The detector receives `uv`, `gh` and `codex` as absolute paths**, and the job's `PATH`
/// holds the directories of all four ([`job_path`]). launchd does not run a login shell, so a
/// job inherits a `PATH` that resolves almost nothing, and a plist that names a bare binary
/// works in a terminal and fails under the supervisor while looking installed. Resolution
/// reuses `/readiness`'s three contexts, so both answer the same way.
///
/// A missing binary refuses the install: a monitor that installs cleanly and then cannot run
/// is exactly what this command exists to prevent.
pub fn resolve_tools(resolver: &Resolver) -> Result<Tools> {
    let mut missing = Vec::new();
    let mut pick = |bin: &str| -> String {
        let r = resolver.resolve(bin);
        // Login before session: the supervisor is closer to a login shell than to whatever
        // environment this command happens to be invoked from, and a session-only binary
        // (a virtualenv, a shim inherited from a parent process) may not exist for launchd.
        for ctx in [CTX_LOGIN, CTX_SESSION, CTX_MINIMAL] {
            if r.found_in(ctx) {
                return r.in_ctx(ctx).to_string();
            }
        }
        missing.push(bin.to_string());
        String::new()
    };
    let uv = pick("uv");
    let gh = pick("gh");
    let codex = pick("codex");
    let node = pick("node");
    if !missing.is_empty() {
        return Err(Error::failure(
            "REVIEW-PR-TOOL-MISSING",
            format!(
                "the supervised detector needs {} on this machine",
                missing.join(" and ")
            ),
        )
        .with_zh("请先安装缺少的命令，然后重新运行 wf review-pr install。"));
    }
    Ok(Tools {
        uv,
        gh,
        codex,
        node,
    })
}

/// The `PATH` the job runs with: the directory of each resolved binary once, `node` first,
/// then the system directories.
///
/// The detector passes its binaries by absolute path; its workers need the `PATH`. npm's
/// `codex` runs `#!/usr/bin/env node`, and a follow-up worker runs `gh` itself.
pub fn job_path(tools: &Tools) -> String {
    let mut dirs: Vec<String> = Vec::new();
    for bin in [&tools.node, &tools.codex, &tools.gh, &tools.uv] {
        let dir = Path::new(bin)
            .parent()
            .expect("a resolved binary is an absolute path")
            .display()
            .to_string();
        if !dirs.contains(&dir) {
            dirs.push(dir);
        }
    }
    for dir in ["/usr/bin", "/bin", "/usr/sbin", "/sbin"] {
        if !dirs.iter().any(|d| d == dir) {
            dirs.push(dir.to_string());
        }
    }
    dirs.join(":")
}

/// The reviewers a detector has in flight, as their own process-group leaders.
///
/// A worker is spawned with `setsid` so that launchd restarting the detector — `KeepAlive`
/// fires on any unexpected exit — does not take a review down with it. Nothing else then
/// bounds a worker's life, so uninstall has to end them: an orphaned `codex exec` outlives
/// the detector that would have reaped it, and can post a review for a job nobody is left
/// to record.
pub fn running_workers(state_dir: &Path) -> Result<Vec<i32>> {
    let db = state_dir.join("monitor.sqlite3");
    if !db.is_file() {
        return Ok(vec![]);
    }
    let conn = rusqlite::Connection::open_with_flags(
        &db,
        rusqlite::OpenFlags::SQLITE_OPEN_READ_ONLY | rusqlite::OpenFlags::SQLITE_OPEN_URI,
    )
    .map_err(|e| Error::failure("REVIEW-PR-STATE", format!("{}: {e}", db.display())))?;
    let mut statement = conn
        .prepare("SELECT pid FROM jobs WHERE status = 'running' AND pid IS NOT NULL")
        .map_err(|e| Error::failure("REVIEW-PR-STATE", format!("{}: {e}", db.display())))?;
    let pids = statement
        .query_map([], |row| row.get::<_, i64>(0))
        .and_then(|rows| rows.collect::<std::result::Result<Vec<i64>, _>>())
        .map_err(|e| Error::failure("REVIEW-PR-STATE", format!("{}: {e}", db.display())))?;
    Ok(pids.into_iter().map(|pid| pid as i32).collect())
}

/// End one worker's process group. Returns whether a group was there to signal.
#[cfg(unix)]
pub fn stop_worker(pid: i32) -> bool {
    // The worker leads its own group, so its group id is its pid and the signal reaches the
    // `codex` it spawned as well as the worker itself.
    unsafe { libc::killpg(pid, libc::SIGTERM) == 0 }
}

#[cfg(not(unix))]
pub fn stop_worker(_pid: i32) -> bool {
    false
}

/// Refuse a repository the resolved `gh` cannot read with the current GitHub credentials: a
/// detector that installs and then cannot poll reviews nothing.
pub fn check_repo(gh: &str, repo: &str) -> Result<()> {
    let out = std::process::Command::new(gh)
        .args(["api", &format!("repos/{repo}"), "--jq", ".full_name"])
        .output()?;
    if !out.status.success() {
        return Err(Error::failure(
            "REVIEW-PR-REPO-UNREACHABLE",
            format!(
                "{gh} cannot read {repo}: {}",
                String::from_utf8_lossy(&out.stderr).trim()
            ),
        )
        .with_zh(
            "当前的 GitHub 凭据无法读取这个仓库，请确认 gh 已登录并且有这个仓库的访问权限。",
        ));
    }
    Ok(())
}

/// Everything the generated plist needs beyond the derived paths.
#[derive(Debug, Clone)]
pub struct Options {
    /// Absolute path to `review_monitor.py`.
    pub script: PathBuf,
    pub poll_seconds: u32,
    pub debounce_seconds: u32,
    pub max_workers: u32,
    pub job_timeout_seconds: u32,
    pub review_model: String,
    pub review_effort: String,
    pub coordinator_model: String,
    pub coordinator_effort: String,
    pub coordinator_sandbox: String,
}

impl Default for Options {
    fn default() -> Self {
        Self {
            script: PathBuf::new(),
            poll_seconds: 30,
            debounce_seconds: 90,
            max_workers: 2,
            job_timeout_seconds: 1800,
            review_model: "gpt-5.6-sol".into(),
            // High for every diff: a real finding hides in the change nobody thought was risky.
            review_effort: "high".into(),
            coordinator_model: "gpt-5.6-luna".into(),
            coordinator_effort: "low".into(),
            coordinator_sandbox: "danger-full-access".into(),
        }
    }
}

/// Render the launchd job. Pure: no filesystem, no environment, so it is fully testable.
pub fn plist(job: &Job, tools: &Tools, opts: &Options) -> String {
    let args: Vec<String> = vec![
        tools.uv.clone(),
        "run".into(),
        "--script".into(),
        opts.script.display().to_string(),
        "--repo".into(),
        job.repo.clone(),
        "--state-dir".into(),
        job.state_dir.display().to_string(),
        "--gh".into(),
        tools.gh.clone(),
        "--codex".into(),
        tools.codex.clone(),
        "--poll-seconds".into(),
        opts.poll_seconds.to_string(),
        "--debounce-seconds".into(),
        opts.debounce_seconds.to_string(),
        "--max-workers".into(),
        opts.max_workers.to_string(),
        "--job-timeout-seconds".into(),
        opts.job_timeout_seconds.to_string(),
        "--review-model".into(),
        opts.review_model.clone(),
        "--review-effort".into(),
        opts.review_effort.clone(),
        "--coordinator-model".into(),
        opts.coordinator_model.clone(),
        "--coordinator-effort".into(),
        opts.coordinator_effort.clone(),
        "--coordinator-sandbox".into(),
        opts.coordinator_sandbox.clone(),
    ];
    let rendered: String = args
        .iter()
        .map(|a| format!("    <string>{}</string>\n", xml_escape(a)))
        .collect();

    format!(
        r#"<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>{label}</string>
  <!-- Generated by `wf review-pr install`. Edit the command, not this file: a
       reinstall overwrites it, and hand-edited absolute paths are what this
       command exists to remove. -->
  <key>ProgramArguments</key>
  <array>
{args}  </array>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key>
    <string>{path}</string>
  </dict>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>ThrottleInterval</key>
  <integer>10</integer>
  <key>ProcessType</key>
  <string>Background</string>
  <key>LowPriorityIO</key>
  <true/>
  <key>StandardOutPath</key>
  <string>{out}</string>
  <key>StandardErrorPath</key>
  <string>{err}</string>
</dict>
</plist>
"#,
        label = xml_escape(&job.label),
        args = rendered,
        path = xml_escape(&job_path(tools)),
        out = xml_escape(&job.stdout_log.display().to_string()),
        err = xml_escape(&job.stderr_log.display().to_string()),
    )
}

fn xml_escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
}

#[cfg(test)]
mod tests {
    use super::*;

    fn home() -> PathBuf {
        PathBuf::from("/Users/example")
    }

    fn tools() -> Tools {
        Tools {
            uv: "/opt/homebrew/bin/uv".into(),
            gh: "/opt/homebrew/bin/gh".into(),
            codex: "/opt/homebrew/bin/codex".into(),
            node: "/Users/example/.local/share/fnm/node-versions/v24.15.0/installation/bin/node"
                .into(),
        }
    }

    fn opts() -> Options {
        Options {
            script: PathBuf::from("/Users/example/.local/state/wf/active/bundle/skills/review-pr/scripts/review_monitor.py"),
            ..Default::default()
        }
    }

    #[test]
    fn a_repo_becomes_a_label_and_a_state_directory() {
        let job = Job::new("capsohq/tokun-cn", &home()).unwrap();
        assert_eq!(job.label, "com.capso.wf.review-pr.capsohq-tokun-cn");
        assert!(job.state_dir.ends_with("Capso/ReviewPR/capsohq_tokun-cn"));
        assert!(job
            .plist
            .ends_with("Library/LaunchAgents/com.capso.wf.review-pr.capsohq-tokun-cn.plist"));
    }

    #[test]
    fn the_label_never_collides_with_the_pre_port_job() {
        // Both may exist on a machine that has not retired the old one. They must be
        // distinguishable, because install refuses on the legacy label rather than racing it.
        let job = Job::new("capsohq/tokun-cn", &home()).unwrap();
        assert_ne!(job.label, job.legacy_label());
        assert_eq!(
            job.legacy_label(),
            "com.openai.rpr-monitor.capsohq-tokun-cn"
        );
        assert!(!job.label.starts_with(LEGACY_LABEL_PREFIX));
    }

    #[test]
    fn a_monitor_installed_under_the_former_org_blocks_one_under_the_current_org() {
        let job = Job::new("txehq/tokun-cn", &home()).unwrap();
        assert_eq!(
            job.conflicting_labels(),
            [
                "com.openai.rpr-monitor.txehq-tokun-cn",
                "com.openai.rpr-monitor.capsohq-tokun-cn",
                "com.capso.wf.review-pr.capsohq-tokun-cn",
            ]
        );
        assert!(!job.conflicting_labels().contains(&job.label));
        let former = Job::new("capsohq/tokun-cn", &home()).unwrap();
        assert_eq!(former.repo, "txehq/tokun-cn");
        assert_eq!(former.label, "com.capso.wf.review-pr.capsohq-tokun-cn");
        assert_eq!(
            former.conflicting_labels(),
            [
                "com.openai.rpr-monitor.capsohq-tokun-cn",
                "com.openai.rpr-monitor.txehq-tokun-cn",
                "com.capso.wf.review-pr.txehq-tokun-cn",
            ]
        );
        let other = Job::new("someone/tokun-cn", &home()).unwrap();
        assert_eq!(other.conflicting_labels(), [other.legacy_label()]);
    }

    #[test]
    fn a_malformed_repo_is_refused_before_anything_is_written() {
        for bad in ["tokun-cn", "", "owner/", "/name", "a/b/c", "own er/name"] {
            let err = Job::new(bad, &home()).unwrap_err();
            assert_eq!(err.kind, "REVIEW-PR-REPO-INVALID", "accepted {bad:?}");
        }
        // `a/b/c` must fail because the name is invalid, not because it silently truncated.
        assert!(Job::new("capsohq/tokun-cn", &home()).is_ok());
    }

    #[test]
    fn the_plist_passes_the_detector_absolute_binaries() {
        // launchd runs with a PATH that resolves almost nothing, so a bare `uv`, `gh` or
        // `codex` here is a job that loads and then cannot run.
        let job = Job::new("capsohq/tokun-cn", &home()).unwrap();
        let xml = plist(&job, &tools(), &opts());
        assert!(xml.contains(
            "<string>/opt/homebrew/bin/uv</string>\n    <string>run</string>\n    <string>--script</string>"
        ));
        assert!(xml.contains("<string>/opt/homebrew/bin/gh</string>"));
        assert!(
            xml.contains("<string>--codex</string>\n    <string>/opt/homebrew/bin/codex</string>")
        );
        for bare in [
            "<string>uv</string>",
            "<string>python3</string>",
            "<string>gh</string>",
            "<string>codex</string>",
        ] {
            assert!(!xml.contains(bare), "plist names a bare binary: {bare}");
        }
    }

    #[test]
    fn workers_run_with_a_path_that_holds_each_resolved_directory_once() {
        // npm's `codex` is `#!/usr/bin/env node`, and a follow-up worker runs `gh` itself, so
        // the workers need a PATH; the resolved `node` comes first so `env` finds that one.
        let job = Job::new("capsohq/tokun-cn", &home()).unwrap();
        let fnm = "/Users/example/.local/share/fnm/node-versions/v24.15.0/installation/bin";
        let expected = format!("{fnm}:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin");
        assert_eq!(job_path(&tools()), expected);
        let xml = plist(&job, &tools(), &opts());
        assert!(xml.contains(&format!(
            "<key>EnvironmentVariables</key>\n  <dict>\n    <key>PATH</key>\n    <string>{expected}</string>"
        )));
        let mut system = tools();
        system.node = "/usr/bin/node".into();
        assert_eq!(
            job_path(&system),
            "/usr/bin:/opt/homebrew/bin:/bin:/usr/sbin:/sbin"
        );
    }

    #[test]
    #[ignore = "needs an authenticated gh on PATH; run with --ignored"]
    fn a_repository_the_github_credentials_cannot_read_is_refused() {
        check_repo("gh", "txehq/txe-workflow").unwrap();
        let err = check_repo("gh", "txehq/this-repository-does-not-exist").unwrap_err();
        assert_eq!(err.kind, "REVIEW-PR-REPO-UNREACHABLE");
    }

    #[test]
    fn the_script_path_goes_through_the_active_symlink() {
        // A generation directory is versioned and is replaced by an update. Pointing the
        // supervisor at `active` is what keeps a monitor running across `wf` updates.
        let job = Job::new("capsohq/tokun-cn", &home()).unwrap();
        let xml = plist(&job, &tools(), &opts());
        assert!(xml.contains("/active/bundle/skills/review-pr/scripts/review_monitor.py"));
    }

    #[test]
    fn the_review_pass_is_pinned_to_high_reasoning_effort() {
        let job = Job::new("capsohq/tokun-cn", &home()).unwrap();
        let xml = plist(&job, &tools(), &opts());
        let i = xml.find("--review-effort").expect("flag present");
        assert!(
            xml[i..].contains("<string>high</string>"),
            "every review runs at high reasoning effort"
        );
    }

    #[test]
    fn every_flag_the_plist_passes_is_one_the_detector_accepts() {
        // The plist and the Python argument parser are two files that must agree. When they
        // drift, launchd reports a job that exits immediately and nothing says which flag.
        let job = Job::new("capsohq/tokun-cn", &home()).unwrap();
        let xml = plist(&job, &tools(), &opts());
        let script = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../skills/review-pr/scripts/review_monitor.py");
        let src = std::fs::read_to_string(&script).expect("the detector ships with the skill");
        // Arguments before the script path belong to `uv run`.
        let script_line = format!("<string>{}</string>", opts().script.display());
        let detector_args = xml
            .split_once(&script_line)
            .expect("the plist names the script")
            .1;
        for line in detector_args.lines() {
            let t = line.trim();
            let Some(flag) = t
                .strip_prefix("<string>--")
                .and_then(|r| r.strip_suffix("</string>"))
            else {
                continue;
            };
            let declared = format!("add_argument(\"--{flag}\"");
            assert!(
                src.contains(&declared),
                "plist passes --{flag}, which review_monitor.py does not declare"
            );
        }
    }

    #[test]
    fn xml_special_characters_cannot_break_out_of_the_document() {
        let job = Job::new("capsohq/tokun-cn", &home()).unwrap();
        let mut o = opts();
        o.review_model = "evil</string><key>RunAtLoad</key><false/><string>".into();
        let xml = plist(&job, &tools(), &o);
        assert!(!xml.contains("<false/>"));
        assert!(xml.contains("&lt;/string&gt;"));
    }

    #[test]
    fn uninstall_finds_the_reviewers_still_running_and_nothing_else() {
        let dir = tempfile::tempdir().unwrap();
        // A state directory that was never used has no workers and is not an error.
        assert_eq!(running_workers(dir.path()).unwrap(), Vec::<i32>::new());

        let conn = rusqlite::Connection::open(dir.path().join("monitor.sqlite3")).unwrap();
        conn.execute_batch(
            "CREATE TABLE jobs(job_id TEXT PRIMARY KEY, status TEXT NOT NULL, pid INTEGER);
             INSERT INTO jobs VALUES('a','running',4242);
             INSERT INTO jobs VALUES('b','running',NULL);
             INSERT INTO jobs VALUES('c','completed',99);
             INSERT INTO jobs VALUES('d','circuit_open',98);",
        )
        .unwrap();
        assert_eq!(running_workers(dir.path()).unwrap(), vec![4242]);
    }

    #[cfg(unix)]
    #[test]
    fn stopping_a_worker_ends_the_process_it_leads() {
        use std::os::unix::process::CommandExt;
        // A worker leads its own group, and the reviewer it spawned is in that group: the
        // signal has to reach both, which is why this is `killpg` and not `kill`.
        let mut child = std::process::Command::new("/bin/sh")
            .args(["-c", "sleep 120 & sleep 120"])
            .process_group(0)
            .spawn()
            .unwrap();
        let group = child.id() as i32;
        assert!(stop_worker(group));
        assert!(!child.wait().unwrap().success());
        // Reaping the shell does not reap the `sleep` it backgrounded: that one is orphaned and
        // stays in the group until init collects it, so the group empties a moment after the
        // signal rather than with it. Waiting for that is the assertion; asserting it on the
        // next line is a race that a loaded runner loses.
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(10);
        while stop_worker(group) {
            assert!(
                std::time::Instant::now() < deadline,
                "the group is still there"
            );
            std::thread::sleep(std::time::Duration::from_millis(20));
        }
    }
}
