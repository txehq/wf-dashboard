//! The transaction: back up, apply, verify, and on any failure put everything back.
//!
//! The invariant is stated once and enforced here: **there is no half-applied generation**.
//! Either every required object reached its target and verified, or the machine is byte-for
//! byte where it started. Nothing in the adapters is allowed to write to a user's file
//! except through a step registered on one of these.

use crate::backup::{Backup, Store};
use crate::db::Db;
use serde::Serialize;
use std::path::{Path, PathBuf};
use wf_core::{Error, Result};

/// What one step did, kept so it can be undone in reverse.
enum Undo {
    /// Restore a file from a backup (or delete it, when the backup records an absence) — if
    /// it still holds `written`, the bytes this transaction left there ("" for none).
    RestoreFile { backup: Backup, written: String },
    /// Delete a file this transaction created — if it still holds `written`.
    RemoveCreated { path: PathBuf, written: String },
    /// Remove a directory tree we created.
    RemoveDir { path: PathBuf },
    /// Run a caller-registered compensation — used by adapters that drive a native manager
    /// and must call its own disable/enable to undo, not touch its files.
    Native { component: String, note: String },
    NativeRestore {
        component: String,
        restore: Box<dyn Fn() -> Result<()>>,
    },
    Symlink {
        path: PathBuf,
        before: Option<PathBuf>,
    },
}

/// A managed-resource row this transaction will publish when it commits.
enum ResourceOp {
    Upsert(crate::ManagedResource),
    Delete {
        agent: String,
        kind: String,
        id: String,
    },
}

#[derive(Debug, Clone, Serialize)]
pub struct TxOutcome {
    pub transaction_id: String,
    pub applied: Vec<String>,
    pub backups: Vec<String>,
    pub rolled_back: bool,
    /// Native compensations we could not run. Empty is the normal case; anything here is
    /// reported loudly, because it is the one place a rollback can be incomplete.
    pub manual_followups: Vec<String>,
}

pub struct Transaction<'a> {
    id: String,
    db: &'a Db,
    store: Store<'a>,
    undo: Vec<Undo>,
    applied: Vec<String>,
    backups: Vec<String>,
    release_version: String,
    dry_run: bool,
    finished: bool,
    receipts: Vec<crate::OwnershipReceipt>,
    native_receipts: Vec<crate::NativeReceipt>,
    forgotten_native: Vec<crate::NativeReceipt>,
    resources: Vec<ResourceOp>,
    /// The plan, recorded whether or not it is executed, so `--dry-run` prints exactly what
    /// a real run would do rather than a separate description of it.
    pub plan: Vec<PlanStep>,
    pub warnings: Vec<String>,
}

#[derive(Debug, Clone, Serialize)]
pub struct PlanStep {
    pub component_id: String,
    pub action: String,
    pub path: String,
    pub detail: String,
}

impl<'a> Transaction<'a> {
    pub fn begin(db: &'a Db, backup_root: PathBuf, release_version: &str, dry_run: bool) -> Self {
        static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
        let id = format!(
            "{}-{}-{}",
            wf_core::time_fmt::now_unix(),
            std::process::id(),
            NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
        );
        Self {
            id,
            db,
            store: Store::new(db, backup_root),
            undo: Vec::new(),
            applied: Vec::new(),
            backups: Vec::new(),
            release_version: release_version.to_string(),
            dry_run,
            finished: false,
            receipts: vec![],
            native_receipts: vec![],
            forgotten_native: vec![],
            resources: vec![],
            plan: Vec::new(),
            warnings: Vec::new(),
        }
    }

    pub fn id(&self) -> &str {
        &self.id
    }

    pub fn is_dry_run(&self) -> bool {
        self.dry_run
    }

    /// Write a file as part of this transaction: back up what is there, write, record a
    /// receipt. `object_id` names the part of the file we own — a managed block id, an MCP
    /// server key — or is empty when we own the file outright.
    pub fn write_file(
        &mut self,
        component_id: &str,
        object_id: &str,
        path: &Path,
        contents: &[u8],
    ) -> Result<bool> {
        wf_core::paths::refuse_symlink(path)?;
        let before = if path.is_file() {
            wf_core::hash::sha256_file(path)?
        } else {
            String::new()
        };
        let after = wf_core::hash::sha256_bytes(contents);
        if before == after {
            return Ok(false); // Nothing to do; do not touch mtime or write a receipt.
        }

        self.plan.push(PlanStep {
            component_id: component_id.to_string(),
            action: if before.is_empty() {
                "create"
            } else {
                "replace"
            }
            .into(),
            path: path.to_string_lossy().into_owned(),
            detail: if before.is_empty() {
                String::new()
            } else {
                format!("{}→{}", &before[..8], &after[..8])
            },
        });
        if self.dry_run {
            return Ok(true);
        }

        // Only an overwrite has something to back up; undoing a creation is a deletion.
        let backup = if before.is_empty() {
            self.undo.push(Undo::RemoveCreated {
                path: path.to_path_buf(),
                written: after.clone(),
            });
            None
        } else {
            let backup = self.store.capture(&self.id, path)?;
            self.backups.push(backup.backup_id.clone());
            self.undo.push(Undo::RestoreFile {
                backup: backup.clone(),
                written: after.clone(),
            });
            Some(backup)
        };

        wf_core::atomic::write_file(path, contents).map_err(|e| {
            let zh = if e.zh.is_empty() {
                wf_core::zh::not_writable(&path.to_string_lossy())
            } else {
                e.zh.clone()
            };
            Error::new(e.code, e.kind.clone(), e.message.clone()).with_zh(zh)
        })?;

        if let Some(backup) = &backup {
            std::fs::set_permissions(path, std::fs::metadata(&backup.backup_path)?.permissions())?;
        }
        self.receipts.push(crate::db::OwnershipReceipt {
            id: 0,
            path: path.to_string_lossy().into_owned(),
            object_id: object_id.to_string(),
            component_id: component_id.to_string(),
            before_sha256: before,
            after_sha256: after,
            release_version: self.release_version.clone(),
            backup_id: backup.map(|b| b.backup_id),
            at: wf_core::time_fmt::now_unix(),
        });
        self.applied.push(component_id.to_string());
        Ok(true)
    }

    /// Register a directory this transaction created, so a rollback removes it.
    pub fn created_dir(&mut self, path: &Path) {
        if !self.dry_run {
            self.undo.push(Undo::RemoveDir {
                path: path.to_path_buf(),
            });
        }
    }

    /// Register a compensation for something a native manager did.
    ///
    /// This records what a rollback cannot do by itself — we do not undo an agent's own
    /// cache by hand — and nothing else. In particular it does **not** mark the component
    /// as applied: whether the machine actually changed is a question only a re-read can
    /// answer, and conflating the two made `wf repair` report the same repair on every run
    /// forever against an agent whose CLI exits 0 without doing anything.
    pub fn native_step(&mut self, component_id: &str, note: &str) {
        if !self.dry_run {
            self.undo.push(Undo::Native {
                component: component_id.to_string(),
                note: note.to_string(),
            });
        }
    }

    pub fn native_restore(&mut self, component: &str, restore: impl Fn() -> Result<()> + 'static) {
        if !self.dry_run {
            self.undo.push(Undo::NativeRestore {
                component: component.into(),
                restore: Box::new(restore),
            });
        }
    }

    pub fn owns_native(
        &self,
        agent: &str,
        config_root: &str,
        kind: crate::NativeObject,
        identity: &str,
    ) -> Result<bool> {
        let root = crate::db::native_root(config_root)?;
        Ok(self
            .native_receipts
            .iter()
            .chain(self.db.native_receipts()?.iter())
            .any(|r| {
                r.agent == agent
                    && r.kind == kind
                    && r.identity == identity
                    && crate::db::native_root(&r.config_root).is_ok_and(|path| path == root)
            }))
    }

    pub fn record_native(&mut self, receipt: crate::NativeReceipt) {
        if !self.dry_run {
            self.native_receipts.push(receipt);
        }
    }

    /// Record that a native object wf owned was removed through its manager. Published at
    /// commit, so a rollback that restores the object keeps its receipt too.
    pub fn forget_native(&mut self, receipt: crate::NativeReceipt) {
        if !self.dry_run {
            self.forgotten_native.push(receipt);
        }
    }

    /// Record that this transaction deployed an object wf now owns. Published at commit.
    pub fn record_resource(&mut self, resource: crate::ManagedResource) {
        if !self.dry_run {
            self.resources.push(ResourceOp::Upsert(resource));
        }
    }

    /// Record that this transaction removed an object wf owned. Published at commit.
    pub fn forget_resource(&mut self, agent: &str, kind: &str, id: &str) {
        if !self.dry_run {
            self.resources.push(ResourceOp::Delete {
                agent: agent.into(),
                kind: kind.into(),
                id: id.into(),
            });
        }
    }

    /// Ownership as this transaction sees it: its own pending rows over the database's.
    pub fn managed_resource(
        &self,
        agent: &str,
        kind: &str,
        id: &str,
    ) -> Result<Option<crate::ManagedResource>> {
        for op in self.resources.iter().rev() {
            match op {
                ResourceOp::Upsert(r)
                    if r.agent_id == agent && r.resource_kind == kind && r.resource_id == id =>
                {
                    return Ok(Some(r.clone()));
                }
                ResourceOp::Delete {
                    agent: a,
                    kind: k,
                    id: i,
                } if a == agent && k == kind && i == id => return Ok(None),
                _ => {}
            }
        }
        self.db.managed_resource(agent, kind, id)
    }

    /// Everything this transaction sees `agent` owning: its pending rows over the database's.
    pub fn managed_resources(&self, agent: &str) -> Result<Vec<crate::ManagedResource>> {
        let mut rows = self.db.managed_resources(Some(agent))?;
        for op in &self.resources {
            match op {
                ResourceOp::Upsert(r) if r.agent_id == agent => {
                    rows.retain(|x| {
                        !(x.resource_kind == r.resource_kind && x.resource_id == r.resource_id)
                    });
                    rows.push(r.clone());
                }
                ResourceOp::Delete { agent: a, kind, id } if a == agent => {
                    rows.retain(|x| !(&x.resource_kind == kind && &x.resource_id == id));
                }
                _ => {}
            }
        }
        Ok(rows)
    }

    /// The database this transaction publishes into, for reads.
    pub fn db(&self) -> &Db {
        self.db
    }

    /// Called inside commit_with after uninstall's file and native changes verified.
    /// Cleanup writes must not re-create the ownership rows being retired.
    pub fn clear_installation(&mut self) -> Result<()> {
        self.db.clear_installation()?;
        self.receipts.clear();
        self.native_receipts.clear();
        self.forgotten_native.clear();
        self.resources.clear();
        Ok(())
    }

    pub fn ensure_directory(&mut self, path: &Path) -> Result<()> {
        if !path.exists() && !self.dry_run {
            std::fs::create_dir_all(path)?;
            self.created_dir(path);
        }
        Ok(())
    }

    pub fn remove_file(&mut self, component: &str, path: &Path) -> Result<()> {
        wf_core::paths::refuse_symlink(path)?;
        self.note_plan(component, "remove", &path.to_string_lossy(), "");
        if self.dry_run || !path.exists() {
            return Ok(());
        }
        let backup = self.store.capture(&self.id, path)?;
        self.backups.push(backup.backup_id.clone());
        self.undo.push(Undo::RestoreFile {
            backup,
            written: String::new(),
        });
        std::fs::remove_file(path)?;
        Ok(())
    }

    pub fn swap_symlink(&mut self, path: &Path, target: Option<&Path>) -> Result<()> {
        if self.dry_run {
            return Ok(());
        }
        let before = match std::fs::symlink_metadata(path) {
            Ok(meta) if meta.file_type().is_symlink() => Some(std::fs::read_link(path)?),
            Ok(_) => {
                return Err(Error::conflict(
                    "ACTIVE-NOT-LINK",
                    format!("{} is not a symlink", path.display()),
                ))
            }
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => None,
            Err(e) => return Err(e.into()),
        };
        self.undo.push(Undo::Symlink {
            path: path.to_path_buf(),
            before,
        });
        if let Some(target) = target {
            wf_core::atomic::swap_symlink(path, target)?;
        } else if path.symlink_metadata().is_ok() {
            std::fs::remove_file(path)?;
        }
        Ok(())
    }

    pub fn note_plan(&mut self, component_id: &str, action: &str, path: &str, detail: &str) {
        self.plan.push(PlanStep {
            component_id: component_id.to_string(),
            action: action.to_string(),
            path: path.to_string(),
            detail: detail.to_string(),
        });
    }

    /// Commit. Nothing further can be undone after this.
    pub fn commit(self) -> Result<TxOutcome> {
        self.commit_with(|_| Ok(()))
    }

    /// Keep file and native undo live until publication and every ownership row commit.
    pub fn commit_with(
        mut self,
        publish: impl FnOnce(&mut Self) -> Result<()>,
    ) -> Result<TxOutcome> {
        if !self.dry_run {
            self.db
                .conn()
                .execute_batch("SAVEPOINT wf_commit")
                .map_err(crate::db::sql)?;
            let result = (|| -> Result<()> {
                publish(&mut self)?;
                for receipt in &self.receipts {
                    self.db.add_receipt(receipt)?;
                }
                for receipt in &self.native_receipts {
                    self.db.record_native(receipt)?;
                }
                for receipt in &self.forgotten_native {
                    self.db.delete_native(receipt)?;
                }
                for op in &self.resources {
                    match op {
                        ResourceOp::Upsert(resource) => {
                            self.db.upsert_managed_resource(resource)?
                        }
                        ResourceOp::Delete { agent, kind, id } => {
                            self.db.delete_managed_resource(agent, kind, id)?
                        }
                    }
                }
                self.db
                    .conn()
                    .execute_batch("RELEASE wf_commit")
                    .map_err(crate::db::sql)?;
                Ok(())
            })();
            if let Err(mut error) = result {
                let _ = self
                    .db
                    .conn()
                    .execute_batch("ROLLBACK TO wf_commit; RELEASE wf_commit");
                let followups = self.undo_all();
                self.finished = true;
                if !followups.is_empty() {
                    error
                        .message
                        .push_str(&format!("; rollback incomplete: {}", followups.join("; ")));
                    error.zh.clear();
                }
                return Err(error);
            }
        }
        self.finished = true;
        Ok(TxOutcome {
            transaction_id: self.id.clone(),
            applied: dedup(std::mem::take(&mut self.applied)),
            backups: std::mem::take(&mut self.backups),
            rolled_back: false,
            manual_followups: vec![],
        })
    }

    /// Undo everything, newest first.
    ///
    /// Rollback is best-effort per step and total in intent: one step that cannot be undone
    /// does not stop the rest from being undone, and it is reported rather than swallowed.
    pub fn rollback(mut self) -> TxOutcome {
        let followups = self.undo_all();
        self.finished = true;
        TxOutcome {
            transaction_id: self.id.clone(),
            applied: vec![],
            backups: std::mem::take(&mut self.backups),
            rolled_back: true,
            manual_followups: followups,
        }
    }

    fn undo_all(&mut self) -> Vec<String> {
        let mut followups = Vec::new();
        for step in self.undo.iter().rev() {
            match step {
                Undo::RestoreFile { backup, written } => {
                    let now = content_hash(Path::new(&backup.original_path));
                    if now == backup.sha256 {
                        // The write never happened, or was already undone.
                    } else if now != *written {
                        followups.push(format!(
                            "{}: changed since wf wrote it, so the rollback left it as it is; `wf backup restore {}` has the earlier copy",
                            backup.original_path, backup.backup_id
                        ));
                    } else if let Err(e) = restore_raw(backup) {
                        followups.push(format!(
                            "{}: could not be restored ({}); `wf backup restore {}`",
                            backup.original_path, e, backup.backup_id
                        ));
                    }
                }
                Undo::RemoveCreated { path, written } => {
                    let now = content_hash(path);
                    if now.is_empty() {
                        // Never written, or already gone.
                    } else if now != *written {
                        followups.push(format!(
                            "{}: changed since wf created it, so the rollback left it in place",
                            path.display()
                        ));
                    } else if let Err(e) = std::fs::remove_file(path) {
                        if e.kind() != std::io::ErrorKind::NotFound {
                            followups
                                .push(format!("{}: could not be removed ({e})", path.display()));
                        }
                    }
                }
                Undo::RemoveDir { path } => {
                    // A native agent may have created unrelated state here concurrently.
                    // Only an empty directory still belongs entirely to this transaction.
                    let _ = std::fs::remove_dir(path);
                }
                Undo::Native { component, note } => {
                    followups.push(format!("{component}: {note}"));
                }
                Undo::NativeRestore { component, restore } => {
                    if let Err(e) = restore() {
                        followups.push(format!("{component}: {e}"));
                    }
                }
                Undo::Symlink { path, before } => {
                    let restored = match before {
                        Some(target) => wf_core::atomic::swap_symlink(path, target),
                        None => match std::fs::remove_file(path) {
                            Ok(()) => Ok(()),
                            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(()),
                            Err(e) => Err(e.into()),
                        },
                    };
                    if let Err(e) = restored {
                        followups.push(format!("{}: {e}", path.display()));
                    }
                }
            }
        }
        self.undo.clear();
        followups
    }
}

impl Drop for Transaction<'_> {
    fn drop(&mut self) {
        if !self.finished {
            let _ = self.undo_all();
        }
    }
}

/// What `path` holds now, as a rollback compares it: the SHA-256 of a regular file, "" for
/// nothing there, and a value no write produces for anything else. A rollback only replaces
/// bytes that are still the ones its transaction wrote; anything else is a newer change.
fn content_hash(path: &Path) -> String {
    match std::fs::symlink_metadata(path) {
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => String::new(),
        Ok(meta) if meta.is_file() => {
            wf_core::hash::sha256_file(path).unwrap_or_else(|_| "unreadable".into())
        }
        _ => "not a regular file".into(),
    }
}

/// Restore without recording a counter-backup. Used only inside a rollback, where the
/// current bytes are the ones this transaction just wrote and are not worth keeping.
fn restore_raw(b: &Backup) -> Result<()> {
    let target = PathBuf::from(&b.original_path);
    if b.sha256.is_empty() {
        return match std::fs::remove_file(&target) {
            Ok(()) => Ok(()),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(()),
            Err(e) => Err(e.into()),
        };
    }
    let bytes = std::fs::read(&b.backup_path)?;
    if wf_core::hash::sha256_bytes(&bytes) != b.sha256 {
        return Err(Error::integrity("BACKUP-CORRUPT", b.backup_path.clone()));
    }
    wf_core::atomic::write_file(&target, &bytes)?;
    std::fs::set_permissions(&target, std::fs::metadata(&b.backup_path)?.permissions())?;
    Ok(())
}

fn dedup(mut v: Vec<String>) -> Vec<String> {
    v.sort();
    v.dedup();
    v
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn managed_symlinks_are_refused_without_changing_the_link_or_target() {
        let (dir, db) = fixture();
        let target = dir.path().join("personal");
        let path = dir.path().join("CLAUDE.md");
        std::fs::write(&target, "personal").unwrap();
        std::os::unix::fs::symlink("personal", &path).unwrap();
        let mut tx = Transaction::begin(&db, dir.path().join("backups"), "1", false);
        assert!(tx
            .write_file("prompt", "block", &path, b"replacement")
            .is_err());
        assert!(tx.remove_file("prompt", &path).is_err());
        tx.rollback();
        assert_eq!(std::fs::read_link(&path).unwrap(), Path::new("personal"));
        assert_eq!(std::fs::read_to_string(&target).unwrap(), "personal");
    }

    #[test]
    fn native_receipts_retain_independent_configuration_roots() {
        let (dir, db) = fixture();
        for root in ["a", "b"] {
            db.record_native(&crate::NativeReceipt {
                agent: "codex".into(),
                kind: crate::NativeObject::Plugin,
                identity: "magi@capsohq".into(),
                binary: "codex".into(),
                config_root: dir.path().join(root).to_string_lossy().into(),
                source: "source".into(),
                version: "1".into(),
            })
            .unwrap();
        }
        assert_eq!(db.native_receipts().unwrap().len(), 2);
        let tx = Transaction::begin(&db, dir.path().join("backups"), "1", true);
        assert!(tx
            .owns_native(
                "codex",
                dir.path().join("a").to_str().unwrap(),
                crate::NativeObject::Plugin,
                "magi@capsohq"
            )
            .unwrap());
        assert!(!tx
            .owns_native(
                "codex",
                dir.path().join("foreign").to_str().unwrap(),
                crate::NativeObject::Plugin,
                "magi@capsohq"
            )
            .unwrap());
    }

    fn fixture() -> (tempfile::TempDir, Db) {
        (tempfile::tempdir().unwrap(), Db::open_memory().unwrap())
    }

    #[test]
    fn rolled_back_writes_leave_no_ownership() {
        let (dir, db) = fixture();
        let path = dir.path().join("owned");
        let mut tx = Transaction::begin(&db, dir.path().join("backups"), "1.0.0", false);
        tx.write_file("fixture", "", &path, b"new").unwrap();
        tx.rollback();
        assert!(db.receipts().unwrap().is_empty());
        assert!(!db.owns(path.to_str().unwrap(), "").unwrap());
    }

    #[test]
    fn publication_failure_reverts_database_files_and_native_operations() {
        let (dir, db) = fixture();
        let path = dir.path().join("config");
        std::fs::write(&path, "old").unwrap();
        let native = std::rc::Rc::new(std::cell::Cell::new(false));
        let mut tx = Transaction::begin(&db, dir.path().join("backups"), "1.0.0", false);
        let undo = native.clone();
        tx.native_restore("native", move || {
            undo.set(false);
            Ok(())
        });
        native.set(true);
        tx.write_file("config", "", &path, b"new").unwrap();
        let result = tx.commit_with(|_| {
            db.set_meta("publication", "new")?;
            Err(Error::failure("INJECTED", "publication failed"))
        });
        assert!(result.is_err());
        assert_eq!(std::fs::read_to_string(&path).unwrap(), "old");
        assert!(!native.get());
        assert!(db.meta("publication").unwrap().is_none());
        assert!(db.receipts().unwrap().is_empty());
    }

    #[test]
    fn dropping_an_uncommitted_transaction_restores_executable_bytes_and_mode() {
        use std::os::unix::fs::PermissionsExt;
        let (dir, db) = fixture();
        let path = dir.path().join("binary");
        std::fs::write(&path, b"old").unwrap();
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o755)).unwrap();
        {
            let mut tx = Transaction::begin(&db, dir.path().join("backups"), "1.0.0", false);
            tx.write_file("binary", "", &path, b"new").unwrap();
        }
        assert_eq!(std::fs::read(&path).unwrap(), b"old");
        assert_eq!(
            std::fs::metadata(&path).unwrap().permissions().mode() & 0o777,
            0o755
        );
        assert!(db.receipts().unwrap().is_empty());
    }

    #[test]
    fn a_failure_halfway_leaves_the_machine_exactly_as_it_was() {
        let (d, db) = fixture();
        let a = d.path().join("a");
        let b = d.path().join("b");
        std::fs::write(&a, "original a").unwrap();
        std::fs::write(&b, "original b").unwrap();

        let mut tx = Transaction::begin(&db, d.path().join("backups"), "1.0.0", false);
        tx.write_file("c1", "", &a, b"new a").unwrap();
        tx.write_file("c2", "", &b, b"new b").unwrap();
        // Third step fails; everything unwinds.
        let out = tx.rollback();

        assert!(out.rolled_back);
        assert_eq!(std::fs::read_to_string(&a).unwrap(), "original a");
        assert_eq!(std::fs::read_to_string(&b).unwrap(), "original b");
        assert!(out.manual_followups.is_empty());
    }

    #[test]
    fn a_file_created_by_a_rolled_back_transaction_is_removed() {
        let (d, db) = fixture();
        let f = d.path().join("brand-new");
        let mut tx = Transaction::begin(&db, d.path().join("backups"), "1.0.0", false);
        tx.write_file("c1", "", &f, b"content").unwrap();
        assert!(f.exists());
        tx.rollback();
        assert!(
            !f.exists(),
            "rollback must not leave a file the transaction invented"
        );
    }

    /// An agent rewrites its own files while an apply runs — Claude Code keeps counters in
    /// `.claude.json`. A rollback puts back only bytes that are still what wf wrote; anything
    /// else is somebody's newer change, kept and reported, never silently reverted.
    #[test]
    fn a_rollback_leaves_a_file_that_changed_after_wf_wrote_it() {
        let (d, db) = fixture();
        let existing = d.path().join(".claude.json");
        let created = d.path().join("created.json");
        std::fs::write(&existing, "before").unwrap();
        let mut tx = Transaction::begin(&db, d.path().join("backups"), "1.0.0", false);
        tx.write_file("c1", "k", &existing, b"ours").unwrap();
        tx.write_file("c1", "k", &created, b"ours").unwrap();
        std::fs::write(&existing, "ours, then the agent's").unwrap();
        std::fs::write(&created, "ours, then the agent's").unwrap();
        let out = tx.rollback();
        assert_eq!(
            std::fs::read_to_string(&existing).unwrap(),
            "ours, then the agent's"
        );
        assert_eq!(
            std::fs::read_to_string(&created).unwrap(),
            "ours, then the agent's"
        );
        assert_eq!(out.manual_followups.len(), 2, "{:?}", out.manual_followups);
        assert!(
            out.manual_followups[0].contains("changed since"),
            "{:?}",
            out.manual_followups
        );
    }

    /// Creating a file is not an overwrite: there is nothing to back up, and undoing it is
    /// deleting it. No backup record, which is also what keeps a first apply of a thousand
    /// skill files from paying a database write apiece.
    /// A write that failed leaves nothing to undo, and says nothing about a later change.
    #[test]
    fn a_rollback_after_a_failed_write_reports_nothing() {
        let (d, db) = fixture();
        let existing = d.path().join("kept.md");
        std::fs::write(&existing, "before").unwrap();
        let mut tx = Transaction::begin(&db, d.path().join("backups"), "1.0.0", false);
        let blocked = d.path().join("no-such-dir/new.md");
        std::fs::write(
            d.path().join("no-such-dir"),
            "a file where a directory must be",
        )
        .unwrap();
        assert!(tx.write_file("c1", "", &blocked, b"x").is_err());
        let out = tx.rollback();
        assert!(
            out.manual_followups.is_empty(),
            "{:?}",
            out.manual_followups
        );
        assert_eq!(std::fs::read_to_string(&existing).unwrap(), "before");
    }

    #[test]
    fn creating_a_file_records_no_backup() {
        let (d, db) = fixture();
        let f = d.path().join("new.md");
        let mut tx = Transaction::begin(&db, d.path().join("backups"), "1.0.0", false);
        assert!(tx.write_file("c1", "", &f, b"content").unwrap());
        let out = tx.commit().unwrap();
        assert!(out.backups.is_empty(), "{:?}", out.backups);
        let receipts = db.receipts().unwrap();
        assert_eq!(receipts.len(), 1);
        assert!(receipts[0].before_sha256.is_empty());
        assert!(receipts[0].backup_id.is_none());
    }

    #[test]
    fn writing_identical_content_is_not_a_write() {
        let (d, db) = fixture();
        let f = d.path().join("f");
        std::fs::write(&f, "same").unwrap();
        let mut tx = Transaction::begin(&db, d.path().join("backups"), "1.0.0", false);
        assert!(!tx.write_file("c1", "", &f, b"same").unwrap());
        let out = tx.commit().unwrap();
        assert!(
            out.backups.is_empty(),
            "an unchanged file needs no backup and no receipt"
        );
        assert!(db.receipts().unwrap().is_empty());
    }

    #[test]
    fn a_dry_run_plans_everything_and_writes_nothing() {
        let (d, db) = fixture();
        let f = d.path().join("f");
        std::fs::write(&f, "before").unwrap();
        let mut tx = Transaction::begin(&db, d.path().join("backups"), "1.0.0", true);
        assert!(
            tx.write_file("c1", "", &f, b"after").unwrap(),
            "a dry run still reports the change"
        );
        assert_eq!(tx.plan.len(), 1);
        assert_eq!(tx.plan[0].action, "replace");
        tx.commit().unwrap();
        assert_eq!(std::fs::read_to_string(&f).unwrap(), "before");
        assert!(db.receipts().unwrap().is_empty());
    }

    #[test]
    fn every_overwrite_leaves_a_receipt_naming_its_backup() {
        let (d, db) = fixture();
        let f = d.path().join("CLAUDE.md");
        std::fs::write(&f, "user text").unwrap();
        let mut tx = Transaction::begin(&db, d.path().join("backups"), "1.0.0", false);
        tx.write_file("capso.prompt.global", "capso.global", &f, b"ours")
            .unwrap();
        tx.commit().unwrap();

        let receipts = db.receipts().unwrap();
        assert_eq!(receipts.len(), 1);
        let r = &receipts[0];
        assert_eq!(r.object_id, "capso.global");
        assert!(r.backup_id.is_some(), "no overwrite without a backup id");
        assert_eq!(r.release_version, "1.0.0");
    }

    #[test]
    fn a_native_step_that_cannot_be_undone_is_reported_not_swallowed() {
        let (d, db) = fixture();
        let mut tx = Transaction::begin(&db, d.path().join("backups"), "1.0.0", false);
        tx.native_step("capso.plugin", "re-enable magi in Claude Code");
        let out = tx.rollback();
        assert_eq!(out.manual_followups.len(), 1);
        assert!(out.manual_followups[0].contains("re-enable"));
    }

    #[test]
    fn a_forgotten_native_receipt_goes_only_when_the_transaction_commits() {
        let (dir, db) = fixture();
        let receipt = crate::NativeReceipt {
            agent: "claude-code".into(),
            kind: crate::NativeObject::Plugin,
            identity: "magi@capsohq".into(),
            binary: "claude".into(),
            config_root: dir.path().join("claude").to_string_lossy().into(),
            source: "source".into(),
            version: "1.7.0".into(),
        };
        db.record_native(&receipt).unwrap();
        for dry_run in [true, false] {
            let mut tx = Transaction::begin(&db, dir.path().join("backups"), "2.0.0", dry_run);
            tx.forget_native(receipt.clone());
            if dry_run {
                tx.commit().unwrap();
            } else {
                tx.rollback();
            }
            assert_eq!(db.native_receipts().unwrap().len(), 1);
        }
        let mut tx = Transaction::begin(&db, dir.path().join("backups"), "2.0.0", false);
        tx.forget_native(receipt);
        tx.commit().unwrap();
        assert!(db.native_receipts().unwrap().is_empty());
    }

    #[test]
    fn registering_a_compensation_is_not_claiming_a_change() {
        let (d, db) = fixture();
        let mut tx = Transaction::begin(&db, d.path().join("backups"), "1.0.0", false);
        tx.native_step("capso.plugin", "uninstall the plugin");
        let out = tx.commit().unwrap();
        assert!(
            out.applied.is_empty(),
            "a compensation is not evidence the machine changed: {:?}",
            out.applied
        );
    }
}
