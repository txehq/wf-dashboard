//! Which proxy a request goes through, and what to tell the person when it fails there.
//!
//! ureq takes one proxy from the environment: the first of [`PROXY_VARS`] whose value parses
//! as a proxy URL. `NO_PROXY` / `no_proxy` exempt hosts from it. Every other proxy variable is
//! ignored, so a failure is reported against that one variable and the URL it holds, with the
//! credentials in the URL replaced by `***`.
//!
//! What the proxy did decides the advice:
//!
//! - the connection to it was refused: nothing is listening at that address;
//! - it answered and refused the destination (an HTTP status to `CONNECT`, a SOCKS reply
//!   code): it runs, and will not carry this host;
//! - it accepted the connection and closed it before the destination answered.

use std::io::ErrorKind;
use ureq::http::Uri;
use ureq::{Proxy, ProxyProtocol};

/// ureq's own order (`Proxy::try_from_env`): the first variable holding a valid proxy URL wins.
pub const PROXY_VARS: [&str; 6] = [
    "ALL_PROXY",
    "all_proxy",
    "HTTPS_PROXY",
    "https_proxy",
    "HTTP_PROXY",
    "http_proxy",
];

/// A proxy variable that holds a valid proxy URL, with that URL as it may be shown.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Candidate {
    pub var: &'static str,
    pub shown: String,
}

/// The proxy configuration every request of one publish uses.
pub struct Route {
    /// Handed to every request, so the proxy the error names is the proxy the request used.
    pub proxy: Option<Proxy>,
    /// Every proxy variable holding a valid URL, in ureq's order. The first one is `proxy`.
    candidates: Vec<Candidate>,
}

/// What the proxy did, when the failure happened at the proxy.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ProxyFailure {
    /// The TCP connection to the proxy address was refused.
    NotListening,
    /// The proxy answered and refused the destination; the answer, e.g. `HTTP 403`.
    Refused(String),
    /// The proxy accepted the connection and closed it.
    Closed,
}

/// A request error explained against the route it took.
pub struct Explanation {
    /// A `PUBLISH-PROXY-*` class when the failure happened at the proxy.
    pub kind: Option<&'static str>,
    pub en: String,
    /// Empty when no proxy was in the way.
    pub zh: String,
}

impl Route {
    pub fn from_env() -> Self {
        Self::new(Proxy::try_from_env(), |var| std::env::var(var).ok())
    }

    pub fn new(proxy: Option<Proxy>, lookup: impl Fn(&str) -> Option<String>) -> Self {
        let candidates = PROXY_VARS
            .iter()
            .filter_map(|&var| {
                let value = lookup(var)?;
                let parsed = Proxy::new(&value).ok()?;
                Some(Candidate {
                    var,
                    shown: shown_url(&parsed),
                })
            })
            .collect::<Vec<_>>();
        assert_eq!(
            proxy.is_some(),
            !candidates.is_empty(),
            "the proxy and the proxy variables were read from different environments"
        );
        Route { proxy, candidates }
    }

    /// The proxy a request to `target` goes through: none when no proxy is set or `NO_PROXY`
    /// exempts the host.
    fn through(&self, target: &Uri) -> Option<(&Proxy, &Candidate)> {
        let proxy = self.proxy.as_ref()?;
        if proxy.is_no_proxy(target) {
            return None;
        }
        Some((proxy, &self.candidates[0]))
    }

    pub fn explain(&self, target: &str, e: &ureq::Error) -> Explanation {
        let uri: Uri = target
            .parse()
            .expect("a URL wf just requested parses as a URI");
        let host = uri.host().unwrap_or(target).to_string();
        let Some((proxy, used)) = self.through(&uri) else {
            return Explanation {
                kind: None,
                en: e.to_string(),
                zh: String::new(),
            };
        };
        let (var, url) = (used.var, &used.shown);
        let (next_en, next_zh) = match self.candidates.get(1) {
            Some(next) => (
                format!("with {var} unset, wf uses {} ({})", next.var, next.shown),
                format!(
                    "取消设置 {var} 之后，wf 会改用 {} 指定的 {}。",
                    next.var, next.shown
                ),
            ),
            None => (
                format!("with {var} unset, wf connects to {host} directly"),
                format!("取消设置 {var} 之后，wf 会直接连接 {host}。"),
            ),
        };
        match classify(proxy.protocol(), e) {
            Some(ProxyFailure::NotListening) => Explanation {
                kind: Some("PUBLISH-PROXY-DOWN"),
                en: format!(
                    "nothing is listening at the proxy {url} from {var} ({e}). Start that proxy, \
                     point {var} at one that is running, or unset {var}; {next_en}"
                ),
                zh: format!(
                    "{var} 指定的代理 {url} 上没有程序在监听，连接被拒绝了。启动这个代理，\
                     或者把 {var} 改成一个正在运行的代理，或者取消设置 {var}。{next_zh}"
                ),
            },
            Some(ProxyFailure::Refused(answer)) => Explanation {
                kind: Some("PUBLISH-PROXY-REFUSED"),
                en: format!(
                    "the proxy {url} from {var} answered and refused the connection to {host}: \
                     {answer}. That proxy will not carry {host}: point {var} at a proxy that \
                     will, or unset {var}; {next_en}"
                ),
                zh: format!(
                    "{var} 指定的代理 {url} 正在运行，但拒绝转发到 {host} 的连接（{answer}）。\
                     这个代理不会转发 {host}：把 {var} 改成能转发 {host} 的代理，或者取消设置 \
                     {var}。{next_zh}"
                ),
            },
            Some(ProxyFailure::Closed) => Explanation {
                kind: Some("PUBLISH-PROXY-CLOSED"),
                en: format!(
                    "the proxy {url} from {var} accepted the connection and closed it before \
                     {host} answered ({e}). Check that the proxy carries {host}, point {var} at \
                     one that does, or unset {var}; {next_en}"
                ),
                zh: format!(
                    "{var} 指定的代理 {url} 接受了连接，但在 {host} 回答之前关闭了连接。\
                     确认这个代理能转发 {host}，或者把 {var} 改成能转发的代理，或者取消设置 \
                     {var}。{next_zh}"
                ),
            },
            None => Explanation {
                kind: None,
                en: format!("{e} (through the proxy {url} from {var})"),
                zh: format!("这次请求经过了 {var} 指定的代理 {url}。"),
            },
        }
    }
}

/// The proxy URL with any user name and password replaced by `***`: proxy URLs routinely
/// carry a password.
pub fn shown_url(proxy: &Proxy) -> String {
    let scheme = proxy.uri().scheme_str().unwrap_or("http");
    let userinfo = if proxy.username().is_some() || proxy.password().is_some() {
        "***@"
    } else {
        ""
    };
    format!("{scheme}://{userinfo}{}:{}", proxy.host(), proxy.port())
}

/// Read what the proxy did out of a request error. `None` when the error does not say the
/// proxy caused it.
///
/// With a proxy in effect every TCP connection a request opens goes to the proxy, so a refused
/// connection is a refusal by the proxy address. The rest comes from ureq's CONNECT connector
/// (`proxy server responded <status>` / `proxy server did not respond`, the latter on EOF) and
/// from the `socks` crate, which reports each SOCKS reply code as an `io::Error` of kind
/// `Other` (a refused login as `PermissionDenied`).
pub fn classify(protocol: ProxyProtocol, e: &ureq::Error) -> Option<ProxyFailure> {
    match e {
        ureq::Error::Io(io) => match io.kind() {
            ErrorKind::ConnectionRefused => Some(ProxyFailure::NotListening),
            ErrorKind::ConnectionReset
            | ErrorKind::ConnectionAborted
            | ErrorKind::UnexpectedEof
            | ErrorKind::BrokenPipe => Some(ProxyFailure::Closed),
            ErrorKind::Other | ErrorKind::PermissionDenied if is_socks(protocol) => {
                Some(ProxyFailure::Refused(format!("SOCKS reply: {io}")))
            }
            _ => None,
        },
        ureq::Error::ConnectProxyFailed(reason) => {
            if let Some(status) = reason.strip_prefix("proxy server responded ") {
                let code = status.split('/').next().unwrap_or(status);
                Some(ProxyFailure::Refused(format!("HTTP {code}")))
            } else if reason == "proxy server did not respond" {
                Some(ProxyFailure::Closed)
            } else {
                None
            }
        }
        _ => None,
    }
}

fn is_socks(protocol: ProxyProtocol) -> bool {
    matches!(
        protocol,
        ProxyProtocol::Socks4
            | ProxyProtocol::Socks4A
            | ProxyProtocol::Socks5
            | ProxyProtocol::Socks5h
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::{Read, Write};
    use std::net::{TcpListener, TcpStream};
    use std::sync::mpsc;
    use std::time::Duration;

    const TARGET: &str = "https://engapp.dev/artifacts/page/abcd1234";

    fn lookup(pairs: &[(&str, &str)]) -> impl Fn(&str) -> Option<String> {
        let owned: Vec<(String, String)> = pairs
            .iter()
            .map(|(k, v)| (k.to_string(), v.to_string()))
            .collect();
        move |var| owned.iter().find(|(k, _)| k == var).map(|(_, v)| v.clone())
    }

    /// A real proxy endpoint on a free local port that handles every connection with `serve`,
    /// and reports each connection it accepted.
    fn listener(serve: fn(TcpStream)) -> (u16, mpsc::Receiver<()>) {
        let l = TcpListener::bind("127.0.0.1:0").unwrap();
        let port = l.local_addr().unwrap().port();
        let (tx, rx) = mpsc::channel();
        std::thread::spawn(move || {
            for conn in l.incoming() {
                let _ = tx.send(());
                serve(conn.unwrap());
            }
        });
        (port, rx)
    }

    /// A local port with nothing listening on it.
    fn closed_port() -> u16 {
        let l = TcpListener::bind("127.0.0.1:0").unwrap();
        l.local_addr().unwrap().port()
    }

    fn read_request_head(conn: &mut TcpStream) {
        let mut seen = Vec::new();
        let mut byte = [0u8; 1];
        while !seen.ends_with(b"\r\n\r\n") {
            if conn.read(&mut byte).unwrap() == 0 {
                return;
            }
            seen.push(byte[0]);
        }
    }

    fn answer_403(mut conn: TcpStream) {
        read_request_head(&mut conn);
        conn.write_all(b"HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n")
            .unwrap();
    }

    fn answer_502(mut conn: TcpStream) {
        read_request_head(&mut conn);
        conn.write_all(b"HTTP/1.1 502 Bad Gateway\r\nContent-Length: 0\r\n\r\n")
            .unwrap();
    }

    fn read_then_close(mut conn: TcpStream) {
        read_request_head(&mut conn);
    }

    fn close_at_once(conn: TcpStream) {
        drop(conn);
    }

    /// SOCKS5: accept "no authentication", then answer the CONNECT with reply code 2,
    /// "connection not allowed by ruleset".
    fn socks_refuse(mut conn: TcpStream) {
        let mut head = [0u8; 2];
        conn.read_exact(&mut head).unwrap();
        let mut methods = vec![0u8; head[1] as usize];
        conn.read_exact(&mut methods).unwrap();
        conn.write_all(&[5, 0]).unwrap();
        let mut request = [0u8; 512];
        let _ = conn.read(&mut request).unwrap();
        conn.write_all(&[5, 2, 0, 1, 0, 0, 0, 0, 0, 0]).unwrap();
    }

    /// Run a real request to [`TARGET`] with this environment and explain its failure.
    fn fail_through(pairs: &[(&str, &str)]) -> Explanation {
        let vars = lookup(pairs);
        let proxy = PROXY_VARS
            .iter()
            .find_map(|v| vars(v).and_then(|value| Proxy::new(&value).ok()));
        let route = Route::new(proxy, vars);
        let e = ureq::head(TARGET)
            .config()
            .proxy(route.proxy.clone())
            .timeout_global(Some(Duration::from_secs(10)))
            .build()
            .call()
            .expect_err("the request must fail at the proxy");
        route.explain(TARGET, &e)
    }

    #[test]
    fn the_first_variable_holding_a_proxy_url_wins_in_ureqs_order() {
        let route = Route::new(
            Some(Proxy::new("socks5h://127.0.0.1:6153").unwrap()),
            lookup(&[
                ("HTTP_PROXY", "http://127.0.0.1:54589"),
                ("HTTPS_PROXY", "http://127.0.0.1:54589"),
                ("ALL_PROXY", "socks5h://127.0.0.1:6153"),
            ]),
        );
        let vars: Vec<&str> = route.candidates.iter().map(|c| c.var).collect();
        assert_eq!(vars, ["ALL_PROXY", "HTTPS_PROXY", "HTTP_PROXY"]);
        assert_eq!(route.candidates[0].shown, "socks5h://127.0.0.1:6153");

        // A value ureq cannot parse is skipped by ureq, so it is skipped here too.
        let route = Route::new(
            Some(Proxy::new("http://127.0.0.1:3128").unwrap()),
            lookup(&[
                ("ALL_PROXY", "ftp://127.0.0.1:21"),
                ("https_proxy", "127.0.0.1:3128"),
            ]),
        );
        assert_eq!(route.candidates[0].var, "https_proxy");
        assert_eq!(route.candidates[0].shown, "http://127.0.0.1:3128");
    }

    #[test]
    fn credentials_in_a_proxy_url_are_never_shown() {
        let proxy = Proxy::new("http://alice:s3cret@127.0.0.1:3128").unwrap();
        assert_eq!(shown_url(&proxy), "http://***@127.0.0.1:3128");
        let proxy = Proxy::new("socks5h://token@proxy.internal").unwrap();
        assert_eq!(shown_url(&proxy), "socks5h://***@proxy.internal:1080");
    }

    #[test]
    fn nothing_listening_at_the_proxy_says_so() {
        let port = closed_port();
        let url = format!("http://127.0.0.1:{port}");
        let x = fail_through(&[("HTTPS_PROXY", &url)]);
        assert_eq!(x.kind, Some("PUBLISH-PROXY-DOWN"), "{}", x.en);
        assert!(
            x.en.contains(&url) && x.en.contains("HTTPS_PROXY"),
            "{}",
            x.en
        );
        assert!(x.zh.contains("没有程序在监听"), "{}", x.zh);
        assert!(x.zh.contains("直接连接 engapp.dev"), "{}", x.zh);
    }

    #[test]
    fn a_proxy_that_answers_connect_with_an_error_status_refused_the_destination() {
        for (serve, code) in [(answer_403 as fn(TcpStream), "403"), (answer_502, "502")] {
            let (port, _) = listener(serve);
            let url = format!("http://127.0.0.1:{port}");
            let x = fail_through(&[("HTTPS_PROXY", &url)]);
            assert_eq!(x.kind, Some("PUBLISH-PROXY-REFUSED"), "{}", x.en);
            assert!(x.en.contains(&format!("HTTP {code}")), "{}", x.en);
            assert!(x.en.contains("will not carry engapp.dev"), "{}", x.en);
            assert!(x.zh.contains(&url) && x.zh.contains("拒绝转发"), "{}", x.zh);
            assert!(!x.zh.contains("没有程序在监听"), "{}", x.zh);
        }
    }

    #[test]
    fn the_password_of_a_refusing_proxy_stays_out_of_the_message() {
        let (port, _) = listener(answer_403);
        let x = fail_through(&[(
            "HTTPS_PROXY",
            &format!("http://alice:s3cret@127.0.0.1:{port}"),
        )]);
        assert_eq!(x.kind, Some("PUBLISH-PROXY-REFUSED"), "{}", x.en);
        for text in [&x.en, &x.zh] {
            assert!(
                !text.contains("s3cret") && !text.contains("alice"),
                "{text}"
            );
            assert!(
                text.contains(&format!("http://***@127.0.0.1:{port}")),
                "{text}"
            );
        }
    }

    #[test]
    fn a_proxy_that_accepts_and_closes_closed_the_connection() {
        for serve in [read_then_close as fn(TcpStream), close_at_once] {
            let (port, _) = listener(serve);
            let url = format!("http://127.0.0.1:{port}");
            let x = fail_through(&[("HTTPS_PROXY", &url)]);
            assert_eq!(x.kind, Some("PUBLISH-PROXY-CLOSED"), "{}", x.en);
            assert!(x.zh.contains("关闭了连接"), "{}", x.zh);
        }
    }

    #[test]
    fn a_socks_proxy_is_used_and_its_refusal_is_read() {
        let (port, _) = listener(socks_refuse);
        let x = fail_through(&[("ALL_PROXY", &format!("socks5h://127.0.0.1:{port}"))]);
        assert_eq!(x.kind, Some("PUBLISH-PROXY-REFUSED"), "{}", x.en);
        assert!(
            x.en.contains("connection not allowed by ruleset"),
            "{}",
            x.en
        );

        let port = closed_port();
        let x = fail_through(&[("ALL_PROXY", &format!("socks5h://127.0.0.1:{port}"))]);
        assert_eq!(x.kind, Some("PUBLISH-PROXY-DOWN"), "{}", x.en);
    }

    /// Issue #58: ALL_PROXY held a SOCKS proxy and HTTPS_PROXY an HTTP one, both listening.
    /// ALL_PROXY is the one ureq uses; the request must reach it, and the message must name it
    /// and say that HTTPS_PROXY takes over once it is unset.
    #[test]
    fn with_all_proxy_and_https_proxy_set_all_proxy_is_used_and_named() {
        let (socks_port, socks_seen) = listener(socks_refuse);
        let (http_port, http_seen) = listener(answer_403);
        let socks = format!("socks5h://127.0.0.1:{socks_port}");
        let http = format!("http://127.0.0.1:{http_port}");
        let x = fail_through(&[
            ("ALL_PROXY", &socks),
            ("HTTPS_PROXY", &http),
            ("HTTP_PROXY", &http),
            ("NO_PROXY", "localhost,127.0.0.1,::1"),
        ]);
        socks_seen
            .recv_timeout(Duration::from_secs(1))
            .expect("the request reached the SOCKS proxy in ALL_PROXY");
        assert!(http_seen.try_recv().is_err(), "HTTPS_PROXY was used");
        assert_eq!(x.kind, Some("PUBLISH-PROXY-REFUSED"), "{}", x.en);
        assert!(
            x.en.contains(&format!("{socks} from ALL_PROXY")),
            "{}",
            x.en
        );
        assert!(
            x.en.contains(&format!(
                "with ALL_PROXY unset, wf uses HTTPS_PROXY ({http})"
            )),
            "{}",
            x.en
        );
    }

    #[test]
    fn a_host_exempted_by_no_proxy_is_reported_without_the_proxy() {
        let proxy = Proxy::builder(ProxyProtocol::Http)
            .host("127.0.0.1")
            .port(closed_port())
            .no_proxy("engapp.dev")
            .build()
            .unwrap();
        let route = Route::new(
            Some(proxy),
            lookup(&[("HTTPS_PROXY", "http://127.0.0.1:1")]),
        );
        let e = ureq::Error::Io(std::io::Error::from(ErrorKind::ConnectionRefused));
        let x = route.explain(TARGET, &e);
        assert_eq!(x.kind, None);
        assert!(x.zh.is_empty(), "{}", x.zh);
        assert!(!x.en.contains("proxy"), "{}", x.en);
    }
}
