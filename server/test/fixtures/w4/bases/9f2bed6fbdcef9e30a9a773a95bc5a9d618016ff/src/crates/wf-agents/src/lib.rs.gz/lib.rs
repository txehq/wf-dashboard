//! `wf-agents` — the one layer through which `wf` manages a coding agent.
//!
//! Every agent `wf` can reach is data, not code: `workflow/teamai/agents.yaml` says where an
//! agent keeps its skills, rules, subagents, hooks, MCP servers, instructions and
//! environment, and which on-disk format each of those takes. Adding an agent whose formats
//! already exist is a registry edit (plus `wf agents register`); adding a new *format* is an
//! adapter in [`formats`], deliberately — guessing at an unfamiliar config file writes
//! plausible-looking garbage into somebody's agent.
//!
//! The ownership boundary is the one [WFR-015] draws. `wf` owns named objects — a skill
//! directory it deployed, one key under `mcpServers`, one hook handler, one managed prompt
//! block — and never a whole file a person also edits. Every write goes through a
//! [`wf_state::Transaction`], so it is backed up, leaves a receipt, and is undone when the
//! transaction does not commit; every object `wf` owns is a row in `managed_resources`,
//! written only when that transaction commits.
//!
//! Resources come from a [`team_repo::TeamRepo`]. In this release that is the verified
//! generation of this repository itself (self-repo mode); the Git and HTTP modes are
//! declared and refuse by name.
//!
//! [WFR-015]: ../../docs/contract/CONTRACT.md

pub mod adapter;
pub mod bridges;
#[cfg(test)]
mod budgets;
pub mod codex_rpc;
pub mod credentials;
pub mod engine;
pub mod formats;
pub mod legacy;
pub mod policy;
pub mod registry;
pub mod resources;
pub mod sessions;
pub mod team_repo;
#[cfg(test)]
pub(crate) mod testing;
pub mod usage;

pub use adapter::{
    AgentConfigPaths, AgentInstall, AgentState, ConfigAdapter, Desired, MachineAdapter,
    ObjectState, ObjectStatus, ResourceChange, TeamAIAdapter,
};
pub use policy::Policies;
pub use registry::{AgentRegistry, AgentSpec};
pub use resources::{ResourceDiff, ResourceHandler, ResourceItem, ResourceKind};
pub use team_repo::{TeamRepo, TeamRepoMode};

use serde::Serialize;

/// One thing that is not as it should be, and the sentence that fixes it.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct Finding {
    pub code: String,
    /// The registry component or team resource this is about.
    pub subject: String,
    pub message: String,
    /// The operator-facing Chinese instruction; empty when the English is enough.
    #[serde(skip_serializing_if = "String::is_empty")]
    pub zh: String,
    pub severity: Severity,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum Severity {
    /// Worth saying; nothing is broken.
    Info,
    /// A capability is degraded.
    Warn,
    /// A required object is not in place.
    Error,
}

impl Finding {
    pub fn new(
        code: impl Into<String>,
        subject: impl Into<String>,
        message: impl Into<String>,
        severity: Severity,
    ) -> Self {
        Self {
            code: code.into(),
            subject: subject.into(),
            message: message.into(),
            zh: String::new(),
            severity,
        }
    }

    pub fn with_zh(mut self, zh: impl Into<String>) -> Self {
        self.zh = zh.into();
        self
    }
}
