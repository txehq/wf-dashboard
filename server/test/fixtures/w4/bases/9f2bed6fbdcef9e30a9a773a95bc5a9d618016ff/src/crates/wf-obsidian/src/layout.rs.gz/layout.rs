use std::path::{Path, PathBuf};
use wf_core::{Error, Result};

/// What a kind of document is attached to, which is what decides where it lives.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Scope {
    /// One `/wf` run's worth of work, under `Project <P>/Features/<slug>/`.
    Feature,
    /// Standing design that outlives any one feature.
    Product,
    /// Belongs to nobody's product — incidents.
    Vault,
}

/// A document type this tool knows how to file. The set is CLOSED.
#[derive(Debug, Clone, Copy)]
pub struct Kind {
    pub name: &'static str,
    pub scope: Scope,
    /// The fixed filename for feature-scoped kinds. Product- and vault-scoped kinds take
    /// their name from `--title` or `--slug` instead.
    pub file: &'static str,
    /// The folder under the product (product scope) or the vault (vault scope).
    pub dir: &'static str,
}

pub const KINDS: &[Kind] = &[
    Kind {
        name: "brief",
        scope: Scope::Feature,
        file: "Brief.md",
        dir: "",
    },
    Kind {
        name: "research",
        scope: Scope::Feature,
        file: "Research.md",
        dir: "",
    },
    Kind {
        name: "design",
        scope: Scope::Feature,
        file: "System Design.md",
        dir: "",
    },
    Kind {
        name: "tickets",
        scope: Scope::Feature,
        file: "Tickets.md",
        dir: "",
    },
    Kind {
        name: "handover",
        scope: Scope::Feature,
        file: "Handover.md",
        dir: "",
    },
    Kind {
        name: "decision",
        scope: Scope::Product,
        file: "",
        dir: "Decisions",
    },
    Kind {
        name: "spec",
        scope: Scope::Product,
        file: "",
        dir: "Specs",
    },
    Kind {
        name: "postmortem",
        scope: Scope::Vault,
        file: "",
        dir: "Postmortems",
    },
];

pub fn kind_names() -> Vec<&'static str> {
    let mut v: Vec<&'static str> = KINDS.iter().map(|k| k.name).collect();
    v.sort_unstable();
    v
}

/// What the caller asked for, before resolution.
#[derive(Debug, Clone, Default)]
pub struct Request {
    pub vault: String,
    pub kind: String,
    pub product: String,
    pub feature: String,
    pub title: String,
    pub slug: String,
    /// YYYY-MM-DD, for vault-scoped kinds.
    pub date: String,
}

/// A resolved destination: everything the writer needs and nothing it has to guess.
#[derive(Debug, Clone)]
pub struct Target {
    pub kind: Kind,
    pub path: PathBuf,
    pub dir: PathBuf,
    /// Set for feature-scoped kinds — the folder whose index is regenerated.
    pub feature_dir: Option<PathBuf>,
}

/// Turn a request into a destination, or explain precisely what is missing.
///
/// Every failure names the field rather than the operation: "invalid arguments" sends
/// someone back to read the source.
pub fn resolve(r: &Request) -> Result<Target> {
    let Some(kind) = KINDS.iter().find(|k| k.name == r.kind).copied() else {
        return Err(Error::usage(
            "OBSIDIAN-KIND",
            format!(
                "unknown kind {:?} — known kinds are {}",
                r.kind,
                kind_names().join(", ")
            ),
        )
        .with_zh(format!(
            "不认识 `{}` 这种文档类型。可用的有：{}。",
            r.kind,
            kind_names().join("、")
        )));
    };
    if r.vault.is_empty() {
        return Err(Error::usage(
            "OBSIDIAN-VAULT",
            "no vault: set $MAGI_VAULT or pass --vault",
        )
        .with_zh(
            "还不知道 vault 在哪里。设置一下 MAGI_VAULT 环境变量，或者用 `--vault` 指定。"
                .to_string(),
        ));
    }
    if !Path::new(&r.vault).is_dir() {
        return Err(Error::usage(
            "OBSIDIAN-VAULT",
            format!(
                "vault {} does not exist — refusing to create a vault tree somewhere unexpected",
                r.vault
            ),
        )
        .with_zh(format!(
            "{} 这个目录不存在。检查一下 MAGI_VAULT 指到哪里了。",
            r.vault
        )));
    }

    match kind.scope {
        Scope::Feature => {
            need(&r.product, kind.name, "--product")?;
            need(&r.feature, kind.name, "--feature")?;
            let product_dir = product_path(&r.vault, &r.product)?;
            let dir = product_dir.join("Features").join(slugify(&r.feature));
            Ok(Target {
                kind,
                path: dir.join(kind.file),
                feature_dir: Some(dir.clone()),
                dir,
            })
        }
        Scope::Product => {
            need(&r.product, kind.name, "--product")?;
            if r.title.trim().is_empty() {
                return Err(Error::usage(
                    "OBSIDIAN-ARG",
                    format!(
                        "kind {:?} needs --title: it becomes the file name",
                        kind.name
                    ),
                )
                .with_zh(format!(
                    "`{}` 类型的文档需要 `--title`，标题会变成文件名。",
                    kind.name
                )));
            }
            let dir = product_path(&r.vault, &r.product)?.join(kind.dir);
            Ok(Target {
                kind,
                path: dir.join(title_file(&r.title)),
                dir,
                feature_dir: None,
            })
        }
        Scope::Vault => {
            need(&r.slug, kind.name, "--slug")?;
            need(&r.date, kind.name, "--date (YYYY-MM-DD)")?;
            let dir = Path::new(&r.vault).join(kind.dir);
            let name = format!("{}-{}.md", r.date, slugify(&r.slug));
            Ok(Target {
                kind,
                path: dir.join(name),
                dir,
                feature_dir: None,
            })
        }
    }
}

fn need(value: &str, kind: &str, flag: &str) -> Result<()> {
    if value.trim().is_empty() {
        return Err(
            Error::usage("OBSIDIAN-ARG", format!("kind {kind:?} needs {flag}"))
                .with_zh(format!("`{kind}` 类型的文档需要 `{flag}`。")),
        );
    }
    Ok(())
}

/// Requires the product folder to already exist. Creating it on demand would let a typo
/// mint `Project Tokun2` and file a document into a product nobody has.
fn product_path(vault: &str, product: &str) -> Result<PathBuf> {
    let name = if product.starts_with("Project ") {
        product.to_string()
    } else {
        format!("Project {product}")
    };
    let dir = Path::new(vault).join(&name);
    if !dir.is_dir() {
        let existing = existing_products(vault);
        return Err(Error::usage(
            "OBSIDIAN-PRODUCT",
            format!(
                "no product folder {name:?} in the vault — existing products are {}",
                existing.join(", ")
            ),
        )
        .with_zh(format!(
            "vault 里没有 `{name}` 这个目录。现有的是：{}。检查一下 `--product` 有没有写错。",
            if existing.is_empty() {
                "（一个都没有）".to_string()
            } else {
                existing.join("、")
            }
        )));
    }
    Ok(dir)
}

fn existing_products(vault: &str) -> Vec<String> {
    let Ok(entries) = std::fs::read_dir(vault) else {
        return vec![];
    };
    let mut out: Vec<String> = entries
        .flatten()
        .filter(|e| e.path().is_dir())
        .filter_map(|e| {
            let n = e.file_name().to_string_lossy().into_owned();
            n.strip_prefix("Project ").map(|s| s.to_string())
        })
        .collect();
    out.sort();
    out
}

pub fn slugify(s: &str) -> String {
    let lower = s.trim().to_lowercase();
    let mut out = String::new();
    let mut last_dash = false;
    for c in lower.chars() {
        if c.is_ascii_lowercase() || c.is_ascii_digit() {
            out.push(c);
            last_dash = false;
        } else if !last_dash {
            out.push('-');
            last_dash = true;
        }
    }
    out.trim_matches('-').to_string()
}

/// Keeps the title readable — the vault's own convention is spaced names like
/// `Bazel Migration.md` — while removing what a path cannot carry.
pub fn title_file(title: &str) -> String {
    let mut clean = title.trim().to_string();
    for bad in ['/', '\\', ':', '\0'] {
        clean = clean.replace(bad, "-");
    }
    if !clean.to_lowercase().ends_with(".md") {
        clean.push_str(".md");
    }
    clean
}

#[cfg(test)]
mod tests {
    use super::*;

    fn vault() -> tempfile::TempDir {
        let d = tempfile::tempdir().unwrap();
        std::fs::create_dir_all(d.path().join("Project TXE/Features")).unwrap();
        std::fs::create_dir_all(d.path().join("Project TXE/Decisions")).unwrap();
        d
    }

    fn req(v: &Path, kind: &str) -> Request {
        Request {
            vault: v.to_string_lossy().into_owned(),
            kind: kind.into(),
            product: "TXE".into(),
            date: "2026-09-04".into(),
            ..Default::default()
        }
    }

    #[test]
    fn a_feature_kind_lands_at_its_fixed_filename() {
        let v = vault();
        let mut r = req(v.path(), "brief");
        r.feature = "Spot Bidding".into();
        let t = resolve(&r).unwrap();
        assert!(
            t.path
                .ends_with("Project TXE/Features/spot-bidding/Brief.md"),
            "{}",
            t.path.display()
        );
        assert!(t.feature_dir.is_some());
    }

    #[test]
    fn a_product_kind_takes_its_name_from_the_title() {
        let v = vault();
        let mut r = req(v.path(), "decision");
        r.title = "Bazel Migration".into();
        let t = resolve(&r).unwrap();
        assert!(
            t.path.ends_with("Project TXE/Decisions/Bazel Migration.md"),
            "{}",
            t.path.display()
        );
        assert!(t.feature_dir.is_none(), "only feature folders get an index");
    }

    #[test]
    fn a_vault_kind_is_dated_and_slugged() {
        let v = vault();
        let mut r = req(v.path(), "postmortem");
        r.slug = "Redis Outage".into();
        let t = resolve(&r).unwrap();
        assert!(
            t.path.ends_with("Postmortems/2026-09-04-redis-outage.md"),
            "{}",
            t.path.display()
        );
    }

    #[test]
    fn an_unknown_kind_is_refused_rather_than_placed_somewhere_plausible() {
        let v = vault();
        let e = resolve(&req(v.path(), "musings")).unwrap_err();
        assert_eq!(e.kind, "OBSIDIAN-KIND");
        assert!(
            e.message.contains("known kinds are brief, decision"),
            "{}",
            e.message
        );
    }

    #[test]
    fn a_product_typo_is_refused_and_lists_what_exists() {
        let v = vault();
        let mut r = req(v.path(), "decision");
        r.product = "TXE2".into();
        r.title = "x".into();
        let e = resolve(&r).unwrap_err();
        assert_eq!(e.kind, "OBSIDIAN-PRODUCT");
        assert!(
            e.message.contains("existing products are TXE"),
            "{}",
            e.message
        );
    }

    #[test]
    fn a_missing_flag_names_the_flag_not_the_operation() {
        let v = vault();
        let e = resolve(&req(v.path(), "brief")).unwrap_err();
        assert!(e.message.contains("--feature"), "{}", e.message);
    }

    #[test]
    fn a_vault_that_does_not_exist_is_refused_rather_than_created() {
        let mut r = req(Path::new("/nonexistent/vault"), "postmortem");
        r.slug = "x".into();
        assert_eq!(resolve(&r).unwrap_err().kind, "OBSIDIAN-VAULT");
        assert!(!Path::new("/nonexistent/vault").exists());
    }

    #[test]
    fn slugify_and_title_file_match_the_go_behaviour() {
        assert_eq!(slugify("  Spot   Bidding! "), "spot-bidding");
        assert_eq!(slugify("TXE-1664 / retag"), "txe-1664-retag");
        assert_eq!(title_file("A/B: test"), "A-B- test.md");
        assert_eq!(title_file("Already.md"), "Already.md");
    }
}
