use clap::{Args, Parser, Subcommand};

/// The command-line surface. Every remote-touching command takes `--repo` and `--branch`,
/// so a rehearsal against a fork never means editing an installed configuration.
#[derive(Debug, Parser)]
#[command(
    name = "wf",
    version,
    about = "Capso 工作流的本地管理器",
    long_about = "安装、检查、修复和回滚这台机器上的 Capso 工作流。\n\
                  常用：wf status｜wf doctor｜wf repair｜wf history search <关键词>"
)]
pub struct Cli {
    /// Emit the stable JSON envelope instead of human text.
    #[arg(long, global = true)]
    pub json: bool,

    #[command(subcommand)]
    pub command: Command,
}

/// Flags shared by everything that can talk to the remote.
#[derive(Debug, Args, Clone, Default)]
pub struct RemoteArgs {
    /// The repository to sync from. Defaults to this build's own upstream.
    #[arg(long, global = true, env = "WF_REPO")]
    pub repo: Option<String>,

    /// The release branch recorded for this installation.
    #[arg(long, global = true, env = "WF_BRANCH")]
    pub branch: Option<String>,

    /// Where releases come from: `owner/repo`, `github:owner/repo`, or `local:<dir>`.
    /// The local form installs from a directory built by `wf release build-local`, which
    /// is how an install can be rehearsed with no private repository involved.
    #[arg(long, global = true, env = "WF_SOURCE")]
    pub source: Option<String>,

    /// `stable` or `canary`.
    #[arg(long, global = true, env = "WF_CHANNEL")]
    pub channel: Option<String>,
}

#[derive(Debug, Subcommand)]
pub enum Command {
    /// Install the workflow on this machine.
    Install {
        #[command(flatten)]
        remote: RemoteArgs,
        /// `all`, or agent ids and aliases separated by commas (`claude,cursor`). Agents
        /// that are not on this machine are skipped.
        #[arg(long, default_value = "all")]
        agent: String,
        /// Print the plan and change nothing.
        #[arg(long)]
        dry_run: bool,
    },
    /// Bring this machine to the current release.
    Sync {
        #[command(flatten)]
        remote: RemoteArgs,
        /// Check the remote even if a check is not due.
        #[arg(long)]
        force: bool,
        /// Do not touch the network; work from what is already here.
        #[arg(long)]
        offline: bool,
        #[arg(long)]
        dry_run: bool,
        /// Set when spawned by the session-start hook. Suppresses all output.
        #[arg(long, hide = true)]
        from_hook: bool,
        /// Only these agents (`all`, or ids and aliases). Defaults to the agents this
        /// machine manages.
        #[arg(long)]
        agent: Option<String>,
    },
    /// What is installed, what has drifted, what needs a reload.
    Status {
        #[command(flatten)]
        remote: RemoteArgs,
    },
    /// Everything status says, plus everything that would block a repair.
    Doctor {
        #[command(flatten)]
        remote: RemoteArgs,
        /// Exit non-zero on any finding, not just on an unhealthy one.
        #[arg(long)]
        strict: bool,
    },
    /// Put the organization's version back.
    Repair {
        #[command(flatten)]
        remote: RemoteArgs,
        /// Repair one component instead of all of them.
        #[arg(long)]
        component: Option<String>,
        /// Only these agents (`all`, or ids and aliases).
        #[arg(long)]
        agent: Option<String>,
        #[arg(long)]
        dry_run: bool,
    },
    /// Return this machine to an earlier release.
    Rollback {
        #[command(flatten)]
        remote: RemoteArgs,
        /// The version to return to. Defaults to the last known good.
        #[arg(long)]
        to: Option<String>,
        #[arg(long)]
        dry_run: bool,
    },
    /// Remove what wf installed, and nothing else.
    Uninstall {
        #[arg(long)]
        dry_run: bool,
        /// Required. Uninstalling touches the agents' configuration.
        #[arg(long)]
        yes: bool,
    },
    /// Every file wf has overwritten, and how to put one back.
    #[command(subcommand)]
    Backup(BackupCmd),
    /// The session-start dispatcher and its events.
    #[command(subcommand)]
    Hook(HookCmd),
    /// The coding agents wf manages on this machine. With no subcommand, the list.
    #[command(visible_alias = "agent")]
    Agents {
        #[command(subcommand)]
        cmd: Option<AgentsCmd>,
    },
    /// The MCP servers wf installs, and whether this machine already reaches them.
    #[command(subcommand)]
    Mcp(McpCmd),
    /// Which skills, tools and agents this machine's sessions have used.
    Usage {
        /// `30d`, `12h`, `90m`, or a date (`2026-09-01`).
        #[arg(long, default_value = "30d")]
        since: String,
        /// One agent instead of all of them.
        #[arg(long)]
        agent: Option<String>,
        /// How many rows each ranking shows.
        #[arg(long, default_value_t = 10)]
        limit: usize,
    },
    /// Summaries of this machine's coding sessions. With no subcommand, the recent ones.
    Sessions {
        #[command(subcommand)]
        cmd: Option<SessionsCmd>,
    },
    /// This machine's coding-agent history: ctx, under the workflow's name. Everything after
    /// `history` goes to ctx unchanged, so `wf history --help` is ctx's own help.
    #[command(disable_help_flag = true)]
    History {
        #[arg(trailing_var_arg = true, allow_hyphen_values = true)]
        args: Vec<std::ffi::OsString>,
    },
    /// Build and verify releases.
    #[command(subcommand)]
    Release(ReleaseCmd),

    /// Install and inspect the supervised PR review detector.
    #[command(subcommand, name = "review-pr")]
    ReviewPr(ReviewPrCmd),

    /// The overseer. Stage 1: measure review/fix rounds per merged PR.
    #[command(subcommand)]
    Magi(MagiCmd),

    /// Derive the facts for a release: commits, pull requests, tickets, migrations.
    #[command(name = "release-notes")]
    ReleaseNotes {
        /// Start of the range. Defaults to the most recent tag.
        #[arg(long)]
        from: Option<String>,
        /// End of the range.
        #[arg(long, default_value = "HEAD")]
        to: String,
        /// Repository to read. Defaults to the current one.
        #[arg(long)]
        root: Option<String>,
    },

    /// Derive the facts for a stakeholder brief: what a merged change is, and whether it is
    /// running on staging.
    #[command(name = "deploy-summary")]
    DeploySummary {
        /// A merged pull request to summarise. Repeat for a batch.
        #[arg(long = "pr", required = true)]
        prs: Vec<u32>,
        /// kubectl context for the environment to check. Omitted means the deployment state
        /// is reported as unknown rather than guessed.
        #[arg(long)]
        context: Option<String>,
        /// Namespace, or `*` for all.
        #[arg(long, default_value = "*")]
        namespace: String,
        /// Required to read a context whose name looks like production.
        #[arg(long)]
        production: bool,
    },
    /// Check this repository's documents, registry and generated surfaces.
    Guard {
        /// Re-render generated surfaces before checking.
        #[arg(long)]
        fix: bool,
        /// Compare the release surface against this ref and require a version bump.
        #[arg(long)]
        base_ref: Option<String>,
        /// The repository root to check.
        #[arg(long, default_value = ".")]
        root: String,
        /// Override today's date, for tests.
        #[arg(long)]
        now: Option<String>,
    },
    /// Verify this machine can do a ticket's work.
    Readiness(ReadinessArgs),
    /// File a document at its standard home in the vault.
    Obsidian(ObsidianArgs),
    /// Derive the state of in-flight work and emit a handover skeleton.
    Handover {
        /// Who is receiving it.
        #[arg(long)]
        to: Option<String>,
        /// Why it is being handed over.
        #[arg(long)]
        why: Option<String>,
        /// The ticket, when the branch does not carry it.
        #[arg(long)]
        ticket: Option<String>,
        /// The work tree being handed over.
        #[arg(long, default_value = ".")]
        root: String,
    },
    /// Publish a page to the org's own domain.
    PublishArtifact {
        /// The file to publish.
        file: String,
        #[arg(long)]
        title: String,
        #[arg(long)]
        kind: Option<String>,
        #[arg(long)]
        id: Option<String>,
        /// Print what would be sent and send nothing.
        #[arg(long)]
        dry_run: bool,
    },
}

#[derive(Debug, clap::Args)]
pub struct ObsidianArgs {
    #[arg(long)]
    pub kind: String,
    #[arg(long)]
    pub slug: Option<String>,
    #[arg(long)]
    pub feature: Option<String>,
    #[arg(long, env = "MAGI_PRODUCT")]
    pub product: Option<String>,
    #[arg(long)]
    pub file: Option<String>,
    #[arg(long)]
    pub title: Option<String>,
    #[arg(long, env = "MAGI_TICKET")]
    pub ticket: Option<String>,
    #[arg(long, env = "MAGI_ARTIFACT_URL")]
    pub url: Option<String>,
    #[arg(long)]
    pub date: Option<String>,
    #[arg(long)]
    pub replace: bool,
    #[arg(long)]
    pub dry_run: bool,
    #[arg(long, env = "MAGI_VAULT")]
    pub vault: Option<String>,
}

#[derive(Debug, clap::Args)]
pub struct ReadinessArgs {
    /// A known tool (optionally >=version), declared custom tool, compose service, or a
    /// command on PATH.
    #[arg(long = "need", short = 'n')]
    pub need: Vec<String>,
    #[arg(long)]
    pub repair: bool,
    #[arg(long)]
    pub force: bool,
    #[arg(long, default_value = "consumer")]
    pub profile: String,
    #[arg(long)]
    pub root: Option<String>,
    /// Override the repo manifest; relative paths are resolved under --root.
    #[arg(long)]
    pub manifest: Option<String>,
    /// The compose file that defines the services asked for; relative paths are resolved
    /// under --root. Without it: the manifest's services.from, then compose.yaml,
    /// compose.yml, docker-compose.yaml or docker-compose.yml in the root, deploy/,
    /// deployments/, docker/ or .devcontainer/.
    #[arg(long)]
    pub compose: Option<String>,
    /// The agent the session runs in, which must carry the components the manifest
    /// requires. Without it: the agent whose session runs this command, else every agent
    /// wf manages on this machine.
    #[arg(long)]
    pub agent: Option<String>,
    #[arg(long, default_value = "12h", value_parser = parse_duration)]
    pub ttl: std::time::Duration,
}

fn parse_duration(mut input: &str) -> Result<std::time::Duration, String> {
    let mut total = std::time::Duration::ZERO;
    if input.is_empty() {
        return Err("duration is empty".into());
    }
    while !input.is_empty() {
        let digits = input.bytes().take_while(u8::is_ascii_digit).count();
        if digits == 0 {
            return Err("use a duration such as 30s, 15m, or 12h".into());
        }
        let count = input[..digits]
            .parse::<u64>()
            .map_err(|_| "duration is too large")?;
        input = &input[digits..];
        let units = input.bytes().take_while(u8::is_ascii_alphabetic).count();
        let part = match &input[..units] {
            "ns" => std::time::Duration::from_nanos(count),
            "us" => std::time::Duration::from_micros(count),
            "ms" => std::time::Duration::from_millis(count),
            "s" => std::time::Duration::from_secs(count),
            "m" => std::time::Duration::from_secs(
                count.checked_mul(60).ok_or("duration is too large")?,
            ),
            "h" => std::time::Duration::from_secs(
                count.checked_mul(3600).ok_or("duration is too large")?,
            ),
            "" if count == 0 => std::time::Duration::ZERO,
            _ => return Err("duration requires ns, us, ms, s, m, or h".into()),
        };
        total = total.checked_add(part).ok_or("duration is too large")?;
        input = &input[units..];
    }
    Ok(total)
}

#[derive(Debug, Subcommand)]
pub enum BackupCmd {
    /// Every backup, newest first.
    List,
    /// Put one back. The current contents are backed up first.
    Restore { id: String },
    /// Drop backups outside the retention window.
    Prune,
}

#[derive(Debug, Subcommand)]
pub enum HookCmd {
    /// The fixed dispatcher. Its argv never changes; policy lives in the bundle.
    SessionStart {
        #[arg(long)]
        agent: String,
        #[command(flatten)]
        remote: RemoteArgs,
    },
    /// A non-SessionStart event, routed through the same fixed dispatcher.
    Dispatch {
        #[arg(long)]
        agent: String,
        #[arg(long)]
        event: String,
    },
}

#[derive(Debug, Subcommand)]
pub enum AgentsCmd {
    /// Every agent wf knows, whether it is on this machine, and whether wf manages it.
    List,
    /// Look for every agent and ask each one that is installed for its version.
    Detect,
    /// What each managed agent carries, object by object.
    Status {
        #[command(flatten)]
        remote: RemoteArgs,
        /// Only these agents (`all`, or ids and aliases).
        #[arg(long)]
        agent: Option<String>,
    },
    /// Start managing an agent, and deploy the team's resources into it.
    Register {
        /// An agent id or alias from `wf agents list`.
        id: String,
        #[arg(long)]
        dry_run: bool,
    },
    /// Stop managing an agent, and remove what wf put there.
    Unregister {
        id: String,
        #[arg(long)]
        dry_run: bool,
    },
}

#[derive(Debug, Subcommand)]
pub enum McpCmd {
    /// The servers this machine already reaches, per agent, before wf writes anything.
    ///
    /// Read-only: it answers whether installing one of ours would put a second connection
    /// to the same service in front of a person. A server somebody else configured is named
    /// by nothing here but the host it shares with ours.
    Survey {
        #[command(flatten)]
        remote: RemoteArgs,
        /// Only these agents (`all`, or ids and aliases).
        #[arg(long)]
        agent: Option<String>,
    },
    /// Record that this machine is not to install one of our MCP servers.
    ///
    /// The decision is the person's, it is kept per agent, and nothing asks about that
    /// server again — no warning, no login prompt, no doctor finding — until `unskip`.
    Skip {
        /// The component id, as `wf mcp survey` and `wf doctor` print it —
        /// `capso.mcp.linear`.
        component: String,
        /// Only this agent. Left out, the decision covers every agent wf writes MCP into.
        #[arg(long)]
        agent: Option<String>,
        /// Our own published host, kept so a later diagnostic can say which service the
        /// decision was about. Never another server's address.
        #[arg(long)]
        host: Option<String>,
        /// Why, in the person's own words. `wf doctor` shows it back to them.
        #[arg(long)]
        reason: Option<String>,
        /// Say what would be recorded, and record nothing.
        #[arg(long)]
        dry_run: bool,
    },
    /// Undo a `skip`, so wf installs that server again.
    ///
    /// Removing the record does not install anything by itself: `wf sync` on a version
    /// already active does no object check at all, so this prints the one command that
    /// does — `wf repair`.
    Unskip {
        /// The component id, as `wf mcp survey` and `wf doctor` print it.
        component: String,
        /// Only this agent. Left out, the decision is undone everywhere it was made.
        #[arg(long)]
        agent: Option<String>,
        /// Say what would be undone, and undo nothing.
        #[arg(long)]
        dry_run: bool,
    },
}

#[derive(Debug, Subcommand)]
pub enum SessionsCmd {
    /// Recent sessions, newest first.
    List {
        #[arg(long, default_value_t = 20)]
        limit: usize,
        /// Only one agent's.
        #[arg(long)]
        agent: Option<String>,
    },
    /// One session's summary.
    Show { id: String },
    /// Put a session in this month's log whether or not it passed the policy's bar.
    /// Defaults to the most recent session.
    Save { id: Option<String> },
    /// Drop usage and session logs older than the policy keeps.
    Prune,
}

#[derive(Debug, Subcommand)]
pub enum ReleaseCmd {
    /// Compile the registry into a lock and a bundle in `--out`.
    BuildLocal {
        #[arg(long, default_value = "dist")]
        out: String,
        #[arg(long, default_value = ".")]
        root: String,
        /// Override the version. Defaults to the workspace version.
        #[arg(long)]
        version: Option<String>,
        /// Include the current binary as this platform's release asset.
        #[arg(long)]
        with_binary: bool,
        /// Already built platform archive, repeatable.
        #[arg(long = "binary", value_name = "TARGET=ARCHIVE")]
        binaries: Vec<String>,
        /// Pin a ctx release in the lock: `latest`, or a tag for an emergency pin. Omitted
        /// pins nothing, and an install from the build leaves a machine's ctx alone.
        #[arg(long, value_name = "latest|vX.Y.Z")]
        ctx: Option<String>,
    },
    /// Package an executable with deterministic cross-platform archive metadata.
    PackBinary {
        #[arg(long)]
        binary: String,
        #[arg(long)]
        out: String,
    },
    /// Check a built release directory against its own lock.
    Verify {
        #[arg(long, default_value = "dist")]
        dir: String,
        /// Require an archive for every supported release target.
        #[arg(long)]
        require_binaries: bool,
    },
    /// Print the lock that this tree would produce.
    BuildLock {
        #[arg(long, default_value = ".")]
        root: String,
    },
}

/// Provisioning for `/review-pr`. Reviewing itself belongs to the skill and the detector;
/// these commands only write, load and report the supervisor job.
#[derive(Debug, Subcommand)]
pub enum ReviewPrCmd {
    /// Write the supervisor job for a repository and load it.
    Install {
        /// OWNER/REPO to poll.
        #[arg(long)]
        repo: String,
        /// Seconds between polls.
        #[arg(long)]
        poll_seconds: Option<u32>,
        /// Concurrent review workers.
        #[arg(long)]
        max_workers: Option<u32>,
        /// Reinstall over an existing job of the same label.
        #[arg(long)]
        replace: bool,
    },
    /// Which detectors are installed, and when each last polled.
    Status {
        /// Limit to one OWNER/REPO.
        #[arg(long)]
        repo: Option<String>,
    },
    /// Where the supervisor writes, and the tail of it.
    Logs {
        #[arg(long)]
        repo: String,
        /// Lines of tail to print.
        #[arg(long, default_value_t = 40)]
        lines: u32,
    },
    /// Unload and remove the job. State is left in place.
    Uninstall {
        #[arg(long)]
        repo: String,
    },
}

/// Magi, the overseer. Only its sensor exists so far.
#[derive(Debug, Subcommand)]
pub enum MagiCmd {
    /// Count review/fix rounds per merged PR, with covariates, rebuilt from GitHub in full.
    Measure {
        /// OWNER/REPO to read.
        #[arg(long)]
        repo: String,
        /// Only PRs merged on or after this date (YYYY-MM-DD).
        #[arg(long)]
        since: Option<String>,
        /// Most recent merged PRs to read.
        #[arg(long, default_value_t = 100)]
        limit: u32,
    },
}
