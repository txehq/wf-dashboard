//! ctx convergence (ADR-0006): bring `ctx` in the wf bin directory to the release the active
//! lock pins, and leave its daemon running.
//!
//! Deliberately not part of [`Engine::apply`]. A release apply is a transaction over files
//! wf owns outright; converging ctx downloads fifty megabytes from another project, hands a
//! live daemon over, and runs a setup that can take minutes. Folded into `apply`, a slow
//! mirror or an old daemon would roll back or block an unrelated skill update. Beside it,
//! the worst a ctx problem can do is leave ctx where it was and say so.
//!
//! Three callers converge: `wf install` (always, re-running setup), `wf sync` (after its
//! update), and the session-start hook, which only *schedules* it — two rows in the state
//! database decide, at most hourly. That third one is what reaches a machine whose update to
//! the release that introduced ctx was applied by the previous `wf`, which had never heard
//! of it.

use crate::engine::{running_version, set_executable, Engine};
use serde::Serialize;
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};
use wf_core::{Error, Result};
use wf_release::lock::{BinaryRef, CtxUpstream};
use wf_release::Lock;
use wf_state::ComponentState;
use wf_state::Transaction;

/// The pin for this platform as [`desired_key`] spells it, written whenever a release is
/// applied. Empty when that release pins no ctx.
pub const DESIRED: &str = "ctx_desired";
/// The key that last converged completely: installed, runtime in place, daemon handed back,
/// set up.
pub const CURRENT: &str = "ctx_current";
/// `KIND: message` from the last attempt that failed, cleared by the next success.
pub const ERROR: &str = "ctx_error";
/// The wf version that recorded [`ERROR`]. A refusal is final only for the wf that made it:
/// a later release may know how to lift it, and has to be allowed to try once.
pub const ERROR_BY: &str = "ctx_error_by";
/// `<archive sha256>:<version>:<library sha256>` of the ONNX Runtime last put beside ctx. The
/// library digest is taken from the verified archive as it is expanded, and every later check
/// hashes the library on disk against it.
pub const RUNTIME: &str = "ctx_runtime";

/// The recorded failures no unattended run of the same wf can clear: both ask a person to
/// retire the ctx this machine already has. Until they do, converging again would fail the
/// same way.
pub const NEEDS_A_PERSON: [&str; 2] = ["CTX-FOREIGN", "CTX-HANDOFF"];
/// The receipt component for the binary. Uninstall leaves it, as it leaves `wf` itself.
pub const COMPONENT: &str = "capso.ctx.binary";

/// The fields upstream's handoff receipt must carry before its executable may be replaced
/// (upstream `docs/unmanaged-installs.md`, CLM-007). Named rather than counted, so a field
/// upstream adds later is ignored instead of refusing every update from then on.
const QUIESCENT: &[&str] = &[
    "ok",
    "installation_quiescent",
    "supervisor_removed",
    "owner_lock_released",
    "endpoint_released",
    "coordination_state_removed",
    "binary_retained",
];

#[derive(Debug, Clone, PartialEq, Serialize)]
#[serde(tag = "state", rename_all = "snake_case")]
pub enum CtxReport {
    /// The release pins no ctx, so whatever ctx the machine has is left alone.
    NotPinned,
    /// Already converged on the pin. Nothing ran.
    Current { version: String },
    /// Another process holds the ctx lock and will finish the job.
    Busy,
    /// A dry run found the machine short of the pin.
    WouldInstall { version: String },
    /// Converged just now. `replaced` is false when only the setup had to run again.
    Installed { version: String, replaced: bool },
}

/// wf's own copy of ctx: the one whose digest the generation pinned and verified.
pub fn pinned_binary(paths: &wf_core::paths::Paths) -> Option<PathBuf> {
    let own = paths.bin_dir.join("ctx");
    own.is_file().then_some(own)
}

/// The ctx that `wf history` runs: wf's own copy, or else whichever one is on PATH. A
/// machine that already had a ctx keeps it — `converge_pinned` refuses to install a second
/// one beside it (`CTX-FOREIGN`), and this is that machine's ctx.
pub fn binary(paths: &wf_core::paths::Paths) -> Option<PathBuf> {
    pinned_binary(paths).or_else(|| wf_core::proc::which("ctx"))
}

/// What this machine converges on for `target`: the binary's sha256 and the runtime's, `-`
/// when the release pins no runtime. One string, so the session-start check stays two reads
/// of the state database; a key in an older spelling differs from it, and so converges again.
pub fn desired_key(pin: &CtxUpstream, target: &str) -> Option<String> {
    let binary = pin.binary_for(target)?;
    Some(format!(
        "{}:{}",
        binary.sha256,
        pin.runtime_for(target).map_or("-", |r| r.sha256.as_str())
    ))
}

/// The sentence for a recorded failure. Every one is a fix, not a diagnosis.
pub fn zh(kind: &str) -> String {
    match kind {
        "CTX-HANDOFF" => "现在这个 ctx 的后台进程没有报告已经完全停下，所以没有替换它，旧的照常能用。手动做一次：\n  1. 停掉旧的后台进程：Linux 运行 `systemctl --user disable --now ctx.service`，macOS 运行 `launchctl bootout gui/$(id -u)/rs.ctx.daemon`；\n  2. 把 ~/.local/bin/ctx 和 ~/.local/bin/ctx.install.json 移到别处；\n  3. 再运行 `wf install`。",
        "CTX-RUNTIME" => "ctx 的语义检索运行库没有装好，现在只能按关键词检索。之后会自动再试，也可以现在运行 `wf install`。",
        "CTX-FOREIGN" => "这台机器上已经有另一个 ctx，wf 不会在它旁边再装一份。先用它自己的方式卸掉：运行 `ctx daemon disable --prepare-uninstall --format=json`，成功后用当初装它的工具（brew、cargo 等）删掉它，然后运行 `wf install`。",
        "CTX-INTEGRITY" => "下载的 ctx 和这个版本锁定的不一致，已经删掉，没有运行，也没有替换现有的 ctx。通常是网络中途出错，之后会自动再试；连续出现请把这条消息发给团队。",
        "CTX-SETUP" => "ctx 已经装好，但设置没有跑完（后台索引或语义检索）。之后会自动再试，也可以现在运行 `wf install`；日志在 wf 状态目录下的 ctx 文件夹里。",
        _ => "ctx 还没有装好。运行 `wf install` 再试一次；还不行的话运行 `wf doctor`，把结果发给团队。",
    }
    .to_string()
}

impl Engine {
    /// The active generation's lock, read as data. Its integrity was settled when the
    /// generation was staged; this only needs to know what it pins.
    pub fn active_lock(&self) -> Result<Option<Lock>> {
        let Some(g) = self.db.active_generation()? else {
            return Ok(None);
        };
        let path = self.paths.generation(&g.version).join("workflow.lock.json");
        Ok(Some(Lock::parse(&std::fs::read_to_string(path)?)?))
    }

    /// Converge ctx on what `lock` pins for this platform.
    ///
    /// `force` re-runs the setup even when the state database says it already finished,
    /// which is what a person running `wf install` means. `from_hook` gives up at once when
    /// another process is converging, rather than waiting.
    pub fn converge_ctx(&self, lock: &Lock, force: bool, from_hook: bool) -> Result<CtxReport> {
        let pin = &lock.ctx_upstream;
        let target = wf_core::paths::target_triple();
        let installed = self.paths.bin_dir.join("ctx");
        let (Some(binary), Some(key)) = (pin.binary_for(target), desired_key(pin, target)) else {
            if !self.opts.dry_run {
                for key in [DESIRED, CURRENT, ERROR, ERROR_BY] {
                    self.db.set_meta(key, "")?;
                }
            }
            return Ok(CtxReport::NotPinned);
        };
        let runtime = pin.runtime_for(target);
        let version = pin.version.clone();
        if self.opts.dry_run {
            let on_pin = installed.is_file()
                && wf_core::hash::sha256_file(&installed)? == binary.sha256
                && runtime.map_or(Ok(true), |r| self.runtime_in_place(r))?;
            return Ok(if on_pin {
                CtxReport::Current { version }
            } else {
                CtxReport::WouldInstall { version }
            });
        }

        let lock_file = self.paths.state_dir.join("ctx.lock");
        let _guard = if from_hook {
            match wf_core::lock::Guard::try_exclusive(&lock_file) {
                Ok(guard) => guard,
                Err(e) if e.code == wf_core::ExitCode::Conflict => return Ok(CtxReport::Busy),
                Err(e) => return Err(e),
            }
        } else {
            wf_core::lock::Guard::exclusive_within(&lock_file, 30_000)?
        };
        self.recover_runtime()?;
        self.db.set_meta(DESIRED, &key)?;
        // The record alone is not enough for the runtime: it is native code ctx loads, and the
        // bytes on disk are what have to still be the verified ones — or, for a release that
        // pins none, there has to be none on record.
        let runtime_settled = match runtime {
            Some(runtime) => self.runtime_in_place(runtime)?,
            None => self.recorded_runtime()?.is_none(),
        };
        if !force && self.db.meta(CURRENT)?.as_deref() == Some(key.as_str()) && runtime_settled {
            return Ok(CtxReport::Current { version });
        }
        match self.converge_pinned(lock, binary, runtime, &installed) {
            Ok(replaced) => {
                self.db.set_meta(CURRENT, &key)?;
                self.db.set_meta(ERROR, "")?;
                self.db.set_meta(ERROR_BY, "")?;
                self.forget_reimplemented_history();
                Ok(CtxReport::Installed { version, replaced })
            }
            Err(e) => {
                self.db
                    .set_meta(ERROR, &format!("{}: {}", e.kind, e.message))?;
                self.db.set_meta(ERROR_BY, wf_core::VERSION)?;
                Err(e)
            }
        }
    }

    /// wf's ctx, when it may be run: the active release pins one, the binary in place hashes
    /// to that pin, and the convergence and runtime it needs are complete. Anything else is
    /// already a finding of [`Engine::ctx_state`], and a diagnostic must not become a way to
    /// execute bytes the release never verified.
    pub fn ctx_verified(&self) -> Result<Option<PathBuf>> {
        let Some(lock) = self.active_lock()? else {
            return Ok(None);
        };
        if desired_key(&lock.ctx_upstream, wf_core::paths::target_triple()).is_none() {
            return Ok(None);
        }
        Ok(self
            .ctx_state()?
            .is_none()
            .then(|| self.paths.bin_dir.join("ctx")))
    }

    /// What `wf status` and `wf doctor` say about ctx, if anything, from the machine record.
    ///
    /// A recorded failure is `blocked`: history is not what this release pins, and a session
    /// told to search it will find that out the hard way. Anything short of that is a
    /// convergence still under way, which the next session start or `wf install` finishes.
    pub fn ctx_state(&self) -> Result<Option<(ComponentState, String)>> {
        let Some(lock) = self.active_lock()? else {
            return Ok(None);
        };
        let pin = &lock.ctx_upstream;
        let target = wf_core::paths::target_triple();
        let (Some(binary), Some(key)) = (pin.binary_for(target), desired_key(pin, target)) else {
            return Ok(None);
        };
        if let Some(error) = self.db.meta(ERROR)?.filter(|e| !e.is_empty()) {
            let kind = error.split(':').next().unwrap_or_default();
            return Ok(Some((
                ComponentState::Blocked,
                format!("{}\n    （技术细节：{error}）", zh(kind)),
            )));
        }
        let installed = self.paths.bin_dir.join("ctx");
        if !installed.is_file() || wf_core::hash::sha256_file(&installed)? != binary.sha256 {
            return Ok(Some((
                ComponentState::UpdatePending,
                format!(
                    "{} 不是这个版本锁定的 ctx {}。运行 `wf install` 换上它。",
                    installed.display(),
                    pin.version
                ),
            )));
        }
        if self.db.meta(CURRENT)?.as_deref() != Some(key.as_str()) {
            return Ok(Some((
                ComponentState::UpdatePending,
                format!(
                    "ctx {} 已经就位，但设置还没有跑完（后台索引、语义检索运行库）。运行 `wf install` 完成它。",
                    pin.version
                ),
            )));
        }
        // The record says converged; the directory is what ctx loads. It can be deleted after.
        match pin.runtime_for(target) {
            Some(runtime) if !self.runtime_in_place(runtime)? => Ok(Some((
                ComponentState::UpdatePending,
                format!(
                    "ctx {} 的语义检索运行库不在 {} 里了，现在只能按关键词检索。运行 `wf install` 装回它。",
                    pin.version,
                    self.runtime_root().display()
                ),
            ))),
            // A runtime this release does not pin is still on record: until convergence moves
            // it out of the loader's way, ctx is not run from `wf doctor`.
            None if self.recorded_runtime()?.is_some() => Ok(Some((
                ComponentState::UpdatePending,
                format!(
                    "{} 里还有这个版本没有锁定的语义检索运行库。运行 `wf install` 把它移走。",
                    self.runtime_root().display()
                ),
            ))),
            _ => Ok(None),
        }
    }

    /// Is the pinned runtime expanded where ctx looks for it?
    /// Is the pinned runtime in place, with the library bytes the verified archive carried?
    fn runtime_in_place(&self, runtime: &BinaryRef) -> Result<bool> {
        let recorded = self.db.meta(RUNTIME)?.unwrap_or_default();
        let mut fields = recorded.split(':');
        let (Some(archive), Some(version), Some(library), None) =
            (fields.next(), fields.next(), fields.next(), fields.next())
        else {
            return Ok(false);
        };
        if archive != runtime.sha256 {
            return Ok(false);
        }
        let Some(path) = wf_release::ctx::runtime_library_path(
            &self.runtime_root(),
            version,
            wf_core::paths::target_triple(),
        ) else {
            return Ok(false);
        };
        Ok(path.is_file() && wf_core::hash::sha256_file(&path)? == library)
    }

    /// `<bin>/onnxruntime`: the runtime cache ctx's loader searches beside its own executable
    /// (`exe_onnxruntime_cache`, upstream `model_runtime/onnx.rs`). Beside the binary, so it
    /// needs no environment variable and holds whatever data root ctx is run with.
    fn runtime_root(&self) -> PathBuf {
        self.paths.bin_dir.join("onnxruntime")
    }

    /// `<bin>/onnxruntime` as wf's own directory: created when absent, and refused when it is a
    /// link or a mount point — before a byte of the archive is staged into it.
    fn runtime_root_checked(&self) -> Result<PathBuf> {
        let root = self.runtime_root();
        wf_core::paths::refuse_symlink(&root)?;
        if !root.exists() {
            std::fs::create_dir(&root)?;
        }
        refuse_mounted(&root)?;
        Ok(root)
    }

    /// Bring the pinned ONNX Runtime into place, before `ctx semantic enable` asks for it.
    fn stage_runtime(
        &self,
        pin: &CtxUpstream,
        runtime: &BinaryRef,
    ) -> Result<Option<wf_release::ctx::StagedRuntime>> {
        if self.runtime_in_place(runtime)? {
            return Ok(None);
        }
        let archive = wf_release::ctx::fetch(
            pin,
            runtime,
            &self.opts.source,
            &self.paths.staging(),
            Duration::from_secs(600),
        )?;
        let staged = wf_release::ctx::stage_runtime(
            &archive,
            &self.runtime_root_checked()?,
            wf_core::paths::target_triple(),
        )?;
        std::fs::remove_file(&archive)?;
        Ok(Some(staged))
    }

    /// Where a runtime displaced by an update waits until that update has converged:
    /// `<runtime root>/.previous/<version>/<platform>/`. Durable, unlike the stage's scratch
    /// directory, so a failed restore or an interrupted process never loses it; the loader
    /// never looks there.
    fn previous_root(&self) -> PathBuf {
        self.runtime_root().join(".previous")
    }

    /// The runtime this machine's record says is in place, as `(archive, version, library)`
    /// digests and version.
    fn recorded_runtime(&self) -> Result<Option<(String, String, String)>> {
        let recorded = self.db.meta(RUNTIME)?.unwrap_or_default();
        let mut fields = recorded.split(':');
        Ok(
            match (fields.next(), fields.next(), fields.next(), fields.next()) {
                (Some(a), Some(v), Some(l), None) if !a.is_empty() => {
                    Some((a.to_string(), v.to_string(), l.to_string()))
                }
                _ => None,
            },
        )
    }

    /// Can the directory at `version_dir/<platform>` be moved aside whole? Neither directory
    /// is a link or a mount point, and nothing inside the tree is either: the tree is renamed
    /// away by the swap and removed once the update has converged, and neither may reach
    /// anything that is not the runtime wf put there.
    fn check_replaceable(&self, version_dir: &Path, dest: &Path) -> Result<()> {
        self.runtime_root_checked()?;
        for path in [version_dir, dest] {
            wf_core::paths::refuse_symlink(path)?;
        }
        if version_dir.exists() {
            refuse_mounted(version_dir)?;
        }
        if dest.exists() {
            refuse_links_and_mounts(dest)?;
        }
        Ok(())
    }

    /// Finish what an interrupted update left in `.previous`, under the ctx lock, before
    /// anything else touches the runtime. The record is the commit marker: it names the
    /// library the committed runtime carries. A displaced tree whose library the record still
    /// names is the committed runtime and goes back in place; any other is left over from an
    /// update that did commit, and goes.
    fn recover_runtime(&self) -> Result<()> {
        let previous_root = self.previous_root();
        if !previous_root.is_dir() {
            return Ok(());
        }
        refuse_links_and_mounts(&previous_root)?;
        let target = wf_core::paths::target_triple();
        let recorded = self.recorded_runtime()?;
        for version in std::fs::read_dir(&previous_root)? {
            let version = version?.file_name();
            for platform in std::fs::read_dir(previous_root.join(&version))? {
                let platform = platform?.file_name();
                let displaced = previous_root.join(&version).join(&platform);
                let live = self.runtime_root().join(&version).join(&platform);
                let version = version.to_string_lossy();
                let library =
                    wf_release::ctx::runtime_library_path(&previous_root, &version, target)
                        .filter(|p| p.is_file())
                        .map(|p| wf_core::hash::sha256_file(&p))
                        .transpose()?;
                let committed_one = recorded
                    .as_ref()
                    .is_some_and(|(_, v, lib)| *v == version && Some(lib) == library.as_ref());
                if committed_one {
                    if live.exists() {
                        refuse_links_and_mounts(&live)?;
                        std::fs::remove_dir_all(&live)?;
                    }
                    std::fs::create_dir_all(live.parent().expect("a version directory"))?;
                    std::fs::rename(&displaced, &live)?;
                } else {
                    std::fs::remove_dir_all(&displaced)?;
                }
            }
            std::fs::remove_dir(previous_root.join(&version))?;
        }
        std::fs::remove_dir(&previous_root)?;
        Ok(())
    }

    /// Move the tree at `dest` into `.previous` and put `new` (a staged tree) in its place, or
    /// nothing when there is none, as part of `tx`. A rollback renames both back. Nothing is
    /// edited in place, and nothing is deleted here: the displaced tree stays in `.previous`
    /// until the update has converged.
    fn swap_runtime(
        &self,
        tx: &mut Transaction,
        version: &str,
        dest: &Path,
        new: Option<&wf_release::ctx::StagedRuntime>,
    ) -> Result<()> {
        let platform = dest.file_name().expect("a platform directory").to_owned();
        let displaced = self.previous_root().join(version).join(&platform);
        let had_previous = std::fs::symlink_metadata(dest).is_ok();
        if had_previous {
            std::fs::create_dir_all(displaced.parent().expect("a version directory"))?;
            std::fs::rename(dest, &displaced)?;
        }
        if let Some(staged) = new {
            std::fs::create_dir_all(dest.parent().expect("a version directory"))?;
            if let Err(e) = std::fs::rename(staged.tree(), dest) {
                if had_previous {
                    std::fs::rename(&displaced, dest)?;
                }
                return Err(e.into());
            }
        }
        let (dest, put_in) = (
            dest.to_path_buf(),
            new.map(|s| s.scratch().join("discarded")),
        );
        tx.native_restore(COMPONENT, move || {
            if let Some(discarded) = &put_in {
                std::fs::rename(&dest, discarded)?;
            }
            if had_previous {
                std::fs::rename(&displaced, &dest)?;
            }
            Ok(())
        });
        Ok(())
    }

    /// Returns whether the binary itself was replaced.
    fn converge_pinned(
        &self,
        lock: &Lock,
        binary: &BinaryRef,
        runtime: Option<&BinaryRef>,
        installed: &Path,
    ) -> Result<bool> {
        let pin = &lock.ctx_upstream;
        let logs = self.paths.state_dir.join("ctx");
        let before = if installed.is_file() {
            Some(wf_core::hash::sha256_file(installed)?)
        } else {
            None
        };
        let replace = before.as_deref() != Some(binary.sha256.as_str());
        if replace && before.is_none() {
            if let Some(other) = wf_core::proc::which("ctx") {
                return Err(Error::failure(
                    "CTX-FOREIGN",
                    format!("{} is already on PATH", other.display()),
                )
                .with_zh(zh("CTX-FOREIGN")));
            }
        }
        // Both halves are downloaded, verified and expanded before anything is touched, then
        // put in place in one transaction: the binary written with its backup, the runtime
        // swapped in whole by rename. Both land together, or a failure anywhere restores both.
        // A download or an archive that fails leaves the running ctx and the runtime it loads
        // as they were.
        let staged_runtime = match runtime {
            Some(runtime) => self.stage_runtime(pin, runtime)?,
            None => None,
        };
        let staged_binary = if replace {
            let staged = wf_release::ctx::fetch(
                pin,
                binary,
                &self.opts.source,
                &self.paths.staging(),
                Duration::from_secs(600),
            )?;
            set_executable(&staged)?;
            expect_version(&staged, &pin.version)?;
            Some(staged)
        } else {
            None
        };

        // A release that pins no runtime — a rollback to one from before runtimes were pinned —
        // must not leave one it never verified where ctx loads it: the recorded runtime is
        // moved out of the loader's way and its record cleared in the same commit.
        let target = wf_core::paths::target_triple();
        let recorded = self.recorded_runtime()?;
        let clear_record = runtime.is_none() && recorded.is_some();
        let unpinned = match (&recorded, wf_release::ctx::runtime_platform_for(target)) {
            (Some((_, version, _)), Some(platform)) if runtime.is_none() => {
                Some(version.clone()).zip(Some(self.runtime_root().join(version).join(platform)))
            }
            _ => None,
        }
        .filter(|(_, dest)| dest.exists());
        let runtime_move = match (&staged_runtime, unpinned) {
            (Some(staged), _) => Some((
                staged.version.clone(),
                staged.destination(&self.runtime_root()),
            )),
            (None, unpinned) => unpinned,
        };

        if staged_binary.is_none() && runtime_move.is_none() && !clear_record {
            lifecycle(installed, &logs)?;
            return Ok(replace);
        }

        // Everything that can refuse the write is asked before the daemon is touched. The
        // handoff is point-in-time: a failure after it would leave nothing indexing.
        wf_core::paths::refuse_symlink(installed)?;
        tempfile::NamedTempFile::new_in(&self.paths.bin_dir)?;
        if let Some((version, dest)) = &runtime_move {
            self.check_replaceable(&self.runtime_root().join(version), dest)?;
        }
        let handed_off = staged_binary.is_some() && before.is_some();
        if handed_off {
            handoff(installed, &logs)?;
        }
        // Asked again after the handoff, which can take two minutes, so the window between
        // the check and the swap is only this function's own.
        if let Some((version, dest)) = &runtime_move {
            self.check_replaceable(&self.runtime_root().join(version), dest)?;
        }

        let record: Option<String> = match (runtime, &staged_runtime) {
            (Some(runtime), Some(staged)) => Some(format!(
                "{}:{}:{}",
                runtime.sha256, staged.version, staged.library_sha256
            )),
            _ if clear_record => Some(String::new()),
            _ => None,
        };
        let mut tx =
            Transaction::begin(&self.db, self.paths.backups(), &lock.release_version, false);
        let mut set_up = false;
        let written = (|| -> Result<()> {
            if let Some((version, dest)) = &runtime_move {
                self.swap_runtime(&mut tx, version, dest, staged_runtime.as_ref())?;
            }
            if let Some(staged) = &staged_binary {
                tx.write_file(COMPONENT, "", installed, &std::fs::read(staged)?)?;
                set_executable(installed)?;
                // A hosted-installer marker beside a binary it did not install is the
                // inconsistent pair upstream refuses to run upgrades against.
                let marker = self.paths.bin_dir.join("ctx.install.json");
                if marker.is_file() {
                    tx.remove_file(COMPONENT, &marker)?;
                }
                expect_version(installed, &pin.version)?;
            }
            // The setup runs before the commit: until it has worked, the transaction still
            // holds the previous binary's backup and the undo that puts the previous runtime
            // back.
            set_up = true;
            lifecycle(installed, &logs)
        })();
        // The runtime's record is written inside the commit, in the same database transaction
        // as the receipts, so the record and the bytes on disk are never two answers.
        let publish = |_: &mut Transaction| match &record {
            Some(record) => self.db.set_meta(RUNTIME, record),
            None => Ok(()),
        };
        let committed = match written {
            Ok(()) => tx.commit_with(publish),
            // A setup that ran started the new daemon, and it is handed off before the
            // previous binary goes back under it. When it will not stop, the new installation
            // stays: it is the verified one, and the next convergence retries its setup.
            Err(e) if set_up && handoff(installed, &logs).is_err() => {
                tx.commit_with(publish)?;
                return Err(e);
            }
            Err(e) => {
                tx.rollback();
                Err(e)
            }
        };
        if let Err(mut e) = committed {
            // The undo put the displaced runtime back; what is left in `.previous` is empty.
            if let Err(tidy) = self.recover_runtime() {
                e.message.push_str(&format!(
                    "; the runtime's leftovers were not tidied: {}",
                    tidy.message
                ));
            }
            // What is in place now is what was there before. When its daemon was handed off,
            // or a setup ran and was handed off above, give it back.
            if (handed_off || set_up) && installed.is_file() {
                let _ = run(
                    installed,
                    &["index", "mode", "auto"],
                    &logs,
                    Duration::from_secs(120),
                );
            }
            return Err(e);
        }
        // Converged: the displaced runtime is no longer needed.
        let previous_root = self.previous_root();
        if previous_root.exists() {
            refuse_links_and_mounts(&previous_root)?;
            std::fs::remove_dir_all(&previous_root)?;
        }
        if let Some(staged) = &staged_binary {
            let _ = std::fs::remove_file(staged);
        }
        Ok(replace)
    }

    /// The index `wf history` kept before it was ctx (1.5 GB on the first machine measured).
    /// Removed only after ctx has converged, never on the way to a release that pins nothing.
    fn forget_reimplemented_history(&self) {
        let state = &self.paths.state_dir;
        let _ = std::fs::remove_dir_all(state.join("history"));
        for name in ["history.pid", "history.spawn.lock"] {
            let _ = std::fs::remove_file(state.join(name));
        }
    }
}

fn expect_version(bin: &Path, version: &str) -> Result<()> {
    let got = running_version(bin).unwrap_or_default();
    if got == version {
        return Ok(());
    }
    Err(Error::failure(
        "CTX-VERSION",
        format!(
            "{} reports version {got:?}; the lock pins {version}",
            bin.display()
        ),
    )
    .with_zh(zh("CTX-VERSION")))
}

/// Upstream's order after an unmanaged install or upgrade, then the semantic opt-in this
/// organization chose. Every step is idempotent, which is what makes a retry safe.
fn lifecycle(installed: &Path, logs: &Path) -> Result<()> {
    for (args, secs) in [
        (&["index", "mode", "auto"][..], 120),
        (&["setup", "--format", "json"][..], 3_600),
        (&["semantic", "enable"][..], 120),
    ] {
        let why = match run(installed, args, logs, Duration::from_secs(secs)) {
            Ok((true, _)) => continue,
            Ok((false, _)) => "exited non-zero".to_string(),
            Err(e) => e.message,
        };
        return Err(Error::failure(
            "CTX-SETUP",
            format!("`ctx {}` {why}; see {}", args.join(" "), logs.display()),
        )
        .with_zh(zh("CTX-SETUP")));
    }
    Ok(())
}

fn handoff(installed: &Path, logs: &Path) -> Result<()> {
    let refused = |why: String| Error::failure("CTX-HANDOFF", why).with_zh(zh("CTX-HANDOFF"));
    let (ok, stdout) = run(
        installed,
        &["daemon", "disable", "--prepare-uninstall", "--format=json"],
        logs,
        Duration::from_secs(120),
    )
    .map_err(|e| refused(e.message))?;
    if ok && receipt(&stdout).is_some_and(|r| quiescent(&r)) {
        return Ok(());
    }
    // A ctx from before 1.0 has no daemon, so there is nothing to hand off and nothing that
    // can run on after the binary is replaced. Its argument parser says so before doing
    // anything; any other refusal still stops the replacement.
    if !ok && predates_daemon(&std::fs::read_to_string(logs.join("daemon-disable.err"))?) {
        return Ok(());
    }
    Err(refused(format!(
        "{} did not report a quiescent installation; see {}",
        installed.display(),
        logs.join("daemon-disable.err").display()
    )))
}

/// The receipt is one JSON object; tolerate a line of chatter printed before it.
fn receipt(stdout: &str) -> Option<serde_json::Value> {
    serde_json::from_str::<serde_json::Value>(stdout.trim())
        .ok()
        .or_else(|| {
            stdout
                .lines()
                .rev()
                .find_map(|line| serde_json::from_str(line.trim()).ok())
        })
        .filter(serde_json::Value::is_object)
}

fn quiescent(receipt: &serde_json::Value) -> bool {
    receipt["scope"] == "installation" && QUIESCENT.iter().all(|k| receipt[*k] == true)
}

/// Walk `tree` without following links and refuse it when anything in it is a symlink or any
/// directory a mount point: a tree wf moves or removes whole must hold only what wf put there.
fn refuse_links_and_mounts(tree: &Path) -> Result<()> {
    for entry in walkdir::WalkDir::new(tree).follow_links(false) {
        let entry = entry.map_err(|e| Error::failure("CTX-RUNTIME", e.to_string()))?;
        if entry.file_type().is_symlink() {
            return Err(Error::failure(
                "CTX-RUNTIME",
                format!("{} is a symlink", entry.path().display()),
            )
            .with_zh(zh("CTX-RUNTIME")));
        }
        if entry.file_type().is_dir() {
            refuse_mounted(entry.path())?;
        }
    }
    Ok(())
}

/// A mount point where the runtime lives is somebody else's filesystem or directory, bound
/// there; moving it or removing what is under it would reach past what wf installed.
fn refuse_mounted(path: &Path) -> Result<()> {
    if wf_core::paths::mount_root(path)? {
        return Err(Error::failure(
            "CTX-RUNTIME",
            format!("{} is a mount point", path.display()),
        )
        .with_zh(zh("CTX-RUNTIME")));
    }
    Ok(())
}

/// clap's refusal of the `daemon` subcommand, which ctx gained in 1.0 together with the
/// daemon itself (0.23.0 prints exactly this and exits 2).
fn predates_daemon(stderr: &str) -> bool {
    stderr
        .lines()
        .any(|line| line.trim() == "error: unrecognized subcommand 'daemon'")
}

/// Run ctx with its output in files rather than pipes, waiting on that one process.
///
/// `proc::run` reads pipes to their end and, at its deadline, kills the whole process group.
/// A ctx command may start the daemon; a daemon holding those pipes would make the call wait
/// out its deadline and then kill the very daemon it was asked to start.
fn run(bin: &Path, args: &[&str], logs: &Path, timeout: Duration) -> Result<(bool, String)> {
    std::fs::create_dir_all(logs)?;
    let name = args
        .iter()
        .take_while(|a| !a.starts_with('-'))
        .copied()
        .collect::<Vec<_>>()
        .join("-");
    let out = logs.join(format!("{name}.out"));
    let err = logs.join(format!("{name}.err"));
    let mut child = std::process::Command::new(bin)
        .args(args)
        .env("NO_COLOR", "1")
        .stdin(std::process::Stdio::null())
        .stdout(std::fs::File::create(&out)?)
        .stderr(std::fs::File::create(&err)?)
        .spawn()?;
    let deadline = Instant::now() + timeout;
    loop {
        if let Some(status) = child.try_wait()? {
            return Ok((
                status.success(),
                std::fs::read_to_string(&out).unwrap_or_default(),
            ));
        }
        if Instant::now() >= deadline {
            let _ = child.kill();
            let _ = child.wait();
            return Err(Error::failure(
                "CTX-TIMEOUT",
                format!(
                    "did not finish within {}s; see {}",
                    timeout.as_secs(),
                    err.display()
                ),
            ));
        }
        std::thread::sleep(Duration::from_millis(50));
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_handoff_receipt_needs_every_named_field_and_tolerates_new_ones() {
        let full = r#"{"ok":true,"scope":"installation","installation_quiescent":true,"supervisor_removed":true,"owner_lock_released":true,"endpoint_released":true,"coordination_state_removed":true,"binary_retained":true,"added_upstream_later":false}"#;
        assert!(quiescent(&receipt(full).unwrap()));
        // A warning line before the receipt is not a reason to refuse it.
        assert!(
            receipt(&format!("note: legacy root ignored\n{full}\n")).is_some_and(|r| quiescent(&r))
        );

        let missing = full.replace(r#""endpoint_released":true,"#, "");
        assert!(!quiescent(&receipt(&missing).unwrap()));
        let not_installation = full.replace(r#""scope":"installation""#, r#""scope":"root""#);
        assert!(!quiescent(&receipt(&not_installation).unwrap()));
        assert!(receipt("error: unrecognized subcommand 'disable'").is_none());
    }

    /// The walk every tree wf moves or removes passes through: a plain tree passes, a link
    /// anywhere in it refuses it.
    #[test]
    fn a_tree_with_a_link_in_it_is_refused() {
        let dir = tempfile::tempdir().unwrap();
        let tree = dir.path().join("runtime");
        std::fs::create_dir_all(tree.join("lib")).unwrap();
        std::fs::write(tree.join("lib/libonnxruntime.so"), b"\x7fELF").unwrap();
        refuse_links_and_mounts(&tree).unwrap();

        std::os::unix::fs::symlink(dir.path(), tree.join("lib/elsewhere")).unwrap();
        let err = refuse_links_and_mounts(&tree).unwrap_err();
        assert_eq!(err.kind, "CTX-RUNTIME");
        assert!(err.message.contains("is a symlink"), "{}", err.message);
    }

    /// A mount point refuses the tree, from the same walk: `/proc` is a mount root on every
    /// Linux host and container, so this runs in CI where a bind mount of its own cannot.
    #[test]
    #[cfg(target_os = "linux")]
    fn a_tree_that_is_a_mount_point_is_refused() {
        let err = refuse_links_and_mounts(Path::new("/proc")).unwrap_err();
        assert_eq!(err.kind, "CTX-RUNTIME");
        assert!(err.message.contains("is a mount point"), "{}", err.message);
    }

    #[test]
    fn only_a_ctx_without_the_daemon_command_skips_the_handoff() {
        // What ctx 0.23.0 prints for `daemon disable --prepare-uninstall --format=json`.
        let pre_1_0 = "error: unrecognized subcommand 'daemon'\n\nUsage: ctx [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.\n";
        assert!(predates_daemon(pre_1_0));
        // A ctx with a daemon that refuses, or a flag it does not know, keeps its daemon.
        assert!(!predates_daemon(
            "error: unexpected argument '--prepare-uninstall' found\n"
        ));
        assert!(!predates_daemon(
            "Error: daemon did not stop within the handoff deadline\n"
        ));
        assert!(!predates_daemon(""));
    }

    #[test]
    fn the_key_names_the_runtime_so_a_machine_without_it_converges_again() {
        let binary = BinaryRef {
            target: "x86_64-unknown-linux-gnu".into(),
            asset: "ctx-linux-x64".into(),
            sha256: "b".repeat(64),
        };
        let mut pin = CtxUpstream {
            version: "1.5.0".into(),
            binaries: vec![binary.clone()],
            ..CtxUpstream::none()
        };
        let target = "x86_64-unknown-linux-gnu";
        assert_eq!(
            desired_key(&pin, target).unwrap(),
            format!("{}:-", "b".repeat(64))
        );
        pin.runtimes.push(BinaryRef {
            asset: "ctx-onnxruntime-linux-x64.tar.gz".into(),
            sha256: "r".repeat(64),
            ..binary
        });
        let key = desired_key(&pin, target).unwrap();
        assert_eq!(key, format!("{}:{}", "b".repeat(64), "r".repeat(64)));
        // What a machine converged by an earlier wf recorded: the binary alone.
        assert_ne!(key, "b".repeat(64));
        assert!(desired_key(&pin, "aarch64-apple-darwin").is_none());
    }

    #[test]
    fn every_recorded_failure_has_its_own_fix() {
        for kind in [
            "CTX-HANDOFF",
            "CTX-FOREIGN",
            "CTX-INTEGRITY",
            "CTX-SETUP",
            "CTX-RUNTIME",
        ] {
            assert_ne!(zh(kind), zh("CTX-SOMETHING-ELSE"), "{kind}");
        }
    }
}
