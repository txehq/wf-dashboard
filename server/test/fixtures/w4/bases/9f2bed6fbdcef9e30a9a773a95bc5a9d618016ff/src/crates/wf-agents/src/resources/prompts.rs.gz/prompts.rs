//! The organization prompt: a managed block in the instructions file each agent reads, or a
//! whole steering file for agents that read steering instead.

use super::object::{Rendered, Shape};
use super::{registry_payload, ResourceHandler, ResourceItem, ResourceKind, ResourceMetadata};
use crate::formats::{codex, PromptFormat};
use crate::{adapter::TeamAIAdapter, registry::PathKind, team_repo::TeamRepo};
use wf_core::Result;

pub struct PromptsHandler;

/// The block id a prompt component owns: `capso.prompt.global` → `capso.global`, the id every
/// release has written into `CLAUDE.md` and `AGENTS.md`.
pub fn block_id(component_id: &str) -> String {
    component_id.replacen(".prompt.", ".", 1)
}

impl ResourceHandler for PromptsHandler {
    fn kind(&self) -> ResourceKind {
        ResourceKind::Prompt
    }

    fn scan_registry(&self, repo: &TeamRepo) -> Result<Vec<ResourceItem>> {
        let root = repo.root()?;
        let registry = repo.registry()?;
        let mut out = Vec::new();
        for c in registry.of_kind(wf_registry::Kind::PromptBlock) {
            let Some(source) = c.source.as_deref() else {
                continue;
            };
            let path = root.join(source);
            let body = std::fs::read_to_string(&path)?;
            let mut payload = registry_payload(c);
            payload.insert("body".into(), body.clone().into());
            out.push(ResourceItem {
                id: block_id(&c.id),
                name: c.id.clone(),
                kind: ResourceKind::Prompt,
                version: None,
                source: path,
                metadata: ResourceMetadata {
                    content_hash: wf_core::hash::sha256_bytes(body.as_bytes()),
                    component_id: Some(c.id.clone()),
                    placement: None,
                    payload: payload.into(),
                },
            });
        }
        Ok(out)
    }

    fn render(&self, item: &ResourceItem, agent: &dyn TeamAIAdapter) -> Result<Option<Rendered>> {
        let (Some(format), Some(path)) = (agent.formats().prompt, agent.path(PathKind::Prompt))
        else {
            return Ok(None);
        };
        let body = item.metadata.payload["body"]
            .as_str()
            .unwrap_or_default()
            .to_string();
        Ok(Some(match format {
            PromptFormat::Append => Rendered::Block {
                path,
                id: item.id.clone(),
                body,
                placement: wf_prompts::Placement::Append,
                shadow: None,
            },
            PromptFormat::CodexEffective => {
                let root = path.parent().unwrap_or(&path).to_path_buf();
                let effective = codex::effective_prompt_file(&root)?;
                let shadow = codex::shadow_prompt_file(&root, &effective);
                Rendered::Block {
                    path: effective,
                    id: item.id.clone(),
                    body,
                    placement: wf_prompts::Placement::Prepend,
                    shadow: Some(shadow),
                }
            }
            PromptFormat::SteeringFile => Rendered::File {
                path,
                bytes: format!("---\ninclusion: always\n---\n\n{body}").into_bytes(),
            },
        }))
    }

    fn shape(&self, agent: &dyn TeamAIAdapter) -> Option<Shape> {
        agent.path(PathKind::Prompt)?;
        self.stored_shape(agent)
    }

    fn stored_shape(&self, agent: &dyn TeamAIAdapter) -> Option<Shape> {
        let path = agent.path(PathKind::Prompt)?;
        Some(match agent.formats().prompt? {
            PromptFormat::Append => Shape::Block { shadows: vec![] },
            // Which of the pair Codex reads is a question about the file's contents today;
            // which files the block must be gone from is the whole pair, either way.
            PromptFormat::CodexEffective => {
                let root = path.parent().unwrap_or(&path);
                Shape::Block {
                    shadows: vec![root.join("AGENTS.md"), root.join("AGENTS.override.md")],
                }
            }
            PromptFormat::SteeringFile => Shape::File,
        })
    }

    fn marker_owned(&self) -> bool {
        true
    }
}
