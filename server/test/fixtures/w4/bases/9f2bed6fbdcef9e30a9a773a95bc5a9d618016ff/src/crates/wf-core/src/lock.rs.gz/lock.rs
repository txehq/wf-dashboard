use std::fs::{File, OpenOptions};
use std::io::{Seek, Write};
use std::mem::ManuallyDrop;
use std::os::fd::AsRawFd;
use std::os::unix::fs::{MetadataExt, OpenOptionsExt};
use std::path::Path;
use std::sync::Mutex;
use std::time::{Duration, Instant};

/// Process-owned POSIX record locks are released when wf exits and are not inherited by
/// forked children. Keep the inode permanent: owner text is diagnostic, never permission
/// to unlink a contended lock. The in-process registry prevents threads from acquiring the
/// same process lock twice, or closing another descriptor and releasing the first lock.
#[derive(Debug)]
pub struct Guard {
    _file: ManuallyDrop<File>,
    identity: (u64, u64),
}

static HELD: Mutex<Vec<(u64, u64)>> = Mutex::new(Vec::new());

impl Drop for Guard {
    fn drop(&mut self) {
        let mut held = HELD.lock().unwrap_or_else(|e| e.into_inner());
        // Close before another thread may open this inode. POSIX closes release all of
        // this process's locks on that inode, including locks taken through another fd.
        unsafe {
            ManuallyDrop::drop(&mut self._file);
        }
        held.retain(|id| *id != self.identity);
    }
}

impl Guard {
    pub fn try_exclusive(path: &Path) -> crate::Result<Self> {
        Self::acquire(path, true)
    }

    pub fn exclusive_within(path: &Path, ms: u64) -> crate::Result<Self> {
        let deadline = Instant::now() + Duration::from_millis(ms);
        loop {
            match Self::try_exclusive(path) {
                Ok(guard) => return Ok(guard),
                Err(e) if e.code == crate::ExitCode::Conflict && Instant::now() < deadline => {
                    std::thread::sleep(Duration::from_millis(10));
                }
                Err(e) => return Err(e),
            }
        }
    }

    pub fn try_shared(path: &Path) -> crate::Result<Self> {
        Self::acquire(path, false)
    }

    fn acquire(path: &Path, exclusive: bool) -> crate::Result<Self> {
        let mut held = HELD.lock().unwrap_or_else(|e| e.into_inner());
        // Stat before opening: even opening and closing a hard-link alias of an inode
        // already locked by this process would release its current record lock.
        if let Ok(meta) = std::fs::metadata(path) {
            if held.contains(&(meta.dev(), meta.ino())) {
                return Err(conflict());
            }
        }
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        let file = OpenOptions::new()
            .create(true)
            .read(true)
            .write(true)
            .truncate(false)
            .mode(0o600)
            .open(path)?;
        let meta = file.metadata()?;
        let identity = (meta.dev(), meta.ino());
        // SAFETY: all-zero flock fields are valid; the fields below define the whole file.
        let mut lock: libc::flock = unsafe { std::mem::zeroed() };
        lock.l_type = if exclusive {
            libc::F_WRLCK
        } else {
            libc::F_RDLCK
        } as _;
        lock.l_whence = libc::SEEK_SET as _;
        if unsafe { libc::fcntl(file.as_raw_fd(), libc::F_SETLK, &lock) } == -1 {
            let err = std::io::Error::last_os_error();
            return Err(
                if matches!(err.raw_os_error(), Some(libc::EACCES) | Some(libc::EAGAIN)) {
                    conflict()
                } else {
                    err.into()
                },
            );
        }
        let current = std::fs::metadata(path)?;
        if (current.dev(), current.ino()) != identity {
            return Err(conflict());
        }
        if exclusive {
            let mut writer = &file;
            writer.set_len(0)?;
            writer.rewind()?;
            write!(
                writer,
                "{}:{}",
                std::process::id(),
                crate::time_fmt::now_unix()
            )?;
            writer.flush()?;
        }
        held.push(identity);
        Ok(Self {
            _file: ManuallyDrop::new(file),
            identity,
        })
    }
}

fn conflict() -> crate::Error {
    crate::Error::conflict("LOCK-HELD", "another wf process holds the state lock")
        .with_zh("另一个 wf 正在更新，本次先跳过。稍后再运行即可，不需要处理。".to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn subprocess_lock_probe() {
        let Some(path) = std::env::var_os("WF_TEST_LOCK_PATH") else {
            return;
        };
        let should_acquire = std::env::var("WF_TEST_LOCK_EXPECT").unwrap() == "free";
        assert_eq!(
            Guard::try_exclusive(Path::new(&path)).is_ok(),
            should_acquire
        );
    }

    fn child_probe(path: &Path, expected: &str) {
        let output = std::process::Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "lock::tests::subprocess_lock_probe",
                "--nocapture",
            ])
            .env("WF_TEST_LOCK_PATH", path)
            .env("WF_TEST_LOCK_EXPECT", expected)
            .output()
            .unwrap();
        assert!(
            output.status.success(),
            "{}",
            String::from_utf8_lossy(&output.stdout)
        );
    }

    #[test]
    fn missing_owner_metadata_cannot_steal_a_live_lock() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("lock");
        let held = Guard::try_exclusive(&path).unwrap();
        held._file.set_len(0).unwrap();
        child_probe(&path, "busy");
        drop(held);
        child_probe(&path, "free");
    }

    #[test]
    fn one_writer_at_a_time() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("lock");
        let held = Guard::try_exclusive(&path).unwrap();
        assert_eq!(
            Guard::try_exclusive(&path).unwrap_err().code,
            crate::ExitCode::Conflict
        );
        drop(held);
        assert!(Guard::try_exclusive(&path).is_ok());
    }

    #[test]
    fn a_second_thread_in_this_process_still_waits() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("lock");
        let _held = Guard::try_exclusive(&path).unwrap();
        assert!(
            !std::thread::spawn(move || Guard::try_exclusive(&path).is_ok())
                .join()
                .unwrap()
        );
    }

    #[test]
    fn aliases_do_not_close_a_live_process_lock() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("lock");
        let alias = dir.path().join("alias");
        let _held = Guard::try_exclusive(&path).unwrap();
        std::fs::hard_link(&path, &alias).unwrap();
        assert!(Guard::try_exclusive(&alias).is_err());
        child_probe(&path, "busy");
    }

    #[test]
    fn forked_descriptors_do_not_keep_the_lock_after_release() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("lock");
        let held = Guard::try_exclusive(&path).unwrap();
        let inode = std::fs::metadata(&path).unwrap().ino();
        let pid = unsafe { libc::fork() };
        assert!(pid >= 0);
        if pid == 0 {
            // Only async-signal-safe syscalls after fork from the multithreaded test host.
            unsafe {
                libc::sleep(5);
                libc::_exit(0);
            }
        }
        drop(held);
        let acquired = Guard::try_exclusive(&path);
        unsafe {
            libc::kill(pid, libc::SIGKILL);
            libc::waitpid(pid, std::ptr::null_mut(), 0);
        }
        assert!(acquired.is_ok());
        assert_eq!(
            std::fs::metadata(&path).unwrap().ino(),
            inode,
            "lock inode was replaced"
        );
    }

    #[test]
    fn waiting_gives_up_at_the_deadline_rather_than_hanging() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("lock");
        let _held = Guard::try_exclusive(&path).unwrap();
        let start = Instant::now();
        assert!(Guard::exclusive_within(&path, 100).is_err());
        assert!(start.elapsed() < Duration::from_secs(1));
    }
}
