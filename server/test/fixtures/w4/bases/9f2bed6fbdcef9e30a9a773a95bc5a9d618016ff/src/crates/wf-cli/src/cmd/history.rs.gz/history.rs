//! `wf history` is ctx (ADR-0006).
//!
//! Not a wrapper: the process becomes ctx, with every argument unchanged. That is what lets
//! `wf history mcp serve` be the workflow's MCP server with no proxy in the stdio path, and
//! what keeps this command from ever disagreeing with ctx's own documentation.

use std::ffi::OsString;
use wf_core::{Error, ExitCode, Result};

pub fn run(args: Vec<OsString>) -> Result<ExitCode> {
    let paths = wf_core::paths::Paths::resolve()?;
    // The MCP server the agent layer writes into every managed agent runs this command, so
    // its tool surface is only ever ctx at the digest this generation pinned. A person
    // typing `wf history` interactively gets whichever ctx this machine has.
    if serves_mcp(&args) {
        let Some(ctx) = wf_sync::ctx::pinned_binary(&paths) else {
            return Err(Error::failure(
                "CTX-FOREIGN",
                format!(
                    "no verified ctx in {}; wf will not serve its history tools from a ctx it \
                     did not install",
                    paths.bin_dir.display()
                ),
            )
            .with_zh(wf_sync::ctx::zh("CTX-FOREIGN")));
        };
        return exec(&ctx, &args);
    }
    let Some(ctx) = wf_sync::ctx::binary(&paths) else {
        return Err(Error::failure(
            "CTX-MISSING",
            format!("no ctx in {} and none on PATH", paths.bin_dir.display()),
        )
        .with_zh("这台机器上还没有 ctx。运行 `wf install` 装上它。"));
    };
    // The flags /history documents are those of the ctx this release pins. Another ctx may
    // take different ones (before 1.0, `--json` in place of `--format json`), and its parse
    // error names only ctx — so say whose ctx this is before handing over.
    if wf_sync::ctx::pinned_binary(&paths).is_none() {
        eprintln!(
            "wf history：{} 不是 wf 安装的 ctx，参数和输出以它自己的 `--help` 为准。运行 `wf doctor` 看怎么换成这个版本锁定的 ctx。",
            ctx.display()
        );
    }
    exec(&ctx, &args)
}

/// `wf history mcp serve …` — the argv `workflow/mcps/history.yaml` deploys.
fn serves_mcp(args: &[OsString]) -> bool {
    args.first().is_some_and(|a| a == "mcp") && args.get(1).is_some_and(|a| a == "serve")
}

#[cfg(unix)]
fn exec(ctx: &std::path::Path, args: &[OsString]) -> Result<ExitCode> {
    use std::os::unix::process::CommandExt;
    // Returns only if the exec itself failed.
    let error = std::process::Command::new(ctx).args(args).exec();
    Err(
        Error::failure("CTX-EXEC", format!("{}: {error}", ctx.display()))
            .with_zh("ctx 启动不了。运行 `wf doctor` 看看是哪里出了问题。"),
    )
}

#[cfg(not(unix))]
fn exec(ctx: &std::path::Path, args: &[OsString]) -> Result<ExitCode> {
    let status = std::process::Command::new(ctx).args(args).status()?;
    Ok(if status.success() {
        ExitCode::Ok
    } else {
        ExitCode::Failure
    })
}
