use super::emit;
use crate::flags::BackupCmd;
use wf_core::{envelope::Envelope, ExitCode, Result};
use wf_state::Db;

pub fn run(json: bool, cmd: BackupCmd) -> Result<ExitCode> {
    let paths = wf_core::paths::Paths::resolve()?;
    let read_only = matches!(cmd, BackupCmd::List);
    let db = if read_only {
        Db::open_read_only(&paths.db())?
    } else {
        Db::open(&paths.db())?
    };
    let _guard = if read_only {
        None
    } else {
        Some(wf_core::lock::Guard::exclusive_within(
            &paths.lock_file(),
            30_000,
        )?)
    };
    let store = wf_state::backup::Store::new(&db, paths.backups());

    match cmd {
        BackupCmd::List => {
            let items = store.list()?;
            let env = Envelope::new("backup list").result(&items);
            let list = items.clone();
            Ok(emit(json, env, move || {
                if list.is_empty() {
                    return "还没有任何备份——wf 还没有覆盖过你的文件。\n".to_string();
                }
                let mut s = String::from("编号　　　　　　　　　时间　　　　文件\n");
                for b in &list {
                    s.push_str(&format!(
                        "{:<22} {:<12} {}{}\n",
                        b.backup_id,
                        wf_core::time_fmt::age_zh(b.at),
                        b.original_path,
                        if b.restored_at.is_some() {
                            "（已还原过）"
                        } else {
                            ""
                        }
                    ));
                }
                s.push_str("\n想还原其中一份：wf backup restore <编号>\n");
                s
            }))
        }
        BackupCmd::Restore { id } => {
            let (restored, counter) = store.restore(&id)?;
            let env = Envelope::new("backup restore").result(serde_json::json!({
                "restored": restored,
                "counter_backup": counter.backup_id,
            }));
            Ok(emit(json, env, move || {
                format!(
                    "已还原 {}。\n还原之前的内容也备份了一份，编号 {}——如果还原错了，用它可以再换回来。\n",
                    restored.original_path, counter.backup_id
                )
            }))
        }
        BackupCmd::Prune => {
            let n = store.prune()?;
            let env = Envelope::new("backup prune").result(serde_json::json!({ "removed": n }));
            Ok(emit(json, env, move || {
                format!("清理了 {n} 份过期备份。\n")
            }))
        }
    }
}
