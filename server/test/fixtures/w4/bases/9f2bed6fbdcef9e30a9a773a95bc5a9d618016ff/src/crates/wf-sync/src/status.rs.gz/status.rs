use serde::Serialize;
use wf_state::ComponentState;

/// One line of `wf status`. Enough to act on, nothing more — this is also what a session
/// start reads, and a session start is not a log viewer.
#[derive(Debug, Clone, Serialize)]
pub struct ComponentRow {
    pub id: String,
    pub kind: String,
    pub agent: String,
    pub state: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub detail: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub zh: String,
    /// Set when a person declined this server on this agent. The `state` beside it is
    /// `current`, because the machine is as they asked for it; this is what separates
    /// "deliberately not installed" from "installed and fine" in what a person reads.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub skipped_at: Option<String>,
}

#[derive(Debug, Clone, Serialize)]
pub struct Status {
    pub active_version: String,
    pub desired_version: String,
    pub channel: String,
    pub source: String,
    pub repo: String,
    pub branch: String,
    pub attested: bool,
    pub platform: String,
    /// Seconds since the last successful remote check; absent when there has never been one.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub stale_seconds: Option<i64>,
    pub stale: bool,
    pub reload_required: bool,
    pub healthy: bool,
    pub agents: Vec<AgentRow>,
    pub components: Vec<ComponentRow>,
    pub warnings: Vec<String>,
    pub backups: usize,
}

/// One managed agent: whether it is on this machine, and how much of what the team
/// repository offers it is in place.
#[derive(Debug, Clone, Serialize)]
pub struct AgentRow {
    pub agent: String,
    pub display_name: String,
    pub installed: bool,
    /// Objects as they should be: current, kept, skipped by policy, or declined by the
    /// person on this machine. A decision of theirs is a settled object — counting it as
    /// outstanding would turn `n/n` into `n-1/n` for a machine with nothing wrong with it.
    pub current: usize,
    pub total: usize,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub effective_prompt_file: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub hook_trusted: Option<bool>,
}

/// One block of component rows under its heading, or nothing when the block is empty.
///
/// The agent is part of every entry. Both shipped MCPs are `agent-oauth` and the credential
/// question is asked once per agent, so a component appears twice; without the agent the two
/// entries are the same id twice over with different text under it, which reads as two things
/// to do rather than one component seen from two sides. Continuation lines are indented past
/// the entry's own prefix for the same reason — several of these sentences are three lines
/// long, and at equal indentation there is no boundary between one entry and the next.
fn section(out: &mut String, heading: &str, rows: &[&ComponentRow]) {
    if rows.is_empty() {
        return;
    }
    out.push_str(heading);
    for c in rows {
        let body = if c.zh.is_empty() {
            wf_core::zh::state_word(&c.state)
        } else {
            c.zh.clone()
        };
        out.push_str(&format!(
            "  {}（{}）— {}\n",
            c.id,
            c.agent,
            body.replace('\n', "\n  ")
        ));
    }
}

impl Status {
    /// The human rendering. `wf status` prints this; it is the first thing anybody reads
    /// when something is wrong, so it leads with the verdict and follows with the reason.
    pub fn render_zh(&self) -> String {
        let mut s = String::new();
        let head = if self.healthy {
            "一切正常"
        } else {
            "有问题需要处理"
        };
        s.push_str(&format!(
            "{head}　当前版本 {}",
            if self.active_version.is_empty() {
                "（还没有安装）"
            } else {
                &self.active_version
            }
        ));
        if !self.desired_version.is_empty() && self.desired_version != self.active_version {
            s.push_str(&format!("，最新版本 {}", self.desired_version));
        }
        s.push('\n');
        s.push_str(&format!("来源　{}（{}）\n", self.source, self.channel));

        for a in &self.agents {
            let mark = if !a.installed {
                "未安装".to_string()
            } else if a.current == a.total {
                format!("{} 项都已就位", a.total)
            } else {
                format!("{}/{} 项已就位", a.current, a.total)
            };
            s.push_str(&format!("  {:<12} {mark}\n", a.agent));
        }

        // A declined server is never in any list a person is asked to act on. It is not a
        // fault, it is what they told this machine to do, and printing it under 需要处理 is
        // the warning the whole feature exists to stop.
        let by_state = |want: fn(ComponentState) -> bool| -> Vec<&ComponentRow> {
            self.components
                .iter()
                .filter(|c| c.skipped_at.is_none() && want(ComponentState::parse(&c.state)))
                .collect()
        };
        section(&mut s, "\n需要处理：\n", &by_state(|st| !st.is_healthy()));
        // Healthy, so it is not in the block above — and still worth a line, because a person
        // asked. The session-start hook stays silent on these; see the note in session.rs.
        // What this must not do is claim the component works: it says what was not looked at,
        // and names the only thing that settles it.
        section(
            &mut s,
            "\n装好了，但这里看不出登录状态：\n",
            &by_state(|st| st == ComponentState::Unverified),
        );
        // Not checked, because there is nothing of ours to check: the person said not to
        // install it. Kept visible so that "why is Linear not here?" has an answer on the
        // machine itself, and so nobody goes looking for a fault that was a decision.
        let declined: Vec<&ComponentRow> = self
            .components
            .iter()
            .filter(|c| c.skipped_at.is_some())
            .collect();
        if !declined.is_empty() {
            s.push_str("\n没有检查，你要求不装的：\n");
            for c in &declined {
                let day = c
                    .skipped_at
                    .as_deref()
                    .and_then(|at| at.split('T').next())
                    .unwrap_or_default();
                s.push_str(&format!("  {:<28} {:<12} {day}\n", c.id, c.agent));
            }
            s.push_str("  想装回来就运行 `wf mcp unskip <名字>`。\n");
        }
        for w in &self.warnings {
            s.push_str(&format!("\n{w}\n"));
        }
        s
    }
}
