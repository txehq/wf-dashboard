//! `mcp-remote` bridges nobody holds any more (txe-workflow#61).
//!
//! An agent launches each of our remote servers as `npx -y mcp-remote <url>`: `npm exec`, a
//! shell, then node. A bridge that is waiting on a browser sign-in does not read its input,
//! so when the agent gives up on it or exits — `claude mcp get` after its 30 s limit, a
//! `claude -p` that has answered — nothing ends the chain, and it keeps running under the init
//! process. It keeps the sign-in with it: `mcp-remote` lets one process per server URL run the
//! sign-in, on a callback port derived from that URL, and every later bridge for the URL waits
//! on it ("Another instance is running the sign-in for this server") without printing the page
//! to open. On a machine with no browser nobody ever saw the page the leftover printed, so the
//! wait does not end.
//!
//! Only bridges `wf` installed are reported (WFR-016). Every stdio server it writes is launched
//! with `WF_MCP_COMPONENT=<component id>` in its environment, and every process of the chain
//! inherits it; a bridge to the same URL without it — one the person started, or another
//! server of theirs — is not ours to report or to suggest killing.

use crate::formats::{McpDef, COMPONENT_ENV};
use serde::Serialize;
use std::collections::BTreeMap;
use std::path::Path;
use sysinfo::{Pid, ProcessRefreshKind, ProcessesToUpdate, System, UpdateKind};
use wf_core::{Error, Result};

/// The leftover processes of one of our servers' bridges.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct Ownerless {
    pub server: String,
    pub url: String,
    /// Every process of every leftover chain — `npm exec`, its shell and node — so one `kill`
    /// ends all of it.
    pub pids: Vec<u32>,
}

/// One row of the process table, as much of it as this question needs.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Process {
    pub pid: u32,
    pub parent: Option<u32>,
    pub name: String,
    pub words: Vec<String>,
    /// `WF_MCP_COMPONENT` from its environment: the component `wf` launched it as.
    pub component: Option<String>,
}

/// The URL a definition bridges to, when it is an `mcp-remote` bridge.
pub fn bridge_url(def: &McpDef) -> Option<&str> {
    let at = def.args.iter().position(|a| is_bridge_word(a))?;
    def.args[at + 1..]
        .iter()
        .find(|a| a.starts_with("https://") || a.starts_with("http://"))
        .map(String::as_str)
}

/// Every MCP definition the bundle at `root` ships, parsed and validated the way an install
/// reads them.
pub fn shipped_definitions(root: &Path) -> Result<Vec<McpDef>> {
    let registry = wf_registry::Registry::load(root)?;
    let mut out = Vec::new();
    for component in registry.of_kind(wf_registry::Kind::Mcp) {
        let Some(source) = component.source.as_deref() else {
            continue;
        };
        let path = root.join(source);
        let text = std::fs::read_to_string(&path)
            .map_err(|e| Error::from(e).with_zh(format!("找不到 {source}。")))?;
        let mut def = McpDef::parse(&text, &path)?;
        def.component = Some(component.id.clone());
        def.validate()?;
        out.push(def);
    }
    Ok(out)
}

/// Our bridges on this machine whose client is gone.
pub fn ownerless(defs: &[McpDef]) -> Vec<Ownerless> {
    let mut system = System::new();
    system.refresh_processes_specifics(
        ProcessesToUpdate::All,
        true,
        ProcessRefreshKind::nothing()
            .with_cmd(UpdateKind::Always)
            .with_environ(UpdateKind::Always),
    );
    let tag = format!("{COMPONENT_ENV}=");
    let table: Vec<Process> = system
        .processes()
        .values()
        // Linux lists every thread as a task of its own; only the process is killed.
        .filter(|p| p.thread_kind().is_none())
        .map(|p| Process {
            pid: p.pid().as_u32(),
            parent: p.parent().map(Pid::as_u32),
            name: p.name().to_string_lossy().into_owned(),
            words: p
                .cmd()
                .iter()
                .flat_map(|arg| {
                    // `npm exec` rewrites its own title into one argument with spaces in it.
                    arg.to_string_lossy()
                        .split_whitespace()
                        .map(str::to_string)
                        .collect::<Vec<_>>()
                })
                .collect(),
            component: p.environ().iter().find_map(|var| {
                var.to_string_lossy()
                    .strip_prefix(tag.as_str())
                    .map(str::to_string)
            }),
        })
        .collect();
    find(&table, defs)
}

/// The same answer over a table already read.
pub fn find(table: &[Process], defs: &[McpDef]) -> Vec<Ownerless> {
    let by_pid: BTreeMap<u32, &Process> = table.iter().map(|p| (p.pid, p)).collect();
    let mut out = Vec::new();
    for def in defs {
        let (Some(url), Some(component)) = (bridge_url(def), def.component.as_deref()) else {
            continue;
        };
        let bridges = |p: &Process| {
            p.component.as_deref() == Some(component)
                && p.words.iter().any(|w| is_bridge_word(w))
                && p.words.iter().any(|w| w == url)
        };
        // Each bridge process under the top of its chain: up the chain while the parent is
        // part of the same bridge. The first process above it is the bridge's client, or the
        // init process that inherited it.
        let mut chains: BTreeMap<u32, (bool, Vec<&Process>)> = BTreeMap::new();
        for p in table.iter().filter(|p| bridges(p)) {
            let mut top = p;
            while let Some(parent) = top.parent.and_then(|pid| by_pid.get(&pid)) {
                if !bridges(parent) {
                    break;
                }
                top = parent;
            }
            let orphaned = match top.parent {
                None | Some(1) => true,
                Some(pid) => by_pid.get(&pid).is_some_and(|p| is_init(&p.name)),
            };
            let chain = chains.entry(top.pid).or_insert((orphaned, Vec::new()));
            chain.1.push(p);
        }
        // A chain that is only a shell is what is left once the bridge itself exited: it
        // holds no port and blocks no sign-in.
        let mut pids: Vec<u32> = chains
            .into_values()
            .filter(|(orphaned, members)| *orphaned && members.iter().any(|p| !is_shell(&p.name)))
            .flat_map(|(_, members)| members.into_iter().map(|p| p.pid))
            .collect();
        if pids.is_empty() {
            continue;
        }
        pids.sort_unstable();
        out.push(Ownerless {
            server: def.name.clone(),
            url: url.to_string(),
            pids,
        });
    }
    out
}

/// `npx` runs the package's binary through `sh -c 'mcp-remote' <url>`, quotes and all.
fn is_bridge_word(word: &str) -> bool {
    let word = word.trim_matches(['\'', '"']);
    word == "mcp-remote" || word.ends_with("/mcp-remote")
}

/// The processes an orphan is handed to: PID 1 under any name, and a service manager acting
/// as the subreaper of a desktop session (`systemd --user`).
fn is_init(name: &str) -> bool {
    matches!(name, "systemd" | "init" | "launchd")
}

fn is_shell(name: &str) -> bool {
    matches!(name, "sh" | "bash" | "dash" | "zsh")
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::process::{Command, Stdio};
    use std::time::{Duration, Instant};

    /// A definition as the registry hands it on: its component is `capso.mcp.<name>`.
    fn def(name: &str, url: &str) -> McpDef {
        let mut def = McpDef::parse(
            &format!("name: {name}\ncommand: npx\nargs: [\"-y\", \"mcp-remote\", \"{url}\"]\n"),
            Path::new("x.yaml"),
        )
        .unwrap();
        def.component = Some(format!("capso.mcp.{name}"));
        def
    }

    /// A process launched by the agent with `capso-linear`'s entry, tag and all.
    fn row(pid: u32, parent: u32, name: &str, command: &str) -> Process {
        Process {
            component: Some("capso.mcp.capso-linear".into()),
            ..theirs(pid, parent, name, command)
        }
    }

    /// The same process without the tag: something wf did not launch.
    fn theirs(pid: u32, parent: u32, name: &str, command: &str) -> Process {
        Process {
            pid,
            parent: Some(parent),
            name: name.into(),
            words: command.split_whitespace().map(str::to_string).collect(),
            component: None,
        }
    }

    /// A bridge to our URL that wf did not launch — the person's own, detached — is not ours
    /// to report, even when it is ownerless (WFR-016). A definition the registry did not hand
    /// on names no component, and is not looked for at all.
    #[test]
    fn a_bridge_without_our_tag_is_never_reported() {
        let url = "https://mcp.linear.app/mcp";
        let table = vec![
            theirs(1, 0, "systemd", "/sbin/init"),
            theirs(7000, 1, "npm exec", &format!("npm exec mcp-remote {url}")),
            theirs(
                7001,
                7000,
                "node",
                &format!("node /x/.bin/mcp-remote {url}"),
            ),
        ];
        assert!(find(&table, &[def("capso-linear", url)]).is_empty());

        let ours = vec![
            row(7000, 1, "npm exec", &format!("npm exec mcp-remote {url}")),
            row(
                7001,
                7000,
                "node",
                &format!("node /x/.bin/mcp-remote {url}"),
            ),
        ];
        let mut untagged = def("capso-linear", url);
        untagged.component = None;
        assert!(find(&ours, &[untagged]).is_empty());
        assert_eq!(
            find(&ours, &[def("capso-linear", url)])[0].pids,
            vec![7000, 7001]
        );
    }

    /// The shipped definitions are the ones read, and each bridges to its own service.
    #[test]
    fn the_shipped_bridges_are_found_by_their_url() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
        let defs = shipped_definitions(&root).unwrap();
        let urls: BTreeMap<&str, Option<&str>> = defs
            .iter()
            .map(|d| (d.name.as_str(), bridge_url(d)))
            .collect();
        assert_eq!(urls["capso-linear"], Some("https://mcp.linear.app/mcp"));
        assert_eq!(
            urls["capso-rackspace-spot"],
            Some("https://mcp.spot.rackspace.com/mcp")
        );
        assert_eq!(urls["wf-history"], None);
    }

    /// The shape txe-workflow#61 printed: one chain under PID 1 and one whose client is alive.
    /// The whole leftover chain is named, and the live one is not.
    #[test]
    fn a_chain_under_init_is_ownerless_and_a_chain_under_its_agent_is_not() {
        let url = "https://mcp.linear.app/mcp";
        let table = vec![
            row(1, 0, "systemd", "/sbin/init"),
            row(500, 1, "claude", "claude"),
            row(8762, 1, "npm exec", &format!("npm exec mcp-remote {url}")),
            row(8776, 8762, "sh", &format!("sh -c 'mcp-remote' {url}")),
            row(
                8777,
                8776,
                "node",
                &format!("node /x/.bin/mcp-remote {url}"),
            ),
            row(9000, 500, "npm exec", &format!("npm exec mcp-remote {url}")),
            row(9001, 9000, "sh", &format!("sh -c 'mcp-remote' {url}")),
            row(
                9002,
                9001,
                "node",
                &format!("node /x/.bin/mcp-remote {url}"),
            ),
            row(9100, 1, "grep", "grep mcp-remote"),
            // A shell left behind by a bridge that has already exited holds nothing.
            row(
                9200,
                1,
                "sh",
                &format!("sh -c sleep 1800 | npx -y mcp-remote {url}"),
            ),
        ];
        assert_eq!(
            find(&table, &[def("capso-linear", url)]),
            vec![Ownerless {
                server: "capso-linear".into(),
                url: url.into(),
                pids: vec![8762, 8776, 8777],
            }]
        );
    }

    /// A desktop session hands orphans to `systemd --user` rather than PID 1; somebody
    /// else's service URL is not ours to report.
    #[test]
    fn a_subreaper_counts_as_init_and_another_url_is_not_ours() {
        let table = vec![
            row(1200, 1, "systemd", "/usr/lib/systemd/systemd --user"),
            row(
                1300,
                1200,
                "node",
                "node /x/mcp-remote https://mcp.linear.app/mcp",
            ),
            row(
                1301,
                1,
                "node",
                "node /x/mcp-remote https://example.com/mcp",
            ),
        ];
        let found = find(&table, &[def("capso-linear", "https://mcp.linear.app/mcp")]);
        assert_eq!(found.len(), 1);
        assert_eq!(found[0].pids, vec![1300]);
    }

    /// A real orphan, made the way an agent leaves one: a shell that starts the bridge in the
    /// background and exits. The live process table is read, and a bridge whose parent is
    /// still running is left out.
    #[test]
    fn a_real_orphaned_bridge_is_found_in_the_live_process_table() {
        let base = format!("https://wf-test-{}.invalid", std::process::id());
        let (orphan, shell_only, owned, untagged) = (
            format!("{base}/orphan"),
            format!("{base}/shell"),
            format!("{base}/owned"),
            format!("{base}/theirs"),
        );
        let sleeper = ["python3", "-c", "import time; time.sleep(30)", "mcp-remote"];
        // A bridge process started in the background by a shell that then exits, with the
        // environment an agent gives a server wf installed.
        Command::new("sh")
            .args(["-c", "\"$@\" >/dev/null 2>&1 &", "sh"])
            .args(sleeper)
            .arg(&orphan)
            .env(COMPONENT_ENV, "capso.mcp.capso-orphan")
            .stdin(Stdio::null())
            .status()
            .unwrap();
        // The same, started without the tag: a bridge wf did not launch.
        Command::new("sh")
            .args(["-c", "\"$@\" >/dev/null 2>&1 &", "sh"])
            .args(sleeper)
            .arg(&untagged)
            .env_remove(COMPONENT_ENV)
            .stdin(Stdio::null())
            .status()
            .unwrap();
        // The shell that is left once a bridge itself has exited.
        Command::new("sh")
            .args(["-c", "\"$@\" >/dev/null 2>&1 &", "sh", "sh", "-c"])
            .arg(format!("sleep 30; : mcp-remote {shell_only}"))
            .env(COMPONENT_ENV, "capso.mcp.capso-shell")
            .stdin(Stdio::null())
            .status()
            .unwrap();
        // A bridge whose client is alive: this test.
        let mut child = Command::new(sleeper[0])
            .args(&sleeper[1..])
            .arg(&owned)
            .env(COMPONENT_ENV, "capso.mcp.capso-owned")
            .stdin(Stdio::null())
            .spawn()
            .unwrap();

        let defs = [
            def("capso-orphan", &orphan),
            def("capso-shell", &shell_only),
            def("capso-owned", &owned),
            def("capso-theirs", &untagged),
        ];
        let deadline = Instant::now() + Duration::from_secs(5);
        let found = loop {
            let found = ownerless(&defs);
            if !found.is_empty() || Instant::now() > deadline {
                break found;
            }
            std::thread::sleep(Duration::from_millis(50));
        };
        child.kill().unwrap();
        child.wait().unwrap();
        Command::new("pkill").args(["-f", &base]).status().unwrap();
        assert_eq!(found.len(), 1, "{found:?}");
        assert_eq!(found[0].server, "capso-orphan");
        assert_eq!(found[0].pids.len(), 1);
    }
}
