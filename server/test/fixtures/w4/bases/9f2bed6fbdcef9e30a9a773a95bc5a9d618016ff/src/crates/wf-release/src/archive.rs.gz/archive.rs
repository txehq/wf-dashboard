//! Archive extraction that assumes the bytes are hostile.
//!
//! Everything in a bundle arrived over a network and will be written into the operator's
//! home directory by a process that runs at every session start. The list of refusals below
//! is not defensive decoration; each one is a way an archive has historically escaped its
//! destination, and none of them can be caught after the fact.
//!
//! The other half of the contract is atomicity: nothing is written to the destination until
//! the whole archive has been read and checked. A half-extracted generation is exactly the
//! state the sync design says must never exist.

use std::collections::HashMap;
use std::io::Read;
use std::path::{Path, PathBuf};
use wf_core::{Error, Result};

/// Ceilings an archive may not exceed. When a lock is available these come from it; the
/// defaults are what applies when we are opening an archive we have no lock for yet.
#[derive(Debug, Clone, Copy)]
pub struct Limits {
    pub max_files: u64,
    pub max_file_bytes: u64,
    pub max_total_bytes: u64,
}

impl Default for Limits {
    fn default() -> Self {
        Self {
            max_files: 20_000,
            max_file_bytes: 64 * 1024 * 1024,
            max_total_bytes: 512 * 1024 * 1024,
        }
    }
}

/// One extracted file, held in memory until the whole archive has passed.
struct Staged {
    path: String,
    mode: u32,
    bytes: Vec<u8>,
}

/// Extract a gzipped tar into `dest`, or refuse.
///
/// `dest` must not exist: the caller stages into a fresh directory and renames it into
/// place, so there is never a moment where a reader can observe a partial generation.
pub fn extract_tar_gz(archive: &Path, dest: &Path, limits: Limits) -> Result<u64> {
    let f = std::fs::File::open(archive)?;
    let gz = flate2::read::GzDecoder::new(std::io::BufReader::new(f));
    let mut tar = tar::Archive::new(gz);

    let mut staged: Vec<Staged> = Vec::new();
    let mut total: u64 = 0;
    let mut folded: HashMap<String, String> = HashMap::new();

    for (index, entry) in tar.entries().map_err(io_integrity)?.enumerate() {
        if index as u64 >= limits.max_files {
            return Err(refuse(
                "ARCHIVE-TOO-MANY-FILES",
                format!("more than {} entries", limits.max_files),
            ));
        }
        let mut entry = entry.map_err(io_integrity)?;
        let kind = entry.header().entry_type();

        // Only regular files and directories. A symlink inside an archive is the classic
        // escape: extract `link -> /Users/x/.ssh`, then extract `link/authorized_keys`.
        if kind.is_symlink() || kind.is_hard_link() {
            return Err(refuse(
                "ARCHIVE-LINK",
                "archive contains a symlink or hard link",
            ));
        }
        if kind.is_block_special() || kind.is_character_special() || kind.is_fifo() {
            return Err(refuse(
                "ARCHIVE-DEVICE",
                "archive contains a device or FIFO entry",
            ));
        }
        if kind.is_dir() {
            let raw = entry.path().map_err(io_integrity)?.into_owned();
            let name = raw
                .to_str()
                .ok_or_else(|| refuse("ARCHIVE-PATH", "non-UTF8 directory path"))?;
            safe_relative(Path::new(name.trim_end_matches(['/', '\\'])))?;
            continue; // Directories are created from the file paths that need them.
        }
        if !kind.is_file() {
            return Err(refuse(
                "ARCHIVE-ENTRY",
                "archive contains a non-regular entry",
            ));
        }

        let raw = entry.path().map_err(io_integrity)?.into_owned();
        let rel = safe_relative(&raw)?;

        let size = entry.header().size().map_err(io_integrity)?;
        if size > limits.max_file_bytes {
            return Err(refuse(
                "ARCHIVE-FILE-TOO-BIG",
                format!("{rel}: {size} bytes"),
            ));
        }
        total = total.saturating_add(size);
        if total > limits.max_total_bytes {
            return Err(refuse(
                "ARCHIVE-TOO-BIG",
                format!("expanded size exceeds {} bytes", limits.max_total_bytes),
            ));
        }

        // A duplicate path means the second copy silently wins — a way to smuggle content
        // past a reviewer who read the first one.
        let folded_key = rel.to_lowercase();
        if let Some(prev) = folded.insert(folded_key, rel.clone()) {
            return Err(refuse(
                "ARCHIVE-DUPLICATE",
                format!("{prev} and {rel} are the same path after case folding"),
            ));
        }

        let mut bytes = Vec::with_capacity(size as usize);
        entry.read_to_end(&mut bytes).map_err(io_integrity)?;
        if bytes.len() as u64 != size {
            return Err(refuse(
                "ARCHIVE-SIZE-MISMATCH",
                format!("{rel}: header says {size}, body is {}", bytes.len()),
            ));
        }

        let mode = entry.header().mode().unwrap_or(0o644);
        staged.push(Staged {
            path: rel,
            mode: if mode & 0o111 != 0 { 0o755 } else { 0o644 },
            bytes,
        });
    }

    // Only now does anything touch the destination.
    if dest.exists() {
        return Err(Error::failure(
            "ARCHIVE-DEST-EXISTS",
            format!("{}: destination already exists", dest.display()),
        ));
    }
    std::fs::create_dir_all(dest)?;
    for s in &staged {
        let out = dest.join(&s.path);
        // Re-check after joining: a path that was safe in isolation must still land inside
        // dest once resolved, and the parent chain must not have become a symlink between
        // the check above and this write (TOCTOU).
        if !out.starts_with(dest) {
            return Err(refuse(
                "ARCHIVE-ESCAPE",
                format!("{}: escapes the destination", s.path),
            ));
        }
        if let Some(parent) = out.parent() {
            std::fs::create_dir_all(parent)?;
            assert_no_symlink_between(dest, parent)?;
        }
        std::fs::write(&out, &s.bytes)?;
        set_mode(&out, s.mode)?;
    }
    Ok(staged.len() as u64)
}

/// Validate an archive-relative path, or refuse.
///
/// Rejected: absolute paths, `..` in any position, `.` components, empty components,
/// Windows drive prefixes, NUL bytes, and anything that is not UTF-8. Every one of these
/// has been used to write outside a destination directory.
pub fn safe_relative(p: &Path) -> Result<String> {
    let s = p
        .to_str()
        .ok_or_else(|| refuse("ARCHIVE-NON-UTF8", "archive path is not valid UTF-8"))?;
    if s.is_empty() {
        return Err(refuse(
            "ARCHIVE-EMPTY-PATH",
            "archive contains an empty path",
        ));
    }
    if s.contains('\0') {
        return Err(refuse("ARCHIVE-NUL", "archive path contains NUL"));
    }
    if s.starts_with('/') || s.starts_with('\\') {
        return Err(refuse("ARCHIVE-ABSOLUTE", format!("{s}: absolute path")));
    }
    // C:\... and \\server\share
    let b = s.as_bytes();
    if b.len() >= 2 && b[1] == b':' && b[0].is_ascii_alphabetic() {
        return Err(refuse(
            "ARCHIVE-DRIVE",
            format!("{s}: drive-qualified path"),
        ));
    }
    // Validate the same spelling extraction will use. Host Path::components normalizes
    // interior dots and treats backslashes as ordinary characters on Unix.
    let normalized = s.replace('\\', "/");
    for part in normalized.split('/') {
        match part {
            "" => {
                return Err(refuse(
                    "ARCHIVE-EMPTY-COMPONENT",
                    format!("{s}: empty component"),
                ))
            }
            "." => return Err(refuse("ARCHIVE-DOT", format!("{s}: contains ."))),
            ".." => return Err(refuse("ARCHIVE-TRAVERSAL", format!("{s}: contains .."))),
            _ => {}
        }
    }
    Ok(normalized)
}

/// Refuse to write through a symlink that appeared under the destination after we checked.
fn assert_no_symlink_between(root: &Path, leaf: &Path) -> Result<()> {
    let mut cur = leaf.to_path_buf();
    while cur.starts_with(root) && cur != root {
        let meta = std::fs::symlink_metadata(&cur)?;
        if meta.file_type().is_symlink() {
            return Err(refuse(
                "ARCHIVE-TOCTOU",
                format!("{}: a symlink appeared in the path", cur.display()),
            ));
        }
        if !cur.pop() {
            break;
        }
    }
    Ok(())
}

fn refuse(kind: &str, msg: impl Into<String>) -> Error {
    Error::integrity(kind, msg).with_zh(
        "下载到的内容里有不安全的文件结构，已经停下来了，什么都没有安装。重新运行一次通常就能解决；如果连续两次都这样，请联系团队。"
            .to_string(),
    )
}

fn io_integrity(e: std::io::Error) -> Error {
    Error::integrity("ARCHIVE-READ", e.to_string()).with_zh(wf_core::zh::integrity_failed())
}

#[cfg(unix)]
fn set_mode(p: &Path, mode: u32) -> Result<()> {
    use std::os::unix::fs::PermissionsExt;
    std::fs::set_permissions(p, std::fs::Permissions::from_mode(mode))?;
    Ok(())
}

#[cfg(not(unix))]
fn set_mode(_p: &Path, _mode: u32) -> Result<()> {
    Ok(())
}

/// Build a gzipped tar deterministically: sorted paths, zeroed timestamps and ownership,
/// two normalised modes. The same tree must produce the same bytes on a Linux runner and on
/// a macOS laptop, or the reproducibility check in CI is measuring the weather.
pub fn build_tar_gz(root: &Path, out: &Path) -> Result<(u64, u64)> {
    let entries = wf_core::hash::tree_entries(root)?;
    let mut buf = Vec::new();
    {
        let gz = flate2::write::GzEncoder::new(&mut buf, flate2::Compression::new(6));
        let mut builder = tar::Builder::new(gz);
        builder.mode(tar::HeaderMode::Deterministic);
        for e in &entries {
            let full = root.join(&e.path);
            let data = std::fs::read(&full)?;
            let mut header = tar::Header::new_gnu();
            header.set_size(data.len() as u64);
            header.set_mode(if e.mode & 0o111 != 0 { 0o755 } else { 0o644 });
            header.set_mtime(0);
            header.set_uid(0);
            header.set_gid(0);
            header.set_entry_type(tar::EntryType::Regular);
            header.set_cksum();
            builder
                .append_data(&mut header, &e.path, std::io::Cursor::new(&data))
                .map_err(io_integrity)?;
        }
        builder
            .into_inner()
            .map_err(io_integrity)?
            .finish()
            .map_err(io_integrity)?;
    }
    wf_core::atomic::write_file(out, &buf)?;
    let total: u64 = entries.iter().map(|e| e.size).sum();
    Ok((entries.len() as u64, total))
}

/// Where a path in a tarball is joined onto a destination, for tests and for callers that
/// need to preview a plan.
pub fn join_checked(dest: &Path, rel: &str) -> Result<PathBuf> {
    let rel = safe_relative(Path::new(rel))?;
    let joined = dest.join(rel);
    if !joined.starts_with(dest) {
        return Err(refuse("ARCHIVE-ESCAPE", "path escapes the destination"));
    }
    Ok(joined)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn tar_with(entries: &[(&str, &[u8], tar::EntryType)]) -> tempfile::NamedTempFile {
        let mut f = tempfile::NamedTempFile::new().unwrap();
        {
            let gz = flate2::write::GzEncoder::new(Vec::new(), flate2::Compression::fast());
            let mut b = tar::Builder::new(gz);
            for (path, data, kind) in entries {
                let mut h = tar::Header::new_gnu();
                h.set_size(data.len() as u64);
                h.set_mode(0o644);
                h.set_entry_type(*kind);
                if *kind == tar::EntryType::Symlink {
                    h.set_size(0);
                    h.set_link_name("/etc/passwd").unwrap();
                }
                // The name field is written by hand rather than through set_path: the tar
                // builder refuses to *write* `..` and absolute paths, which is exactly the
                // archive these tests need in order to prove the reader refuses to *read*
                // them. A real attacker is not using this crate's builder either.
                let name = &mut h.as_old_mut().name;
                name.fill(0);
                let bytes = path.as_bytes();
                assert!(bytes.len() < name.len(), "fixture path too long");
                name[..bytes.len()].copy_from_slice(bytes);
                h.set_cksum();
                b.append(&h, std::io::Cursor::new(*data)).unwrap();
            }
            let raw = b.into_inner().unwrap().finish().unwrap();
            f.write_all(&raw).unwrap();
        }
        f.flush().unwrap();
        f
    }

    fn refuses(entries: &[(&str, &[u8], tar::EntryType)], expect: &str) {
        let a = tar_with(entries);
        let d = tempfile::tempdir().unwrap();
        let dest = d.path().join("out");
        let err = extract_tar_gz(a.path(), &dest, Limits::default()).unwrap_err();
        assert_eq!(err.kind, expect, "got {err}");
        assert!(!dest.exists(), "refused archives must leave nothing behind");
    }

    #[test]
    fn a_clean_archive_extracts() {
        let a = tar_with(&[
            ("a.md", b"one".as_ref(), tar::EntryType::Regular),
            ("nested/b.md", b"two".as_ref(), tar::EntryType::Regular),
        ]);
        let d = tempfile::tempdir().unwrap();
        let dest = d.path().join("out");
        assert_eq!(
            extract_tar_gz(a.path(), &dest, Limits::default()).unwrap(),
            2
        );
        assert_eq!(
            std::fs::read_to_string(dest.join("nested/b.md")).unwrap(),
            "two"
        );
    }

    #[test]
    fn directory_headers_count_toward_the_limit_and_validate_paths() {
        let archive = tar_with(&[
            ("a/", b"", tar::EntryType::Directory),
            ("b/", b"", tar::EntryType::Directory),
        ]);
        let dir = tempfile::tempdir().unwrap();
        let destination = dir.path().join("out");
        let error = extract_tar_gz(
            archive.path(),
            &destination,
            Limits {
                max_files: 1,
                ..Default::default()
            },
        )
        .unwrap_err();
        assert_eq!(error.kind, "ARCHIVE-TOO-MANY-FILES");
        assert!(!destination.exists());
        refuses(
            &[("../outside/", b"", tar::EntryType::Directory)],
            "ARCHIVE-TRAVERSAL",
        );
    }

    #[test]
    fn traversal_is_refused() {
        refuses(
            &[("../escape.md", b"x".as_ref(), tar::EntryType::Regular)],
            "ARCHIVE-TRAVERSAL",
        );
    }

    #[test]
    fn backslash_traversal_is_refused_before_any_entry_lands() {
        for name in [
            r"..\escape.md",
            r"nested\..\escape.md",
            r"nested/..\escape.md",
        ] {
            refuses(
                &[
                    ("safe.md", b"safe", tar::EntryType::Regular),
                    (name, b"escape", tar::EntryType::Regular),
                ],
                "ARCHIVE-TRAVERSAL",
            );
        }
    }

    #[test]
    fn normalized_archive_paths_have_no_ambiguous_components() {
        for name in ["a//b", "a/./b", "a/"] {
            assert!(safe_relative(Path::new(name)).is_err(), "accepted {name}");
        }
        assert_eq!(safe_relative(Path::new(r"a\b")).unwrap(), "a/b");
    }

    #[test]
    fn an_absolute_path_is_refused() {
        refuses(
            &[("/etc/cron.d/x", b"x".as_ref(), tar::EntryType::Regular)],
            "ARCHIVE-ABSOLUTE",
        );
    }

    #[test]
    fn a_symlink_is_refused() {
        refuses(
            &[("link", b"".as_ref(), tar::EntryType::Symlink)],
            "ARCHIVE-LINK",
        );
    }

    #[test]
    fn a_case_folded_duplicate_is_refused() {
        refuses(
            &[
                ("README.md", b"a".as_ref(), tar::EntryType::Regular),
                ("readme.md", b"b".as_ref(), tar::EntryType::Regular),
            ],
            "ARCHIVE-DUPLICATE",
        );
    }

    #[test]
    fn a_zip_bomb_is_refused_before_it_lands() {
        let a = tar_with(&[("big", vec![0u8; 4096].as_slice(), tar::EntryType::Regular)]);
        let d = tempfile::tempdir().unwrap();
        let dest = d.path().join("out");
        let limits = Limits {
            max_total_bytes: 1024,
            ..Limits::default()
        };
        let err = extract_tar_gz(a.path(), &dest, limits).unwrap_err();
        assert_eq!(err.kind, "ARCHIVE-TOO-BIG");
        assert!(!dest.exists());
    }

    #[test]
    fn refusal_happens_before_any_file_lands() {
        // The good entry precedes the bad one, so a streaming extractor would already have
        // written it by the time it refused.
        refuses(
            &[
                ("good.md", b"harmless".as_ref(), tar::EntryType::Regular),
                ("../evil.md", b"payload".as_ref(), tar::EntryType::Regular),
            ],
            "ARCHIVE-TRAVERSAL",
        );
    }

    #[test]
    fn build_is_byte_identical_across_runs() {
        let src = tempfile::tempdir().unwrap();
        std::fs::create_dir_all(src.path().join("skills/a")).unwrap();
        std::fs::write(src.path().join("skills/a/SKILL.md"), "x").unwrap();
        std::fs::write(src.path().join("registry.yaml"), "y").unwrap();
        let d = tempfile::tempdir().unwrap();
        let (n1, b1) = build_tar_gz(src.path(), &d.path().join("one.tgz")).unwrap();
        // Touch the sources so mtime differs; the archive must not.
        std::fs::write(src.path().join("registry.yaml"), "y").unwrap();
        let (n2, b2) = build_tar_gz(src.path(), &d.path().join("two.tgz")).unwrap();
        assert_eq!((n1, b1), (n2, b2));
        assert_eq!(
            std::fs::read(d.path().join("one.tgz")).unwrap(),
            std::fs::read(d.path().join("two.tgz")).unwrap(),
            "the same tree must produce the same bytes"
        );
    }

    #[test]
    fn a_round_trip_preserves_the_tree_digest() {
        let src = tempfile::tempdir().unwrap();
        std::fs::create_dir_all(src.path().join("a/b")).unwrap();
        std::fs::write(src.path().join("a/b/c.md"), "content").unwrap();
        std::fs::write(src.path().join("top.md"), "top").unwrap();
        let before = wf_core::hash::tree_digest(src.path()).unwrap();

        let d = tempfile::tempdir().unwrap();
        let tgz = d.path().join("bundle.tgz");
        build_tar_gz(src.path(), &tgz).unwrap();
        let dest = d.path().join("expanded");
        extract_tar_gz(&tgz, &dest, Limits::default()).unwrap();
        assert_eq!(before, wf_core::hash::tree_digest(&dest).unwrap());
    }
}
