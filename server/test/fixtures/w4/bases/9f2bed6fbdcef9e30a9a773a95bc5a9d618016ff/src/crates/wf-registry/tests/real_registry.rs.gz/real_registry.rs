use wf_registry::Registry;

/// The real registry in this repository validates against the real tree.
///
/// This is the positive control the negative fixtures in `validate` need: without it, a
/// mutation "causing" a violation could just as easily be reporting one that was already
/// there.
#[test]
fn the_shipped_registry_is_clean() {
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../..")
        .canonicalize()
        .unwrap();
    let reg = Registry::load(&root).expect("workflow/registry.yaml loads");
    let violations = wf_registry::validate(&reg, Some(&root));
    assert!(
        violations.is_empty(),
        "registry has violations:\n{}",
        violations
            .iter()
            .map(|v| v.to_string())
            .collect::<Vec<_>>()
            .join("\n")
    );
}
