//! `wf handover` — derive the state of in-flight work and emit a handover skeleton with
//! every derivable fact already filled in.
//!
//! The split is deliberate and mirrors readiness: this answers what a command can answer,
//! and the skill asks the sender only what no command can. Having a model run `git` and
//! `gh` and transcribe the results is where fabrication enters — a handover narrated from
//! memory fails the way a postmortem narrated from memory does.
//!
//! Every derived line in the output carries the command that reproduces it, so the receiver
//! verifies rather than trusts.

use serde::Serialize;
use std::path::Path;
use std::time::Duration;
use wf_core::Result;

const INTEGRATION_BRANCH: &str = "origin/main";
const PROBE: Duration = Duration::from_secs(15);

/// How far the work has got. It decides what a receiver cannot do without, which is why it
/// is inferred rather than asked: the sender knows it, but so does the repository, and the
/// repository does not misremember.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum Stage {
    /// A ticket exists and a branch does not. "This was going to be mine."
    NotStarted,
    /// A branch with work on it, no PR yet.
    InProgress,
    /// A PR is open. What matters shifts to findings and what is contested.
    InReview,
}

impl Stage {
    pub fn as_str(self) -> &'static str {
        match self {
            Stage::NotStarted => "not started",
            Stage::InProgress => "in progress",
            Stage::InReview => "in review",
        }
    }
}

/// Everything about the handover that a command can answer.
#[derive(Debug, Clone, Serialize)]
pub struct State {
    pub stage: Stage,
    /// Why that stage was inferred, so a wrong guess is visible rather than silently
    /// shaping the whole document.
    pub stage_reason: String,

    #[serde(skip_serializing_if = "String::is_empty")]
    pub repo: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub branch: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub base: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub head: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub ticket: String,

    pub dirty_files: usize,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub dirty_detail: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub ahead: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub behind: String,
    pub pushed: bool,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub last_commits: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub changed_files: String,

    #[serde(skip_serializing_if = "String::is_empty")]
    pub pr: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub pr_state: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub pr_checks: String,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub reviews: String,

    /// What must be settled before the handover is honest — above all an uncommitted tree,
    /// which exists on exactly one machine and which nothing else references.
    #[serde(skip_serializing_if = "Vec::is_empty")]
    pub blocking: Vec<String>,
}

impl Default for State {
    fn default() -> Self {
        Self {
            stage: Stage::NotStarted,
            stage_reason: String::new(),
            repo: String::new(),
            branch: String::new(),
            base: String::new(),
            head: String::new(),
            ticket: String::new(),
            dirty_files: 0,
            dirty_detail: String::new(),
            ahead: String::new(),
            behind: String::new(),
            pushed: false,
            last_commits: String::new(),
            changed_files: String::new(),
            pr: String::new(),
            pr_state: String::new(),
            pr_checks: String::new(),
            reviews: String::new(),
            blocking: Vec::new(),
        }
    }
}

pub fn gather(dir: &Path) -> Result<State> {
    if git(dir, &["rev-parse", "--is-inside-work-tree"]) != "true" {
        return Err(wf_core::Error::usage(
            "HANDOVER-NOT-A-REPO",
            format!("{} is not a git work tree", dir.display()),
        )
        .with_zh("这里不是一个 git 仓库。请到要交接的那个仓库目录下再运行一次。".to_string()));
    }
    let mut s = State {
        repo: wf_publish_artifact::parse::repo_from(&git(dir, &["remote", "get-url", "origin"])),
        branch: git(dir, &["rev-parse", "--abbrev-ref", "HEAD"]),
        head: git(dir, &["rev-parse", "--short", "HEAD"]),
        ..Default::default()
    };
    s.ticket = wf_publish_artifact::parse::ticket_from(&s.branch);
    s.base = git(dir, &["merge-base", "HEAD", INTEGRATION_BRANCH])
        .chars()
        .take(9)
        .collect();

    let status = git(dir, &["status", "--porcelain"]);
    if !status.is_empty() {
        let lines: Vec<&str> = status.lines().collect();
        s.dirty_files = lines.len();
        s.dirty_detail = lines[..lines.len().min(10)].join("\n");
    }
    s.ahead = git(
        dir,
        &[
            "rev-list",
            "--count",
            &format!("{INTEGRATION_BRANCH}..HEAD"),
        ],
    );
    s.behind = git(
        dir,
        &[
            "rev-list",
            "--count",
            &format!("HEAD..{INTEGRATION_BRANCH}"),
        ],
    );
    s.pushed = !git(
        dir,
        &["rev-parse", "--verify", &format!("origin/{}", s.branch)],
    )
    .is_empty();
    s.last_commits = git(
        dir,
        &[
            "log",
            "--oneline",
            "-8",
            &format!("{INTEGRATION_BRANCH}..HEAD"),
        ],
    );
    s.changed_files = git(
        dir,
        &["diff", "--stat", &format!("{INTEGRATION_BRANCH}...HEAD")],
    );

    gather_pr(dir, &mut s);
    infer(&mut s);
    find_blocking(&mut s);
    Ok(s)
}

fn gather_pr(dir: &Path, s: &mut State) {
    if s.branch.is_empty() || s.branch == "HEAD" {
        return;
    }
    let out = run(
        dir,
        "gh",
        &[
            "pr",
            "list",
            "--head",
            &s.branch,
            "--state",
            "all",
            "--json",
            "number,state,title,reviewDecision",
            "--limit",
            "1",
        ],
    );
    let Ok(prs) = serde_json::from_str::<Vec<serde_json::Value>>(&out) else {
        return;
    };
    let Some(p) = prs.first() else { return };
    s.pr = p["number"]
        .as_i64()
        .map(|n| n.to_string())
        .unwrap_or_default();
    s.pr_state = p["state"].as_str().unwrap_or("").to_string();
    s.reviews = p["reviewDecision"].as_str().unwrap_or("").to_string();
    if !s.pr.is_empty() {
        s.pr_checks = run(
            dir,
            "gh",
            &[
                "pr",
                "checks",
                &s.pr,
                "--json",
                "name,state",
                "--jq",
                r#"[.[]|select(.state!="SUCCESS")]|length as $n|if $n==0 then "all passing" else "\($n) not passing" end"#,
            ],
        );
    }
}

/// Decide the stage and record why.
fn infer(s: &mut State) {
    if !s.pr.is_empty() && s.pr_state == "OPEN" {
        s.stage = Stage::InReview;
        s.stage_reason = format!("PR #{} is open", s.pr);
    } else if s.branch.is_empty()
        || s.branch == "main"
        || s.branch == "master"
        || s.branch == "HEAD"
    {
        s.stage = Stage::NotStarted;
        s.stage_reason = format!("no feature branch is checked out (on {})", s.branch);
    } else if s.ahead == "0" && s.dirty_files == 0 {
        s.stage = Stage::NotStarted;
        s.stage_reason = format!(
            "branch {} has no commits beyond {INTEGRATION_BRANCH} and a clean tree",
            s.branch
        );
    } else {
        s.stage = Stage::InProgress;
        s.stage_reason = format!(
            "branch {} has {} commit(s) and no open PR",
            s.branch, s.ahead
        );
    }
}

/// Name what must be settled before the handover can be honest.
fn find_blocking(s: &mut State) {
    if s.dirty_files > 0 {
        s.blocking.push(format!(
            "{} uncommitted file(s). This is the most losable thing in a handover — it exists on one \
             machine, in one directory, and nothing else references it. Commit and push it, or say in \
             the handover that it is being abandoned.",
            s.dirty_files
        ));
    }
    if s.stage != Stage::NotStarted && !s.pushed && s.ahead != "0" && !s.ahead.is_empty() {
        s.blocking.push(format!(
            "branch {:?} has {} local commit(s) and no remote counterpart — the receiver cannot fetch \
             what was done. Push it.",
            s.branch, s.ahead
        ));
    }
    if s.ticket.is_empty() {
        s.blocking.push(
            "no ticket id in the branch name — a handover needs the ticket it is transferring; pass \
             --ticket if the branch does not carry it"
                .to_string(),
        );
    }
}

/// Remove a blocking item the caller has answered — passing `--ticket` answers the
/// missing-ticket one, and leaving it in the list would train people to ignore the list.
pub fn drop_blocking(s: &mut State, prefix: &str) {
    s.blocking.retain(|b| !b.starts_with(prefix));
}

/// The handover skeleton: derived facts filled in, and the sections only the sender can
/// answer left as explicit prompts rather than as blanks that get skipped.
pub fn render(s: &State, to: &str, why: &str, date: &str) -> String {
    let mut w = String::new();
    let user = std::env::var("USER").unwrap_or_default();
    w.push_str(&format!("# Handover — {}\n\n", headline(s)));
    w.push_str(&format!(
        "**From:** {} · **To:** {} · **Date:** {date}\n",
        or(&user, "unknown"),
        or(to, "_(who is receiving this?)_")
    ));
    w.push_str(&format!(
        "**Ticket:** {} · **Stage:** {}\n",
        or(&s.ticket.to_uppercase(), "_(none)_"),
        s.stage.as_str()
    ));
    w.push_str(&format!(
        "\n> Stage inferred because {}. If that is wrong, say so here — everything below\n> is shaped by it.\n",
        s.stage_reason
    ));

    if !why.is_empty() {
        w.push_str(&format!("\n**Why it is being handed over:** {why}\n"));
    } else {
        w.push_str(
            "\n**Why it is being handed over:** _(out of time · wrong person for it · blocked on \
             something you own — these lead the receiver to act differently, so say which)_\n",
        );
    }

    if !s.blocking.is_empty() {
        w.push_str("\n## ⚠️ Settle before sending\n\n");
        for b in &s.blocking {
            w.push_str(&format!("- {b}\n"));
        }
    }

    w.push_str("\n## Where the work is\n\n");
    w.push_str(
        "Every line here is derived. The command that reproduces it is given, so nothing\nbelow has to be taken on trust.\n\n",
    );
    w.push_str("| | | reproduce with |\n|---|---|---|\n");
    row(&mut w, "repo", &s.repo, "`git remote get-url origin`");
    row(
        &mut w,
        "branch",
        &s.branch,
        "`git rev-parse --abbrev-ref HEAD`",
    );
    row(&mut w, "head", &s.head, "`git rev-parse --short HEAD`");
    row(
        &mut w,
        "pushed",
        yes_no(s.pushed),
        &format!("`git rev-parse --verify origin/{}`", s.branch),
    );
    row(
        &mut w,
        "ahead / behind main",
        &format!("{} / {}", s.ahead, s.behind),
        &format!("`git rev-list --count {INTEGRATION_BRANCH}..HEAD`"),
    );
    row(
        &mut w,
        "merge base",
        &s.base,
        &format!("`git merge-base HEAD {INTEGRATION_BRANCH}`"),
    );
    row(
        &mut w,
        "uncommitted files",
        &s.dirty_files.to_string(),
        "`git status --porcelain`",
    );
    if !s.pr.is_empty() {
        row(
            &mut w,
            "PR",
            &format!("#{} ({})", s.pr, s.pr_state.to_lowercase()),
            &format!("`gh pr view {}`", s.pr),
        );
        row(
            &mut w,
            "review",
            or(&s.reviews, "none recorded"),
            &format!("`gh pr view {} --json reviews`", s.pr),
        );
        row(
            &mut w,
            "checks",
            or(&s.pr_checks, "unknown"),
            &format!("`gh pr checks {}`", s.pr),
        );
    }

    if !s.last_commits.is_empty() {
        w.push_str(&format!(
            "\n### Commits on this branch\n\n```\n{}\n```\n",
            s.last_commits
        ));
    }
    if !s.changed_files.is_empty() {
        w.push_str(&format!(
            "\n### Files touched\n\n```\n{}\n```\n",
            s.changed_files
        ));
    }
    if !s.dirty_detail.is_empty() {
        w.push_str(&format!(
            "\n### Uncommitted right now\n\n```\n{}\n```\n",
            s.dirty_detail
        ));
    }

    w.push_str("\n## What only you know\n\n");
    w.push_str(
        "**Done, and verified how.** _(what did you run or observe? a green local build is not a\nverified claim, and the receiver cannot tell the difference from outside)_\n\n",
    );
    w.push_str(
        "**Tried and rejected.** _(include why each was rejected: an alternative with no recorded\nreason gets re-attempted)_\n\n",
    );
    w.push_str("**Decisions taken, and on what evidence.** _(anything the receiver would otherwise\nreopen)_\n\n");

    w.push_str("## Next concrete step\n\n");
    w.push_str(
        "_(one specific action, such as \"fix the failing case in TestX then re-run the suite\")_\n\n",
    );

    w.push_str("## Traps\n\n");
    w.push_str(
        "_(what will bite them: a flaky test, a service that must be running, an ordering\nconstraint, a thing that looks wrong and is not)_\n\n",
    );

    w.push_str("## Getting to a working state\n\n```bash\n");
    if !s.repo.is_empty() {
        w.push_str(&format!(
            "git fetch origin && git switch {}\n",
            or(&s.branch, "<branch>")
        ));
    }
    w.push_str("wf readiness            # verify the machine before anything else\n```\n");
    w
}

fn headline(s: &State) -> String {
    if !s.ticket.is_empty() {
        return s.ticket.to_uppercase();
    }
    if !s.branch.is_empty() {
        return s.branch.clone();
    }
    "untitled work".to_string()
}

fn row(w: &mut String, label: &str, value: &str, cmd: &str) {
    w.push_str(&format!("| {label} | {} | {cmd} |\n", or(value, "—")));
}

fn or<'a>(v: &'a str, fallback: &'a str) -> &'a str {
    if v.trim().is_empty() {
        fallback
    } else {
        v
    }
}

fn yes_no(b: bool) -> &'static str {
    if b {
        "yes"
    } else {
        "**no**"
    }
}

fn git(dir: &Path, args: &[&str]) -> String {
    run(dir, "git", args)
}

/// A bounded command in a directory. A failure is an absent answer: callers derive
/// best-effort context, and a detached HEAD or a missing upstream must degrade to an empty
/// field rather than an error nobody can act on.
fn run(dir: &Path, program: &str, args: &[&str]) -> String {
    match wf_core::proc::run_in(program, args, &[], Some(dir), PROBE) {
        Ok(o) if o.ok() => o.stdout.trim().to_string(),
        _ => String::new(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn non_git_commands_use_the_handover_repository() {
        let dir = tempfile::tempdir().unwrap();
        let got = run(dir.path(), "/bin/pwd", &[]);
        assert_eq!(
            Path::new(&got).canonicalize().unwrap(),
            dir.path().canonicalize().unwrap()
        );
    }

    fn repo() -> tempfile::TempDir {
        let d = tempfile::tempdir().unwrap();
        let g = |args: &[&str]| {
            wf_core::proc::run(
                "git",
                &[&["-C", d.path().to_str().unwrap()], args].concat(),
                PROBE,
            )
            .unwrap();
        };
        g(&["init", "-q", "-b", "main"]);
        g(&["config", "user.email", "t@example.com"]);
        g(&["config", "user.name", "T"]);
        std::fs::write(d.path().join("a"), "1").unwrap();
        g(&["add", "-A"]);
        g(&["commit", "-qm", "first"]);
        d
    }

    #[test]
    fn a_directory_that_is_not_a_repo_says_so_in_a_sentence() {
        let d = tempfile::tempdir().unwrap();
        let e = gather(d.path()).unwrap_err();
        assert_eq!(e.kind, "HANDOVER-NOT-A-REPO");
        assert!(e.zh.contains("git 仓库"));
    }

    #[test]
    fn an_uncommitted_tree_is_the_first_blocking_item() {
        let d = repo();
        std::fs::write(d.path().join("b"), "2").unwrap();
        let s = gather(d.path()).unwrap();
        assert!(s.dirty_files > 0);
        assert!(s.blocking[0].contains("uncommitted"), "{:?}", s.blocking);
        assert!(
            s.blocking[0].contains("one machine"),
            "the reason has to be in the message"
        );
    }

    #[test]
    fn a_ticket_passed_by_flag_removes_its_own_blocking_item() {
        let d = repo();
        let mut s = gather(d.path()).unwrap();
        assert!(s.blocking.iter().any(|b| b.starts_with("no ticket id")));
        s.ticket = "txe-1664".into();
        drop_blocking(&mut s, "no ticket id");
        assert!(!s.blocking.iter().any(|b| b.starts_with("no ticket id")));
    }

    #[test]
    fn the_stage_reason_is_always_present_so_a_wrong_guess_is_visible() {
        let d = repo();
        let s = gather(d.path()).unwrap();
        assert!(!s.stage_reason.is_empty());
        assert_eq!(s.stage, Stage::NotStarted, "on main with a clean tree");
        assert!(s.stage_reason.contains("main"), "{}", s.stage_reason);
    }

    #[test]
    fn every_derived_row_carries_the_command_that_reproduces_it() {
        let d = repo();
        let s = gather(d.path()).unwrap();
        let out = render(&s, "Alex", "out of time", "2026-09-05");
        for cmd in [
            "git remote get-url origin",
            "git rev-parse --abbrev-ref HEAD",
            "git status --porcelain",
        ] {
            assert!(out.contains(cmd), "missing reproduction command {cmd}");
        }
        assert!(out.contains("**To:** Alex"));
        assert!(out.contains("out of time"));
        assert!(
            out.contains("wf readiness"),
            "the getting-started block must name the current tool"
        );
    }

    #[test]
    fn the_sections_only_a_person_can_answer_are_prompts_not_blanks() {
        let d = repo();
        let s = gather(d.path()).unwrap();
        let out = render(&s, "", "", "2026-09-05");
        assert!(out.contains("Tried and rejected"));
        assert!(
            out.contains("include why each was rejected"),
            "a blank heading gets skipped"
        );
        assert!(out.contains("_(who is receiving this?)_"));
    }
}
