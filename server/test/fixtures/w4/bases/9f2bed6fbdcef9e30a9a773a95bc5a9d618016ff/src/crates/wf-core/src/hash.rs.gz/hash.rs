use sha2::{Digest, Sha256};
use std::io::Read;
use std::path::Path;

pub fn sha256_bytes(b: &[u8]) -> String {
    let mut h = Sha256::new();
    h.update(b);
    hex::encode(h.finalize())
}

pub fn sha256_file(path: &Path) -> crate::Result<String> {
    let mut f = std::fs::File::open(path)?;
    let mut h = Sha256::new();
    let mut buf = vec![0u8; 64 * 1024];
    loop {
        let n = f.read(&mut buf)?;
        if n == 0 {
            break;
        }
        h.update(&buf[..n]);
    }
    Ok(hex::encode(h.finalize()))
}

/// One entry in a tree digest. Public because `wf release verify` reports which entry
/// diverged, and "the digest differs" without the entry is not actionable.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TreeEntry {
    pub path: String,
    pub mode: u32,
    pub size: u64,
    pub sha256: String,
}

/// The deterministic tree digest of a directory, per the release protocol.
///
/// The invariant this exists to hold: the same source tree on macOS and on Linux produces
/// the same 64 hex characters. Everything that would break that — mtime, uid, gid, the
/// checkout path, archive timestamps, directory iteration order — is excluded by
/// construction rather than normalised afterwards.
///
/// Two mode bits survive, not twelve: a file is `0o100755` if any execute bit is set and
/// `0o100644` otherwise. A umask difference between a runner and a laptop must not change
/// the digest, but losing the executable bit on a hook dispatcher would ship a component
/// that cannot run.
///
/// Anything that is not a regular file is a hard error. A symlink in a release tree is
/// either an accident or an escape, and neither should build.
pub fn tree_entries(root: &Path) -> crate::Result<Vec<TreeEntry>> {
    let mut out = Vec::new();
    let mut seen_folded: std::collections::HashMap<String, String> = Default::default();

    for entry in walkdir::WalkDir::new(root)
        .follow_links(false)
        .sort_by_file_name()
    {
        let entry = entry
            .map_err(|e| crate::Error::failure("TREE-WALK", format!("{}: {e}", root.display())))?;
        let ft = entry.file_type();
        if ft.is_dir() {
            continue;
        }
        let rel = entry
            .path()
            .strip_prefix(root)
            .map_err(|_| crate::Error::failure("TREE-WALK", "path escaped the root"))?;

        let path = rel
            .to_str()
            .ok_or_else(|| {
                crate::Error::integrity(
                    "TREE-NON-UTF8",
                    format!("{}: path is not valid UTF-8", rel.display()),
                )
            })?
            .replace('\\', "/");

        if !ft.is_file() {
            return Err(crate::Error::integrity(
                "TREE-NOT-REGULAR",
                format!("{path}: not a regular file (symlink, device or socket)"),
            )
            .with_zh(
                "发布内容里出现了符号链接或特殊文件，这不安全。请检查源目录后重新构建。"
                    .to_string(),
            ));
        }
        if path
            .split('/')
            .any(|c| c.is_empty() || c == "." || c == "..")
        {
            return Err(crate::Error::integrity(
                "TREE-BAD-PATH",
                format!("{path}: non-normalised path component"),
            ));
        }

        // A case-folding collision is invisible on a case-insensitive macOS checkout and
        // fatal on a case-sensitive Linux one. Fail at build time, where somebody can fix
        // it, rather than at install time on somebody else's laptop.
        let folded = path.to_lowercase();
        if let Some(prev) = seen_folded.insert(folded, path.clone()) {
            if prev != path {
                return Err(crate::Error::integrity(
                    "TREE-CASE-COLLISION",
                    format!("{prev} and {path} differ only by case"),
                ));
            }
        }

        let meta = entry
            .metadata()
            .map_err(|e| crate::Error::failure("TREE-STAT", format!("{path}: {e}")))?;
        out.push(TreeEntry {
            path,
            mode: normalised_mode(&meta),
            size: meta.len(),
            sha256: sha256_file(entry.path())?,
        });
    }

    out.sort_by(|a, b| a.path.as_bytes().cmp(b.path.as_bytes()));
    Ok(out)
}

pub fn tree_digest(root: &Path) -> crate::Result<String> {
    Ok(digest_entries(&tree_entries(root)?))
}

pub fn digest_entries(entries: &[TreeEntry]) -> String {
    let mut h = Sha256::new();
    for e in entries {
        h.update(format!("{:o}", e.mode).as_bytes());
        h.update([0]);
        h.update(e.path.as_bytes());
        h.update([0]);
        h.update(e.size.to_string().as_bytes());
        h.update([0]);
        h.update(e.sha256.as_bytes());
        h.update(b"\n");
    }
    hex::encode(h.finalize())
}

#[cfg(unix)]
fn normalised_mode(meta: &std::fs::Metadata) -> u32 {
    use std::os::unix::fs::PermissionsExt;
    if meta.permissions().mode() & 0o111 != 0 {
        0o100755
    } else {
        0o100644
    }
}

#[cfg(not(unix))]
fn normalised_mode(_meta: &std::fs::Metadata) -> u32 {
    0o100644
}

#[cfg(test)]
mod tests {
    use super::*;

    fn tree(files: &[(&str, &str)]) -> tempfile::TempDir {
        let d = tempfile::tempdir().unwrap();
        for (p, c) in files {
            let full = d.path().join(p);
            std::fs::create_dir_all(full.parent().unwrap()).unwrap();
            std::fs::write(full, c).unwrap();
        }
        d
    }

    #[test]
    fn digest_ignores_mtime_and_checkout_path() {
        let a = tree(&[("a.md", "one"), ("nested/b.md", "two")]);
        let b = tree(&[("a.md", "one"), ("nested/b.md", "two")]);
        // Different temp roots, different creation times, same content.
        assert_eq!(
            tree_digest(a.path()).unwrap(),
            tree_digest(b.path()).unwrap()
        );
    }

    #[test]
    fn digest_follows_content() {
        let a = tree(&[("a.md", "one")]);
        let b = tree(&[("a.md", "onf")]);
        assert_ne!(
            tree_digest(a.path()).unwrap(),
            tree_digest(b.path()).unwrap()
        );
    }

    #[test]
    fn digest_follows_the_executable_bit_but_not_the_umask() {
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let a = tree(&[("hook", "#!/bin/sh\n")]);
            let before = tree_digest(a.path()).unwrap();
            std::fs::set_permissions(
                a.path().join("hook"),
                std::fs::Permissions::from_mode(0o600),
            )
            .unwrap();
            assert_eq!(
                before,
                tree_digest(a.path()).unwrap(),
                "0644 vs 0600 must not move it"
            );
            std::fs::set_permissions(
                a.path().join("hook"),
                std::fs::Permissions::from_mode(0o755),
            )
            .unwrap();
            assert_ne!(before, tree_digest(a.path()).unwrap(), "+x must move it");
        }
    }

    #[test]
    fn a_symlink_in_a_release_tree_is_an_error() {
        #[cfg(unix)]
        {
            let d = tree(&[("real.md", "x")]);
            std::os::unix::fs::symlink("real.md", d.path().join("link.md")).unwrap();
            let err = tree_digest(d.path()).unwrap_err();
            assert_eq!(err.kind, "TREE-NOT-REGULAR");
        }
    }

    #[test]
    fn case_collisions_fail_at_build_time() {
        // Only meaningful where the filesystem can hold both.
        let d = tempfile::tempdir().unwrap();
        if std::fs::write(d.path().join("Readme.md"), "a").is_ok()
            && std::fs::write(d.path().join("README.md"), "b").is_ok()
            && std::fs::read_to_string(d.path().join("Readme.md")).unwrap() == "a"
        {
            let err = tree_digest(d.path()).unwrap_err();
            assert_eq!(err.kind, "TREE-CASE-COLLISION");
        }
    }
}
