use super::emit;
use crate::flags::ReleaseCmd;
use std::path::{Path, PathBuf};
use wf_core::{envelope::Envelope, ExitCode, Result};
use wf_release::bundle::{self, BuildOptions};

pub fn run(json: bool, cmd: ReleaseCmd) -> Result<ExitCode> {
    match cmd {
        ReleaseCmd::BuildLocal {
            out,
            root,
            version,
            with_binary,
            binaries: supplied,
            ctx,
        } => {
            let root = PathBuf::from(&root);
            let out = PathBuf::from(&out);
            let version = version.unwrap_or_else(|| wf_core::VERSION.to_string());

            // A local build carries the running binary as this platform's asset when asked,
            // so an install rehearsal exercises the same download-verify-replace path a real
            // release does — minus only the parts GitHub is the authority for.
            let mut binaries = Vec::new();
            for input in supplied {
                let (target, path) = input.split_once('=').ok_or_else(|| {
                    wf_core::Error::usage("BINARY-INPUT", "--binary expects TARGET=ARCHIVE")
                })?;
                binaries.push((target.to_string(), PathBuf::from(path)));
            }
            if with_binary {
                let exe = std::env::current_exe()?;
                let staged = out.join(wf_release::source::Assets::binary(
                    &version,
                    wf_core::paths::target_triple(),
                ));
                std::fs::create_dir_all(&out)?;
                pack_binary(&exe, &staged)?;
                binaries.push((wf_core::paths::target_triple().to_string(), staged));
            }

            // Resolved before anything is written, so a ctx release that cannot be pinned
            // for every platform fails the build instead of shipping half a fleet without it.
            let ctx = ctx
                .map(|tag| wf_release::ctx::resolve(&tag, std::time::Duration::from_secs(60)))
                .transpose()?;
            let (lock, lock_path, bundle_path) = bundle::build(&BuildOptions {
                root: &root,
                out: &out,
                version: &version,
                source_commit: git_head(&root),
                binaries,
                ctx,
            })?;

            let env = Envelope::new("release build-local").result(serde_json::json!({
                "version": lock.release_version,
                "lock": lock_path,
                "bundle": bundle_path,
                "bundle_sha256": lock.bundle.sha256,
                "tree_sha256": lock.bundle.tree_sha256,
                "file_count": lock.bundle.file_count,
                "components": lock.components.len(),
                "ctx": lock.ctx_upstream.version,
            }));
            let (v, b, n, dir) = (
                lock.release_version.clone(),
                lock.bundle.sha256.clone(),
                lock.components.len(),
                out.display().to_string(),
            );
            Ok(emit(json, env, move || {
                format!(
                    "已在 {dir} 构建 {v}：{n} 个组件，包摘要 {}。\n用 `wf install --source local:{dir}` 就可以在本机安装它。\n",
                    &b[..12]
                )
            }))
        }

        ReleaseCmd::PackBinary { binary, out } => {
            if let Some(parent) = Path::new(&out).parent() {
                std::fs::create_dir_all(parent)?;
            }
            pack_binary(Path::new(&binary), Path::new(&out))?;
            Ok(ExitCode::Ok)
        }

        ReleaseCmd::Verify {
            dir,
            require_binaries,
        } => {
            let dir = PathBuf::from(&dir);
            let lock = bundle::verify_local(&dir, require_binaries)?;
            let (rel, _) = wf_release::source::resolve_local(&dir)?;
            let bundle_path = dir.join(&lock.bundle.asset);
            let got = wf_core::hash::sha256_file(&bundle_path)?;
            let mut env = Envelope::new("release verify").result(serde_json::json!({
                "version": rel.version,
                "bundle_sha256": got,
                "expected": lock.bundle.sha256,
            }));
            if got != lock.bundle.sha256 {
                env = env.error(
                    wf_core::envelope::Note::new(
                        "BUNDLE-DIGEST-MISMATCH",
                        "bundle does not match its lock",
                    )
                    .with_zh(wf_core::zh::integrity_failed()),
                );
            }
            let v = rel.version.clone();
            let ok = got == lock.bundle.sha256;
            Ok(emit(json, env, move || {
                if ok {
                    format!("{v} 校验通过。\n")
                } else {
                    format!("{v} 校验没通过，这份构建不能用。\n")
                }
            }))
        }

        ReleaseCmd::BuildLock { root } => {
            let tmp = tempdir()?;
            let (lock, _, _) = bundle::build(&BuildOptions {
                root: Path::new(&root),
                out: tmp.path(),
                version: wf_core::VERSION,
                source_commit: git_head(Path::new(&root)),
                binaries: vec![],
                ctx: None,
            })?;
            print!("{}", lock.render());
            Ok(ExitCode::Ok)
        }
    }
}

/// The binary, as a tarball with the name a release asset unpacks to.
fn pack_binary(exe: &Path, out: &Path) -> Result<()> {
    let staging = tempdir()?;
    let dest = staging.path().join("wf");
    std::fs::copy(exe, &dest)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(&dest, std::fs::Permissions::from_mode(0o755))?;
    }
    wf_release::archive::build_tar_gz(staging.path(), out)?;
    Ok(())
}

fn tempdir() -> Result<tempfile::TempDir> {
    tempfile::tempdir().map_err(wf_core::Error::from)
}

/// The commit this tree is at, or empty. A local build with no git available still works;
/// the lock simply records no source commit, and the installer skips the tag comparison.
fn git_head(root: &Path) -> String {
    let Ok(out) = wf_core::proc::run(
        "git",
        &["-C", &root.to_string_lossy(), "rev-parse", "HEAD"],
        std::time::Duration::from_secs(10),
    ) else {
        return String::new();
    };
    if !out.ok() {
        return String::new();
    }
    let s = out.stdout.trim().to_string();
    if s.len() == 40 {
        s
    } else {
        String::new()
    }
}
