-- 002 — the agent management layer (wf-agents).
--
-- Additive only. A binary that predates these tables ignores them, which is what keeps
-- `wf rollback` able to hand the database to an older release: the refusal version in
-- `meta.schema` moves only when an older reader would misread something it already knows.
--
-- Timestamps are fixed-width UTC text (`2026-09-16T10:30:00.123Z`), so a string comparison
-- is a time comparison and every range query can use an index.

-- Every usage event a hook reported. Local only; nothing reads this table off the machine.
CREATE TABLE IF NOT EXISTS usage_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    session_id TEXT NOT NULL,
    agent TEXT NOT NULL,
    event_type TEXT NOT NULL,          -- skill | tool | prompt | session_start | session_end
    skill_name TEXT,
    tool_name TEXT,
    source TEXT,
    metadata TEXT                      -- JSON object
);
CREATE INDEX IF NOT EXISTS usage_events_by_session ON usage_events(session_id);
CREATE INDEX IF NOT EXISTS usage_events_by_timestamp ON usage_events(timestamp);
CREATE INDEX IF NOT EXISTS usage_events_by_agent ON usage_events(agent);

CREATE TABLE IF NOT EXISTS known_skills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    skill_name TEXT UNIQUE NOT NULL,
    first_seen TEXT NOT NULL,
    last_used TEXT NOT NULL,
    use_count INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS session_summaries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT UNIQUE NOT NULL,
    agent TEXT NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT,
    tool_count INTEGER NOT NULL DEFAULT 0,
    intervention_count INTEGER NOT NULL DEFAULT 0,
    valuable INTEGER NOT NULL DEFAULT 0,
    first_prompt_redacted TEXT,
    metadata TEXT                      -- JSON object
);
CREATE INDEX IF NOT EXISTS session_summaries_by_start ON session_summaries(start_time);

-- Which agents this machine manages. The spec itself lives in agents.yaml; `metadata` keeps
-- the snapshot a registration was made from, so a later bundle that drops an agent still
-- says what was registered.
CREATE TABLE IF NOT EXISTS agent_registry (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    config_root TEXT,
    binary_path TEXT,
    version TEXT,
    last_detected TEXT,
    enabled INTEGER NOT NULL DEFAULT 1,
    metadata TEXT                      -- JSON object
);

-- What wf has deployed into an agent and still owns. Replaces teamai's managed-hooks.json and
-- managed-mcp.json: one row per object, written only when the transaction that deployed it
-- commits, so a rollback cannot leave a row naming an object that is not there.
CREATE TABLE IF NOT EXISTS managed_resources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id TEXT NOT NULL,
    resource_kind TEXT NOT NULL,       -- skill | rule | hook | mcp | doc | env | agent | prompt
    resource_id TEXT NOT NULL,
    source_path TEXT,
    deployed_path TEXT NOT NULL,
    content_hash TEXT,
    deployed_at TEXT NOT NULL,
    UNIQUE(agent_id, resource_kind, resource_id)
);

-- The team repository this machine reads resources from. One row: a machine has one team.
CREATE TABLE IF NOT EXISTS team_repo_state (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    mode TEXT NOT NULL,                -- self-repo | git | http
    remote_url TEXT,
    last_pull_rev TEXT,
    last_pull_time TEXT,
    last_sync_time TEXT,
    metadata TEXT                      -- JSON object
);

-- Reserved for the HTTP backend mode (team-repo roadmap phase 4). Created now so that mode
-- arrives as code, not as a second migration.
CREATE TABLE IF NOT EXISTS remote_commands (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    command_id INTEGER NOT NULL,
    command_type TEXT NOT NULL,
    received_at TEXT NOT NULL,
    executed_at TEXT,
    success INTEGER,
    error_message TEXT,
    metadata TEXT                      -- JSON object
);
