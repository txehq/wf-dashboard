use time::format_description::well_known::Rfc3339;
use time::OffsetDateTime;

pub fn now_rfc3339() -> String {
    OffsetDateTime::now_utc()
        .format(&Rfc3339)
        .unwrap_or_default()
}

pub fn now_unix() -> i64 {
    OffsetDateTime::now_utc().unix_timestamp()
}

pub fn today() -> String {
    let d = OffsetDateTime::now_utc().date();
    format!("{:04}-{:02}-{:02}", d.year(), u8::from(d.month()), d.day())
}

/// A UTC instant as fixed-width RFC 3339 with milliseconds: `2026-09-16T10:30:00.123Z`.
///
/// Fixed width is the point. The usage tables compare these as strings, and a formatter
/// that drops a trailing zero fraction sorts `10:30:00.5Z` before `10:30:00Z`.
pub fn utc_millis(unix_ms: i64) -> String {
    let at = OffsetDateTime::from_unix_timestamp_nanos(i128::from(unix_ms) * 1_000_000)
        .unwrap_or(OffsetDateTime::UNIX_EPOCH);
    format!(
        "{:04}-{:02}-{:02}T{:02}:{:02}:{:02}.{:03}Z",
        at.year(),
        u8::from(at.month()),
        at.day(),
        at.hour(),
        at.minute(),
        at.second(),
        at.millisecond()
    )
}

pub fn now_utc_millis() -> String {
    utc_millis(now_unix_millis())
}

pub fn now_unix_millis() -> i64 {
    (OffsetDateTime::now_utc().unix_timestamp_nanos() / 1_000_000) as i64
}

/// Any RFC 3339 instant, as milliseconds since the epoch.
pub fn parse_rfc3339_millis(text: &str) -> Option<i64> {
    let at = OffsetDateTime::parse(text.trim(), &Rfc3339).ok()?;
    Some((at.unix_timestamp_nanos() / 1_000_000) as i64)
}

/// Human age for a status line: "3 天前", "12 分钟前".
pub fn age_zh(then_unix: i64) -> String {
    let secs = (now_unix() - then_unix).max(0);
    match secs {
        s if s < 60 => "刚刚".to_string(),
        s if s < 3600 => format!("{} 分钟前", s / 60),
        s if s < 86400 => format!("{} 小时前", s / 3600),
        s => format!("{} 天前", s / 86400),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn millisecond_timestamps_are_fixed_width_and_sort_as_their_instants() {
        let instants = [0, 500, 1_000, 1_758_018_600_000, 1_758_018_600_005];
        let texts: Vec<String> = instants.iter().map(|ms| utc_millis(*ms)).collect();
        assert_eq!(utc_millis(0), "1970-01-01T00:00:00.000Z");
        assert_eq!(utc_millis(1_758_018_600_005), "2025-09-16T10:30:00.005Z");
        assert!(texts.iter().all(|t| t.len() == texts[0].len()), "{texts:?}");
        let mut sorted = texts.clone();
        sorted.sort();
        assert_eq!(sorted, texts, "string order must be time order");
    }

    #[test]
    fn rfc3339_instants_parse_back_through_any_offset() {
        assert_eq!(
            parse_rfc3339_millis(&utc_millis(1_758_018_600_123)),
            Some(1_758_018_600_123)
        );
        assert_eq!(
            parse_rfc3339_millis("2025-09-16T18:30:00+08:00"),
            Some(1_758_018_600_000)
        );
        assert_eq!(parse_rfc3339_millis("yesterday"), None);
    }
}
