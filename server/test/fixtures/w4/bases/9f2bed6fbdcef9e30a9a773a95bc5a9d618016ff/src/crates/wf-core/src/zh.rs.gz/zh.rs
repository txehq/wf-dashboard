//! The operator-facing voice.
//!
//! This is an internal tool, so everyone who runs it already has access to the repository.
//! That makes the interesting failure "your login expired" rather than "you are not
//! authorised", and it decides the register: say what to do next, in one or two sentences,
//! and leave the mechanism to the log. A person whose session has gone stale does not need
//! to be told about OAuth scopes; they need to be told to run one command.
//!
//! Every sentence here is a fix, not a diagnosis.

/// The `gh` login is missing or expired.
pub fn gh_not_logged_in() -> String {
    "还没有登录 GitHub。请先运行 `gh auth login`，按提示登录之后再执行一次刚才的命令。".to_string()
}

/// `gh` is logged in but the repository is not readable from this account.
pub fn repo_unreadable(repo: &str) -> String {
    format!(
        "当前 GitHub 账号读不到 {repo}。多数情况下是登录的账号不对或者授权过期了：\n  1. 运行 `gh auth status` 看看现在登录的是哪个账号；\n  2. 如果不是你的工作账号，运行 `gh auth login` 换一个；\n  3. 如果账号没错，把这条消息发给团队里的管理员，让他把你加进这个仓库。"
    )
}

/// No release has been published on this channel yet.
pub fn no_release(repo: &str, channel: &str) -> String {
    format!(
        "{repo} 上还没有 {channel} 版本可以安装。\n  如果你只是想在本地试一下，可以在仓库中运行 `wf release build-local --out dist`，再用 `wf install --source local:dist` 安装本地构建的版本（请使用隔离的测试配置；本地构建没有 GitHub 发布证明）。"
    )
}

/// `gh` itself is not installed.
pub fn gh_missing() -> String {
    "还没有安装 GitHub CLI。macOS 上运行 `brew install gh`，Linux 上参考 https://cli.github.com 安装，装好后运行 `gh auth login` 登录。".to_string()
}

pub fn git_missing() -> String {
    "还没有安装 git。macOS 上运行 `xcode-select --install`，Linux 上用系统包管理器安装即可。"
        .to_string()
}

/// The platform is outside what this release line ships.
pub fn unsupported_platform(triple: &str) -> String {
    format!(
        "这台机器是 {triple}，目前的版本还没有为它构建。\n  现在支持的是 Apple Silicon 的 macOS 和 x86_64 的 Linux。如果你确实需要在这台机器上用，请告诉团队。"
    )
}

/// A downloaded asset did not match what the release says it should be.
pub fn integrity_failed() -> String {
    "下载下来的文件和 GitHub 上记录的不一致，已经停下来了，什么都没有安装。\n  通常是网络中途出错，重新运行一次就好。如果连续两次都这样，请把这条消息发给团队。"
        .to_string()
}

/// An update did not land, and the machine is still on the version it already had.
///
/// Says what happened, not why. This used to assert 连不上网络 for every non-integrity
/// failure — including a purely local source with no network in play — which left the one
/// person who could act on it reading a sentence that was not true. The cause travels
/// beside this as a technical detail; see `lkg_message`.
pub fn still_using(version: &str) -> String {
    format!("（仍然在用已经装好的 {version}，工作不受影响。）")
}

pub fn update_failed_using_lkg(version: &str) -> String {
    format!("这次没能更新到新版本，继续使用已经装好的 {version}。工作不受影响，之后会自动再试。")
}

/// The stale window has been open too long.
pub fn stale_too_long(days: i64) -> String {
    format!(
        "已经 {days} 天没能和团队的版本对上了。\n  请检查网络，或者运行一次 `gh auth status` 确认登录还在。命令仍然可以正常使用。"
    )
}

/// One `wf_state::ComponentState`, in the operator's language.
///
/// The fallback for an unrecognized word is the word itself: a row restored from the state
/// database carries no rendered sentence of its own, and printing the raw `unverified` under a
/// Chinese heading is how a report ends up half-translated. `wf-state` cannot be depended on
/// from here, so this is keyed by the string `ComponentState::as_str` writes.
pub fn state_word(state: &str) -> String {
    match state {
        "current" => "已经就位",
        "staged" => "已经下载，还没启用",
        "update_pending" => "有更新的版本，正在取",
        "reload_required" => "文件已经更新，这个会话还在用旧的",
        "credential_missing" => "装好了，但还缺少需要的凭据",
        "unverified" => "装好了，登录状态这里看不出来",
        "drifted" => "被改动、删掉或停用了",
        "conflict_replaced" => "有同名的东西，已经备份后替换",
        "stale" => "很久没有和团队的版本对上了",
        "blocked" => "用不了，需要先处理",
        "unsupported" => "不在这个版本支持的范围里",
        other => other,
    }
    .to_string()
}

/// A required credential reference has no value in the environment.
pub fn credential_missing(component: &str, reference: &str) -> String {
    format!(
        "{component} 已经装好了，但还缺少 {reference}。\n  把它加到你的 shell 配置里（例如 ~/.zshrc）之后重开一个终端就行；在补上之前，其它功能都能正常用。"
    )
}

/// An `agent-oauth` component with no reference to read: this component's own server logs in
/// through a browser and holds the token itself. Installed, and unobserved — which is what
/// this has to say instead of reporting it as in place (txe-workflow#40).
///
/// The token store is keyed by service URL and lives on the machine, not inside any agent, so
/// one login covers them all. Saying so is what stops several rows for one component from
/// reading as separate things to do.
///
/// One server is named, because `wf` installs one (WFR-016).
pub fn login_unverified(component: &str, host: &str) -> String {
    format!(
        "{component} 已经装好了。它在浏览器里登录 {host}，凭据存在本机、各个 agent 共用同一份，wf 看不到有没有登录过。\n  第一次用到时按提示完成授权即可。要确认，发一次真实的只读调用，别只看状态。"
    )
}

/// A user file was about to be overwritten and has been backed up first.
pub fn backed_up(path: &str, backup_id: &str) -> String {
    format!(
        "{path} 里原来的内容已经备份，备份编号 {backup_id}。\n  想拿回原来的内容，运行 `wf backup restore {backup_id}`。"
    )
}

/// The Codex SessionStart hook is waiting on a human to trust it.
pub fn codex_hook_untrusted() -> String {
    "Codex 里还有一个待确认的启动钩子。请在 Codex 中输入 `/hooks`，看一眼命令确认无误后信任它。\n  确认之后，以后的版本更新都不需要你再确认一次。"
        .to_string()
}

/// A newer version has been staged but this session keeps what it loaded at startup.
pub fn reload_required(current: &str, desired: &str) -> String {
    format!("已经准备好 {desired}（当前这个会话仍在用 {current}）。\n  开一个新会话就会切过去。")
}

/// A path is not writable.
pub fn not_writable(path: &str) -> String {
    format!(
        "{path} 现在写不进去。请确认这个目录是你自己的，或者设置 WF_HOME 指到一个你有权限的目录再试一次。"
    )
}
