//! Magi, stage 1: the sensor.
//!
//! The whole Magi design is a control loop on one number — review/fix rounds to ship a
//! feature — and until this crate existed that number was not measured anywhere. This
//! measures it, with the covariates any later comparison needs, and does nothing else. No
//! attribution, no proposals, no judgement: those are stages 2 and 3 and they live elsewhere.
//!
//! **Derived, not collected.** A round is a review at head H followed by a push. That is
//! already in every pull request's timeline, so the baseline needs no webhook, no service and
//! no Actions — a read of merged PRs produces it. This is the consequence of the ingestion
//! rule (Magi Service S1): GitHub is the event log, and Magi observes it.
//!
//! **Rebuilt in full on every run.** There is no incremental state, so there is nothing to
//! corrupt and nothing to migrate. The ledger is always a fresh derivation from GitHub — which
//! is the rebuild test from the ingestion design, embodied rather than promised.

use serde::{Deserialize, Serialize};
use std::path::Path;
use std::time::Duration;
use wf_core::{Error, Result};

const PROBE: Duration = Duration::from_secs(60);

/// The markers that identify a review as one of ours.
///
/// The review is posted under a person's token, so the author is not the identity — the
/// marker is. These are the same strings the detector treats as coverage truth, and the legacy
/// forms are recognised for the same reason it recognises them: history was written with them.
pub const RPR_MARKERS: [&str; 3] = [
    "<!-- OpenAI Codex via RPR -->",
    "<!-- OpenAI Codex via RPRB -->",
    "Review by OpenAI Codex via RPRB",
];

/// Which reviewer wrote a review — or neither.
///
/// Two dialects exist today and only one is a contract. The detector (`/review-pr`) posts
/// `## Codex Code Review (MODEL, EFFORT)` with a hidden marker and `### Severity [N]` counts,
/// validated before posting. The fix loop posts `## Codex review — pass N (…)` with one
/// `### HIGH n — title` heading per finding, no marker, and — measured across eight
/// consecutive merged PRs — three spellings of the same header. The sensor reads both, and
/// TXE-1806 asks the fix loop for a structured block so that nothing downstream has to.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
pub enum Dialect {
    /// `/review-pr`: marker-identified, machine-validated.
    Rpr,
    /// The fix loop: prose, recognised by its header.
    Rprf,
}

pub fn dialect(body: &str) -> Option<Dialect> {
    if RPR_MARKERS.iter().any(|m| body.contains(m)) {
        return Some(Dialect::Rpr);
    }
    let rprf = body.lines().any(|l| {
        let t = l.trim_start();
        t.starts_with("## Codex review —")
            || t.starts_with("## Codex review –")
            || t.starts_with("## Codex review -")
    });
    rprf.then_some(Dialect::Rprf)
}

pub fn is_rpr(body: &str) -> bool {
    dialect(body).is_some()
}

/// The pass number the fix loop declares — `pass N` — and, for its terminal summary
/// (`## Codex review — 5 passes, 44 findings, 43 addressed`), the total it declares.
///
/// Returns `(this_pass, declared_total)`. A summary review is not itself a pass: counting it
/// would add a round that never happened. It is recorded as a declared total instead, and
/// where that disagrees with the push-derived count the disagreement is data — `capsohq/txe#2036`
/// posts passes 1, 2, 3 and 5 as reviews and no pass 4.
pub fn parse_pass(body: &str) -> (Option<u32>, Option<u32>) {
    let Some(line) = body
        .lines()
        .map(str::trim_start)
        .find(|l| l.starts_with("## Codex review"))
    else {
        return (None, None);
    };
    let words: Vec<&str> = line.split_whitespace().collect();
    for w in words.windows(2) {
        let num = |t: &str| {
            t.trim_matches(|c: char| !c.is_ascii_digit())
                .parse::<u32>()
                .ok()
        };
        if w[0] == "pass" {
            if let Some(n) = num(w[1]) {
                return (Some(n), None);
            }
        }
        if w[1].starts_with("pass") && w[1] != "pass" {
            if let Some(n) = num(w[0]) {
                return (None, Some(n));
            }
        }
    }
    (None, None)
}

/// Findings per severity in one review pass, from the `### Severity [N]` headings the review
/// contract requires. One of the four Goodhart guards: a falling round count with falling
/// severity-per-pass is progress; with rising severity it is reviews getting shorter.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize)]
pub struct Severity {
    pub critical: u32,
    pub high: u32,
    pub medium: u32,
    pub low: u32,
}

impl Severity {
    pub fn total(&self) -> u32 {
        self.critical + self.high + self.medium + self.low
    }
}

pub fn parse_severity(body: &str) -> Severity {
    let mut s = Severity::default();
    let bump = |s: &mut Severity, name: &str, n: u32| match name.to_ascii_lowercase().as_str() {
        "critical" => s.critical += n,
        "high" => s.high += n,
        "medium" => s.medium += n,
        "low" => s.low += n,
        _ => {}
    };
    for line in body.lines() {
        let Some(rest) = line.trim().strip_prefix("### ") else {
            continue;
        };
        // Detector form: `### High [3]` — a count.
        if let Some((name, count)) = rest.split_once(" [") {
            if let Some(n) = count
                .strip_suffix(']')
                .and_then(|c| c.trim().parse::<u32>().ok())
            {
                bump(&mut s, name.trim(), n);
                continue;
            }
        }
        // Fix-loop form: `### HIGH 1 — title` or `### ⚠️ HIGH 1 — title` — one finding.
        let rest = rest.trim_start_matches(|c: char| !c.is_ascii_alphabetic());
        let mut it = rest.split_whitespace();
        if let (Some(name), Some(num)) = (it.next(), it.next()) {
            if num.chars().all(|c| c.is_ascii_digit()) && !num.is_empty() {
                bump(&mut s, name, 1);
            }
        }
    }
    s
}

/// The reviewing model and its reasoning effort, from the review header
/// `## Codex Code Review (MODEL, EFFORT)`.
///
/// The confounder that dominates every comparison in this system. A model change can move the
/// round count with no lever touched, so it is recorded on every pass and every later
/// comparison stratifies on it.
pub fn parse_model(body: &str) -> Option<(String, String)> {
    let line = body
        .lines()
        .map(str::trim_start)
        .find(|l| l.starts_with("## Codex Code Review (") || l.starts_with("## Codex review"))?;
    // The first parenthesised group. `(`gpt-5.6-sol`, effort high, sandbox=…)` and
    // `(gpt-5.6-sol, effort=high)` are both in the wild.
    let inner = line.split_once('(')?.1.split_once(')')?.0;
    let mut parts = inner.split(',').map(|p| p.trim().trim_matches('`').trim());
    let model = parts.next()?.to_string();
    let mut effort = String::new();
    for p in parts {
        if let Some(e) = p.strip_prefix("effort") {
            effort = e.trim_start_matches(['=', ' ', ':']).trim().to_string();
            break;
        }
        if effort.is_empty() && !p.contains('=') {
            effort = p.to_string();
        }
    }
    if model.is_empty() {
        return None;
    }
    Some((model, effort))
}

/// A review as GitHub returns it.
#[derive(Debug, Clone, Deserialize)]
pub struct Review {
    #[serde(default)]
    pub submitted_at: String,
    #[serde(default)]
    pub commit_id: String,
    #[serde(default)]
    pub body: String,
}

/// A commit on the pull request, in the order GitHub lists them.
#[derive(Debug, Clone, Deserialize)]
pub struct Commit {
    pub sha: String,
}

/// One RPR pass over a pull request.
#[derive(Debug, Clone, Serialize)]
pub struct Pass {
    pub at: String,
    pub head: String,
    pub dialect: Dialect,
    /// The pass number the fix loop wrote, when it wrote one.
    pub declared_pass: Option<u32>,
    pub model: String,
    pub effort: String,
    pub severity: Severity,
    /// Did a push follow this review? If so, it cost a fix round.
    pub followed_by_push: bool,
}

/// Derive the passes, and for each whether it was followed by a push.
///
/// A review is "followed by a push" when a commit exists later in the PR's commit list than
/// the head it reviewed. A review whose head is not in the list at all was force-pushed away —
/// the head changed, which is the same thing, so it counts as followed. The alternative,
/// treating an absent head as no round, would make a history rewrite look like a clean pass.
pub fn passes(reviews: &[Review], commits: &[Commit]) -> Vec<Pass> {
    let mut ours: Vec<(&Review, Dialect)> = reviews
        .iter()
        .filter_map(|r| dialect(&r.body).map(|d| (r, d)))
        // A terminal summary ("5 passes, 44 findings") is not a pass.
        .filter(|(r, d)| *d == Dialect::Rpr || parse_pass(&r.body).1.is_none())
        .collect();
    ours.sort_by(|a, b| a.0.submitted_at.cmp(&b.0.submitted_at));
    let last = commits.len().saturating_sub(1);
    // The fix loop writes `(same thread, effort high)` on a continuation pass, meaning the
    // model of the previous pass. Recorded as that model, because "same thread" stratifies
    // nothing and the model is the covariate that matters.
    let mut prev: Option<(String, String)> = None;
    ours.into_iter()
        .map(|(r, d)| {
            let parsed = parse_model(&r.body).unwrap_or_default();
            let (model, effort) = match (&parsed, &prev) {
                ((m, _), Some(p)) if m.is_empty() || m.eq_ignore_ascii_case("same thread") => (
                    p.0.clone(),
                    if parsed.1.is_empty() {
                        p.1.clone()
                    } else {
                        parsed.1.clone()
                    },
                ),
                _ => parsed.clone(),
            };
            if !model.is_empty() {
                prev = Some((model.clone(), effort.clone()));
            }
            let followed_by_push = match commits.iter().position(|c| c.sha == r.commit_id) {
                Some(i) => i < last,
                None => true,
            };
            Pass {
                at: r.submitted_at.clone(),
                head: r.commit_id.clone(),
                dialect: d,
                declared_pass: parse_pass(&r.body).0,
                model,
                effort,
                severity: parse_severity(&r.body),
                followed_by_push,
            }
        })
        .collect()
}

/// The highest pass number the fix loop declared anywhere on the PR.
pub fn declared_passes(reviews: &[Review]) -> Option<u32> {
    reviews
        .iter()
        .filter_map(|r| {
            let (p, t) = parse_pass(&r.body);
            p.max(t)
        })
        .max()
}

/// Fix rounds: passes that cost a push.
pub fn fix_rounds(passes: &[Pass]) -> u32 {
    passes.iter().filter(|p| p.followed_by_push).count() as u32
}

/// One merged pull request, measured.
#[derive(Debug, Clone, Serialize)]
pub struct PrRow {
    pub number: u32,
    pub title: String,
    pub author: String,
    pub created_at: String,
    pub merged_at: String,
    pub additions: u32,
    pub deletions: u32,
    pub files: u32,
    pub tickets: Vec<String>,
    pub passes: Vec<Pass>,
    pub fix_rounds: u32,
    /// The highest pass number the fix loop declared, from `pass N` or its `N passes`
    /// summary. A second derivation of the same quantity; disagreement with `fix_rounds` is
    /// itself a signal.
    pub declared_passes: Option<u32>,
}

/// The Monday of the ISO week containing an RFC 3339 timestamp, as `YYYY-MM-DD`.
pub fn week_of(rfc3339: &str) -> Option<String> {
    let dt = time::OffsetDateTime::parse(rfc3339, &time::format_description::well_known::Rfc3339)
        .ok()?;
    let d = dt.date();
    let back = d.weekday().number_days_from_monday() as i64;
    let monday = d.checked_sub(time::Duration::days(back))?;
    Some(format!(
        "{:04}-{:02}-{:02}",
        monday.year(),
        monday.month() as u8,
        monday.day()
    ))
}

/// One week of merged pull requests, aggregated.
#[derive(Debug, Clone, Serialize)]
pub struct WeekRow {
    pub week: String,
    pub prs: u32,
    /// PRs that had at least one RPR pass — the denominator that matters.
    pub reviewed: u32,
    pub mean_rounds: f64,
    pub median_rounds: f64,
    pub max_rounds: u32,
    pub mean_findings_per_pass: f64,
    pub mean_lines_changed: f64,
}

/// Weekly aggregation over reviewed PRs only. A PR with no RPR pass is counted but says
/// nothing about rounds, and averaging it in as zero would make an unreviewed week look like
/// a perfect one.
pub fn weekly(rows: &[PrRow]) -> Vec<WeekRow> {
    let mut by_week: std::collections::BTreeMap<String, Vec<&PrRow>> = Default::default();
    for r in rows {
        if let Some(w) = week_of(&r.merged_at) {
            by_week.entry(w).or_default().push(r);
        }
    }
    by_week
        .into_iter()
        .map(|(week, prs)| {
            let reviewed: Vec<&&PrRow> = prs.iter().filter(|p| !p.passes.is_empty()).collect();
            let mut rounds: Vec<u32> = reviewed.iter().map(|p| p.fix_rounds).collect();
            rounds.sort_unstable();
            let n = rounds.len();
            let mean = |v: &[u32]| {
                if v.is_empty() {
                    0.0
                } else {
                    v.iter().map(|&x| x as f64).sum::<f64>() / v.len() as f64
                }
            };
            let median = match n {
                0 => 0.0,
                _ if n % 2 == 1 => rounds[n / 2] as f64,
                _ => (rounds[n / 2 - 1] + rounds[n / 2]) as f64 / 2.0,
            };
            let all_passes: Vec<&Pass> = reviewed.iter().flat_map(|p| p.passes.iter()).collect();
            let findings = if all_passes.is_empty() {
                0.0
            } else {
                all_passes
                    .iter()
                    .map(|p| p.severity.total() as f64)
                    .sum::<f64>()
                    / all_passes.len() as f64
            };
            let lines: Vec<u32> = reviewed.iter().map(|p| p.additions + p.deletions).collect();
            WeekRow {
                week,
                prs: prs.len() as u32,
                reviewed: n as u32,
                mean_rounds: mean(&rounds),
                median_rounds: median,
                max_rounds: rounds.last().copied().unwrap_or(0),
                mean_findings_per_pass: findings,
                mean_lines_changed: mean(&lines),
            }
        })
        .collect()
}

/// Everything a run produced. `rebuilt_from` is a statement, not a field: this is never
/// incremental.
#[derive(Debug, Clone, Serialize)]
pub struct Ledger {
    pub repo: String,
    pub generated_at: String,
    pub since: Option<String>,
    pub rebuilt_from: &'static str,
    pub rows: Vec<PrRow>,
    pub weeks: Vec<WeekRow>,
}

#[derive(Deserialize)]
struct PrListRow {
    number: u32,
    #[serde(default)]
    title: String,
    #[serde(default)]
    author: Author,
    #[serde(rename = "createdAt", default)]
    created_at: String,
    #[serde(rename = "mergedAt", default)]
    merged_at: String,
    #[serde(default)]
    additions: u32,
    #[serde(default)]
    deletions: u32,
    #[serde(rename = "changedFiles", default)]
    changed_files: u32,
    #[serde(default)]
    body: String,
}
#[derive(Deserialize, Default)]
struct Author {
    #[serde(default)]
    login: String,
}

/// Read the merged pull requests and measure each one.
pub fn gather(root: &Path, repo: &str, since: Option<&str>, limit: u32) -> Result<Ledger> {
    let mut search = String::from("is:merged");
    if let Some(s) = since {
        search.push_str(&format!(" merged:>={s}"));
    }
    let limit_s = limit.to_string();
    let list = gh(
        root,
        &[
            "pr",
            "list",
            "-R",
            repo,
            "--state",
            "merged",
            "--search",
            &search,
            "--limit",
            &limit_s,
            "--json",
            "number,title,author,createdAt,mergedAt,additions,deletions,changedFiles,body",
        ],
    )?;
    let prs: Vec<PrListRow> = serde_json::from_str(&list)
        .map_err(|e| Error::failure("MAGI-LIST-UNPARSEABLE", format!("gh pr list: {e}")))?;

    let mut rows = Vec::with_capacity(prs.len());
    for pr in prs {
        let n = pr.number.to_string();
        let reviews: Vec<Review> = serde_json::from_str(&gh(
            root,
            &[
                "api",
                "--paginate",
                &format!("repos/{repo}/pulls/{n}/reviews"),
            ],
        )?)
        .unwrap_or_default();
        let commits: Vec<Commit> = serde_json::from_str(&gh(
            root,
            &[
                "api",
                "--paginate",
                &format!("repos/{repo}/pulls/{n}/commits"),
            ],
        )?)
        .unwrap_or_default();
        let passes = passes(&reviews, &commits);
        let fix_rounds = fix_rounds(&passes);
        let declared = declared_passes(&reviews);
        rows.push(PrRow {
            number: pr.number,
            tickets: wf_release_notes::tickets_in(&format!("{}\n{}", pr.title, pr.body)),
            title: pr.title,
            author: pr.author.login,
            created_at: pr.created_at,
            merged_at: pr.merged_at,
            additions: pr.additions,
            deletions: pr.deletions,
            files: pr.changed_files,
            passes,
            fix_rounds,
            declared_passes: declared,
        });
    }
    rows.sort_by(|a, b| a.merged_at.cmp(&b.merged_at));
    let weeks = weekly(&rows);
    Ok(Ledger {
        repo: repo.to_string(),
        generated_at: wf_core::time_fmt::now_rfc3339(),
        since: since.map(str::to_string),
        rebuilt_from: "github — full derivation, no incremental state",
        rows,
        weeks,
    })
}

fn gh(root: &Path, args: &[&str]) -> Result<String> {
    match wf_core::proc::run_in("gh", args, &[], Some(root), PROBE) {
        Ok(o) if o.ok() => Ok(o.stdout),
        Ok(o) => Err(Error::failure(
            "MAGI-GH",
            o.stderr
                .lines()
                .next()
                .unwrap_or("gh reported no error output")
                .trim()
                .to_string(),
        )
        .with_zh("无法读取 GitHub，请检查 gh 是否已登录。")),
        Err(e) => Err(Error::failure(
            "MAGI-NO-GH",
            format!("gh could not be run: {e}"),
        )),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn review(at: &str, head: &str, body: &str) -> Review {
        Review {
            submitted_at: at.into(),
            commit_id: head.into(),
            body: body.into(),
        }
    }

    fn rpr_body(sev: &str) -> String {
        format!("## Codex Code Review (gpt-5.6-sol, high)\n<!-- OpenAI Codex via RPR -->\n{sev}")
    }

    /// capsohq/tokun-cn#347 as read from GitHub on 2026-09-08: ten commits, ten RPR passes each
    /// at a distinct head, the last merged with Medium/Low findings still open. Hand-counted
    /// expectation: 10 passes, 9 followed by a push.
    fn fixture_347() -> (Vec<Review>, Vec<Commit>) {
        let heads = [
            "ef300269", "4ace8769", "1af336f0", "c08b2c58", "92003584", "e2932706", "c4f1682d",
            "cfae4013", "8dca4a1c", "ef7a1ff6",
        ];
        let sevs = [
            "### High [3]\n### Medium [8]",
            "### High [3]\n### Medium [3]",
            "### High [2]\n### Medium [4]\n### Low [1]",
            "### High [3]\n### Medium [6]",
            "### High [1]\n### Medium [5]\n### Low [2]",
            "### High [1]\n### Medium [2]\n### Low [1]",
            "### High [2]\n### Medium [6]",
            "### Medium [3]\n### Low [2]",
            "### High [2]\n### Medium [2]\n### Low [1]",
            "### Medium [2]\n### Low [1]",
        ];
        let reviews = heads
            .iter()
            .zip(sevs.iter())
            .enumerate()
            .map(|(i, (h, s))| review(&format!("2026-08-29T1{}:00:00Z", i), h, &rpr_body(s)))
            .collect();
        let commits = heads
            .iter()
            .map(|h| Commit { sha: h.to_string() })
            .collect();
        (reviews, commits)
    }

    #[test]
    fn the_real_pr_counts_ten_passes_and_nine_rounds() {
        let (reviews, commits) = fixture_347();
        let p = passes(&reviews, &commits);
        assert_eq!(p.len(), 10, "every RPR review is a pass");
        assert_eq!(
            fix_rounds(&p),
            9,
            "all but the last were followed by a push"
        );
        assert!(
            !p[9].followed_by_push,
            "the final pass was merged, not pushed over"
        );
        assert_eq!(p[0].model, "gpt-5.6-sol");
        assert_eq!(p[0].effort, "high");
        assert_eq!(p[0].severity.high, 3);
        assert_eq!(p[0].severity.medium, 8);
        assert_eq!(p[0].severity.total(), 11);
        assert_eq!(p[9].severity.total(), 3, "merged with M2 L1 open");
    }

    #[test]
    fn a_single_clean_pass_is_zero_rounds() {
        // The positive control for the count: a matcher that always says "followed" would
        // pass the fixture above and make every clean PR look like it took a round.
        let commits = vec![Commit { sha: "aaa".into() }];
        let reviews = vec![review("2026-09-01T00:00:00Z", "aaa", &rpr_body("clean"))];
        let p = passes(&reviews, &commits);
        assert_eq!(p.len(), 1);
        assert_eq!(fix_rounds(&p), 0);
    }

    #[test]
    fn a_review_at_a_force_pushed_head_counts_as_followed() {
        // The head changed — that is what a round is — even though the reviewed commit is no
        // longer in the list. Treating it as clean would make a history rewrite look like a
        // perfect pass.
        let commits = vec![Commit { sha: "new".into() }];
        let reviews = vec![review(
            "2026-09-01T00:00:00Z",
            "gone",
            &rpr_body("### High [1]"),
        )];
        assert_eq!(fix_rounds(&passes(&reviews, &commits)), 1);
    }

    #[test]
    fn only_marked_reviews_are_passes() {
        // The author is a person's token; the marker is the identity. A human's LGTM is not
        // a pass, and neither is a review that merely mentions the reviewer.
        let commits = vec![Commit { sha: "a".into() }, Commit { sha: "b".into() }];
        let reviews = vec![
            review("2026-09-01T00:00:00Z", "a", "LGTM"),
            review(
                "2026-09-01T00:01:00Z",
                "a",
                "I ran OpenAI Codex via RPR myself, looks fine",
            ),
            review("2026-09-01T00:02:00Z", "a", &rpr_body("### Low [1]")),
        ];
        let p = passes(&reviews, &commits);
        assert_eq!(p.len(), 1);
    }

    #[test]
    fn the_legacy_markers_are_recognised() {
        for m in RPR_MARKERS {
            assert!(
                is_rpr(&format!("## Codex Code Review (x, high)\n{m}\nbody")),
                "{m}"
            );
        }
        assert!(!is_rpr("nothing here"));
    }

    #[test]
    fn severity_parses_the_contract_headings_and_nothing_else() {
        let s = parse_severity("### Critical [1]\n### High [2]\n### Medium [3]\n### Low [4]\n### Notes [9]\n#### 1. finding [7]");
        assert_eq!(
            s,
            Severity {
                critical: 1,
                high: 2,
                medium: 3,
                low: 4
            }
        );
        assert_eq!(parse_severity("no headings").total(), 0);
    }

    #[test]
    fn the_model_header_parses_and_its_absence_is_none() {
        assert_eq!(
            parse_model("## Codex Code Review (gpt-5.6-sol, high)\nx"),
            Some(("gpt-5.6-sol".into(), "high".into()))
        );
        assert_eq!(parse_model("## Something else"), None);
    }

    // ---- the fix loop's dialect, from real reviews on capsohq/txe, 2026-09-08 ----

    #[test]
    fn the_fix_loops_three_header_spellings_all_parse() {
        // Measured across eight consecutive merged PRs. One fact, three spellings; the sensor
        // must read all of them or the main repository registers zero passes — which is
        // exactly what happened on the first run.
        for (hdr, want_pass) in [
            (
                "## Codex review — pass 1 (`gpt-5.6-sol`, effort high). All fixed in `6…`",
                1,
            ),
            ("## Codex review — pass 2 (gpt-5.6-sol, effort=high)", 2),
            (
                "## Codex review — pass 1 (`gpt-5.6-sol`, effort high, sandbox=read-only)",
                1,
            ),
            (
                "## Codex review — pass 5 (gpt-5.6-sol, effort=high) — **TERMINATED**",
                5,
            ),
        ] {
            assert_eq!(dialect(hdr), Some(Dialect::Rprf), "{hdr}");
            assert_eq!(
                parse_model(hdr),
                Some(("gpt-5.6-sol".into(), "high".into())),
                "{hdr}"
            );
            assert_eq!(parse_pass(hdr), (Some(want_pass), None), "{hdr}");
        }
    }

    #[test]
    fn the_fix_loops_terminal_summary_is_not_a_pass() {
        // `capsohq/txe#2038` posted only this. Counting it as a pass would add a round that
        // never happened; it is a declared total instead.
        let summary =
            "## Codex review — 5 passes, 44 findings, 43 addressed\n### The two that mattered";
        assert_eq!(parse_pass(summary), (None, Some(5)));
        let commits = vec![Commit { sha: "a".into() }];
        let reviews = vec![review("2026-09-01T00:00:00Z", "a", summary)];
        assert!(
            passes(&reviews, &commits).is_empty(),
            "a summary is not a pass"
        );
        assert_eq!(declared_passes(&reviews), Some(5));
    }

    #[test]
    fn the_fix_loop_severity_is_one_heading_per_finding() {
        // `capsohq/txe#2039` pass 1: four HIGH, one LOW, with prose headings around them that
        // must not be counted, and `#2043` with the ⚠️ prefix.
        let body = "## Codex review — pass 1 (gpt-5.6-sol, effort=high)\n\
                    ### HIGH 1 — any semver-shaped value is accepted as a pin\n\
                    ### HIGH 2 — hunk-wide pairing accepts a pin MOVED between files\n\
                    ### HIGH 3 — content that looks like a diff header is silently skipped\n\
                    ### HIGH 4 — the acceptance exemption authenticates a forgeable field\n\
                    ### LOW 1 — comments still describe the removed behaviour\n\
                    ### Confirmed fixed from pass 0\n\
                    ## Verification\n\
                    ### ⚠️ MEDIUM 2 — a surviving mutant";
        let s = parse_severity(body);
        assert_eq!(s.high, 4);
        assert_eq!(s.low, 1);
        assert_eq!(s.medium, 1, "the ⚠️-prefixed heading counts");
        assert_eq!(s.critical, 0);
        assert_eq!(s.total(), 6, "prose headings are not findings");
    }

    #[test]
    fn a_fix_loop_pr_counts_its_passes_and_records_the_declared_total() {
        // `capsohq/txe#2036`: passes 1, 2, 3 and 5 posted as reviews at four heads, no pass 4.
        // Push-derived rounds and the declared total disagree, and both are kept.
        let heads = ["2f255af4", "29b753b5", "9b7c3ff9", "9b9c7135"];
        let hdrs = [
            "## Codex review — pass 1 (gpt-5.6-sol, effort=high, sandbox=read-only)\n### HIGH 1 — x",
            "## Codex review — pass 2 (gpt-5.6-sol, effort=high)\n### HIGH 1 — y",
            "## Codex review — pass 3 (gpt-5.6-sol, effort=high)\n### MEDIUM 1 — z",
            "## Codex review — pass 5 (gpt-5.6-sol, effort=high) — **TERMINATED**\n### Loop summary",
        ];
        let reviews: Vec<Review> = heads
            .iter()
            .zip(hdrs.iter())
            .enumerate()
            .map(|(i, (h, b))| review(&format!("2026-09-05T0{i}:00:00Z"), h, b))
            .collect();
        let commits: Vec<Commit> = heads
            .iter()
            .map(|h| Commit { sha: h.to_string() })
            .collect();
        let p = passes(&reviews, &commits);
        assert_eq!(p.len(), 4);
        assert_eq!(
            fix_rounds(&p),
            3,
            "three of the four were followed by a push"
        );
        assert_eq!(p[3].declared_pass, Some(5));
        assert_eq!(declared_passes(&reviews), Some(5));
        assert!(p.iter().all(|x| x.dialect == Dialect::Rprf));
    }

    #[test]
    fn a_same_thread_pass_inherits_the_previous_model() {
        // Observed on capsohq/txe: a continuation pass headed `(same thread, effort high)`.
        // "same thread" stratifies nothing; the model is the covariate that matters.
        let commits = vec![Commit { sha: "a".into() }, Commit { sha: "b".into() }];
        let reviews = vec![
            review(
                "2026-09-05T00:00:00Z",
                "a",
                "## Codex review — pass 1 (gpt-5.6-sol, effort=high)\n### HIGH 1 — x",
            ),
            review(
                "2026-09-05T01:00:00Z",
                "b",
                "## Codex review — pass 2 (same thread, effort high)\n### LOW 1 — y",
            ),
        ];
        let p = passes(&reviews, &commits);
        assert_eq!(p[1].model, "gpt-5.6-sol");
        assert_eq!(p[1].effort, "high");
    }

    #[test]
    fn the_detector_dialect_still_parses_unchanged() {
        // Extending to the second dialect must not have bent the first.
        let (reviews, commits) = fixture_347();
        let p = passes(&reviews, &commits);
        assert_eq!(fix_rounds(&p), 9);
        assert!(p.iter().all(|x| x.dialect == Dialect::Rpr));
        assert!(p.iter().all(|x| x.declared_pass.is_none()));
        assert_eq!(declared_passes(&reviews), None);
    }

    #[test]
    fn a_week_starts_on_monday() {
        // 2026-08-29 is a Saturday; its week's Monday is 2026-08-24.
        assert_eq!(
            week_of("2026-08-29T14:35:33Z").as_deref(),
            Some("2026-08-24")
        );
        // A Monday maps to itself.
        assert_eq!(
            week_of("2026-08-24T00:00:00Z").as_deref(),
            Some("2026-08-24")
        );
        assert_eq!(week_of("not a date"), None);
    }

    fn row(merged: &str, rounds: u32, passes_n: usize, lines: u32) -> PrRow {
        let passes = (0..passes_n)
            .map(|i| Pass {
                at: format!("t{i}"),
                head: format!("h{i}"),
                model: "m".into(),
                effort: "high".into(),
                severity: Severity {
                    high: 2,
                    ..Default::default()
                },
                followed_by_push: (i as u32) < rounds,
                dialect: Dialect::Rpr,
                declared_pass: None,
            })
            .collect();
        PrRow {
            number: 1,
            title: "t".into(),
            author: "a".into(),
            created_at: merged.into(),
            merged_at: merged.into(),
            additions: lines,
            deletions: 0,
            files: 1,
            tickets: vec![],
            passes,
            fix_rounds: rounds,
            declared_passes: None,
        }
    }

    #[test]
    fn weekly_aggregates_reviewed_prs_only() {
        let rows = vec![
            row("2026-08-25T00:00:00Z", 9, 10, 100),
            row("2026-08-27T00:00:00Z", 3, 4, 300),
            // Unreviewed: counted, but must not drag the mean toward zero.
            row("2026-08-28T00:00:00Z", 0, 0, 50),
            row("2026-09-02T00:00:00Z", 1, 2, 10),
        ];
        let w = weekly(&rows);
        assert_eq!(w.len(), 2);
        assert_eq!(w[0].week, "2026-08-24");
        assert_eq!(w[0].prs, 3);
        assert_eq!(
            w[0].reviewed, 2,
            "the unreviewed PR is not in the denominator"
        );
        assert_eq!(w[0].mean_rounds, 6.0);
        assert_eq!(
            w[0].median_rounds, 6.0,
            "even count: mean of the middle two"
        );
        assert_eq!(w[0].max_rounds, 9);
        assert_eq!(w[0].mean_findings_per_pass, 2.0);
        assert_eq!(w[0].mean_lines_changed, 200.0);
        assert_eq!(w[1].reviewed, 1);
        assert_eq!(w[1].median_rounds, 1.0, "odd count: the middle");
    }
}
