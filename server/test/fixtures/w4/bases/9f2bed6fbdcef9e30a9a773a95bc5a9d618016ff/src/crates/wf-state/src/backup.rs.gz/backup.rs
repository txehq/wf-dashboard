use crate::db::{sql, Db};
use rusqlite::{params, OptionalExtension};
use serde::Serialize;
use std::path::{Path, PathBuf};
use wf_core::{Error, Result};

/// One backed-up file. The id is what a person types into `wf backup restore`, so it is
/// short, sortable and unambiguous rather than a UUID.
#[derive(Debug, Clone, Serialize)]
pub struct Backup {
    pub backup_id: String,
    pub transaction_id: String,
    pub original_path: String,
    pub backup_path: String,
    pub sha256: String,
    pub at: i64,
    pub restored_at: Option<i64>,
}

/// Retention: keep the last 10 changing transactions *and* everything from the last 30
/// days. Either condition keeps a backup, because the two failure modes are different — a
/// busy week would age out a bad change under a count-only rule, and a quiet month would
/// age out the only copy of something under a time-only rule.
pub const KEEP_TRANSACTIONS: usize = 10;
pub const KEEP_DAYS: i64 = 30;

pub struct Store<'a> {
    db: &'a Db,
    root: PathBuf,
}

impl<'a> Store<'a> {
    pub fn new(db: &'a Db, root: PathBuf) -> Self {
        Self { db, root }
    }

    /// Copy a file aside before it is overwritten, and record where it went.
    ///
    /// A path that does not exist yet still gets a receipt with an empty digest: "there was
    /// nothing here" is a fact a restore needs, and without it a restore of a file we
    /// created would have to guess whether to delete it.
    pub fn capture(&self, transaction_id: &str, path: &Path) -> Result<Backup> {
        wf_core::paths::refuse_symlink(path)?;
        if path.try_exists()? && !path.is_file() {
            return Err(Error::failure(
                "BACKUP-NOT-FILE",
                format!("{} is not a regular file", path.display()),
            ));
        }
        let now = wf_core::time_fmt::now_unix();
        // Time to the second plus a path digest is readable but not unique: capturing the
        // same file twice inside one second — which a restore does by design, and a repair
        // of two objects in one file does by accident — would collide. The suffix makes the
        // id unique without making it unreadable.
        let base = format!(
            "{}-{}",
            short_time(now),
            short_hash(&path.to_string_lossy())
        );
        let backup_id = self.unique_id(&base)?;
        let dest = self
            .root
            .join(transaction_id)
            .join(format!("{backup_id}.bak"));

        // An absence is recorded as a row with no digest, and no file: restoring it means
        // removing what was created, which needs nothing from disk.
        let sha = if path.is_file() {
            let bytes = std::fs::read(path)?;
            wf_core::atomic::write_file(&dest, &bytes)?;
            std::fs::set_permissions(&dest, std::fs::metadata(path)?.permissions())?;
            wf_core::hash::sha256_bytes(&bytes)
        } else {
            String::new()
        };

        let b = Backup {
            backup_id: backup_id.clone(),
            transaction_id: transaction_id.to_string(),
            original_path: path.to_string_lossy().into_owned(),
            backup_path: dest.to_string_lossy().into_owned(),
            sha256: sha,
            at: now,
            restored_at: None,
        };
        self.db
            .conn()
            .execute(
                "INSERT INTO backups(backup_id, transaction_id, original_path, backup_path, sha256, at)
                 VALUES(?1,?2,?3,?4,?5,?6)",
                params![b.backup_id, b.transaction_id, b.original_path, b.backup_path, b.sha256, b.at],
            )
            .map_err(sql)?;
        Ok(b)
    }

    /// First unused id in the `base`, `base-2`, `base-3` … series.
    fn unique_id(&self, base: &str) -> Result<String> {
        for n in 1..1000 {
            let candidate = if n == 1 {
                base.to_string()
            } else {
                format!("{base}-{n}")
            };
            let taken: i64 = self
                .db
                .conn()
                .query_row(
                    "SELECT COUNT(*) FROM backups WHERE backup_id=?1",
                    params![candidate],
                    |r| r.get(0),
                )
                .map_err(sql)?;
            if taken == 0 {
                return Ok(candidate);
            }
        }
        Err(Error::failure(
            "BACKUP-ID",
            "could not allocate a backup id",
        ))
    }

    pub fn list(&self) -> Result<Vec<Backup>> {
        let mut st = self
            .db
            .conn()
            .prepare("SELECT backup_id,transaction_id,original_path,backup_path,sha256,at,restored_at FROM backups ORDER BY at DESC, backup_id DESC")
            .map_err(sql)?;
        let rows = st
            .query_map([], |r| {
                Ok(Backup {
                    backup_id: r.get(0)?,
                    transaction_id: r.get(1)?,
                    original_path: r.get(2)?,
                    backup_path: r.get(3)?,
                    sha256: r.get(4)?,
                    at: r.get(5)?,
                    restored_at: r.get(6)?,
                })
            })
            .map_err(sql)?;
        rows.collect::<std::result::Result<Vec<_>, _>>()
            .map_err(sql)
    }

    pub fn get(&self, id: &str) -> Result<Option<Backup>> {
        self.db
            .conn()
            .query_row(
                "SELECT backup_id,transaction_id,original_path,backup_path,sha256,at,restored_at FROM backups WHERE backup_id=?1",
                params![id],
                |r| {
                    Ok(Backup {
                        backup_id: r.get(0)?,
                        transaction_id: r.get(1)?,
                        original_path: r.get(2)?,
                        backup_path: r.get(3)?,
                        sha256: r.get(4)?,
                        at: r.get(5)?,
                        restored_at: r.get(6)?,
                    })
                },
            )
            .optional()
            .map_err(sql)
    }

    /// Put a backup back — after backing up what is there now.
    ///
    /// A restore that overwrites the current state irreversibly is the same defect the
    /// backup existed to prevent, one level up. Restoring twice by mistake must be
    /// recoverable too.
    pub fn restore(&self, id: &str) -> Result<(Backup, Backup)> {
        let b = self.get(id)?.ok_or_else(|| {
            Error::usage("BACKUP-UNKNOWN", format!("no backup {id}")).with_zh(format!(
                "没有编号为 {id} 的备份。运行 `wf backup list` 看看有哪些。"
            ))
        })?;
        let target = PathBuf::from(&b.original_path);

        let counter = self.capture(&format!("restore-{id}"), &target)?;

        if !b.sha256.is_empty() {
            let bytes = std::fs::read(&b.backup_path).map_err(|e| {
                Error::from(e).with_zh(format!("备份文件 {} 不见了，无法恢复。", b.backup_path))
            })?;
            let got = wf_core::hash::sha256_bytes(&bytes);
            if got != b.sha256 {
                return Err(Error::integrity(
                    "BACKUP-CORRUPT",
                    format!("{}: expected {}, got {got}", b.backup_path, b.sha256),
                )
                .with_zh("这份备份的内容已经损坏，不能用来恢复。".to_string()));
            }
            wf_core::atomic::write_file(&target, &bytes)?;
            std::fs::set_permissions(&target, std::fs::metadata(&b.backup_path)?.permissions())?;
        } else {
            // The original did not exist. Restoring means removing what we put there.
            match std::fs::remove_file(&target) {
                Ok(()) => {}
                Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
                Err(e) => return Err(e.into()),
            }
        }

        self.db
            .conn()
            .execute(
                "UPDATE backups SET restored_at=?2 WHERE backup_id=?1",
                params![id, wf_core::time_fmt::now_unix()],
            )
            .map_err(sql)?;
        Ok((b, counter))
    }

    /// Drop backups outside the retention window.
    ///
    /// A backup is only removed once a newer restorable copy of the same path exists —
    /// otherwise a quiet month of no changes would delete the only copy of a file whose
    /// original is long gone.
    pub fn prune(&self) -> Result<usize> {
        let all = self.list()?;
        let cutoff = wf_core::time_fmt::now_unix() - KEEP_DAYS * 86_400;

        let mut txs: Vec<String> = Vec::new();
        for b in &all {
            if !txs.contains(&b.transaction_id) {
                txs.push(b.transaction_id.clone());
            }
        }
        let keep_txs: std::collections::HashSet<&String> =
            txs.iter().take(KEEP_TRANSACTIONS).collect();

        let mut newer_for_path: std::collections::HashMap<&str, usize> = Default::default();
        for b in &all {
            *newer_for_path.entry(b.original_path.as_str()).or_insert(0) += 1;
        }

        let mut removed = 0;
        let mut seen_for_path: std::collections::HashMap<&str, usize> = Default::default();
        for b in &all {
            let idx = seen_for_path.entry(b.original_path.as_str()).or_insert(0);
            *idx += 1;
            let is_newest_for_path = *idx == 1;
            let in_time_window = b.at >= cutoff;
            let in_count_window = keep_txs.contains(&b.transaction_id);
            if is_newest_for_path || in_time_window || in_count_window {
                continue;
            }
            let _ = std::fs::remove_file(&b.backup_path);
            self.db
                .conn()
                .execute(
                    "DELETE FROM backups WHERE backup_id=?1",
                    params![b.backup_id],
                )
                .map_err(sql)?;
            removed += 1;
        }
        Ok(removed)
    }
}

fn short_time(unix: i64) -> String {
    // Sortable and readable: 260904-143012.
    let d =
        time::OffsetDateTime::from_unix_timestamp(unix).unwrap_or(time::OffsetDateTime::UNIX_EPOCH);
    format!(
        "{:02}{:02}{:02}-{:02}{:02}{:02}",
        d.year() % 100,
        u8::from(d.month()),
        d.day(),
        d.hour(),
        d.minute(),
        d.second()
    )
}

fn short_hash(s: &str) -> String {
    wf_core::hash::sha256_bytes(s.as_bytes())[..6].to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn store<'a>(d: &tempfile::TempDir, db: &'a Db) -> Store<'a> {
        Store::new(db, d.path().join("backups"))
    }

    #[test]
    fn a_restore_is_byte_exact() {
        let d = tempfile::tempdir().unwrap();
        let db = Db::open_memory().unwrap();
        let s = store(&d, &db);
        let f = d.path().join("CLAUDE.md");
        let original = "# mine\n\nwith a trailing blank line and a \r\n or two\n";
        std::fs::write(&f, original).unwrap();

        let b = s.capture("tx1", &f).unwrap();
        std::fs::write(&f, "clobbered").unwrap();
        s.restore(&b.backup_id).unwrap();
        assert_eq!(std::fs::read_to_string(&f).unwrap(), original);
    }

    #[test]
    fn restoring_backs_up_what_it_is_about_to_replace() {
        let d = tempfile::tempdir().unwrap();
        let db = Db::open_memory().unwrap();
        let s = store(&d, &db);
        let f = d.path().join("f");
        std::fs::write(&f, "v1").unwrap();
        let b = s.capture("tx1", &f).unwrap();
        std::fs::write(&f, "v2").unwrap();

        let (_, counter) = s.restore(&b.backup_id).unwrap();
        assert_eq!(std::fs::read_to_string(&f).unwrap(), "v1");
        // The v2 that the restore replaced is itself recoverable.
        s.restore(&counter.backup_id).unwrap();
        assert_eq!(std::fs::read_to_string(&f).unwrap(), "v2");
    }

    #[test]
    fn a_file_that_did_not_exist_restores_to_not_existing() {
        let d = tempfile::tempdir().unwrap();
        let db = Db::open_memory().unwrap();
        let s = store(&d, &db);
        let f = d.path().join("created-by-wf");
        let b = s.capture("tx1", &f).unwrap();
        std::fs::write(&f, "we made this").unwrap();
        s.restore(&b.backup_id).unwrap();
        assert!(
            !f.exists(),
            "restoring an absence must remove the file we created"
        );
    }

    /// An absence is a row, not a file: a first apply that creates a thousand skill files
    /// would otherwise spend two fsyncs apiece writing empty markers nothing ever reads.
    #[test]
    fn recording_an_absence_writes_no_backup_file() {
        let d = tempfile::tempdir().unwrap();
        let db = Db::open_memory().unwrap();
        let s = store(&d, &db);
        let b = s.capture("tx1", &d.path().join("new")).unwrap();
        assert!(b.sha256.is_empty());
        assert!(!std::path::Path::new(&b.backup_path).exists());
        assert!(
            s.get(&b.backup_id).unwrap().is_some(),
            "the absence is recorded"
        );
    }

    #[test]
    fn restoring_absence_does_not_claim_to_remove_a_directory() {
        let d = tempfile::tempdir().unwrap();
        let db = Db::open_memory().unwrap();
        let s = store(&d, &db);
        let path = d.path().join("was-absent");
        let backup = s.capture("initial", &path).unwrap();
        std::fs::create_dir(&path).unwrap();
        assert!(s.restore(&backup.backup_id).is_err());
        assert!(path.is_dir());
        assert!(s
            .get(&backup.backup_id)
            .unwrap()
            .unwrap()
            .restored_at
            .is_none());
    }

    #[test]
    fn a_corrupt_backup_refuses_to_restore_rather_than_writing_garbage() {
        let d = tempfile::tempdir().unwrap();
        let db = Db::open_memory().unwrap();
        let s = store(&d, &db);
        let f = d.path().join("f");
        std::fs::write(&f, "good").unwrap();
        let b = s.capture("tx1", &f).unwrap();
        std::fs::write(&b.backup_path, "corrupted").unwrap();
        std::fs::write(&f, "current").unwrap();

        let e = s.restore(&b.backup_id).unwrap_err();
        assert_eq!(e.kind, "BACKUP-CORRUPT");
        assert_eq!(
            std::fs::read_to_string(&f).unwrap(),
            "current",
            "the target is untouched"
        );
    }

    #[test]
    fn pruning_never_removes_the_only_copy_of_a_path() {
        let d = tempfile::tempdir().unwrap();
        let db = Db::open_memory().unwrap();
        let s = store(&d, &db);
        let f = d.path().join("rare");
        std::fs::write(&f, "x").unwrap();
        let b = s.capture("tx-old", &f).unwrap();
        // Age it far past both windows.
        db.conn()
            .execute(
                "UPDATE backups SET at = ?1 WHERE backup_id = ?2",
                rusqlite::params![wf_core::time_fmt::now_unix() - 400 * 86_400, b.backup_id],
            )
            .unwrap();
        // And push it out of the count window.
        for i in 0..(KEEP_TRANSACTIONS + 2) {
            let g = d.path().join(format!("other{i}"));
            std::fs::write(&g, "y").unwrap();
            s.capture(&format!("tx{i}"), &g).unwrap();
        }
        s.prune().unwrap();
        assert!(
            s.get(&b.backup_id).unwrap().is_some(),
            "the only copy of a path survives pruning"
        );
    }
}
