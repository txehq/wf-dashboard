//! Environment: `env/env.yaml` in the team repository, one named key per variable in each
//! agent's own environment table.
//!
//! This is configuration, not credentials. A value shaped like a secret fails the scan — the
//! team repository is a Git repository, and D-018 keeps secret values out of everything `wf`
//! ships and every backup it takes — and only keys the policy allows are written.

use super::object::{Rendered, Shape};
use super::{ResourceHandler, ResourceItem, ResourceKind, ResourceMetadata, POLICY_REFUSED};
use crate::formats::env_keys;
use crate::{adapter::TeamAIAdapter, registry::PathKind, team_repo::TeamRepo};
use serde::{Deserialize, Serialize};
use wf_core::{Error, Result};

pub const ENV_FILE: &str = "env.yaml";

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct EnvFile {
    #[serde(default = "one")]
    pub schema_version: u32,
    #[serde(default)]
    pub variables: Vec<EnvVar>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct EnvVar {
    pub key: String,
    pub value: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
}

fn one() -> u32 {
    1
}

pub struct EnvHandler;

impl ResourceHandler for EnvHandler {
    fn kind(&self) -> ResourceKind {
        ResourceKind::Env
    }

    fn scan_registry(&self, repo: &TeamRepo) -> Result<Vec<ResourceItem>> {
        let Some(dir) = repo.resource_dir(ResourceKind::Env)? else {
            return Ok(vec![]);
        };
        let path = dir.join(ENV_FILE);
        let text = match std::fs::read_to_string(&path) {
            Ok(text) => text,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(vec![]),
            Err(e) => return Err(e.into()),
        };
        let file: EnvFile = serde_yaml_ng::from_str(&text)
            .map_err(|e| Error::usage("ENV-PARSE", format!("{}: {e}", path.display())))?;
        if file.schema_version != 1 {
            return Err(Error::unsupported(
                "ENV-SCHEMA",
                format!(
                    "{} declares schema_version {}",
                    path.display(),
                    file.schema_version
                ),
            ));
        }
        let mut out: Vec<ResourceItem> = Vec::new();
        for var in file.variables {
            if !crate::formats::env_name(&var.key) {
                return Err(Error::usage(
                    "ENV-KEY",
                    format!("{:?} is not an environment name", var.key),
                ));
            }
            if var
                .value
                .split_whitespace()
                .any(wf_core::redact::looks_like_secret)
            {
                return Err(Error::usage(
                    "ENV-SECRET",
                    format!(
                        "{}: the value looks like a credential; the team repository carries configuration, never secrets",
                        var.key
                    ),
                ));
            }
            if out.iter().any(|i| i.id == var.key) {
                return Err(Error::usage(
                    "ENV-DUPLICATE",
                    format!("{} is declared twice", var.key),
                ));
            }
            out.push(ResourceItem {
                id: var.key.clone(),
                name: var.key.clone(),
                kind: ResourceKind::Env,
                version: None,
                source: path.clone(),
                metadata: ResourceMetadata {
                    content_hash: wf_core::hash::sha256_bytes(var.value.as_bytes()),
                    payload: serde_json::json!({"value": var.value}),
                    ..Default::default()
                },
            });
        }
        Ok(out)
    }

    fn render(&self, item: &ResourceItem, agent: &dyn TeamAIAdapter) -> Result<Option<Rendered>> {
        let (Some(format), Some(path)) = (agent.formats().env, agent.path(PathKind::Env)) else {
            return Ok(None);
        };
        if !agent.policies().env.key_allowed(&item.id) {
            return Err(Error::usage(
                POLICY_REFUSED,
                format!("{}: not in env.allowed_keys", item.id),
            ));
        }
        let (document, keys) = env_keys(format, &item.id);
        Ok(Some(Rendered::Key {
            path,
            document,
            keys,
            value: item.metadata.payload["value"].clone(),
        }))
    }

    fn shape(&self, agent: &dyn TeamAIAdapter) -> Option<Shape> {
        agent.path(PathKind::Env)?;
        self.stored_shape(agent)
    }

    fn stored_shape(&self, agent: &dyn TeamAIAdapter) -> Option<Shape> {
        let format = agent.formats().env?;
        Some(Shape::Key(env_keys(format, "_").0))
    }
}
