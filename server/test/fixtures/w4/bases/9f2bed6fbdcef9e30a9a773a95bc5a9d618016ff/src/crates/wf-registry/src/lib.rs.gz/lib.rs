//! `workflow/registry.yaml` — the one list of everything this organization ships.
//!
//! Before this file existed, a skill was "shipped" because it happened to be in `skills/`,
//! a plugin manifest carried a version somebody remembered to bump, and nothing connected
//! the two. The registry replaces all of that with a single declaration per component, and
//! every generated surface — the lock, the bundle, the docs — is rendered from it. The
//! `plugin:` identity block stays in the schema only because wf 1.x parses this file when it
//! applies the release that retires the plugin (ADR-0007). A component that is not registered does not ship, and a
//! registered component that is not on disk fails the build.
//!
//! Two rules in here are refusals rather than defaults, and both are deliberate:
//!
//! - `required: false` is rejected outright (D-014). Every organization resource is
//!   mandatory in this release line; a schema that can express "optional" invites a
//!   component that is quietly absent on half the fleet.
//! - An unknown `kind` is an error, never a skip. Guessing at the semantics of a config
//!   file nobody wrote an adapter for is how a tool ends up writing a plausible-looking
//!   file into somebody's agent configuration.

pub mod schema;
pub mod validate;

pub use schema::*;
pub use validate::{validate, Violation};
