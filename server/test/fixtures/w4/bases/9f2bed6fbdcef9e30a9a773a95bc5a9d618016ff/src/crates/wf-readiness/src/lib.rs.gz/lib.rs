//! `wf readiness` — verify this machine can actually do a ticket's work.
//!
//! Ported from `cmd/readiness`. Three things make it more than a checklist, and all three
//! survive the port because each was the reason the tool exists:
//!
//! - **Three contexts, not one.** "Is it installed" is the wrong question; the right one is
//!   "does it resolve in the shell that will actually run it". Homebrew, pyenv, nvm, asdf
//!   and rustup all install behind a profile edit or a shim, so the answer differs by
//!   context on a completely normal machine — and a tool that answers in the developer's
//!   terminal but not in the shell the session spawns is the failure that wastes an
//!   afternoon.
//! - **Requirements are derived from the file that already pins them.** A version copied
//!   from `Cargo.toml` into a checklist is a drift surface, and the drift is silent until a
//!   build fails for a reason nobody checked.
//! - **A stat-only fingerprint decides whether to skip.** An unchanged machine costs no
//!   process spawns at all, which is what makes it affordable to run at the top of every
//!   session.
//!
//! Repair is tiered by blast radius rather than by convenience: reversible things happen on
//! their own, installs need `--repair`, and anything touching a credential is printed and
//! never executed.

pub mod catalog;
pub mod check;
pub mod components;
mod compose;
mod credentials;
pub mod manifest;
mod repair;
pub mod requirements;
pub mod resolve;
mod services;
pub mod state;

pub use check::{Finding, Severity, Tier, Verdict};
pub use requirements::{Requirements, ToolReq};
pub use resolve::{Resolution, Resolver, CTX_LOGIN, CTX_MINIMAL, CTX_SESSION};

use std::path::Path;
use wf_core::Result;

pub struct Options<'a> {
    pub root: &'a Path,
    pub profile: &'a str,
    pub extras: &'a [String],
    pub repair: bool,
    pub force: bool,
    /// Where the shipped profiles live — the bundle on an installed machine, the repo in a
    /// checkout.
    pub profile_root: Option<&'a Path>,
    /// Where the cached verdict lives. `None` means the platform cache directory; passing a
    /// path is how a test gets an isolated cache without mutating the environment.
    pub cache_dir: Option<&'a Path>,
    pub manifest: Option<&'a Path>,
    /// The compose file that defines the services asked for, relative to `root`. `None`
    /// means the manifest's `services.from`, then discovery.
    pub compose: Option<&'a Path>,
    /// The agent running the check (`claude-code`, `codex`). `None` means every agent `wf`
    /// manages on this machine.
    pub agent: Option<&'a str>,
    /// What `wf` installed. `None` means this machine's own ([`components::Installation::here`]),
    /// read only when a component is required; passing one is how a test checks a disposable
    /// installation.
    pub installation: Option<&'a components::Installation>,
    pub ttl: std::time::Duration,
}

pub fn run(opt: &Options<'_>) -> Result<Verdict> {
    let req = requirements::load(
        opt.root,
        opt.profile,
        opt.extras,
        opt.profile_root,
        opt.manifest,
        opt.compose,
    )?;
    check::check(opt, &req)
}
