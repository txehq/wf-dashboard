use std::fmt;

/// Exit codes are part of the CLI contract: scripts branch on them, so they are stable and
/// each one means exactly one thing.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(i32)]
pub enum ExitCode {
    /// Everything asked for happened.
    Ok = 0,
    /// A known operation failed, or the machine is not healthy. Actionable, retryable.
    Failure = 1,
    /// The invocation or the configuration is wrong. Retrying unchanged cannot help.
    Usage = 2,
    /// This agent, platform or version is outside the release's compatibility range.
    Unsupported = 3,
    /// Integrity or security: a digest, signature-equivalent, schema or archive check failed.
    /// Nothing downloaded under this code is ever executed.
    Integrity = 4,
    /// Another process holds the lock, or a transaction collided. Retrying later can help.
    Conflict = 5,
}

impl ExitCode {
    pub fn as_i32(self) -> i32 {
        self as i32
    }
}

/// A failure with the exit code it maps to and, where one exists, the sentence a user can
/// act on. `zh` carries the Chinese operator-facing text; `Display` carries the English
/// engineering text that goes to logs.
#[derive(Debug)]
pub struct Error {
    pub code: ExitCode,
    /// Stable, greppable class — `RELEASE-DIGEST-MISMATCH`, not a sentence.
    pub kind: String,
    pub message: String,
    /// What the operator should do next, in Chinese. Empty when there is nothing to do.
    pub zh: String,
    pub source: Option<Box<dyn std::error::Error + Send + Sync>>,
}

impl Error {
    pub fn new(code: ExitCode, kind: impl Into<String>, message: impl Into<String>) -> Self {
        Self {
            code,
            kind: kind.into(),
            message: message.into(),
            zh: String::new(),
            source: None,
        }
    }

    /// Attach the operator-facing Chinese sentence. It should say what to do, not why the
    /// internals are unhappy — the audience is someone trying to get back to work.
    pub fn with_zh(mut self, zh: impl Into<String>) -> Self {
        self.zh = zh.into();
        self
    }

    pub fn with_source(mut self, source: impl std::error::Error + Send + Sync + 'static) -> Self {
        self.source = Some(Box::new(source));
        self
    }

    pub fn usage(kind: impl Into<String>, message: impl Into<String>) -> Self {
        Self::new(ExitCode::Usage, kind, message)
    }
    pub fn failure(kind: impl Into<String>, message: impl Into<String>) -> Self {
        Self::new(ExitCode::Failure, kind, message)
    }
    pub fn integrity(kind: impl Into<String>, message: impl Into<String>) -> Self {
        Self::new(ExitCode::Integrity, kind, message)
    }
    pub fn unsupported(kind: impl Into<String>, message: impl Into<String>) -> Self {
        Self::new(ExitCode::Unsupported, kind, message)
    }
    pub fn conflict(kind: impl Into<String>, message: impl Into<String>) -> Self {
        Self::new(ExitCode::Conflict, kind, message)
    }
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}: {}", self.kind, self.message)
    }
}

impl std::error::Error for Error {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        self.source
            .as_ref()
            .map(|e| e.as_ref() as &(dyn std::error::Error + 'static))
    }
}

impl From<std::io::Error> for Error {
    fn from(e: std::io::Error) -> Self {
        let kind = match e.kind() {
            std::io::ErrorKind::NotFound => "IO-NOT-FOUND",
            std::io::ErrorKind::PermissionDenied => "IO-PERMISSION-DENIED",
            _ => "IO",
        };
        Error::new(ExitCode::Failure, kind, e.to_string())
    }
}

impl From<serde_json::Error> for Error {
    fn from(e: serde_json::Error) -> Self {
        Error::new(ExitCode::Usage, "JSON", e.to_string())
    }
}

pub type Result<T> = std::result::Result<T, Error>;
