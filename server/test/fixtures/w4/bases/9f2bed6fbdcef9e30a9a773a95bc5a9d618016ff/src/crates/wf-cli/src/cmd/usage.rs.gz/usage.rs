//! `wf usage` and `wf sessions`: what the agents' own hooks recorded on this machine.
//! Everything here reads or tidies local state; nothing is sent anywhere.

use super::emit;
use crate::flags::SessionsCmd;
use wf_agents::policy::Policies;
use wf_agents::registry::AgentRegistry;
use wf_agents::sessions::{SessionCollector, SessionStorage, SessionSummary};
use wf_agents::usage::{analytics, tracker::UsageTracker};
use wf_core::{envelope::Envelope, ExitCode, Result};
use wf_state::{Db, UsageQuery};

/// The machine's state and the active generation's agents and policy — or the built-in
/// ones, before anything is installed.
struct Local {
    paths: wf_core::paths::Paths,
    db: Db,
    agents: AgentRegistry,
    policies: Policies,
}

impl Local {
    fn open(write: bool) -> Result<Self> {
        let paths = wf_core::paths::Paths::resolve()?;
        let db = if write {
            paths.ensure_dirs()?;
            Db::open(&paths.db())?
        } else {
            Db::open_read_only(&paths.db())?
        };
        let bundle = db
            .active_generation()?
            .map(|g| paths.generation(&g.version).join("bundle"))
            .filter(|d| d.is_dir());
        let (agents, policies) = match bundle {
            Some(dir) => {
                let ctx = wf_agents::engine::Context::load(&dir, &paths)?;
                (ctx.agents, ctx.policies)
            }
            None => (AgentRegistry::builtin(), Policies::default()),
        };
        Ok(Self {
            paths,
            db,
            agents,
            policies,
        })
    }

    /// An id for an alias (`claude` → `claude-code`); a name wf does not know is kept as
    /// given, because the history may predate the agent's removal.
    fn agent_id(&self, name: Option<&str>) -> Option<String> {
        name.map(|n| self.agents.find(n).map_or(n, |s| s.id.as_str()).to_string())
    }

    fn storage(&self) -> SessionStorage {
        SessionStorage::new(&self.paths.state_dir.join("sessions"))
    }
}

pub fn usage(json: bool, since: &str, agent: Option<&str>, limit: usize) -> Result<ExitCode> {
    let local = Local::open(false)?;
    let filter = analytics::StatsFilter {
        agent: local.agent_id(agent),
        since: Some(analytics::parse_since(
            since,
            wf_core::time_fmt::now_unix_millis(),
        )?),
        limit,
    };
    let stats = analytics::compute(&local.db, &filter)?;
    let env = Envelope::new("usage").result(&stats);
    Ok(emit(json, env, move || analytics::render_zh(&stats)))
}

pub fn sessions(json: bool, cmd: SessionsCmd) -> Result<ExitCode> {
    match cmd {
        SessionsCmd::List { limit, agent } => {
            let local = Local::open(false)?;
            let rows = local
                .db
                .session_summaries(local.agent_id(agent.as_deref()).as_deref(), limit)?;
            let summaries: Vec<SessionSummary> =
                rows.iter().map(SessionSummary::from_row).collect();
            let env = Envelope::new("sessions list").result(&summaries);
            Ok(emit(json, env, move || {
                if summaries.is_empty() {
                    return "还没有会话记录。会话结束时 agent 的钩子会把摘要记在本机。\n".into();
                }
                let mut s = String::new();
                for x in &summaries {
                    s.push_str(&format!(
                        "{}  {:<12} {:<3} 工具 {:>4} 次，干预 {} 次  {}\n",
                        x.timestamp[..16].replace('T', " "),
                        x.agent,
                        if x.valuable { "★" } else { "" },
                        x.tool_total,
                        x.intervention_count,
                        x.session_id
                    ));
                }
                s
            }))
        }
        SessionsCmd::Show { id } => {
            let local = Local::open(false)?;
            let summary = local
                .db
                .session_summary(&id)?
                .map(|row| SessionSummary::from_row(&row))
                .ok_or_else(|| unknown_session(&id))?;
            let env = Envelope::new("sessions show").result(&summary);
            Ok(emit(json, env, move || {
                SessionStorage::render_entry(&summary)
            }))
        }
        SessionsCmd::Save { id } => {
            let local = Local::open(true)?;
            let id = match id {
                Some(id) => id,
                None => local
                    .db
                    .latest_session_id(None)?
                    .ok_or_else(|| unknown_session("latest"))?,
            };
            let events = local.db.usage_events(&UsageQuery {
                session_id: Some(id.clone()),
                ..Default::default()
            })?;
            let summary = SessionCollector::new(&local.policies.sessions)
                .collect_session(&id, &events)
                .ok_or_else(|| unknown_session(&id))?;
            local.db.upsert_session_summary(&summary.to_row())?;
            let log = local.storage().append_monthly_log(&summary)?;
            let env = Envelope::new("sessions save").result(serde_json::json!({
                "session": summary,
                "log": log,
            }));
            Ok(emit(json, env, move || {
                format!("已把会话 {id} 记到 {}。\n", log.display())
            }))
        }
        SessionsCmd::Prune => {
            let local = Local::open(true)?;
            let now = wf_core::time_fmt::now_unix_millis();
            // Asked for by a person, so not gated to once a day.
            local.db.set_meta("usage_pruned_on", "")?;
            let events =
                UsageTracker::new(&local.db, &local.paths.state_dir, &local.policies).prune(now)?;
            let logs = local
                .storage()
                .prune_logs(local.policies.sessions.retention_months as usize, now)?;
            let env = Envelope::new("sessions prune").result(serde_json::json!({
                "usage_events": events,
                "session_logs": logs,
            }));
            let count = logs.len();
            Ok(emit(json, env, move || {
                format!("清理了 {events} 条过期的使用记录和 {count} 个过期的会话日志。\n")
            }))
        }
    }
}

fn unknown_session(id: &str) -> wf_core::Error {
    wf_core::Error::usage("SESSION-UNKNOWN", format!("no recorded session {id}")).with_zh(format!(
        "没有找到会话 {id} 的记录。运行 `wf sessions` 看看有哪些。"
    ))
}
