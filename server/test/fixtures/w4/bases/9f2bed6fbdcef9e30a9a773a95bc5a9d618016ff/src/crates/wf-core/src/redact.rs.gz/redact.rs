//! Secret redaction, applied at every boundary that leaves this process: stdout, the
//! journal, diagnostics, and the context injected into a model.
//!
//! The rule the design rests on (D-018) is that `wf` never holds a secret *value*. This
//! module is the second fence, not the first: it catches a token that arrived in a
//! subprocess's stderr or a config file we echoed, so that a leak upstream does not become
//! a leak into a transcript.

/// Prefixes of credential formats we can recognise on sight. Matching is on the prefix plus
/// a run of token characters, so a rotated token of a different length is still caught.
const TOKEN_PREFIXES: &[&str] = &[
    "ghp_",
    "gho_",
    "ghu_",
    "ghs_",
    "ghr_",
    "github_pat_", // GitHub
    "sk-ant-",
    "sk-",
    "sk_live_",
    "sk_test_", // Anthropic / OpenAI / Stripe
    "lin_api_",
    "lin_oauth_", // Linear
    "xoxb-",
    "xoxp-",
    "xoxa-", // Slack
    "AKIA",
    "ASIA", // AWS access key ids
];

const MASK: &str = "«redacted»";

pub fn redact(input: &str) -> String {
    let mut out = String::with_capacity(input.len());
    let bytes = input.as_bytes();
    let mut i = 0;
    'outer: while i < bytes.len() {
        for p in TOKEN_PREFIXES {
            if bytes[i..].starts_with(p.as_bytes()) {
                // A prefix alone is not a secret — "sk-" appears in prose. Require enough
                // token body after it that we are looking at a credential, not a word.
                let mut j = i + p.len();
                while j < bytes.len() && is_token_byte(bytes[j]) {
                    j += 1;
                }
                if j - (i + p.len()) >= 8 {
                    out.push_str(MASK);
                    i = j;
                    continue 'outer;
                }
            }
        }
        // Also redact anything that reads as `Authorization: Bearer <blob>`.
        if bytes[i..].len() > 7 && bytes[i..].starts_with(b"Bearer ") {
            let mut j = i + 7;
            while j < bytes.len() && is_token_byte(bytes[j]) {
                j += 1;
            }
            if j - (i + 7) >= 12 {
                out.push_str("Bearer ");
                out.push_str(MASK);
                i = j;
                continue 'outer;
            }
        }
        let ch_len = utf8_len(bytes[i]);
        out.push_str(&input[i..i + ch_len]);
        i += ch_len;
    }
    out
}

/// True when a value looks like a credential — used to reject a registry entry that carries
/// a secret value where it should carry only a reference name (D-018).
pub fn looks_like_secret(value: &str) -> bool {
    let v = value.trim();
    if v.len() < 16 {
        return false;
    }
    if TOKEN_PREFIXES.iter().any(|p| v.starts_with(p)) {
        return true;
    }
    // A long, high-entropy, single-token string with no spaces and no path separators is
    // not a variable name.
    let entropy_shaped = v.len() >= 24
        && !v.contains(char::is_whitespace)
        && !v.contains('/')
        && v.chars().any(|c| c.is_ascii_digit())
        && v.chars().any(|c| c.is_ascii_uppercase())
        && v.chars().any(|c| c.is_ascii_lowercase());
    entropy_shaped
}

fn is_token_byte(b: u8) -> bool {
    b.is_ascii_alphanumeric() || b == b'_' || b == b'-'
}

fn utf8_len(b: u8) -> usize {
    match b {
        0x00..=0x7F => 1,
        0xC0..=0xDF => 2,
        0xE0..=0xEF => 3,
        _ => 4,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn masks_a_github_token_anywhere_in_a_line() {
        let got = redact("remote: fatal, token gho_ABCDEFGHIJKLMNOPQRSTUVWXYZ012345 rejected");
        assert!(!got.contains("gho_ABCDEFGH"), "{got}");
        assert!(got.contains("«redacted»"), "{got}");
        assert!(got.contains("rejected"), "surrounding text survives: {got}");
    }

    #[test]
    fn leaves_prose_that_merely_starts_like_a_prefix() {
        let s = "the sk- prefix is documented in AKIA style";
        assert_eq!(redact(s), s);
    }

    #[test]
    fn masks_a_bearer_header() {
        let got = redact("Authorization: Bearer abcdefghijklmnopqrstuvwxyz");
        assert!(got.ends_with("«redacted»"), "{got}");
    }

    #[test]
    fn survives_multibyte_input() {
        let s = "中文说明：请重新登录 gh，然后再试一次。";
        assert_eq!(redact(s), s);
    }

    #[test]
    fn recognises_a_secret_value_in_a_registry_field() {
        assert!(looks_like_secret("lin_api_0123456789abcdefghij"));
        assert!(!looks_like_secret("LINEAR_API_TOKEN"));
        assert!(!looks_like_secret("environment"));
    }
}
