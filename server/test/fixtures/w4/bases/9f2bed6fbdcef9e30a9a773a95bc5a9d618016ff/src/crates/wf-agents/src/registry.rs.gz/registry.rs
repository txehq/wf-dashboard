//! The agent registry — every coding agent `wf` can manage, as data.
//!
//! `workflow/teamai/agents.yaml` ships in the verified generation; a machine may add or
//! override entries in `<config dir>/agents.yaml` (the overlay), which is how "a new agent is
//! a few lines of configuration" stays true on a laptop before anybody cuts a release.
//!
//! Paths are relative to the agent's configuration **root**, not to the home directory,
//! because the two first-class agents relocate that root: `CLAUDE_CONFIG_DIR` and
//! `CODEX_HOME` move everything, and for Claude Code they move `.claude.json` from beside
//! `~/.claude` to *inside* the override. `root_env_paths` is where a spec says so.

use crate::formats::{AgentFormat, EnvFormat, HookFormat, McpFormat, PromptFormat, RuleFormat};
use crate::resources::ResourceKind;
use serde::{Deserialize, Serialize};
use std::path::{Component, Path, PathBuf};
use wf_core::{Error, Result};

pub const AGENTS_FILE: &str = "workflow/teamai/agents.yaml";
pub const SCHEMA_VERSION: u32 = 1;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AgentsFile {
    pub schema_version: u32,
    #[serde(default)]
    pub agents: Vec<AgentSpec>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AgentSpec {
    /// Lowercase kebab-case; what `--agent` and `wf agents register` take.
    pub id: String,
    pub display_name: String,
    /// Other names `--agent` accepts.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub aliases: Vec<String>,
    /// The name a deployed hook passes back as `--agent`, defaulting to the id. It is part
    /// of the argv Codex binds its trust to (CLM-003), so it is stated rather than derived:
    /// a name that moved when a list was reordered would cost the fleet a re-trust.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub hook_name: Option<String>,
    #[serde(default = "default_category")]
    pub category: String,
    /// The configuration root, relative to the home directory (`.claude`).
    pub root: String,
    /// An environment variable that relocates the root when it is set and non-empty.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub root_env: Option<String>,
    /// The executable whose presence on PATH also counts as installed.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub binary: Option<String>,
    #[serde(default)]
    pub paths: AgentPaths,
    /// Paths that differ when the root came from `root_env`, relative to that root.
    #[serde(default, skip_serializing_if = "AgentPaths::is_empty")]
    pub root_env_paths: AgentPaths,
    #[serde(default)]
    pub formats: AgentFormats,
}

fn default_category() -> String {
    "coding".into()
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AgentPaths {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub skills: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub rules: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub agents: Option<String>,
    /// A settings file that carries hooks and environment unless those have their own path.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub settings: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub hooks: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub prompt: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub mcp: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub env: Option<String>,
}

impl AgentPaths {
    pub fn is_empty(&self) -> bool {
        *self == Self::default()
    }

    fn get(&self, kind: PathKind) -> Option<&str> {
        match kind {
            PathKind::Skills => self.skills.as_deref(),
            PathKind::Rules => self.rules.as_deref(),
            PathKind::Agents => self.agents.as_deref(),
            PathKind::Settings => self.settings.as_deref(),
            PathKind::Hooks => self.hooks.as_deref(),
            PathKind::Prompt => self.prompt.as_deref(),
            PathKind::Mcp => self.mcp.as_deref(),
            PathKind::Env => self.env.as_deref(),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PathKind {
    Skills,
    Rules,
    Agents,
    Settings,
    Hooks,
    Prompt,
    Mcp,
    Env,
}

impl PathKind {
    pub const ALL: [PathKind; 8] = [
        PathKind::Skills,
        PathKind::Rules,
        PathKind::Agents,
        PathKind::Settings,
        PathKind::Hooks,
        PathKind::Prompt,
        PathKind::Mcp,
        PathKind::Env,
    ];

    pub fn as_str(self) -> &'static str {
        match self {
            PathKind::Skills => "skills",
            PathKind::Rules => "rules",
            PathKind::Agents => "agents",
            PathKind::Settings => "settings",
            PathKind::Hooks => "hooks",
            PathKind::Prompt => "prompt",
            PathKind::Mcp => "mcp",
            PathKind::Env => "env",
        }
    }
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AgentFormats {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub hook: Option<HookFormat>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub mcp: Option<McpFormat>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub rule: Option<RuleFormat>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub agent: Option<AgentFormat>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub prompt: Option<PromptFormat>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub env: Option<EnvFormat>,
}

/// Where one agent lives on this machine.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AgentLocation {
    pub home: PathBuf,
    pub root: PathBuf,
    pub root_from_env: bool,
}

/// One reason a registry cannot be used. Codes are stable so a CI log is greppable.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Violation {
    pub code: &'static str,
    pub subject: String,
    pub message: String,
}

impl std::fmt::Display for Violation {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}  {}: {}", self.code, self.subject, self.message)
    }
}

impl AgentSpec {
    /// Where this agent's root is, given a home directory and an environment lookup.
    pub fn locate(&self, home: &Path, env: &dyn Fn(&str) -> Option<String>) -> AgentLocation {
        if let Some(value) = self
            .root_env
            .as_deref()
            .and_then(env)
            .filter(|v| !v.is_empty())
        {
            // Joining on `home` keeps a relative value pointing at one place: resolved
            // against the working directory instead, every directory wf ran from would get
            // its own copy and forget the last one.
            return AgentLocation {
                home: home.to_path_buf(),
                root: normalize(&home.join(value)),
                root_from_env: true,
            };
        }
        AgentLocation {
            home: home.to_path_buf(),
            root: normalize(&home.join(&self.root)),
            root_from_env: false,
        }
    }

    /// Where this agent lives on this machine, from the process environment.
    pub fn locate_here(&self, home: &Path) -> AgentLocation {
        self.locate(home, &|key| std::env::var(key).ok())
    }

    /// The absolute path of one of this agent's locations, if the spec declares it. Hooks and
    /// environment fall back to `settings`, which is where Claude-shaped agents keep both.
    pub fn path(&self, location: &AgentLocation, kind: PathKind) -> Option<PathBuf> {
        let own = |kind: PathKind| {
            location
                .root_from_env
                .then(|| self.root_env_paths.get(kind))
                .flatten()
                .or_else(|| self.paths.get(kind))
                .map(|rel| normalize(&location.root.join(rel)))
        };
        match kind {
            PathKind::Hooks | PathKind::Env => own(kind).or_else(|| own(PathKind::Settings)),
            _ => own(kind),
        }
    }

    /// Every kind of resource this spec has both somewhere to write and a format for.
    pub fn supported_resources(&self) -> Vec<ResourceKind> {
        let has = |kind: PathKind| {
            self.paths.get(kind).is_some()
                || (matches!(kind, PathKind::Hooks | PathKind::Env)
                    && self.paths.settings.is_some())
        };
        let f = &self.formats;
        let mut out = Vec::new();
        if has(PathKind::Skills) {
            out.push(ResourceKind::Skill);
        }
        if has(PathKind::Rules) && f.rule.is_some() {
            out.push(ResourceKind::Rule);
        }
        if has(PathKind::Hooks) && f.hook.is_some() {
            out.push(ResourceKind::Hook);
        }
        if has(PathKind::Mcp) && f.mcp.is_some() {
            out.push(ResourceKind::Mcp);
        }
        if has(PathKind::Env) && f.env.is_some() {
            out.push(ResourceKind::Env);
        }
        if has(PathKind::Agents) && f.agent.is_some() {
            out.push(ResourceKind::Agent);
        }
        if has(PathKind::Prompt) && f.prompt.is_some() {
            out.push(ResourceKind::Prompt);
        }
        out
    }

    /// Is `name` this agent's id or one of its aliases?
    pub fn answers_to(&self, name: &str) -> bool {
        self.id == name || self.aliases.iter().any(|a| a == name)
    }

    /// The name a hook passes back as `--agent`.
    pub fn hook_name(&self) -> &str {
        self.hook_name.as_deref().unwrap_or(&self.id)
    }
}

#[derive(Debug, Clone, PartialEq, Default)]
pub struct AgentRegistry {
    agents: Vec<AgentSpec>,
}

impl AgentRegistry {
    pub fn parse(yaml: &str) -> Result<Self> {
        let file: AgentsFile = serde_yaml_ng::from_str(yaml).map_err(|e| {
            Error::usage("AGENTS-PARSE", format!("agents.yaml: {e}"))
                .with_zh("agents.yaml 读不下来，可能是格式写错了。请检查缩进、字段名和格式名称。")
        })?;
        if file.schema_version != SCHEMA_VERSION {
            return Err(Error::unsupported(
                "AGENTS-SCHEMA",
                format!(
                    "agents.yaml declares schema_version {} but this build understands {SCHEMA_VERSION}",
                    file.schema_version
                ),
            )
            .with_zh("这份 agents.yaml 比当前的 wf 版本更新。请先运行 `wf sync` 升级 wf。"));
        }
        Ok(Self {
            agents: file.agents,
        })
    }

    /// The registry this binary was built with — what a generation that predates
    /// `agents.yaml` means, and what `wf agents` shows before anything is installed.
    pub fn builtin() -> Self {
        Self::parse(include_str!("../../../workflow/teamai/agents.yaml"))
            .expect("the shipped agents.yaml parses; a test holds it to that")
    }

    /// The registry a verified generation ships.
    pub fn load(bundle_dir: &Path) -> Result<Self> {
        let path = bundle_dir.join(AGENTS_FILE);
        let text = std::fs::read_to_string(&path)
            .map_err(|e| Error::from(e).with_zh(format!("找不到 {}。", path.display())))?;
        Self::parse(&text)
    }

    /// Entries in `overlay` replace bundled entries with the same id and add the rest.
    pub fn with_overlay(mut self, overlay: &str) -> Result<Self> {
        for spec in Self::parse(overlay)?.agents {
            match self.agents.iter_mut().find(|a| a.id == spec.id) {
                Some(existing) => *existing = spec,
                None => self.agents.push(spec),
            }
        }
        Ok(self)
    }

    /// The bundled registry plus the machine's overlay file, when there is one.
    pub fn load_with_overlay(bundle_dir: &Path, overlay: &Path) -> Result<Self> {
        let base = Self::load(bundle_dir)?;
        match std::fs::read_to_string(overlay) {
            Ok(text) => base.with_overlay(&text),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(base),
            Err(e) => Err(e.into()),
        }
    }

    pub fn agents(&self) -> &[AgentSpec] {
        &self.agents
    }

    pub fn find(&self, name: &str) -> Option<&AgentSpec> {
        self.agents
            .iter()
            .find(|a| a.id == name)
            .or_else(|| self.agents.iter().find(|a| a.answers_to(name)))
    }

    /// `all`, or a comma-separated list of ids and aliases. An unknown name is a usage error.
    pub fn select(&self, spec: &str) -> Result<Vec<&AgentSpec>> {
        if spec.trim() == "all" {
            return Ok(self.agents.iter().collect());
        }
        let mut out: Vec<&AgentSpec> = Vec::new();
        for name in spec.split(',').map(str::trim).filter(|n| !n.is_empty()) {
            let agent = self.find(name).ok_or_else(|| {
                let known: Vec<&str> = self.agents.iter().map(|a| a.id.as_str()).collect();
                Error::usage(
                    "AGENT",
                    format!("{name}: expected all or one of {}", known.join(", ")),
                )
                .with_zh(format!(
                    "不认识 `{name}` 这个 agent。可选的有：all、{}。",
                    known.join("、")
                ))
            })?;
            if !out.iter().any(|a| a.id == agent.id) {
                out.push(agent);
            }
        }
        Ok(out)
    }

    pub fn validate(&self) -> Vec<Violation> {
        let mut out = Vec::new();
        let mut names = std::collections::BTreeMap::<&str, &str>::new();
        for a in &self.agents {
            let v = |code, message: String| Violation {
                code,
                subject: a.id.clone(),
                message,
            };
            if !kebab(&a.id) {
                out.push(v("AGT002", "id must be lowercase kebab-case".into()));
            }
            for name in std::iter::once(&a.id).chain(&a.aliases) {
                if let Some(owner) = names.insert(name, &a.id) {
                    out.push(v(
                        "AGT003",
                        format!("{name:?} is already the id or an alias of {owner}"),
                    ));
                }
            }
            if !a.answers_to(a.hook_name()) {
                out.push(v(
                    "AGT010",
                    format!(
                        "hook_name {:?} is neither the id nor one of the aliases, so a hook \
                         running it would name an agent --agent does not accept",
                        a.hook_name()
                    ),
                ));
            }
            if !relative_within(&a.root, 0) || a.root.is_empty() || a.root.contains("..") {
                out.push(v(
                    "AGT004",
                    format!(
                        "root {:?} must be a relative directory under the home directory",
                        a.root
                    ),
                ));
            }
            let depth = Path::new(&a.root).components().count();
            for kind in PathKind::ALL {
                if let Some(rel) = a.paths.get(kind) {
                    if !relative_within(rel, depth) {
                        out.push(v(
                            "AGT005",
                            format!("{} path {rel:?} must be relative and stay under the home directory", kind.as_str()),
                        ));
                    }
                }
                if let Some(rel) = a.root_env_paths.get(kind) {
                    if a.root_env.is_none() {
                        out.push(v(
                            "AGT007",
                            format!(
                                "root_env_paths.{} is set but the agent has no root_env",
                                kind.as_str()
                            ),
                        ));
                    } else if !relative_within(rel, 0) {
                        out.push(v(
                            "AGT007",
                            format!(
                                "root_env_paths.{} {rel:?} must stay inside the relocated root",
                                kind.as_str()
                            ),
                        ));
                    }
                }
            }
            let f = &a.formats;
            let p = &a.paths;
            let pairs = [
                ("rule", p.rules.is_some(), f.rule.is_some()),
                ("agent", p.agents.is_some(), f.agent.is_some()),
                ("mcp", p.mcp.is_some(), f.mcp.is_some()),
                ("prompt", p.prompt.is_some(), f.prompt.is_some()),
                (
                    "hook",
                    p.hooks.is_some() || p.settings.is_some(),
                    f.hook.is_some(),
                ),
                (
                    "env",
                    p.env.is_some() || p.settings.is_some(),
                    f.env.is_some(),
                ),
            ];
            for (what, has_path, has_format) in pairs {
                // `settings` alone may legitimately carry only one of hooks and env.
                let settings_only = matches!(what, "hook" | "env")
                    && p.settings.is_some()
                    && p.hooks.is_none()
                    && p.env.is_none();
                if has_path && !has_format && !settings_only {
                    out.push(v(
                        "AGT006",
                        format!("a {what} path is declared with no {what} format — wf would not know how to write it"),
                    ));
                }
                if has_format && !has_path {
                    out.push(v(
                        "AGT006",
                        format!("a {what} format is declared with nowhere to write it"),
                    ));
                }
            }
            if let Some(env) = &a.root_env {
                if !env_name(env) {
                    out.push(v(
                        "AGT008",
                        format!("root_env {env:?} is not an environment variable name"),
                    ));
                }
            }
            if let Some(binary) = &a.binary {
                if binary.is_empty()
                    || binary.contains(['/', '\\'])
                    || binary.contains(char::is_whitespace)
                {
                    out.push(v(
                        "AGT009",
                        format!("binary {binary:?} must be a bare program name"),
                    ));
                }
            }
            if a.supported_resources().is_empty() {
                out.push(v(
                    "AGT010",
                    "declares nothing wf could manage — give it at least a skills path".into(),
                ));
            }
        }
        out
    }
}

fn kebab(id: &str) -> bool {
    !id.is_empty()
        && !id.starts_with('-')
        && !id.ends_with('-')
        && id
            .bytes()
            .all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b == b'-')
}

fn env_name(name: &str) -> bool {
    !name.is_empty()
        && !name.starts_with(|c: char| c.is_ascii_digit())
        && name
            .bytes()
            .all(|b| b.is_ascii_uppercase() || b.is_ascii_digit() || b == b'_')
}

/// A relative, forward-slashed path that, joined under a directory `depth` levels below the
/// home directory, never climbs above it.
fn relative_within(rel: &str, depth: usize) -> bool {
    if rel.is_empty() || rel.starts_with('/') || rel.starts_with('~') || rel.contains('\\') {
        return false;
    }
    let mut level = depth as isize;
    for part in rel.split('/') {
        match part {
            "" | "." => return false,
            ".." => {
                level -= 1;
                if level < 0 {
                    return false;
                }
            }
            _ => level += 1,
        }
    }
    true
}

/// Lexical normalisation: `.` dropped, `..` pops. No filesystem access, so a path that does
/// not exist yet normalises the same as one that does.
fn normalize(path: &Path) -> PathBuf {
    let mut out = PathBuf::new();
    for c in path.components() {
        match c {
            Component::CurDir => {}
            Component::ParentDir => {
                out.pop();
            }
            other => out.push(other.as_os_str()),
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    const CLAUDE: &str = r#"
schema_version: 1
agents:
  - id: claude-code
    display_name: Claude Code
    aliases: [claude]
    hook_name: claude
    root: .claude
    root_env: CLAUDE_CONFIG_DIR
    binary: claude
    paths:
      skills: skills
      rules: rules
      agents: agents
      settings: settings.json
      prompt: CLAUDE.md
      mcp: ../.claude.json
    root_env_paths:
      mcp: .claude.json
    formats:
      hook: claude
      mcp: claude-json
      rule: markdown
      agent: claude-markdown
      prompt: append
      env: claude-settings
  - id: cursor
    display_name: Cursor
    root: .cursor
    paths:
      skills: skills
      rules: rules
      hooks: hooks.json
      mcp: mcp.json
    formats:
      hook: cursor
      mcp: cursor-json
      rule: cursor-mdc
"#;

    fn registry() -> AgentRegistry {
        AgentRegistry::parse(CLAUDE).expect("parses")
    }

    fn no_env(_: &str) -> Option<String> {
        None
    }

    fn codes(reg: &AgentRegistry) -> Vec<&'static str> {
        reg.validate().into_iter().map(|v| v.code).collect()
    }

    #[test]
    fn the_shipped_registry_parses_and_validates() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
        let reg = AgentRegistry::load(&root).expect("workflow/teamai/agents.yaml loads");
        assert_eq!(reg.validate(), vec![]);
        for id in [
            "claude-code",
            "codex",
            "cursor",
            "kiro",
            "zcode",
            "openclaw",
        ] {
            assert!(
                reg.find(id).is_some(),
                "{id} is not in the shipped registry"
            );
        }
    }

    #[test]
    fn a_clean_registry_has_no_violations() {
        assert_eq!(registry().validate(), vec![]);
    }

    #[test]
    fn paths_resolve_under_the_home_root_by_default() {
        let reg = registry();
        let claude = reg.find("claude").expect("alias finds the agent");
        let at = claude.locate(Path::new("/home/a"), &no_env);
        assert_eq!(at.root, PathBuf::from("/home/a/.claude"));
        assert!(!at.root_from_env);
        assert_eq!(
            claude.path(&at, PathKind::Skills),
            Some(PathBuf::from("/home/a/.claude/skills"))
        );
        // `.claude.json` sits beside `~/.claude`, not inside it.
        assert_eq!(
            claude.path(&at, PathKind::Mcp),
            Some(PathBuf::from("/home/a/.claude.json"))
        );
        // Hooks and environment live in settings.json when they have no path of their own.
        assert_eq!(
            claude.path(&at, PathKind::Hooks),
            Some(PathBuf::from("/home/a/.claude/settings.json"))
        );
        assert_eq!(
            claude.path(&at, PathKind::Env),
            Some(PathBuf::from("/home/a/.claude/settings.json"))
        );
        assert_eq!(
            claude.path(&at, PathKind::Settings),
            claude.path(&at, PathKind::Hooks)
        );
    }

    #[test]
    fn the_root_environment_variable_relocates_the_root_and_its_own_paths_apply() {
        let reg = registry();
        let claude = reg.find("claude-code").unwrap();
        let env = |key: &str| (key == "CLAUDE_CONFIG_DIR").then(|| "/work/claude-alt".to_string());
        let at = claude.locate(Path::new("/home/a"), &env);
        assert_eq!(at.root, PathBuf::from("/work/claude-alt"));
        assert!(at.root_from_env);
        assert_eq!(
            claude.path(&at, PathKind::Mcp),
            Some(PathBuf::from("/work/claude-alt/.claude.json")),
            "with an override, .claude.json lives inside it"
        );
        assert_eq!(
            claude.path(&at, PathKind::Prompt),
            Some(PathBuf::from("/work/claude-alt/CLAUDE.md"))
        );
        // An empty override is an unset variable spelled badly.
        let empty = |key: &str| (key == "CLAUDE_CONFIG_DIR").then(String::new);
        assert_eq!(
            claude.locate(Path::new("/home/a"), &empty).root,
            PathBuf::from("/home/a/.claude")
        );
        // A relative override resolves to one place. Against the working directory instead,
        // every directory `wf` ran from would get its own copy, and the recorded placement
        // would resolve somewhere else on the next run.
        let relative = |key: &str| (key == "CLAUDE_CONFIG_DIR").then(|| ".claude-work".into());
        assert_eq!(
            claude.locate(Path::new("/home/a"), &relative).root,
            PathBuf::from("/home/a/.claude-work")
        );
        let dotted = |key: &str| (key == "CLAUDE_CONFIG_DIR").then(|| "/work/x/../claude".into());
        assert_eq!(
            claude.locate(Path::new("/home/a"), &dotted).root,
            PathBuf::from("/work/claude")
        );
    }

    #[test]
    fn an_agent_supports_exactly_the_kinds_it_has_a_place_and_a_format_for() {
        let reg = registry();
        let mut claude = reg.find("claude-code").unwrap().supported_resources();
        claude.sort();
        assert_eq!(
            claude,
            vec![
                ResourceKind::Skill,
                ResourceKind::Rule,
                ResourceKind::Hook,
                ResourceKind::Mcp,
                ResourceKind::Env,
                ResourceKind::Agent,
                ResourceKind::Prompt,
            ]
        );
        let mut cursor = reg.find("cursor").unwrap().supported_resources();
        cursor.sort();
        assert_eq!(
            cursor,
            vec![
                ResourceKind::Skill,
                ResourceKind::Rule,
                ResourceKind::Hook,
                ResourceKind::Mcp
            ]
        );
    }

    #[test]
    fn a_hook_names_the_agent_by_the_name_the_entry_states() {
        let reg = registry();
        assert_eq!(reg.find("claude-code").unwrap().hook_name(), "claude");
        assert_eq!(reg.find("cursor").unwrap().hook_name(), "cursor");
        // Reordering the aliases does not move it: it is the argv Codex binds trust to.
        let reordered = CLAUDE.replace("aliases: [claude]", "aliases: [cc, claude]");
        let reg = AgentRegistry::parse(&reordered).unwrap();
        assert_eq!(reg.find("claude-code").unwrap().hook_name(), "claude");
        // And it has to be a name `--agent` accepts.
        let stray = CLAUDE.replace("hook_name: claude", "hook_name: klawd");
        assert!(codes(&AgentRegistry::parse(&stray).unwrap()).contains(&"AGT010"));
    }

    #[test]
    fn selection_takes_all_or_a_list_and_refuses_an_unknown_name() {
        let reg = registry();
        assert_eq!(reg.select("all").unwrap().len(), 2);
        let picked: Vec<&str> = reg
            .select("cursor, claude")
            .unwrap()
            .iter()
            .map(|a| a.id.as_str())
            .collect();
        assert_eq!(picked, ["cursor", "claude-code"]);
        // Duplicates collapse: `claude,claude-code` is one agent.
        assert_eq!(reg.select("claude,claude-code").unwrap().len(), 1);
        let err = reg.select("claude,windsurf").unwrap_err();
        assert_eq!(err.code, wf_core::ExitCode::Usage);
        assert!(err.message.contains("windsurf"), "{}", err.message);
    }

    #[test]
    fn an_overlay_replaces_by_id_and_adds_new_agents() {
        let reg = registry()
            .with_overlay(
                r#"
schema_version: 1
agents:
  - id: cursor
    display_name: Cursor (company build)
    root: .cursor-company
    paths:
      skills: skills
  - id: windsurf
    display_name: Windsurf
    root: .codeium/windsurf
    paths:
      skills: skills
"#,
            )
            .unwrap();
        assert_eq!(reg.agents().len(), 3);
        assert_eq!(reg.find("cursor").unwrap().root, ".cursor-company");
        assert_eq!(reg.find("windsurf").unwrap().display_name, "Windsurf");
        assert_eq!(reg.validate(), vec![]);
    }

    #[test]
    fn a_missing_overlay_file_is_the_bundled_registry() {
        let bundle = tempfile::tempdir().unwrap();
        std::fs::create_dir_all(bundle.path().join("workflow/teamai")).unwrap();
        std::fs::write(bundle.path().join(AGENTS_FILE), CLAUDE).unwrap();
        let reg = AgentRegistry::load_with_overlay(bundle.path(), &bundle.path().join("nope.yaml"))
            .unwrap();
        assert_eq!(reg, registry());
    }

    #[test]
    fn a_newer_schema_or_an_unknown_field_is_refused_rather_than_half_read() {
        let newer = CLAUDE.replace("schema_version: 1", "schema_version: 2");
        assert_eq!(
            AgentRegistry::parse(&newer).unwrap_err().code,
            wf_core::ExitCode::Unsupported
        );
        let unknown = CLAUDE.replace("binary: claude", "binary: claude\n    colour: blue");
        assert_eq!(
            AgentRegistry::parse(&unknown).unwrap_err().code,
            wf_core::ExitCode::Usage
        );
        let bad_format = CLAUDE.replace("hook: cursor", "hook: vscode");
        assert!(
            AgentRegistry::parse(&bad_format).is_err(),
            "an unknown format is not a skip"
        );
    }

    #[test]
    fn identity_rules_are_enforced() {
        let dup = format!("{CLAUDE}  - id: cursor\n    display_name: Again\n    root: .again\n    paths:\n      skills: skills\n");
        assert!(codes(&AgentRegistry::parse(&dup).unwrap()).contains(&"AGT003"));
        let alias_clash = CLAUDE.replace("aliases: [claude]", "aliases: [cursor]");
        assert!(codes(&AgentRegistry::parse(&alias_clash).unwrap()).contains(&"AGT003"));
        let bad_id = CLAUDE.replace("id: cursor", "id: Cursor IDE");
        assert!(codes(&AgentRegistry::parse(&bad_id).unwrap()).contains(&"AGT002"));
        let bad_env = CLAUDE.replace("root_env: CLAUDE_CONFIG_DIR", "root_env: \"$(whoami)\"");
        assert!(codes(&AgentRegistry::parse(&bad_env).unwrap()).contains(&"AGT008"));
        let bad_binary = CLAUDE.replace("binary: claude", "binary: /usr/bin/claude");
        assert!(codes(&AgentRegistry::parse(&bad_binary).unwrap()).contains(&"AGT009"));
    }

    #[test]
    fn paths_may_not_leave_the_home_directory_or_be_absolute() {
        for (from, to) in [
            ("root: .cursor", "root: /etc"),
            ("root: .cursor", "root: ../elsewhere"),
            ("mcp: mcp.json", "mcp: /etc/mcp.json"),
            ("mcp: mcp.json", "mcp: ../../etc/mcp.json"),
            ("mcp: mcp.json", "mcp: ~/mcp.json"),
            ("mcp: .claude.json", "mcp: ../.claude.json"),
        ] {
            let reg = AgentRegistry::parse(&CLAUDE.replacen(from, to, 1)).unwrap();
            let found = codes(&reg);
            assert!(
                found.contains(&"AGT004") || found.contains(&"AGT005") || found.contains(&"AGT007"),
                "{from} -> {to} was accepted: {found:?}"
            );
        }
    }

    #[test]
    fn a_path_without_a_format_or_a_format_without_a_path_is_refused() {
        let no_format = CLAUDE.replace("      rule: cursor-mdc\n", "");
        assert!(codes(&AgentRegistry::parse(&no_format).unwrap()).contains(&"AGT006"));
        let no_path = CLAUDE.replace("      hooks: hooks.json\n", "");
        assert!(codes(&AgentRegistry::parse(&no_path).unwrap()).contains(&"AGT006"));
        let root_env_paths_without_env = CLAUDE.replace("    root_env: CLAUDE_CONFIG_DIR\n", "");
        assert!(
            codes(&AgentRegistry::parse(&root_env_paths_without_env).unwrap()).contains(&"AGT007")
        );
    }

    #[test]
    fn an_agent_with_nothing_to_manage_is_refused() {
        let empty = CLAUDE.replace(
            "    paths:\n      skills: skills\n      rules: rules\n      hooks: hooks.json\n      mcp: mcp.json\n    formats:\n      hook: cursor\n      mcp: cursor-json\n      rule: cursor-mdc\n",
            "",
        );
        assert!(codes(&AgentRegistry::parse(&empty).unwrap()).contains(&"AGT010"));
    }
}
