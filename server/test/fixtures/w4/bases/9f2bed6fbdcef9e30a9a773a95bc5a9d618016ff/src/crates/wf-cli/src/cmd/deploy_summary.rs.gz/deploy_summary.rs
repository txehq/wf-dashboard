//! `wf deploy-summary` — the facts a stakeholder brief is written from.
//!
//! It reports what a change is and whether it is running. It does not write the brief: the
//! sentence a non-engineer can act on is judgment, and no command produces it.

use super::emit;
use std::path::PathBuf;
use wf_core::{envelope::Envelope, envelope::Note, Error, ExitCode, Result};
use wf_deploy_summary::{Brief, Deployment};

pub fn run(
    json: bool,
    prs: &[u32],
    context: Option<&str>,
    namespace: &str,
    production: bool,
) -> Result<ExitCode> {
    if prs.is_empty() {
        return Err(Error::usage(
            "DEPLOY-SUMMARY-NO-PR",
            "name at least one merged pull request with --pr",
        )
        .with_zh("请用 --pr 指定至少一个已合并的 PR。"));
    }
    if let Some(c) = context {
        if !production && looks_like_production(c) {
            return Err(Error::usage(
                "DEPLOY-SUMMARY-PRODUCTION",
                format!("{c} looks like production — pass --production to say so on purpose"),
            )
            .with_zh("该上下文看起来是生产环境，请显式加上 --production。"));
        }
    }

    let root: PathBuf = super::tools::git_root();
    let changes = wf_deploy_summary::changes(&root, prs)?;

    let (deployment, environment) = match context {
        Some(c) => (
            wf_deploy_summary::deployment(&root, c, namespace, &changes),
            format!("{c}/{namespace}"),
        ),
        // No environment named is itself an unknown, not a "not deployed". The brief has to
        // say which it is, and "nobody looked" is a different sentence from "it isn't there".
        None => (
            Deployment::Unknown {
                why: "no environment was named — pass --context to check one".into(),
            },
            "none".into(),
        ),
    };

    let brief = Brief {
        changes,
        environment,
        deployment,
        unchecked: vec![
            "a change is linked to a running container by its commit appearing in an image \
             tag; a product that does not tag that way makes the link invisible here"
                .into(),
            "migration state is not read — it is a separate fact with its own artifact".into(),
            "whether the change behaves correctly is not established, only whether it is \
             running"
                .into(),
        ],
    };

    let unknown = !brief.deployment.is_known();
    let mut env = Envelope::new("deploy-summary").result(&brief);
    if unknown {
        env = env.warn(Note::new("UNKNOWN", brief.deployment.sentence()));
    }
    if brief.tickets().is_empty() {
        env = env.warn(Note::new(
            "NO-TICKETS",
            "no ticket ids on these pull requests — nothing to record the page against".to_string(),
        ));
    }

    let text = render(&brief);
    emit(json, env, move || text);
    // An unknown deployment state is not a failure of the command — the brief is complete and
    // says plainly that the question is open. Exit 0 so a summary can still be published; the
    // page carries the honesty, not the exit code.
    Ok(ExitCode::Ok)
}

/// Production is named, never inferred into.
fn looks_like_production(context: &str) -> bool {
    let c = context.to_ascii_lowercase();
    ["prod", "production", "live"]
        .iter()
        .any(|m| c.split(['-', '_', '.']).any(|seg| seg == *m))
}

fn render(b: &Brief) -> String {
    let mut s = String::new();
    for c in &b.changes {
        s.push_str(&format!(
            "#{}  {}\n  {}\n  by {} · merged {} · {} file(s) +{} −{}\n",
            c.number,
            c.title,
            c.url,
            c.author,
            c.merged_at,
            c.files_changed,
            c.additions,
            c.deletions
        ));
        if !c.tickets.is_empty() {
            s.push_str(&format!("  tickets  {}\n", c.tickets.join(", ")));
        }
        s.push('\n');
    }
    s.push_str(&format!("staging  {}\n", b.deployment.sentence()));
    s.push_str("\nnot checked:\n");
    for u in &b.unchecked {
        s.push_str(&format!("  - {u}\n"));
    }
    s.push_str(
        "\nThese are facts, not the brief. The page says what shipped in a sentence a\n\
         non-engineer can act on, why, and where to see it — see the skill.\n",
    );
    s
}

#[cfg(test)]
mod tests {
    use super::looks_like_production;

    #[test]
    fn production_contexts_are_recognised_by_segment() {
        for c in ["capso-prod-hk", "acme_production", "live.cluster", "PROD"] {
            assert!(looks_like_production(c), "missed {c}");
        }
    }

    #[test]
    fn a_word_merely_containing_prod_is_not_production() {
        // `reproducible` and `product-dev` contain "prod"; treating them as production fires
        // the guard on ordinary development clusters, and a guard that cries wolf gets turned
        // off. Segment equality, not substring.
        for c in [
            "capso-development-hk",
            "product-dev",
            "reproducible-testing",
            "capso-txe-devcontainers",
        ] {
            assert!(!looks_like_production(c), "false positive on {c}");
        }
    }
}
