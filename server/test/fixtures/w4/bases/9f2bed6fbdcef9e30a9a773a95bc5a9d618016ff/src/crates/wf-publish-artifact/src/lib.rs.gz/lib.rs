//! `wf publish-artifact` — upload a page or an image to the org's own domain and print the
//! URL.
//!
//! The tests hold three parsing properties:
//!
//! - A ticket id is derived with a leading word boundary, so the branch `feat-99-x` does not
//!   yield the ticket `t-99` out of the letter "t" in "feat".
//! - Generated ids are held to the same format check as `--id`, so a short generated id
//!   cannot be uploaded without complaint.
//! - A flag whose value is missing says so.
//!
//! The credentials file is *read*, never sourced, so nothing in it runs. A 200 on PUT is
//! followed by a read-back of the object before the URL is printed: a URL that 404s is never
//! handed out.
//!
//! One credential: the Access service token. Cloudflare Access is the whole gate — the service
//! token gets the request past it, and nothing else stands between a signed-in caller and the
//! bucket. An `ENGAPP_UPLOAD_TOKEN` key in the env file is ignored.

pub mod meta;
pub mod parse;
pub mod proxy;

pub use parse::{content_type_for, new_id, valid_id, ContentType, Kind};
pub use proxy::Route;

use std::path::Path;
use std::time::Duration;
use wf_core::{Error, Result};

const HTTP_TIMEOUT: Duration = Duration::from_secs(60);

#[derive(Debug, Clone)]
pub struct Credentials {
    pub base: String,
    pub access_id: String,
    pub access_secret: String,
}

const CREDENTIAL_NOTE: &str = "see the publish-artifacts skill, §Setup";

impl Credentials {
    /// Read the env file without sourcing it.
    pub fn load() -> Result<Self> {
        let path = match std::env::var_os("ENGAPP_ARTIFACTS_CRED") {
            Some(p) => std::path::PathBuf::from(p),
            None => {
                let home = std::env::var_os("HOME")
                    .map(std::path::PathBuf::from)
                    .ok_or_else(|| Error::usage("NO-HOME", "HOME is not set"))?;
                home.join(".config/engapp-artifacts/env")
            }
        };
        let text = std::fs::read_to_string(&path).map_err(|_| {
            Error::failure("PUBLISH-NO-CREDENTIALS", format!("no credentials at {} — {CREDENTIAL_NOTE}", path.display()))
                .with_zh(format!(
                    "还没有配置发布用的凭据（{}）。按 `/publish-artifacts` 技能里的「Setup」一节配置一次就好。",
                    path.display()
                ))
        })?;
        let vars = parse_env_file(&text);
        let get = |k: &str| vars.get(k).cloned().unwrap_or_default();
        let cred = Credentials {
            base: get("ENGAPP_ARTIFACTS_BASE"),
            access_id: get("CF_ACCESS_CLIENT_ID"),
            access_secret: get("CF_ACCESS_CLIENT_SECRET"),
        };
        let missing: Vec<&str> = [
            ("ENGAPP_ARTIFACTS_BASE", &cred.base),
            ("CF_ACCESS_CLIENT_ID", &cred.access_id),
            ("CF_ACCESS_CLIENT_SECRET", &cred.access_secret),
        ]
        .iter()
        .filter(|(_, v)| v.is_empty())
        .map(|(n, _)| *n)
        .collect();
        if !missing.is_empty() {
            return Err(Error::failure(
                "PUBLISH-CREDENTIALS-INCOMPLETE",
                format!(
                    "{} is missing {} — {CREDENTIAL_NOTE}",
                    path.display(),
                    missing.join(", ")
                ),
            )
            .with_zh(format!(
                "{} 里还缺 {}。按技能里的「Setup」补齐就行。",
                path.display(),
                missing.join("、")
            )));
        }
        Ok(cred)
    }
}

pub fn parse_env_file(text: &str) -> std::collections::BTreeMap<String, String> {
    let mut out = std::collections::BTreeMap::new();
    for line in text.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let line = line.strip_prefix("export ").unwrap_or(line);
        let Some((k, v)) = line.split_once('=') else {
            continue;
        };
        out.insert(
            k.trim().to_string(),
            v.trim().trim_matches(['"', '\'']).to_string(),
        );
    }
    out
}

pub struct Options<'a> {
    pub file: &'a Path,
    pub title: &'a str,
    pub kind: Option<&'a str>,
    pub id: Option<&'a str>,
    pub dry_run: bool,
}

/// Publish, and return the URL.
pub fn publish(opt: &Options<'_>) -> Result<String> {
    if opt.title.trim().is_empty() {
        // Not decoration: the title is the only human-readable thing on the index.
        return Err(Error::usage(
            "PUBLISH-NO-TITLE",
            "--title is required — it is what the index shows, and a file name is not a title",
        )
        .with_zh(
            "发布需要一个标题（`--title`）。索引页上只显示这个，文件名不算标题。".to_string(),
        ));
    }
    let meta_info = std::fs::metadata(opt.file).map_err(|e| {
        Error::failure("PUBLISH-FILE", format!("file missing or unreadable: {e}"))
            .with_zh(format!("读不到 {}。请确认路径对不对。", opt.file.display()))
    })?;
    let ct = content_type_for(opt.file)?;
    let kind = match opt.kind {
        Some(k) => Kind::parse(k).ok_or_else(|| {
            Error::usage(
                "PUBLISH-KIND",
                format!("--kind must be page or img, got {k:?}"),
            )
            .with_zh("`--kind` 只能是 page 或 img。".to_string())
        })?,
        None => ct.kind,
    };
    if let Some(id) = opt.id {
        if !valid_id(id) {
            return Err(Error::usage(
                "PUBLISH-ID",
                format!("--id must be 8 characters of [0-9a-z], got {id:?}"),
            )
            .with_zh("`--id` 必须是 8 位的小写字母或数字。".to_string()));
        }
    }

    let meta = meta::collect(opt.file, kind, meta_info.len());
    let meta_json = serde_json::to_string(&meta)?;

    if opt.dry_run {
        // Everything up to the network, and nothing after it: the same parsing, the same
        // content type, the same provenance — so a rehearsal exercises what actually breaks.
        let id = opt.id.map(str::to_string).unwrap_or_else(new_id);
        return Ok(format!(
            "{}/{}/{}",
            "(dry-run) ".to_string() + base_of_dry_run().trim_end_matches('/'),
            kind.as_str(),
            id
        ));
    }

    let cred = Credentials::load()?;
    let route = Route::from_env();
    let base = cred.base.trim_end_matches('/').to_string();
    let id = match opt.id {
        Some(i) => i.to_string(),
        None => free_id(&cred, &route, kind)?,
    };
    let url = format!("{base}/{}/{id}", kind.as_str());
    let body = std::fs::read(opt.file)?;

    let resp = ureq::put(&url)
        .header("CF-Access-Client-Id", &cred.access_id)
        .header("CF-Access-Client-Secret", &cred.access_secret)
        .header("Content-Type", ct.mime)
        .header("X-Artifact-Title", opt.title)
        .header("X-Artifact-Session", &meta.session)
        .header("X-Artifact-Meta", &meta_json)
        .config()
        .timeout_global(Some(HTTP_TIMEOUT))
        .proxy(route.proxy.clone())
        .build()
        .send(&body[..]);

    match resp {
        Ok(r) if r.status() == 200 => {}
        Ok(mut r) => {
            let status = r.status();
            let detail = r.body_mut().read_to_string().unwrap_or_default();
            return Err(Error::failure(
                "PUBLISH-HTTP",
                format!("upload failed (HTTP {status}): {}", detail.trim()),
            )
            .with_zh(
                "上传没有成功。稍后再试一次；如果一直不行，请把这条消息发给团队。".to_string(),
            ));
        }
        Err(e) => {
            return Err(network_error(
                &route.explain(&url, &e),
                "upload failed",
                "上传的时候网络出错了。",
                "检查一下网络之后再试一次。",
            ))
        }
    }

    // A 200 on PUT is not proof the object is servable. Handing out a URL that 404s is worse
    // than failing here.
    read_back(&cred, &route, &url)?;
    Ok(url)
}

/// A failed request. A failure at the proxy takes its `PUBLISH-PROXY-*` class and the proxy's
/// advice; anything else is `PUBLISH-NETWORK` with the generic retry.
fn network_error(x: &proxy::Explanation, stage: &str, zh_stage: &str, zh_retry: &str) -> Error {
    match x.kind {
        Some(kind) => Error::failure(kind, format!("{stage}: {}", x.en))
            .with_zh(format!("{zh_stage}{}", x.zh)),
        None => Error::failure("PUBLISH-NETWORK", format!("{stage}: {}", x.en))
            .with_zh(format!("{zh_stage}{zh_retry}{}", x.zh)),
    }
}

fn base_of_dry_run() -> String {
    Credentials::load()
        .map(|c| c.base)
        .unwrap_or_else(|_| "https://engapp.dev/artifacts".to_string())
}

/// Generate ids until one is unused. Regenerating on collision rather than overwriting is
/// the whole reason this check exists: a collision would silently replace someone else's page.
fn free_id(cred: &Credentials, route: &Route, kind: Kind) -> Result<String> {
    let base = cred.base.trim_end_matches('/');
    for _ in 0..5 {
        let id = new_id();
        let url = format!("{base}/{}/{id}", kind.as_str());
        let resp = ureq::head(&url)
            .header("CF-Access-Client-Id", &cred.access_id)
            .header("CF-Access-Client-Secret", &cred.access_secret)
            .config()
            .timeout_global(Some(HTTP_TIMEOUT))
            .proxy(route.proxy.clone())
            .build()
            .call();
        match resp {
            Ok(r) if r.status() == 404 => return Ok(id),
            Ok(_) => continue,
            // ureq surfaces a 404 as an error unless configured otherwise; treat it as free.
            Err(ureq::Error::StatusCode(404)) => return Ok(id),
            Err(e) => {
                return Err(network_error(
                    &route.explain(&url, &e),
                    "checking id availability",
                    "检查地址是否可用时网络出错了。",
                    "稍后再试一次。",
                ))
            }
        }
    }
    Err(Error::failure(
        "PUBLISH-ID-EXHAUSTED",
        "could not find a free id in 5 attempts",
    )
    .with_zh("连续 5 次生成的地址都被占用了，这不太正常。请把这条消息发给团队。".to_string()))
}

fn read_back(cred: &Credentials, route: &Route, url: &str) -> Result<()> {
    let resp = ureq::get(url)
        .header("CF-Access-Client-Id", &cred.access_id)
        .header("CF-Access-Client-Secret", &cred.access_secret)
        .config()
        .timeout_global(Some(HTTP_TIMEOUT))
        .proxy(route.proxy.clone())
        .build()
        .call();
    match resp {
        Ok(r) if r.status() == 200 => Ok(()),
        Ok(r) => Err(Error::failure(
            "PUBLISH-NOT-SERVABLE",
            format!(
                "uploaded but NOT servable (HTTP {}) — do not hand this URL out",
                r.status()
            ),
        )
        .with_zh("文件传上去了，但还打不开，先不要把链接发出去。过一会儿再发一次。".to_string())),
        Err(e) => {
            // The upload went through, so the URL must not be handed out whatever the cause:
            // the class stays PUBLISH-NOT-SERVABLE, and the proxy's advice, if any, rides along.
            let x = route.explain(url, &e);
            let retry = if x.kind.is_some() {
                ""
            } else {
                "过一会儿再发一次。"
            };
            Err(Error::failure(
                "PUBLISH-NOT-SERVABLE",
                format!(
                    "uploaded but could not be read back: {} — do not hand this URL out",
                    x.en
                ),
            )
            .with_zh(format!(
                "文件传上去了，但还打不开，先不要把链接发出去。{retry}{}",
                x.zh
            )))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn an_env_file_is_read_never_sourced() {
        // The shell version ran `.` on this file. A command substitution here must be
        // inert text, not an execution.
        let vars = parse_env_file(
            "# comment\nexport ENGAPP_ARTIFACTS_BASE=\"https://x/artifacts\"\nCF_ACCESS_CLIENT_ID='i'\nEVIL=$(touch /tmp/wf-sourced)\n",
        );
        assert_eq!(vars["ENGAPP_ARTIFACTS_BASE"], "https://x/artifacts");
        assert_eq!(vars["CF_ACCESS_CLIENT_ID"], "i");
        assert_eq!(vars["EVIL"], "$(touch /tmp/wf-sourced)");
        assert!(!Path::new("/tmp/wf-sourced").exists());
    }

    #[test]
    fn a_stale_upload_token_in_the_env_file_is_not_an_error() {
        // The Worker no longer checks X-Upload-Token, so the key is dead weight — but a
        // machine that still carries it must keep publishing. Reading it and shrugging is
        // the whole point; only the three live keys are required.
        let vars = parse_env_file(
            "ENGAPP_ARTIFACTS_BASE=https://engapp.dev/artifacts\nENGAPP_UPLOAD_TOKEN=leftover\nCF_ACCESS_CLIENT_ID=i\nCF_ACCESS_CLIENT_SECRET=s\n",
        );
        assert_eq!(vars["ENGAPP_UPLOAD_TOKEN"], "leftover");
        // Nothing in the credential path reads it any more.
        let cred = Credentials {
            base: vars["ENGAPP_ARTIFACTS_BASE"].clone(),
            access_id: vars["CF_ACCESS_CLIENT_ID"].clone(),
            access_secret: vars["CF_ACCESS_CLIENT_SECRET"].clone(),
        };
        assert_eq!(cred.base, "https://engapp.dev/artifacts");
        assert_eq!(cred.access_id, "i");
        assert_eq!(cred.access_secret, "s");
    }

    #[test]
    fn a_missing_title_says_why_rather_than_exiting_silently() {
        let d = tempfile::tempdir().unwrap();
        let f = d.path().join("x.html");
        std::fs::write(&f, "<p>x</p>").unwrap();
        let e = publish(&Options {
            file: &f,
            title: "  ",
            kind: None,
            id: None,
            dry_run: true,
        })
        .unwrap_err();
        assert_eq!(e.kind, "PUBLISH-NO-TITLE");
        assert!(!e.zh.is_empty());
    }

    #[test]
    fn a_bad_id_is_refused_before_anything_is_uploaded() {
        let d = tempfile::tempdir().unwrap();
        let f = d.path().join("x.html");
        std::fs::write(&f, "<p>x</p>").unwrap();
        let e = publish(&Options {
            file: &f,
            title: "t",
            kind: None,
            id: Some("SHORT"),
            dry_run: true,
        })
        .unwrap_err();
        assert_eq!(e.kind, "PUBLISH-ID");
    }

    #[test]
    fn a_dry_run_does_everything_except_the_network() {
        let d = tempfile::tempdir().unwrap();
        let f = d.path().join("page.html");
        std::fs::write(&f, "<p>x</p>").unwrap();
        let url = publish(&Options {
            file: &f,
            title: "t",
            kind: None,
            id: Some("abcd1234"),
            dry_run: true,
        })
        .unwrap();
        assert!(url.contains("/page/abcd1234"), "{url}");
        assert!(url.starts_with("(dry-run)"), "{url}");
    }
}
