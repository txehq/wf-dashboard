use crate::requirements::{CredReq, Requirements, ServiceReq, SourceFile, ToolReq};
use serde::Deserialize;
use std::path::{Path, PathBuf};
use wf_core::{Error, Result};

#[derive(Default, Deserialize)]
#[serde(deny_unknown_fields)]
struct Manifest {
    version: u32,
    #[serde(default)]
    toolchains: Vec<DeclaredTool>,
    #[serde(default)]
    services: Services,
    #[serde(default)]
    credentials: Vec<DeclaredCredential>,
    /// Registry components the agent running the check must carry.
    #[serde(default)]
    components: Vec<String>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct DeclaredTool {
    id: String,
    #[serde(default)]
    min: String,
    #[serde(default)]
    version_from: String,
    #[serde(default)]
    optional: bool,
}

#[derive(Default, Deserialize)]
#[serde(deny_unknown_fields)]
struct Services {
    #[serde(default)]
    from: String,
    #[serde(default)]
    need: Vec<String>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct DeclaredCredential {
    id: String,
    #[serde(default)]
    env: Vec<String>,
    #[serde(default)]
    capabilities: Vec<String>,
    #[serde(default)]
    probe: bool,
}

/// Explicit override, repository declaration, then the organization declaration for the
/// repository's origin. An absent implicit manifest is not an error.
pub fn resolve(
    root: &Path,
    profile_root: Option<&Path>,
    explicit: Option<&Path>,
) -> Option<PathBuf> {
    if let Some(path) = explicit {
        return Some(if path.is_absolute() {
            path.to_path_buf()
        } else {
            root.join(path)
        });
    }
    let local = root.join("readiness.yaml");
    if local.is_file() {
        return Some(local);
    }
    let remote = wf_core::proc::run_in(
        "git",
        &["remote", "get-url", "origin"],
        &[],
        Some(root),
        std::time::Duration::from_secs(2),
    )
    .ok()?;
    if !remote.ok() {
        return None;
    }
    let remote = remote
        .stdout
        .trim()
        .trim_end_matches(".git")
        .replace(':', "/");
    let parts: Vec<_> = remote.split('/').filter(|s| !s.is_empty()).collect();
    if parts.len() < 2 {
        return None;
    }
    let (owner, repo) = (parts[parts.len() - 2], parts[parts.len() - 1]);
    if [owner, repo].iter().any(|s| {
        *s == "."
            || *s == ".."
            || !s
                .chars()
                .all(|c| c.is_ascii_alphanumeric() || "._-".contains(c))
    }) {
        return None;
    }
    // A checkout cloned before the org rename still names the old owner in its origin, and
    // an absent implicit manifest is not an error, so a literal lookup would pass silently
    // with half the requirements missing (TXE-1927).
    let owner = wf_core::canonical_owner(owner);
    let relative = format!("manifests/{owner}/{repo}.yaml");
    let mut roots = vec![root.to_path_buf()];
    if let Some(path) = profile_root {
        roots.push(path.to_path_buf());
    }
    if let Ok(paths) = wf_core::paths::Paths::resolve() {
        roots.push(paths.active_link().join("bundle"));
    }
    roots
        .into_iter()
        .map(|r| r.join(&relative))
        .find(|p| p.is_file())
}

/// The directories a compose file is looked for in, in order: the repository root, where
/// Docker Compose itself looks, then the directories repositories keep deployment files in.
const COMPOSE_DIRS: [&str; 5] = ["", "deploy", "deployments", "docker", ".devcontainer"];

/// Docker Compose's own file names, in its order of preference.
const COMPOSE_NAMES: [&str; 4] = [
    "compose.yaml",
    "compose.yml",
    "docker-compose.yaml",
    "docker-compose.yml",
];

/// The first compose file under `root`, taking the directories in order and, within one,
/// the name Compose itself prefers.
fn discover_compose(root: &Path) -> Option<String> {
    COMPOSE_DIRS
        .iter()
        .flat_map(|dir| {
            COMPOSE_NAMES
                .iter()
                .map(move |name| Path::new(dir).join(name).to_string_lossy().into_owned())
        })
        .find(|p| root.join(p).is_file())
}

/// Where discovery looked, in the words an error can print.
fn compose_search_description() -> String {
    let dirs: Vec<String> = COMPOSE_DIRS
        .iter()
        .map(|d| {
            if d.is_empty() {
                "./".into()
            } else {
                format!("{d}/")
            }
        })
        .collect();
    format!("{} in {}", COMPOSE_NAMES.join(", "), dirs.join(", "))
}

pub fn load_into(
    req: &mut Requirements,
    root: &Path,
    manifest: Option<&Path>,
    ticket_extras: &[String],
    compose: Option<&Path>,
) -> Result<()> {
    let mut declared = Manifest::default();
    if let Some(path) = manifest {
        let text = std::fs::read_to_string(path)?;
        declared = serde_yaml_ng::from_str(&text)
            .map_err(|e| Error::usage("READINESS-MANIFEST", format!("{}: {e}", path.display())))?;
        if declared.version != 1 {
            return Err(Error::unsupported(
                "READINESS-MANIFEST",
                "manifest version must be 1",
            ));
        }
        req.sources.push(SourceFile {
            path: path.to_string_lossy().into_owned(),
            hash: wf_core::hash::sha256_bytes(text.as_bytes()),
        });
        for tool in declared.toolchains {
            let id = crate::catalog::canonical(&tool.id).to_string();
            let mut t = ToolReq {
                id: id.clone(),
                min: tool.min,
                optional: tool.optional,
                from: path.to_string_lossy().into_owned(),
                ..Default::default()
            };
            if !tool.version_from.is_empty() {
                let (pin, source) =
                    crate::requirements::derive_version(root, &tool.version_from, &id)?;
                t.min = pin.min;
                t.exact = pin.exact;
                t.from = tool.version_from;
                req.sources.push(source);
            }
            req.tools.push(t);
        }
        req.components.extend(declared.components);
        req.credentials
            .extend(declared.credentials.into_iter().map(|c| CredReq {
                id: c.id,
                env: c.env,
                capabilities: c.capabilities,
                allow_probe: c.probe,
                ..Default::default()
            }));
    }
    let mut need = declared.services.need;
    let candidates = crate::requirements::ticket_needs(req, ticket_extras);
    if need.is_empty() && candidates.is_empty() {
        return Ok(());
    }
    // Named beats discovered: `--compose`, then the manifest's `services.from`.
    let named = compose
        .map(|p| p.to_string_lossy().into_owned())
        .or_else(|| (!declared.services.from.is_empty()).then_some(declared.services.from));
    let file = match named {
        Some(file) if !root.join(&file).is_file() => {
            return Err(Error::usage(
                "READINESS-SERVICE",
                format!("compose file {} does not exist", root.join(&file).display()),
            )
            .with_zh(format!(
                "指定的 compose 文件 {} 不存在。检查 `--compose` 或者清单里的 `services.from`。",
                root.join(&file).display()
            )));
        }
        Some(file) => Some(file),
        None => discover_compose(root),
    };
    let compose = match &file {
        Some(file) => {
            // The file and the project's `.env` beside it both change what Compose answers.
            let path = root.join(file);
            let env = path.parent().map(|dir| dir.join(".env"));
            for source in std::iter::once(path.clone()).chain(env.filter(|p| p.is_file())) {
                req.sources.push(SourceFile {
                    hash: wf_core::hash::sha256_bytes(&std::fs::read(&source)?),
                    path: source.to_string_lossy().into_owned(),
                });
            }
            Some(crate::compose::service_names(root, file)?)
        }
        None => None,
    };
    let where_looked = match &file {
        Some(file) => format!("{file} defines no such service"),
        None => format!(
            "no compose file was found under {} (looked for {})",
            root.display(),
            compose_search_description()
        ),
    };
    // A name compose claims is a service; one it does not claim is a tool when the session
    // can run it, and otherwise nothing this check can verify.
    let mut unresolved = Vec::new();
    for name in candidates {
        if compose.as_ref().is_some_and(|c| c.contains(&name)) {
            need.push(name);
        } else if wf_core::proc::which(&name).is_some() {
            req.tools.push(ToolReq {
                id: name,
                from: "--need".into(),
                ..Default::default()
            });
        } else {
            unresolved.push(name);
        }
    }
    if !unresolved.is_empty() {
        let names = unresolved.join(", ");
        return Err(Error::usage(
            "READINESS-NEED",
            format!(
                "--need {names}: not a known toolchain, not on PATH, and {where_looked}; \
                 name the compose file with --compose <path>, or give a tool a version \
                 (--need '{}>=0')",
                unresolved[0]
            ),
        )
        .with_zh(format!(
            "`--need {names}` 既不是认识的工具链，也不在 PATH 里；{}。如果它是一个服务，用 `--compose <路径>` 指出 compose 文件。",
            match &file {
                Some(file) => format!("{file} 里也没有定义这个服务"),
                None => format!(
                    "在 {} 下面也没有找到 compose 文件（找过 {}）",
                    root.display(),
                    compose_search_description()
                ),
            }
        )));
    }
    need.sort();
    need.dedup();
    if need.is_empty() {
        return Ok(());
    }
    let (Some(file), Some(compose)) = (file, compose) else {
        let names = need.join(", ");
        return Err(Error::usage(
            "READINESS-SERVICE",
            format!("services {names} need a compose file, and {where_looked}; name one with --compose <path> or services.from in the manifest"),
        )
        .with_zh(format!(
            "服务 {names} 需要一个 compose 文件，但在 {} 下面没有找到（找过 {}）。用 `--compose <路径>` 或者清单里的 `services.from` 指出它。",
            root.display(),
            compose_search_description()
        )));
    };
    for name in need {
        if !compose.contains(&name) {
            return Err(Error::usage(
                "READINESS-SERVICE",
                format!("{file}: required service {name} is not defined; name the compose file that defines it with --compose <path>"),
            ));
        }
        req.services.push(ServiceReq {
            name,
            from: file.clone(),
        });
    }
    req.tools.push(ToolReq {
        id: "docker".into(),
        from: file,
        ..Default::default()
    });
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A repository with the empty consumer profile and the given files.
    fn repo(files: &[(&str, &str)]) -> tempfile::TempDir {
        let dir = tempfile::tempdir().unwrap();
        let mut all = vec![(
            "workflow/readiness/consumer.yaml",
            "schema_version: 1\nprofile: consumer\nrequirements: []\n",
        )];
        all.extend_from_slice(files);
        for (path, text) in all {
            let path = dir.path().join(path);
            std::fs::create_dir_all(path.parent().unwrap()).unwrap();
            std::fs::write(path, text).unwrap();
        }
        dir
    }

    const POSTGRES: &str =
        "services:\n  postgres:\n    image: postgres:18-alpine\n    ports: ['127.0.0.1:5432:5432']\n";

    fn load(
        dir: &tempfile::TempDir,
        need: &[&str],
        compose: Option<&Path>,
    ) -> Result<Requirements> {
        let need: Vec<String> = need.iter().map(|s| s.to_string()).collect();
        crate::requirements::load(dir.path(), "consumer", &need, None, None, compose)
    }

    // Every test that asks Docker Compose what a file means runs where Docker is: Linux CI
    // and any developer machine with it. GitHub's macOS runners have none; `--ignored` runs
    // them on a Mac that does.
    #[test]
    #[cfg_attr(target_os = "macos", ignore = "needs Docker Compose")]
    fn a_compose_file_under_deploy_is_found() {
        let dir = repo(&[
            ("deploy/docker-compose.yml", POSTGRES),
            ("deploy/docker-compose.local.yml", "services: {}\n"),
            ("deploy/docker-compose.standalone.yml", "services: {}\n"),
        ]);
        let req = load(&dir, &["postgres", "node", "pnpm", "bazel"], None).unwrap();
        assert_eq!(req.services.len(), 1);
        assert_eq!(req.services[0].name, "postgres");
        assert_eq!(req.services[0].from, "deploy/docker-compose.yml");
        for tool in ["node", "pnpm", "bazel", "docker"] {
            assert!(req.tools.iter().any(|t| t.id == tool), "missing {tool}");
        }
    }

    #[test]
    #[cfg_attr(target_os = "macos", ignore = "needs Docker Compose")]
    fn a_variable_nobody_set_yet_does_not_hide_which_names_are_services() {
        // sub2api's shape: a required variable, and a database with no host port.
        let dir = repo(&[(
            "deploy/docker-compose.yml",
            "services:\n  postgres:\n    image: postgres:18-alpine\n    environment:\n      - POSTGRES_PASSWORD=${WF_FIXTURE_PASSWORD:?POSTGRES_PASSWORD is required}\n  app:\n    image: alpine\n    ports: ['${WF_FIXTURE_HOST:-0.0.0.0}:${WF_FIXTURE_PORT:-8080}:8080']\n",
        )]);
        let req = load(&dir, &["postgres", "app"], None).unwrap();
        let names: Vec<&str> = req.services.iter().map(|s| s.name.as_str()).collect();
        assert_eq!(names, ["app", "postgres"]);
    }

    #[test]
    #[cfg_attr(target_os = "macos", ignore = "needs Docker Compose")]
    fn the_project_env_file_is_a_source() {
        let dir = repo(&[
            ("deploy/docker-compose.yml", POSTGRES),
            ("deploy/.env", "POSTGRES_PASSWORD=fixture\n"),
        ]);
        let req = load(&dir, &["postgres"], None).unwrap();
        assert!(req.sources.iter().any(|s| s.path.ends_with("deploy/.env")));
    }

    #[test]
    #[cfg_attr(target_os = "macos", ignore = "needs Docker Compose")]
    fn the_root_wins_over_deploy_and_compose_yaml_wins_within_a_directory() {
        let dir = repo(&[
            ("deploy/compose.yaml", POSTGRES),
            ("docker-compose.yml", POSTGRES),
            ("compose.yaml", POSTGRES),
        ]);
        let req = load(&dir, &["postgres"], None).unwrap();
        assert_eq!(req.services[0].from, "compose.yaml");
    }

    #[test]
    fn toolchain_needs_never_consult_compose() {
        let dir = repo(&[("compose.yaml", "services: [this is not a compose file\n")]);
        let req = load(&dir, &["node", "pnpm", "bazel"], None).unwrap();
        assert!(req.services.is_empty());
        for tool in ["node", "pnpm", "bazel"] {
            assert!(req.tools.iter().any(|t| t.id == tool), "missing {tool}");
        }
        let bare = repo(&[]);
        assert!(load(&bare, &["node", "pnpm", "bazel"], None).is_ok());
    }

    #[test]
    fn a_service_with_no_compose_file_anywhere_names_where_it_looked() {
        let dir = repo(&[]);
        let err = load(&dir, &["wf-fixture-orders-db", "node"], None).unwrap_err();
        assert_eq!(err.kind, "READINESS-NEED");
        assert_eq!(err.code, wf_core::ExitCode::Usage);
        for looked in [
            "compose.yaml",
            "docker-compose.yml",
            "deploy/",
            "docker/",
            "--compose",
        ] {
            assert!(err.message.contains(looked), "{looked}: {}", err.message);
        }
        assert!(
            err.message.contains("wf-fixture-orders-db"),
            "{}",
            err.message
        );
        assert!(!err.zh.is_empty());
    }

    #[test]
    fn a_declared_service_with_no_compose_file_names_where_it_looked() {
        let dir = repo(&[(
            "readiness.yaml",
            "version: 1\nservices:\n  need: [postgres]\n",
        )]);
        let err = load(&dir, &[], None).unwrap_err();
        assert_eq!(err.kind, "READINESS-SERVICE");
        assert!(err.message.contains("deploy/"), "{}", err.message);
        assert!(
            err.message.contains("docker-compose.yaml"),
            "{}",
            err.message
        );
    }

    #[test]
    #[cfg_attr(target_os = "macos", ignore = "needs Docker Compose")]
    fn a_named_compose_file_beats_discovery_and_must_exist() {
        let dir = repo(&[
            ("compose.yaml", "services: {}\n"),
            ("deploy/docker-compose.local.yml", POSTGRES),
        ]);
        let named = Path::new("deploy/docker-compose.local.yml");
        let req = load(&dir, &["postgres"], Some(named)).unwrap();
        assert_eq!(req.services[0].from, "deploy/docker-compose.local.yml");
        let err = load(&dir, &["postgres"], Some(Path::new("nowhere.yml"))).unwrap_err();
        assert!(err.message.contains("nowhere.yml"), "{}", err.message);
    }

    #[test]
    #[cfg_attr(target_os = "macos", ignore = "needs Docker Compose")]
    fn a_name_compose_does_not_define_is_a_tool_when_the_session_can_run_it() {
        let dir = repo(&[("deploy/docker-compose.yml", POSTGRES)]);
        let req = load(&dir, &["sh"], None).unwrap();
        assert!(req.services.is_empty());
        assert!(req.tools.iter().any(|t| t.id == "sh" && t.from == "--need"));
    }

    #[test]
    fn a_checkout_cloned_before_the_org_rename_still_finds_its_manifest() {
        let dir = tempfile::tempdir().unwrap();
        let root = dir.path();
        let git = |args: &[&str]| {
            assert!(std::process::Command::new("git")
                .args(args)
                .current_dir(root)
                .output()
                .unwrap()
                .status
                .success());
        };
        git(&["init", "-q"]);
        git(&["remote", "add", "origin", "git@github.com:capsohq/txe.git"]);
        let profile = root.join("profile");
        let want = profile.join("manifests/txehq/txe.yaml");
        std::fs::create_dir_all(want.parent().unwrap()).unwrap();
        std::fs::write(&want, "version: 1\n").unwrap();
        assert_eq!(resolve(root, Some(&profile), None), Some(want));
    }
}
