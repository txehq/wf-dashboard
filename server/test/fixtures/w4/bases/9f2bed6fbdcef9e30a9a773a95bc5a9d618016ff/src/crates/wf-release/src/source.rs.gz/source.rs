//! Where a release comes from.
//!
//! Two sources, one interface. `GitHub` is production: an immutable release, resolved and
//! verified through `gh`. `Local` is a directory laid out exactly like a release's assets —
//! which is what makes it possible to rehearse an install, an upgrade, a rollback and a
//! failed-integrity path without publishing anything, and without a private repository
//! being reachable at all.
//!
//! `Local` is not a weaker path with checks disabled. It runs the same digest verification
//! against the same lock; what it skips is only the part GitHub is the authority for
//! (release immutability and asset attestation), and `wf status` says so out loud, because
//! a machine that installed from a directory should not report itself as verified against a
//! release nobody published.

use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Channel {
    Stable,
    Canary,
}

impl Channel {
    pub fn as_str(self) -> &'static str {
        match self {
            Channel::Stable => "stable",
            Channel::Canary => "canary",
        }
    }
    pub fn parse(s: &str) -> Option<Self> {
        match s {
            "stable" => Some(Channel::Stable),
            "canary" | "rc" | "prerelease" => Some(Channel::Canary),
            _ => None,
        }
    }
}

/// A resolved release: the tag, the version and where its assets can be fetched from.
#[derive(Debug, Clone)]
pub struct ReleaseRef {
    pub tag: String,
    pub version: String,
    pub channel: Channel,
    /// True only for an immutable GitHub release that `gh release verify` accepted.
    pub attested: bool,
    pub source: ReleaseSource,
}

#[derive(Debug, Clone)]
pub enum ReleaseSource {
    GitHub {
        repo: String,
        branch: String,
    },
    /// A directory holding the same asset filenames a release would.
    Local {
        dir: PathBuf,
    },
}

impl ReleaseSource {
    /// A description that `parse` accepts back. The round trip matters: this string is
    /// what a machine records at install time and reads back on every later sync.
    pub fn describe(&self) -> String {
        match self {
            ReleaseSource::GitHub { repo, .. } => format!("github:{repo}"),
            ReleaseSource::Local { dir } => format!("local:{}", dir.display()),
        }
    }

    pub fn is_local(&self) -> bool {
        matches!(self, ReleaseSource::Local { .. })
    }

    /// Parse `--source`. `local:<dir>` or `local` (meaning `./dist`) selects the local
    /// path; anything else is `owner/repo` on GitHub.
    pub fn parse(spec: &str, default_repo: &str, branch: &str) -> wf_core::Result<Self> {
        if spec == "local" {
            return Ok(ReleaseSource::Local {
                dir: PathBuf::from("dist"),
            });
        }
        if let Some(dir) = spec.strip_prefix("local:") {
            return Ok(ReleaseSource::Local {
                dir: PathBuf::from(dir),
            });
        }
        if let Some(repo) = spec.strip_prefix("github:") {
            return Ok(ReleaseSource::GitHub {
                repo: repo.to_string(),
                branch: branch.to_string(),
            });
        }
        if spec.is_empty() {
            return Ok(ReleaseSource::GitHub {
                repo: default_repo.to_string(),
                branch: branch.to_string(),
            });
        }
        if spec.contains('/') && !spec.starts_with('.') && !spec.starts_with('/') {
            return Ok(ReleaseSource::GitHub {
                repo: spec.to_string(),
                branch: branch.to_string(),
            });
        }
        Err(wf_core::Error::usage(
            "SOURCE-SPEC",
            format!("{spec:?}: expected owner/repo, github:owner/repo, or local:<dir>"),
        )
        .with_zh("`--source` 只接受两种写法：`owner/repo`，或者 `local:目录`。".to_string()))
    }
}

/// The asset names a release carries. Rendered from the version so the installer and the
/// builder cannot disagree about a filename.
pub struct Assets;

impl Assets {
    pub fn binary(version: &str, target: &str) -> String {
        format!("wf-v{version}-{target}.tar.gz")
    }
    pub fn bundle(version: &str) -> String {
        format!("workflow-v{version}.tar.gz")
    }
    pub const LOCK: &'static str = "workflow.lock.json";
    pub fn sbom(version: &str) -> String {
        format!("SBOM-v{version}.spdx.json")
    }
    pub fn third_party(version: &str) -> String {
        format!("THIRD_PARTY-LICENSES-v{version}.tar.gz")
    }
    pub fn checksums(version: &str) -> String {
        format!("checksums-v{version}.txt")
    }
}

/// Resolve the local source: read its lock and confirm the assets it names are present.
pub fn resolve_local(dir: &Path) -> wf_core::Result<(ReleaseRef, crate::Lock)> {
    let lock_path = dir.join(Assets::LOCK);
    let text = std::fs::read_to_string(&lock_path).map_err(|e| {
        wf_core::Error::from(e).with_zh(format!(
            "{} 里没有找到 workflow.lock.json。先运行 `wf release build-local --out {}` 生成一份。",
            dir.display(),
            dir.display()
        ))
    })?;
    let lock = crate::Lock::parse(&text)?;
    Ok((
        ReleaseRef {
            tag: format!("v{}", lock.release_version),
            version: lock.release_version.clone(),
            channel: if lock.release_version.contains("-rc.") {
                Channel::Canary
            } else {
                Channel::Stable
            },
            attested: false,
            source: ReleaseSource::Local {
                dir: dir.to_path_buf(),
            },
        },
        lock,
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn source_spec_covers_both_paths() {
        assert!(matches!(
            ReleaseSource::parse("local:./dist", "o/r", "main").unwrap(),
            ReleaseSource::Local { .. }
        ));
        assert!(matches!(
            ReleaseSource::parse("local", "o/r", "main").unwrap(),
            ReleaseSource::Local { .. }
        ));
        match ReleaseSource::parse("acme/fork", "o/r", "release/stable").unwrap() {
            ReleaseSource::GitHub { repo, branch } => {
                assert_eq!(repo, "acme/fork");
                assert_eq!(branch, "release/stable");
            }
            _ => panic!("expected GitHub"),
        }
        match ReleaseSource::parse("", "txehq/txe-workflow", "main").unwrap() {
            ReleaseSource::GitHub { repo, .. } => assert_eq!(repo, "txehq/txe-workflow"),
            _ => panic!("expected the default repo"),
        }
        assert!(ReleaseSource::parse("nonsense", "o/r", "main").is_err());
    }

    #[test]
    fn a_description_parses_back_into_the_same_source() {
        for spec in ["local:/tmp/dist", "github:acme/fork"] {
            let a = ReleaseSource::parse(spec, "o/r", "main").unwrap();
            let b = ReleaseSource::parse(&a.describe(), "o/r", "main").unwrap();
            assert_eq!(a.describe(), b.describe(), "{spec} did not round trip");
        }
    }

    #[test]
    fn asset_names_are_shared_by_builder_and_installer() {
        assert_eq!(
            Assets::binary("1.0.0", "aarch64-apple-darwin"),
            "wf-v1.0.0-aarch64-apple-darwin.tar.gz"
        );
        assert_eq!(Assets::bundle("1.0.0"), "workflow-v1.0.0.tar.gz");
    }
}
