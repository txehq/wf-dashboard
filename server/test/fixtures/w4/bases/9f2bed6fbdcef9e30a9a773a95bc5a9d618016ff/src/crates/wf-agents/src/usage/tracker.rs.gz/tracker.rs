//! The usage tracker: every event into SQLite for queries, a line into `usage.jsonl` for
//! anything that later wants the raw record, and the list of skills ever used in
//! `known-skills.json`.
//!
//! This runs inside a hook on every tool call, so it is written for that: one row insert,
//! one append, and the skills file rewritten only when a skill was used.

use super::analytics::{self, StatsFilter, UsageStats};
use super::{
    is_correction, prompt_summary, PromptEvent, SessionEvent, SkillUsageEvent, ToolUseEvent,
    TrackedEvent,
};
use crate::policy::Policies;
use serde_json::{json, Value};
use std::path::{Path, PathBuf};
use wf_core::Result;
use wf_state::{Db, UsageEventRow, UsageQuery};

/// Past this, `usage.jsonl` rotates to `usage.jsonl.1` so a log can never fill a disk.
pub const USAGE_LOG_MAX_BYTES: u64 = 16 * 1024 * 1024;

pub struct UsageTracker<'a> {
    db: &'a Db,
    dir: PathBuf,
    policies: &'a Policies,
}

impl<'a> UsageTracker<'a> {
    /// `dir` is wf's state directory: the log and the skills file live beside the database.
    pub fn new(db: &'a Db, dir: &Path, policies: &'a Policies) -> Self {
        Self {
            db,
            dir: dir.to_path_buf(),
            policies,
        }
    }

    pub fn usage_log(&self) -> PathBuf {
        self.dir.join("usage.jsonl")
    }

    pub fn known_skills_file(&self) -> PathBuf {
        self.dir.join("known-skills.json")
    }

    pub fn enabled(&self) -> bool {
        self.policies.usage.enabled
    }

    /// Record a skill use, and remember the skill.
    pub fn track_skill(&mut self, event: SkillUsageEvent) -> Result<()> {
        if !self.enabled() {
            return Ok(());
        }
        let mut row = row("skill", &event.session_id, &event.agent, &event.timestamp);
        row.skill_name = Some(event.skill_name.clone());
        row.source = Some(event.source.as_str().to_string());
        self.record(
            row,
            json!({"type": "skill", "timestamp": event.timestamp, "session_id": event.session_id,
                   "agent": event.agent, "skill": event.skill_name, "source": event.source.as_str()}),
        )?;
        self.db
            .touch_known_skill(&event.skill_name, &event.timestamp)?;
        let names: Vec<String> = self
            .db
            .known_skills()?
            .into_iter()
            .map(|k| k.skill_name)
            .collect();
        let mut text = serde_json::to_string_pretty(&names)?;
        text.push('\n');
        wf_core::atomic::write_file(&self.known_skills_file(), text.as_bytes())
    }

    pub fn track_session_start(&mut self, event: SessionEvent) -> Result<()> {
        self.track_session("session_start", event)
    }

    pub fn track_session_end(&mut self, event: SessionEvent) -> Result<()> {
        self.track_session("session_end", event)
    }

    /// The end of one turn, which is also the last word from agents with no session-end hook.
    pub fn track_stop(&mut self, event: SessionEvent) -> Result<()> {
        self.track_session("stop", event)
    }

    fn track_session(&mut self, kind: &str, event: SessionEvent) -> Result<()> {
        if !self.enabled() {
            return Ok(());
        }
        let mut row = row(kind, &event.session_id, &event.agent, &event.timestamp);
        row.metadata = event.metadata;
        self.record(
            row,
            json!({"type": kind, "timestamp": event.timestamp, "session_id": event.session_id, "agent": event.agent}),
        )
    }

    pub fn track_tool_use(&mut self, event: ToolUseEvent) -> Result<()> {
        if !self.enabled() {
            return Ok(());
        }
        let mut row = row("tool", &event.session_id, &event.agent, &event.timestamp);
        row.tool_name = Some(event.tool_name.clone());
        self.record(
            row,
            json!({"type": "tool", "timestamp": event.timestamp, "session_id": event.session_id,
                   "agent": event.agent, "tool": event.tool_name}),
        )
    }

    /// A prompt is kept as a count and a correction flag; only a session's first is kept as
    /// text, redacted and shortened.
    pub fn track_prompt(&mut self, event: PromptEvent) -> Result<()> {
        if !self.enabled() {
            return Ok(());
        }
        let first = self
            .db
            .usage_events(&UsageQuery {
                session_id: Some(event.session_id.clone()),
                event_type: Some("prompt".into()),
                ..Default::default()
            })?
            .is_empty();
        let mut metadata = serde_json::Map::new();
        if first {
            metadata.insert("summary".into(), prompt_summary(&event.text).into());
        }
        metadata.insert(
            "correction".into(),
            (!first && is_correction(&event.text)).into(),
        );
        let mut row = row("prompt", &event.session_id, &event.agent, &event.timestamp);
        row.metadata = Value::Object(metadata);
        self.record(
            row,
            json!({"type": "prompt", "timestamp": event.timestamp, "session_id": event.session_id, "agent": event.agent}),
        )
    }

    /// Record every event from one hook invocation.
    pub fn track(&mut self, events: &[TrackedEvent]) -> Result<()> {
        for event in events.iter().cloned() {
            match event {
                TrackedEvent::SessionStart(e) => self.track_session_start(e)?,
                TrackedEvent::SessionEnd(e) => self.track_session_end(e)?,
                TrackedEvent::Stop(e) => self.track_stop(e)?,
                TrackedEvent::Prompt(e) => self.track_prompt(e)?,
                TrackedEvent::ToolUse(e) => self.track_tool_use(e)?,
                TrackedEvent::Skill(e) => self.track_skill(e)?,
            }
        }
        Ok(())
    }

    pub fn get_stats(&self, filter: &StatsFilter) -> Result<UsageStats> {
        analytics::compute(self.db, filter)
    }

    /// Drop events older than the retention window, from the database and the log, at most
    /// once a day. Returns how many database rows went.
    pub fn prune(&mut self, now_ms: i64) -> Result<usize> {
        let today = wf_core::time_fmt::utc_millis(now_ms)[..10].to_string();
        if self.db.meta("usage_pruned_on")?.as_deref() == Some(today.as_str()) {
            return Ok(0);
        }
        let retention_ms = i64::from(self.policies.usage.retention_days) * 86_400_000;
        let cutoff = wf_core::time_fmt::utc_millis(now_ms - retention_ms);
        let removed = self.db.prune_usage_events(&cutoff)?;
        let log = self.usage_log();
        let _lock = self.log_lock()?;
        if let Ok(text) = std::fs::read_to_string(&log) {
            let kept: String = text
                .lines()
                .filter(|line| {
                    serde_json::from_str::<Value>(line)
                        .ok()
                        .and_then(|v| v["timestamp"].as_str().map(|t| t >= cutoff.as_str()))
                        .unwrap_or(false)
                })
                .map(|line| format!("{line}\n"))
                .collect();
            if kept != text {
                wf_core::atomic::write_file(&log, kept.as_bytes())?;
            }
        }
        self.db.set_meta("usage_pruned_on", &today)?;
        Ok(removed)
    }

    fn record(&mut self, row: UsageEventRow, line: Value) -> Result<()> {
        self.db.insert_usage_event(&row)?;
        self.append_log(&line)
    }

    /// Held around every change to `usage.jsonl`: an append that lands between the daily
    /// trim's read and its rewrite would otherwise vanish in the rewrite.
    fn log_lock(&self) -> Result<wf_core::lock::Guard> {
        std::fs::create_dir_all(&self.dir)?;
        wf_core::lock::Guard::exclusive_within(&self.dir.join("usage.lock"), 2_000)
    }

    fn append_log(&self, line: &Value) -> Result<()> {
        use std::io::Write;
        let log = self.usage_log();
        let _lock = self.log_lock()?;
        if std::fs::metadata(&log).is_ok_and(|m| m.len() > USAGE_LOG_MAX_BYTES) {
            std::fs::rename(&log, log.with_extension("jsonl.1"))?;
        }
        let mut file = std::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(&log)?;
        // One write per line: short appends to a local file do not interleave.
        file.write_all(format!("{line}\n").as_bytes())?;
        Ok(())
    }
}

fn row(kind: &str, session: &str, agent: &str, timestamp: &str) -> UsageEventRow {
    UsageEventRow {
        id: 0,
        timestamp: timestamp.to_string(),
        session_id: session.to_string(),
        agent: agent.to_string(),
        event_type: kind.to_string(),
        skill_name: None,
        tool_name: None,
        source: None,
        metadata: Value::Null,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::usage::SkillSource;

    struct Fixture {
        dir: tempfile::TempDir,
        db: Db,
        policies: Policies,
    }

    impl Fixture {
        fn new() -> Self {
            Self {
                dir: tempfile::tempdir().unwrap(),
                db: Db::open_memory().unwrap(),
                policies: Policies::default(),
            }
        }
        fn tracker(&self) -> UsageTracker<'_> {
            UsageTracker::new(&self.db, self.dir.path(), &self.policies)
        }
    }

    fn skill(at: &str, session: &str, name: &str) -> SkillUsageEvent {
        SkillUsageEvent {
            timestamp: at.into(),
            session_id: session.into(),
            agent: "claude-code".into(),
            skill_name: name.into(),
            source: SkillSource::Shared,
        }
    }

    fn prompt(at: &str, session: &str, text: &str) -> PromptEvent {
        PromptEvent {
            session_id: session.into(),
            agent: "claude-code".into(),
            timestamp: at.into(),
            text: text.into(),
        }
    }

    #[test]
    fn a_skill_use_lands_in_the_database_the_log_and_the_known_skills_file() {
        let f = Fixture::new();
        let mut t = f.tracker();
        t.track_skill(skill("2026-09-16T10:00:00.000Z", "s1", "lfg"))
            .unwrap();
        t.track_skill(skill("2026-09-16T10:05:00.000Z", "s1", "ic"))
            .unwrap();
        t.track_skill(skill("2026-09-16T10:06:00.000Z", "s2", "lfg"))
            .unwrap();

        let rows = f.db.usage_events(&UsageQuery::default()).unwrap();
        assert_eq!(rows.len(), 3);
        assert_eq!(rows[0].event_type, "skill");
        assert_eq!(rows[0].source.as_deref(), Some("shared"));
        let known = f.db.known_skills().unwrap();
        assert_eq!(
            known
                .iter()
                .find(|k| k.skill_name == "lfg")
                .unwrap()
                .use_count,
            2
        );

        let log = std::fs::read_to_string(t.usage_log()).unwrap();
        let lines: Vec<serde_json::Value> = log
            .lines()
            .map(|l| serde_json::from_str(l).unwrap())
            .collect();
        assert_eq!(lines.len(), 3);
        assert_eq!(
            lines[0],
            json!({"type": "skill", "timestamp": "2026-09-16T10:00:00.000Z", "session_id": "s1", "agent": "claude-code", "skill": "lfg", "source": "shared"})
        );

        let names: Vec<String> =
            serde_json::from_str(&std::fs::read_to_string(t.known_skills_file()).unwrap()).unwrap();
        assert_eq!(names, ["ic", "lfg"], "sorted, unique");
    }

    #[test]
    fn prompts_keep_a_count_a_correction_flag_and_only_the_first_as_redacted_text() {
        let f = Fixture::new();
        let mut t = f.tracker();
        t.track_prompt(prompt(
            "2026-09-16T10:00:00.000Z",
            "s1",
            "fix the build, token ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        ))
        .unwrap();
        t.track_prompt(prompt(
            "2026-09-16T10:01:00.000Z",
            "s1",
            "no, that's not what I asked",
        ))
        .unwrap();
        let rows =
            f.db.usage_events(&UsageQuery {
                event_type: Some("prompt".into()),
                ..Default::default()
            })
            .unwrap();
        assert_eq!(rows.len(), 2);
        let first = rows[0].metadata["summary"].as_str().unwrap();
        assert!(first.starts_with("fix the build"), "{first}");
        assert!(!first.contains("ghp_ABCD"), "{first}");
        assert!(
            rows[1].metadata.get("summary").is_none(),
            "only the first prompt keeps text"
        );
        assert_eq!(rows[1].metadata["correction"], true);
        assert_eq!(rows[0].metadata["correction"], false);
        let log = std::fs::read_to_string(t.usage_log()).unwrap();
        assert!(
            !log.contains("fix the build"),
            "the log never carries prompt text: {log}"
        );
    }

    #[test]
    fn a_disabled_policy_records_nothing() {
        let mut f = Fixture::new();
        f.policies.usage.enabled = false;
        let mut t = f.tracker();
        t.track(&[
            TrackedEvent::Skill(skill("2026-09-16T10:00:00.000Z", "s1", "lfg")),
            TrackedEvent::ToolUse(ToolUseEvent {
                session_id: "s1".into(),
                agent: "codex".into(),
                tool_name: "Bash".into(),
                timestamp: "2026-09-16T10:00:00.000Z".into(),
            }),
        ])
        .unwrap();
        assert!(f
            .db
            .usage_events(&UsageQuery::default())
            .unwrap()
            .is_empty());
        assert!(!t.usage_log().exists());
    }

    #[test]
    fn every_kind_of_event_is_recorded_by_track() {
        let f = Fixture::new();
        let mut t = f.tracker();
        let session = |kind: &str| SessionEvent {
            session_id: "s1".into(),
            agent: "codex".into(),
            timestamp: format!("2026-09-16T10:00:0{}.000Z", kind.len() % 10),
            metadata: json!({"cwd": "/w"}),
        };
        t.track(&[
            TrackedEvent::SessionStart(session("a")),
            TrackedEvent::Prompt(prompt("2026-09-16T10:00:02.000Z", "s1", "hello")),
            TrackedEvent::ToolUse(ToolUseEvent {
                session_id: "s1".into(),
                agent: "codex".into(),
                tool_name: "Bash".into(),
                timestamp: "2026-09-16T10:00:03.000Z".into(),
            }),
            TrackedEvent::Skill(skill("2026-09-16T10:00:04.000Z", "s1", "lfg")),
            TrackedEvent::Stop(session("stop")),
            TrackedEvent::SessionEnd(session("session_end")),
        ])
        .unwrap();
        let kinds: Vec<String> =
            f.db.usage_events(&UsageQuery::default())
                .unwrap()
                .into_iter()
                .map(|e| e.event_type)
                .collect();
        let mut sorted = kinds.clone();
        sorted.sort();
        assert_eq!(
            sorted,
            [
                "prompt",
                "session_end",
                "session_start",
                "skill",
                "stop",
                "tool"
            ]
        );
    }

    #[test]
    fn pruning_honours_the_retention_window_in_the_database_and_the_log() {
        let f = Fixture::new();
        let mut t = f.tracker();
        let day = 86_400_000i64;
        let now = wf_core::time_fmt::parse_rfc3339_millis("2026-09-16T00:00:00Z").unwrap();
        for age_days in [120, 91, 10, 0] {
            t.track_tool_use(ToolUseEvent {
                session_id: "s".into(),
                agent: "codex".into(),
                tool_name: "Bash".into(),
                timestamp: wf_core::time_fmt::utc_millis(now - age_days * day),
            })
            .unwrap();
        }
        assert_eq!(t.prune(now).unwrap(), 2);
        assert_eq!(f.db.usage_events(&UsageQuery::default()).unwrap().len(), 2);
        assert_eq!(
            std::fs::read_to_string(t.usage_log())
                .unwrap()
                .lines()
                .count(),
            2
        );
        assert_eq!(
            t.prune(now).unwrap(),
            0,
            "a second prune in the same day does nothing"
        );
    }

    /// Hooks from parallel sessions append while the daily trim rewrites the log. No line an
    /// append wrote may vanish in the rewrite.
    #[test]
    fn appends_during_the_daily_trim_are_never_lost() {
        let dir = tempfile::tempdir().unwrap();
        let db_path = dir.path().join("state.sqlite3");
        Db::open(&db_path).unwrap();
        let policies = Policies::default();
        let now = wf_core::time_fmt::now_unix_millis();
        let stop = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        let pruner = {
            let (dir, db_path, policies, stop) = (
                dir.path().to_path_buf(),
                db_path.clone(),
                policies.clone(),
                stop.clone(),
            );
            std::thread::spawn(move || {
                let db = Db::open(&db_path).unwrap();
                let mut t = UsageTracker::new(&db, &dir, &policies);
                while !stop.load(std::sync::atomic::Ordering::Relaxed) {
                    // Something past retention every time, so every trim rewrites the file.
                    t.track_tool_use(ToolUseEvent {
                        session_id: "expired".into(),
                        agent: "codex".into(),
                        tool_name: "Bash".into(),
                        timestamp: wf_core::time_fmt::utc_millis(now - 400 * 86_400_000),
                    })
                    .unwrap();
                    db.set_meta("usage_pruned_on", "").unwrap();
                    t.prune(now).unwrap();
                }
            })
        };
        let writers: Vec<_> = (0..4)
            .map(|w| {
                let (dir, db_path, policies) =
                    (dir.path().to_path_buf(), db_path.clone(), policies.clone());
                std::thread::spawn(move || {
                    let db = Db::open(&db_path).unwrap();
                    let mut t = UsageTracker::new(&db, &dir, &policies);
                    for n in 0..40 {
                        t.track_tool_use(ToolUseEvent {
                            session_id: format!("w{w}-{n}"),
                            agent: "codex".into(),
                            tool_name: "Bash".into(),
                            timestamp: wf_core::time_fmt::utc_millis(now),
                        })
                        .unwrap();
                    }
                })
            })
            .collect();
        for w in writers {
            w.join().unwrap();
        }
        stop.store(true, std::sync::atomic::Ordering::Relaxed);
        pruner.join().unwrap();
        let log = std::fs::read_to_string(dir.path().join("usage.jsonl")).unwrap();
        assert_eq!(log.lines().filter(|l| l.contains("\"w")).count(), 160);
    }

    #[test]
    fn the_log_rotates_rather_than_growing_without_bound() {
        let f = Fixture::new();
        let mut t = f.tracker();
        std::fs::write(t.usage_log(), vec![b'x'; USAGE_LOG_MAX_BYTES as usize + 1]).unwrap();
        t.track_tool_use(ToolUseEvent {
            session_id: "s".into(),
            agent: "codex".into(),
            tool_name: "Bash".into(),
            timestamp: "2026-09-16T10:00:00.000Z".into(),
        })
        .unwrap();
        assert!(t.usage_log().with_extension("jsonl.1").exists());
        assert_eq!(
            std::fs::read_to_string(t.usage_log())
                .unwrap()
                .lines()
                .count(),
            1
        );
    }

    /// The plan's budget: one usage event in well under ten milliseconds. Each call is a
    /// durable SQLite write, so it waits on the disk — see [`crate::budgets`].
    #[test]
    #[ignore = "waits on the disk; the budgets job runs it alone"]
    fn recording_an_event_stays_inside_its_budget() {
        let dir = tempfile::tempdir().unwrap();
        let db = Db::open(&dir.path().join("state.sqlite3")).unwrap();
        let policies = Policies::default();
        let mut t = UsageTracker::new(&db, dir.path(), &policies);
        let mut samples = Vec::new();
        for i in 0..40 {
            let started = std::time::Instant::now();
            t.track_tool_use(ToolUseEvent {
                session_id: "s".into(),
                agent: "codex".into(),
                tool_name: format!("T{i}"),
                timestamp: wf_core::time_fmt::now_utc_millis(),
            })
            .unwrap();
            samples.push(started.elapsed().as_micros());
        }
        samples.sort_unstable();
        let median = samples[samples.len() / 2];
        assert!(
            median < 10_000,
            "median usage write {median}µs is over the 10ms budget"
        );
    }
}
