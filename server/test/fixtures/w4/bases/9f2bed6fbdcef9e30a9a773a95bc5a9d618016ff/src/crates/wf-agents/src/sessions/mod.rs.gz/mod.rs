//! Sessions: what one conversation with an agent amounted to, summarised from its usage
//! events and, when it was worth keeping, written to a monthly log on this machine.

pub mod collector;
pub mod storage;

pub use collector::{SessionCollector, SessionSummary};
pub use storage::SessionStorage;
