use std::path::Path;
use std::process::Command;

#[test]
fn release_jobs_build_and_promote_the_commit_verified_by_the_gate() {
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
    let workflow: serde_yaml_ng::Value = serde_yaml_ng::from_str(
        &std::fs::read_to_string(root.join(".github/workflows/release.yml")).unwrap(),
    )
    .unwrap();
    let jobs = workflow["jobs"].as_mapping().unwrap();
    let gate = &workflow["jobs"]["gate"];
    assert!(
        gate["outputs"]["sha"].as_str().is_some(),
        "gate must publish its verified commit"
    );
    for (name, job) in jobs {
        let name = name.as_str().unwrap();
        for step in job["steps"].as_sequence().unwrap() {
            if step["uses"]
                .as_str()
                .is_some_and(|s| s.starts_with("actions/checkout@"))
            {
                let source = step["with"]["ref"]
                    .as_str()
                    .expect("release checkout must select an explicit source");
                if name == "gate" {
                    assert!(
                        source.contains("inputs.tag"),
                        "manual input must select the tag being validated"
                    );
                } else {
                    assert_eq!(
                        source, "${{ needs.gate.outputs.sha }}",
                        "{name} must consume the already verified commit"
                    );
                }
            }
        }
    }
}

#[test]
fn publication_verifies_both_platform_archives() {
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
    let dir = tempfile::tempdir().unwrap();
    let exe = env!("CARGO_BIN_EXE_wf");
    let mut inputs = Vec::new();
    for target in wf_core::paths::SUPPORTED_TARGETS {
        let input = dir.path().join(format!("input-{target}"));
        std::fs::write(&input, format!("test binary for {target}")).unwrap();
        let archive = dir
            .path()
            .join(wf_release::source::Assets::binary(wf_core::VERSION, target));
        assert!(Command::new(exe)
            .args(["release", "pack-binary", "--binary"])
            .arg(input)
            .arg("--out")
            .arg(&archive)
            .status()
            .unwrap()
            .success());
        inputs.push(format!("{target}={}", archive.display()));
    }
    let mut build = Command::new(exe);
    build
        .args(["release", "build-local", "--root"])
        .arg(root)
        .arg("--out")
        .arg(dir.path());
    for input in inputs {
        build.arg("--binary").arg(input);
    }
    assert!(build.status().unwrap().success());
    let verify = || {
        Command::new(exe)
            .args(["release", "verify", "--require-binaries", "--dir"])
            .arg(dir.path())
            .output()
            .unwrap()
    };
    assert!(verify().status.success());
    let lock = wf_release::Lock::parse(
        &std::fs::read_to_string(dir.path().join("workflow.lock.json")).unwrap(),
    )
    .unwrap();
    assert_eq!(lock.binaries.len(), wf_core::paths::SUPPORTED_TARGETS.len());
    std::fs::remove_file(dir.path().join(&lock.binaries[0].asset)).unwrap();
    assert_eq!(verify().status.code(), Some(4));
}
