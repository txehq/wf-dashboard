use serde::Deserialize;
use std::collections::BTreeMap;
use std::path::Path;
use wf_core::Result;

/// `docs/index.yaml` — the document and skill registry.
#[derive(Debug, Deserialize)]
pub struct Registry {
    #[serde(default)]
    pub version: u32,
    #[serde(default)]
    pub policy: Policy,
    #[serde(default)]
    pub docs: Vec<Doc>,
    #[serde(default)]
    pub skills: Vec<Skill>,
}

#[derive(Debug, Default, Deserialize)]
pub struct Policy {
    #[serde(default)]
    pub stamp_max_age_days: i64,
    #[serde(default)]
    pub claim_max_age_days: i64,
    #[serde(default)]
    pub spec_root: String,
    #[serde(default)]
    pub shell: ShellPolicy,
}

/// WFR-010's machine half: which shell scripts may exist, and how big a bootstrap is
/// allowed to get before it stops being one.
#[derive(Debug, Default, Deserialize)]
pub struct ShellPolicy {
    #[serde(default)]
    pub allow: Vec<String>,
    #[serde(default)]
    pub max_lines: i64,
}

#[derive(Debug, Default, Deserialize)]
pub struct Doc {
    pub path: String,
    #[serde(default)]
    pub purpose: String,
    #[serde(default)]
    pub audience: String,
    #[serde(default)]
    pub read_when: String,
    #[serde(default)]
    pub surface: String,
    #[serde(default)]
    pub generator: String,
    #[serde(default)]
    pub stamp: String,
}

#[derive(Debug, Default, Deserialize)]
pub struct Skill {
    #[serde(default)]
    pub node: String,
    #[serde(default)]
    pub name: String,
    #[serde(default)]
    pub invocation: String,
    #[serde(default)]
    pub status: String,
    #[serde(default)]
    pub spec: String,
    #[serde(default)]
    pub note: String,
}

impl Registry {
    pub fn load(root: &Path) -> Result<Self> {
        let p = root.join(crate::REGISTRY_PATH);
        let text = std::fs::read_to_string(&p).map_err(|e| {
            // An unreadable registry fails closed: we cannot conclude "clean" from a tree
            // we could not read.
            wf_core::Error::usage("GUARD-REGISTRY", format!("{}: {e}", p.display()))
        })?;
        serde_yaml_ng::from_str(&text)
            .map_err(|e| wf_core::Error::usage("GUARD-REGISTRY", format!("{}: {e}", p.display())))
    }
}

/// The YAML frontmatter of a markdown file, plus whether a block was present at all.
///
/// A malformed block is an error, never a silent empty map — that would make every
/// frontmatter check vacuously pass.
pub fn front_matter(path: &Path) -> Result<Option<BTreeMap<String, String>>> {
    let bytes = std::fs::read_to_string(path)?;
    let text = bytes.replace("\r\n", "\n");
    if !text.starts_with("---\n") {
        return Ok(None);
    }
    let Some(end) = text[4..].find("\n---") else {
        return Err(wf_core::Error::usage(
            "GUARD-FRONTMATTER",
            format!("{}: frontmatter opened but never closed", path.display()),
        ));
    };
    let block = &text[4..4 + end];
    let raw: serde_yaml_ng::Value = serde_yaml_ng::from_str(block).map_err(|e| {
        wf_core::Error::usage(
            "GUARD-FRONTMATTER",
            format!("{}: frontmatter is not valid YAML: {e}", path.display()),
        )
    })?;
    let mut out = BTreeMap::new();
    if let serde_yaml_ng::Value::Mapping(m) = raw {
        for (k, v) in m {
            let Some(key) = k.as_str() else { continue };
            let value = match &v {
                serde_yaml_ng::Value::String(s) => s.clone(),
                serde_yaml_ng::Value::Number(n) => n.to_string(),
                serde_yaml_ng::Value::Bool(b) => b.to_string(),
                // An unquoted YYYY-MM-DD parses as a plain scalar here; keep the text.
                other => serde_yaml_ng::to_string(other)
                    .unwrap_or_default()
                    .trim()
                    .to_string(),
            };
            out.insert(key.to_string(), value.trim().to_string());
        }
    }
    Ok(Some(out))
}

pub fn parse_date(s: &str) -> Option<time::Date> {
    let s = s.trim();
    let fmt = time::macros::format_description!("[year]-[month]-[day]");
    time::Date::parse(s, fmt).ok()
}

/// GitHub's heading-anchor derivation, closely enough for our headings: lowercase, drop
/// everything that is not a letter, digit, space, hyphen or underscore (this drops
/// non-ASCII punctuation such as the em dash), then spaces become hyphens.
pub fn slug(h: &str) -> String {
    let h = h.trim().to_lowercase();
    let kept: String = h
        .chars()
        .filter(|c| {
            c.is_ascii_lowercase() || c.is_ascii_digit() || *c == ' ' || *c == '-' || *c == '_'
        })
        .collect();
    kept.trim().replace(' ', "-")
}

/// The GitHub-style heading slugs of a markdown file.
pub fn anchors(path: &Path) -> Result<std::collections::BTreeSet<String>> {
    let text = std::fs::read_to_string(path)?;
    let re = regex::Regex::new(r"(?m)^#{1,6}\s+(.*)$").unwrap();
    Ok(re.captures_iter(&text).map(|c| slug(&c[1])).collect())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn slugs_match_github_for_our_headings() {
        assert_eq!(
            slug("Distribution is the plugin"),
            "distribution-is-the-plugin"
        );
        assert_eq!(
            slug("Shell is for bootstrap — and nothing else"),
            "shell-is-for-bootstrap--and-nothing-else"
        );
        assert_eq!(
            slug("Clean slate — skill text is authored from its node"),
            "clean-slate--skill-text-is-authored-from-its-node"
        );
    }

    #[test]
    fn an_unclosed_frontmatter_is_an_error_not_an_empty_map() {
        let d = tempfile::tempdir().unwrap();
        let p = d.path().join("x.md");
        std::fs::write(&p, "---\nname: x\nno closing marker\n").unwrap();
        assert!(front_matter(&p).is_err());
    }

    #[test]
    fn a_date_in_frontmatter_stays_a_date_string() {
        let d = tempfile::tempdir().unwrap();
        let p = d.path().join("x.md");
        std::fs::write(&p, "---\nlast-verified: 2026-09-04\n---\n# body\n").unwrap();
        let fm = front_matter(&p).unwrap().unwrap();
        assert_eq!(fm["last-verified"], "2026-09-04");
        assert!(parse_date(&fm["last-verified"]).is_some());
    }

    #[test]
    fn a_file_with_no_frontmatter_reports_absence_rather_than_failing() {
        let d = tempfile::tempdir().unwrap();
        let p = d.path().join("x.md");
        std::fs::write(&p, "# just a heading\n").unwrap();
        assert!(front_matter(&p).unwrap().is_none());
    }
}
