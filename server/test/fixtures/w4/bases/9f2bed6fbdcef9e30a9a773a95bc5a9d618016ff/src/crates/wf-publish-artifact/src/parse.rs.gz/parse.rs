use std::path::Path;
use wf_core::{Error, Result};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Kind {
    Page,
    Img,
}

impl Kind {
    pub fn as_str(self) -> &'static str {
        match self {
            Kind::Page => "page",
            Kind::Img => "img",
        }
    }
    pub fn parse(s: &str) -> Option<Self> {
        match s {
            "page" => Some(Kind::Page),
            "img" => Some(Kind::Img),
            _ => None,
        }
    }
}

#[derive(Debug, Clone, Copy)]
pub struct ContentType {
    pub mime: &'static str,
    pub kind: Kind,
}

const BY_EXTENSION: &[(&str, ContentType)] = &[
    (
        "html",
        ContentType {
            mime: "text/html; charset=utf-8",
            kind: Kind::Page,
        },
    ),
    (
        "htm",
        ContentType {
            mime: "text/html; charset=utf-8",
            kind: Kind::Page,
        },
    ),
    (
        "pdf",
        ContentType {
            mime: "application/pdf",
            kind: Kind::Page,
        },
    ),
    (
        "png",
        ContentType {
            mime: "image/png",
            kind: Kind::Img,
        },
    ),
    (
        "jpg",
        ContentType {
            mime: "image/jpeg",
            kind: Kind::Img,
        },
    ),
    (
        "jpeg",
        ContentType {
            mime: "image/jpeg",
            kind: Kind::Img,
        },
    ),
    (
        "gif",
        ContentType {
            mime: "image/gif",
            kind: Kind::Img,
        },
    ),
    (
        "webp",
        ContentType {
            mime: "image/webp",
            kind: Kind::Img,
        },
    ),
    (
        "svg",
        ContentType {
            mime: "image/svg+xml",
            kind: Kind::Img,
        },
    ),
];

pub fn content_type_for(path: &Path) -> Result<ContentType> {
    let ext = path
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        .to_lowercase();
    BY_EXTENSION
        .iter()
        .find(|(e, _)| *e == ext)
        .map(|(_, ct)| *ct)
        .ok_or_else(|| {
            Error::usage(
                "PUBLISH-EXTENSION",
                format!("unsupported extension {ext:?} — html, htm, pdf, png, jpg, jpeg, gif, webp or svg"),
            )
            .with_zh("这种文件类型不支持。可以发布的是 html、htm、pdf、png、jpg、jpeg、gif、webp 和 svg。".to_string())
        })
}

const ID_ALPHABET: &[u8] = b"0123456789abcdefghijklmnopqrstuvwxyz";

/// The artifact id format. The generated path and the `--id` path are held to the same rule;
/// in the shell version only `--id` was checked, so a short generated id would have been
/// uploaded without complaint.
pub fn valid_id(s: &str) -> bool {
    s.len() == 8
        && s.bytes()
            .all(|b| b.is_ascii_lowercase() || b.is_ascii_digit())
}

/// Draw 8 characters from a uniform source.
///
/// Built by construction rather than by trimming a filtered stream, which removes the
/// "what if fewer than 8 characters survived the filter" question the shell pipeline could
/// not answer about itself.
pub fn new_id() -> String {
    let mut out = String::with_capacity(8);
    for _ in 0..8 {
        out.push(ID_ALPHABET[uniform(ID_ALPHABET.len())] as char);
    }
    debug_assert!(valid_id(&out));
    out
}

/// A uniform index below `n`, from the OS. Rejection sampling, so the modulo bias that
/// would make some ids likelier than others does not exist.
fn uniform(n: usize) -> usize {
    let limit = (u32::MAX / n as u32) * n as u32;
    loop {
        let mut b = [0u8; 4];
        getrandom(&mut b);
        let v = u32::from_le_bytes(b);
        if v < limit {
            return (v % n as u32) as usize;
        }
    }
}

fn getrandom(buf: &mut [u8]) {
    use std::io::Read;
    // /dev/urandom is the OS CSPRNG on both supported platforms. A failure here is not
    // something to paper over with a timestamp — an id that is guessable is an id somebody
    // else's page can be overwritten at.
    let mut f = std::fs::File::open("/dev/urandom").expect("/dev/urandom");
    f.read_exact(buf).expect("reading /dev/urandom");
}

/// Extract a Linear-style id from a branch name.
///
/// The leading boundary is the whole point. `t` is a real project key, so it cannot simply
/// be dropped; without a boundary it matches inside ordinary words, and the branch
/// `feat-99-x` yielded the ticket `t-99` out of the "t" in "feat" — which was then stored in
/// real artifact metadata.
pub fn ticket_from(branch: &str) -> String {
    let re = regex::Regex::new(r"(?i)(?:^|[^a-z0-9])(txe|cap|t)-?(\d{1,6})(?:[^0-9]|$)").unwrap();
    let Some(c) = re.captures(branch) else {
        return String::new();
    };
    format!("{}-{}", c[1].to_lowercase(), &c[2])
}

/// Reduce a git remote to `owner/repo`.
///
/// Keeping only the last two path segments drops any credential in an HTTPS remote as a
/// side effect — including one containing a slash, which a naive `//user:pass@` strip does
/// not handle.
pub fn repo_from(remote: &str) -> String {
    let remote = remote.trim();
    if remote.is_empty() {
        return String::new();
    }
    let re = regex::Regex::new(r"([^/:]+/[^/]+?)(?:\.git)?/?$").unwrap();
    re.captures(remote)
        .map(|c| c[1].to_string())
        .unwrap_or_default()
}

/// The `cc<n>` derivation from `CLAUDE_CONFIG_DIR`. Digit-anchored and tolerant of a
/// trailing slash: a path that is not a numbered config dir yields plain `cc`, which means
/// "no instance identity" rather than an error.
pub fn instance_from(config_dir: &str) -> String {
    let re = regex::Regex::new(r"/\.claude([0-9]*)/?$").unwrap();
    match re.captures(config_dir) {
        Some(c) => format!("cc{}", &c[1]),
        None => "cc".to_string(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_ticket_is_not_invented_out_of_the_word_feat() {
        // The measured defect this boundary exists for.
        assert_eq!(ticket_from("feat-99-spot-bidding"), "");
        assert_eq!(ticket_from("txe-1664-version-gate"), "txe-1664");
        assert_eq!(ticket_from("TXE1664"), "txe-1664");
        assert_eq!(ticket_from("user/t-42-fix"), "t-42");
        assert_eq!(ticket_from("main"), "");
        assert_eq!(
            ticket_from("repeat-12"),
            "",
            "the t in 'repeat' is not a project key"
        );
    }

    #[test]
    fn a_remote_reduces_to_owner_repo_and_drops_credentials() {
        assert_eq!(
            repo_from("git@github.com:txehq/txe-workflow.git"),
            "txehq/txe-workflow"
        );
        assert_eq!(
            repo_from("https://github.com/txehq/txe-workflow"),
            "txehq/txe-workflow"
        );
        assert_eq!(
            repo_from("https://user:pa/ss@github.com/txehq/txe-workflow.git"),
            "txehq/txe-workflow"
        );
        assert_eq!(repo_from(""), "");
    }

    #[test]
    fn an_instance_label_degrades_to_cc_rather_than_erroring() {
        assert_eq!(instance_from("/Users/x/.claude"), "cc");
        assert_eq!(instance_from("/Users/x/.claude2/"), "cc2");
        assert_eq!(instance_from("/some/other/path"), "cc");
        assert_eq!(instance_from(""), "cc");
    }

    #[test]
    fn every_generated_id_passes_the_same_check_as_a_supplied_one() {
        for _ in 0..500 {
            let id = new_id();
            assert!(valid_id(&id), "{id}");
        }
        assert!(!valid_id("SHORT"));
        assert!(!valid_id("abcdefgh1"));
        assert!(!valid_id("ABCDEFGH"));
        assert!(valid_id("abcd1234"));
    }

    #[test]
    fn generated_ids_are_not_all_the_same() {
        let a: std::collections::HashSet<String> = (0..50).map(|_| new_id()).collect();
        assert!(a.len() > 45, "ids repeated far too often: {}", a.len());
    }

    #[test]
    fn extensions_map_to_a_kind_and_an_unknown_one_is_refused() {
        assert_eq!(
            content_type_for(Path::new("a.HTML")).unwrap().kind,
            Kind::Page
        );
        assert_eq!(
            content_type_for(Path::new("a.png")).unwrap().kind,
            Kind::Img
        );
        assert!(content_type_for(Path::new("a.exe")).is_err());
        assert!(content_type_for(Path::new("noext")).is_err());
    }
}
