//! The design's performance budgets, measured where the work happens, against a database on
//! disk.
//!
//! Two of them are bounded by the disk rather than the code: a usage row is a durable database
//! write, and a skill is a durable file. The budgets are what a developer's machine gives; a
//! disk where one durable write costs more — a CI container's overlay filesystem, measured at
//! 12 ms for a usage hook and 7.2 s for a thousand skills — gets a budget in durable writes
//! measured on that same disk. That calibration is the knob; it still fails a change that makes
//! the work bigger in writes, or a cost per skill that grows with the number of skills.
//!
//! Every test here that waits on the disk is `#[ignore]`, and the `budgets` CI job runs them
//! on their own. Calibrating inside the noise does not remove it: sharing a runner with two
//! hundred other tests, all of them fsyncing, measures the machine rather than the diff, and
//! the calibration and the measurement it divides land in different parts of that run.

use crate::adapter::{Desired, TeamAIAdapter};
use crate::formats::HookEvent;
use crate::policy::Policies;
use crate::testing::{Machine, TeamFixture, REGISTRY};
use std::time::{Duration, Instant};

fn on_disk() -> Machine {
    let mut m = Machine::new();
    m.db = wf_state::Db::open(&m.dir.path().join("state.sqlite3")).unwrap();
    m
}

fn p95(mut samples: Vec<Duration>) -> Duration {
    samples.sort_unstable();
    samples[samples.len() * 95 / 100 - 1]
}

/// Detection runs for every agent on every apply and status: a directory check and a `PATH`
/// lookup, never a process.
#[test]
fn detecting_an_agent_takes_under_fifty_milliseconds() {
    let team = TeamFixture::new();
    let m = Machine::new();
    for spec in team.agents().agents() {
        let adapter = m.adapter(&team, &spec.id, Policies::default());
        let samples = (0..20)
            .map(|_| {
                let started = Instant::now();
                adapter.detect().unwrap();
                started.elapsed()
            })
            .collect();
        let took = p95(samples);
        assert!(took < Duration::from_millis(50), "{}: {took:?}", spec.id);
    }
}

/// A usage hook runs on every tool call: ten milliseconds, or six durable database writes on a
/// disk where one costs more than that allows. A hook is one such write and a line appended.
#[test]
#[ignore = "waits on the disk; the budgets job runs it alone"]
fn recording_a_hook_takes_under_ten_milliseconds() {
    let m = on_disk();
    let policies = Policies::default();
    let payload = serde_json::json!({"session_id": "s1", "tool_name": "Edit", "tool_input": {"file_path": "/w/a.rs"}});
    let samples = (0..60)
        .map(|_| {
            let ctx = crate::usage::HookContext {
                agent: "claude-code",
                event: HookEvent::PostToolUse,
                now: wf_core::time_fmt::now_utc_millis(),
                fallback_session: &|| "pid-1".into(),
                is_skill: &|_| false,
            };
            let started = Instant::now();
            crate::usage::record_hook(&m.db, m.dir.path(), &policies, &ctx, &payload).unwrap();
            started.elapsed()
        })
        .skip(10)
        .collect();
    let took = p95(samples);
    let durable_write = p95((0..30)
        .map(|i| {
            let started = Instant::now();
            m.db.set_meta("budget_calibration", &i.to_string()).unwrap();
            started.elapsed()
        })
        .collect());
    let budget = Duration::from_millis(10).max(durable_write * 6);
    eprintln!("usage hook p95 {took:?}; one durable database write p95 {durable_write:?}; budget {budget:?}");
    assert!(
        took < budget,
        "usage hook p95 {took:?} over its budget {budget:?}"
    );
}

/// A thousand skills reach an agent in under five seconds, and the next run over the same
/// machine finds nothing to do. A skill may cost what ten durable file writes cost on this disk
/// where that is more than five milliseconds — deploying one is about one such write — and the
/// cost per skill must not grow with the number of skills.
#[test]
#[ignore = "waits on the disk; the budgets job runs it alone"]
fn a_thousand_skills_reach_an_agent_in_under_five_seconds() {
    let dir = tempfile::tempdir().unwrap();
    let durable_write = p95((0..40)
        .map(|i| {
            let path = dir.path().join(format!("s{i}/SKILL.md"));
            let started = Instant::now();
            wf_core::atomic::write_file(&path, b"---\nname: s\n---\n").unwrap();
            started.elapsed()
        })
        .collect());
    let budget = Duration::from_secs(5).max(durable_write * 10 * 1000);
    let (small_first, small_again) = sync_skills(50);
    let (first, again) = sync_skills(1000);
    eprintln!(
        "a thousand skills: first sync {first:?}, no-change sync {again:?}, budget {budget:?} \
         (one durable file write p95 {durable_write:?}); fifty took {small_first:?} and {small_again:?}"
    );
    assert!(first < budget, "first sync {first:?} over {budget:?}");
    assert!(again < budget, "no-change sync {again:?} over {budget:?}");
    assert!(
        first / 1000 < small_first / 50 * 3,
        "a skill costs more among a thousand ({:?}) than among fifty ({:?})",
        first / 1000,
        small_first / 50
    );
}

/// Deploy `n` one-file skills into a Claude Code on a disk-backed machine, then sync again.
/// Returns how long each sync took.
fn sync_skills(n: usize) -> (Duration, Duration) {
    let team = TeamFixture::new();
    let mut registry = REGISTRY.trim_start().to_string();
    for i in 0..n {
        registry.push_str(&format!(
            "  - id: capso.skill.s{i}\n    kind: skill\n    source: skills/s{i}\n    required: true\n    targets: [claude-code, codex]\n"
        ));
        team.write(
            &format!("skills/s{i}/SKILL.md"),
            &format!("---\nname: s{i}\ndescription: budget\n---\nStep {i}.\n"),
        );
    }
    team.write("workflow/registry.yaml", &registry);
    let m = on_disk();
    std::fs::create_dir_all(m.at(".claude")).unwrap();
    let claude = m.adapter(&team, "claude-code", Policies::default());
    let converge = || {
        let started = Instant::now();
        let desired = Desired::scan(&team.repo());
        let mut tx = m.tx(false);
        let (_, applied) = crate::engine::converge(&claude, &desired, &mut tx).unwrap();
        tx.commit().unwrap();
        (started.elapsed(), applied.len())
    };
    let (first, applied) = converge();
    assert!(applied >= n, "{applied}");
    assert!(m
        .at(&format!(".claude/skills/s{}/SKILL.md", n - 1))
        .is_file());
    let (again, applied) = converge();
    assert_eq!(applied, 0);
    (first, again)
}
