//! The shapes a rendered resource takes, and the four things done to one: say where it is,
//! hash what it should be, read what is there, and write or erase it through a transaction.
//!
//! Every handler renders into one of these, so the rules that matter are enforced once: a
//! write is backed up and leaves a receipt, a document that does not parse is refused rather
//! than replaced, and an unchanged object is never rewritten.

use crate::formats::{
    get_hook_format, json_doc, openclaw, toml_doc, Document, HookEntry, HookFormat,
};
use serde_json::Value;
use std::path::{Path, PathBuf};
use wf_core::{Error, Result};
use wf_state::Transaction;

/// Where an object lives: a path, and for an object inside a file, its key there.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Placement {
    pub path: PathBuf,
    pub object: Option<String>,
}

impl Placement {
    /// `path#object`, with `%` and `#` in the path escaped so the split is unambiguous.
    pub fn render(&self) -> String {
        let path = self
            .path
            .to_string_lossy()
            .replace('%', "%25")
            .replace('#', "%23");
        match &self.object {
            Some(object) => format!("{path}#{object}"),
            None => path,
        }
    }

    pub fn parse(text: &str) -> Self {
        let (path, object) = match text.split_once('#') {
            Some((path, object)) => (path, Some(object.to_string())),
            None => (text, None),
        };
        Self {
            path: PathBuf::from(path.replace("%23", "#").replace("%25", "%")),
            object,
        }
    }

    fn object(&self) -> Result<&str> {
        self.object.as_deref().ok_or_else(|| {
            Error::failure(
                "PLACEMENT",
                format!("{} names no object inside the file", self.path.display()),
            )
        })
    }

    fn keys(&self) -> Result<Vec<String>> {
        Ok(self.object()?.split('/').map(String::from).collect())
    }
}

/// How an object is found again from nothing but its ownership row.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Shape {
    Tree,
    File,
    /// `shadows` are the agent's other instructions files, which the same block must not be
    /// left in. Only the agent knows whether it keeps any, so the shape carries them rather
    /// than a file-name table guessing from the placement.
    Block {
        shadows: Vec<PathBuf>,
    },
    Key(Document),
    Hook(HookFormat),
}

#[derive(Debug, Clone, PartialEq)]
pub enum Rendered {
    /// A directory wf owns whole — a skill. `hash` is the source's [`tree_hash`], carried
    /// from the scan so inspect and verify do not read every source file again.
    Tree {
        path: PathBuf,
        source: PathBuf,
        hash: String,
    },
    /// A file wf owns whole — a rule, a subagent, a document, a steering prompt.
    File { path: PathBuf, bytes: Vec<u8> },
    /// The organization block in an instructions file somebody else owns. `shadow` is a file
    /// the same block must not also be in (Codex's other instructions file).
    Block {
        path: PathBuf,
        id: String,
        body: String,
        placement: wf_prompts::Placement,
        shadow: Option<PathBuf>,
    },
    /// One key in a JSON or TOML document somebody else owns.
    Key {
        path: PathBuf,
        document: Document,
        keys: Vec<String>,
        value: Value,
    },
    /// One hook handler in an agent's hook document (for OpenClaw, its hook directory).
    Hook {
        path: PathBuf,
        format: HookFormat,
        entry: HookEntry,
    },
}

/// What is at an object's placement now.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Probe {
    Absent,
    Present(String),
}

impl Rendered {
    pub fn shape(&self) -> Shape {
        match self {
            Rendered::Tree { .. } => Shape::Tree,
            Rendered::File { .. } => Shape::File,
            Rendered::Block { shadow, .. } => Shape::Block {
                shadows: shadow.clone().into_iter().collect(),
            },
            Rendered::Key { document, .. } => Shape::Key(*document),
            Rendered::Hook { format, .. } => Shape::Hook(*format),
        }
    }

    pub fn placement(&self) -> Placement {
        let (path, object) = match self {
            Rendered::Tree { path, .. } | Rendered::File { path, .. } => (path, None),
            Rendered::Block { path, id, .. } => (path, Some(id.clone())),
            Rendered::Key { path, keys, .. } => (path, Some(keys.join("/"))),
            Rendered::Hook { path, entry, .. } => (path, Some(entry.identity())),
        };
        Placement {
            path: path.clone(),
            object,
        }
    }

    /// Every path writing this object would replace. One of them being a symlink makes the
    /// object a conflict: `wf` never writes through a link (WFR-015).
    pub fn paths(&self) -> Vec<PathBuf> {
        match self {
            Rendered::Tree { path, .. }
            | Rendered::File { path, .. }
            | Rendered::Key { path, .. } => {
                vec![path.clone()]
            }
            Rendered::Block { path, shadow, .. } => std::iter::once(path.clone())
                .chain(shadow.clone())
                .collect(),
            Rendered::Hook { path, format, .. } if *format == HookFormat::Openclaw => {
                vec![
                    path.clone(),
                    hook_document(*format, path),
                    path.join("handler.ts"),
                ]
            }
            Rendered::Hook { path, format, .. } => vec![hook_document(*format, path)],
        }
    }

    /// The first of [`Rendered::paths`], or of the directories holding it up to and
    /// including `root`, that is a symlink. A linked directory carries the write out of the
    /// agent's root — into the dotfiles repository `~/.claude` points at, say — where a tree
    /// write deletes the files it does not recognise, so it is a conflict for the same
    /// reason a linked leaf is.
    pub fn symlinked(&self, root: &Path) -> Option<PathBuf> {
        self.paths().into_iter().find_map(|p| {
            if is_symlink(&p) {
                return Some(p);
            }
            linked_holder(&p, root)
        })
    }

    /// The hash [`probe`] reports once this object is in place.
    pub fn hash(&self) -> Result<String> {
        Ok(match self {
            Rendered::Tree { hash, .. } => hash.clone(),
            Rendered::File { bytes, .. } => wf_core::hash::sha256_bytes(bytes),
            Rendered::Block {
                id,
                body,
                placement,
                ..
            } => {
                let alone = wf_prompts::apply("", id, body, *placement)?.text;
                block_hash(&wf_prompts::extract(&alone, id).unwrap_or_default())
            }
            Rendered::Key { value, .. } => json_doc::canonical_hash(value),
            Rendered::Hook { format, entry, .. } => {
                json_doc::canonical_hash(&get_hook_format(*format).render_hook(entry))
            }
        })
    }

    pub fn probe(&self) -> Result<Probe> {
        if let Rendered::Block {
            id,
            shadow: Some(shadow),
            ..
        } = self
        {
            let text = wf_core::paths::read_text_or_empty(shadow)?;
            if wf_prompts::extract(&text, id).is_some() {
                // In the file this agent does not read: not in place, whatever the other says.
                return Ok(Probe::Present(block_hash("\0shadowed")));
            }
        }
        probe(self.shape(), &self.placement())
    }

    /// Put the object in place. Returns whether anything was (or, in a dry run, would be)
    /// written.
    pub fn write(&self, component: &str, tx: &mut Transaction<'_>) -> Result<bool> {
        match self {
            Rendered::Tree { path, source, .. } => write_tree(path, source, component, tx),
            Rendered::File { path, bytes } => {
                ensure_parent(tx, path)?;
                tx.write_file(component, "", path, bytes)
            }
            Rendered::Block {
                path,
                id,
                body,
                placement,
                shadow,
            } => {
                let mut changed = false;
                let have = wf_core::paths::read_text_or_empty(path)?;
                let render = wf_prompts::apply(&have, id, body, *placement)?;
                if render.text != have {
                    ensure_parent(tx, path)?;
                    changed |= tx.write_file(component, id, path, render.text.as_bytes())?;
                }
                if let Some(shadow) = shadow {
                    changed |= remove_block(shadow, id, component, tx)?;
                }
                Ok(changed)
            }
            Rendered::Key {
                path,
                document,
                keys,
                value,
            } => {
                let have = wf_core::paths::read_text_or_empty(path)?;
                let new = match document {
                    Document::Json => {
                        let mut doc = json_doc::parse_object(&have, path)?;
                        json_doc::set(&mut doc, keys, value.clone(), path)?;
                        if have.trim().is_empty() {
                            json_doc::render(&doc)
                        } else {
                            json_doc::render_if_changed(&have, &doc, path)?
                        }
                    }
                    Document::Toml => {
                        let mut doc = toml_doc::parse(&have, path)?;
                        toml_doc::set(&mut doc, keys, value, path)?;
                        toml_doc::render_if_changed(&have, &doc)
                    }
                };
                if new == have {
                    return Ok(false);
                }
                ensure_parent(tx, path)?;
                tx.write_file(component, &keys.join("/"), path, new.as_bytes())
            }
            Rendered::Hook {
                path,
                format,
                entry,
            } => {
                let adapter = get_hook_format(*format);
                if !adapter.supports(entry.event) {
                    return Err(Error::unsupported(
                        "HOOK-EVENT",
                        format!("{format:?} hooks have no {} event", entry.event.as_str()),
                    ));
                }
                let doc_path = hook_document(*format, path);
                let have = wf_core::paths::read_text_or_empty(&doc_path)?;
                let new = adapter.upsert(&have, entry, &doc_path)?;
                let identity = entry.identity();
                let mut changed = false;
                if new != have {
                    ensure_parent(tx, &doc_path)?;
                    changed |= tx.write_file(component, &identity, &doc_path, new.as_bytes())?;
                }
                if *format == HookFormat::Openclaw {
                    let handler = path.join("handler.ts");
                    let want = openclaw::handler_ts(&new).unwrap_or_default();
                    if wf_core::paths::read_text_or_empty(&handler)? != want {
                        ensure_parent(tx, &handler)?;
                        changed |=
                            tx.write_file(component, &identity, &handler, want.as_bytes())?;
                    }
                }
                Ok(changed)
            }
        }
    }
}

/// What is at a placement now, knowing only its shape.
pub fn probe(shape: Shape, placement: &Placement) -> Result<Probe> {
    let path = &placement.path;
    let present = |hash: String| Ok(Probe::Present(hash));
    match shape {
        Shape::Tree => {
            if !path.exists() {
                return Ok(Probe::Absent);
            }
            present(tree_hash(path)?)
        }
        Shape::File => {
            if !path.exists() {
                return Ok(Probe::Absent);
            }
            present(wf_core::hash::sha256_file(path)?)
        }
        Shape::Block { .. } => {
            let text = wf_core::paths::read_text_or_empty(path)?;
            match wf_prompts::extract(&text, placement.object()?) {
                Some(body) => present(block_hash(&body)),
                None => Ok(Probe::Absent),
            }
        }
        Shape::Key(document) => {
            let text = wf_core::paths::read_text_or_empty(path)?;
            if text.trim().is_empty() {
                return Ok(Probe::Absent);
            }
            let keys = placement.keys()?;
            let value = match document {
                Document::Json => {
                    json_doc::get(&json_doc::parse_object(&text, path)?, &keys).cloned()
                }
                Document::Toml => toml_doc::get(&toml_doc::parse(&text, path)?, &keys),
            };
            Ok(match value {
                Some(v) => Probe::Present(json_doc::canonical_hash(&v)),
                None => Probe::Absent,
            })
        }
        Shape::Hook(format) => {
            let doc_path = hook_document(format, path);
            let text = wf_core::paths::read_text_or_empty(&doc_path)?;
            if text.trim().is_empty() {
                return Ok(Probe::Absent);
            }
            let identity = placement.object()?;
            let found = get_hook_format(format)
                .parse_hooks(&text, &doc_path)?
                .into_iter()
                .find(|(id, _)| id == identity);
            let Some((_, native)) = found else {
                return Ok(Probe::Absent);
            };
            if format == HookFormat::Openclaw {
                // `HOOK.md` only names `./handler.ts`; that file is the code OpenClaw runs,
                // so an entry whose sidecar is gone or edited is not in place.
                let handler = path.join("handler.ts");
                let want = openclaw::handler_ts(&text).unwrap_or_default();
                if wf_core::paths::read_text_or_empty(&handler)? != want {
                    return Ok(Probe::Absent);
                }
            }
            Ok(Probe::Present(json_doc::canonical_hash(&native)))
        }
    }
}

/// Take an object out of its placement. Returns whether anything changed.
pub fn erase(
    shape: Shape,
    placement: &Placement,
    component: &str,
    tx: &mut Transaction<'_>,
) -> Result<bool> {
    let path = &placement.path;
    match shape {
        Shape::Tree => {
            if !path.is_dir() {
                return Ok(false);
            }
            let mut files = Vec::new();
            for entry in walkdir::WalkDir::new(path).follow_links(false) {
                let entry = entry.map_err(|e| Error::failure("TREE-WALK", e.to_string()))?;
                if !entry.file_type().is_dir() {
                    files.push(entry.into_path());
                }
            }
            for file in &files {
                tx.remove_file(component, file)?;
            }
            if !tx.is_dry_run() {
                // Leaf first. A directory that is not empty holds something that is not ours.
                for entry in walkdir::WalkDir::new(path)
                    .contents_first(true)
                    .into_iter()
                    .flatten()
                {
                    if entry.file_type().is_dir() {
                        let _ = std::fs::remove_dir(entry.path());
                    }
                }
            }
            Ok(!files.is_empty())
        }
        Shape::File => {
            if !path.exists() {
                return Ok(false);
            }
            tx.remove_file(component, path)?;
            Ok(true)
        }
        Shape::Block { shadows } => {
            let id = placement.object()?;
            let mut changed = remove_block(path, id, component, tx)?;
            for shadow in shadows.iter().filter(|s| s.as_path() != path) {
                changed |= remove_block(shadow, id, component, tx)?;
            }
            Ok(changed)
        }
        Shape::Key(document) => {
            let have = wf_core::paths::read_text_or_empty(path)?;
            if have.trim().is_empty() {
                return Ok(false);
            }
            let keys = placement.keys()?;
            let new = match document {
                Document::Json => {
                    let mut doc = json_doc::parse_object(&have, path)?;
                    if !json_doc::remove(&mut doc, &keys) {
                        return Ok(false);
                    }
                    json_doc::render_if_changed(&have, &doc, path)?
                }
                Document::Toml => {
                    let mut doc = toml_doc::parse(&have, path)?;
                    if !toml_doc::remove(&mut doc, &keys) {
                        return Ok(false);
                    }
                    toml_doc::render_if_changed(&have, &doc)
                }
            };
            if new == have {
                return Ok(false);
            }
            tx.write_file(component, &keys.join("/"), path, new.as_bytes())
        }
        Shape::Hook(format) => {
            let doc_path = hook_document(format, path);
            let have = wf_core::paths::read_text_or_empty(&doc_path)?;
            if have.trim().is_empty() {
                return Ok(false);
            }
            let identity = placement.object()?;
            let new = get_hook_format(format).remove(&have, identity, &doc_path)?;
            if new == have {
                return Ok(false);
            }
            let whole = matches!(format, HookFormat::Kiro | HookFormat::Openclaw);
            if new.is_empty() && whole {
                tx.remove_file(component, &doc_path)?;
                if format == HookFormat::Openclaw {
                    let handler = path.join("handler.ts");
                    if handler.exists() {
                        tx.remove_file(component, &handler)?;
                    }
                    if !tx.is_dry_run() {
                        let _ = std::fs::remove_dir(path);
                    }
                }
                return Ok(true);
            }
            let mut changed = tx.write_file(component, identity, &doc_path, new.as_bytes())?;
            if format == HookFormat::Openclaw {
                let handler = path.join("handler.ts");
                let want = openclaw::handler_ts(&new).unwrap_or_default();
                changed |= tx.write_file(component, identity, &handler, want.as_bytes())?;
            }
            Ok(changed)
        }
    }
}

/// A digest of a skill tree that ignores the caches running its scripts leaves behind.
pub fn tree_hash(dir: &Path) -> Result<String> {
    let entries: Vec<_> = wf_core::hash::tree_entries(dir)?
        .into_iter()
        .filter(|e| !is_build_artifact(&e.path))
        .collect();
    Ok(wf_core::hash::digest_entries(&entries))
}

/// The same exclusion the release renderer applies (`wf-release`'s `is_build_artifact`):
/// what is never packaged is never drift either.
pub fn is_build_artifact(rel: &str) -> bool {
    rel.split('/').any(|seg| seg == "__pycache__") || rel.ends_with(".pyc") || rel.ends_with(".pyo")
}

pub fn is_symlink(path: &Path) -> bool {
    std::fs::symlink_metadata(path).is_ok_and(|m| m.file_type().is_symlink())
}

/// The outermost symlink among the directories from `root` down to `path`'s parent.
/// `path` itself is the caller's to check.
pub fn linked_holder(path: &Path, root: &Path) -> Option<PathBuf> {
    let relative = path.strip_prefix(root).ok()?;
    if is_symlink(root) {
        return Some(root.to_path_buf());
    }
    let mut dir = root.to_path_buf();
    let mut components: Vec<_> = relative.components().collect();
    components.pop();
    for part in components {
        dir.push(part);
        if is_symlink(&dir) {
            return Some(dir);
        }
    }
    None
}

/// A block takes the line endings of the file it lives in, so its hash does not.
fn block_hash(body: &str) -> String {
    wf_core::hash::sha256_bytes(body.replace("\r\n", "\n").as_bytes())
}

/// The file a format's handlers live in. For OpenClaw the placement is a directory, and the
/// handlers are in the `HOOK.md` inside it.
pub fn hook_document(format: HookFormat, path: &Path) -> PathBuf {
    if format == HookFormat::Openclaw {
        path.join("HOOK.md")
    } else {
        path.to_path_buf()
    }
}

fn remove_block(path: &Path, id: &str, component: &str, tx: &mut Transaction<'_>) -> Result<bool> {
    let text = wf_core::paths::read_text_or_empty(path)?;
    let cleaned = wf_prompts::remove(&text, id)?;
    if cleaned.text == text {
        return Ok(false);
    }
    tx.write_file(component, id, path, cleaned.text.as_bytes())
}

/// Create `path`'s missing ancestors one level at a time, so a rollback removes each.
fn ensure_parent(tx: &mut Transaction<'_>, path: &Path) -> Result<()> {
    match path.parent() {
        Some(parent) => ensure_dir(tx, parent),
        None => Ok(()),
    }
}

fn ensure_dir(tx: &mut Transaction<'_>, dir: &Path) -> Result<()> {
    let mut missing = Vec::new();
    let mut current = Some(dir);
    while let Some(d) = current {
        if d.as_os_str().is_empty() || d.exists() {
            break;
        }
        missing.push(d);
        current = d.parent();
    }
    for d in missing.into_iter().rev() {
        tx.ensure_directory(d)?;
    }
    Ok(())
}

fn write_tree(
    path: &Path,
    source: &Path,
    component: &str,
    tx: &mut Transaction<'_>,
) -> Result<bool> {
    let entries: Vec<_> = wf_core::hash::tree_entries(source)?
        .into_iter()
        .filter(|e| !is_build_artifact(&e.path))
        .collect();
    ensure_dir(tx, path)?;
    let mut changed = false;
    for e in &entries {
        let target = path.join(&e.path);
        ensure_parent(tx, &target)?;
        let bytes = std::fs::read(source.join(&e.path))?;
        changed |= tx.write_file(component, "", &target, &bytes)?;
        if !tx.is_dry_run() {
            changed |= sync_executable(&target, e.mode & 0o111 != 0)?;
        }
    }
    if path.is_dir() {
        let wanted: std::collections::BTreeSet<&str> =
            entries.iter().map(|e| e.path.as_str()).collect();
        for entry in walkdir::WalkDir::new(path).follow_links(false) {
            let entry = entry.map_err(|e| Error::failure("TREE-WALK", e.to_string()))?;
            if entry.file_type().is_dir() {
                continue;
            }
            let rel = entry
                .path()
                .strip_prefix(path)
                .map(|r| r.to_string_lossy().replace('\\', "/"))
                .unwrap_or_default();
            if !is_build_artifact(&rel) && !wanted.contains(rel.as_str()) {
                tx.remove_file(component, entry.path())?;
                changed = true;
            }
        }
    }
    Ok(changed)
}

/// The tree digest keeps one mode bit, so a script that lost it is drift and has to get it
/// back even when its bytes are already right.
#[cfg(unix)]
fn sync_executable(path: &Path, executable: bool) -> Result<bool> {
    use std::os::unix::fs::PermissionsExt;
    let mode = std::fs::metadata(path)?.permissions().mode();
    let want = if executable {
        mode | 0o755
    } else {
        mode & !0o111
    };
    if want == mode {
        return Ok(false);
    }
    std::fs::set_permissions(path, std::fs::Permissions::from_mode(want))?;
    Ok(true)
}

#[cfg(not(unix))]
fn sync_executable(_path: &Path, _executable: bool) -> Result<bool> {
    Ok(false)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::formats::HookEvent;
    use wf_state::Db;

    struct Fixture {
        dir: tempfile::TempDir,
        db: Db,
    }

    impl Fixture {
        fn new() -> Self {
            Self {
                dir: tempfile::tempdir().unwrap(),
                db: Db::open_memory().unwrap(),
            }
        }
        fn path(&self, rel: &str) -> PathBuf {
            self.dir.path().join(rel)
        }
        fn tx(&self, dry_run: bool) -> Transaction<'_> {
            Transaction::begin(&self.db, self.path("backups"), "2.0.0", dry_run)
        }
        fn write(&self, rel: &str, text: &str) {
            let p = self.path(rel);
            std::fs::create_dir_all(p.parent().unwrap()).unwrap();
            std::fs::write(p, text).unwrap();
        }
        fn read(&self, rel: &str) -> String {
            std::fs::read_to_string(self.path(rel)).unwrap_or_default()
        }
    }

    #[test]
    fn a_placement_round_trips_through_paths_that_contain_the_separator() {
        for (path, object) in [
            ("/home/a/.claude.json", Some("mcpServers/capso-linear")),
            (
                "/home/a/odd#dir%/settings.json",
                Some("SessionStart/capso-wf-bootstrap"),
            ),
            ("/home/a/.claude/skills/lfg", None),
            ("/home/a/#/x", None),
        ] {
            let p = Placement {
                path: PathBuf::from(path),
                object: object.map(String::from),
            };
            assert_eq!(Placement::parse(&p.render()), p, "{}", p.render());
        }
        assert_eq!(
            Placement {
                path: "/a/b".into(),
                object: Some("x".into())
            }
            .render(),
            "/a/b#x"
        );
    }

    fn skill_source(f: &Fixture) -> PathBuf {
        f.write("bundle/skills/lfg/SKILL.md", "---\nname: lfg\n---\n");
        f.write("bundle/skills/lfg/scripts/run.py", "print('hi')\n");
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            std::fs::set_permissions(
                f.path("bundle/skills/lfg/scripts/run.py"),
                std::fs::Permissions::from_mode(0o755),
            )
            .unwrap();
        }
        f.path("bundle/skills/lfg")
    }

    #[test]
    fn a_tree_is_copied_whole_verified_by_hash_and_erased_whole() {
        let f = Fixture::new();
        let tree = Rendered::Tree {
            path: f.path("claude/skills/lfg"),
            source: skill_source(&f),
            hash: tree_hash(&skill_source(&f)).unwrap(),
        };
        assert_eq!(tree.probe().unwrap(), Probe::Absent);
        let mut tx = f.tx(false);
        assert!(tree.write("capso.skill.lfg", &mut tx).unwrap());
        tx.commit().unwrap();
        assert_eq!(tree.probe().unwrap(), Probe::Present(tree.hash().unwrap()));
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let mode = std::fs::metadata(f.path("claude/skills/lfg/scripts/run.py"))
                .unwrap()
                .permissions()
                .mode();
            assert_ne!(mode & 0o111, 0, "the script lost its executable bit");
        }
        // A cache from running a script is not drift…
        f.write(
            "claude/skills/lfg/scripts/__pycache__/run.cpython-312.pyc",
            "bytecode",
        );
        assert_eq!(tree.probe().unwrap(), Probe::Present(tree.hash().unwrap()));
        // …but a stray file is, and a rewrite removes it.
        f.write("claude/skills/lfg/stray.md", "old");
        assert_ne!(tree.probe().unwrap(), Probe::Present(tree.hash().unwrap()));
        let mut tx = f.tx(false);
        assert!(tree.write("capso.skill.lfg", &mut tx).unwrap());
        tx.commit().unwrap();
        assert!(!f.path("claude/skills/lfg/stray.md").exists());
        let mut tx = f.tx(false);
        assert!(
            !tree.write("capso.skill.lfg", &mut tx).unwrap(),
            "an identical tree is not a write"
        );
        tx.commit().unwrap();

        let mut tx = f.tx(false);
        assert!(erase(Shape::Tree, &tree.placement(), "capso.skill.lfg", &mut tx).unwrap());
        tx.commit().unwrap();
        assert!(
            !f.path("claude/skills/lfg").exists(),
            "the tree and its directories are gone"
        );
        assert!(f.path("claude/skills").exists(), "the parent is not ours");
    }

    #[test]
    fn a_rolled_back_tree_leaves_no_directory_behind() {
        let f = Fixture::new();
        let tree = Rendered::Tree {
            path: f.path("claude/skills/lfg"),
            source: skill_source(&f),
            hash: tree_hash(&skill_source(&f)).unwrap(),
        };
        let mut tx = f.tx(false);
        tree.write("capso.skill.lfg", &mut tx).unwrap();
        tx.rollback();
        assert!(
            !f.path("claude/skills").exists(),
            "every created directory was undone"
        );
    }

    #[test]
    fn a_file_is_written_probed_and_erased() {
        let f = Fixture::new();
        let file = Rendered::File {
            path: f.path("cursor/rules/security/secrets.mdc"),
            bytes: b"---\nalwaysApply: true\n---\n".to_vec(),
        };
        let mut tx = f.tx(false);
        assert!(file.write("team.rule.security/secrets", &mut tx).unwrap());
        tx.commit().unwrap();
        assert_eq!(file.probe().unwrap(), Probe::Present(file.hash().unwrap()));
        assert_eq!(
            probe(Shape::File, &file.placement()).unwrap(),
            Probe::Present(file.hash().unwrap())
        );
        let mut tx = f.tx(false);
        assert!(erase(
            Shape::File,
            &file.placement(),
            "team.rule.security/secrets",
            &mut tx
        )
        .unwrap());
        tx.commit().unwrap();
        assert_eq!(file.probe().unwrap(), Probe::Absent);
        let mut tx = f.tx(false);
        assert!(
            !erase(Shape::File, &file.placement(), "x", &mut tx).unwrap(),
            "erasing nothing changes nothing"
        );
    }

    #[test]
    fn a_block_joins_a_personal_file_and_leaves_it_as_it_was() {
        let f = Fixture::new();
        f.write("claude/CLAUDE.md", "my notes\r\n");
        let block = Rendered::Block {
            path: f.path("claude/CLAUDE.md"),
            id: "capso.global".into(),
            body: "## Capso\n\nUse /lfg.\n".into(),
            placement: wf_prompts::Placement::Append,
            shadow: None,
        };
        assert_eq!(block.probe().unwrap(), Probe::Absent);
        let mut tx = f.tx(false);
        assert!(block.write("capso.prompt.global", &mut tx).unwrap());
        tx.commit().unwrap();
        assert!(f.read("claude/CLAUDE.md").starts_with("my notes\r\n"));
        assert_eq!(
            block.probe().unwrap(),
            Probe::Present(block.hash().unwrap())
        );
        assert_eq!(
            probe(Shape::Block { shadows: vec![] }, &block.placement()).unwrap(),
            Probe::Present(block.hash().unwrap())
        );

        // Somebody edits inside the block: drift, visible from the row alone.
        let edited = f.read("claude/CLAUDE.md").replace("Use /lfg.", "CLOBBERED");
        std::fs::write(f.path("claude/CLAUDE.md"), edited).unwrap();
        assert_ne!(
            block.probe().unwrap(),
            Probe::Present(block.hash().unwrap())
        );

        let mut tx = f.tx(false);
        assert!(erase(
            Shape::Block { shadows: vec![] },
            &block.placement(),
            "capso.prompt.global",
            &mut tx
        )
        .unwrap());
        tx.commit().unwrap();
        assert_eq!(f.read("claude/CLAUDE.md"), "my notes\r\n");
    }

    #[test]
    fn a_codex_block_never_stays_in_the_shadow_file() {
        let f = Fixture::new();
        f.write("codex/AGENTS.override.md", "override\n");
        f.write(
            "codex/AGENTS.md",
            &wf_prompts::apply("", "capso.global", "old", wf_prompts::Placement::Prepend)
                .unwrap()
                .text,
        );
        let block = Rendered::Block {
            path: f.path("codex/AGENTS.override.md"),
            id: "capso.global".into(),
            body: "new".into(),
            placement: wf_prompts::Placement::Prepend,
            shadow: Some(f.path("codex/AGENTS.md")),
        };
        assert_ne!(
            block.probe().unwrap(),
            Probe::Present(block.hash().unwrap())
        );
        let mut tx = f.tx(false);
        block.write("capso.prompt.global", &mut tx).unwrap();
        tx.commit().unwrap();
        assert!(wf_prompts::extract(&f.read("codex/AGENTS.md"), "capso.global").is_none());
        assert_eq!(
            block.probe().unwrap(),
            Probe::Present(block.hash().unwrap())
        );
        // Erasing from the row also cleans the shadow, wherever the block went since.
        let mut tx = f.tx(false);
        erase(
            Shape::Block {
                shadows: vec![f.path("codex/AGENTS.md")],
            },
            &block.placement(),
            "capso.prompt.global",
            &mut tx,
        )
        .unwrap();
        tx.commit().unwrap();
        assert_eq!(f.read("codex/AGENTS.override.md"), "override\n");
    }

    #[test]
    fn a_json_key_is_set_and_erased_without_touching_its_neighbours() {
        let f = Fixture::new();
        let user = "{\"numStartups\": 12, \"mcpServers\": {\"mine\": {\"command\": \"uvx\"}}}";
        f.write("home/.claude.json", user);
        let key = Rendered::Key {
            path: f.path("home/.claude.json"),
            document: Document::Json,
            keys: vec!["mcpServers".into(), "capso-linear".into()],
            value: serde_json::json!({"type": "stdio", "command": "npx", "args": []}),
        };
        assert_eq!(key.probe().unwrap(), Probe::Absent);
        let mut tx = f.tx(false);
        assert!(key.write("capso.mcp.linear", &mut tx).unwrap());
        tx.commit().unwrap();
        let doc: Value = serde_json::from_str(&f.read("home/.claude.json")).unwrap();
        assert_eq!(doc["numStartups"], 12);
        assert_eq!(doc["mcpServers"]["mine"]["command"], "uvx");
        assert_eq!(key.probe().unwrap(), Probe::Present(key.hash().unwrap()));
        assert_eq!(
            probe(Shape::Key(Document::Json), &key.placement()).unwrap(),
            Probe::Present(key.hash().unwrap())
        );
        let receipts = f.db.receipts().unwrap();
        assert_eq!(receipts[0].object_id, "mcpServers/capso-linear");

        let mut tx = f.tx(false);
        assert!(erase(
            Shape::Key(Document::Json),
            &key.placement(),
            "capso.mcp.linear",
            &mut tx
        )
        .unwrap());
        tx.commit().unwrap();
        assert_eq!(
            serde_json::from_str::<Value>(&f.read("home/.claude.json")).unwrap(),
            serde_json::from_str::<Value>(user).unwrap()
        );
    }

    #[test]
    fn a_document_that_does_not_parse_is_refused_and_left_alone() {
        let f = Fixture::new();
        f.write("home/.claude.json", "{ not json");
        let key = Rendered::Key {
            path: f.path("home/.claude.json"),
            document: Document::Json,
            keys: vec!["mcpServers".into(), "x".into()],
            value: serde_json::json!({}),
        };
        let mut tx = f.tx(false);
        assert_eq!(
            key.write("c", &mut tx).unwrap_err().code,
            wf_core::ExitCode::Conflict
        );
        tx.rollback();
        assert_eq!(f.read("home/.claude.json"), "{ not json");
        assert!(key.probe().is_err());
    }

    #[test]
    fn a_toml_key_keeps_the_rest_of_the_document_byte_for_byte() {
        let f = Fixture::new();
        let user = "# mine\nmodel = \"gpt-5\"\n";
        f.write("codex/config.toml", user);
        let key = Rendered::Key {
            path: f.path("codex/config.toml"),
            document: Document::Toml,
            keys: vec!["mcp_servers".into(), "capso-linear".into()],
            value: serde_json::json!({"command": "npx", "args": ["-y"], "env_vars": ["LINEAR_API_TOKEN"]}),
        };
        let mut tx = f.tx(false);
        assert!(key.write("capso.mcp.linear", &mut tx).unwrap());
        tx.commit().unwrap();
        assert!(f.read("codex/config.toml").starts_with(user));
        assert_eq!(key.probe().unwrap(), Probe::Present(key.hash().unwrap()));
        let mut tx = f.tx(false);
        erase(
            Shape::Key(Document::Toml),
            &key.placement(),
            "capso.mcp.linear",
            &mut tx,
        )
        .unwrap();
        tx.commit().unwrap();
        assert_eq!(f.read("codex/config.toml"), user);
    }

    fn usage(event: HookEvent, agent: &str) -> HookEntry {
        HookEntry {
            event,
            matcher: None,
            argv: [
                "/x/wf",
                "hook",
                "dispatch",
                "--event",
                event.as_str(),
                "--agent",
                agent,
            ]
            .map(String::from)
            .to_vec(),
            timeout_secs: Some(10),
        }
    }

    #[test]
    fn a_hook_is_upserted_probed_and_erased_in_a_shared_settings_file() {
        let f = Fixture::new();
        f.write("claude/settings.json", "{\"model\": \"opus\"}");
        let hook = Rendered::Hook {
            path: f.path("claude/settings.json"),
            format: HookFormat::Claude,
            entry: usage(HookEvent::Stop, "claude"),
        };
        let mut tx = f.tx(false);
        assert!(hook.write("capso.hook.usage.stop", &mut tx).unwrap());
        tx.commit().unwrap();
        assert_eq!(hook.probe().unwrap(), Probe::Present(hook.hash().unwrap()));
        assert_eq!(
            hook.placement().object.as_deref(),
            Some("Stop/capso-wf-usage")
        );
        let mut tx = f.tx(false);
        assert!(erase(
            Shape::Hook(HookFormat::Claude),
            &hook.placement(),
            "c",
            &mut tx
        )
        .unwrap());
        tx.commit().unwrap();
        assert_eq!(
            serde_json::from_str::<Value>(&f.read("claude/settings.json")).unwrap(),
            serde_json::json!({"model": "opus"})
        );
    }

    #[test]
    fn a_hook_file_wf_owns_whole_goes_when_its_last_handler_does() {
        let f = Fixture::new();
        let hook = Rendered::Hook {
            path: f.path("kiro/hooks/capso-wf.json"),
            format: HookFormat::Kiro,
            entry: usage(HookEvent::Stop, "kiro"),
        };
        let mut tx = f.tx(false);
        hook.write("c", &mut tx).unwrap();
        tx.commit().unwrap();
        assert!(f.path("kiro/hooks/capso-wf.json").is_file());
        let mut tx = f.tx(false);
        assert!(erase(
            Shape::Hook(HookFormat::Kiro),
            &hook.placement(),
            "c",
            &mut tx
        )
        .unwrap());
        tx.commit().unwrap();
        assert!(!f.path("kiro/hooks/capso-wf.json").exists());
    }

    #[test]
    fn an_openclaw_hook_writes_its_declaration_and_its_handler_together() {
        let f = Fixture::new();
        let hook = Rendered::Hook {
            path: f.path("openclaw/workspace/hooks/capso-wf"),
            format: HookFormat::Openclaw,
            entry: HookEntry {
                event: HookEvent::SessionStart,
                matcher: None,
                argv: ["/x/wf", "hook", "session-start", "--agent", "openclaw"]
                    .map(String::from)
                    .to_vec(),
                timeout_secs: None,
            },
        };
        let mut tx = f.tx(false);
        hook.write("c", &mut tx).unwrap();
        tx.commit().unwrap();
        assert!(f
            .read("openclaw/workspace/hooks/capso-wf/HOOK.md")
            .contains("session:start"));
        assert!(f
            .read("openclaw/workspace/hooks/capso-wf/handler.ts")
            .contains("session-start"));
        assert_eq!(hook.probe().unwrap(), Probe::Present(hook.hash().unwrap()));
        let mut tx = f.tx(false);
        erase(
            Shape::Hook(HookFormat::Openclaw),
            &hook.placement(),
            "c",
            &mut tx,
        )
        .unwrap();
        tx.commit().unwrap();
        assert!(!f.path("openclaw/workspace/hooks/capso-wf/HOOK.md").exists());
        assert!(!f
            .path("openclaw/workspace/hooks/capso-wf/handler.ts")
            .exists());
    }

    /// `HOOK.md` only names `./handler.ts`; that file is the code OpenClaw runs. Probing the
    /// declaration alone read a hook whose handler was gone as in place, so `wf repair` had
    /// nothing to do while every session's hook failed.
    #[test]
    fn an_openclaw_hook_whose_handler_is_gone_is_not_in_place() {
        let f = Fixture::new();
        let hook = Rendered::Hook {
            path: f.path("openclaw/workspace/hooks/capso-wf"),
            format: HookFormat::Openclaw,
            entry: HookEntry {
                event: HookEvent::SessionStart,
                matcher: None,
                argv: ["/x/wf", "hook", "session-start", "--agent", "openclaw"]
                    .map(String::from)
                    .to_vec(),
                timeout_secs: None,
            },
        };
        let mut tx = f.tx(false);
        hook.write("c", &mut tx).unwrap();
        tx.commit().unwrap();
        let handler = f.path("openclaw/workspace/hooks/capso-wf/handler.ts");

        std::fs::remove_file(&handler).unwrap();
        assert_eq!(hook.probe().unwrap(), Probe::Absent);
        std::fs::write(&handler, "// somebody rewrote this\n").unwrap();
        assert_eq!(hook.probe().unwrap(), Probe::Absent);

        let mut tx = f.tx(false);
        assert!(hook.write("c", &mut tx).unwrap(), "and it is repaired");
        tx.commit().unwrap();
        assert_eq!(hook.probe().unwrap(), Probe::Present(hook.hash().unwrap()));
    }

    /// A skill directory whose files somebody already deleted is an empty directory: there
    /// is nothing left to remove, and reporting a removal that did not happen is what made
    /// `wf sync` announce changes it never made.
    #[test]
    fn erasing_an_empty_tree_removes_nothing_and_says_so() {
        let f = Fixture::new();
        std::fs::create_dir_all(f.path("claude/skills/lfg")).unwrap();
        let placement = Placement {
            path: f.path("claude/skills/lfg"),
            object: None,
        };
        let mut tx = f.tx(false);
        assert!(!erase(Shape::Tree, &placement, "capso.skill.lfg", &mut tx).unwrap());
        tx.commit().unwrap();
    }

    #[test]
    fn a_dry_run_plans_every_shape_and_writes_nothing() {
        let f = Fixture::new();
        let objects = vec![
            Rendered::Tree {
                path: f.path("a/skills/lfg"),
                source: skill_source(&f),
                hash: tree_hash(&skill_source(&f)).unwrap(),
            },
            Rendered::File {
                path: f.path("a/rules/x.md"),
                bytes: b"x".to_vec(),
            },
            Rendered::Block {
                path: f.path("a/CLAUDE.md"),
                id: "capso.global".into(),
                body: "b".into(),
                placement: wf_prompts::Placement::Append,
                shadow: None,
            },
            Rendered::Key {
                path: f.path("a/.claude.json"),
                document: Document::Json,
                keys: vec!["mcpServers".into(), "x".into()],
                value: serde_json::json!({}),
            },
            Rendered::Hook {
                path: f.path("a/settings.json"),
                format: HookFormat::Claude,
                entry: usage(HookEvent::Stop, "claude"),
            },
        ];
        let mut tx = f.tx(true);
        for o in &objects {
            assert!(o.write("c", &mut tx).unwrap(), "{o:?}");
        }
        assert!(!tx.plan.is_empty());
        tx.commit().unwrap();
        assert!(!f.path("a").exists(), "a dry run created something");
    }
}
