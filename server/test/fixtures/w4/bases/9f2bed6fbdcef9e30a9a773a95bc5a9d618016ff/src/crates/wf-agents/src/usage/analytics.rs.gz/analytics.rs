//! Usage statistics: counts grouped the ways `wf usage` shows them.

use serde::Serialize;
use wf_core::{Error, Result};
use wf_state::{Db, GroupCount, UsageGroup, UsageQuery};

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct StatsFilter {
    pub agent: Option<String>,
    /// Fixed-width UTC text; see [`parse_since`].
    pub since: Option<String>,
    /// How many rows each ranking keeps.
    pub limit: usize,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct UsageStats {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub since: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub agent: Option<String>,
    pub events: i64,
    pub sessions: i64,
    pub prompts: i64,
    pub skills: Vec<GroupCount>,
    pub tools: Vec<GroupCount>,
    pub agents: Vec<GroupCount>,
    /// Oldest day first.
    pub days: Vec<GroupCount>,
    pub known_skills: i64,
}

pub fn compute(db: &Db, filter: &StatsFilter) -> Result<UsageStats> {
    let query = UsageQuery {
        agent: filter.agent.clone(),
        since: filter.since.clone(),
        ..Default::default()
    };
    let limit = if filter.limit == 0 { 10 } else { filter.limit };
    let kinds = db.usage_grouped(&query, UsageGroup::EventType, usize::MAX)?;
    let mut days = db.usage_grouped(&query, UsageGroup::Day, usize::MAX)?;
    days.sort_by(|a, b| a.key.cmp(&b.key));
    Ok(UsageStats {
        since: filter.since.clone(),
        agent: filter.agent.clone(),
        events: kinds.iter().map(|k| k.count).sum(),
        sessions: db
            .usage_grouped(&query, UsageGroup::Session, usize::MAX)?
            .len() as i64,
        prompts: kinds
            .iter()
            .find(|k| k.key == "prompt")
            .map(|k| k.count)
            .unwrap_or(0),
        skills: db.usage_grouped(&query, UsageGroup::Skill, limit)?,
        tools: db.usage_grouped(&query, UsageGroup::Tool, limit)?,
        agents: db.usage_grouped(&query, UsageGroup::Agent, usize::MAX)?,
        days,
        known_skills: db.known_skills()?.len() as i64,
    })
}

/// `30d`, `12h`, `90m`, or a date `YYYY-MM-DD`, as the fixed-width UTC lower bound.
pub fn parse_since(text: &str, now_ms: i64) -> Result<String> {
    let refuse = || {
        Error::usage(
            "SINCE",
            format!("{text:?}: expected a duration such as 30d, 12h or 90m, or a date YYYY-MM-DD"),
        )
        .with_zh("`--since` 要写成 30d、12h、90m 这样的时长，或者 2026-09-01 这样的日期。")
    };
    let text = text.trim();
    if text.len() == 10 && text.as_bytes()[4] == b'-' && text.as_bytes()[7] == b'-' {
        let at = wf_core::time_fmt::parse_rfc3339_millis(&format!("{text}T00:00:00Z"))
            .ok_or_else(refuse)?;
        return Ok(wf_core::time_fmt::utc_millis(at));
    }
    let digits = text.trim_end_matches(char::is_alphabetic);
    let unit = &text[digits.len()..];
    let count: i64 = digits.parse().map_err(|_| refuse())?;
    let per = match unit {
        "d" => 86_400_000,
        "h" => 3_600_000,
        "m" => 60_000,
        _ => return Err(refuse()),
    };
    Ok(wf_core::time_fmt::utc_millis(
        now_ms - count.saturating_mul(per),
    ))
}

/// The human rendering `wf usage` prints.
pub fn render_zh(stats: &UsageStats) -> String {
    if stats.events == 0 {
        return "这段时间里还没有使用记录。wf 只统计 agent 钩子在本机报告的使用情况，不会上传任何数据。\n"
            .to_string();
    }
    let mut s = String::new();
    let scope = match (&stats.agent, &stats.since) {
        (Some(a), Some(t)) => format!("（{a}，自 {} 起）", &t[..10]),
        (Some(a), None) => format!("（{a}）"),
        (None, Some(t)) => format!("（自 {} 起）", &t[..10]),
        (None, None) => String::new(),
    };
    s.push_str(&format!(
        "使用情况{scope}：{} 个事件，{} 个会话，{} 条提示。\n",
        stats.events, stats.sessions, stats.prompts
    ));
    let table = |s: &mut String, title: &str, rows: &[GroupCount], unit: &str| {
        if rows.is_empty() {
            return;
        }
        s.push_str(&format!("\n{title}\n"));
        for r in rows {
            s.push_str(&format!(
                "  {:<28} {:>6} {unit}  最近 {}\n",
                r.key,
                r.count,
                &r.last_seen[..10]
            ));
        }
    };
    table(&mut s, "常用技能：", &stats.skills, "次");
    table(&mut s, "常用工具：", &stats.tools, "次");
    table(&mut s, "各 agent：", &stats.agents, "个事件");
    if !stats.days.is_empty() {
        s.push_str("\n按天：\n");
        for d in &stats.days {
            s.push_str(&format!("  {}  {:>6}\n", d.key, d.count));
        }
    }
    s.push_str(&format!(
        "\n这台机器上一共用过 {} 个技能。\n",
        stats.known_skills
    ));
    s
}

#[cfg(test)]
mod tests {
    use super::*;
    use wf_state::UsageEventRow;

    fn event(db: &Db, at: &str, session: &str, agent: &str, kind: &str, name: Option<&str>) {
        db.insert_usage_event(&UsageEventRow {
            id: 0,
            timestamp: at.into(),
            session_id: session.into(),
            agent: agent.into(),
            event_type: kind.into(),
            skill_name: (kind == "skill").then(|| name.unwrap().to_string()),
            tool_name: (kind == "tool").then(|| name.unwrap().to_string()),
            source: None,
            metadata: serde_json::Value::Null,
        })
        .unwrap();
    }

    fn seeded() -> Db {
        let db = Db::open_memory().unwrap();
        event(
            &db,
            "2026-09-14T10:00:00.000Z",
            "a",
            "claude-code",
            "prompt",
            None,
        );
        event(
            &db,
            "2026-09-14T10:01:00.000Z",
            "a",
            "claude-code",
            "skill",
            Some("lfg"),
        );
        event(
            &db,
            "2026-09-14T10:02:00.000Z",
            "a",
            "claude-code",
            "tool",
            Some("Edit"),
        );
        event(
            &db,
            "2026-09-16T09:00:00.000Z",
            "b",
            "codex",
            "tool",
            Some("Bash"),
        );
        event(
            &db,
            "2026-09-16T09:01:00.000Z",
            "b",
            "codex",
            "tool",
            Some("Bash"),
        );
        event(
            &db,
            "2026-09-16T09:02:00.000Z",
            "b",
            "codex",
            "skill",
            Some("lfg"),
        );
        db.touch_known_skill("lfg", "2026-09-14T10:01:00.000Z")
            .unwrap();
        db
    }

    #[test]
    fn stats_count_events_sessions_and_rank_what_was_used() {
        let db = seeded();
        let all = compute(
            &db,
            &StatsFilter {
                limit: 10,
                ..Default::default()
            },
        )
        .unwrap();
        assert_eq!(all.events, 6);
        assert_eq!(all.sessions, 2);
        assert_eq!(all.prompts, 1);
        assert_eq!(all.skills[0].key, "lfg");
        assert_eq!(all.skills[0].count, 2);
        assert_eq!(all.tools[0].key, "Bash");
        assert_eq!(all.agents.len(), 2);
        assert_eq!(
            all.days.iter().map(|d| d.key.as_str()).collect::<Vec<_>>(),
            ["2026-09-14", "2026-09-16"]
        );
        assert_eq!(all.known_skills, 1);
    }

    #[test]
    fn stats_narrow_by_agent_and_time() {
        let db = seeded();
        let codex = compute(
            &db,
            &StatsFilter {
                agent: Some("codex".into()),
                limit: 10,
                ..Default::default()
            },
        )
        .unwrap();
        assert_eq!(codex.events, 3);
        assert_eq!(codex.sessions, 1);
        let recent = compute(
            &db,
            &StatsFilter {
                since: Some("2026-09-15T00:00:00.000Z".into()),
                limit: 1,
                ..Default::default()
            },
        )
        .unwrap();
        assert_eq!(recent.events, 3);
        assert_eq!(recent.tools.len(), 1);
    }

    #[test]
    fn since_takes_durations_and_dates_and_refuses_the_rest() {
        let now = wf_core::time_fmt::parse_rfc3339_millis("2026-09-16T12:00:00Z").unwrap();
        assert_eq!(parse_since("30d", now).unwrap(), "2026-08-17T12:00:00.000Z");
        assert_eq!(parse_since("12h", now).unwrap(), "2026-09-16T00:00:00.000Z");
        assert_eq!(parse_since("90m", now).unwrap(), "2026-09-16T10:30:00.000Z");
        assert_eq!(
            parse_since("2026-09-01", now).unwrap(),
            "2026-09-01T00:00:00.000Z"
        );
        for bad in ["", "yesterday", "30", "3w", "2026-13-01"] {
            assert_eq!(
                parse_since(bad, now).unwrap_err().code,
                wf_core::ExitCode::Usage,
                "{bad}"
            );
        }
    }

    #[test]
    fn the_rendering_leads_with_totals_and_says_so_when_there_is_nothing() {
        let db = seeded();
        let text = render_zh(
            &compute(
                &db,
                &StatsFilter {
                    limit: 10,
                    ..Default::default()
                },
            )
            .unwrap(),
        );
        assert!(text.contains("6"), "{text}");
        assert!(text.contains("lfg"), "{text}");
        let empty = render_zh(
            &compute(
                &Db::open_memory().unwrap(),
                &StatsFilter {
                    limit: 10,
                    ..Default::default()
                },
            )
            .unwrap(),
        );
        assert!(empty.contains("还没有"), "{empty}");
    }
}
