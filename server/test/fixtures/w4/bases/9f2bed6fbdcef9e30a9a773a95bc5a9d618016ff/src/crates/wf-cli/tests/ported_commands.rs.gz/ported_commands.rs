use std::process::Command;

#[test]
fn readiness_rechecks_after_installing_a_missing_tool() {
    use std::os::unix::fs::PermissionsExt;
    let dir = tempfile::tempdir().unwrap();
    let bin = dir.path().join("bin");
    std::fs::create_dir_all(&bin).unwrap();
    let brew = bin.join("brew");
    std::fs::write(&brew, "#!/bin/sh\nprintf '#!/bin/sh\\nexit 0\\n' > \"$(dirname \"$0\")/review-probe\"\nchmod +x \"$(dirname \"$0\")/review-probe\"\n").unwrap();
    std::fs::set_permissions(&brew, std::fs::Permissions::from_mode(0o755)).unwrap();
    std::fs::create_dir_all(dir.path().join("workflow/readiness")).unwrap();
    std::fs::write(dir.path().join("workflow/readiness/consumer.yaml"), "schema_version: 1\nprofile: consumer\nrequirements:\n  - tool: review-probe\n    install:\n      darwin: brew install review-probe\n      linux: brew install review-probe\n").unwrap();
    let out = Command::new(env!("CARGO_BIN_EXE_wf"))
        .current_dir(dir.path())
        .env("PATH", format!("{}:/usr/bin:/bin", bin.display()))
        .env("SHELL", "/bin/sh")
        .env("WF_HOME", dir.path().join("state"))
        .args(["readiness", "--repair", "--force", "--json"])
        .output()
        .unwrap();
    assert!(
        bin.join("review-probe").is_file(),
        "the fixture install did not run"
    );
    assert!(
        out.status.success(),
        "{}",
        String::from_utf8_lossy(&out.stdout)
    );
    let result: serde_json::Value = serde_json::from_slice(&out.stdout).unwrap();
    assert_eq!(result["result"]["ready"], true);
    assert_eq!(result["result"]["repaired"], true);
}

#[test]
fn readiness_cache_tracks_credentials_and_network_expiry_without_storing_secrets() {
    let dir = tempfile::tempdir().unwrap();
    std::fs::create_dir_all(dir.path().join("workflow/readiness")).unwrap();
    std::fs::write(dir.path().join("workflow/readiness/consumer.yaml"),"schema_version: 1\nprofile: consumer\nrequirements:\n  - tool: true\n    credential:\n      env: [WF_REVIEW_CREDENTIAL]\n").unwrap();
    let run = |secret: &str| {
        let out = Command::new(env!("CARGO_BIN_EXE_wf"))
            .current_dir(dir.path())
            .env("WF_HOME", dir.path().join("state"))
            .env("CLAUDE_CONFIG_DIR", dir.path().join("claude"))
            .env("WF_REVIEW_CREDENTIAL", secret)
            .env("SHELL", "/bin/sh")
            .args(["readiness", "--json"])
            .output()
            .unwrap();
        assert!(
            out.status.success(),
            "{}",
            String::from_utf8_lossy(&out.stdout)
        );
        serde_json::from_slice::<serde_json::Value>(&out.stdout).unwrap()["result"].clone()
    };
    let a = "review-fixture-token-alpha";
    let b = "review-fixture-token-beta";
    assert_eq!(run(a)["cached"], false);
    assert_eq!(run(a)["cached"], true);
    let third = run(b);
    assert_eq!(third["cached"], false);
    let path = third["state_file"].as_str().unwrap();
    let text = std::fs::read_to_string(path).unwrap();
    assert!(!text.contains(a) && !text.contains(b));
    let mut state: serde_json::Value = serde_json::from_str(&text).unwrap();
    state["at"] = serde_json::json!("2000-01-01T00:00:00Z");
    std::fs::write(path, serde_json::to_vec(&state).unwrap()).unwrap();
    assert_eq!(run(b)["cached"], false);
}

#[test]
fn obsidian_accepts_the_documented_inputs_for_every_kind() {
    let dir = tempfile::tempdir().unwrap();
    let vault = dir.path().join("vault");
    std::fs::create_dir_all(vault.join("Project TXE")).unwrap();
    let body = dir.path().join("body.md");
    std::fs::write(&body, "# Review fixture\n").unwrap();
    for kind in wf_obsidian::layout::KINDS {
        let mut command = Command::new(env!("CARGO_BIN_EXE_wf"));
        command
            .args(["obsidian", "--kind", kind.name, "--vault"])
            .arg(&vault)
            .arg("--file")
            .arg(&body)
            .args([
                "--ticket",
                "TXE-123",
                "--url",
                "https://example.test/artifact",
                "--date",
                "2026-09-05",
                "--json",
            ]);
        match kind.scope {
            wf_obsidian::Scope::Feature => {
                command.args(["--product", "TXE", "--feature", "spot-bidding"]);
            }
            wf_obsidian::Scope::Product => {
                command.args(["--product", "TXE", "--title", "Decision Title"]);
            }
            wf_obsidian::Scope::Vault => {
                command.args(["--slug", "incident"]);
            }
        }
        let out = command.output().unwrap();
        assert!(
            out.status.success(),
            "{}: {}",
            kind.name,
            String::from_utf8_lossy(&out.stderr)
        );
        let data: serde_json::Value = serde_json::from_slice(&out.stdout).unwrap();
        let text = std::fs::read_to_string(data["result"]["path"].as_str().unwrap()).unwrap();
        assert!(text.contains("TXE-123") && text.contains("https://example.test/artifact"));
        assert!(text.contains("# Review fixture"));
    }
}

#[test]
#[cfg_attr(target_os = "macos", ignore = "needs Docker Compose")]
fn readiness_waits_for_a_started_docker_daemon_before_rechecking() {
    use std::os::unix::fs::PermissionsExt;
    let dir = tempfile::tempdir().unwrap();
    let bin = dir.path().join("bin");
    std::fs::create_dir(&bin).unwrap();
    for name in ["open", "systemctl", "sudo"] {
        let path = bin.join(name);
        std::fs::write(&path, "#!/bin/sh\ntouch starting\n").unwrap();
        std::fs::set_permissions(path, std::fs::Permissions::from_mode(0o755)).unwrap();
    }
    // Only the daemon is slow to start here: what the compose file means is still the real
    // Compose's answer.
    let real = wf_core::proc::which("docker").expect("docker is needed for this test");
    let docker = bin.join("docker");
    std::fs::write(
        &docker,
        format!(
            "#!/bin/sh\nif [ \"$1\" = compose ]; then exec '{}' \"$@\"; fi\n",
            real.display()
        ) + r#"if [ "$1" = --version ]; then echo 'Docker version 27.3.0'; exit 0; fi
if [ "$1" = info ]; then
  [ -e starting ] || exit 1
  count=0
  [ ! -f attempts ] || read count < attempts
  count=$((count + 1))
  echo "$count" > attempts
  [ "$count" -ge 3 ] || exit 1
  echo 27.3.0
fi
"#,
    )
    .unwrap();
    std::fs::set_permissions(docker, std::fs::Permissions::from_mode(0o755)).unwrap();
    let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
    let port = listener.local_addr().unwrap().port();
    std::fs::create_dir_all(dir.path().join("workflow/readiness")).unwrap();
    std::fs::write(
        dir.path().join("workflow/readiness/consumer.yaml"),
        "schema_version: 1\nprofile: consumer\nrequirements: []\n",
    )
    .unwrap();
    std::fs::write(
        dir.path().join("readiness.yaml"),
        "version: 1\nservices:\n  need: [fixture]\n",
    )
    .unwrap();
    std::fs::write(
        dir.path().join("compose.yaml"),
        format!("services:\n  fixture:\n    image: alpine:latest\n    ports: ['{port}:5432']\n"),
    )
    .unwrap();
    let output = Command::new(env!("CARGO_BIN_EXE_wf"))
        .current_dir(dir.path())
        .env("PATH", format!("{}:/usr/bin:/bin", bin.display()))
        .env("SHELL", "/bin/sh")
        .env("WF_HOME", dir.path().join("state"))
        .args(["readiness", "--force", "--json"])
        .output()
        .unwrap();
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
    let value: serde_json::Value = serde_json::from_slice(&output.stdout).unwrap();
    assert_eq!(value["result"]["ready"], true);
    assert_eq!(value["result"]["repaired"], true);
}
