use serde::Serialize;
use serde_json::Value;

/// The JSON contract every scriptable command speaks. Its shape does not change with the
/// command; only `result` does. A consumer can therefore branch on `ok` and `errors`
/// without knowing which subcommand produced the document.
#[derive(Debug, Serialize)]
pub struct Envelope {
    pub schema_version: u32,
    pub ok: bool,
    pub command: String,
    pub release_version: String,
    pub result: Value,
    pub warnings: Vec<Note>,
    pub errors: Vec<Note>,
}

/// A warning or an error, in the same shape, so a consumer can render both with one path.
#[derive(Debug, Serialize, Clone)]
pub struct Note {
    /// Stable, greppable class.
    pub code: String,
    pub message: String,
    /// The operator-facing Chinese sentence, when there is an action to take.
    #[serde(skip_serializing_if = "String::is_empty", default)]
    pub zh: String,
}

impl Note {
    pub fn new(code: impl Into<String>, message: impl Into<String>) -> Self {
        Self {
            code: code.into(),
            message: message.into(),
            zh: String::new(),
        }
    }
    pub fn with_zh(mut self, zh: impl Into<String>) -> Self {
        self.zh = zh.into();
        self
    }
}

impl Envelope {
    pub fn new(command: impl Into<String>) -> Self {
        Self {
            schema_version: 1,
            ok: true,
            command: command.into(),
            release_version: crate::VERSION.to_string(),
            result: Value::Object(Default::default()),
            warnings: Vec::new(),
            errors: Vec::new(),
        }
    }

    pub fn result(mut self, v: impl Serialize) -> Self {
        self.result = serde_json::to_value(v).unwrap_or(Value::Null);
        self
    }

    pub fn warn(mut self, n: Note) -> Self {
        self.warnings.push(n);
        self
    }

    pub fn error(mut self, n: Note) -> Self {
        self.ok = false;
        self.errors.push(n);
        self
    }

    /// Redacts on the way out. Anything that reached the envelope carrying a secret-shaped
    /// string leaves without it — the envelope is the last gate before stdout, and stdout
    /// on a SessionStart hook goes into a model's context.
    pub fn render(&self) -> String {
        let raw = serde_json::to_string_pretty(self).unwrap_or_else(|e| {
            format!("{{\"schema_version\":1,\"ok\":false,\"errors\":[{{\"code\":\"ENVELOPE\",\"message\":{:?}}}]}}", e.to_string())
        });
        crate::redact::redact(&raw)
    }
}
