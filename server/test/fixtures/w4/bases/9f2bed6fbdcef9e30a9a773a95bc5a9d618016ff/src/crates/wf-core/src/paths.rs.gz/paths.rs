use std::path::{Path, PathBuf};

/// Missing optional user files are empty; an unreadable file must never become an empty
/// input to a managed-object rewrite.
pub fn read_text_or_empty(path: &Path) -> crate::Result<String> {
    match std::fs::read_to_string(path) {
        Ok(text) => Ok(text),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(String::new()),
        Err(e) => Err(e.into()),
    }
}

/// A managed file may be replaced atomically, but replacing a user symlink would lose
/// its topology and cannot be undone by a byte backup.
pub fn refuse_symlink(path: &Path) -> crate::Result<()> {
    match std::fs::symlink_metadata(path) {
        Ok(meta) if meta.file_type().is_symlink() => Err(crate::Error::conflict(
            "MANAGED-SYMLINK",
            format!(
                "{} is a symlink; wf preserves it instead of replacing it",
                path.display()
            ),
        )),
        Ok(_) => Ok(()),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(error) => Err(error.into()),
    }
}

/// Is `path` the root of a mount — a filesystem mounted there, or a directory bind-mounted
/// there? A bind mount of a directory on the same filesystem has the same device as its
/// parent, so only the kernel can say; Linux answers it directly (`STATX_ATTR_MOUNT_ROOT`,
/// since 5.8), and a kernel that cannot answer is an error, never a "no".
#[cfg(target_os = "linux")]
pub fn mount_root(path: &Path) -> crate::Result<bool> {
    use std::os::unix::ffi::OsStrExt;
    let name = std::ffi::CString::new(path.as_os_str().as_bytes()).map_err(|_| {
        crate::Error::usage(
            "PATH-NUL",
            format!("{} contains a NUL byte", path.display()),
        )
    })?;
    // SAFETY: `name` is a valid NUL-terminated path and `found` is a writable statx buffer.
    let mut found: libc::statx = unsafe { std::mem::zeroed() };
    let rc = unsafe {
        libc::statx(
            libc::AT_FDCWD,
            name.as_ptr(),
            libc::AT_SYMLINK_NOFOLLOW,
            libc::STATX_BASIC_STATS,
            &mut found,
        )
    };
    if rc != 0 {
        return Err(std::io::Error::last_os_error().into());
    }
    let bit = libc::STATX_ATTR_MOUNT_ROOT as u64;
    if found.stx_attributes_mask & bit == 0 {
        return Err(crate::Error::unsupported(
            "MOUNT-UNKNOWN",
            format!(
                "this kernel does not say whether {} is a mount point",
                path.display()
            ),
        ));
    }
    Ok(found.stx_attributes & bit != 0)
}

/// Is `path` the root of a mount? Without Linux's attribute, a device that differs from the
/// parent's is the signal; macOS has no bind mounts for it to miss.
#[cfg(not(target_os = "linux"))]
pub fn mount_root(path: &Path) -> crate::Result<bool> {
    use std::os::unix::fs::MetadataExt;
    let here = std::fs::symlink_metadata(path)?;
    let Some(parent) = path.parent().filter(|p| !p.as_os_str().is_empty()) else {
        return Ok(true);
    };
    Ok(here.dev() != std::fs::metadata(parent)?.dev())
}

/// Every path `wf` reads or writes, resolved once.
///
/// `WF_HOME` overrides the lot — that is what makes an isolated test, a dev container and
/// a Docker fresh-install rehearsal possible without touching the operator's real machine.
/// When it is set, config, state and cache all live under it, so a test cannot leak into
/// `~/Library` by forgetting one of the three.
#[derive(Debug, Clone)]
pub struct Paths {
    pub home: PathBuf,
    pub config_dir: PathBuf,
    pub state_dir: PathBuf,
    pub cache_dir: PathBuf,
    pub bin_dir: PathBuf,
}

impl Paths {
    pub fn resolve() -> crate::Result<Self> {
        let home = std::env::var_os("HOME")
            .map(PathBuf::from)
            .ok_or_else(|| {
                crate::Error::usage("NO-HOME", "HOME is not set")
                    .with_zh("当前环境没有 HOME 变量，wf 不知道该把配置写到哪里。请在正常的用户登录环境下再运行一次。")
            })?;

        if let Some(root) = std::env::var_os("WF_HOME").map(PathBuf::from) {
            return Ok(Self {
                config_dir: root.join("config"),
                state_dir: root.join("state"),
                cache_dir: root.join("cache"),
                bin_dir: root.join("bin"),
                home,
            });
        }

        let (config_dir, state_dir, cache_dir) = if cfg!(target_os = "macos") {
            (
                home.join("Library/Application Support/wf"),
                home.join("Library/Application Support/wf/state"),
                home.join("Library/Caches/wf"),
            )
        } else {
            (
                xdg(&home, "XDG_CONFIG_HOME", ".config").join("wf"),
                xdg(&home, "XDG_STATE_HOME", ".local/state").join("wf"),
                xdg(&home, "XDG_CACHE_HOME", ".cache").join("wf"),
            )
        };

        Ok(Self {
            config_dir,
            state_dir,
            cache_dir,
            bin_dir: home.join(".local/bin"),
            home,
        })
    }

    pub fn config_file(&self) -> PathBuf {
        self.config_dir.join("config.toml")
    }
    pub fn db(&self) -> PathBuf {
        self.state_dir.join("state.sqlite3")
    }
    pub fn generations(&self) -> PathBuf {
        self.state_dir.join("generations")
    }
    pub fn generation(&self, version: &str) -> PathBuf {
        self.generations().join(version)
    }
    pub fn active_link(&self) -> PathBuf {
        self.state_dir.join("active")
    }
    pub fn backups(&self) -> PathBuf {
        self.state_dir.join("backups")
    }
    pub fn journal(&self) -> PathBuf {
        self.state_dir.join("journal.log")
    }
    pub fn lock_file(&self) -> PathBuf {
        self.state_dir.join("wf.lock")
    }
    pub fn staging(&self) -> PathBuf {
        // Same filesystem as the generations it becomes, so activation is a rename and
        // never a copy across devices.
        self.state_dir.join("staging")
    }
    pub fn binary(&self) -> PathBuf {
        self.bin_dir.join("wf")
    }

    /// Whether a shell would find the binary we just installed.
    ///
    /// Install writes `wf` into `bin_dir` and writes agent hooks that call it by absolute
    /// path, so the agents keep working either way. The person does not: they are told to
    /// run `wf doctor` next, and on a machine whose profile never added `~/.local/bin` that
    /// instruction fails with nothing to act on. Asking the question here lets the install
    /// say so while it still has their attention.
    pub fn bin_dir_on_path(&self, path_var: &str) -> bool {
        dir_on_path(&self.bin_dir, path_var)
    }

    pub fn ensure_dirs(&self) -> crate::Result<()> {
        for d in [
            &self.config_dir,
            &self.state_dir,
            &self.cache_dir,
            &self.bin_dir,
            &self.generations(),
            &self.backups(),
            &self.staging(),
        ] {
            std::fs::create_dir_all(d).map_err(|e| {
                crate::Error::from(e).with_zh(format!(
                    "无法创建目录 {}。请确认该位置可写，或设置 WF_HOME 指向一个你有写权限的目录。",
                    d.display()
                ))
            })?;
        }
        // The state directory holds ownership receipts and backups of the operator's own
        // files. Other users on a shared host have no business reading it.
        restrict(&self.state_dir)?;
        Ok(())
    }
}

fn xdg(home: &Path, var: &str, fallback: &str) -> PathBuf {
    match std::env::var_os(var) {
        Some(v) if !v.is_empty() => PathBuf::from(v),
        _ => home.join(fallback),
    }
}

#[cfg(unix)]
fn restrict(dir: &Path) -> crate::Result<()> {
    use std::os::unix::fs::PermissionsExt;
    let mut perms = std::fs::metadata(dir)?.permissions();
    perms.set_mode(0o700);
    std::fs::set_permissions(dir, perms)?;
    Ok(())
}

#[cfg(not(unix))]
fn restrict(_dir: &Path) -> crate::Result<()> {
    Ok(())
}

/// The release target triple this binary was built for. It is compiled in rather than
/// probed, so a binary can never claim to be a platform it is not.
pub fn target_triple() -> &'static str {
    if cfg!(all(target_os = "macos", target_arch = "aarch64")) {
        "aarch64-apple-darwin"
    } else if cfg!(all(target_os = "linux", target_arch = "x86_64")) {
        "x86_64-unknown-linux-gnu"
    } else if cfg!(all(target_os = "macos", target_arch = "x86_64")) {
        "x86_64-apple-darwin"
    } else if cfg!(all(target_os = "linux", target_arch = "aarch64")) {
        "aarch64-unknown-linux-gnu"
    } else {
        "unsupported"
    }
}

/// The two targets this release line promises (D-007). Anything else installs nothing.
pub const SUPPORTED_TARGETS: &[&str] = &["aarch64-apple-darwin", "x86_64-unknown-linux-gnu"];

pub fn platform_supported() -> bool {
    SUPPORTED_TARGETS.contains(&target_triple())
}

/// Is `dir` one of the entries in a PATH-shaped string?
///
/// Takes the variable rather than reading the environment so it is testable without
/// mutating global state, which no test can do safely while others run beside it.
/// Compares resolved paths as well as literal ones: `/home/me/.local/bin` and a PATH that
/// reached the same directory through a symlink are the same answer to the only question
/// being asked, which is whether typing `wf` will work.
pub fn dir_on_path(dir: &Path, path_var: &str) -> bool {
    let resolved = dir.canonicalize().ok();
    std::env::split_paths(path_var)
        .any(|entry| entry == dir || (resolved.is_some() && entry.canonicalize().ok() == resolved))
}

#[cfg(test)]
mod tests {
    /// Real mounts of this machine: `/` and `/proc` are mount roots, a directory inside a
    /// temporary directory is not.
    #[test]
    #[cfg(target_os = "linux")]
    fn a_mount_root_is_told_from_a_plain_directory() {
        assert!(super::mount_root(std::path::Path::new("/")).unwrap());
        assert!(super::mount_root(std::path::Path::new("/proc")).unwrap());
        let d = tempfile::tempdir().unwrap();
        std::fs::create_dir(d.path().join("plain")).unwrap();
        assert!(!super::mount_root(&d.path().join("plain")).unwrap());
    }

    #[test]
    fn a_bin_dir_that_is_on_path_is_recognised() {
        let d = tempfile::tempdir().unwrap();
        let dir = d.path().to_path_buf();
        let var = format!("/usr/bin:{}:/bin", dir.display());
        assert!(super::dir_on_path(&dir, &var));
    }

    #[test]
    fn a_bin_dir_that_is_absent_is_reported_absent() {
        let d = tempfile::tempdir().unwrap();
        assert!(!super::dir_on_path(d.path(), "/usr/bin:/bin"));
        assert!(!super::dir_on_path(d.path(), ""));
    }

    #[test]
    fn a_path_entry_reaching_the_same_directory_by_symlink_counts() {
        // The check exists to answer "will typing wf work", and it will.
        let d = tempfile::tempdir().unwrap();
        let real = d.path().join("real");
        std::fs::create_dir(&real).unwrap();
        let link = d.path().join("link");
        #[cfg(unix)]
        std::os::unix::fs::symlink(&real, &link).unwrap();
        assert!(super::dir_on_path(&real, &format!("{}", link.display())));
    }

    use super::*;

    #[test]
    fn wf_home_captures_every_directory() {
        let tmp = tempfile::tempdir().unwrap();
        // Set both, so the assertion is that WF_HOME wins rather than that HOME is unset.
        temp_env(
            &[
                ("WF_HOME", Some(tmp.path().to_str().unwrap())),
                ("HOME", Some("/nonexistent")),
            ],
            || {
                let p = Paths::resolve().unwrap();
                for d in [&p.config_dir, &p.state_dir, &p.cache_dir, &p.bin_dir] {
                    assert!(d.starts_with(tmp.path()), "{} escaped WF_HOME", d.display());
                }
            },
        );
    }

    fn temp_env(vars: &[(&str, Option<&str>)], f: impl FnOnce()) {
        let saved: Vec<_> = vars
            .iter()
            .map(|(k, _)| (*k, std::env::var_os(k)))
            .collect();
        for (k, v) in vars {
            match v {
                Some(v) => std::env::set_var(k, v),
                None => std::env::remove_var(k),
            }
        }
        f();
        for (k, v) in saved {
            match v {
                Some(v) => std::env::set_var(k, v),
                None => std::env::remove_var(k),
            }
        }
    }
}
