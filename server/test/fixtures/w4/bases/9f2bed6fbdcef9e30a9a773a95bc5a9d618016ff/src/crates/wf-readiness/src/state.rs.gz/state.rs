use crate::check::Finding;
use crate::requirements::Requirements;
use crate::resolve::Resolver;
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

/// The cached verdict, keyed by a fingerprint that is cheap to recompute.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct State {
    #[serde(default)]
    pub salt: String,
    pub fingerprint: String,
    pub at: String,
    pub findings: Vec<Finding>,
    pub versions: std::collections::BTreeMap<String, String>,
}

// Finding needs to survive a round trip through the cache.
impl<'de> Deserialize<'de> for Finding {
    fn deserialize<D: serde::Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        #[derive(Deserialize)]
        struct Raw {
            code: String,
            subject: String,
            severity: String,
            detail: String,
            #[serde(default)]
            fix: String,
            #[serde(default)]
            tier: Option<String>,
            #[serde(default)]
            zh: String,
        }
        let r = Raw::deserialize(d)?;
        Ok(Finding {
            code: r.code,
            subject: r.subject,
            severity: match r.severity.as_str() {
                "fail" => crate::check::Severity::Fail,
                "warn" => crate::check::Severity::Warn,
                _ => crate::check::Severity::Note,
            },
            detail: r.detail,
            fix: r.fix,
            tier: r.tier.and_then(|t| match t.as_str() {
                "reversible" => Some(crate::check::Tier::Reversible),
                "install" => Some(crate::check::Tier::Install),
                "manual" => Some(crate::check::Tier::Manual),
                _ => None,
            }),
            zh: r.zh,
        })
    }
}

pub fn path(root: &Path, cache_dir: Option<&Path>) -> PathBuf {
    let base = match cache_dir {
        Some(d) => d.to_path_buf(),
        None => wf_core::paths::Paths::resolve()
            .map(|p| p.cache_dir)
            .unwrap_or_else(|_| PathBuf::from("/tmp")),
    };
    // Keyed by the checkout, so two worktrees of the same repo do not share a verdict.
    let root = root.canonicalize().unwrap_or_else(|_| root.to_path_buf());
    let key = wf_core::hash::sha256_bytes(root.to_string_lossy().as_bytes());
    base.join("readiness").join(format!("{}.json", &key[..16]))
}

/// The fingerprint that decides whether to skip.
///
/// Stat and hash only, with one exception — no process is started to compute it, which is
/// what lets the fast path promise that an unchanged machine costs no spawns. Its inputs are
/// exactly the things that can change the answer: the requirement files, the session PATH,
/// where each tool currently resolves, the state of each required component in each agent,
/// and, when services are asked for, what Compose resolves their file to.
///
/// That last input is the exception. A compose file interpolates this process's environment
/// and the project's `.env`, so an unset required variable or a changed port changes the
/// verdict without changing a file; only Compose knows the result, so it is asked, once per
/// file. The resolved model can hold secret values and is salted like a credential.
pub fn fingerprint(
    root: &std::path::Path,
    req: &Requirements,
    resolver: &Resolver,
    salt: &str,
    components: &[Finding],
) -> String {
    let mut parts = vec![serde_json::to_string(req).expect("requirements serialize")];
    let files: std::collections::BTreeSet<&str> =
        req.services.iter().map(|s| s.from.as_str()).collect();
    for file in files {
        let resolved = match crate::compose::model("docker", root, file) {
            Ok(model) => model.to_string(),
            Err(why) => format!("unresolved:{why}"),
        };
        parts.push(format!(
            "compose:{file}:{}",
            wf_core::hash::sha256_bytes(format!("{salt}\0{resolved}").as_bytes())
        ));
    }
    parts.push(format!(
        "components:{}",
        serde_json::to_string(components).expect("findings serialize")
    ));
    for s in &req.sources {
        parts.push(format!("src:{}={}", s.path, s.hash));
    }
    parts.push(format!(
        "path:{}",
        std::env::var("PATH").unwrap_or_default()
    ));
    for t in &req.tools {
        let path = resolver.resolve_session(&t.id);
        parts.push(format!("tool:{}@{}={}", t.id, t.min, path));
        use std::os::unix::fs::MetadataExt;
        if let Ok(meta) = std::fs::metadata(path) {
            parts.push(format!(
                "stat:{}:{}:{}:{}:{}",
                t.id,
                meta.ino(),
                meta.len(),
                meta.mtime(),
                meta.mtime_nsec()
            ));
        }
    }
    for credential in &req.credentials {
        let value = crate::credentials::material(credential).unwrap_or_default();
        parts.push(format!(
            "credential:{}:{}",
            credential.id,
            wf_core::hash::sha256_bytes(format!("{salt}\0{value}").as_bytes())
        ));
    }
    let home = PathBuf::from(std::env::var_os("HOME").unwrap_or_default());
    let claude = std::env::var_os("CLAUDE_CONFIG_DIR")
        .map(PathBuf::from)
        .unwrap_or_else(|| home.join(".claude"));
    let gh = std::env::var_os("GH_CONFIG_DIR")
        .map(PathBuf::from)
        .unwrap_or_else(|| home.join(".config/gh"));
    for path in [
        claude.join("settings.json"),
        gh.join("hosts.yml"),
        home.join(".rustup/settings.toml"),
        home.join(".zprofile"),
        home.join(".zshrc"),
        home.join(".bash_profile"),
        home.join(".bashrc"),
    ] {
        let mut bytes = salt.as_bytes().to_vec();
        bytes.extend(std::fs::read(&path).unwrap_or_default());
        parts.push(format!(
            "config:{}:{}",
            path.display(),
            wf_core::hash::sha256_bytes(&bytes)
        ));
    }
    parts.sort();
    wf_core::hash::sha256_bytes(parts.join("\n").as_bytes())
}

pub fn load(p: &Path) -> Option<State> {
    serde_json::from_str(&std::fs::read_to_string(p).ok()?).ok()
}

pub fn save(p: &Path, s: &State) -> wf_core::Result<()> {
    use std::os::unix::fs::{DirBuilderExt, PermissionsExt};
    if let Some(parent) = p.parent() {
        std::fs::DirBuilder::new()
            .recursive(true)
            .mode(0o700)
            .create(parent)?;
        std::fs::set_permissions(parent, std::fs::Permissions::from_mode(0o700))?;
    }
    wf_core::atomic::write_file(p, serde_json::to_string(s)?.as_bytes())?;
    std::fs::set_permissions(p, std::fs::Permissions::from_mode(0o600))?;
    Ok(())
}

pub fn new_salt() -> wf_core::Result<String> {
    use std::io::Read;
    let mut bytes = [0; 32];
    std::fs::File::open("/dev/urandom")?.read_exact(&mut bytes)?;
    Ok(wf_core::hash::sha256_bytes(&bytes))
}

pub fn reusable(
    state: &State,
    fingerprint: &str,
    _req: &Requirements,
    ttl: std::time::Duration,
) -> bool {
    if state.salt.is_empty()
        || state.fingerprint != fingerprint
        || state
            .findings
            .iter()
            .any(|f| f.severity == crate::Severity::Fail)
    {
        return false;
    }
    {
        let Ok(at) =
            time::OffsetDateTime::parse(&state.at, &time::format_description::well_known::Rfc3339)
        else {
            return false;
        };
        let age = time::OffsetDateTime::now_utc().unix_timestamp() - at.unix_timestamp();
        if age < 0 || age as u64 >= ttl.as_secs() {
            return false;
        }
    }
    true
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tool_only_successes_expire_at_the_requested_ttl() {
        let state = State {
            salt: "s".into(),
            fingerprint: "same".into(),
            at: "2000-01-01T00:00:00Z".into(),
            findings: vec![],
            versions: Default::default(),
        };
        assert!(!reusable(
            &state,
            "same",
            &Requirements::default(),
            std::time::Duration::from_secs(60)
        ));
    }

    #[test]
    fn the_fingerprint_moves_when_a_source_file_does() {
        let r = Resolver::with_paths("/usr/bin", None, "/home/x");
        let mut req = Requirements::default();
        req.sources.push(crate::requirements::SourceFile {
            path: "a".into(),
            hash: "1".into(),
        });
        let root = std::path::Path::new("/");
        let before = fingerprint(root, &req, &r, "fixture", &[]);
        req.sources[0].hash = "2".into();
        assert_ne!(before, fingerprint(root, &req, &r, "fixture", &[]));
    }

    #[test]
    fn the_fingerprint_moves_when_a_component_does() {
        let r = Resolver::with_paths("/usr/bin", None, "/home/x");
        let req = Requirements::default();
        let component = |code: &str| Finding {
            code: code.into(),
            subject: "capso.mcp.linear (codex)".into(),
            severity: crate::check::Severity::Note,
            detail: String::new(),
            fix: String::new(),
            tier: None,
            zh: String::new(),
        };
        let root = std::path::Path::new("/");
        assert_ne!(
            fingerprint(root, &req, &r, "fixture", &[component("COMPONENT-OK")]),
            fingerprint(root, &req, &r, "fixture", &[component("COMPONENT-MISSING")])
        );
    }

    #[test]
    fn two_worktrees_do_not_share_a_verdict() {
        assert_ne!(
            path(Path::new("/a/repo"), None),
            path(Path::new("/b/repo"), None)
        );
    }
}
