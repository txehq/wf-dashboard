//! Documents: the team repository's `docs/` tree, kept current in one place on the machine.
//!
//! Documents belong to no agent, so only the machine target takes them.

use super::object::{Rendered, Shape};
use super::{files_under, ResourceHandler, ResourceItem, ResourceKind, ResourceMetadata};
use crate::{adapter::TeamAIAdapter, team_repo::TeamRepo};
use wf_core::Result;

pub struct DocsHandler;

impl ResourceHandler for DocsHandler {
    fn kind(&self) -> ResourceKind {
        ResourceKind::Doc
    }

    fn scan_registry(&self, repo: &TeamRepo) -> Result<Vec<ResourceItem>> {
        let Some(dir) = repo.resource_dir(ResourceKind::Doc)? else {
            return Ok(vec![]);
        };
        let mut out = Vec::new();
        for rel in files_under(&dir)? {
            if rel.split('/').any(|s| s.starts_with('.')) {
                continue;
            }
            let source = dir.join(&rel);
            out.push(ResourceItem {
                id: rel.clone(),
                name: rel,
                kind: ResourceKind::Doc,
                version: None,
                metadata: ResourceMetadata {
                    content_hash: wf_core::hash::sha256_file(&source)?,
                    ..Default::default()
                },
                source,
            });
        }
        Ok(out)
    }

    fn render(&self, item: &ResourceItem, agent: &dyn TeamAIAdapter) -> Result<Option<Rendered>> {
        let Some(dir) = agent.docs_dir() else {
            return Ok(None);
        };
        Ok(Some(Rendered::File {
            path: dir.join(&item.id),
            bytes: std::fs::read(&item.source)?,
        }))
    }

    fn shape(&self, agent: &dyn TeamAIAdapter) -> Option<Shape> {
        agent.docs_dir().map(|_| Shape::File)
    }

    fn stored_shape(&self, _agent: &dyn TeamAIAdapter) -> Option<Shape> {
        Some(Shape::File)
    }
}
