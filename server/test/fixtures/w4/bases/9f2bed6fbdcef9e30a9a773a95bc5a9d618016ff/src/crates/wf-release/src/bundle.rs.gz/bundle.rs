//! Building a release, and fetching one.
//!
//! `build` is the compiler: registry in, a lock and a bundle out, deterministically enough
//! that two runs on two platforms produce the same digests. `fetch` is the client: a
//! verified lock, a verified bundle, expanded into a generation directory that either
//! becomes active whole or does not exist.

use crate::archive::{self, Limits};
use crate::github::Gh;
use crate::lock::{BinaryRef, BundleRef, Compatibility, ComponentRef, CtxUpstream, Lock};
use crate::render;
use crate::source::{Assets, Channel, ReleaseRef, ReleaseSource};
use std::path::{Path, PathBuf};
use std::time::Duration;
use wf_core::{Error, Result};
use wf_registry::Registry;

/// The version floors this release was actually tested against. They are constants here and
/// measured by the acceptance run, not remembered — when a probe raises one, this is the
/// single place it changes and the lock carries it to every machine.
pub const CLAUDE_FLOOR: &str = ">=2.0.0";
pub const CODEX_FLOOR: &str = ">=0.30.0";

pub struct BuildOptions<'a> {
    pub root: &'a Path,
    pub out: &'a Path,
    pub version: &'a str,
    pub source_commit: String,
    /// Binaries to reference in the lock. Empty during a local build — a lock with no
    /// binary row installs the bundle and keeps the `wf` already on the machine.
    pub binaries: Vec<(String, PathBuf)>,
    /// The ctx release to pin, already resolved. `None` pins nothing, which keeps the ctx
    /// already on a machine — the same bargain a lock with no binary row makes for `wf`.
    pub ctx: Option<CtxUpstream>,
}

/// Compile the registry into a lock and a bundle.
pub fn build(opts: &BuildOptions<'_>) -> Result<(Lock, PathBuf, PathBuf)> {
    let reg = Registry::load(opts.root)?;
    let violations = wf_registry::validate(&reg, Some(opts.root));
    if !violations.is_empty() {
        return Err(Error::usage(
            "REGISTRY-INVALID",
            violations
                .iter()
                .map(|v| v.to_string())
                .collect::<Vec<_>>()
                .join("; "),
        )
        .with_zh(
            "workflow/registry.yaml 还有问题没解决，先运行 `wf guard` 看看具体是哪一条。"
                .to_string(),
        ));
    }

    // Stage the bundle tree on disk so its digest is computed over real files with real
    // modes — the same way the installed side will compute it after extraction.
    std::fs::create_dir_all(opts.out)?;
    let stage = opts.out.join(".stage");
    let _ = std::fs::remove_dir_all(&stage);
    let tree = render::bundle_tree(&reg, opts.root, opts.version)?;
    for (rel, bytes) in &tree {
        let p = archive::join_checked(&stage, rel)?;
        if let Some(parent) = p.parent() {
            std::fs::create_dir_all(parent)?;
        }
        std::fs::write(&p, bytes)?;
    }
    let tree_sha = wf_core::hash::tree_digest(&stage)?;

    let bundle_name = Assets::bundle(opts.version);
    let bundle_path = opts.out.join(&bundle_name);
    let (file_count, expanded_size) = archive::build_tar_gz(&stage, &bundle_path)?;
    let bundle_sha = wf_core::hash::sha256_file(&bundle_path)?;
    std::fs::remove_dir_all(&stage)?;

    let mut components = Vec::new();
    for c in &reg.components {
        let tree_sha256 = match c.source.as_deref() {
            Some(src) => {
                let p = opts.root.join(src);
                if p.is_dir() {
                    // The same exclusion the bundle applies. Hashing the directory as it
                    // sits would make the lock depend on whether anybody had run a skill's
                    // tests, while the archive beside it would not change.
                    let entries: Vec<_> = wf_core::hash::tree_entries(&p)?
                        .into_iter()
                        .filter(|e| !render::is_build_artifact(&e.path))
                        .collect();
                    wf_core::hash::digest_entries(&entries)
                } else {
                    wf_core::hash::sha256_file(&p)?
                }
            }
            None => String::new(),
        };
        components.push(ComponentRef {
            id: c.id.clone(),
            kind: c.kind.as_str().to_string(),
            tree_sha256,
            required: c.required,
            targets: render::targets_of(c)
                .iter()
                .map(|s| s.to_string())
                .collect(),
        });
    }

    let mut binaries = Vec::new();
    let mut targets = std::collections::HashSet::new();
    for (target, path) in &opts.binaries {
        if !wf_core::paths::SUPPORTED_TARGETS.contains(&target.as_str())
            || !targets.insert(target.as_str())
        {
            return Err(Error::usage(
                "BINARY-TARGET",
                format!("unsupported or duplicate binary target {target}"),
            ));
        }
        let asset = Assets::binary(opts.version, target);
        let destination = opts.out.join(&asset);
        if path != &destination {
            std::fs::copy(path, &destination)?;
        }
        binaries.push(BinaryRef {
            target: target.clone(),
            asset,
            sha256: wf_core::hash::sha256_file(&destination)?,
        });
    }

    let lock = Lock {
        schema_version: 1,
        release_version: opts.version.to_string(),
        source_commit: opts.source_commit.clone(),
        created_at: wf_core::time_fmt::now_rfc3339(),
        bundle: BundleRef {
            asset: bundle_name,
            sha256: bundle_sha,
            expanded_size,
            file_count,
            tree_sha256: tree_sha,
        },
        binaries,
        components,
        compatibility: Compatibility {
            wf: format!("={}", opts.version),
            claude_code: CLAUDE_FLOOR.to_string(),
            codex: CODEX_FLOOR.to_string(),
            platforms: wf_core::paths::SUPPORTED_TARGETS
                .iter()
                .map(|s| s.to_string())
                .collect(),
        },
        ctx_upstream: opts.ctx.clone().unwrap_or_else(CtxUpstream::none),
    };

    let lock_path = opts.out.join(Assets::LOCK);
    wf_core::atomic::write_file(&lock_path, lock.render().as_bytes())?;
    Ok((lock, lock_path, bundle_path))
}

/// Resolve which release a machine should be running, without downloading it.
///
/// This is the only network call a session start is allowed to make, and it runs under the
/// caller's deadline. It returns `None` on any reachable-but-empty answer so the caller can
/// keep the last known good generation rather than treat "no release yet" as a failure.
pub fn resolve(
    source: &ReleaseSource,
    channel: Channel,
    timeout: Duration,
) -> Result<Option<ReleaseRef>> {
    match source {
        ReleaseSource::Local { dir } => {
            let (r, _) = crate::source::resolve_local(dir)?;
            Ok(Some(r))
        }
        ReleaseSource::GitHub { repo, branch } => {
            let gh = Gh::new(repo.clone()).with_timeout(timeout);
            let Some(rel) = gh.latest(channel)? else {
                return Ok(None);
            };
            if channel == Channel::Stable && rel.prerelease {
                return Ok(None);
            }
            let version = rel.tag_name.trim_start_matches('v').to_string();
            Ok(Some(ReleaseRef {
                tag: rel.tag_name,
                version,
                channel,
                attested: rel.immutable,
                source: ReleaseSource::GitHub {
                    repo: repo.clone(),
                    branch: branch.clone(),
                },
            }))
        }
    }
}

/// What a fetch produced: a verified lock, and a directory holding the expanded bundle.
#[derive(Debug)]
pub struct Fetched {
    pub lock: Lock,
    pub bundle_dir: PathBuf,
    /// The downloaded binary for this platform, when the release carries one.
    pub binary: Option<PathBuf>,
    pub attested: bool,
    /// Reasons this release is trusted less than a fully attested one. Empty is the
    /// production case; a local build always has at least one.
    pub caveats: Vec<String>,
}

/// Download, verify and expand a release into `work`.
///
/// Order matters and is not negotiable: the release is verified before an asset is trusted,
/// the lock is verified before the bundle is trusted, and the bundle's digest is checked
/// before a single byte of it is extracted. Nothing downloaded is ever executed before its
/// digest matches the lock.
pub fn fetch(rel: &ReleaseRef, work: &Path, timeout: Duration) -> Result<Fetched> {
    std::fs::create_dir_all(work)?;
    restrict(work)?;
    let mut caveats = Vec::new();

    let (lock, bundle_path, binary) = match &rel.source {
        ReleaseSource::Local { dir } => {
            caveats.push(
                "installed from a local build; GitHub release attestation was not available".into(),
            );
            let lock = Lock::parse(&std::fs::read_to_string(dir.join(Assets::LOCK))?)?;
            let bundle = dir.join(&lock.bundle.asset);
            let binary = lock
                .binary_for(wf_core::paths::target_triple())
                .map(|b| -> Result<PathBuf> {
                    let path = dir.join(&b.asset);
                    let got = wf_core::hash::sha256_file(&path)
                        .map_err(|e| Error::integrity("BINARY-MISSING", e.message))?;
                    if got != b.sha256 {
                        return Err(Error::integrity(
                            "BINARY-DIGEST-MISMATCH",
                            format!("{} does not match its lock", b.asset),
                        ));
                    }
                    Ok(path)
                })
                .transpose()?;
            (lock, bundle, binary)
        }
        ReleaseSource::GitHub { repo, .. } => {
            let gh = Gh::new(repo.clone()).with_timeout(timeout);

            // 1. The release itself. An unverifiable release is a stop, not a warning.
            gh.verify_release(&rel.tag)?;
            if !rel.attested {
                return Err(Error::integrity(
                    "RELEASE-MUTABLE",
                    format!("{} is not an immutable release", rel.tag),
                )
                .with_zh("这个版本还没有被锁定，不能安装。请让发版的人重新发一次。".to_string()));
            }

            // 2. The lock, verified as an asset, then parsed.
            let lock_path = gh.download(&rel.tag, Assets::LOCK, work)?;
            gh.verify_asset(&rel.tag, &lock_path)?;
            let lock = Lock::parse(&std::fs::read_to_string(&lock_path)?)?;

            if lock.release_version != rel.version {
                return Err(Error::integrity(
                    "LOCK-VERSION-MISMATCH",
                    format!(
                        "tag {} carries a lock for {}",
                        rel.tag, lock.release_version
                    ),
                )
                .with_zh(wf_core::zh::integrity_failed()));
            }
            // 3. The tag points at the tree the lock says it was built from.
            let sha = gh.tag_commit(&rel.tag)?;
            if sha != lock.source_commit {
                return Err(Error::integrity(
                    "LOCK-COMMIT-MISMATCH",
                    format!("tag {} is {sha}, lock says {}", rel.tag, lock.source_commit),
                )
                .with_zh(wf_core::zh::integrity_failed()));
            }

            // 4. The API's own digest for each asset, checked against the lock before the
            //    bytes are used. Two independent statements have to agree.
            let api = gh.release(&rel.tag)?;
            let bundle_path = gh.download(&rel.tag, &lock.bundle.asset, work)?;
            gh.verify_asset(&rel.tag, &bundle_path)?;
            check_digest(&api, &lock.bundle.asset, &lock.bundle.sha256)?;
            let got = wf_core::hash::sha256_file(&bundle_path)?;
            if got != lock.bundle.sha256 {
                return Err(Error::integrity(
                    "BUNDLE-DIGEST-MISMATCH",
                    format!(
                        "{}: expected {}, got {got}",
                        lock.bundle.asset, lock.bundle.sha256
                    ),
                )
                .with_zh(wf_core::zh::integrity_failed()));
            }

            let binary = match lock.binary_for(wf_core::paths::target_triple()) {
                Some(b) => {
                    let p = gh.download(&rel.tag, &b.asset, work)?;
                    gh.verify_asset(&rel.tag, &p)?;
                    check_digest(&api, &b.asset, &b.sha256)?;
                    let got = wf_core::hash::sha256_file(&p)?;
                    if got != b.sha256 {
                        return Err(Error::integrity(
                            "BINARY-DIGEST-MISMATCH",
                            format!("{}: expected {}, got {got}", b.asset, b.sha256),
                        )
                        .with_zh(wf_core::zh::integrity_failed()));
                    }
                    Some(p)
                }
                None => {
                    if !lock.supports_platform(wf_core::paths::target_triple()) {
                        return Err(Error::unsupported(
                            "PLATFORM-UNSUPPORTED",
                            format!("{} is not in this release", wf_core::paths::target_triple()),
                        )
                        .with_zh(wf_core::zh::unsupported_platform(
                            wf_core::paths::target_triple(),
                        )));
                    }
                    None
                }
            };
            (lock, bundle_path, binary)
        }
    };

    // The local path verifies the same digest; what it cannot do is prove the release was
    // immutable, and the caveat above says so.
    let got = wf_core::hash::sha256_file(&bundle_path)?;
    if got != lock.bundle.sha256 {
        return Err(Error::integrity(
            "BUNDLE-DIGEST-MISMATCH",
            format!(
                "{}: expected {}, got {got}",
                lock.bundle.asset, lock.bundle.sha256
            ),
        )
        .with_zh(wf_core::zh::integrity_failed()));
    }

    // 5. Expand, under the ceilings the lock declares.
    let bundle_dir = work.join("bundle");
    let _ = std::fs::remove_dir_all(&bundle_dir);
    let limits = Limits {
        max_files: lock.bundle.file_count.max(1) + 16,
        max_file_bytes: 64 * 1024 * 1024,
        max_total_bytes: lock.bundle.expanded_size.max(1024) * 2 + 1024 * 1024,
    };
    archive::extract_tar_gz(&bundle_path, &bundle_dir, limits)?;

    // 6. The expanded tree is what the lock says it is. The archive digest proved the
    //    container; this proves the contents.
    let tree = wf_core::hash::tree_digest(&bundle_dir)?;
    if tree != lock.bundle.tree_sha256 {
        let _ = std::fs::remove_dir_all(&bundle_dir);
        return Err(Error::integrity(
            "BUNDLE-TREE-MISMATCH",
            format!(
                "expanded tree {tree} does not match lock {}",
                lock.bundle.tree_sha256
            ),
        )
        .with_zh(wf_core::zh::integrity_failed()));
    }

    Ok(Fetched {
        lock,
        bundle_dir,
        binary,
        attested: !rel.source.is_local(),
        caveats,
    })
}

pub(crate) fn check_digest(api: &crate::github::ApiRelease, asset: &str, want: &str) -> Result<()> {
    let Some(a) = api.assets.iter().find(|a| a.name == asset) else {
        return Err(Error::integrity(
            "ASSET-UNKNOWN",
            format!("{asset} is not in the release"),
        ));
    };
    match a.sha256() {
        Some(d) if d == want => Ok(()),
        Some(d) => Err(Error::integrity(
            "ASSET-DIGEST-MISMATCH",
            format!("{asset}: GitHub says {d}, lock says {want}"),
        )
        .with_zh(wf_core::zh::integrity_failed())),
        // No digest at all is not a pass. It means we have one statement where the design
        // requires two.
        None => Err(Error::integrity(
            "ASSET-NO-DIGEST",
            format!("{asset}: GitHub reports no sha256 digest"),
        )
        .with_zh(wf_core::zh::integrity_failed())),
    }
}

/// Verify all platform assets without executing foreign-platform binaries. Publication
/// requires the complete target matrix; local bundle-only development builds may omit it.
pub fn verify_local(dir: &Path, require_binaries: bool) -> Result<Lock> {
    let (release, lock) = crate::source::resolve_local(dir)?;
    let mut targets = std::collections::HashSet::new();
    for binary in &lock.binaries {
        if !targets.insert(binary.target.as_str()) {
            return Err(Error::integrity("BINARY-TARGET", "duplicate binary target"));
        }
        let path = dir.join(&binary.asset);
        let got = wf_core::hash::sha256_file(&path)
            .map_err(|e| Error::integrity("BINARY-MISSING", e.message))?;
        if got != binary.sha256 {
            return Err(Error::integrity("BINARY-DIGEST-MISMATCH", &binary.asset));
        }
        let staging = tempfile::tempdir()?;
        archive::extract_tar_gz(
            &path,
            &staging.path().join("binary"),
            Limits {
                max_files: 4,
                max_file_bytes: 128 * 1024 * 1024,
                max_total_bytes: 256 * 1024 * 1024,
            },
        )?;
        if !staging.path().join("binary/wf").is_file() {
            return Err(Error::integrity("BINARY-SHAPE", &binary.asset));
        }
    }
    if require_binaries
        && wf_core::paths::SUPPORTED_TARGETS
            .iter()
            .any(|target| !targets.contains(target))
    {
        return Err(Error::integrity(
            "BINARY-MISSING",
            "release must include every supported platform binary",
        ));
    }
    let staging = tempfile::tempdir()?;
    fetch(&release, staging.path(), Duration::from_secs(1))?;
    Ok(lock)
}

#[cfg(unix)]
fn restrict(d: &Path) -> Result<()> {
    use std::os::unix::fs::PermissionsExt;
    std::fs::set_permissions(d, std::fs::Permissions::from_mode(0o700))?;
    Ok(())
}
#[cfg(not(unix))]
fn restrict(_d: &Path) -> Result<()> {
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_missing_or_tampered_declared_local_binary_is_refused() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
        let dir = tempfile::tempdir().unwrap();
        let binary = dir.path().join("binary.tar.gz");
        std::fs::write(&binary, b"original binary archive").unwrap();
        let (lock, _, _) = build(&BuildOptions {
            root: &root,
            out: dir.path(),
            version: wf_core::VERSION,
            source_commit: String::new(),
            binaries: vec![(wf_core::paths::target_triple().into(), binary.clone())],
            ctx: None,
        })
        .unwrap();
        let expected = dir.path().join(&lock.binaries[0].asset);
        if binary != expected {
            std::fs::copy(&binary, &expected).unwrap();
        }
        for tamper in [false, true] {
            if tamper {
                std::fs::write(&expected, b"tampered binary").unwrap();
            } else {
                std::fs::remove_file(&expected).unwrap();
            }
            let (release, _) = crate::source::resolve_local(dir.path()).unwrap();
            let work = tempfile::tempdir().unwrap();
            assert!(
                fetch(&release, work.path(), Duration::from_secs(1)).is_err(),
                "tamper={tamper}"
            );
            assert!(!work.path().join("bundle").exists());
        }
    }

    fn repo_root() -> PathBuf {
        Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../..")
            .canonicalize()
            .unwrap()
    }

    fn build_local(out: &Path, version: &str) -> Lock {
        let (lock, _, _) = build(&BuildOptions {
            root: &repo_root(),
            out,
            version,
            source_commit: "0".repeat(40),
            binaries: vec![],
            ctx: None,
        })
        .unwrap();
        lock
    }

    #[test]
    fn a_build_is_reproducible() {
        let a = tempfile::tempdir().unwrap();
        let b = tempfile::tempdir().unwrap();
        let la = build_local(a.path(), "1.0.0");
        let lb = build_local(b.path(), "1.0.0");
        assert_eq!(
            la.bundle.sha256, lb.bundle.sha256,
            "two builds of one tree must be identical"
        );
        assert_eq!(la.bundle.tree_sha256, lb.bundle.tree_sha256);
        assert_eq!(
            la.components, lb.components,
            "every component digest, not only the bundle's"
        );
        assert_eq!(
            std::fs::read(a.path().join(&la.bundle.asset)).unwrap(),
            std::fs::read(b.path().join(&lb.bundle.asset)).unwrap()
        );
    }

    /// A `__pycache__` a test run left beside a skill is not in the bundle, so it must not
    /// move that skill's digest in the lock either.
    #[test]
    fn a_build_artifact_beside_a_skill_changes_no_digest() {
        let d = tempfile::tempdir().unwrap();
        let before = build_local(d.path(), "1.0.0");
        let cache = repo_root().join("skills/review-pr/scripts/__pycache__");
        std::fs::create_dir_all(&cache).unwrap();
        std::fs::write(cache.join("review_monitor.cpython-313.pyc"), b"stale").unwrap();
        let after = build_local(tempfile::tempdir().unwrap().path(), "1.0.0");
        std::fs::remove_dir_all(&cache).unwrap();
        assert_eq!(before.components, after.components);
        assert_eq!(before.bundle.tree_sha256, after.bundle.tree_sha256);
    }

    #[test]
    fn the_lock_covers_every_registered_component() {
        let d = tempfile::tempdir().unwrap();
        let lock = build_local(d.path(), "1.0.0");
        let reg = Registry::load(&repo_root()).unwrap();
        assert_eq!(lock.components.len(), reg.components.len());
        for c in &reg.components {
            assert!(
                lock.components.iter().any(|x| x.id == c.id),
                "{} missing from the lock",
                c.id
            );
        }
    }

    #[test]
    fn a_local_release_round_trips_through_fetch() {
        let dist = tempfile::tempdir().unwrap();
        let lock = build_local(dist.path(), "1.0.0");
        let work = tempfile::tempdir().unwrap();
        let (rel, _) = crate::source::resolve_local(dist.path()).unwrap();
        let got = fetch(&rel, work.path(), Duration::from_secs(10)).unwrap();
        assert_eq!(got.lock.bundle.tree_sha256, lock.bundle.tree_sha256);
        assert!(got.bundle_dir.join("workflow/registry.yaml").is_file());
        assert!(got.bundle_dir.join("skills/lfg/SKILL.md").is_file());
        assert!(got.bundle_dir.join("workflow/teamai/agents.yaml").is_file());
        assert!(
            !got.caveats.is_empty(),
            "a local install must say it is not attested"
        );
    }

    #[test]
    fn a_tampered_bundle_is_refused_and_nothing_is_expanded() {
        let dist = tempfile::tempdir().unwrap();
        let lock = build_local(dist.path(), "1.0.0");
        // Flip a byte in the archive after the lock was written.
        let p = dist.path().join(&lock.bundle.asset);
        let mut bytes = std::fs::read(&p).unwrap();
        let n = bytes.len();
        bytes[n / 2] ^= 0xff;
        std::fs::write(&p, &bytes).unwrap();

        let work = tempfile::tempdir().unwrap();
        let (rel, _) = crate::source::resolve_local(dist.path()).unwrap();
        let err = fetch(&rel, work.path(), Duration::from_secs(10)).unwrap_err();
        assert_eq!(err.code, wf_core::ExitCode::Integrity);
        assert!(
            !work.path().join("bundle").exists(),
            "nothing may be expanded from a bad bundle"
        );
    }

    #[test]
    fn a_lock_that_disagrees_with_its_bundle_is_refused() {
        let dist = tempfile::tempdir().unwrap();
        let mut lock = build_local(dist.path(), "1.0.0");
        lock.bundle.tree_sha256 = "f".repeat(64);
        std::fs::write(dist.path().join(Assets::LOCK), lock.render()).unwrap();
        let work = tempfile::tempdir().unwrap();
        let (rel, _) = crate::source::resolve_local(dist.path()).unwrap();
        let err = fetch(&rel, work.path(), Duration::from_secs(10)).unwrap_err();
        assert_eq!(err.kind, "BUNDLE-TREE-MISMATCH");
        assert!(!work.path().join("bundle").exists());
    }
}
