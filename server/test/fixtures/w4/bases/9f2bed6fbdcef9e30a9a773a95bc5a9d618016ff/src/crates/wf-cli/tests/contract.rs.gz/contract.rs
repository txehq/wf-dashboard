//! The CLI's own contract tests: the surface a script or a skill can depend on.

use clap::CommandFactory;

/// The guard checks that a skill only names subcommands that exist, against a list it
/// holds itself — it cannot import the CLI, because the CLI imports it. This is the fence
/// that keeps the two from drifting: add a subcommand without adding it to the guard's
/// list, and this fails.
#[test]
fn the_guards_subcommand_list_matches_the_real_cli() {
    let cmd = wf_cli_flags::Cli::command();
    let mut actual: Vec<String> = cmd
        .get_subcommands()
        .map(|s| s.get_name().to_string())
        .collect();
    actual.sort();
    let mut known: Vec<String> = wf_guard::WF_SUBCOMMANDS
        .iter()
        .map(|s| s.to_string())
        .collect();
    known.sort();
    assert_eq!(
        actual, known,
        "wf-guard::WF_SUBCOMMANDS is out of date; CMD002 would miss a typo in a skill"
    );
}

/// Exit codes are part of the contract: scripts branch on them.
#[test]
fn exit_codes_are_stable() {
    use wf_core::ExitCode;
    assert_eq!(ExitCode::Ok.as_i32(), 0);
    assert_eq!(ExitCode::Failure.as_i32(), 1);
    assert_eq!(ExitCode::Usage.as_i32(), 2);
    assert_eq!(ExitCode::Unsupported.as_i32(), 3);
    assert_eq!(ExitCode::Integrity.as_i32(), 4);
    assert_eq!(ExitCode::Conflict.as_i32(), 5);
}

/// Every remote-touching command takes `--repo` and `--branch`, so a rehearsal against a
/// fork never means editing an installed configuration.
#[test]
fn every_remote_command_can_be_pointed_somewhere_else() {
    let cmd = wf_cli_flags::Cli::command();
    for name in ["install", "sync", "status", "doctor", "repair", "rollback"] {
        let sub = cmd
            .find_subcommand(name)
            .unwrap_or_else(|| panic!("{name} is missing"));
        let ids: Vec<&str> = sub.get_arguments().map(|a| a.get_id().as_str()).collect();
        assert!(
            ids.contains(&"repo"),
            "{name} cannot be pointed at another repository"
        );
        assert!(
            ids.contains(&"branch"),
            "{name} cannot be pointed at another branch"
        );
    }
}

/// The commands that change a machine can all be rehearsed first.
///
/// Nested subcommands are walked too. Checking only the top level said nothing at all about
/// `wf mcp skip`, which writes a decision that then governs every later run — exactly the
/// kind of command somebody wants to rehearse.
#[test]
fn every_mutating_command_has_a_dry_run() {
    let cmd = wf_cli_flags::Cli::command();
    let path = |names: &[&str]| -> Vec<String> { names.iter().map(|s| s.to_string()).collect() };
    let mutating: Vec<Vec<String>> = vec![
        path(&["install"]),
        path(&["sync"]),
        path(&["repair"]),
        path(&["rollback"]),
        path(&["uninstall"]),
        path(&["mcp", "skip"]),
        path(&["mcp", "unskip"]),
        path(&["agents", "unregister"]),
    ];
    for names in mutating {
        let mut sub = &cmd;
        let mut walked = Vec::new();
        for name in &names {
            sub = sub
                .find_subcommand(name)
                .unwrap_or_else(|| panic!("no such command: wf {}", names.join(" ")));
            walked.push(name.as_str());
        }
        let ids: Vec<&str> = sub.get_arguments().map(|a| a.get_id().as_str()).collect();
        assert!(
            ids.contains(&"dry_run"),
            "wf {} has no --dry-run; it cannot be rehearsed",
            walked.join(" ")
        );
    }
}

/// clap's own validation, which catches an ambiguous or duplicated flag at test time rather
/// than at a user.
#[test]
fn the_command_tree_is_well_formed() {
    wf_cli_flags::Cli::command().debug_assert();
}
