use serde::{Deserialize, Serialize};

/// `workflow.lock.json` — the release's own description of itself.
///
/// The lock does not contain its own hash, and that is deliberate rather than an omission:
/// a self-describing digest proves nothing, because whoever changed the file could change
/// the digest too. Its trust comes from outside — the immutable GitHub Release asset
/// metadata — and once the lock is trusted it becomes the authority for everything inside
/// the bundle. Two layers: the release vouches for the lock, the lock vouches for the files.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Lock {
    pub schema_version: u32,
    pub release_version: String,
    pub source_commit: String,
    pub created_at: String,
    pub bundle: BundleRef,
    pub binaries: Vec<BinaryRef>,
    pub components: Vec<ComponentRef>,
    pub compatibility: Compatibility,
    pub ctx_upstream: CtxUpstream,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct BundleRef {
    pub asset: String,
    pub sha256: String,
    /// The expanded-size ceiling an extractor refuses to exceed. A bundle that claims 4 MB
    /// and expands to 40 GB is a zip bomb, and the only place to notice is here.
    pub expanded_size: u64,
    pub file_count: u64,
    /// The tree digest of the expanded bundle. Recomputed after extraction; a mismatch
    /// means the archive and the lock disagree about what was shipped.
    pub tree_sha256: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct BinaryRef {
    pub target: String,
    pub asset: String,
    pub sha256: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ComponentRef {
    pub id: String,
    pub kind: String,
    /// Empty for components with no source tree (a hook dispatcher is an argv).
    #[serde(default)]
    pub tree_sha256: String,
    pub required: bool,
    pub targets: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Compatibility {
    pub wf: String,
    /// Version floors are measured, not remembered. They are written by the release that
    /// last ran the capability probes against a real agent.
    pub claude_code: String,
    pub codex: String,
    pub platforms: Vec<String>,
}

/// The ctx release this wf release installs, and the exact bytes each platform may run.
///
/// Resolved from upstream's latest release when the release is built (ADR-0006), so "latest"
/// still means one set of bytes per wf version and a rollback names one ctx.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct CtxUpstream {
    pub version: String,
    pub commit: String,
    pub license: String,
    /// One pinned upstream asset per supported target. Empty in a local build, which leaves
    /// the ctx on a machine alone. Defaulted because a lock written before ctx was installed
    /// has no such field, and a rollback to one must still parse.
    #[serde(default)]
    pub binaries: Vec<BinaryRef>,
    /// The CPU ONNX Runtime sidecar from the same upstream release, one archive per target.
    /// ctx's semantic search loads it and never installs it into an unmanaged installation
    /// (upstream `docs/unmanaged-installs.md`), so wf does. Defaulted for the same reason as
    /// `binaries`: a lock from before it was pinned still parses, and pins no runtime.
    #[serde(default)]
    pub runtimes: Vec<BinaryRef>,
}

impl CtxUpstream {
    /// No pin at all: what a local build and a build-lock preview carry.
    pub fn none() -> Self {
        Self {
            version: String::new(),
            commit: String::new(),
            license: "Apache-2.0".into(),
            binaries: vec![],
            runtimes: vec![],
        }
    }

    pub fn binary_for(&self, target: &str) -> Option<&BinaryRef> {
        self.binaries.iter().find(|b| b.target == target)
    }

    pub fn runtime_for(&self, target: &str) -> Option<&BinaryRef> {
        self.runtimes.iter().find(|b| b.target == target)
    }
}

impl Lock {
    pub fn parse(json: &str) -> wf_core::Result<Self> {
        let lock: Lock = serde_json::from_str(json).map_err(|e| {
            wf_core::Error::integrity("LOCK-PARSE", format!("workflow.lock.json: {e}"))
                .with_zh(wf_core::zh::integrity_failed())
        })?;
        if lock.schema_version != 1 {
            return Err(wf_core::Error::unsupported(
                "LOCK-SCHEMA",
                format!(
                    "lock schema_version {} is newer than this build",
                    lock.schema_version
                ),
            )
            .with_zh("这个版本比当前的 wf 新。请先升级 wf 再安装。"));
        }
        Ok(lock)
    }

    pub fn render(&self) -> String {
        // Pretty and stable: the lock is read by humans during an incident, and diffed
        // byte-for-byte by CI to prove the build is deterministic.
        let mut s = serde_json::to_string_pretty(self).expect("lock serialises");
        s.push('\n');
        s
    }

    pub fn binary_for(&self, target: &str) -> Option<&BinaryRef> {
        self.binaries.iter().find(|b| b.target == target)
    }

    /// Does this release ship anything this machine can run?
    pub fn supports_platform(&self, target: &str) -> bool {
        self.compatibility.platforms.iter().any(|p| p == target)
    }

    /// Compare an agent's reported version against the floor this release was tested at.
    /// Absent or unparseable floors do not block: a floor nobody measured must not become
    /// a wall nobody can climb.
    pub fn agent_supported(&self, agent: wf_registry::Agent, version: Option<&str>) -> bool {
        let floor = match agent {
            wf_registry::Agent::ClaudeCode => &self.compatibility.claude_code,
            wf_registry::Agent::Codex => &self.compatibility.codex,
        };
        let Some(floor) = floor.strip_prefix(">=") else {
            return true;
        };
        let (Some(have), Some(want)) = (version.and_then(semver_triple), semver_triple(floor))
        else {
            return true;
        };
        have >= want
    }
}

/// Parse the leading `major.minor.patch` of a version string, ignoring any prefix such as
/// `v` and any suffix such as `-rc.1` or ` (Claude Code)`.
pub fn semver_triple(s: &str) -> Option<(u64, u64, u64)> {
    let s = s.trim().trim_start_matches('v');
    let head: String = s
        .chars()
        .take_while(|c| c.is_ascii_digit() || *c == '.')
        .collect();
    let mut it = head.split('.').filter(|p| !p.is_empty());
    let a = it.next()?.parse().ok()?;
    let b = it.next().and_then(|x| x.parse().ok()).unwrap_or(0);
    let c = it.next().and_then(|x| x.parse().ok()).unwrap_or(0);
    Some((a, b, c))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn version_floors_ignore_prefixes_and_suffixes() {
        assert_eq!(semver_triple("v1.2.3-rc.1"), Some((1, 2, 3)));
        assert_eq!(semver_triple("2.0.14 (Claude Code)"), Some((2, 0, 14)));
        assert_eq!(semver_triple("0.9"), Some((0, 9, 0)));
        assert_eq!(semver_triple("not-a-version"), None);
    }

    fn lock_with(claude: &str) -> Lock {
        Lock {
            schema_version: 1,
            release_version: "1.0.0".into(),
            source_commit: "0".repeat(40),
            created_at: "2026-09-04T00:00:00Z".into(),
            bundle: BundleRef {
                asset: "b".into(),
                sha256: "0".repeat(64),
                expanded_size: 0,
                file_count: 0,
                tree_sha256: "0".repeat(64),
            },
            binaries: vec![],
            components: vec![],
            compatibility: Compatibility {
                wf: "=1.0.0".into(),
                claude_code: claude.into(),
                codex: ">=0.5.0".into(),
                platforms: vec!["aarch64-apple-darwin".into()],
            },
            ctx_upstream: CtxUpstream::none(),
        }
    }

    #[test]
    fn an_agent_below_the_measured_floor_is_unsupported() {
        let l = lock_with(">=2.0.0");
        assert!(!l.agent_supported(wf_registry::Agent::ClaudeCode, Some("1.9.9")));
        assert!(l.agent_supported(wf_registry::Agent::ClaudeCode, Some("2.0.0")));
    }

    #[test]
    fn an_unmeasured_floor_does_not_block() {
        let l = lock_with("");
        assert!(l.agent_supported(wf_registry::Agent::ClaudeCode, Some("0.0.1")));
        // Neither does an agent that will not tell us its version.
        let l = lock_with(">=2.0.0");
        assert!(l.agent_supported(wf_registry::Agent::ClaudeCode, None));
    }

    #[test]
    fn a_lock_round_trips() {
        let mut l = lock_with(">=2.0.0");
        assert_eq!(Lock::parse(&l.render()).unwrap(), l);
        l.ctx_upstream.version = "1.4.7".into();
        l.ctx_upstream.binaries.push(BinaryRef {
            target: "x86_64-unknown-linux-gnu".into(),
            asset: "ctx-linux-x64".into(),
            sha256: "d".repeat(64),
        });
        l.ctx_upstream.runtimes.push(BinaryRef {
            target: "x86_64-unknown-linux-gnu".into(),
            asset: "ctx-onnxruntime-linux-x64.tar.gz".into(),
            sha256: "e".repeat(64),
        });
        let back = Lock::parse(&l.render()).unwrap();
        assert_eq!(back, l);
        assert_eq!(
            back.ctx_upstream
                .binary_for("x86_64-unknown-linux-gnu")
                .map(|b| b.asset.as_str()),
            Some("ctx-linux-x64")
        );
        assert_eq!(
            back.ctx_upstream
                .runtime_for("x86_64-unknown-linux-gnu")
                .map(|b| b.asset.as_str()),
            Some("ctx-onnxruntime-linux-x64.tar.gz")
        );
    }

    /// A lock written before ctx was pinned must still parse: `wf rollback` stages exactly those.
    #[test]
    fn a_lock_from_before_ctx_was_installed_still_parses() {
        let mut v: serde_json::Value = serde_json::from_str(&lock_with("").render()).unwrap();
        v["ctx_upstream"] = serde_json::json!({
            "version": "1.3.2",
            "commit": "4338adbb7c1420221ac4a2c75f277bc4300561e3",
            "license": "Apache-2.0"
        });
        let l = Lock::parse(&v.to_string()).unwrap();
        assert!(l.ctx_upstream.binaries.is_empty());
        assert!(l.ctx_upstream.runtimes.is_empty());
        assert!(l
            .ctx_upstream
            .binary_for("x86_64-unknown-linux-gnu")
            .is_none());
    }
}
