//! ctx, the upstream this release installs as local history (ADR-0006).
//!
//! Two halves, like the rest of this crate. [`resolve`] runs when a release is built: it
//! turns "latest" into one tag and one digest per platform, written into the lock. [`fetch`]
//! runs on a machine: it brings exactly those bytes onto disk and refuses anything else.
//! Neither executes ctx; what happens to the daemon is the sync engine's business.

use crate::github::{ApiAsset, Gh};
use crate::lock::{BinaryRef, CtxUpstream};
use crate::source::ReleaseSource;
use std::path::{Path, PathBuf};
use std::time::Duration;
use wf_core::{Error, ExitCode, Result};

pub const REPO: &str = "ctxrs/ctx";

/// The asset upstream publishes for one of this release line's targets.
pub fn asset_for(target: &str) -> Option<&'static str> {
    match target {
        "aarch64-apple-darwin" => Some("ctx-macos-arm64"),
        "x86_64-unknown-linux-gnu" => Some("ctx-linux-x64"),
        _ => None,
    }
}

/// The CPU ONNX Runtime sidecar upstream publishes beside each binary.
pub fn runtime_asset_for(target: &str) -> Option<&'static str> {
    match target {
        "aarch64-apple-darwin" => Some("ctx-onnxruntime-macos-arm64.tar.gz"),
        "x86_64-unknown-linux-gnu" => Some("ctx-onnxruntime-linux-x64.tar.gz"),
        _ => None,
    }
}

/// The platform directory ctx's loader looks for the runtime under
/// (`onnxruntime/<version>/<platform>/lib/`, upstream `model_runtime/onnx.rs`).
pub fn runtime_platform_for(target: &str) -> Option<&'static str> {
    match target {
        "aarch64-apple-darwin" => Some("macos-arm64"),
        "x86_64-unknown-linux-gnu" => Some("linux-x64"),
        _ => None,
    }
}

/// Pin a ctx release: `latest`, or a tag such as `v1.4.6` for an emergency pin.
///
/// Every supported target must have an asset and a sha256 digest, or the build fails:
/// a lock that pins ctx for one platform and silently not the other is a fleet half of
/// which never gets history.
pub fn resolve(tag: &str, timeout: Duration) -> Result<CtxUpstream> {
    let gh = Gh::new(REPO).with_timeout(timeout);
    let upstream = |e: Error| {
        Error::failure("CTX-UPSTREAM", format!("{REPO} {tag}: {}", e.message)).with_zh(format!(
            "读不到 {REPO} 的 {tag} 版本（{}）。请检查网络和 `gh auth status`，再重新构建。",
            e.kind
        ))
    };
    let rel = if tag == "latest" {
        gh.latest_published()
    } else if tag.starts_with('v') {
        gh.release(tag)
    } else {
        gh.release(&format!("v{tag}"))
    }
    .map_err(upstream)?;
    let binaries = pins(&rel.tag_name, &rel.assets, asset_for)?;
    let runtimes = pins(&rel.tag_name, &rel.assets, runtime_asset_for)?;
    let commit = gh.tag_commit(&rel.tag_name).map_err(upstream)?;
    Ok(CtxUpstream {
        version: rel.tag_name.trim_start_matches('v').to_string(),
        commit,
        license: "Apache-2.0".into(),
        binaries,
        runtimes,
    })
}

fn pins(
    tag: &str,
    assets: &[ApiAsset],
    asset_for: fn(&str) -> Option<&'static str>,
) -> Result<Vec<BinaryRef>> {
    let mut out = Vec::new();
    for target in wf_core::paths::SUPPORTED_TARGETS {
        let missing = |what: &str| {
            Error::failure("CTX-UPSTREAM", format!("{REPO} {tag}: {what} for {target}"))
                .with_zh(format!(
                    "{REPO} 的 {tag} 缺少 {target} 的可校验文件，不能锁定它。换一个版本（`--ctx vX.Y.Z`）重新构建。"
                ))
        };
        let asset = asset_for(target).ok_or_else(|| missing("no known asset name"))?;
        let sha256 = assets
            .iter()
            .find(|a| a.name == asset)
            .and_then(ApiAsset::sha256)
            .filter(|d| d.len() == 64 && d.bytes().all(|b| b.is_ascii_hexdigit()))
            .ok_or_else(|| missing("no asset with a sha256 digest"))?;
        out.push(BinaryRef {
            target: target.to_string(),
            asset: asset.to_string(),
            sha256: sha256.to_ascii_lowercase(),
        });
    }
    Ok(out)
}

/// Put one pinned upstream asset for this platform — the ctx binary or its runtime archive —
/// at `<dir>/ctx-<sha256>`, verified, never executed.
///
/// WFR-014's order, with one scoped difference: upstream's releases are mutable, so the
/// authority is the digest wf's own immutable lock carries. GitHub's API digest must agree
/// with it before a byte is downloaded, and the bytes must agree with it afterwards. A copy
/// left by an earlier attempt is reused only if it still hashes to the pin.
pub fn fetch(
    pin: &CtxUpstream,
    binary: &BinaryRef,
    source: &ReleaseSource,
    dir: &Path,
    timeout: Duration,
) -> Result<PathBuf> {
    let dest = dir.join(format!("ctx-{}", binary.sha256));
    if dest.is_file() && wf_core::hash::sha256_file(&dest)? == binary.sha256 {
        return Ok(dest);
    }
    std::fs::create_dir_all(dir)?;
    let work = tempfile::Builder::new().prefix("ctx-").tempdir_in(dir)?;
    // A local release directory may carry the asset for a rehearsal; otherwise it comes
    // from upstream, whatever the source of the wf release itself.
    let local = match source {
        ReleaseSource::Local { dir } => Some(dir.join(&binary.asset)).filter(|p| p.is_file()),
        ReleaseSource::GitHub { .. } => None,
    };
    let downloaded = match local {
        Some(path) => {
            let copy = work.path().join(&binary.asset);
            std::fs::copy(path, &copy)?;
            copy
        }
        None => {
            let gh = Gh::new(REPO).with_timeout(timeout);
            let tag = format!("v{}", pin.version);
            let api = gh.release(&tag)?;
            crate::bundle::check_digest(&api, &binary.asset, &binary.sha256).map_err(integrity)?;
            gh.download(&tag, &binary.asset, work.path())?
        }
    };
    let got = wf_core::hash::sha256_file(&downloaded)?;
    if got != binary.sha256 {
        return Err(integrity(Error::integrity(
            "CTX-DIGEST-MISMATCH",
            format!("{}: expected {}, got {got}", binary.asset, binary.sha256),
        )));
    }
    std::fs::rename(&downloaded, &dest)?;
    Ok(dest)
}

/// The runtime library's file name inside the sidecar's `lib/`.
pub fn runtime_library_for(target: &str) -> Option<&'static str> {
    match target {
        "aarch64-apple-darwin" => Some("libonnxruntime.dylib"),
        "x86_64-unknown-linux-gnu" => Some("libonnxruntime.so"),
        _ => None,
    }
}

/// Where the runtime of `version` puts its library under `root`: the layout ctx's loader
/// searches beside its own executable, `<root>/<VERSION_NUMBER>/<platform>/lib/<library>`.
pub fn runtime_library_path(root: &Path, version: &str, target: &str) -> Option<PathBuf> {
    Some(
        root.join(version)
            .join(runtime_platform_for(target)?)
            .join("lib")
            .join(runtime_library_for(target)?),
    )
}

/// A runtime expanded and checked beside its destination, not yet in place: a complete tree in
/// a scratch directory on the destination's filesystem, so it goes in by one rename. The
/// caller swaps it in; dropping it removes the scratch directory and whatever the swap left
/// there.
#[derive(Debug)]
pub struct StagedRuntime {
    work: tempfile::TempDir,
    platform: &'static str,
    /// `VERSION_NUMBER` from the archive: the one the ctx built alongside it looks for.
    pub version: String,
    /// The library's sha256 as the verified archive carried it, for every later check that
    /// the bytes ctx loads are still these.
    pub library_sha256: String,
}

impl StagedRuntime {
    /// The complete new runtime tree.
    pub fn tree(&self) -> PathBuf {
        self.work.path().join("runtime")
    }

    /// Scratch space beside the tree, on the same filesystem, removed with it.
    pub fn scratch(&self) -> &Path {
        self.work.path()
    }

    /// Where it belongs under `root`: `<root>/<version>/<platform>/`.
    pub fn destination(&self, root: &Path) -> PathBuf {
        root.join(&self.version).join(self.platform)
    }
}

/// Expand a verified runtime archive into a scratch directory under `root` and check it,
/// without touching anything a running ctx loads. `root` must already be verified as wf's own
/// directory: the archive is written inside it.
///
/// The archive is expanded by the same hostile-archive extractor a release bundle goes
/// through (regular files and directories only, relative paths, bounded sizes). The version
/// comes from the archive itself: it is the one the ctx built alongside it looks for, and the
/// lock does not carry it.
pub fn stage_runtime(archive: &Path, root: &Path, target: &str) -> Result<StagedRuntime> {
    let broken = |why: String| {
        Error::failure("CTX-RUNTIME", why).with_zh(
            "ctx 的语义检索运行库没有装好，现在只能按关键词检索。之后会自动再试，也可以现在运行 `wf install`。",
        )
    };
    let (Some(platform), Some(library)) =
        (runtime_platform_for(target), runtime_library_for(target))
    else {
        return Err(broken(format!("no ONNX Runtime layout for {target}")));
    };
    let work = tempfile::Builder::new()
        .prefix(".staging-")
        .tempdir_in(root)?;
    let expanded = work.path().join("runtime");
    // Upstream's sidecars hold five files, the largest under 40 MB.
    crate::archive::extract_tar_gz(
        archive,
        &expanded,
        crate::archive::Limits {
            max_files: 64,
            max_file_bytes: 256 * 1024 * 1024,
            max_total_bytes: 512 * 1024 * 1024,
        },
    )?;

    let version = std::fs::read_to_string(expanded.join("VERSION_NUMBER"))?
        .trim()
        .to_string();
    if !is_version(&version) {
        return Err(broken(format!(
            "{}: VERSION_NUMBER {version:?} is not a version",
            archive.display()
        )));
    }
    let lib = expanded.join("lib").join(library);
    if !lib.is_file() {
        return Err(broken(format!(
            "{}: no lib/{library} in the archive",
            archive.display()
        )));
    }
    Ok(StagedRuntime {
        library_sha256: wf_core::hash::sha256_file(&lib)?,
        work,
        platform,
        version,
    })
}

/// It becomes a directory name under the runtime root, so it is dot-separated numbers and
/// nothing else: `1.27.0` passes, `..`, `1..2` and `.` do not.
fn is_version(s: &str) -> bool {
    !s.is_empty()
        && s.split('.')
            .all(|part| !part.is_empty() && part.bytes().all(|b| b.is_ascii_digit()))
}

/// One code for every way the bytes can disagree with the lock, so the machine record and
/// `wf doctor` have one sentence to show.
fn integrity(e: Error) -> Error {
    if e.code != ExitCode::Integrity {
        return e;
    }
    Error::integrity("CTX-INTEGRITY", e.message).with_zh(
        "下载的 ctx 和这个版本锁定的不一致，已经删掉，没有运行，也没有替换现有的 ctx。\n  通常是网络中途出错，稍后会自动再试；连续出现请把这条消息发给团队。",
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    fn asset(name: &str, digest: Option<String>) -> ApiAsset {
        ApiAsset {
            name: name.into(),
            digest,
            size: 1,
        }
    }

    #[test]
    fn every_supported_target_has_an_upstream_asset() {
        for target in wf_core::paths::SUPPORTED_TARGETS {
            assert!(asset_for(target).is_some(), "{target} has no ctx asset");
            assert!(
                runtime_asset_for(target).is_some() && runtime_platform_for(target).is_some(),
                "{target} has no ONNX Runtime sidecar"
            );
        }
    }

    #[test]
    fn a_release_missing_one_platform_cannot_be_pinned() {
        let d = format!("sha256:{}", "a".repeat(64));
        let all = [
            asset("ctx-macos-arm64", Some(d.clone())),
            asset("ctx-linux-x64", Some(d.clone())),
            asset("ctx-windows-x64.exe", Some(d.clone())),
        ];
        let pinned = pins("v1.4.7", &all, asset_for).unwrap();
        assert_eq!(pinned.len(), wf_core::paths::SUPPORTED_TARGETS.len());
        assert!(pinned.iter().all(|b| b.sha256 == "a".repeat(64)));

        let no_linux = [asset("ctx-macos-arm64", Some(d.clone()))];
        assert_eq!(
            pins("v1.4.7", &no_linux, asset_for).unwrap_err().kind,
            "CTX-UPSTREAM"
        );
        let no_digest = [asset("ctx-macos-arm64", None), asset("ctx-linux-x64", None)];
        assert_eq!(
            pins("v1.4.7", &no_digest, asset_for).unwrap_err().kind,
            "CTX-UPSTREAM"
        );

        // The runtime is pinned under the same rule: a release without one for every
        // platform leaves half the fleet on keyword search, so it cannot be pinned either.
        assert_eq!(
            pins("v1.4.7", &all, runtime_asset_for).unwrap_err().kind,
            "CTX-UPSTREAM"
        );
        let runtimes = [
            asset("ctx-onnxruntime-macos-arm64.tar.gz", Some(d.clone())),
            asset("ctx-onnxruntime-linux-x64.tar.gz", Some(d)),
        ];
        let pinned = pins("v1.5.0", &runtimes, runtime_asset_for).unwrap();
        assert_eq!(pinned.len(), wf_core::paths::SUPPORTED_TARGETS.len());
        assert!(pinned
            .iter()
            .all(|b| b.asset.starts_with("ctx-onnxruntime-")));
    }

    fn pinned(bytes: &[u8]) -> (CtxUpstream, BinaryRef) {
        let binary = BinaryRef {
            target: wf_core::paths::target_triple().into(),
            asset: "ctx-test".into(),
            sha256: wf_core::hash::sha256_bytes(bytes),
        };
        let pin = CtxUpstream {
            version: "1.4.7".into(),
            binaries: vec![binary.clone()],
            ..CtxUpstream::none()
        };
        (pin, binary)
    }

    #[test]
    fn a_local_asset_is_verified_and_a_tampered_one_leaves_nothing() {
        let release = tempfile::tempdir().unwrap();
        let staging = tempfile::tempdir().unwrap();
        let source = ReleaseSource::Local {
            dir: release.path().to_path_buf(),
        };
        let (pin, binary) = pinned(b"#!/bin/sh\necho ctx 1.4.7\n");

        std::fs::write(release.path().join("ctx-test"), b"tampered").unwrap();
        let err = fetch(
            &pin,
            &binary,
            &source,
            staging.path(),
            Duration::from_secs(1),
        )
        .unwrap_err();
        assert_eq!(err.kind, "CTX-INTEGRITY");
        assert!(!staging
            .path()
            .join(format!("ctx-{}", binary.sha256))
            .exists());

        std::fs::write(
            release.path().join("ctx-test"),
            b"#!/bin/sh\necho ctx 1.4.7\n",
        )
        .unwrap();
        let got = fetch(
            &pin,
            &binary,
            &source,
            staging.path(),
            Duration::from_secs(1),
        )
        .unwrap();
        assert_eq!(wf_core::hash::sha256_file(&got).unwrap(), binary.sha256);

        // A verified copy from an earlier attempt is reused without a source at all.
        std::fs::remove_file(release.path().join("ctx-test")).unwrap();
        let again = fetch(
            &pin,
            &binary,
            &source,
            staging.path(),
            Duration::from_secs(1),
        );
        assert_eq!(again.unwrap(), got);
    }

    /// A sidecar shaped like upstream's: `VERSION_NUMBER` and `lib/<library>` at the top.
    fn sidecar(dir: &Path, version: &str, library: &str) -> PathBuf {
        let path = dir.join("ctx-onnxruntime.tar.gz");
        let gz = flate2::write::GzEncoder::new(
            std::fs::File::create(&path).unwrap(),
            flate2::Compression::default(),
        );
        let mut tar = tar::Builder::new(gz);
        for (name, body) in [
            ("VERSION_NUMBER", format!("{version}\n")),
            ("LICENSE", "MIT".to_string()),
            (&format!("lib/{library}") as &str, "\x7fELF".to_string()),
        ] {
            let mut header = tar::Header::new_gnu();
            header.set_size(body.len() as u64);
            header.set_mode(0o755);
            header.set_cksum();
            tar.append_data(&mut header, name, body.as_bytes()).unwrap();
        }
        tar.into_inner().unwrap().finish().unwrap();
        path
    }

    #[test]
    fn a_staged_runtime_is_a_complete_tree_beside_its_destination() {
        let target = "x86_64-unknown-linux-gnu";
        let work = tempfile::tempdir().unwrap();
        let root = work.path().join("bin/onnxruntime");
        std::fs::create_dir_all(&root).unwrap();

        let archive = sidecar(work.path(), "1.27.0", "libonnxruntime.so");
        let staged = stage_runtime(&archive, &root, target).unwrap();
        assert_eq!(staged.version, "1.27.0");
        assert_eq!(
            staged.library_sha256,
            wf_core::hash::sha256_bytes(b"\x7fELF")
        );
        assert_eq!(staged.destination(&root), root.join("1.27.0/linux-x64"));
        assert_eq!(
            runtime_library_path(&root, "1.27.0", target).unwrap(),
            root.join("1.27.0/linux-x64/lib/libonnxruntime.so")
        );
        let tree = staged.tree();
        assert!(tree.starts_with(&root), "staged outside the runtime root");
        assert!(tree.starts_with(staged.scratch()));
        assert_eq!(std::fs::read(tree.join("LICENSE")).unwrap(), b"MIT");
        assert_eq!(
            std::fs::read(tree.join("VERSION_NUMBER")).unwrap(),
            b"1.27.0\n"
        );
        assert_eq!(
            std::fs::read(tree.join("lib/libonnxruntime.so")).unwrap(),
            b"\x7fELF"
        );
        // Staging writes nothing where the loader looks.
        assert!(!root.join("1.27.0").exists());
    }

    /// Staging touches nothing a running ctx loads: a staged runtime that is never committed —
    /// the update failed later — leaves the copy already in place byte for byte.
    #[test]
    fn a_staged_runtime_that_is_dropped_leaves_the_previous_copy_alone() {
        let target = "x86_64-unknown-linux-gnu";
        let work = tempfile::tempdir().unwrap();
        let root = work.path().join("onnxruntime");
        let old = root.join("1.27.0/linux-x64/lib/libonnxruntime.so");
        std::fs::create_dir_all(old.parent().unwrap()).unwrap();
        std::fs::write(&old, b"the runtime the running ctx loads").unwrap();

        let archive = sidecar(work.path(), "1.27.0", "libonnxruntime.so");
        let staged = stage_runtime(&archive, &root, target).unwrap();
        drop(staged);
        assert_eq!(
            std::fs::read(&old).unwrap(),
            b"the runtime the running ctx loads"
        );
        let left: Vec<_> = std::fs::read_dir(&root)
            .unwrap()
            .map(|e| e.unwrap().file_name())
            .collect();
        assert_eq!(left, vec![std::ffi::OsString::from("1.27.0")]);
    }

    #[test]
    fn an_archive_without_the_library_or_a_version_is_refused() {
        let target = "x86_64-unknown-linux-gnu";
        let work = tempfile::tempdir().unwrap();
        let root = work.path().join("onnxruntime");
        std::fs::create_dir_all(&root).unwrap();

        let wrong_library = sidecar(work.path(), "1.27.0", "libonnxruntime.dylib");
        let err = stage_runtime(&wrong_library, &root, target).unwrap_err();
        assert_eq!(err.kind, "CTX-RUNTIME");
        assert!(!root.join("1.27.0").exists());

        // Each of these would name a directory outside `<root>/<version>/`.
        for bad in ["../../escape", "..", ".", "1..2", "1.27.0/.."] {
            let not_a_version = sidecar(work.path(), bad, "libonnxruntime.so");
            let err = stage_runtime(&not_a_version, &root, target).unwrap_err();
            assert_eq!(err.kind, "CTX-RUNTIME", "{bad}");
        }
        assert!(is_version("1.27.0"));
    }

    #[test]
    fn a_runtime_archive_with_a_link_is_refused_before_anything_is_written() {
        let work = tempfile::tempdir().unwrap();
        let root = work.path().join("onnxruntime");
        std::fs::create_dir_all(&root).unwrap();
        let path = work.path().join("linked.tar.gz");
        let gz = flate2::write::GzEncoder::new(
            std::fs::File::create(&path).unwrap(),
            flate2::Compression::default(),
        );
        let mut tar = tar::Builder::new(gz);
        let mut header = tar::Header::new_gnu();
        header.set_entry_type(tar::EntryType::Symlink);
        header.set_size(0);
        header.set_mode(0o777);
        tar.append_link(&mut header, "lib", "/etc").unwrap();
        tar.into_inner().unwrap().finish().unwrap();

        let err = stage_runtime(&path, &root, "x86_64-unknown-linux-gnu").unwrap_err();
        assert_eq!(err.kind, "ARCHIVE-LINK");
        let left: Vec<_> = std::fs::read_dir(&root).unwrap().collect();
        assert!(left.is_empty(), "{left:?}");
    }
}
