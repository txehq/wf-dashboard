//! `wf mcp` — the servers this machine already reaches, and the ones a person declined.

use super::{emit, options};
use crate::flags::McpCmd;
use wf_agents::adapter::Desired;
use wf_agents::resources::mcp::Candidate;
use wf_core::{envelope::Envelope, ExitCode, Result};
use wf_sync::Engine;

pub fn run(json: bool, cmd: McpCmd) -> Result<ExitCode> {
    match cmd {
        McpCmd::Survey { remote, agent } => survey(json, remote, agent),
        McpCmd::Skip {
            component,
            agent,
            host,
            reason,
            dry_run,
        } => skip(json, &component, agent, host, reason, dry_run),
        McpCmd::Unskip {
            component,
            agent,
            dry_run,
        } => unskip(json, &component, agent, dry_run),
    }
}

fn survey(json: bool, remote: crate::flags::RemoteArgs, agent: Option<String>) -> Result<ExitCode> {
    let mut opts = options(&remote)?;
    opts.dry_run = true;
    opts.agents = agent;
    let engine = Engine::open(opts)?;

    let mut env = Envelope::new("mcp survey");
    let bundle = match (remote.source.as_ref(), engine.active_bundle_dir()) {
        (None, Some(bundle)) => bundle,
        _ => {
            let release = wf_release::bundle::resolve(
                &engine.opts.source,
                engine.opts.channel,
                engine.opts.remote_timeout,
            )?
            .ok_or_else(|| {
                wf_core::Error::failure("NO-RELEASE", "no installable release for MCP survey")
            })?;
            engine.stage(&release)?.1.join("bundle")
        }
    };
    let ctx = engine.context(&bundle)?;
    let adapters =
        wf_agents::engine::select_agents(&ctx, &engine.db, engine.opts.agents.as_deref())?;
    let desired = Desired::scan(&ctx.repo);
    let rows = wf_agents::resources::mcp::candidates(&desired, &adapters, &engine.db)?;

    env.result["candidates"] = serde_json::to_value(&rows)?;
    // Already decided, so the agent driving an install knows not to ask about these again.
    env.result["skipped"] = serde_json::to_value(engine.db.skipped_mcps()?)?;
    // Warnings are `emit`'s to print, in both renderings; the human text here is the answer
    // itself and nothing else.
    let rendered = render(&rows);
    Ok(emit(json, env, move || rendered))
}

/// Which agents a decision covers. Named, or every agent wf writes MCP servers into — read
/// from the shipped agent registry rather than from an installation, because the question
/// `/install` asks comes before there is one.
fn agents_for(agent: Option<&str>) -> Result<Vec<String>> {
    let registry = wf_agents::registry::AgentRegistry::builtin();
    let selected = match agent {
        Some(name) => registry.select(name)?,
        None => registry.select("all")?,
    };
    let out: Vec<String> = selected
        .iter()
        .filter(|spec| spec.formats.mcp.is_some())
        .map(|spec| spec.id.clone())
        .collect();
    if out.is_empty() {
        return Err(wf_core::Error::usage(
            "MCP-AGENT",
            format!(
                "{}: no agent here keeps MCP servers, so there is nothing to decide",
                agent.unwrap_or("all")
            ),
        )
        .with_zh(format!(
            "{} 不保存 MCP 服务，没有什么可以决定的。",
            agent.unwrap_or("所有 agent")
        )));
    }
    Ok(out)
}

/// A decision is a write to this machine's state, so it takes the same lifecycle lock an
/// apply does: a decision recorded while a sync is halfway through its own object pass would
/// be read by that pass or not depending on timing.
fn engine_for_decision(dry_run: bool) -> Result<Engine> {
    let mut opts = options(&crate::flags::RemoteArgs::default())?;
    opts.dry_run = dry_run;
    opts.offline = true;
    Engine::open(opts)
}

fn skip(
    json: bool,
    component: &str,
    agent: Option<String>,
    host: Option<String>,
    reason: Option<String>,
    dry_run: bool,
) -> Result<ExitCode> {
    let agents = agents_for(agent.as_deref())?;
    let engine = engine_for_decision(dry_run)?;
    let _guard = engine.lifecycle_lock(false)?;
    let at = wf_core::time_fmt::now_utc_millis();
    let rows: Vec<wf_state::SkippedMcp> = agents
        .iter()
        .map(|id| wf_state::SkippedMcp {
            agent_id: id.clone(),
            component_id: component.to_string(),
            skipped_at: at.clone(),
            reason: reason.clone().unwrap_or_default(),
            host: host.clone().unwrap_or_default(),
            source: "user".into(),
        })
        .collect();
    if !dry_run {
        for row in &rows {
            engine.db.record_skipped_mcp(row)?;
        }
    }
    let env = Envelope::new("mcp skip").result(serde_json::json!({
        "component": component,
        "agents": agents,
        "dry_run": dry_run,
        "recorded": rows,
    }));
    let component = component.to_string();
    let where_ = agents.join("、");
    Ok(emit(json, env, move || {
        if dry_run {
            format!("演练完成，什么都没有记录。将记下：{where_} 不安装 {component}。\n")
        } else {
            format!(
                "记下了：{where_} 不再安装 {component}。以后不会再问，也不会再提醒。\n\
                 想装回来就运行 `wf mcp unskip {component}`。\n"
            )
        }
    }))
}

fn unskip(json: bool, component: &str, agent: Option<String>, dry_run: bool) -> Result<ExitCode> {
    let engine = engine_for_decision(dry_run)?;
    let _guard = engine.lifecycle_lock(false)?;
    // Counted before anything is removed, so a dry run and a real one report the same number
    // and "there was nothing to undo" is distinguishable from "undone".
    let matching: Vec<wf_state::SkippedMcp> = engine
        .db
        .skipped_mcps()?
        .into_iter()
        .filter(|s| s.component_id == component && agent.as_deref().is_none_or(|a| s.agent_id == a))
        .collect();
    if !dry_run && !matching.is_empty() {
        engine.db.forget_skipped_mcp(component, agent.as_deref())?;
    }
    let env = Envelope::new("mcp unskip").result(serde_json::json!({
        "component": component,
        "agents": matching.iter().map(|s| s.agent_id.clone()).collect::<Vec<_>>(),
        "undone": matching.len(),
        "dry_run": dry_run,
        // Removing the record installs nothing by itself. `wf sync` on a version already
        // active returns before it checks a single object, so the one command that puts the
        // server back is named here rather than left for the person to guess.
        "next": (!dry_run && !matching.is_empty()).then_some("wf repair"),
    }));
    let component = component.to_string();
    let count = matching.len();
    let where_ = matching
        .iter()
        .map(|s| s.agent_id.clone())
        .collect::<Vec<_>>()
        .join("、");
    Ok(emit(json, env, move || {
        if count == 0 {
            format!("{component} 本来就没有被跳过，什么都不用做。\n")
        } else if dry_run {
            format!("演练完成，什么都没有改动。将撤销：{where_} 上不装 {component} 的决定。\n")
        } else {
            format!(
                "{where_} 上不装 {component} 的决定已经撤销。\n\
                 运行 `wf repair` 把它装上——只是撤销记录不会自己安装。\n"
            )
        }
    }))
}

fn render(rows: &[Candidate]) -> String {
    if rows.is_empty() {
        return String::new();
    }
    let mut s = String::from("安装前需要确认的 MCP 条目：\n");
    for row in rows {
        s.push_str(&format!(
            "  {:<22} {:<12} {}（{}）\n",
            row.component_id,
            row.agent,
            if row.by == wf_agents::formats::Occupied::Key {
                "同名条目已存在".to_string()
            } else {
                format!("{} 已被占用", row.hosts.join("、"))
            },
            if row.by == wf_agents::formats::Occupied::Host {
                "按服务比对"
            } else {
                "按名字比对"
            }
        ));
    }
    s
}
