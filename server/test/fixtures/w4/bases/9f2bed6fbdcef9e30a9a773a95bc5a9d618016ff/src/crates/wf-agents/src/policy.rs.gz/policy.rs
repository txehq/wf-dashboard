//! `workflow/teamai/policies.yaml` — what the organization allows the agent layer to do.
//!
//! Every list here follows one rule: **empty means unrestricted**, a non-empty list is an
//! allowlist. The exception is environment keys that would hijack a process rather than
//! configure it (`PATH`, loader variables); those are refused whatever the list says, because
//! a verified release is a trust boundary for content, not a licence to rewrite how every
//! program on the machine starts.

use serde::{Deserialize, Serialize};
use std::path::Path;
use wf_core::{Error, Result};

pub const POLICIES_FILE: &str = "workflow/teamai/policies.yaml";
pub const SCHEMA_VERSION: u32 = 1;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Policies {
    pub schema_version: u32,
    #[serde(default)]
    pub usage: UsagePolicy,
    #[serde(default)]
    pub sessions: SessionsPolicy,
    #[serde(default)]
    pub mcp: McpPolicy,
    #[serde(default)]
    pub hooks: HooksPolicy,
    #[serde(default)]
    pub rules: RulesPolicy,
    #[serde(default)]
    pub env: EnvPolicy,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct UsagePolicy {
    #[serde(default = "yes")]
    pub enabled: bool,
    #[serde(default)]
    pub storage: Storage,
    #[serde(default = "ninety")]
    pub retention_days: u32,
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum Storage {
    #[default]
    Local,
    /// Declared so the vocabulary is complete; refused by [`Policies::validate`] until an
    /// uploader exists.
    Remote,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SessionsPolicy {
    #[serde(default = "yes")]
    pub enabled: bool,
    /// Summarise sessions as their events arrive, and log the valuable ones when they end.
    #[serde(default = "yes")]
    pub auto_collect: bool,
    #[serde(default)]
    pub valuable_threshold: ValuableThreshold,
    #[serde(default = "six")]
    pub retention_months: u32,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ValuableThreshold {
    /// Distinct tools a session must use to count as valuable on its own.
    #[serde(default = "three")]
    pub min_tools: u32,
    /// Interventions (a correction, an interrupt, a rejected tool) that make a session
    /// valuable on their own, whatever its tools.
    #[serde(default = "one")]
    pub min_interventions: u32,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct McpPolicy {
    #[serde(default = "yes")]
    pub auto_apply: bool,
    #[serde(default)]
    pub allowed_commands: Vec<String>,
    #[serde(default)]
    pub allowed_hosts: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct HooksPolicy {
    #[serde(default = "yes")]
    pub auto_apply: bool,
    /// Only handlers that run `wf` itself. Anything else would be a script the release
    /// ships and every session executes.
    #[serde(default)]
    pub require_team_scripts: bool,
}

#[derive(Debug, Clone, Default, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RulesPolicy {
    /// Rules restored over a person's edit. Every other rule is seeded once and then belongs
    /// to whoever edits it; a drifted copy is reported, not overwritten.
    #[serde(default)]
    pub enforced: Vec<String>,
}

#[derive(Debug, Clone, Default, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct EnvPolicy {
    #[serde(default)]
    pub allowed_keys: Vec<String>,
}

fn yes() -> bool {
    true
}
fn one() -> u32 {
    1
}
fn three() -> u32 {
    3
}
fn six() -> u32 {
    6
}
fn ninety() -> u32 {
    90
}

impl Default for UsagePolicy {
    fn default() -> Self {
        Self {
            enabled: true,
            storage: Storage::Local,
            retention_days: 90,
        }
    }
}
impl Default for SessionsPolicy {
    fn default() -> Self {
        Self {
            enabled: true,
            auto_collect: true,
            valuable_threshold: ValuableThreshold::default(),
            retention_months: 6,
        }
    }
}
impl Default for ValuableThreshold {
    fn default() -> Self {
        Self {
            min_tools: 3,
            min_interventions: 1,
        }
    }
}
impl Default for McpPolicy {
    fn default() -> Self {
        Self {
            auto_apply: true,
            allowed_commands: vec![],
            allowed_hosts: vec![],
        }
    }
}
impl Default for HooksPolicy {
    fn default() -> Self {
        Self {
            auto_apply: true,
            require_team_scripts: false,
        }
    }
}
impl Default for Policies {
    fn default() -> Self {
        Self {
            schema_version: SCHEMA_VERSION,
            usage: UsagePolicy::default(),
            sessions: SessionsPolicy::default(),
            mcp: McpPolicy::default(),
            hooks: HooksPolicy::default(),
            rules: RulesPolicy::default(),
            env: EnvPolicy::default(),
        }
    }
}

/// Environment keys that change how processes start rather than what they do.
const HIJACK_KEYS: &[&str] = &["PATH", "HOME", "SHELL", "IFS", "ENV", "BASH_ENV"];
const HIJACK_PREFIXES: &[&str] = &["LD_", "DYLD_"];

impl Policies {
    pub fn parse(yaml: &str) -> Result<Self> {
        let policies: Policies = serde_yaml_ng::from_str(yaml).map_err(|e| {
            Error::usage("POLICIES-PARSE", format!("policies.yaml: {e}"))
                .with_zh("policies.yaml 读不下来，可能是格式写错了。请检查缩进和字段名。")
        })?;
        if policies.schema_version != SCHEMA_VERSION {
            return Err(Error::unsupported(
                "POLICIES-SCHEMA",
                format!(
                    "policies.yaml declares schema_version {} but this build understands {SCHEMA_VERSION}",
                    policies.schema_version
                ),
            ));
        }
        Ok(policies)
    }

    /// The bundle's policies. The file is a shipped surface, not an optional overlay: the
    /// defaults are unrestricted, so a generation whose copy is missing would accept any MCP
    /// launcher and any host on every machine that took it.
    pub fn load(bundle_dir: &Path) -> Result<Self> {
        let path = bundle_dir.join(POLICIES_FILE);
        match std::fs::read_to_string(&path) {
            Ok(text) => Self::parse(&text),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Err(Error::failure(
                "POLICIES-MISSING",
                format!(
                    "{} is not in this generation; wf will not manage agents without the \
                     team's policies",
                    path.display()
                ),
            )),
            Err(e) => Err(e.into()),
        }
    }

    pub fn validate(&self) -> Vec<crate::registry::Violation> {
        let mut out = Vec::new();
        let mut v = |code, subject: &str, message: String| {
            out.push(crate::registry::Violation {
                code,
                subject: subject.into(),
                message,
            })
        };
        if self.usage.storage == Storage::Remote {
            v(
                "POL001",
                "usage.storage",
                "remote storage has no uploader in this release; usage stays local".into(),
            );
        }
        if self.usage.retention_days == 0 {
            v(
                "POL002",
                "usage.retention_days",
                "0 would delete every event as it arrives".into(),
            );
        }
        if self.sessions.retention_months == 0 {
            v(
                "POL002",
                "sessions.retention_months",
                "0 would delete every session log as it is written".into(),
            );
        }
        for pattern in &self.mcp.allowed_hosts {
            if !host_pattern_shaped(pattern) {
                v(
                    "POL003",
                    "mcp.allowed_hosts",
                    format!(
                        "{pattern:?} must be a host name such as mcp.linear.app or *.txehq.com"
                    ),
                );
            }
        }
        for key in &self.env.allowed_keys {
            if !env_key_shaped(key) || hijacks(key) {
                v(
                    "POL004",
                    "env.allowed_keys",
                    format!("{key:?} is not an environment name wf may set"),
                );
            }
        }
        out
    }
}

impl McpPolicy {
    pub fn command_allowed(&self, command: &str) -> bool {
        self.allowed_commands.is_empty() || self.allowed_commands.iter().any(|c| c == command)
    }

    /// `*.example.com` matches `example.com` and every subdomain; a `*` label elsewhere
    /// matches exactly one label. Comparison ignores ASCII case.
    pub fn host_allowed(&self, host: &str) -> bool {
        if self.allowed_hosts.is_empty() {
            return true;
        }
        !host.is_empty()
            && self
                .allowed_hosts
                .iter()
                .any(|pattern| host_pattern_matches(pattern, host))
    }
}

impl EnvPolicy {
    pub fn key_allowed(&self, key: &str) -> bool {
        env_key_shaped(key)
            && !hijacks(key)
            && (self.allowed_keys.is_empty() || self.allowed_keys.iter().any(|k| k == key))
    }
}

impl RulesPolicy {
    pub fn is_enforced(&self, rule_id: &str) -> bool {
        self.enforced.iter().any(|r| r == rule_id)
    }
}

impl SessionsPolicy {
    pub fn is_valuable(&self, distinct_tools: usize, interventions: usize) -> bool {
        distinct_tools >= self.valuable_threshold.min_tools as usize
            || interventions >= self.valuable_threshold.min_interventions as usize
    }
}

fn host_pattern_matches(pattern: &str, host: &str) -> bool {
    let pattern = pattern.to_ascii_lowercase();
    let host = host.to_ascii_lowercase();
    if let Some(apex) = pattern.strip_prefix("*.") {
        if host == apex || host.ends_with(&format!(".{apex}")) {
            return true;
        }
    }
    let p: Vec<&str> = pattern.split('.').collect();
    let h: Vec<&str> = host.split('.').collect();
    p.len() == h.len() && p.iter().zip(&h).all(|(p, h)| *p == "*" || p == h)
}

fn host_pattern_shaped(pattern: &str) -> bool {
    let labels: Vec<&str> = pattern.split('.').collect();
    labels.len() >= 2
        && labels.iter().any(|l| *l != "*")
        && labels.iter().all(|l| {
            *l == "*"
                || (!l.is_empty() && l.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-'))
        })
}

fn env_key_shaped(key: &str) -> bool {
    !key.is_empty()
        && !key.starts_with(|c: char| c.is_ascii_digit())
        && key
            .bytes()
            .all(|b| b.is_ascii_uppercase() || b.is_ascii_digit() || b == b'_')
}

fn hijacks(key: &str) -> bool {
    HIJACK_KEYS.contains(&key) || HIJACK_PREFIXES.iter().any(|p| key.starts_with(p))
}

#[cfg(test)]
mod tests {
    use super::*;

    const SHIPPED_SHAPE: &str = r#"
schema_version: 1
usage:
  enabled: true
  storage: local
  retention_days: 90
sessions:
  enabled: true
  auto_collect: true
  valuable_threshold:
    min_tools: 3
    min_interventions: 1
  retention_months: 6
mcp:
  auto_apply: true
  allowed_commands: [npx, node]
  allowed_hosts: ["*.txehq.com", mcp.linear.app, "mcp.*.com"]
hooks:
  auto_apply: true
  require_team_scripts: false
rules:
  enforced: [security/secrets]
env:
  allowed_keys: [LINEAR_WORKSPACE]
"#;

    fn policies() -> Policies {
        Policies::parse(SHIPPED_SHAPE).unwrap()
    }

    #[test]
    fn the_shipped_policies_parse_and_validate() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
        let p = Policies::load(&root).expect("workflow/teamai/policies.yaml loads");
        assert_eq!(p.validate(), vec![]);
        // Both MCP servers the registry ships have to survive their own policy.
        assert!(p.mcp.command_allowed("npx"));
        assert!(p.mcp.host_allowed("mcp.linear.app"));
        assert!(p.mcp.host_allowed("mcp.spot.rackspace.com"));
    }

    #[test]
    fn a_generation_without_the_file_is_refused() {
        // The defaults are unrestricted, so taking them for a missing file would let a
        // generation that lost its policies accept any MCP launcher on every machine.
        let dir = tempfile::tempdir().unwrap();
        assert_eq!(
            Policies::load(dir.path()).unwrap_err().kind,
            "POLICIES-MISSING"
        );
        assert_eq!(
            Policies::parse("schema_version: 1\n").unwrap(),
            Policies::default()
        );
    }

    #[test]
    fn an_unknown_field_or_a_newer_schema_is_refused() {
        assert!(Policies::parse("schema_version: 1\nusage:\n  upload: true\n").is_err());
        assert_eq!(
            Policies::parse("schema_version: 2\n").unwrap_err().code,
            wf_core::ExitCode::Unsupported
        );
    }

    #[test]
    fn remote_storage_is_not_a_thing_this_release_can_do() {
        let p =
            Policies::parse(&SHIPPED_SHAPE.replace("storage: local", "storage: remote")).unwrap();
        assert_eq!(p.validate()[0].code, "POL001");
    }

    #[test]
    fn a_retention_of_zero_would_delete_everything_and_is_refused() {
        let p = Policies::parse(&SHIPPED_SHAPE.replace("retention_days: 90", "retention_days: 0"))
            .unwrap();
        assert!(p.validate().iter().any(|v| v.code == "POL002"));
        let p =
            Policies::parse(&SHIPPED_SHAPE.replace("retention_months: 6", "retention_months: 0"))
                .unwrap();
        assert!(p.validate().iter().any(|v| v.code == "POL002"));
    }

    #[test]
    fn host_patterns_are_shaped_like_hosts() {
        for bad in [
            "\"https://mcp.linear.app\"",
            "\"*\"",
            "\"mcp.linear.app/sse\"",
            "\"\"",
        ] {
            let p = Policies::parse(&SHIPPED_SHAPE.replace("mcp.linear.app,", &format!("{bad},")))
                .unwrap();
            assert!(
                p.validate().iter().any(|v| v.code == "POL003"),
                "{bad} was accepted"
            );
        }
    }

    #[test]
    fn allowed_env_keys_must_be_names_and_never_hijack_process_startup() {
        let p = Policies::parse(&SHIPPED_SHAPE.replace("[LINEAR_WORKSPACE]", "[PATH]")).unwrap();
        assert!(p.validate().iter().any(|v| v.code == "POL004"));
        let p = Policies::parse(&SHIPPED_SHAPE.replace("[LINEAR_WORKSPACE]", "[\"not a name\"]"))
            .unwrap();
        assert!(p.validate().iter().any(|v| v.code == "POL004"));
    }

    #[test]
    fn commands_match_exactly_and_an_empty_list_allows_anything() {
        let p = policies();
        assert!(p.mcp.command_allowed("npx"));
        assert!(
            !p.mcp.command_allowed("/usr/bin/npx"),
            "no path normalisation"
        );
        assert!(!p.mcp.command_allowed("python"));
        assert!(McpPolicy::default().command_allowed("anything"));
    }

    #[test]
    fn host_wildcards_cover_the_apex_and_subdomains_and_nothing_that_merely_ends_alike() {
        let p = policies();
        assert!(p.mcp.host_allowed("txehq.com"));
        assert!(p.mcp.host_allowed("api.txehq.com"));
        assert!(p.mcp.host_allowed("a.b.txehq.com"));
        assert!(
            p.mcp.host_allowed("API.TXEHQ.COM"),
            "hosts compare without case"
        );
        assert!(!p.mcp.host_allowed("badtxehq.com"));
        assert!(p.mcp.host_allowed("mcp.linear.app"));
        assert!(!p.mcp.host_allowed("evil.linear.app"));
        // A middle wildcard is exactly one label.
        assert!(p.mcp.host_allowed("mcp.github.com"));
        assert!(!p.mcp.host_allowed("mcp.a.b.com"));
        assert!(!p.mcp.host_allowed(""));
        assert!(McpPolicy::default().host_allowed("anything.example"));
    }

    #[test]
    fn env_keys_follow_the_allowlist_but_never_admit_a_hijack() {
        let p = policies();
        assert!(p.env.key_allowed("LINEAR_WORKSPACE"));
        assert!(!p.env.key_allowed("OTHER"));
        let open = EnvPolicy::default();
        assert!(open.key_allowed("ANYTHING_ELSE"));
        for key in [
            "PATH",
            "LD_PRELOAD",
            "DYLD_INSERT_LIBRARIES",
            "HOME",
            "lower",
            "1ABC",
            "",
        ] {
            assert!(!open.key_allowed(key), "{key} was allowed");
        }
    }

    #[test]
    fn enforced_rules_and_valuable_sessions() {
        let p = policies();
        assert!(p.rules.is_enforced("security/secrets"));
        assert!(!p.rules.is_enforced("style"));
        // Either condition alone makes a session valuable.
        assert!(p.sessions.is_valuable(3, 0));
        assert!(p.sessions.is_valuable(0, 1));
        assert!(!p.sessions.is_valuable(2, 0));
    }
}
