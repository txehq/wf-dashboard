//! Custom subagents: `agents/<name>.yaml` in the team repository — one canonical definition,
//! rendered as a Claude markdown agent, a Cursor agent, a Codex role file or a Kiro agent.

use super::object::{Rendered, Shape};
use super::{files_under, ResourceHandler, ResourceItem, ResourceKind, ResourceMetadata};
use crate::formats::{render_agent, SubagentDef};
use crate::{adapter::TeamAIAdapter, registry::PathKind, team_repo::TeamRepo};
use wf_core::{Error, Result};

pub struct AgentsHandler;

impl ResourceHandler for AgentsHandler {
    fn kind(&self) -> ResourceKind {
        ResourceKind::Agent
    }

    fn scan_registry(&self, repo: &TeamRepo) -> Result<Vec<ResourceItem>> {
        let Some(dir) = repo.resource_dir(ResourceKind::Agent)? else {
            return Ok(vec![]);
        };
        let mut out = Vec::new();
        for rel in files_under(&dir)? {
            let Some(stem) = rel.strip_suffix(".yaml") else {
                continue;
            };
            let source = dir.join(&rel);
            let text = std::fs::read_to_string(&source)?;
            let def: SubagentDef = serde_yaml_ng::from_str(&text)
                .map_err(|e| Error::usage("AGENT-PARSE", format!("{rel}: {e}")))?;
            if def.name != stem {
                return Err(Error::usage(
                    "AGENT-NAME",
                    format!("{rel}: name {:?} must match the file name", def.name),
                ));
            }
            out.push(ResourceItem {
                id: def.name.clone(),
                name: def.name.clone(),
                kind: ResourceKind::Agent,
                version: None,
                source,
                metadata: ResourceMetadata {
                    content_hash: wf_core::hash::sha256_bytes(text.as_bytes()),
                    payload: serde_json::to_value(&def)?,
                    ..Default::default()
                },
            });
        }
        Ok(out)
    }

    fn render(&self, item: &ResourceItem, agent: &dyn TeamAIAdapter) -> Result<Option<Rendered>> {
        let (Some(format), Some(dir)) = (agent.formats().agent, agent.path(PathKind::Agents))
        else {
            return Ok(None);
        };
        let def: SubagentDef = serde_json::from_value(item.metadata.payload.clone())?;
        let (ext, text) = render_agent(format, &def)?;
        Ok(Some(Rendered::File {
            path: dir.join(format!("{}.{ext}", def.name)),
            bytes: text.into_bytes(),
        }))
    }

    fn shape(&self, agent: &dyn TeamAIAdapter) -> Option<Shape> {
        agent.path(PathKind::Agents)?;
        self.stored_shape(agent)
    }

    fn stored_shape(&self, agent: &dyn TeamAIAdapter) -> Option<Shape> {
        agent.formats().agent?;
        Some(Shape::File)
    }
}
