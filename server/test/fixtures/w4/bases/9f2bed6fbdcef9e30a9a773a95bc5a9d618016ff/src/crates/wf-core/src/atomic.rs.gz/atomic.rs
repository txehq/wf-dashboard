use std::io::Write;
use std::path::Path;

/// Write a file so that a reader sees either the old bytes or the new bytes, never a
/// truncated file and never a missing one.
///
/// The temp file is created in the *destination directory*, not in /tmp: a rename across
/// filesystems is a copy, and a copy is exactly the non-atomic write this exists to avoid.
/// The directory fsync after the rename is what makes the new name survive a power loss —
/// without it the data is durable and the name is not.
pub fn write_file(path: &Path, contents: &[u8]) -> crate::Result<()> {
    let dir = path.parent().ok_or_else(|| {
        crate::Error::usage(
            "ATOMIC-NO-PARENT",
            format!("{}: no parent directory", path.display()),
        )
    })?;
    std::fs::create_dir_all(dir)?;
    let mut tmp = tempfile::Builder::new()
        .prefix(".wf-tmp-")
        .tempfile_in(dir)
        .map_err(|e| {
            crate::Error::from(e).with_zh(format!(
                "无法在 {} 写入临时文件。请确认该目录可写、磁盘还有空间。",
                dir.display()
            ))
        })?;
    tmp.write_all(contents)?;
    tmp.as_file_mut().sync_all()?;
    tmp.persist(path).map_err(|e| crate::Error::from(e.error))?;
    sync_dir(dir)?;
    Ok(())
}

/// Replace a file, preserving its mode. Used for the binary self-update, where losing the
/// executable bit would leave the operator with a `wf` that cannot start.
pub fn replace_preserving_mode(dest: &Path, src: &Path) -> crate::Result<()> {
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let mode = std::fs::metadata(dest)
            .map(|m| m.permissions().mode())
            .unwrap_or(0o755);
        std::fs::set_permissions(src, std::fs::Permissions::from_mode(mode))?;
    }
    let dir = dest.parent().unwrap_or_else(|| Path::new("."));
    std::fs::rename(src, dest)?;
    sync_dir(dir)?;
    Ok(())
}

pub fn sync_dir(dir: &Path) -> crate::Result<()> {
    // Best effort on platforms where opening a directory for sync is not supported;
    // required where it is.
    if let Ok(f) = std::fs::File::open(dir) {
        let _ = f.sync_all();
    }
    Ok(())
}

/// Point `link` at `target` atomically. Used for the `active` generation pointer, which is
/// the one byte that decides which release a session is running: it must switch in a single
/// step or a crash mid-update leaves a machine with no active generation at all.
pub fn swap_symlink(link: &Path, target: &Path) -> crate::Result<()> {
    let dir = link.parent().ok_or_else(|| {
        crate::Error::usage("ATOMIC-NO-PARENT", format!("{}: no parent", link.display()))
    })?;
    std::fs::create_dir_all(dir)?;
    let tmp = dir.join(format!(".wf-link-{}", std::process::id()));
    let _ = std::fs::remove_file(&tmp);
    #[cfg(unix)]
    std::os::unix::fs::symlink(target, &tmp)?;
    #[cfg(not(unix))]
    std::fs::write(&tmp, target.to_string_lossy().as_bytes())?;
    std::fs::rename(&tmp, link)?;
    sync_dir(dir)?;
    Ok(())
}

pub fn read_symlink(link: &Path) -> Option<std::path::PathBuf> {
    #[cfg(unix)]
    {
        std::fs::read_link(link).ok()
    }
    #[cfg(not(unix))]
    {
        std::fs::read_to_string(link)
            .ok()
            .map(std::path::PathBuf::from)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_failed_write_leaves_the_old_bytes() {
        let d = tempfile::tempdir().unwrap();
        let p = d.path().join("f");
        write_file(&p, b"old").unwrap();
        write_file(&p, b"new").unwrap();
        assert_eq!(std::fs::read(&p).unwrap(), b"new");
        // No temp files left behind.
        let strays: Vec<_> = std::fs::read_dir(d.path())
            .unwrap()
            .filter_map(|e| e.ok())
            .filter(|e| e.file_name().to_string_lossy().starts_with(".wf-tmp-"))
            .collect();
        assert!(strays.is_empty(), "left {} temp files", strays.len());
    }

    #[test]
    fn symlink_swap_is_observable_as_one_step() {
        let d = tempfile::tempdir().unwrap();
        std::fs::create_dir_all(d.path().join("a")).unwrap();
        std::fs::create_dir_all(d.path().join("b")).unwrap();
        let link = d.path().join("active");
        swap_symlink(&link, &d.path().join("a")).unwrap();
        assert!(read_symlink(&link).unwrap().ends_with("a"));
        swap_symlink(&link, &d.path().join("b")).unwrap();
        assert!(read_symlink(&link).unwrap().ends_with("b"));
    }
}
