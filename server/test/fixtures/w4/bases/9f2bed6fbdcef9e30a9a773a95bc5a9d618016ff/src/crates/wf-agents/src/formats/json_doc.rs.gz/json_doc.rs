//! Key-level surgery on a JSON document a person also edits.
//!
//! The contract is WFR-015's: `wf` owns named keys and nothing else. A document that does not
//! parse is refused — never "repaired" into an object holding only our keys — and a document
//! whose value did not change is returned byte for byte, so a no-op edit is not a write.

use serde_json::{Map, Value};
use std::path::Path;
use wf_core::{Error, Result};

/// Parse `text` as a JSON object. Empty text is an empty object.
pub fn parse_object(text: &str, path: &Path) -> Result<Value> {
    if text.trim().is_empty() {
        return Ok(Value::Object(Map::new()));
    }
    let doc: Value = serde_json::from_str(text).map_err(|e| {
        Error::conflict(
            "JSON-PARSE",
            format!("{} cannot be merged: {e}", path.display()),
        )
        .with_zh(format!(
            "{} 不是合法的 JSON，wf 没有改动它。请先修好这个文件再运行一次。",
            path.display()
        ))
    })?;
    if !doc.is_object() {
        return Err(Error::conflict(
            "JSON-SHAPE",
            format!("{} is not a JSON object", path.display()),
        ));
    }
    Ok(doc)
}

pub fn get<'a>(doc: &'a Value, keys: &[String]) -> Option<&'a Value> {
    keys.iter()
        .try_fold(doc, |node, key| node.as_object()?.get(key))
}

/// Set `keys` to `value`, creating intermediate objects. An intermediate that exists and is
/// not an object is a conflict: overwriting it would destroy somebody's configuration.
pub fn set(doc: &mut Value, keys: &[String], value: Value, path: &Path) -> Result<()> {
    let Some((last, parents)) = keys.split_last() else {
        *doc = value;
        return Ok(());
    };
    let mut node = doc;
    for key in parents {
        let obj = node
            .as_object_mut()
            .ok_or_else(|| shape_conflict(path, keys))?;
        node = obj
            .entry(key.clone())
            .or_insert_with(|| Value::Object(Map::new()));
    }
    let obj = node
        .as_object_mut()
        .ok_or_else(|| shape_conflict(path, keys))?;
    obj.insert(last.clone(), value);
    Ok(())
}

fn shape_conflict(path: &Path, keys: &[String]) -> Error {
    Error::conflict(
        "JSON-SHAPE",
        format!(
            "{}: {} is inside something that is not an object",
            path.display(),
            keys.join(".")
        ),
    )
}

/// Remove the leaf at `keys`. Parents are left as they are, empty or not.
pub fn remove(doc: &mut Value, keys: &[String]) -> bool {
    let Some((last, parents)) = keys.split_last() else {
        return false;
    };
    let mut node = doc;
    for key in parents {
        match node.as_object_mut().and_then(|o| o.get_mut(key)) {
            Some(next) => node = next,
            None => return false,
        }
    }
    node.as_object_mut()
        .is_some_and(|o| o.shift_remove(last).is_some())
}

/// Two-space pretty print with a trailing newline — the shape every agent writes itself.
pub fn render(doc: &Value) -> String {
    let mut text = serde_json::to_string_pretty(doc).expect("a JSON value renders");
    text.push('\n');
    text
}

/// `original` when `doc` still equals what `original` parses to, the rendering otherwise.
pub fn render_if_changed(original: &str, doc: &Value, path: &Path) -> Result<String> {
    if parse_object(original, path)? == *doc {
        return Ok(original.to_string());
    }
    Ok(render(doc))
}

/// A hash that ignores key order and whitespace: two spellings of one value hash the same.
pub fn canonical_hash(value: &Value) -> String {
    fn canonical(value: &Value) -> Value {
        match value {
            Value::Object(map) => {
                let sorted: std::collections::BTreeMap<&String, Value> =
                    map.iter().map(|(k, v)| (k, canonical(v))).collect();
                Value::Object(sorted.into_iter().map(|(k, v)| (k.clone(), v)).collect())
            }
            Value::Array(items) => Value::Array(items.iter().map(canonical).collect()),
            other => other.clone(),
        }
    }
    wf_core::hash::sha256_bytes(canonical(value).to_string().as_bytes())
}

#[cfg(test)]
mod tests {
    use super::*;
    use proptest::prelude::*;

    fn keys(k: &[&str]) -> Vec<String> {
        k.iter().map(|s| s.to_string()).collect()
    }

    fn p() -> &'static Path {
        Path::new("/x/settings.json")
    }

    #[test]
    fn empty_text_is_an_empty_object_and_anything_else_must_be_an_object() {
        assert_eq!(parse_object("", p()).unwrap(), serde_json::json!({}));
        assert_eq!(parse_object("  \n", p()).unwrap(), serde_json::json!({}));
        for bad in ["[]", "{broken", "// comment\n{}", "\"text\""] {
            let err = parse_object(bad, p()).unwrap_err();
            assert_eq!(err.code, wf_core::ExitCode::Conflict, "{bad}");
            assert!(err.message.contains("/x/settings.json"), "{}", err.message);
        }
    }

    #[test]
    fn set_creates_the_path_and_refuses_to_replace_a_non_object_parent() {
        let mut doc = parse_object(r#"{"theme":"dark"}"#, p()).unwrap();
        set(
            &mut doc,
            &keys(&["mcpServers", "capso-linear"]),
            serde_json::json!({"command":"npx"}),
            p(),
        )
        .unwrap();
        assert_eq!(
            get(&doc, &keys(&["mcpServers", "capso-linear", "command"])),
            Some(&serde_json::json!("npx"))
        );
        assert_eq!(doc["theme"], "dark");
        let mut bad = serde_json::json!({"mcpServers": ["not", "an", "object"]});
        assert_eq!(
            set(
                &mut bad,
                &keys(&["mcpServers", "x"]),
                serde_json::json!(1),
                p()
            )
            .unwrap_err()
            .code,
            wf_core::ExitCode::Conflict
        );
    }

    #[test]
    fn remove_takes_the_leaf_and_leaves_its_parent() {
        let mut doc = serde_json::json!({"mcpServers": {"a": 1, "b": 2}, "other": true});
        assert!(remove(&mut doc, &keys(&["mcpServers", "a"])));
        assert!(!remove(&mut doc, &keys(&["mcpServers", "a"])));
        assert!(!remove(&mut doc, &keys(&["nope", "a"])));
        assert!(remove(&mut doc, &keys(&["mcpServers", "b"])));
        assert_eq!(doc, serde_json::json!({"mcpServers": {}, "other": true}));
    }

    #[test]
    fn an_unchanged_document_keeps_its_bytes_and_a_changed_one_is_pretty_printed() {
        let original = "{\"b\": 1,   \"a\": {\"x\": [1,2]}}";
        let doc = parse_object(original, p()).unwrap();
        assert_eq!(render_if_changed(original, &doc, p()).unwrap(), original);
        let mut changed = doc.clone();
        set(&mut changed, &keys(&["c"]), serde_json::json!("new"), p()).unwrap();
        let text = render_if_changed(original, &changed, p()).unwrap();
        assert!(text.ends_with("}\n"));
        assert!(
            text.starts_with("{\n  \"b\": 1,"),
            "key order is preserved: {text}"
        );
    }

    #[test]
    fn the_canonical_hash_ignores_key_order_and_whitespace_but_not_values() {
        let a: Value = serde_json::from_str(r#"{"a":1,"b":{"c":[1,2],"d":"x"}}"#).unwrap();
        let b: Value =
            serde_json::from_str("{ \"b\": {\"d\": \"x\", \"c\": [1, 2]}, \"a\": 1 }").unwrap();
        let c: Value = serde_json::from_str(r#"{"a":1,"b":{"c":[2,1],"d":"x"}}"#).unwrap();
        assert_eq!(canonical_hash(&a), canonical_hash(&b));
        assert_ne!(canonical_hash(&a), canonical_hash(&c));
    }

    fn json_value() -> impl Strategy<Value = Value> {
        let leaf = prop_oneof![
            Just(Value::Null),
            any::<bool>().prop_map(Value::Bool),
            any::<i32>().prop_map(Value::from),
            "[a-z ]{0,6}".prop_map(Value::String),
        ];
        leaf.prop_recursive(3, 12, 4, |inner| {
            prop_oneof![
                prop::collection::vec(inner.clone(), 0..3).prop_map(Value::Array),
                prop::collection::btree_map("[a-z]{1,3}", inner, 0..4)
                    .prop_map(|m| Value::Object(m.into_iter().collect())),
            ]
        })
    }

    proptest! {
        /// Everything outside the owned key survives a set-then-remove round trip, and a
        /// second identical set is not a change.
        #[test]
        fn keys_outside_the_owned_one_are_untouched(
            base in prop::collection::btree_map("[a-z]{1,3}", json_value(), 0..5),
            owned in json_value(),
        ) {
            let mut doc = Value::Object(base.into_iter().collect());
            if let Some(obj) = doc.as_object_mut() {
                obj.remove("wfowned");
            }
            let before = doc.clone();
            let k = keys(&["wfowned", "server"]);
            set(&mut doc, &k, owned.clone(), p()).unwrap();
            let once = render(&doc);
            let mut again = parse_object(&once, p()).unwrap();
            set(&mut again, &k, owned, p()).unwrap();
            prop_assert_eq!(render_if_changed(&once, &again, p()).unwrap(), once);
            prop_assert!(remove(&mut doc, &k));
            doc.as_object_mut().unwrap().remove("wfowned");
            prop_assert_eq!(doc, before);
        }
    }
}
