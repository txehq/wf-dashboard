-- 003 — the MCP servers a person told wf not to install.
--
-- Additive only, like 002, and for the same reason: `wf rollback` has to be able to hand the
-- database to an older release. A binary that predates this table never reads it and so never
-- learns of the decision — it would install the server the person declined. That is a
-- downgrade putting back something the operator removed, which is recoverable by running the
-- newer binary again; it is not a misread of something the older binary already knows, which
-- is what `meta.schema` refuses over.
--
-- One row is one decision about one server on one agent. The decision is per agent on
-- purpose: a person may already hold Linear inside Claude Code and want wf's copy in Codex,
-- and a machine-wide record could not express that.
--
-- Nothing of the connection that prompted the question is stored. `host` is **our** published
-- host, the one from our own definition, never a value read out of somebody's document; there
-- is no column for their server's name, and there cannot be one (WFR-016, WFR-018).
-- The key is the registry's component id (`capso.mcp.linear`), not the server's name inside
-- the document (`capso-linear`). Every other table, every doctor line and every step in the
-- install report is keyed that way, and a record that has to be translated before it can be
-- joined is a record that will one day be joined wrongly.
CREATE TABLE IF NOT EXISTS skipped_mcps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id TEXT NOT NULL,
    component_id TEXT NOT NULL,        -- e.g. capso.mcp.linear
    skipped_at TEXT NOT NULL,          -- fixed-width UTC text, as in 002
    reason TEXT,                       -- why, in the person's terms; shown by doctor
    host TEXT,                         -- our own published host at the time of the decision
    source TEXT NOT NULL,              -- who recorded it: user | install
    UNIQUE(agent_id, component_id)
);
CREATE INDEX IF NOT EXISTS skipped_mcps_by_agent ON skipped_mcps(agent_id);
