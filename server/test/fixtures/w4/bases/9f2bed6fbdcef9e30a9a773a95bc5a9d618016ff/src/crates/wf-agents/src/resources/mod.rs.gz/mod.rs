//! Resource handlers: one per kind of thing `wf` deploys into an agent.
//!
//! A handler knows two things about its kind: how to read it out of the team repository
//! ([`ResourceHandler::scan_registry`]) and how to render one item for one agent
//! ([`ResourceHandler::render`]). Everything else — reading what is on disk, diffing,
//! writing, removing, recording ownership — is the same for every kind, because every
//! rendered object is one of a handful of [`object::Rendered`] shapes.

pub mod agents;
pub mod docs;
pub mod env;
pub mod hooks;
pub mod mcp;
pub mod object;
pub mod prompts;
pub mod rules;
pub mod skills;

use crate::adapter::TeamAIAdapter;
use crate::team_repo::TeamRepo;
use object::{Placement, Rendered, Shape};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::path::PathBuf;
use wf_core::Result;
use wf_state::{ManagedResource, Transaction};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum ResourceKind {
    Skill,
    Rule,
    Hook,
    Mcp,
    Doc,
    Env,
    Agent,
    Prompt,
}

impl ResourceKind {
    pub const ALL: [ResourceKind; 8] = [
        ResourceKind::Skill,
        ResourceKind::Rule,
        ResourceKind::Hook,
        ResourceKind::Mcp,
        ResourceKind::Doc,
        ResourceKind::Env,
        ResourceKind::Agent,
        ResourceKind::Prompt,
    ];

    pub fn as_str(self) -> &'static str {
        match self {
            ResourceKind::Skill => "skill",
            ResourceKind::Rule => "rule",
            ResourceKind::Hook => "hook",
            ResourceKind::Mcp => "mcp",
            ResourceKind::Doc => "doc",
            ResourceKind::Env => "env",
            ResourceKind::Agent => "agent",
            ResourceKind::Prompt => "prompt",
        }
    }

    pub fn parse(text: &str) -> Option<Self> {
        Self::ALL.into_iter().find(|k| k.as_str() == text)
    }
}

/// One resource: format independent when it comes out of the team repository, and carrying
/// its rendered hash once it has been rendered for an agent or read back from one.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResourceItem {
    /// Unique within its kind: a skill name, a rule path, a server name, a component id.
    pub id: String,
    pub name: String,
    pub kind: ResourceKind,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub version: Option<String>,
    /// Where the canonical bytes are, in the team repository.
    pub source: PathBuf,
    pub metadata: ResourceMetadata,
}

#[derive(Debug, Clone, Default, PartialEq, Serialize, Deserialize)]
pub struct ResourceMetadata {
    /// The hash diffs compare. For an item read out of the team repository it covers the
    /// source; for a rendered or deployed item it covers the object as written.
    pub content_hash: String,
    /// The registry component this came from, when it came from the registry.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub component_id: Option<String>,
    /// Where the object lives, when this item describes a deployed or rendered object.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub placement: Option<String>,
    /// The parsed definition (a server, a hook, a variable set); kind specific.
    #[serde(default, skip_serializing_if = "Value::is_null")]
    pub payload: Value,
}

impl ResourceItem {
    /// The id receipts and plans name this object by: its registry component when it has
    /// one, `team.<kind>.<id>` otherwise.
    pub fn component_id(&self) -> String {
        self.metadata
            .component_id
            .clone()
            .unwrap_or_else(|| format!("team.{}.{}", self.kind.as_str(), self.id))
    }
}

/// What it takes to go from `local` to `registry`.
#[derive(Debug, Clone, Default, PartialEq, Serialize)]
pub struct ResourceDiff {
    /// In the registry, not deployed.
    pub added: Vec<ResourceItem>,
    /// Deployed, but not as the registry has it now.
    pub modified: Vec<ResourceItem>,
    /// Deployed, and no longer in the registry.
    pub removed: Vec<String>,
}

impl ResourceDiff {
    pub fn is_empty(&self) -> bool {
        self.added.is_empty() && self.modified.is_empty() && self.removed.is_empty()
    }
}

/// Compare by id and content hash. `added` and `modified` keep registry order, `removed`
/// keeps local order, so a plan reads in the order its sources are declared.
pub fn diff(local: &[ResourceItem], registry: &[ResourceItem]) -> ResourceDiff {
    let mut out = ResourceDiff::default();
    for wanted in registry {
        match local.iter().find(|have| have.id == wanted.id) {
            None => out.added.push(wanted.clone()),
            Some(have) if have.metadata.content_hash != wanted.metadata.content_hash => {
                out.modified.push(wanted.clone())
            }
            Some(_) => {}
        }
    }
    out.removed = local
        .iter()
        .filter(|have| !registry.iter().any(|wanted| wanted.id == have.id))
        .map(|have| have.id.clone())
        .collect();
    out
}

/// One kind of resource.
pub trait ResourceHandler: Send + Sync {
    fn kind(&self) -> ResourceKind;

    /// What the team repository says should be deployed, format independent.
    fn scan_registry(&self, repo: &TeamRepo) -> Result<Vec<ResourceItem>>;

    /// `item` as it would be written into `agent`, or `None` when this agent does not take
    /// it (no path, no format, an event or transport the format cannot express). Refusals a
    /// person should hear about are errors: [`POLICY_SKIP`] keeps what is there,
    /// [`POLICY_REFUSED`] retires it, anything else blocks the object.
    fn render(&self, item: &ResourceItem, agent: &dyn TeamAIAdapter) -> Result<Option<Rendered>>;

    /// How this kind's objects sit in `agent`, or `None` when the agent does not take the kind.
    fn shape(&self, agent: &dyn TeamAIAdapter) -> Option<Shape>;

    /// How to find an object of this kind wf already put in `agent`, knowing only what the
    /// ownership row recorded. An agent that stopped taking the kind still has to be able to
    /// take back what it wrote, so this reads the agent's formats and ignores its paths.
    fn stored_shape(&self, agent: &dyn TeamAIAdapter) -> Option<Shape> {
        self.shape(agent)
    }

    /// Whether an object of this kind proves it is wf's by what it contains (a managed block's
    /// markers, a hook's `wf hook` command), so an exact copy with no row is adopted.
    fn marker_owned(&self) -> bool {
        false
    }

    /// What wf owns of this kind in `agent`, read back from disk. An owned object that is
    /// no longer there is left out: to a diff, gone is gone.
    fn scan_local(
        &self,
        agent: &dyn TeamAIAdapter,
        owned: &[ManagedResource],
    ) -> Result<Vec<ResourceItem>> {
        let Some(shape) = self.stored_shape(agent) else {
            return Ok(vec![]);
        };
        let mut out = Vec::new();
        for row in owned
            .iter()
            .filter(|r| r.agent_id == agent.id() && r.resource_kind == self.kind().as_str())
        {
            if let object::Probe::Present(hash) =
                object::probe(shape.clone(), &Placement::parse(&row.deployed_path))?
            {
                out.push(owned_item(self.kind(), row, hash));
            }
        }
        Ok(out)
    }

    fn diff(&self, local: &[ResourceItem], registry: &[ResourceItem]) -> ResourceDiff {
        diff(local, registry)
    }

    /// Write `item` into `agent` and record ownership. Returns whether anything changed.
    fn deploy(
        &self,
        item: &ResourceItem,
        agent: &dyn TeamAIAdapter,
        tx: &mut Transaction<'_>,
    ) -> Result<bool> {
        let Some(rendered) = self.render(item, agent)? else {
            return Ok(false);
        };
        let changed = rendered.write(&item.component_id(), tx)?;
        tx.record_resource(ownership(agent, item, &rendered)?);
        Ok(changed)
    }

    /// Remove an object wf deployed and forget it. Returns whether anything changed.
    fn remove(
        &self,
        item: &ResourceItem,
        agent: &dyn TeamAIAdapter,
        tx: &mut Transaction<'_>,
    ) -> Result<bool> {
        let changed = match (self.stored_shape(agent), placement_of(item)) {
            (Some(shape), Some(placement)) => {
                object::erase(shape, &placement, &item.component_id(), tx)?
            }
            _ => false,
        };
        tx.forget_resource(agent.id(), self.kind().as_str(), &item.id);
        Ok(changed)
    }
}

/// A render refusal that leaves an existing object in place (`auto_apply: false`).
pub const POLICY_SKIP: &str = "POLICY-SKIP";
/// A render refusal that retires an existing object: the policy forbids it.
pub const POLICY_REFUSED: &str = "POLICY-REFUSED";

/// The ownership row for `item` rendered into `agent`.
pub fn ownership(
    agent: &dyn TeamAIAdapter,
    item: &ResourceItem,
    rendered: &Rendered,
) -> Result<ManagedResource> {
    Ok(ManagedResource {
        agent_id: agent.id().to_string(),
        resource_kind: item.kind.as_str().to_string(),
        resource_id: item.id.clone(),
        source_path: item.source.to_string_lossy().into_owned(),
        deployed_path: rendered.placement().render(),
        content_hash: rendered.hash()?,
        deployed_at: wf_core::time_fmt::now_utc_millis(),
    })
}

/// An ownership row as an item: what wf wrote, where, and the hash it has now.
pub fn owned_item(kind: ResourceKind, row: &ManagedResource, hash: String) -> ResourceItem {
    ResourceItem {
        id: row.resource_id.clone(),
        name: row.resource_id.clone(),
        kind,
        version: None,
        source: PathBuf::from(&row.source_path),
        metadata: ResourceMetadata {
            content_hash: hash,
            component_id: None,
            placement: Some(row.deployed_path.clone()),
            payload: Value::Null,
        },
    }
}

/// The registry agents a registry-sourced item names, if it came from the registry.
pub fn targets_of(item: &ResourceItem) -> Option<Vec<String>> {
    item.metadata.payload.get("targets").and_then(|t| {
        t.as_array().map(|a| {
            a.iter()
                .filter_map(|v| v.as_str().map(String::from))
                .collect()
        })
    })
}

/// A registry component as the fields every registry-sourced item carries.
pub(crate) fn registry_payload(
    component: &wf_registry::Component,
) -> serde_json::Map<String, Value> {
    let mut payload = serde_json::Map::new();
    payload.insert(
        "targets".into(),
        component
            .targets
            .iter()
            .map(|t| t.agent().as_str().to_string())
            .collect::<Vec<_>>()
            .into(),
    );
    payload
}

/// Every file under `dir`, as forward-slashed paths relative to it, sorted.
pub(crate) fn files_under(dir: &std::path::Path) -> Result<Vec<String>> {
    if !dir.is_dir() {
        return Ok(vec![]);
    }
    Ok(wf_core::hash::tree_entries(dir)?
        .into_iter()
        .map(|e| e.path)
        .collect())
}

/// The handler for a kind.
pub fn handler(kind: ResourceKind) -> &'static dyn ResourceHandler {
    match kind {
        ResourceKind::Skill => &skills::SkillsHandler,
        ResourceKind::Rule => &rules::RulesHandler,
        ResourceKind::Hook => &hooks::HooksHandler,
        ResourceKind::Mcp => &mcp::McpHandler,
        ResourceKind::Doc => &docs::DocsHandler,
        ResourceKind::Env => &env::EnvHandler,
        ResourceKind::Agent => &agents::AgentsHandler,
        ResourceKind::Prompt => &prompts::PromptsHandler,
    }
}

fn placement_of(item: &ResourceItem) -> Option<Placement> {
    item.metadata.placement.as_deref().map(Placement::parse)
}

#[cfg(test)]
mod tests {
    use super::*;
    use proptest::prelude::*;

    fn item(id: &str, hash: &str) -> ResourceItem {
        ResourceItem {
            id: id.into(),
            name: id.into(),
            kind: ResourceKind::Skill,
            version: None,
            source: PathBuf::from(format!("skills/{id}")),
            metadata: ResourceMetadata {
                content_hash: hash.into(),
                ..Default::default()
            },
        }
    }

    fn ids(items: &[ResourceItem]) -> Vec<&str> {
        items.iter().map(|i| i.id.as_str()).collect()
    }

    #[test]
    fn a_diff_names_what_to_add_update_and_remove() {
        let local = [item("a", "1"), item("b", "1"), item("c", "1")];
        let registry = [item("d", "1"), item("b", "2"), item("a", "1")];
        let d = diff(&local, &registry);
        assert_eq!(ids(&d.added), ["d"]);
        assert_eq!(ids(&d.modified), ["b"]);
        assert_eq!(
            d.modified[0].metadata.content_hash, "2",
            "the registry side is what gets deployed"
        );
        assert_eq!(d.removed, ["c"]);
        assert!(!d.is_empty());
        assert!(diff(&registry, &registry).is_empty());
    }

    #[test]
    fn component_ids_fall_back_to_a_team_namespace() {
        let mut i = item("security/secrets", "1");
        i.kind = ResourceKind::Rule;
        assert_eq!(i.component_id(), "team.rule.security/secrets");
        i.metadata.component_id = Some("capso.skill.lfg".into());
        assert_eq!(i.component_id(), "capso.skill.lfg");
    }

    #[test]
    fn every_kind_has_a_handler_that_answers_to_it() {
        for kind in ResourceKind::ALL {
            assert_eq!(handler(kind).kind(), kind);
            assert_eq!(ResourceKind::parse(kind.as_str()), Some(kind));
        }
    }

    fn side() -> impl Strategy<Value = Vec<ResourceItem>> {
        prop::collection::btree_map("[a-e]", "[0-2]", 0..5)
            .prop_map(|m| m.into_iter().map(|(id, hash)| item(&id, &hash)).collect())
    }

    /// Apply a diff the way the engine does: remove, update, add.
    fn apply(local: &[ResourceItem], d: &ResourceDiff) -> Vec<ResourceItem> {
        let mut out: Vec<ResourceItem> = local
            .iter()
            .filter(|i| !d.removed.contains(&i.id))
            .cloned()
            .collect();
        for m in &d.modified {
            let slot = out
                .iter_mut()
                .find(|i| i.id == m.id)
                .expect("modified exists");
            *slot = m.clone();
        }
        out.extend(d.added.iter().cloned());
        out
    }

    fn sorted(mut v: Vec<ResourceItem>) -> Vec<(String, String)> {
        v.sort_by(|a, b| a.id.cmp(&b.id));
        v.into_iter()
            .map(|i| (i.id, i.metadata.content_hash))
            .collect()
    }

    proptest! {
        /// A→B and B→A are mirror images: what one adds the other removes, and both see
        /// the same objects as changed.
        #[test]
        fn a_diff_and_its_reverse_are_mirror_images(a in side(), b in side()) {
            let there = diff(&a, &b);
            let back = diff(&b, &a);
            let mut added: Vec<&str> = ids(&there.added);
            added.sort();
            let mut removed: Vec<&str> = back.removed.iter().map(String::as_str).collect();
            removed.sort();
            prop_assert_eq!(added, removed);
            let mut m1 = ids(&there.modified);
            m1.sort();
            let mut m2 = ids(&back.modified);
            m2.sort();
            prop_assert_eq!(m1, m2);
        }

        /// Applying A→B to A reaches B, after which there is nothing left to do.
        #[test]
        fn applying_a_diff_converges_and_then_there_is_nothing_to_do(a in side(), b in side()) {
            let reached = apply(&a, &diff(&a, &b));
            prop_assert_eq!(sorted(reached.clone()), sorted(b.clone()));
            prop_assert!(diff(&reached, &b).is_empty());
        }
    }
}
