//! The GitHub half: resolve a release, verify it, download its assets, verify those.
//!
//! Everything here goes through `gh`, never through a token this process holds. That is the
//! whole credential design (D-008): `wf` has no secret to leak because it never has one.
//! It also means the failure everyone will actually hit is "your `gh` login expired", which
//! is why the errors in this module are written as instructions rather than diagnoses.

use serde::Deserialize;
use std::path::Path;
use std::time::Duration;
use wf_core::{proc, Error, Result};

/// How long a network call may take when a human is waiting. Session-start callers pass
/// their own, much shorter, deadline.
const DEFAULT_TIMEOUT: Duration = Duration::from_secs(60);

#[derive(Debug, Deserialize)]
pub struct ApiRelease {
    pub tag_name: String,
    #[serde(default)]
    pub draft: bool,
    #[serde(default)]
    pub prerelease: bool,
    #[serde(default)]
    pub immutable: bool,
    #[serde(default)]
    pub assets: Vec<ApiAsset>,
}

#[derive(Debug, Deserialize)]
pub struct ApiAsset {
    pub name: String,
    #[serde(default)]
    pub digest: Option<String>,
    #[serde(default)]
    pub size: u64,
}

impl ApiAsset {
    /// The API returns `sha256:<hex>`; the lock stores bare hex.
    pub fn sha256(&self) -> Option<&str> {
        self.digest.as_deref()?.strip_prefix("sha256:")
    }
}

pub struct Gh {
    program: String,
    pub repo: String,
    pub timeout: Duration,
}

impl Gh {
    pub fn new(repo: impl Into<String>) -> Self {
        Self {
            program: "gh".into(),
            repo: repo.into(),
            timeout: DEFAULT_TIMEOUT,
        }
    }

    pub fn with_timeout(mut self, d: Duration) -> Self {
        self.timeout = d;
        self
    }

    /// Is `gh` installed and logged in, and can this account see the repository?
    ///
    /// The three failures are separated because the fix is different for each, and this is
    /// an internal tool: everyone running it is supposed to have access, so "you are not
    /// authorised" is almost always really "you are logged in as the wrong account".
    pub fn preflight(&self) -> Result<()> {
        if proc::which(&self.program).is_none() {
            return Err(Error::failure("GH-MISSING", "gh is not installed")
                .with_zh(wf_core::zh::gh_missing()));
        }
        let auth = proc::run(&self.program, &["auth", "status"], self.timeout)?;
        if !auth.ok() {
            return Err(Error::failure("GH-NOT-LOGGED-IN", "gh auth status failed")
                .with_zh(wf_core::zh::gh_not_logged_in()));
        }
        let probe = proc::run(
            &self.program,
            &["api", &format!("repos/{}", self.repo), "--jq", ".full_name"],
            self.timeout,
        )?;
        if !probe.ok() {
            return Err(Error::failure(
                "REPO-UNREADABLE",
                format!("cannot read repos/{} as the current gh account", self.repo),
            )
            .with_zh(wf_core::zh::repo_unreadable(&self.repo)));
        }
        Ok(())
    }

    /// The newest release on a channel, or nothing.
    ///
    /// `stable` means non-draft, non-prerelease *and* immutable. The immutability
    /// requirement is load-bearing: without it, "verified" would mean only that the bytes
    /// match a digest that whoever published them could rewrite tomorrow.
    pub fn latest(&self, channel: crate::Channel) -> Result<Option<ApiRelease>> {
        let out = proc::run(
            &self.program,
            &["api", &format!("repos/{}/releases?per_page=30", self.repo)],
            self.timeout,
        )?;
        if !out.ok() {
            return Err(self.classify(&out));
        }
        let releases: Vec<ApiRelease> = serde_json::from_str(&out.stdout).map_err(|e| {
            Error::failure("GH-API-SHAPE", format!("unexpected releases payload: {e}"))
        })?;
        Ok(releases.into_iter().find(|r| match channel {
            crate::Channel::Stable => !r.draft && !r.prerelease && r.immutable,
            crate::Channel::Canary => !r.draft && r.immutable,
        }))
    }

    pub fn release(&self, tag: &str) -> Result<ApiRelease> {
        self.release_at(&format!("repos/{}/releases/tags/{tag}", self.repo))
    }

    /// The release GitHub marks latest: non-draft, non-prerelease, immutable or not.
    ///
    /// Only for an upstream whose bytes the lock pins by digest (ctx). Never for this
    /// repository's own releases, which must come through [`Gh::latest`].
    pub fn latest_published(&self) -> Result<ApiRelease> {
        self.release_at(&format!("repos/{}/releases/latest", self.repo))
    }

    fn release_at(&self, endpoint: &str) -> Result<ApiRelease> {
        let out = proc::run(&self.program, &["api", endpoint], self.timeout)?;
        if !out.ok() {
            return Err(self.classify(&out));
        }
        serde_json::from_str(&out.stdout)
            .map_err(|e| Error::failure("GH-API-SHAPE", format!("unexpected release payload: {e}")))
    }

    /// `gh release verify` — the release exists and is immutable.
    ///
    /// A `gh` too old to have the subcommand is reported as unverified rather than as a
    /// pass. Treating "I could not check" as "it checked out" is the one failure mode a
    /// verification step must not have.
    pub fn verify_release(&self, tag: &str) -> Result<()> {
        let out = proc::run(
            &self.program,
            &["release", "verify", tag, "-R", &self.repo],
            self.timeout,
        )?;
        if out.ok() {
            return Ok(());
        }
        Err(Error::integrity(
            "RELEASE-UNVERIFIED",
            format!(
                "gh release verify {tag} failed: {}",
                first_line(&out.stderr)
            ),
        )
        .with_zh(wf_core::zh::integrity_failed()))
    }

    pub fn verify_asset(&self, tag: &str, path: &Path) -> Result<()> {
        let p = path.to_string_lossy().into_owned();
        let out = proc::run(
            &self.program,
            &["release", "verify-asset", tag, &p, "-R", &self.repo],
            self.timeout,
        )?;
        if out.ok() {
            return Ok(());
        }
        Err(Error::integrity(
            "ASSET-UNVERIFIED",
            format!(
                "gh release verify-asset {} failed: {}",
                path.display(),
                first_line(&out.stderr)
            ),
        )
        .with_zh(wf_core::zh::integrity_failed()))
    }

    pub fn download(&self, tag: &str, asset: &str, into: &Path) -> Result<std::path::PathBuf> {
        std::fs::create_dir_all(into)?;
        let dir = into.to_string_lossy().into_owned();
        let out = proc::run(
            &self.program,
            &[
                "release",
                "download",
                tag,
                "-R",
                &self.repo,
                "-p",
                asset,
                "-D",
                &dir,
                "--clobber",
            ],
            self.timeout,
        )?;
        if !out.ok() {
            return Err(self.classify(&out));
        }
        let p = into.join(asset);
        if !p.is_file() {
            return Err(Error::failure(
                "ASSET-MISSING",
                format!("{asset} is not in release {tag}"),
            )
            .with_zh(format!(
                "这个版本里没有 {asset}。请联系团队重新发一次版本。"
            )));
        }
        Ok(p)
    }

    /// The commit a tag points at — checked against the lock's `source_commit`, so a
    /// release built from a different tree than the tag claims cannot install.
    pub fn tag_commit(&self, tag: &str) -> Result<String> {
        let mut endpoint = format!("repos/{}/git/ref/tags/{tag}", self.repo);
        let mut seen = std::collections::HashSet::new();
        for _ in 0..16 {
            let out = proc::run(&self.program, &["api", &endpoint], self.timeout)?;
            if !out.ok() {
                return Err(self.classify(&out));
            }
            let value: serde_json::Value = serde_json::from_str(&out.stdout)
                .map_err(|e| Error::integrity("TAG-SHAPE", e.to_string()))?;
            let object = &value["object"];
            let sha = object["sha"].as_str().unwrap_or_default();
            if sha.len() != 40
                || !sha.bytes().all(|b| b.is_ascii_hexdigit())
                || !seen.insert(sha.to_string())
            {
                return Err(Error::integrity(
                    "TAG-SHAPE",
                    "invalid or cyclic tag object",
                ));
            }
            match object["type"].as_str() {
                Some("commit") => return Ok(sha.to_string()),
                Some("tag") => endpoint = format!("repos/{}/git/tags/{sha}", self.repo),
                _ => {
                    return Err(Error::integrity(
                        "TAG-SHAPE",
                        "tag does not resolve to a commit",
                    ))
                }
            }
        }
        Err(Error::integrity(
            "TAG-SHAPE",
            "tag nesting exceeds 16 objects",
        ))
    }

    /// Turn a `gh` failure into the sentence that tells the operator what to do.
    fn classify(&self, out: &proc::Output) -> Error {
        let s = format!("{}{}", out.stdout, out.stderr);
        if out.timed_out {
            return Error::failure("GH-TIMEOUT", "gh timed out")
                .with_zh("连接 GitHub 超时了。请检查网络后再试一次。".to_string());
        }
        if s.contains("gh auth login")
            || s.contains("authentication")
            || s.contains("Bad credentials")
        {
            return Error::failure("GH-NOT-LOGGED-IN", "gh is not authenticated")
                .with_zh(wf_core::zh::gh_not_logged_in());
        }
        if s.contains("Not Found")
            || s.contains("404")
            || s.contains("HTTP 403")
            || s.contains("Resource not accessible")
        {
            return Error::failure(
                "REPO-UNREADABLE",
                format!("repos/{} not readable", self.repo),
            )
            .with_zh(wf_core::zh::repo_unreadable(&self.repo));
        }
        Error::failure("GH", first_line(&s).to_string()).with_zh(
            "和 GitHub 通信时出了点问题，稍后再试一次。如果一直不行，请把这条消息发给团队。"
                .to_string(),
        )
    }
}

fn first_line(s: &str) -> &str {
    s.lines()
        .find(|l| !l.trim().is_empty())
        .unwrap_or("")
        .trim()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn fake_gh(body: &str) -> (tempfile::TempDir, Gh) {
        use std::os::unix::fs::PermissionsExt;
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("gh");
        std::fs::write(&path, format!("#!/bin/sh\n{body}\n")).unwrap();
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o755)).unwrap();
        let mut gh = Gh::new("owner/repo");
        gh.program = path.to_string_lossy().into_owned();
        (dir, gh)
    }

    #[test]
    fn unavailable_attestation_is_an_error() {
        let (_dir, gh) = fake_gh("echo 'unknown command' >&2; exit 1");
        assert!(gh.verify_release("v1.0.0").is_err());
        assert!(gh.verify_asset("v1.0.0", Path::new("asset")).is_err());
    }

    #[test]
    fn mutable_releases_do_not_shadow_installable_releases() {
        let (_dir, gh) = fake_gh(
            r#"echo '[{"tag_name":"v2.0.0","draft":false,"prerelease":false,"immutable":false},{"tag_name":"v1.0.0","draft":false,"prerelease":false,"immutable":true}]'"#,
        );
        for channel in [crate::Channel::Stable, crate::Channel::Canary] {
            assert_eq!(gh.latest(channel).unwrap().unwrap().tag_name, "v1.0.0");
        }
    }

    #[test]
    fn tag_lookup_errors_do_not_disable_source_binding() {
        let (_dir, gh) = fake_gh("echo 'network unavailable' >&2; exit 1");
        assert!(gh.tag_commit("v1.0.0").is_err());
    }

    #[test]
    fn annotated_tags_are_peeled_to_the_commit() {
        let tag = "a".repeat(40);
        let commit = "c".repeat(40);
        let script = format!("case \"$2\" in\n *git/ref/tags/*) echo '{{\"object\":{{\"type\":\"tag\",\"sha\":\"{tag}\"}}}}' ;;\n *git/tags/{tag}) echo '{{\"object\":{{\"type\":\"commit\",\"sha\":\"{commit}\"}}}}' ;;\n *) exit 1 ;;\nesac");
        let (_dir, gh) = fake_gh(&script);
        assert_eq!(gh.tag_commit("v1.0.0").unwrap(), commit);
    }

    #[test]
    fn a_digest_is_stripped_of_its_algorithm_prefix() {
        let a = ApiAsset {
            name: "x".into(),
            digest: Some(format!("sha256:{}", "a".repeat(64))),
            size: 1,
        };
        assert_eq!(a.sha256(), Some("a".repeat(64).as_str()));
        let b = ApiAsset {
            name: "x".into(),
            digest: None,
            size: 1,
        };
        assert_eq!(b.sha256(), None);
        // An algorithm we do not understand is not silently accepted as sha256.
        let c = ApiAsset {
            name: "x".into(),
            digest: Some("md5:deadbeef".into()),
            size: 1,
        };
        assert_eq!(c.sha256(), None);
    }

    #[test]
    fn an_expired_login_is_reported_as_an_instruction() {
        let gh = Gh::new("txehq/txe-workflow");
        let out = proc::Output {
            status: Some(1),
            stdout: String::new(),
            stderr: "gh: To get started with GitHub CLI, please run: gh auth login".into(),
            timed_out: false,
        };
        let e = gh.classify(&out);
        assert_eq!(e.kind, "GH-NOT-LOGGED-IN");
        assert!(e.zh.contains("gh auth login"), "{}", e.zh);
    }

    #[test]
    fn a_404_is_reported_as_the_wrong_account_not_as_a_permission_lecture() {
        let gh = Gh::new("txehq/txe-workflow");
        let out = proc::Output {
            status: Some(1),
            stdout: String::new(),
            stderr: "gh: Not Found (HTTP 404)".into(),
            timed_out: false,
        };
        let e = gh.classify(&out);
        assert_eq!(e.kind, "REPO-UNREADABLE");
        assert!(e.zh.contains("gh auth status"), "{}", e.zh);
    }
}
