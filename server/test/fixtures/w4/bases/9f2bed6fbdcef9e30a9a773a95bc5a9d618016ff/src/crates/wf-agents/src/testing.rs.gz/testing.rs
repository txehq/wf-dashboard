//! Fixtures shared by this crate's tests: a miniature team repository with one resource of
//! every kind, and a disposable machine to deploy it into. Nothing here touches a real home.

use crate::adapter::{ConfigAdapter, MachineAdapter};
use crate::policy::Policies;
use crate::registry::AgentRegistry;
use crate::team_repo::TeamRepo;
use std::path::{Path, PathBuf};

pub const REGISTRY: &str = r#"
schema_version: 2
organization: txehq
product: wf
plugin:
  id: capso.magi
  name: magi
  marketplace: capsohq
  description: fixture
components:
  - id: capso.skill.lfg
    kind: skill
    source: skills/lfg
    required: true
    targets: [claude-code, codex]
  - id: capso.prompt.global
    kind: prompt-block
    source: workflow/prompts/capso-global.md
    required: true
    targets:
      - agent: claude-code
        scope: user
        destination: effective-claude-md
      - agent: codex
        scope: user
        destination: effective-agents-md
  - id: capso.hook.session-start
    kind: hook-dispatcher
    required: true
    event: SessionStart
    executable: wf
    arguments: [hook, session-start]
    trust_contract: stable-definition
    targets: [claude-code, codex]
  - id: capso.hook.usage.post-tool-use
    kind: hook-dispatcher
    required: true
    event: PostToolUse
    executable: wf
    arguments: [hook, dispatch, --event, PostToolUse]
    trust_contract: stable-definition
    targets: [claude-code, codex]
  - id: capso.mcp.linear
    kind: mcp
    source: workflow/mcps/linear.yaml
    required: true
    targets: [claude-code, codex]
    credentials:
      mode: agent-oauth
      references: []
      values_forbidden: true
      login_host: mcp.linear.app
"#;

pub const TEAM_CONFIG: &str = r#"
schema_version: 1
team:
  name: TXE
  repo_mode: self-repo
self_repo:
  resources:
    rules: workflow/rules
    docs: workflow/docs
    env: workflow/env
    agents: workflow/agents
"#;

pub struct TeamFixture {
    pub dir: tempfile::TempDir,
}

impl TeamFixture {
    pub fn new() -> Self {
        let f = Self {
            dir: tempfile::tempdir().unwrap(),
        };
        f.write("workflow/registry.yaml", REGISTRY);
        f.write("workflow/teamai/team-config.yaml", TEAM_CONFIG);
        f.write(
            "workflow/teamai/agents.yaml",
            &std::fs::read_to_string(shipped("workflow/teamai/agents.yaml")).unwrap(),
        );
        f.write("workflow/teamai/policies.yaml", "schema_version: 1\n");
        f.write(
            "skills/lfg/SKILL.md",
            "---\nname: lfg\ndescription: fixture\n---\nGo.\n",
        );
        f.write("skills/lfg/scripts/run.py", "print('lfg')\n");
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            std::fs::set_permissions(
                f.path("skills/lfg/scripts/run.py"),
                std::fs::Permissions::from_mode(0o755),
            )
            .unwrap();
        }
        f.write(
            "workflow/prompts/capso-global.md",
            "## Capso\n\nUse /lfg.\n",
        );
        f.write(
            "workflow/mcps/linear.yaml",
            "schema_version: 1\nname: capso-linear\ntransport: stdio\ncommand: npx\nargs: [\"-y\", \"mcp-remote\", \"https://mcp.linear.app/sse\"]\nenv_references: [LINEAR_API_TOKEN]\n",
        );
        f.write(
            "workflow/rules/security/secrets.md",
            "---\ndescription: Never commit secrets\npaths: [\"**/*.env\"]\n---\n# Secrets\nNever commit them.\n",
        );
        f.write("workflow/rules/style.md", "# Style\nBe brief.\n");
        f.write(
            "workflow/agents/code-reviewer.yaml",
            "name: code-reviewer\ndescription: Reviews diffs\ninstructions: |\n  You review code.\nmodel: sonnet\ntools: [Read, Grep]\n",
        );
        f.write(
            "workflow/env/env.yaml",
            "schema_version: 1\nvariables:\n  - key: TEAM_NAME\n    value: txe\n    description: The team this machine works for\n",
        );
        f.write("workflow/docs/runbooks/deploy.md", "# Deploy\n");
        f
    }

    pub fn root(&self) -> &Path {
        self.dir.path()
    }

    pub fn path(&self, rel: &str) -> PathBuf {
        self.dir.path().join(rel)
    }

    pub fn write(&self, rel: &str, text: &str) {
        let p = self.path(rel);
        std::fs::create_dir_all(p.parent().unwrap()).unwrap();
        std::fs::write(p, text).unwrap();
    }

    pub fn remove(&self, rel: &str) {
        let p = self.path(rel);
        if p.is_dir() {
            std::fs::remove_dir_all(p).unwrap();
        } else {
            std::fs::remove_file(p).unwrap();
        }
    }

    pub fn repo(&self) -> TeamRepo {
        TeamRepo::open(self.root()).unwrap()
    }

    pub fn agents(&self) -> AgentRegistry {
        AgentRegistry::load(self.root()).unwrap()
    }
}

/// A file from this repository's own tree.
pub fn shipped(rel: &str) -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../..")
        .join(rel)
}

pub struct Machine {
    pub dir: tempfile::TempDir,
    pub db: wf_state::Db,
}

impl Machine {
    pub fn new() -> Self {
        let dir = tempfile::tempdir().unwrap();
        std::fs::create_dir_all(dir.path().join("home")).unwrap();
        Self {
            dir,
            db: wf_state::Db::open_memory().unwrap(),
        }
    }

    pub fn home(&self) -> PathBuf {
        self.dir.path().join("home")
    }

    pub fn at(&self, rel: &str) -> PathBuf {
        self.home().join(rel)
    }

    pub fn read(&self, rel: &str) -> String {
        std::fs::read_to_string(self.at(rel)).unwrap_or_default()
    }

    pub fn write(&self, rel: &str, text: &str) {
        let p = self.at(rel);
        std::fs::create_dir_all(p.parent().unwrap()).unwrap();
        std::fs::write(p, text).unwrap();
    }

    pub fn wf_binary(&self) -> PathBuf {
        self.dir.path().join("bin/wf")
    }

    pub fn tx(&self, dry_run: bool) -> wf_state::Transaction<'_> {
        wf_state::Transaction::begin(&self.db, self.dir.path().join("backups"), "2.0.0", dry_run)
    }

    /// An adapter for one agent of `team`'s registry, rooted in this machine's home with no
    /// environment overrides, so the test never reads the real `CLAUDE_CONFIG_DIR`.
    pub fn adapter(&self, team: &TeamFixture, id: &str, policies: Policies) -> ConfigAdapter {
        let spec = team.agents().find(id).unwrap().clone();
        let location = spec.locate(&self.home(), &|_| None);
        ConfigAdapter::new(spec, location, self.wf_binary(), policies)
    }

    pub fn machine(&self, policies: Policies) -> MachineAdapter {
        MachineAdapter::new(
            self.dir.path().join("state/docs"),
            self.wf_binary(),
            policies,
        )
    }
}
