//! The install rehearsal: a machine with nothing on it, taken through the whole lifecycle.
//!
//! This started as a shell script and is here instead for the reason WFR-011 gives: text at
//! process boundaries belongs somewhere it can be tested. The shell version died twice at a
//! `set -e` boundary on a machine that was working exactly as designed, and its "a dry run
//! writes nothing" assertion was quietly wrong — both of which are visible here and were
//! not there.
//!
//! Everything runs against the real binary in a subprocess, in a temporary home, with
//! `HOME`, `CLAUDE_CONFIG_DIR` and `CODEX_HOME` pointed somewhere disposable. Nothing touches
//! the machine's own configuration — which, now that `wf install` deploys into every agent it
//! finds under the home directory, includes a developer's real `~/.cursor`.

use std::collections::BTreeMap;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};

struct Machine {
    _dir: tempfile::TempDir,
    home: PathBuf,
    claude: PathBuf,
    codex: PathBuf,
    dist: PathBuf,
    /// A PATH whose `claude` and `codex` are stand-ins.
    ///
    /// A real Codex answers the dispatcher-trust question from the person's own decisions,
    /// and a real agent may reach the network when asked anything. The stand-ins answer
    /// `--version` and record everything else they are asked, which is the whole surface wf
    /// runs an agent for.
    path: String,
}

impl Machine {
    fn new() -> Self {
        let dir = tempfile::tempdir().unwrap();
        let m = Machine {
            home: dir.path().join("home"),
            claude: dir.path().join("claude"),
            codex: dir.path().join("codex"),
            dist: dir.path().join("dist"),
            path: String::new(),
            _dir: dir,
        };
        let fake_bin = m._dir.path().join("fakebin");
        std::fs::create_dir_all(&fake_bin).unwrap();
        Machine::install_agent_double(&fake_bin, "claude", "2.1.0");
        Machine::install_agent_double(&fake_bin, "codex", "0.40.0");
        let m = Machine {
            path: format!(
                "{}:{}",
                fake_bin.display(),
                std::env::var("PATH").unwrap_or_default()
            ),
            ..m
        };
        for p in [&m.home, &m.claude, &m.codex] {
            std::fs::create_dir_all(p).unwrap();
        }
        m
    }

    /// Write a stand-in agent that answers the two questions detection asks and logs
    /// everything else.
    fn install_agent_double(dir: &Path, name: &str, version: &str) {
        let script = format!(
            r#"#!/bin/sh
echo "$@" >> "$(dirname "$0")/{name}.log"
case "$1" in
  --version) echo "{name} {version}" ;;
  plugin|mcp) echo "usage: {name} $1" ;;
esac
exit 0
"#
        );
        let bin = dir.join(name);
        std::fs::write(&bin, script).unwrap();
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            std::fs::set_permissions(&bin, std::fs::Permissions::from_mode(0o755)).unwrap();
        }
    }

    fn run(&self, args: &[&str]) -> Output {
        Command::new(env!("CARGO_BIN_EXE_wf"))
            .args(args)
            .env("HOME", self._dir.path())
            .env("WF_HOME", &self.home)
            .env("CLAUDE_CONFIG_DIR", &self.claude)
            .env("CODEX_HOME", &self.codex)
            .env("PATH", &self.path)
            .output()
            .expect("wf runs")
    }

    /// Run and require success, with the output in the failure message — a rehearsal that
    /// fails with "assertion failed: status.success()" tells nobody anything.
    fn ok(&self, args: &[&str]) -> String {
        let out = self.run(args);
        assert!(
            out.status.success(),
            "wf {} exited {:?}\n--- stdout ---\n{}\n--- stderr ---\n{}",
            args.join(" "),
            out.status.code(),
            String::from_utf8_lossy(&out.stdout),
            String::from_utf8_lossy(&out.stderr)
        );
        String::from_utf8_lossy(&out.stdout).into_owned()
    }

    /// The JSON envelope, whatever the exit code.
    ///
    /// `status` and `doctor` exit non-zero when the machine is not fully healthy, which is
    /// right for a health check and wrong for reading one field. In a sandbox the machine
    /// will not be healthy: the Codex stand-in cannot say it trusts the dispatcher, so that
    /// one component stays blocked, as it does on a real machine until a person trusts it.
    fn json(&self, args: &[&str]) -> serde_json::Value {
        let mut full = args.to_vec();
        full.push("--json");
        let out = self.run(&full);
        let stdout = String::from_utf8_lossy(&out.stdout);
        serde_json::from_str(stdout.trim()).unwrap_or_else(|e| {
            panic!(
                "wf {} did not print JSON ({e})\n--- stdout ---\n{stdout}\n--- stderr ---\n{}",
                args.join(" "),
                String::from_utf8_lossy(&out.stderr)
            )
        })
    }

    /// The files `wf` manages in the two first-party agents, with their contents hashed.
    ///
    /// Scoped deliberately. Detecting an agent runs its binary — the only honest way to ask
    /// what version it is and which subcommands it has — and Codex creates scratch
    /// directories under its own home when it starts. The claim under test is that *wf*
    /// writes nothing, not that no process anywhere touches a file.
    fn managed(&self) -> BTreeMap<String, String> {
        let mut out = BTreeMap::new();
        for p in [
            self.claude.join("CLAUDE.md"),
            self.codex.join("AGENTS.md"),
            self.codex.join("AGENTS.override.md"),
            self.codex.join("hooks.json"),
            self.codex.join("config.toml"),
            self.claude.join("settings.json"),
            self.claude.join(".claude.json"),
        ] {
            if let Ok(bytes) = std::fs::read(&p) {
                out.insert(
                    p.to_string_lossy().into_owned(),
                    wf_core::hash::sha256_bytes(&bytes),
                );
            }
        }
        out
    }

    fn read(&self, p: &Path) -> String {
        std::fs::read_to_string(p).unwrap_or_default()
    }

    /// Build a release from this checkout, carrying this platform's binary.
    fn build_release(&self) {
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
        let mut args = vec![
            "release",
            "build-local",
            "--out",
            self.dist.to_str().unwrap(),
            "--root",
            root.to_str().unwrap(),
        ];
        if wf_core::paths::platform_supported() {
            args.push("--with-binary");
        }
        self.ok(&args);
        self.ok(&["release", "verify", "--dir", self.dist.to_str().unwrap()]);
    }

    fn source(&self) -> String {
        format!("local:{}", self.dist.display())
    }
}

/// Marked `#[ignore]`, and run explicitly in CI with `--release`.
///
/// Not because it is flaky — it is hermetic — but because it is heavy in a debug build:
/// `--with-binary` packs and compresses whatever `wf` binary is running, and a debug one is
/// an order of magnitude larger than a release one. Roughly three minutes debug against a
/// few seconds release. `cargo test --workspace` should stay something a developer runs
/// without thinking about it.
///
/// The whole lifecycle, in the order a person meets it.
///
/// One test rather than eight, because each step depends on the machine the previous one
/// left behind — and eight tests that each rebuild a release would spend eight times the
/// wall clock to assert the same things about less realistic states.
#[test]
#[ignore = "end-to-end rehearsal; run with --release: cargo test --release -- --ignored"]
fn a_machine_with_nothing_on_it_can_be_installed_repaired_and_uninstalled() {
    let m = Machine::new();
    m.build_release();

    // --- an unsupported platform refuses, and that is the whole test there ------------
    //
    // This is a real acceptance case rather than a skip: an arm64 Linux container on a Mac
    // is a machine this release line does not ship for, and it must refuse by name before
    // downloading or executing anything.
    let platform = wf_core::paths::target_triple().to_string();
    if !wf_core::paths::platform_supported() {
        let out = m.run(&["install", "--source", &m.source()]);
        assert!(!out.status.success(), "install succeeded on {platform}");
        let stderr = String::from_utf8_lossy(&out.stderr);
        assert!(
            stderr.contains(&platform),
            "the refusal did not name the platform: {stderr}"
        );
        assert!(m.managed().is_empty(), "a refused install wrote something");
        return;
    }

    // --- a dry run changes nothing --------------------------------------------------
    let before = m.managed();
    let plan = m.ok(&["install", "--source", &m.source(), "--dry-run"]);
    assert!(plan.contains("演练完成"), "{plan}");
    assert!(
        plan.contains("CLAUDE.md"),
        "the plan must name what it would write: {plan}"
    );
    assert_eq!(before, m.managed(), "a dry run changed a managed file");
    assert!(
        !m.home.join("state").exists(),
        "dry-run initialized persistent state"
    );

    // --- install ---------------------------------------------------------------------
    let out = m.ok(&["install", "--source", &m.source()]);
    assert!(
        out.contains(&format!("已安装 {}", wf_core::VERSION)),
        "{out}"
    );

    let status = m.json(&["status"]);
    assert_ne!(
        status["result"]["active_version"], "",
        "nothing became active"
    );
    assert_eq!(
        status["result"]["attested"], false,
        "a local build must never report itself as attested"
    );

    // --- the prompt block landed in both agents --------------------------------------
    for f in [m.claude.join("CLAUDE.md"), m.codex.join("AGENTS.md")] {
        assert!(
            m.read(&f).contains("wf:managed-begin id=capso.global"),
            "no managed block in {}",
            f.display()
        );
    }

    // --- the Codex dispatcher is the frozen argv -------------------------------------
    let hooks: serde_json::Value = serde_json::from_str(&m.read(&m.codex.join("hooks.json")))
        .expect("hooks.json is valid JSON");
    let ours = hooks["hooks"]["SessionStart"]
        .as_array()
        .expect("a SessionStart list")
        .iter()
        .flat_map(|group| group["hooks"].as_array().expect("native handler group"))
        .find(|handler| handler["statusMessage"] == "capso-wf-bootstrap")
        .expect("our dispatcher");
    let command = ours["command"].as_str().unwrap();
    assert_eq!(
        command,
        format!(
            "{} hook session-start --agent codex",
            m.home.join("bin/wf").display()
        )
    );
    // Nothing version-shaped: a definition that moves per release un-trusts itself.
    assert!(!ours.to_string().contains(wf_core::VERSION), "{ours}");

    // --- wf replaced its own binary, and it runs ------------------------------------
    let installed = m.home.join("bin/wf");
    assert!(installed.is_file(), "the release binary was not installed");
    let version = Command::new(&installed).arg("--version").output().unwrap();
    assert!(
        String::from_utf8_lossy(&version.stdout).contains(wf_core::VERSION),
        "the installed binary reports the wrong version"
    );

    // --- the session-start hook answers ----------------------------------------------
    let hook = m.ok(&["hook", "session-start", "--agent", "claude"]);
    let v: serde_json::Value = serde_json::from_str(hook.trim()).expect("the hook prints JSON");
    assert_eq!(v["hookSpecificOutput"]["hookEventName"], "SessionStart");

    // --- a user's own text survives a repair; the clobbered block does not ------------
    let claude_md = m.claude.join("CLAUDE.md");
    let edited = m.read(&claude_md).replace(
        "The Magi skills are installed on this machine.",
        "CLOBBERED",
    ) + "\n## My own notes\n\nDo not lose this.\n";
    std::fs::write(&claude_md, edited).unwrap();

    m.ok(&["repair"]);
    let repaired = m.read(&claude_md);
    assert!(
        repaired.contains("My own notes"),
        "repair lost the user's text"
    );
    assert!(
        !repaired.contains("CLOBBERED"),
        "repair did not restore the block"
    );

    // --- a second repair is a no-op --------------------------------------------------
    let again = m.json(&["repair"]);
    assert_eq!(
        again["result"]["applied"].as_array().unwrap().len(),
        0,
        "repair was not idempotent: {}",
        again["result"]["applied"]
    );

    // --- every overwrite left a restorable backup ------------------------------------
    let backups = m.json(&["backup", "list"]);
    let edited_backup = backups["result"]
        .as_array()
        .unwrap()
        .iter()
        .find(|backup| {
            backup["original_path"].as_str() == claude_md.to_str()
                && backup["backup_path"].as_str().is_some_and(|path| {
                    std::fs::read_to_string(path).is_ok_and(|text| text.contains("CLOBBERED"))
                })
        })
        .expect("the edited Claude prompt has its own backup");
    let id = edited_backup["backup_id"].as_str().unwrap();
    m.ok(&["backup", "restore", id]);
    // Restoring brought the edited version back, which is the point: it is recoverable.
    assert!(
        m.read(&claude_md).contains("CLOBBERED"),
        "the backup did not restore"
    );
    m.ok(&["repair"]);

    // --- uninstall removes only what it has a receipt for ----------------------------
    let mine = m.claude.join("a-skill-nobody-manages.md");
    std::fs::write(&mine, "keep me").unwrap();
    m.ok(&["uninstall", "--yes"]);
    assert!(mine.is_file(), "uninstall removed a file it did not own");
    assert!(
        installed.is_file(),
        "uninstall removed the binary needed to restore backups"
    );
    assert!(
        !m.read(&m.codex.join("hooks.json"))
            .contains("capso-wf-bootstrap"),
        "uninstall left the dispatcher behind"
    );
    assert_eq!(m.read(&mine), "keep me");
    assert!(
        !m.read(&claude_md).contains("wf:managed-begin"),
        "uninstall left its block behind"
    );
}

/// A release whose bundle has been tampered with installs nothing at all.
#[test]
#[ignore = "end-to-end rehearsal; run with --release: cargo test --release -- --ignored"]
fn a_tampered_release_installs_nothing() {
    let m = Machine::new();
    m.build_release();

    let lock: serde_json::Value =
        serde_json::from_str(&m.read(&m.dist.join("workflow.lock.json"))).unwrap();
    let bundle = m.dist.join(lock["bundle"]["asset"].as_str().unwrap());
    let mut bytes = std::fs::read(&bundle).unwrap();
    let n = bytes.len();
    bytes[n / 2] ^= 0xff;
    std::fs::write(&bundle, &bytes).unwrap();

    let out = m.run(&["install", "--source", &m.source()]);
    assert!(!out.status.success(), "a tampered release installed");
    // On a platform this release line ships for, the refusal is an integrity failure. On one
    // it does not, the platform check fires first and refuses before anything is downloaded —
    // which is the right order, and means the code is 3 rather than 4. Either way nothing is
    // written, which is the property that actually matters.
    let expected = if wf_core::paths::platform_supported() {
        4 // integrity
    } else {
        3 // unsupported platform, refused before the bundle was ever opened
    };
    assert_eq!(
        out.status.code(),
        Some(expected),
        "on {} the refusal should exit {expected}\n{}",
        wf_core::paths::target_triple(),
        String::from_utf8_lossy(&out.stderr)
    );
    assert!(m.managed().is_empty(), "a refused install wrote something");
}
