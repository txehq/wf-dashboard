use crate::schema::*;
use std::collections::BTreeSet;
use std::path::Path;

/// One reason a registry cannot be released. Codes are stable so a CI log is greppable.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Violation {
    pub code: &'static str,
    pub subject: String,
    pub message: String,
}

impl std::fmt::Display for Violation {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}  {}: {}", self.code, self.subject, self.message)
    }
}

fn v(code: &'static str, subject: impl Into<String>, message: impl Into<String>) -> Violation {
    Violation {
        code,
        subject: subject.into(),
        message: message.into(),
    }
}

/// Everything that must hold before a registry can be compiled into a release.
///
/// `root` is the repository root; when it is `Some`, sources are resolved on disk and the
/// registry and the tree are required to be the same set — the same invariant the document
/// registry holds for docs, for the same reason: an unregistered file and a registered
/// ghost are both silent until somebody's session breaks.
pub fn validate(reg: &Registry, root: Option<&Path>) -> Vec<Violation> {
    let mut out = Vec::new();
    let mut ids = BTreeSet::new();

    if reg.organization.trim().is_empty() {
        out.push(v("REG001", "organization", "must not be empty"));
    }
    if !reg
        .plugin
        .name
        .chars()
        .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '-')
    {
        out.push(v(
            "REG002",
            &reg.plugin.name,
            "plugin name must be lowercase kebab-case",
        ));
    }

    for c in &reg.components {
        if !valid_id(&c.id) {
            out.push(v(
                "REG003",
                &c.id,
                "id must be dotted lowercase, e.g. capso.skill.interview",
            ));
        }
        if !ids.insert(c.id.clone()) {
            out.push(v("REG004", &c.id, "declared twice"));
        }
        // D-014. The schema can express only mandatory components in this release line.
        if !c.required {
            out.push(v(
                "REG005",
                &c.id,
                "required: false is rejected — every organization resource is mandatory in this release line",
            ));
        }
        if c.targets.is_empty() {
            out.push(v(
                "REG006",
                &c.id,
                "no targets — a component nothing delivers is not a deliverable",
            ));
        }
        let mut seen_agents = BTreeSet::new();
        for t in &c.targets {
            if !seen_agents.insert(t.agent()) {
                out.push(v(
                    "REG007",
                    &c.id,
                    format!("agent {} targeted twice", t.agent().as_str()),
                ));
            }
        }

        // Per-kind shape. A kind whose required field is missing is a component the
        // renderer would have to guess at.
        match c.kind {
            Kind::Skill
            | Kind::HookPolicy
            | Kind::Mcp
            | Kind::ReadinessProfile
            | Kind::PromptBlock => {
                if c.source.as_deref().unwrap_or("").is_empty() {
                    out.push(v(
                        "REG008",
                        &c.id,
                        format!("kind {} needs a source path", c.kind.as_str()),
                    ));
                }
            }
            Kind::HookDispatcher => {
                if c.event.as_deref().unwrap_or("").is_empty() {
                    out.push(v("REG009", &c.id, "hook-dispatcher needs an event"));
                }
                if c.executable.as_deref().unwrap_or("").is_empty() {
                    out.push(v("REG009", &c.id, "hook-dispatcher needs an executable"));
                }
                // The trust contract is the whole reason the dispatcher is fixed: Codex
                // binds trust to the exact definition, so a dispatcher whose argv is
                // computed per release would demand a human re-trust on every release.
                if c.trust_contract.as_deref() != Some("stable-definition") {
                    out.push(v(
                        "REG010",
                        &c.id,
                        "hook-dispatcher must declare trust_contract: stable-definition",
                    ));
                }
                if c.arguments
                    .iter()
                    .any(|a| a.contains("$(") || a.contains('`') || a.contains(';'))
                {
                    out.push(v(
                        "REG011",
                        &c.id,
                        "hook arguments must be literal argv, never shell",
                    ));
                }
            }
        }

        if let Some(src) = c.source.as_deref() {
            if src.starts_with('/') || src.contains("..") || src.contains('\\') {
                out.push(v(
                    "REG012",
                    &c.id,
                    format!("source {src:?} must be a relative, forward-slashed repo path"),
                ));
            } else if let Some(root) = root {
                if !root.join(src).exists() {
                    out.push(v("REG013", &c.id, format!("source {src} is not on disk")));
                }
            }
        }

        // D-018. A secret value in the registry would be copied into the lock, the bundle,
        // every machine's state database and every backup of it. Refuse at the schema.
        if let Some(cred) = &c.credentials {
            if !cred.values_forbidden {
                out.push(v(
                    "REG014",
                    &c.id,
                    "credentials.values_forbidden must be true",
                ));
            }
            // `agent-oauth` is the one mode with nothing to reference: the provider has no
            // token route, so a name here would be a name nobody can set. Every other mode
            // keeps the old rule — credentials that reference nothing check nothing.
            if cred.references.is_empty() && cred.mode != crate::CREDENTIAL_MODE_AGENT_OAUTH {
                out.push(v(
                    "REG015",
                    &c.id,
                    "credentials declared with no references",
                ));
            }
            if !cred.references.is_empty() && cred.mode == crate::CREDENTIAL_MODE_AGENT_OAUTH {
                out.push(v(
                    "REG020",
                    &c.id,
                    format!(
                        "credentials.mode is {:?} but references are set — a login the agent holds has no environment name",
                        cred.mode
                    ),
                ));
            }
            // A browser login has to say where it goes, or the one thing this mode can report
            // is a sentence with a hole in it.
            let oauth = cred.mode == crate::CREDENTIAL_MODE_AGENT_OAUTH;
            if oauth && cred.login_host.is_empty() {
                out.push(v(
                    "REG017",
                    &c.id,
                    format!(
                        "credentials.mode is {:?} but login_host is empty — name the host this component's own server logs in to",
                        cred.mode
                    ),
                ));
            }
            if !oauth && !cred.login_host.is_empty() {
                out.push(v(
                    "REG018",
                    &c.id,
                    format!(
                        "login_host is set but credentials.mode is {:?}; only {:?} reads it",
                        cred.mode,
                        crate::CREDENTIAL_MODE_AGENT_OAUTH
                    ),
                ));
            }
            let host = &cred.login_host;
            if !host.is_empty()
                && (host.contains("://") || host.contains('/') || host.trim().is_empty())
            {
                out.push(v(
                    "REG019",
                    &c.id,
                    format!("login_host {host:?} must be a bare host name such as mcp.linear.app"),
                ));
            }
            for r in &cred.references {
                if wf_core::redact::looks_like_secret(r) {
                    out.push(v(
                        "REG016",
                        &c.id,
                        format!("credential reference {r:?} looks like a secret value, not a name"),
                    ));
                }
            }
        }
        if c.kind != Kind::Mcp && c.credentials.is_some() {
            out.push(v("REG017", &c.id, "only kind: mcp carries credentials"));
        }
        match c.startup_timeout_sec {
            Some(_) if c.kind != Kind::Mcp => out.push(v(
                "REG022",
                &c.id,
                "only kind: mcp carries startup_timeout_sec",
            )),
            Some(0) => out.push(v(
                "REG022",
                &c.id,
                "startup_timeout_sec must be at least one second",
            )),
            _ => {}
        }
    }

    if let Some(root) = root {
        out.extend(same_set_skills(reg, root));
    }
    out
}

/// The registry and `skills/` are the same set. A skill directory nobody registered ships
/// to nobody; a registered skill with no directory fails at render time on a runner instead
/// of here, where the message can say which line of the registry is wrong.
fn same_set_skills(reg: &Registry, root: &Path) -> Vec<Violation> {
    let mut out = Vec::new();
    let registered: BTreeSet<&str> = reg
        .of_kind(Kind::Skill)
        .filter_map(Registry::skill_name)
        .collect();
    let dir = root.join("skills");
    let Ok(entries) = std::fs::read_dir(&dir) else {
        return out;
    };
    let mut on_disk = BTreeSet::new();
    for e in entries.flatten() {
        if e.path().is_dir() && e.path().join("SKILL.md").is_file() {
            if let Some(name) = e.file_name().to_str() {
                on_disk.insert(name.to_string());
            }
        }
    }
    for name in &on_disk {
        if !registered.contains(name.as_str()) {
            out.push(v(
                "REG020",
                format!("skills/{name}"),
                "on disk but absent from workflow/registry.yaml — an unregistered skill ships to nobody",
            ));
        }
    }
    for name in &registered {
        if !on_disk.contains(*name) {
            out.push(v(
                "REG021",
                format!("skills/{name}"),
                "registered but has no SKILL.md",
            ));
        }
    }
    out
}

fn valid_id(id: &str) -> bool {
    if id.is_empty() || id.starts_with('.') || id.ends_with('.') || id.contains("..") {
        return false;
    }
    id.split('.').count() >= 2
        && id
            .chars()
            .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '.' || c == '-')
}

#[cfg(test)]
mod tests {
    use super::*;

    const BASE: &str = r#"
schema_version: 2
organization: capsohq
product: wf
plugin:
  id: capso.magi
  name: magi
  marketplace: capsohq
  description: test
components:
  - id: capso.skill.interview
    kind: skill
    source: skills/interview
    required: true
    targets: [claude-code, codex]
"#;

    fn parse(y: &str) -> Registry {
        Registry::parse(y).expect("parses")
    }

    #[test]
    fn a_clean_registry_has_no_violations() {
        assert_eq!(validate(&parse(BASE), None), vec![]);
    }

    const MCP: &str = r#"
  - id: capso.mcp.linear
    kind: mcp
    source: workflow/mcps/linear.yaml
    required: true
    targets: [claude-code, codex]
    credentials:
      mode: MODE
      references: [LINEAR_API_TOKEN]
      values_forbidden: true
      login_host: HOST
"#;

    fn with_mcp(mode: &str, host: &str) -> Registry {
        parse(&format!(
            "{BASE}{}",
            MCP.replace("MODE", mode).replace("HOST", host)
        ))
    }

    fn codes(reg: &Registry) -> Vec<&'static str> {
        validate(reg, None).into_iter().map(|v| v.code).collect()
    }

    #[test]
    fn a_login_host_under_any_other_mode_is_dead_configuration() {
        // `environment` answers from a variable this machine can read. A host beside it named
        // a browser login nothing in that mode ever performs.
        assert_eq!(
            codes(&with_mcp("environment", "mcp.linear.app")),
            vec!["REG018"]
        );
        assert_eq!(codes(&with_mcp("environment", "\"\"")), Vec::<&str>::new());
    }

    const OAUTH_ONLY: &str = r#"
  - id: capso.mcp.rackspace-spot
    kind: mcp
    source: workflow/mcps/rackspace-spot.yaml
    required: true
    targets: [claude-code, codex]
    credentials:
      mode: agent-oauth
      references: REFS
      values_forbidden: true
      login_host: mcp.spot.rackspace.com
"#;

    fn with_oauth_only(refs: &str) -> Registry {
        parse(&format!("{BASE}{}", OAUTH_ONLY.replace("REFS", refs)))
    }

    #[test]
    fn a_login_the_server_holds_needs_no_reference() {
        // Rackspace Spot has no token route: requiring a reference here would mean naming an
        // environment variable nobody can set, which is worse than naming nothing.
        assert_eq!(codes(&with_oauth_only("[]")), Vec::<&str>::new());
    }

    #[test]
    fn an_oauth_only_credential_with_a_reference_is_refused() {
        assert_eq!(codes(&with_oauth_only("[SPOT_TOKEN]")), vec!["REG020"]);
    }

    /// A browser login that does not say where it goes leaves the one sentence this mode can
    /// produce with a hole in it — and `login_host` is now the only thing in the registry that
    /// says which service a component's own server talks to.
    #[test]
    fn an_oauth_only_credential_still_names_its_host() {
        let missing_host = OAUTH_ONLY
            .replace("REFS", "[]")
            .replace("login_host: mcp.spot.rackspace.com", "login_host: \"\"");
        assert_eq!(
            codes(&parse(&format!("{BASE}{missing_host}"))),
            vec!["REG017"]
        );
    }

    #[test]
    fn a_host_is_a_bare_host_name_not_a_url() {
        let url = OAUTH_ONLY.replace("REFS", "[]").replace(
            "login_host: mcp.spot.rackspace.com",
            "login_host: \"https://mcp.spot.rackspace.com/mcp\"",
        );
        assert_eq!(codes(&parse(&format!("{BASE}{url}"))), vec!["REG019"]);
    }

    /// A startup limit belongs to a server, and a limit of nothing would drop the server
    /// before it could start.
    #[test]
    fn a_startup_limit_is_a_positive_number_on_an_mcp_component() {
        let limited = |seconds: &str| {
            OAUTH_ONLY.replace("REFS", "[]") + &format!("    startup_timeout_sec: {seconds}\n")
        };
        assert_eq!(
            codes(&parse(&format!("{BASE}{}", limited("120")))),
            Vec::<&str>::new()
        );
        assert_eq!(
            codes(&parse(&format!("{BASE}{}", limited("0")))),
            vec!["REG022"]
        );
        let on_a_skill = BASE.replace(
            "targets: [claude-code, codex]",
            "targets: [claude-code, codex]\n    startup_timeout_sec: 120",
        );
        assert_eq!(codes(&parse(&on_a_skill)), vec!["REG022"]);
    }

    #[test]
    fn optional_is_refused_by_the_schema() {
        let r = parse(&BASE.replace("required: true", "required: false"));
        let got = validate(&r, None);
        assert!(got.iter().any(|x| x.code == "REG005"), "{got:?}");
    }

    #[test]
    fn a_duplicate_id_is_caught() {
        let mut r = parse(BASE);
        let dup = r.components[0].clone();
        r.components.push(dup);
        assert!(validate(&r, None).iter().any(|x| x.code == "REG004"));
    }

    #[test]
    fn a_secret_value_where_a_name_belongs_is_refused() {
        let y = BASE.to_string()
            + r#"
  - id: capso.mcp.linear
    kind: mcp
    source: workflow/mcps/linear.yaml
    required: true
    targets: [claude-code]
    credentials:
      mode: environment
      references: ["lin_api_0123456789abcdefghij"]
"#;
        assert!(validate(&parse(&y), None)
            .iter()
            .any(|x| x.code == "REG016"));
    }

    #[test]
    fn a_dispatcher_without_a_stable_trust_contract_is_refused() {
        let y = BASE.to_string()
            + r#"
  - id: capso.hook.session-start
    kind: hook-dispatcher
    required: true
    event: SessionStart
    executable: wf
    arguments: [hook, session-start]
    targets: [claude-code, codex]
"#;
        let got = validate(&parse(&y), None);
        assert!(got.iter().any(|x| x.code == "REG010"), "{got:?}");
    }

    #[test]
    fn a_shell_fragment_in_hook_argv_is_refused() {
        let y = BASE.to_string()
            + r#"
  - id: capso.hook.session-start
    kind: hook-dispatcher
    required: true
    event: SessionStart
    executable: wf
    arguments: [hook, "session-start; rm -rf /"]
    trust_contract: stable-definition
    targets: [codex]
"#;
        assert!(validate(&parse(&y), None)
            .iter()
            .any(|x| x.code == "REG011"));
    }

    #[test]
    fn an_unknown_kind_fails_to_parse_rather_than_being_skipped() {
        let y = BASE.replace("kind: skill", "kind: quantum-widget");
        assert!(Registry::parse(&y).is_err());
    }

    #[test]
    fn a_newer_schema_is_refused_not_best_effort_parsed() {
        let y = BASE.replace("schema_version: 2", "schema_version: 99");
        let e = Registry::parse(&y).unwrap_err();
        assert_eq!(e.code, wf_core::ExitCode::Unsupported);
    }
}
