//! Monthly session logs: `<state dir>/sessions/YYYY-MM.md`, one entry per session worth
//! keeping, each entry marked so a session has one entry however often it is saved.

use super::collector::SessionSummary;
use std::path::{Path, PathBuf};
use wf_core::Result;

pub struct SessionStorage {
    dir: PathBuf,
}

impl SessionStorage {
    pub fn new(dir: &Path) -> Self {
        Self {
            dir: dir.to_path_buf(),
        }
    }

    pub fn dir(&self) -> &Path {
        &self.dir
    }

    /// The log for a `YYYY-MM` month.
    pub fn log_path(&self, month: &str) -> PathBuf {
        self.dir.join(format!("{month}.md"))
    }

    fn marker(session_id: &str) -> String {
        format!("<!-- wf:session {session_id} -->")
    }

    pub fn render_entry(summary: &SessionSummary) -> String {
        let s = summary;
        let date = &s.end.as_deref().unwrap_or(&s.timestamp)[..10];
        let short: String = s
            .session_id
            .split('-')
            .next()
            .filter(|p| !p.is_empty())
            .unwrap_or(&s.session_id)
            .chars()
            .take(8)
            .collect();
        let mut out = format!(
            "{}\n### {date} · {short} · {}\n\n",
            Self::marker(&s.session_id),
            s.agent
        );
        if let Some(cwd) = &s.cwd {
            out.push_str(&format!("- Project: `{cwd}`\n"));
        }
        out.push_str(&format!(
            "- Prompts: {} · Tools: {} ({} distinct)\n- Interventions: {}\n",
            s.prompts, s.tool_total, s.distinct_tools, s.intervention_count
        ));
        if !s.skills.is_empty() {
            out.push_str(&format!("- Skills: {}\n", s.skills.join(", ")));
        }
        if !s.top_tools.is_empty() {
            let tools: Vec<String> = s
                .top_tools
                .iter()
                .map(|(t, n)| format!("{t}×{n}"))
                .collect();
            out.push_str(&format!("- Top tools: {}\n", tools.join(", ")));
        }
        if let Some(ask) = &s.first_prompt_redacted {
            out.push_str(&format!("- First ask: {ask}\n"));
        }
        out
    }

    /// Put the session in its month's log: appended the first time, its entry replaced in
    /// place after that. Returns the log.
    pub fn append_monthly_log(&mut self, summary: &SessionSummary) -> Result<PathBuf> {
        let month = &summary.end.as_deref().unwrap_or(&summary.timestamp)[..7];
        let path = self.log_path(month);
        // Sessions end turns in parallel, and each save rewrites the month's file.
        std::fs::create_dir_all(&self.dir)?;
        let _lock = wf_core::lock::Guard::exclusive_within(&self.dir.join(".lock"), 5_000)?;
        let existing = wf_core::paths::read_text_or_empty(&path)?;
        let marker = format!("{}\n", Self::marker(&summary.session_id));
        let entry = Self::render_entry(summary);
        let at = existing
            .match_indices(&marker)
            .map(|(i, _)| i)
            .find(|&i| i == 0 || existing.as_bytes()[i - 1] == b'\n');
        let text = if let Some(start) = at {
            // The entry runs to the blank line before the next entry, or to the end.
            let end = existing[start..]
                .find("\n\n<!-- wf:session ")
                .map_or(existing.len(), |i| start + i + 1);
            format!("{}{entry}{}", &existing[..start], &existing[end..])
        } else if existing.is_empty() {
            format!("# Session log — {month}\n\n{entry}")
        } else if existing.ends_with('\n') {
            format!("{existing}\n{entry}")
        } else {
            format!("{existing}\n\n{entry}")
        };
        if text != existing {
            wf_core::atomic::write_file(&path, text.as_bytes())?;
        }
        Ok(path)
    }

    /// Delete month logs older than the last `keep_months` months. Returns what went.
    pub fn prune_logs(&mut self, keep_months: usize, now_ms: i64) -> Result<Vec<PathBuf>> {
        let month_index = |text: &str| -> Option<i64> {
            let bytes = text.as_bytes();
            if text.len() != 7 || bytes[4] != b'-' {
                return None;
            }
            let year: i64 = text[..4].parse().ok()?;
            let month: i64 = text[5..].parse().ok()?;
            (1..=12).contains(&month).then_some(year * 12 + month - 1)
        };
        let now = month_index(&wf_core::time_fmt::utc_millis(now_ms)[..7]).unwrap_or(0);
        let Ok(entries) = std::fs::read_dir(&self.dir) else {
            return Ok(vec![]);
        };
        let mut gone = Vec::new();
        for entry in entries.flatten() {
            let name = entry.file_name().to_string_lossy().into_owned();
            let Some(index) = name.strip_suffix(".md").and_then(month_index) else {
                continue;
            };
            if now - index >= keep_months as i64 {
                std::fs::remove_file(entry.path())?;
                gone.push(entry.path());
            }
        }
        Ok(gone)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn summary(id: &str, start: &str, end: Option<&str>) -> SessionSummary {
        SessionSummary {
            session_id: id.into(),
            timestamp: start.into(),
            end: end.map(String::from),
            agent: "claude-code".into(),
            cwd: Some("/work/app".into()),
            prompts: 3,
            tool_total: 12,
            distinct_tools: 5,
            top_tools: vec![("Edit".into(), 4), ("Bash".into(), 3)],
            skills: vec!["lfg".into(), "ic".into()],
            intervention_count: 1,
            valuable: true,
            first_prompt_redacted: Some("fix the flaky test".into()),
        }
    }

    #[test]
    fn an_entry_reads_like_a_log_line_a_person_can_scan() {
        let entry = SessionStorage::render_entry(&summary(
            "aaaabbbb-1111-2222",
            "2026-09-16T10:00:00.000Z",
            Some("2026-09-16T11:00:00.000Z"),
        ));
        assert_eq!(
            entry,
            "<!-- wf:session aaaabbbb-1111-2222 -->\n\
             ### 2026-09-16 · aaaabbbb · claude-code\n\n\
             - Project: `/work/app`\n\
             - Prompts: 3 · Tools: 12 (5 distinct)\n\
             - Interventions: 1\n\
             - Skills: lfg, ic\n\
             - Top tools: Edit×4, Bash×3\n\
             - First ask: fix the flaky test\n"
        );
    }

    #[test]
    fn a_session_is_written_once_into_the_month_it_ended() {
        let dir = tempfile::tempdir().unwrap();
        let mut storage = SessionStorage::new(&dir.path().join("sessions"));
        let s = summary(
            "s1",
            "2026-08-31T23:50:00.000Z",
            Some("2026-09-01T00:10:00.000Z"),
        );
        let path = storage.append_monthly_log(&s).unwrap();
        assert_eq!(path, dir.path().join("sessions/2026-09.md"));
        let once = std::fs::read_to_string(&path).unwrap();
        assert!(
            once.starts_with("# Session log — 2026-09\n\n<!-- wf:session s1 -->\n"),
            "{once}"
        );
        storage.append_monthly_log(&s).unwrap();
        assert_eq!(
            std::fs::read_to_string(&path).unwrap(),
            once,
            "saving twice writes once"
        );
        storage
            .append_monthly_log(&summary("s2", "2026-09-02T10:00:00.000Z", None))
            .unwrap();
        let twice = std::fs::read_to_string(&path).unwrap();
        assert!(
            twice.starts_with(&once) && twice.contains("<!-- wf:session s2 -->"),
            "{twice}"
        );
    }

    /// Agents with no session-end hook are last heard from at a turn's end, so a session is
    /// saved at every one: each save brings its one entry up to date, wherever it sits.
    #[test]
    fn saving_a_session_again_brings_its_one_entry_up_to_date() {
        let dir = tempfile::tempdir().unwrap();
        let mut storage = SessionStorage::new(dir.path());
        let mut s1 = summary("s1", "2026-09-02T10:00:00.000Z", None);
        storage.append_monthly_log(&s1).unwrap();
        let path = storage
            .append_monthly_log(&summary("s2", "2026-09-03T10:00:00.000Z", None))
            .unwrap();
        s1.tool_total = 20;
        storage.append_monthly_log(&s1).unwrap();
        let text = std::fs::read_to_string(&path).unwrap();
        assert_eq!(text.matches("<!-- wf:session s1 -->").count(), 1, "{text}");
        let s2_at = text.find("<!-- wf:session s2 -->").unwrap();
        assert!(text[..s2_at].contains("Tools: 20 (5 distinct)"), "{text}");
        assert!(!text[..s2_at].contains("Tools: 12"), "{text}");
        assert!(
            text.find("<!-- wf:session s1 -->").unwrap() < s2_at,
            "in place: {text}"
        );
        assert!(text.starts_with("# Session log — 2026-09\n\n"), "{text}");
        assert!(
            text[..s2_at].ends_with("\n\n"),
            "a blank line between entries: {text}"
        );

        storage.append_monthly_log(&s1).unwrap();
        assert_eq!(std::fs::read_to_string(&path).unwrap(), text);
    }

    /// Parallel sessions end turns at the same moment; every one of them keeps its entry.
    #[test]
    fn concurrent_saves_lose_no_session() {
        let dir = tempfile::tempdir().unwrap();
        let threads: Vec<_> = (0..12)
            .map(|t| {
                let dir = dir.path().to_path_buf();
                std::thread::spawn(move || {
                    let mut storage = SessionStorage::new(&dir);
                    for n in 0..6 {
                        storage
                            .append_monthly_log(&summary(
                                &format!("s{t}-{n}"),
                                "2026-09-02T10:00:00.000Z",
                                None,
                            ))
                            .unwrap();
                    }
                })
            })
            .collect();
        for t in threads {
            t.join().unwrap();
        }
        let text = std::fs::read_to_string(dir.path().join("2026-09.md")).unwrap();
        assert_eq!(text.matches("<!-- wf:session ").count(), 72, "{text}");
    }

    #[test]
    fn pruning_keeps_the_last_months_and_nothing_else_it_did_not_write() {
        let dir = tempfile::tempdir().unwrap();
        let logs = dir.path().join("sessions");
        std::fs::create_dir_all(&logs).unwrap();
        for name in [
            "2026-02.md",
            "2026-03.md",
            "2026-04.md",
            "2026-09.md",
            "notes.md",
            "2026-9.md",
        ] {
            std::fs::write(logs.join(name), "x").unwrap();
        }
        let mut storage = SessionStorage::new(&logs);
        let now = wf_core::time_fmt::parse_rfc3339_millis("2026-09-16T00:00:00Z").unwrap();
        let mut gone: Vec<String> = storage
            .prune_logs(6, now)
            .unwrap()
            .into_iter()
            .map(|p| p.file_name().unwrap().to_string_lossy().into_owned())
            .collect();
        gone.sort();
        assert_eq!(
            gone,
            ["2026-02.md", "2026-03.md"],
            "April through September is six months"
        );
        for kept in ["2026-04.md", "2026-09.md", "notes.md", "2026-9.md"] {
            assert!(logs.join(kept).exists(), "{kept}");
        }
        assert!(SessionStorage::new(&dir.path().join("missing"))
            .prune_logs(6, now)
            .unwrap()
            .is_empty());
    }
}
