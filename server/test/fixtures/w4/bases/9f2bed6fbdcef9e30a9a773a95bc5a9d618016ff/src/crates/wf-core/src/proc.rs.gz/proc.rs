use std::io::{ErrorKind, Read, Write};
use std::os::fd::AsRawFd;
use std::os::unix::process::CommandExt;
use std::path::Path;
use std::process::Command;
use std::time::{Duration, Instant};

/// The result of running an external program. Output is capped and redacted before it can
/// reach a log, a diagnostic bundle or a model's context.
#[derive(Debug, Clone)]
pub struct Output {
    pub status: Option<i32>,
    pub stdout: String,
    pub stderr: String,
    pub timed_out: bool,
}

impl Output {
    pub fn ok(&self) -> bool {
        self.status == Some(0)
    }
}

/// Cap on captured output. A native plugin manager that decides to print a megabyte of
/// progress must not be able to push that into a hook's stdout or a SQLite row.
const MAX_CAPTURE: usize = 256 * 1024;

/// Linux can transiently refuse exec while another process still has a writable handle
/// to a newly installed executable. Retry only that errno, within the caller's original
/// deadline; permission, format, and missing-program errors remain immediate failures.
///
/// **`spawn()` returning `Err` is not something this can rely on.** Where the standard
/// library can use `posix_spawn`, glibc reports a failed exec by having the *child* exit
/// 127 — so the parent gets `Ok(child)` and the errno never appears. Measured on a Debian
/// x86_64 VM: spawning a program that does not exist returns `Ok` and exits 127, which made
/// both this retry and the missing-program message dead code on Linux while both passed on
/// macOS. `deferred_exec_failure` below is the other half of the fix.
fn spawn_with_deadline(
    command: &mut Command,
    deadline: Instant,
) -> std::io::Result<std::process::Child> {
    loop {
        match command.spawn() {
            Err(error)
                if error.raw_os_error() == Some(libc::ETXTBSY) && Instant::now() < deadline =>
            {
                std::thread::sleep(
                    Duration::from_millis(2)
                        .min(deadline.saturating_duration_since(Instant::now())),
                );
            }
            result => return result,
        }
    }
}

/// Did this child die because the exec failed, rather than because the program ran and
/// returned 127?
///
/// The signal is narrow on purpose: status 127, nothing at all on either stream, and a
/// program we already resolved to an executable file. A real command that exits 127 almost
/// always says something first; one that says nothing and whose binary we just verified is
/// glibc reporting an exec failure after the fork.
fn deferred_exec_failure(out: &Output) -> bool {
    out.status == Some(127) && out.stdout.is_empty() && out.stderr.is_empty() && !out.timed_out
}

/// Resolve a program to an absolute path before spawning it.
///
/// Two things this buys. The missing-program error becomes deterministic — a stat walk of
/// PATH gives the same answer on every platform, where `spawn()`'s error does not. And the
/// child is exec'd by absolute path, so a PATH that changes between the check and the spawn
/// cannot substitute a different binary.
fn resolve(program: &str) -> crate::Result<std::path::PathBuf> {
    if program.contains('/') {
        let p = std::path::PathBuf::from(program);
        return if p.is_file() {
            Ok(p)
        } else {
            Err(not_found(program))
        };
    }
    which(program).ok_or_else(|| not_found(program))
}

fn not_found(program: &str) -> crate::Error {
    crate::Error::failure("EXEC-NOT-FOUND", format!("{program}: not found on PATH"))
        .with_zh(format!("找不到命令 {program}。请先安装它，再重新运行。"))
}

/// A short-lived native JSONL control connection. Both reads and writes share one deadline,
/// and dropping the connection terminates the process group; it never becomes a daemon.
pub struct JsonLineProcess {
    child: std::process::Child,
    input: std::process::ChildStdin,
    output: std::process::ChildStdout,
    pending: Vec<u8>,
    deadline: Instant,
}

impl JsonLineProcess {
    pub fn spawn(
        program: &str,
        args: &[&str],
        env: &[(&str, &str)],
        cwd: &Path,
        timeout: Duration,
    ) -> crate::Result<Self> {
        let mut command = Command::new(program);
        command
            .args(args)
            .envs(env.iter().copied())
            .current_dir(cwd)
            .process_group(0)
            .stdin(std::process::Stdio::piped())
            .stdout(std::process::Stdio::piped())
            .stderr(std::process::Stdio::null());
        let deadline = Instant::now() + timeout;
        let mut child = spawn_with_deadline(&mut command, deadline)?;
        let input = child.stdin.take().unwrap();
        let output = child.stdout.take().unwrap();
        let result = Self {
            child,
            input,
            output,
            pending: vec![],
            deadline,
        };
        nonblocking(&result.input)?;
        nonblocking(&result.output)?;
        Ok(result)
    }

    pub fn send(&mut self, value: &serde_json::Value) -> crate::Result<()> {
        let mut bytes = serde_json::to_vec(value)?;
        bytes.push(b'\n');
        let mut offset = 0;
        while offset < bytes.len() {
            self.check_deadline()?;
            match self.input.write(&bytes[offset..]) {
                Ok(0) => {
                    return Err(crate::Error::failure(
                        "RPC-EOF",
                        "native control connection closed",
                    ))
                }
                Ok(n) => offset += n,
                Err(e) if e.kind() == ErrorKind::WouldBlock => {
                    std::thread::sleep(Duration::from_millis(2))
                }
                Err(e) if e.kind() == ErrorKind::Interrupted => {}
                Err(e) => return Err(e.into()),
            }
        }
        Ok(())
    }

    pub fn receive(&mut self) -> crate::Result<serde_json::Value> {
        let mut bytes = [0; 8192];
        loop {
            self.check_deadline()?;
            if let Some(end) = self.pending.iter().position(|b| *b == b'\n') {
                let line: Vec<_> = self.pending.drain(..=end).collect();
                return serde_json::from_slice(&line).map_err(|_| {
                    crate::Error::failure("RPC-JSON", "native control response is not JSON")
                });
            }
            if self.pending.len() > 2 * 1024 * 1024 {
                return Err(crate::Error::failure(
                    "RPC-SIZE",
                    "native control response exceeded 2 MiB",
                ));
            }
            match self.output.read(&mut bytes) {
                Ok(0) => {
                    return Err(crate::Error::failure(
                        "RPC-EOF",
                        "native control connection closed",
                    ))
                }
                Ok(n) => self.pending.extend_from_slice(&bytes[..n]),
                Err(e) if e.kind() == ErrorKind::WouldBlock => {
                    std::thread::sleep(Duration::from_millis(2))
                }
                Err(e) if e.kind() == ErrorKind::Interrupted => {}
                Err(e) => return Err(e.into()),
            }
        }
    }

    fn check_deadline(&self) -> crate::Result<()> {
        if Instant::now() >= self.deadline {
            Err(crate::Error::failure(
                "RPC-TIMEOUT",
                "native control request timed out",
            ))
        } else {
            Ok(())
        }
    }
}

impl Drop for JsonLineProcess {
    fn drop(&mut self) {
        unsafe {
            libc::kill(-(self.child.id() as i32), libc::SIGKILL);
        }
        let _ = self.child.kill();
        let _ = self.child.wait();
    }
}

/// Run a program with an argument vector.
///
/// There is no shell here and there is never going to be one. Every argument the adapters
/// pass — a marketplace URL, a plugin name, a file path — is attacker-adjacent in the sense
/// that it comes from a registry or a release, and `sh -c` would turn a quoting mistake into
/// arbitrary execution on every developer machine at session start.
pub fn run(program: &str, args: &[&str], timeout: Duration) -> crate::Result<Output> {
    run_with_env(program, args, &[], timeout)
}

pub fn run_with_env(
    program: &str,
    args: &[&str],
    env: &[(&str, &str)],
    timeout: Duration,
) -> crate::Result<Output> {
    run_in(program, args, env, None, timeout)
}

/// Run in the repository whose version pins and native commands must be observed.
pub fn run_in(
    program: &str,
    args: &[&str],
    env: &[(&str, &str)],
    directory: Option<&Path>,
    timeout: Duration,
) -> crate::Result<Output> {
    // Resolved before anything is spawned, so "not installed" is a stat walk with the same
    // answer everywhere rather than an errno the platform may never produce.
    let resolved = resolve(program)?;
    let deadline = Instant::now() + timeout;
    loop {
        let out = run_resolved(&resolved, args, env, directory, deadline)?;
        // An exec that failed after the fork looks like a child that exited 127 in silence.
        // Retry it inside the caller's deadline — this is the window a freshly installed
        // binary is still open for writing in — and hand back whatever we last saw once the
        // deadline is gone, rather than inventing an error for a command that may simply
        // have exited 127.
        if !deferred_exec_failure(&out) || Instant::now() >= deadline {
            return Ok(out);
        }
        std::thread::sleep(
            Duration::from_millis(2).min(deadline.saturating_duration_since(Instant::now())),
        );
    }
}

fn run_resolved(
    program: &Path,
    args: &[&str],
    env: &[(&str, &str)],
    directory: Option<&Path>,
    deadline: Instant,
) -> crate::Result<Output> {
    let mut cmd = Command::new(program);
    cmd.args(args);
    if let Some(directory) = directory {
        cmd.current_dir(directory);
    }
    // Descendants inherit this group. Killing only the immediate child leaves their
    // output descriptors open and can make a supposedly bounded call wait indefinitely.
    cmd.process_group(0);
    // Never let a subprocess stop to ask for a password. A git or gh prompt inside a
    // SessionStart hook hangs the terminal a developer is trying to work in.
    cmd.env("GIT_TERMINAL_PROMPT", "0");
    cmd.env("GIT_ASKPASS", "");
    cmd.env("SSH_ASKPASS", "");
    cmd.env("CLICOLOR", "0");
    cmd.env("NO_COLOR", "1");
    for (k, v) in env {
        cmd.env(k, v);
    }
    cmd.stdin(std::process::Stdio::null());
    cmd.stdout(std::process::Stdio::piped());
    cmd.stderr(std::process::Stdio::piped());

    let mut child = spawn_with_deadline(&mut cmd, deadline).map_err(|e| {
        if e.kind() == std::io::ErrorKind::NotFound {
            not_found(&program.to_string_lossy())
        } else {
            crate::Error::from(e)
        }
    })?;

    let mut so = child.stdout.take();
    let mut se = child.stderr.take();
    let mut stdout = Vec::new();
    let mut stderr = Vec::new();
    let result = (|| -> std::io::Result<(Option<std::process::ExitStatus>, bool)> {
        nonblocking(so.as_ref().unwrap())?;
        nonblocking(se.as_ref().unwrap())?;
        let mut status = None;
        loop {
            read_available(&mut so, &mut stdout)?;
            read_available(&mut se, &mut stderr)?;
            if status.is_none() {
                status = child.try_wait()?;
            }
            if status.is_some() && so.is_none() && se.is_none() {
                return Ok((status, false));
            }
            if Instant::now() >= deadline {
                return Ok((status, true));
            }
            std::thread::sleep(Duration::from_millis(2));
        }
    })();
    if !matches!(&result, Ok((_, false))) {
        // Pipe reads are nonblocking, so even a descendant that starts a new session
        // cannot prevent the deadline from returning and closing our descriptors.
        unsafe {
            libc::kill(-(child.id() as i32), libc::SIGKILL);
        }
        let _ = child.kill();
        let _ = child.wait();
    };
    let (status, timed_out) = result?;
    Ok(Output {
        status: if timed_out {
            None
        } else {
            status.and_then(|s| s.code())
        },
        stdout: crate::redact::redact(&String::from_utf8_lossy(&stdout)),
        stderr: crate::redact::redact(&String::from_utf8_lossy(&stderr)),
        timed_out,
    })
}

fn nonblocking(pipe: &impl AsRawFd) -> std::io::Result<()> {
    let fd = pipe.as_raw_fd();
    let flags = unsafe { libc::fcntl(fd, libc::F_GETFL) };
    if flags == -1 || unsafe { libc::fcntl(fd, libc::F_SETFL, flags | libc::O_NONBLOCK) } == -1 {
        return Err(std::io::Error::last_os_error());
    }
    Ok(())
}

fn read_available(r: &mut Option<impl Read>, buf: &mut Vec<u8>) -> std::io::Result<()> {
    let Some(reader) = r.as_mut() else {
        return Ok(());
    };
    let mut chunk = [0u8; 8 * 1024];
    // Bound each drain pass too: a continuously writing child must not starve the clock.
    for _ in 0..32 {
        match reader.read(&mut chunk) {
            Ok(0) => {
                *r = None;
                break;
            }
            Err(e) if e.kind() == ErrorKind::WouldBlock => break,
            Err(e) if e.kind() == ErrorKind::Interrupted => continue,
            Err(e) => return Err(e),
            Ok(n) => {
                if buf.len() < MAX_CAPTURE {
                    let take = n.min(MAX_CAPTURE - buf.len());
                    buf.extend_from_slice(&chunk[..take]);
                }
                // Keep draining past the cap so the child is never blocked on a full pipe.
            }
        }
    }
    Ok(())
}

/// Resolve a program on PATH without running it.
pub fn which(program: &str) -> Option<std::path::PathBuf> {
    let path = std::env::var_os("PATH")?;
    for dir in std::env::split_paths(&path) {
        let candidate = dir.join(program);
        if is_executable(&candidate) {
            return Some(candidate);
        }
    }
    None
}

#[cfg(unix)]
fn is_executable(p: &std::path::Path) -> bool {
    use std::os::unix::fs::PermissionsExt;
    std::fs::metadata(p)
        .map(|m| m.is_file() && m.permissions().mode() & 0o111 != 0)
        .unwrap_or(false)
}

#[cfg(not(unix))]
fn is_executable(p: &std::path::Path) -> bool {
    p.is_file()
}

/// A marker only identifies a candidate owner. PID zero and invalid PIDs are never owners.
pub fn process_alive(pid: u32) -> bool {
    let Ok(pid) = i32::try_from(pid) else {
        return false;
    };
    if pid <= 0 {
        return false;
    }
    // SAFETY: signal zero checks existence/permission without delivering a signal.
    unsafe {
        libc::kill(pid, 0) == 0
            || std::io::Error::last_os_error().raw_os_error() == Some(libc::EPERM)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A binary still open for writing becomes runnable once the writer lets go.
    ///
    /// Linux only, and deliberately so. Holding a write handle to a shell script is a
    /// fixture that behaves differently per platform: on Linux it is the ETXTBSY window the
    /// self-update actually hits, and on macOS it produced a one-in-five timeout that
    /// measured the fixture rather than the code. The portable half of this contract — a
    /// missing program, an absolute path that is not there, a genuine 127 — is asserted
    /// unconditionally below.
    #[cfg(target_os = "linux")]
    #[test]
    fn a_transient_executable_writer_is_retried_within_the_deadline() {
        use std::os::unix::fs::PermissionsExt;
        let dir = tempfile::tempdir().unwrap();
        let binary = dir.path().join("probe");
        std::fs::write(&binary, "#!/bin/sh\necho ready\n").unwrap();
        std::fs::set_permissions(&binary, std::fs::Permissions::from_mode(0o755)).unwrap();
        let writer = std::fs::OpenOptions::new()
            .write(true)
            .open(&binary)
            .unwrap();
        let release = std::thread::spawn(move || {
            std::thread::sleep(Duration::from_millis(40));
            drop(writer);
        });
        let result = run(binary.to_str().unwrap(), &[], Duration::from_secs(1));
        release.join().unwrap();
        let output = result.unwrap();
        assert!(output.ok(), "{output:?}");
        assert_eq!(output.stdout.trim(), "ready");
    }

    /// A writer that never lets go must not turn a 30ms deadline into an unbounded wait.
    ///
    /// The assertion is the deadline, not the outcome, which is what makes it portable: on
    /// a kernel that refuses the exec the call fails, on one that permits it the program
    /// simply runs, and either way the bound holds. Requiring an error encoded one
    /// platform's answer as the contract.
    #[test]
    fn a_persistent_executable_writer_cannot_extend_the_deadline() {
        use std::os::unix::fs::PermissionsExt;
        let dir = tempfile::tempdir().unwrap();
        let binary = dir.path().join("probe");
        std::fs::write(&binary, "#!/bin/sh\nexit 0\n").unwrap();
        std::fs::set_permissions(&binary, std::fs::Permissions::from_mode(0o755)).unwrap();
        let _writer = std::fs::OpenOptions::new()
            .write(true)
            .open(&binary)
            .unwrap();
        let started = Instant::now();
        let _ = run(binary.to_str().unwrap(), &[], Duration::from_millis(30));
        assert!(
            started.elapsed() < Duration::from_millis(250),
            "a blocked exec extended a 30ms deadline to {:?}",
            started.elapsed()
        );
    }

    #[test]
    fn captures_status_and_streams() {
        let o = run(
            "/bin/sh",
            &["-c", "echo out; echo err >&2; exit 3"],
            Duration::from_secs(5),
        )
        .unwrap();
        assert_eq!(o.status, Some(3));
        assert_eq!(o.stdout.trim(), "out");
        assert_eq!(o.stderr.trim(), "err");
    }

    #[test]
    fn a_hung_child_is_killed_at_the_deadline() {
        let started = Instant::now();
        let o = run("/bin/sh", &["-c", "sleep 30"], Duration::from_millis(200)).unwrap();
        assert!(o.timed_out);
        assert!(
            started.elapsed() < Duration::from_secs(5),
            "deadline not enforced"
        );
    }

    #[test]
    fn inherited_output_pipes_do_not_outlive_the_deadline() {
        let start = Instant::now();
        let output = run(
            "/bin/sh",
            &["-c", "sleep 30 & exit 0"],
            Duration::from_millis(100),
        )
        .unwrap();
        assert!(output.timed_out);
        assert!(start.elapsed() < Duration::from_secs(2));
    }

    #[test]
    fn commands_observe_the_requested_working_directory() {
        let dir = tempfile::tempdir().unwrap();
        let output = run_in(
            "/bin/pwd",
            &[],
            &[],
            Some(dir.path()),
            Duration::from_secs(1),
        )
        .unwrap();
        assert!(output.ok());
        assert_eq!(
            Path::new(output.stdout.trim()).canonicalize().unwrap(),
            dir.path().canonicalize().unwrap()
        );
    }

    #[test]
    fn an_argument_is_never_a_shell_word() {
        // If this were `sh -c`, the semicolon would run a second command.
        let o = run(
            "/bin/echo",
            &["a; touch /tmp/wf-should-not-exist"],
            Duration::from_secs(5),
        )
        .unwrap();
        assert_eq!(o.stdout.trim(), "a; touch /tmp/wf-should-not-exist");
        assert!(!std::path::Path::new("/tmp/wf-should-not-exist").exists());
    }

    #[test]
    fn subprocess_output_is_redacted_before_it_is_returned() {
        let o = run(
            "/bin/sh",
            &["-c", "echo 'token gho_AAAAAAAABBBBBBBBCCCCCCCC'"],
            Duration::from_secs(5),
        )
        .unwrap();
        assert!(!o.stdout.contains("gho_AAAA"), "{}", o.stdout);
    }

    /// The message a person actually sees when a tool is not installed.
    ///
    /// This failed on Linux while passing on macOS, and the reason is worth keeping: where
    /// the standard library can use `posix_spawn`, glibc reports a failed exec by having
    /// the child exit 127, so `spawn()` returns `Ok` and the errno never reaches us. The
    /// friendly message was unreachable on exactly the platform half the fleet runs.
    /// Resolution is a stat walk now, so the answer is the same everywhere.
    #[test]
    fn a_missing_program_says_what_to_install() {
        let e = run("wf-definitely-not-a-program", &[], Duration::from_secs(1)).unwrap_err();
        assert_eq!(e.kind, "EXEC-NOT-FOUND");
        assert!(e.zh.contains("找不到命令"));
    }

    #[test]
    fn a_missing_absolute_path_is_also_reported_as_not_found() {
        let e = run(
            "/nonexistent/definitely-not-here",
            &[],
            Duration::from_secs(1),
        )
        .unwrap_err();
        assert_eq!(e.kind, "EXEC-NOT-FOUND");
    }

    /// A program that genuinely exits 127 is reported, not retried into an error.
    #[test]
    fn a_real_127_is_a_result_not_an_exec_failure() {
        let out = run(
            "/bin/sh",
            &["-c", "echo said something; exit 127"],
            Duration::from_secs(5),
        )
        .unwrap();
        assert_eq!(out.status, Some(127));
        assert_eq!(out.stdout.trim(), "said something");
    }
}
