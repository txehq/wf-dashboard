//! Provisioning for the `/review-pr` detector: write the supervisor job, load it, report it.
//!
//! Everything here is operational. The review-only authority boundary belongs to the skill
//! contract and to the detector; nothing in this file may widen it, and in particular no
//! command here posts to GitHub.

use super::emit;
use crate::flags::ReviewPrCmd;
use std::path::PathBuf;
use std::process::Command;
use wf_core::{envelope::Envelope, envelope::Note, Error, ExitCode, Result};
use wf_review_pr::{Job, Options};

pub fn run(json: bool, cmd: ReviewPrCmd) -> Result<ExitCode> {
    match cmd {
        ReviewPrCmd::Install {
            repo,
            poll_seconds,
            max_workers,
            replace,
        } => install(json, &repo, poll_seconds, max_workers, replace),
        ReviewPrCmd::Status { repo } => status(json, repo.as_deref()),
        ReviewPrCmd::Logs { repo, lines } => logs(json, &repo, lines),
        ReviewPrCmd::Uninstall { repo } => uninstall(json, &repo),
    }
}

fn home() -> Result<PathBuf> {
    std::env::var_os("HOME").map(PathBuf::from).ok_or_else(|| {
        Error::failure("REVIEW-PR-NO-HOME", "HOME is not set")
            .with_zh("无法确定用户主目录，请在正常的登录环境中运行。")
    })
}

/// Where the detector lives once installed.
///
/// Through `active`, never a versioned generation directory: `active` is swapped atomically
/// by an update, so a plist pointing at it keeps working while one pointing at
/// `generations/1.1.0/…` breaks the moment the machine updates — silently, because launchd
/// reports a job that exits rather than a missing file anybody reads.
fn script_path(paths: &wf_core::paths::Paths) -> Result<PathBuf> {
    let installed = paths
        .active_link()
        .join("bundle/skills/review-pr/scripts/review_monitor.py");
    if installed.exists() {
        return Ok(installed);
    }
    // A checkout, for developing the skill itself.
    let checkout = super::tools::git_root().join("skills/review-pr/scripts/review_monitor.py");
    if checkout.exists() {
        return Ok(checkout);
    }
    Err(Error::failure(
        "REVIEW-PR-DETECTOR-MISSING",
        format!("no review_monitor.py at {}", installed.display()),
    )
    .with_zh("请先运行 wf install 或 wf sync，把技能安装到这台机器上。"))
}

fn launchctl(args: &[&str]) -> std::io::Result<std::process::Output> {
    Command::new("/bin/launchctl").args(args).output()
}

/// Is a job with this label known to launchd?
fn loaded(label: &str) -> bool {
    launchctl(&["list", label])
        .map(|o| o.status.success())
        .unwrap_or(false)
}

fn install(
    json: bool,
    repo: &str,
    poll_seconds: Option<u32>,
    max_workers: Option<u32>,
    replace: bool,
) -> Result<ExitCode> {
    if !cfg!(target_os = "macos") {
        return Err(Error::unsupported(
            "REVIEW-PR-NO-SUPERVISOR",
            "supervised review currently supports launchd (macOS) only",
        )
        .with_zh("当前仅支持 macOS 的 launchd。"));
    }
    let home = home()?;
    let job = Job::new(repo, &home)?;

    // Refuse rather than race. The pre-port `com.openai.rpr-monitor.*` job polls the same
    // repository from a different state directory, so its leases and circuits cannot see
    // ours: both would spawn a worker for the same uncovered head and the PR would collect
    // two reviews. Distinct labels are what make this detectable instead of an overwrite.
    if let Some(other) = job.conflicting_labels().into_iter().find(|l| loaded(l)) {
        return Err(Error::conflict(
            "REVIEW-PR-LEGACY-JOB",
            format!(
                "{other} is already polling {repo}; two monitors on one repository double-review it. \
                 Unload it first: launchctl bootout gui/$(id -u)/{other}"
            ),
        )
        .with_zh("该仓库已有旧版监控任务在运行，请先卸载它，避免重复评审。"));
    }
    if loaded(&job.label) && !replace {
        return Err(Error::conflict(
            "REVIEW-PR-ALREADY-INSTALLED",
            format!(
                "{} is already loaded; pass --replace to reinstall",
                job.label
            ),
        )
        .with_zh("该任务已安装，如需重装请加 --replace。"));
    }

    let paths = wf_core::paths::Paths::resolve()?;
    let resolver = wf_readiness::Resolver::new();
    let tools = wf_review_pr::resolve_tools(&resolver)?;
    wf_review_pr::check_repo(&tools.gh, &job.repo)?;
    let mut opts = Options {
        script: script_path(&paths)?,
        ..Default::default()
    };
    if let Some(p) = poll_seconds {
        opts.poll_seconds = p;
    }
    if let Some(w) = max_workers {
        opts.max_workers = w;
    }

    for dir in [&job.state_dir, &job.plist, &job.stdout_log] {
        if let Some(parent) = dir.parent() {
            std::fs::create_dir_all(parent)?;
        }
    }
    std::fs::create_dir_all(&job.state_dir)?;
    wf_core::atomic::write_file(
        &job.plist,
        wf_review_pr::plist(&job, &tools, &opts).as_bytes(),
    )?;

    if replace && loaded(&job.label) {
        let _ = launchctl(&["bootout", &format!("gui/{}/{}", uid(), job.label)]);
    }
    let out = launchctl(&[
        "bootstrap",
        &format!("gui/{}", uid()),
        &job.plist.display().to_string(),
    ])
    .map_err(|e| Error::failure("REVIEW-PR-LAUNCHCTL", e.to_string()))?;
    if !out.status.success() {
        return Err(Error::failure(
            "REVIEW-PR-LOAD-FAILED",
            format!(
                "launchctl refused the job: {}",
                String::from_utf8_lossy(&out.stderr).trim()
            ),
        )
        .with_zh("launchd 拒绝加载任务，请检查上面的错误信息。"));
    }

    let mut env = Envelope::new("review-pr install").result(&job);
    // Loading is not polling. The heartbeat is the artifact that proves the detector is
    // actually working, and it does not exist until the first validated poll.
    env = env.warn(Note::new(
        "VERIFY",
        format!(
            "loaded. Confirm it is polling with `wf review-pr status --repo {repo}` \
             once a poll interval has passed — a loaded job is not yet a working one."
        ),
    ));
    Ok(emit(json, env, move || {
        format!(
            "installed {}\n  repo    {}\n  state   {}\n  plist   {}\n  logs    {}\n",
            job.label,
            job.repo,
            job.state_dir.display(),
            job.plist.display(),
            job.stdout_log.display()
        )
    }))
}

fn uid() -> u32 {
    // launchctl's modern domain syntax needs the numeric uid; `id -u` is the portable read.
    Command::new("/usr/bin/id")
        .arg("-u")
        .output()
        .ok()
        .and_then(|o| String::from_utf8_lossy(&o.stdout).trim().parse().ok())
        .unwrap_or(501)
}

/// Report on installed jobs.
///
/// Reads the heartbeat, not just the process table: a live pid proves a process exists, not
/// that it is polling. The detector writes a heartbeat after each validated poll, and that is
/// the artifact that differs when it has wedged.
fn status(json: bool, repo: Option<&str>) -> Result<ExitCode> {
    let home = home()?;
    let dir = home.join("Library/LaunchAgents");
    let mut rows: Vec<serde_json::Value> = Vec::new();
    let entries = std::fs::read_dir(&dir).ok().into_iter().flatten().flatten();
    for e in entries {
        let name = e.file_name().to_string_lossy().to_string();
        let Some(rest) = name.strip_prefix(&format!("{}.", wf_review_pr::LABEL_PREFIX)) else {
            continue;
        };
        let label = format!(
            "{}.{}",
            wf_review_pr::LABEL_PREFIX,
            rest.trim_end_matches(".plist")
        );
        let job_repo = rest.trim_end_matches(".plist").replacen('-', "/", 1);
        if repo.is_some_and(|r| r != job_repo) {
            continue;
        }
        let job = Job::new(&job_repo, &home).ok();
        let heartbeat = job
            .as_ref()
            .and_then(|j| std::fs::metadata(j.state_dir.join("heartbeat.json")).ok())
            .and_then(|m| m.modified().ok())
            .and_then(|t| t.elapsed().ok())
            .map(|d| d.as_secs());
        rows.push(serde_json::json!({
            "label": label,
            "repo": job_repo,
            "loaded": loaded(&label),
            "heartbeat_age_seconds": heartbeat,
        }));
    }
    let empty = rows.is_empty();
    let mut env = Envelope::new("review-pr status").result(&rows);
    if empty {
        env = env.warn(Note::new(
            "NONE",
            "no review-pr jobs installed; `wf review-pr install --repo OWNER/REPO`".to_string(),
        ));
    }
    let render = rows.clone();
    Ok(emit(json, env, move || {
        if render.is_empty() {
            return "no review-pr jobs installed\n".to_string();
        }
        let mut s = String::new();
        for r in &render {
            let hb = match r["heartbeat_age_seconds"].as_u64() {
                Some(n) => format!("{n}s ago"),
                None => "never — not polling yet".to_string(),
            };
            s.push_str(&format!(
                "{}\n  loaded     {}\n  heartbeat  {}\n",
                r["repo"].as_str().unwrap_or(""),
                r["loaded"].as_bool().unwrap_or(false),
                hb
            ));
        }
        s
    }))
}

fn logs(json: bool, repo: &str, lines: u32) -> Result<ExitCode> {
    let job = Job::new(repo, &home()?)?;
    let text = std::fs::read_to_string(&job.stdout_log).unwrap_or_default();
    let tail: Vec<&str> = text.lines().rev().take(lines as usize).collect();
    let body: String = tail.into_iter().rev().collect::<Vec<_>>().join("\n");
    let env = Envelope::new("review-pr logs").result(serde_json::json!({
        "stdout": job.stdout_log.display().to_string(),
        "stderr": job.stderr_log.display().to_string(),
    }));
    Ok(emit(json, env, move || {
        format!("{}\n{body}\n", job.stdout_log.display())
    }))
}

fn uninstall(json: bool, repo: &str) -> Result<ExitCode> {
    let job = Job::new(repo, &home()?)?;
    if loaded(&job.label) {
        let _ = launchctl(&["bootout", &format!("gui/{}/{}", uid(), job.label)]);
    }
    // Workers lead their own process groups so a detector restart leaves a review running;
    // nothing else bounds them, so uninstall is where they end. After the job is unloaded,
    // so nothing dispatches another one behind this.
    let mut stopped = Vec::new();
    for pid in wf_review_pr::running_workers(&job.state_dir)? {
        if wf_review_pr::stop_worker(pid) {
            stopped.push(pid);
        }
    }
    let removed = std::fs::remove_file(&job.plist).is_ok();
    let mut env = Envelope::new("review-pr uninstall").result(&job);
    if !stopped.is_empty() {
        env = env.warn(Note::new(
            "WORKERS-STOPPED",
            format!(
                "ended {} reviewer(s) still running: {}",
                stopped.len(),
                stopped
                    .iter()
                    .map(i32::to_string)
                    .collect::<Vec<_>>()
                    .join(", ")
            ),
        ));
    }
    // State is deliberately left behind: it holds the attempt and usage history, and GitHub
    // remains the coverage truth, so a reinstall reconstructs from the PRs regardless.
    env = env.warn(Note::new(
        "STATE-KEPT",
        format!("state left at {}", job.state_dir.display()),
    ));
    Ok(emit(json, env, move || {
        format!(
            "{} {}\n",
            if removed { "removed" } else { "not installed" },
            job.label
        )
    }))
}
