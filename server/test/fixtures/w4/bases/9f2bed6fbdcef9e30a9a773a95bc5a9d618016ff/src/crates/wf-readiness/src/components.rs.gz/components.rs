//! Registry components `wf` must have put into the agent that runs the check.
//!
//! Linear reaches a session as the `capso-linear` MCP server `wf` writes into each agent's
//! own configuration (ADR-0007), so "can this session file, claim and close a ticket" is a
//! question about that agent's copy of `capso.mcp.linear`. It is read the way `wf status`
//! reads it — the agent's own files against the active generation and the ownership rows —
//! and the server is never called: it logs in through the browser, and an object in place is
//! never reported as a login that works.

use crate::{Finding, Severity, Tier};
use wf_agents::engine::Context;
use wf_agents::{Desired, ObjectStatus, ResourceKind, TeamAIAdapter};
use wf_core::{Error, Result};
use wf_registry::Kind;
use wf_state::Db;

pub const COMPONENT_OK: &str = "COMPONENT-OK";
pub const COMPONENT_MISSING: &str = "COMPONENT-MISSING";
pub const COMPONENT_DRIFT: &str = "COMPONENT-DRIFT";
pub const COMPONENT_DECLINED: &str = "COMPONENT-DECLINED";

/// What `wf` installed on a machine: the active generation's agent layer, and the state
/// database that records which objects it owns and which a person declined.
pub struct Installation {
    pub context: Context,
    pub db: Db,
}

impl Installation {
    /// This machine's, or `None` when `wf` has no active generation here.
    pub fn here() -> Result<Option<Self>> {
        let paths = wf_core::paths::Paths::resolve()?;
        let db = Db::open_read_only(&paths.db())?;
        let Some(generation) = db.active_generation()? else {
            return Ok(None);
        };
        let bundle = paths.generation(&generation.version).join("bundle");
        let context = Context::load(&bundle, &paths)?;
        Ok(Some(Self { context, db }))
    }
}

/// The agent whose session started this process, from the marker each one sets in the
/// environment of every command it runs.
pub fn running_agent(env: &dyn Fn(&str) -> Option<String>) -> Option<&'static str> {
    [("CLAUDECODE", "claude-code"), ("CODEX_THREAD_ID", "codex")]
        .into_iter()
        .find(|(key, _)| env(key).is_some_and(|v| !v.is_empty()))
        .map(|(_, agent)| agent)
}

/// One finding per required component and agent. `agent` is the agent running the check;
/// without one, every agent `wf` manages on this machine must carry the component, because
/// the session that does the work may run in any of them.
pub(crate) fn check(
    installation: Option<&Installation>,
    agent: Option<&str>,
    required: &[String],
) -> Result<Vec<Finding>> {
    if required.is_empty() {
        return Ok(vec![]);
    }
    let Some(installation) = installation else {
        return Ok(required
            .iter()
            .map(|id| Finding {
                code: COMPONENT_MISSING.into(),
                subject: id.clone(),
                severity: Severity::Fail,
                detail: format!("wf is not installed on this machine, so no agent carries {id}"),
                fix: "wf install".into(),
                tier: Some(Tier::Manual),
                zh: format!(
                    "这台机器还没有安装 wf，所以没有哪个 agent 带着 {id}。运行 `wf install`。"
                ),
            })
            .collect());
    };
    let ctx = &installation.context;
    let registry = ctx.repo.registry()?;
    let mut kinds = Vec::new();
    for id in required {
        let component = registry
            .components
            .iter()
            .find(|c| &c.id == id)
            .ok_or_else(|| {
                Error::usage(
                    "READINESS-COMPONENT",
                    format!("{id} is not a component of the installed release"),
                )
            })?;
        kinds.push(match component.kind {
            Kind::Skill => ResourceKind::Skill,
            Kind::Mcp => ResourceKind::Mcp,
            Kind::PromptBlock => ResourceKind::Prompt,
            Kind::HookDispatcher => ResourceKind::Hook,
            Kind::HookPolicy | Kind::ReadinessProfile => {
                return Err(Error::usage(
                    "READINESS-COMPONENT",
                    format!(
                        "{id} is a {} and is never placed in an agent",
                        component.kind.as_str()
                    ),
                ))
            }
        });
    }
    kinds.sort();
    kinds.dedup();
    let desired = Desired::scan_kinds(&ctx.repo, &kinds);
    let skipped = installation.db.skipped_mcps()?;
    let mut findings = Vec::new();
    for adapter in wf_agents::engine::select_agents(ctx, &installation.db, agent)? {
        // Named, the agent is the one running this check. Unnamed, an agent that is not on
        // this machine cannot be where the work happens.
        if agent.is_none() && adapter.detect()?.is_none() {
            continue;
        }
        let owned = installation.db.managed_resources(Some(adapter.id()))?;
        let state = adapter.inspect(&desired, &owned, &skipped)?;
        for id in required {
            let object = state.objects.iter().find(|o| &o.component_id == id);
            findings.push(finding(
                id,
                adapter.id(),
                adapter.display_name(),
                object.map(|o| (o.status, o.detail.as_str())),
            ));
        }
    }
    if findings.is_empty() {
        findings.extend(required.iter().map(|id| Finding {
            code: COMPONENT_MISSING.into(),
            subject: id.clone(),
            severity: Severity::Fail,
            detail: format!("no agent wf manages is on this machine, so none carries {id}"),
            fix: "wf install".into(),
            tier: Some(Tier::Manual),
            zh: format!(
                "这台机器上没有 wf 管理的 agent，所以没有哪个带着 {id}。运行 `wf install`。"
            ),
        }));
    }
    Ok(findings)
}

fn finding(id: &str, agent: &str, display: &str, object: Option<(ObjectStatus, &str)>) -> Finding {
    let subject = format!("{id} ({agent})");
    let repair = format!("wf repair --component {id} --agent {agent}");
    let Some((status, detail)) = object else {
        return Finding {
            code: COMPONENT_MISSING.into(),
            subject,
            severity: Severity::Fail,
            detail: format!("{display} has no place for {id}"),
            fix: String::new(),
            tier: Some(Tier::Manual),
            zh: format!("{display} 放不下 {id}，在这个 agent 里做不了需要它的工作。"),
        };
    };
    let said = if detail.is_empty() {
        String::new()
    } else {
        format!(" ({detail})")
    };
    let (code, severity, fix, zh) = match status {
        ObjectStatus::Current | ObjectStatus::Kept => (
            COMPONENT_OK,
            Severity::Note,
            String::new(),
            String::new(),
        ),
        // Only the entry this release installs is proof the component is there. A changed or
        // older entry may point anywhere — the retired Linear endpoint, a different command —
        // and a declined one is not there at all; either way the work that needs it cannot
        // start on the strength of it.
        ObjectStatus::Outdated | ObjectStatus::Drifted => (
            COMPONENT_DRIFT,
            Severity::Fail,
            repair.clone(),
            format!(
                "{display} 里的 {id} 和这个版本不一致，不能确定它还能用。运行 `{repair}` 换回这个版本的配置。"
            ),
        ),
        ObjectStatus::SkippedByUser => (
            COMPONENT_DECLINED,
            Severity::Fail,
            format!("wf mcp unskip {id} --agent {agent} && {repair}"),
            format!(
                "这台机器上选择了不在 {display} 里安装 {id}，需要它的工作在这里做不了。要装回它，运行 `wf mcp unskip {id} --agent {agent}`，再运行 `{repair}`。"
            ),
        ),
        ObjectStatus::Conflict => (
            COMPONENT_MISSING,
            Severity::Fail,
            "wf doctor".into(),
            format!(
                "{display} 里同名的配置不是 wf 安装的 {id}，wf 不会改动它。运行 `wf doctor` 查看详细情况。"
            ),
        ),
        ObjectStatus::Missing
        | ObjectStatus::Stale
        | ObjectStatus::Skipped
        | ObjectStatus::Blocked => (
            COMPONENT_MISSING,
            Severity::Fail,
            repair.clone(),
            format!("{display} 里没有 wf 安装的 {id}，这个会话用不了它。运行 `{repair}` 装回去。"),
        ),
    };
    Finding {
        code: code.into(),
        subject,
        severity,
        detail: format!("{id} in {display} is {}{said}", status.as_str()),
        fix,
        tier: (severity != Severity::Note).then_some(Tier::Manual),
        zh,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::BTreeMap;
    use std::path::{Path, PathBuf};

    /// This checkout as the generation, deployed for real into a disposable home.
    struct Machine {
        _dir: tempfile::TempDir,
        installation: Installation,
        claude_mcp: PathBuf,
    }

    impl Machine {
        fn new() -> Self {
            let dir = tempfile::tempdir().unwrap();
            let home = dir.path().join("home");
            std::fs::create_dir_all(home.join(".claude")).unwrap();
            let bundle = Path::new(env!("CARGO_MANIFEST_DIR"))
                .join("../..")
                .canonicalize()
                .unwrap();
            let env = BTreeMap::from([("PATH".to_string(), "/usr/bin:/bin".to_string())]);
            let context = Context::new(
                &bundle,
                &home,
                dir.path().join("bin/wf"),
                dir.path().join("docs"),
                None,
                env,
            )
            .unwrap();
            let db = Db::open(&dir.path().join("state.db")).unwrap();
            Self {
                claude_mcp: home.join(".claude.json"),
                installation: Installation { context, db },
                _dir: dir,
            }
        }

        /// What `wf install` does to one agent: apply the generation and commit.
        fn install(&self, agent: &str) {
            let ctx = &self.installation.context;
            let adapters =
                wf_agents::engine::select_agents(ctx, &self.installation.db, Some(agent)).unwrap();
            let mut tx = wf_state::Transaction::begin(
                &self.installation.db,
                self._dir.path().join("backups"),
                "0.0.0",
                false,
            );
            wf_agents::engine::apply(ctx, &adapters, &mut tx).unwrap();
            tx.commit().unwrap();
        }
    }

    fn linear() -> Vec<String> {
        vec!["capso.mcp.linear".into()]
    }

    #[test]
    fn the_linear_requirement_is_met_by_the_mcp_server_wf_installed() {
        let m = Machine::new();
        let before = check(Some(&m.installation), Some("claude-code"), &linear()).unwrap();
        assert_eq!(before.len(), 1, "{before:?}");
        assert_eq!(before[0].code, COMPONENT_MISSING);
        assert_eq!(before[0].severity, Severity::Fail);
        assert_eq!(
            before[0].fix,
            "wf repair --component capso.mcp.linear --agent claude-code"
        );

        m.install("claude-code");
        let written = std::fs::read_to_string(&m.claude_mcp).unwrap();
        assert!(written.contains("capso-linear"), "{written}");
        let after = check(Some(&m.installation), Some("claude-code"), &linear()).unwrap();
        assert_eq!(after.len(), 1, "{after:?}");
        assert_eq!(after[0].code, COMPONENT_OK, "{after:?}");
        assert_eq!(after[0].severity, Severity::Note);
        assert_eq!(after[0].subject, "capso.mcp.linear (claude-code)");
    }

    #[test]
    fn a_server_removed_from_the_agent_is_missing_again() {
        let m = Machine::new();
        m.install("claude-code");
        let mut doc: serde_json::Value =
            serde_json::from_str(&std::fs::read_to_string(&m.claude_mcp).unwrap()).unwrap();
        doc["mcpServers"]
            .as_object_mut()
            .unwrap()
            .remove("capso-linear")
            .unwrap();
        std::fs::write(&m.claude_mcp, serde_json::to_string(&doc).unwrap()).unwrap();
        let found = check(Some(&m.installation), Some("claude-code"), &linear()).unwrap();
        assert_eq!(found[0].code, COMPONENT_MISSING, "{found:?}");
    }

    /// An entry changed after install — here pointed back at Linear's retired endpoint — is no
    /// proof the component works, so the work that needs it does not start on it.
    #[test]
    fn a_changed_entry_blocks_with_the_repair_that_restores_it() {
        let m = Machine::new();
        m.install("claude-code");
        let mut doc: serde_json::Value =
            serde_json::from_str(&std::fs::read_to_string(&m.claude_mcp).unwrap()).unwrap();
        doc["mcpServers"]["capso-linear"]["args"] =
            serde_json::json!(["-y", "mcp-remote", "https://mcp.linear.app/sse"]);
        std::fs::write(&m.claude_mcp, serde_json::to_string(&doc).unwrap()).unwrap();
        let found = check(Some(&m.installation), Some("claude-code"), &linear()).unwrap();
        assert_eq!(found[0].code, COMPONENT_DRIFT, "{found:?}");
        assert_eq!(found[0].severity, Severity::Fail);
        assert_eq!(
            found[0].fix,
            "wf repair --component capso.mcp.linear --agent claude-code"
        );
    }

    /// A server the person declined is not there, so the work that needs it cannot start; the
    /// fix names both commands that bring it back.
    #[test]
    fn a_declined_component_blocks_with_unskip_and_repair() {
        let m = Machine::new();
        m.installation
            .db
            .record_skipped_mcp(&wf_state::SkippedMcp {
                agent_id: "claude-code".into(),
                component_id: "capso.mcp.linear".into(),
                skipped_at: "2026-09-22T00:00:00Z".into(),
                reason: "uses its own Linear connection".into(),
                host: "mcp.linear.app".into(),
                source: "user".into(),
            })
            .unwrap();
        m.install("claude-code");
        let found = check(Some(&m.installation), Some("claude-code"), &linear()).unwrap();
        assert_eq!(found[0].code, COMPONENT_DECLINED, "{found:?}");
        assert_eq!(found[0].severity, Severity::Fail);
        assert_eq!(
            found[0].fix,
            "wf mcp unskip capso.mcp.linear --agent claude-code && wf repair --component capso.mcp.linear --agent claude-code"
        );
    }

    #[test]
    fn without_a_running_agent_every_managed_agent_on_the_machine_must_carry_it() {
        let m = Machine::new();
        m.install("claude-code");
        let found = check(Some(&m.installation), None, &linear()).unwrap();
        let subjects: Vec<&str> = found.iter().map(|f| f.subject.as_str()).collect();
        assert_eq!(subjects, ["capso.mcp.linear (claude-code)"], "{found:?}");
        assert_eq!(found[0].code, COMPONENT_OK);
    }

    #[test]
    fn a_machine_without_wf_carries_nothing() {
        let found = check(None, Some("codex"), &linear()).unwrap();
        assert_eq!(found[0].code, COMPONENT_MISSING);
        assert_eq!(found[0].fix, "wf install");
    }

    #[test]
    fn an_unknown_component_is_a_usage_error() {
        let m = Machine::new();
        let err = check(
            Some(&m.installation),
            Some("claude-code"),
            &["linear@claude-plugins-official".into()],
        )
        .unwrap_err();
        assert_eq!(err.kind, "READINESS-COMPONENT");
    }

    #[test]
    fn the_running_agent_is_read_from_its_own_marker() {
        let env = |pairs: &'static [(&'static str, &'static str)]| {
            move |key: &str| {
                pairs
                    .iter()
                    .find(|(k, _)| *k == key)
                    .map(|(_, v)| v.to_string())
            }
        };
        assert_eq!(
            running_agent(&env(&[("CLAUDECODE", "1")])),
            Some("claude-code")
        );
        assert_eq!(
            running_agent(&env(&[("CODEX_THREAD_ID", "01a0c836")])),
            Some("codex")
        );
        assert_eq!(running_agent(&env(&[])), None);
    }
}
