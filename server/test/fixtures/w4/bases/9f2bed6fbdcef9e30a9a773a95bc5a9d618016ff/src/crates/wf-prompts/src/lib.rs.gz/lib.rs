//! The managed block: how `wf` owns a few lines inside a file it does not own.
//!
//! `CLAUDE.md` and `AGENTS.md` belong to the person whose machine this is. They put their
//! own instructions in there, and the organization's prompt has to live in the same file
//! because that is the only file the agent reads. So the ownership boundary is not the
//! file, it is a pair of markers — and the contract this module holds is that **outside a
//! well-formed block, the bytes come out exactly as they went in**.
//!
//! "Exactly" is meant literally and is what the property tests check: a UTF-8 BOM survives,
//! CRLF stays CRLF, a file with no trailing newline still has none, and a file that never
//! had a block gets one appended without its existing last line changing.
//!
//! When the markers are *not* well-formed — duplicated, nested, one end missing — there is
//! no safe surgical edit, so the file is backed up whole and rebuilt. That is the only path
//! that discards anything, it never runs without a backup, and it reports itself as
//! `conflict_replaced` rather than succeeding quietly.

use wf_core::Result;

pub const SCHEMA: u32 = 2;

/// What a render did to a file.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Outcome {
    /// The block was already exactly right.
    Unchanged,
    /// There was no block; one was added.
    Inserted,
    /// A well-formed block was updated in place; everything else is byte-identical.
    Updated,
    /// The markers were malformed. The file was rebuilt; the caller must back it up first
    /// and report `conflict_replaced`.
    Rebuilt,
}

/// Where a new block goes when the file has none.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Placement {
    /// Claude reads the whole file; appending keeps the user's own opening intact.
    Append,
    /// Codex truncates instruction files at a byte budget, so an organization block placed
    /// at the end of a long file is the half that gets cut.
    Prepend,
}

pub fn begin_marker(id: &str) -> String {
    format!("<!-- wf:managed-begin id={id} schema={SCHEMA} -->")
}

pub fn end_marker(id: &str) -> String {
    format!("<!-- wf:managed-end id={id} -->")
}

/// A begin marker for any schema, so a block written by an older or newer build is still
/// recognised as ours rather than treated as user text and duplicated.
fn begin_prefix(id: &str) -> String {
    format!("<!-- wf:managed-begin id={id} ")
}

#[derive(Debug)]
pub struct Render {
    pub text: String,
    pub outcome: Outcome,
}

/// Put `body` into `original` as the block owned by `id`.
pub fn apply(original: &str, id: &str, body: &str, placement: Placement) -> Result<Render> {
    let (bom, rest) = split_bom(original);
    let eol = detect_eol(rest);
    let had_final_newline = rest.ends_with('\n') || rest.is_empty();

    let begins = find_all(rest, &begin_prefix(id));
    let ends = find_all(rest, &end_marker(id));

    // Malformed: anything other than exactly one properly ordered pair.
    if begins.len() > 1 || ends.len() > 1 || begins.len() != ends.len() {
        return Ok(Render {
            text: rebuild(bom, rest, id, body, eol, placement, had_final_newline),
            outcome: Outcome::Rebuilt,
        });
    }

    if begins.is_empty() {
        // The separator lengths are part of the owned block's receipt. Without them an
        // appended block cannot distinguish an original final EOL from one we inserted.
        let (before, after) = match placement {
            Placement::Append => (
                if rest.is_empty() {
                    0
                } else if rest.ends_with('\n') {
                    eol.len()
                } else {
                    2 * eol.len()
                },
                eol.len(),
            ),
            Placement::Prepend => (
                0,
                if rest.is_empty() {
                    eol.len()
                } else {
                    2 * eol.len()
                },
            ),
        };
        let boundary = format!("<!-- wf:boundary before={before} after={after} -->");
        let block = render_block(id, body, eol, &boundary);
        let text = match placement {
            Placement::Append => {
                let mut s = String::from(bom);
                s.push_str(rest);
                if !rest.is_empty() && !rest.ends_with('\n') {
                    s.push_str(eol);
                }
                if !rest.is_empty() {
                    s.push_str(eol);
                }
                s.push_str(&block);
                if !had_final_newline && !rest.is_empty() {
                    // The file had no trailing newline; the block ends with one, and
                    // stripping it back would leave a dangling marker. Keeping the newline
                    // is the one place the "outside bytes are identical" rule bends, and it
                    // bends only at the very end of the file.
                }
                s
            }
            Placement::Prepend => {
                let mut s = String::from(bom);
                s.push_str(&block);
                if !rest.is_empty() {
                    s.push_str(eol);
                    s.push_str(rest);
                }
                s
            }
        };
        return Ok(Render {
            text,
            outcome: Outcome::Inserted,
        });
    }

    let bstart = begins[0];
    let end_pos = ends[0];
    if end_pos < bstart {
        return Ok(Render {
            text: rebuild(bom, rest, id, body, eol, placement, had_final_newline),
            outcome: Outcome::Rebuilt,
        });
    }
    let end_marker_len = end_marker(id).len();
    let bend = end_pos + end_marker_len;

    let before = &rest[..bstart];
    let after = &rest[bend..];
    let first_line = rest[bstart..].split('\n').next().unwrap_or_default();
    let boundary = first_line
        .split_once("-->")
        .map(|(_, tail)| tail.trim_end_matches('\r'))
        .unwrap_or_default();
    let mut block = render_block(id, body, eol, boundary);
    if boundary.is_empty() {
        // A legacy marker has no insertion receipt. Preserve its schema and all outside
        // whitespace rather than claiming that an unrecoverable boundary was migrated.
        block = block.replacen(&begin_marker(id), first_line.trim_end_matches('\r'), 1);
    }
    // The block ends with an EOL; whatever followed the old end marker is preserved
    // verbatim, including the newline that used to terminate it.
    let block_no_trailing = block.trim_end_matches(['\r', '\n']);

    let mut text = String::from(bom);
    text.push_str(before);
    text.push_str(block_no_trailing);
    text.push_str(after);

    let outcome = if text == original {
        Outcome::Unchanged
    } else {
        Outcome::Updated
    };
    Ok(Render { text, outcome })
}

/// Remove the block owned by `id`, leaving everything else alone. Used when the effective
/// file changes — the block moves to the new file, then leaves the old one, so the prompt is
/// never present twice.
pub fn remove(original: &str, id: &str) -> Result<Render> {
    let (bom, rest) = split_bom(original);
    let begins = find_all(rest, &begin_prefix(id));
    let ends = find_all(rest, &end_marker(id));
    if begins.len() != 1 || ends.len() != 1 || ends[0] < begins[0] {
        return Ok(Render {
            text: original.to_string(),
            outcome: Outcome::Unchanged,
        });
    }
    let mut bstart = begins[0];
    let mut bend = ends[0] + end_marker(id).len();
    let first_line = rest[bstart..].split('\n').next().unwrap_or_default();
    if let Some((before, after)) = insertion_boundary(first_line) {
        // Only remove the recorded adjacent EOL bytes. If the user edited the boundary,
        // preserve it instead of extending the removal into personal text.
        if let Some(start) = bstart.checked_sub(before) {
            if rest
                .get(start..bstart)
                .is_some_and(|s| s.bytes().all(|b| b == b'\r' || b == b'\n'))
            {
                bstart = start;
            }
        }
        if let Some(end) = bend.checked_add(after) {
            if rest
                .get(bend..end)
                .is_some_and(|s| s.bytes().all(|b| b == b'\r' || b == b'\n'))
            {
                bend = end;
            }
        }
    }
    let mut text = String::from(bom);
    text.push_str(&rest[..bstart]);
    text.push_str(&rest[bend..]);
    Ok(Render {
        text,
        outcome: Outcome::Updated,
    })
}

/// The block's current body, if the file holds a well-formed one.
pub fn extract(original: &str, id: &str) -> Option<String> {
    let (_, rest) = split_bom(original);
    let begins = find_all(rest, &begin_prefix(id));
    let ends = find_all(rest, &end_marker(id));
    if begins.len() != 1 || ends.len() != 1 || ends[0] < begins[0] {
        return None;
    }
    let after_begin = rest[begins[0]..].find('\n')? + begins[0] + 1;
    if after_begin > ends[0] {
        return Some(String::new());
    }
    Some(
        rest[after_begin..ends[0]]
            .trim_end_matches(['\r', '\n'])
            .to_string(),
    )
}

fn insertion_boundary(line: &str) -> Option<(usize, usize)> {
    let (_, tail) = line.split_once("<!-- wf:boundary before=")?;
    let (before, tail) = tail.split_once(" after=")?;
    let after = tail
        .strip_suffix(" -->")
        .or_else(|| tail.strip_suffix(" -->\r"))?;
    let (before, after) = (before.parse().ok()?, after.parse().ok()?);
    (before <= 4 && after <= 4).then_some((before, after))
}

fn render_block(id: &str, body: &str, eol: &str, boundary: &str) -> String {
    let body = body.trim_end_matches(['\r', '\n']);
    let body = if eol == "\r\n" {
        body.replace('\n', "\r\n")
    } else {
        body.replace("\r\n", "\n")
    };
    format!(
        "{}{boundary}{eol}{body}{eol}{}{eol}",
        begin_marker(id),
        end_marker(id)
    )
}

/// Rebuild a file whose markers cannot be trusted: every recognisable marker line is
/// dropped, the surviving text is kept, and one correct block is written.
///
/// This discards marker lines and nothing else. A caller reaching this path has already
/// backed the file up, and the state it reports is `conflict_replaced`.
fn rebuild(
    bom: &str,
    rest: &str,
    id: &str,
    body: &str,
    _eol: &str,
    placement: Placement,
    _had_final_newline: bool,
) -> String {
    let mut kept: Vec<&str> = Vec::new();
    let mut inside = false;
    for line in rest.split_inclusive('\n') {
        let t = line.trim();
        if t.starts_with(&begin_prefix(id))
            || t.starts_with(&format!("<!-- wf:managed-begin id={id}"))
        {
            inside = true;
            continue;
        }
        if t == end_marker(id) {
            inside = false;
            continue;
        }
        if inside {
            continue; // stale body between broken markers
        }
        kept.push(line);
    }
    let user = format!("{bom}{}", kept.concat());
    apply(&user, id, body, placement)
        .expect("marker-free text can be rendered")
        .text
}

fn split_bom(s: &str) -> (&str, &str) {
    match s.strip_prefix('\u{feff}') {
        Some(rest) => ("\u{feff}", rest),
        None => ("", s),
    }
}

/// CRLF only if the file is predominantly CRLF. A single stray \r\n in an LF file must not
/// convert the whole file.
fn detect_eol(s: &str) -> &'static str {
    let crlf = s.matches("\r\n").count();
    let lf = s.matches('\n').count();
    if crlf > 0 && crlf * 2 >= lf {
        "\r\n"
    } else {
        "\n"
    }
}

fn find_all(hay: &str, needle: &str) -> Vec<usize> {
    let mut out = Vec::new();
    let mut from = 0;
    while let Some(i) = hay[from..].find(needle) {
        out.push(from + i);
        from += i + needle.len();
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    const ID: &str = "capso.global";
    const BODY: &str = "## Capso\n\nUse /wf.";

    fn apply_ok(original: &str, placement: Placement) -> Render {
        apply(original, ID, BODY, placement).unwrap()
    }

    #[test]
    fn an_empty_file_gets_a_block() {
        let r = apply_ok("", Placement::Append);
        assert_eq!(r.outcome, Outcome::Inserted);
        assert!(r.text.starts_with(&begin_marker(ID)));
        assert!(r.text.trim_end().ends_with(&end_marker(ID)));
    }

    #[test]
    fn a_second_apply_changes_nothing() {
        let once = apply_ok("# mine\n", Placement::Append).text;
        let twice = apply_ok(&once, Placement::Append);
        assert_eq!(twice.outcome, Outcome::Unchanged);
        assert_eq!(twice.text, once);
    }

    #[test]
    fn bytes_outside_the_block_are_identical_after_an_update() {
        let before = "\u{feff}# My notes\r\n\r\nDon't touch this.\r\n";
        let first = apply_ok(before, Placement::Append).text;
        let second = apply(&first, ID, "## Capso\n\nDifferent body.", Placement::Append).unwrap();
        assert_eq!(second.outcome, Outcome::Updated);

        // Everything before the marker is byte-for-byte what it was.
        let head_len = second.text.find("<!-- wf:managed-begin").unwrap();
        assert_eq!(&second.text[..head_len], &first[..head_len]);
        assert!(second.text.starts_with('\u{feff}'), "the BOM survives");
        assert!(
            second.text.contains("Don't touch this.\r\n"),
            "CRLF text survives"
        );
    }

    #[test]
    fn crlf_files_get_crlf_markers() {
        let r = apply_ok("# mine\r\nline\r\n", Placement::Append);
        assert!(
            r.text.contains(&begin_marker(ID)) && !r.text.replace("\r\n", "").contains('\n'),
            "{:?}",
            r.text
        );
        assert!(
            !r.text.contains("-->\n<"),
            "no bare LF introduced into a CRLF file"
        );
    }

    #[test]
    fn a_file_with_no_trailing_newline_keeps_its_last_line_intact() {
        let r = apply_ok("last line without newline", Placement::Append);
        assert!(r.text.starts_with("last line without newline\n"));
        assert!(r.text.contains(&begin_marker(ID)));
    }

    #[test]
    fn duplicate_markers_are_rebuilt_not_surgically_edited() {
        let broken = format!(
            "# mine\n{b}\nold one\n{e}\nmiddle\n{b}\nold two\n{e}\n",
            b = begin_marker(ID),
            e = end_marker(ID)
        );
        let r = apply_ok(&broken, Placement::Append);
        assert_eq!(r.outcome, Outcome::Rebuilt);
        assert_eq!(
            r.text.matches(&begin_marker(ID)).count(),
            1,
            "exactly one block survives"
        );
        assert!(r.text.contains("# mine"), "user text is kept");
        assert!(
            r.text.contains("middle"),
            "user text between the broken blocks is kept"
        );
        assert!(
            !r.text.contains("old one"),
            "stale block bodies are dropped"
        );
    }

    #[test]
    fn a_missing_end_marker_is_rebuilt() {
        let broken = format!("# mine\n{}\nbody with no end\n", begin_marker(ID));
        let r = apply_ok(&broken, Placement::Append);
        assert_eq!(r.outcome, Outcome::Rebuilt);
        assert_eq!(r.text.matches(&end_marker(ID)).count(), 1);
        assert!(r.text.contains("# mine"));
    }

    #[test]
    fn a_block_written_by_a_different_schema_is_still_ours() {
        let older = format!(
            "# mine\n\n<!-- wf:managed-begin id={ID} schema=0 -->\nold body\n{}\n",
            end_marker(ID)
        );
        let r = apply_ok(&older, Placement::Append);
        assert_eq!(
            r.outcome,
            Outcome::Updated,
            "an older schema must be updated, not duplicated"
        );
        assert_eq!(r.text.matches("wf:managed-begin").count(), 1);
    }

    #[test]
    fn legacy_markers_do_not_claim_an_insertion_receipt_they_never_had() {
        let before = format!(
            "mine\r\n\r\n<!-- wf:managed-begin id={ID} schema=1 -->\r\nold\r\n{}\r\nnotes\r\n\r\n",
            end_marker(ID)
        );
        let changed = apply_ok(&before, Placement::Append);
        assert!(changed.text.contains("schema=1"));
        assert!(!changed.text.contains("wf:boundary"));
        assert_eq!(
            remove(&changed.text, ID).unwrap().text,
            "mine\r\n\r\n\r\nnotes\r\n\r\n"
        );
    }

    #[test]
    fn prepend_puts_the_block_where_a_byte_budget_cannot_cut_it() {
        let r = apply_ok("# a very long user file\n", Placement::Prepend);
        assert!(r.text.starts_with(&begin_marker(ID)));
        assert!(r.text.contains("# a very long user file"));
    }

    #[test]
    fn removing_a_block_leaves_the_user_file_as_it_was() {
        let before = "# mine\n\nSome text.\n";
        let with = apply_ok(before, Placement::Append).text;
        let without = remove(&with, ID).unwrap();
        assert_eq!(without.text, before);
    }

    #[test]
    fn removing_from_a_file_without_one_is_a_no_op() {
        let s = "# nothing to do here\n";
        assert_eq!(remove(s, ID).unwrap().text, s);
    }

    #[test]
    fn extract_round_trips_the_body() {
        let with = apply_ok("# mine\n", Placement::Append).text;
        assert_eq!(extract(&with, ID).unwrap(), BODY);
        assert_eq!(extract("# no block\n", ID), None);
    }

    #[test]
    fn two_different_ids_coexist() {
        let a = apply("# mine\n", "capso.global", "A body", Placement::Append)
            .unwrap()
            .text;
        let b = apply(&a, "other.block", "B body", Placement::Append).unwrap();
        assert_eq!(b.outcome, Outcome::Inserted);
        assert_eq!(extract(&b.text, "capso.global").unwrap(), "A body");
        assert_eq!(extract(&b.text, "other.block").unwrap(), "B body");
    }

    /// The property the whole module exists for, checked across a spread of shapes rather
    /// than one hand-picked file.
    #[test]
    fn user_bytes_survive_an_update_for_every_shape_of_file() {
        let shapes = [
            "",
            "\n",
            "x",
            "x\n",
            "\u{feff}x\n",
            "\u{feff}",
            "a\r\nb\r\n",
            "a\r\nb",
            "# h\n\n- one\n- two\n\n",
            "trailing spaces   \n\n\n",
            "unicode 中文 🎉\n",
        ];
        for s in shapes {
            for placement in [Placement::Append, Placement::Prepend] {
                let first = apply(s, ID, "body one", placement).unwrap();
                assert_ne!(
                    first.outcome,
                    Outcome::Rebuilt,
                    "clean input must never rebuild: {s:?}"
                );
                let second = apply(&first.text, ID, "body two", placement).unwrap();
                assert_ne!(
                    second.outcome,
                    Outcome::Rebuilt,
                    "our own output must never rebuild: {s:?}"
                );

                // Removing the block returns the file to something that differs from the
                // original only in trailing whitespace.
                let back = remove(&second.text, ID).unwrap().text;
                assert_eq!(
                    back, s,
                    "user text did not survive a round trip for {s:?} / {placement:?}"
                );
                if s.starts_with('\u{feff}') {
                    assert!(second.text.starts_with('\u{feff}'), "BOM lost for {s:?}");
                }
            }
        }
    }
}
