//! The release compiler and its client half.
//!
//! `render` turns the registry into every generated surface. `lock` and `bundle` turn those
//! into the two artifacts a machine actually installs. `github` and `source` are how a
//! machine gets them, and `archive` is the part that assumes the bytes are hostile.

pub mod archive;
pub mod bundle;
pub mod ctx;
pub mod github;
pub mod lock;
pub mod render;
pub mod source;

pub use lock::Lock;
pub use source::{Channel, ReleaseRef, ReleaseSource};
