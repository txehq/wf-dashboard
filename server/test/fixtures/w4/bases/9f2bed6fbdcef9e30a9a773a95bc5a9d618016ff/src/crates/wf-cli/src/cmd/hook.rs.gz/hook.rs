use super::hook_options;
use crate::flags::HookCmd;
use serde_json::Value;
use wf_core::{ExitCode, Result};

/// A payload larger than this is not read whole: a tool's output rides in PostToolUse, and
/// nothing wf records needs more than the first few fields.
const PAYLOAD_MAX_BYTES: u64 = 8 * 1024 * 1024;

/// The fixed dispatcher.
///
/// Whatever happens in here, the exit code is 0. Session start prints valid JSON; every other
/// event prints nothing. A session that fails because the workflow manager had a bad day is a
/// session the person cannot use, and there is no version of that trade worth making.
pub fn run(_json: bool, cmd: HookCmd) -> Result<ExitCode> {
    match cmd {
        HookCmd::SessionStart { agent, remote } => {
            let opts = hook_options(&remote).unwrap_or_else(|_| wf_sync::Options::defaults());
            match wf_sync::session_start(&agent, opts, &read_payload()) {
                Ok((out, report)) => {
                    println!("{}", out.render());
                    // The journal is local and content-free: durations and paths taken, never
                    // prompt text and never a transcript.
                    if let Ok(paths) = wf_core::paths::Paths::resolve() {
                        let line = serde_json::to_string(&report).unwrap_or_default();
                        let _ = append_line(&paths.journal(), &line);
                    }
                }
                Err(_) => {
                    println!(
                        "{}",
                        wf_hooks::HookOutput::new(String::new(), None).render()
                    );
                }
            }
            Ok(ExitCode::Ok)
        }
        HookCmd::Dispatch { agent, event } => {
            // Every other event routes through the same trusted argv; what gets recorded is
            // the team policy's call. Adding an event here changes no definition a person
            // approved.
            let _ = wf_sync::session::dispatch(&agent, &event, &read_payload());
            Ok(ExitCode::Ok)
        }
    }
}

/// What the agent handed the hook on stdin, as JSON, or null. Bounded in size, and in time:
/// an agent that never closes stdin costs a second, not the session.
fn read_payload() -> Value {
    use std::io::{IsTerminal, Read};
    if std::io::stdin().is_terminal() {
        return Value::Null;
    }
    let (tx, rx) = std::sync::mpsc::channel();
    std::thread::spawn(move || {
        let mut buf = Vec::new();
        let _ = std::io::stdin()
            .lock()
            .take(PAYLOAD_MAX_BYTES)
            .read_to_end(&mut buf);
        let _ = tx.send(buf);
    });
    rx.recv_timeout(std::time::Duration::from_secs(1))
        .ok()
        .and_then(|buf| serde_json::from_slice(&buf).ok())
        .unwrap_or(Value::Null)
}

fn append_line(path: &std::path::Path, line: &str) -> std::io::Result<()> {
    use std::io::Write;
    if let Some(p) = path.parent() {
        std::fs::create_dir_all(p)?;
    }
    // Keep the journal small enough that it never becomes the reason a disk filled.
    if std::fs::metadata(path)
        .map(|m| m.len() > 4 * 1024 * 1024)
        .unwrap_or(false)
    {
        let _ = std::fs::remove_file(path);
    }
    let mut f = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(path)?;
    writeln!(f, "{line}")
}
