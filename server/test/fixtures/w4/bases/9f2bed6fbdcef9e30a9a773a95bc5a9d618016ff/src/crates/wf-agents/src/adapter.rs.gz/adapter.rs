//! The unified adapter: one trait for every agent, and one implementation of
//! `inspect → apply → verify` for all of them.
//!
//! An adapter answers questions about an agent — where things go, in which format — and the
//! lifecycle is written once on top of those answers and the resource handlers. That is what
//! keeps "add an agent" a configuration change: [`ConfigAdapter`] is the only agent adapter,
//! and it is built from an `agents.yaml` entry.

use crate::formats::{HookFormat, McpFormat};
use crate::policy::Policies;
use crate::registry::{AgentFormats, AgentLocation, AgentSpec, PathKind};
use crate::resources::{ResourceItem, ResourceKind};
use crate::team_repo::TeamRepo;
use crate::Finding;
use serde::Serialize;
use std::collections::BTreeMap;
use std::path::{Path, PathBuf};
use wf_core::Result;
use wf_state::{ManagedResource, SkippedMcp, Transaction};

/// Where an installed agent was found.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct AgentInstall {
    /// Empty when the agent's binary is not on PATH (its configuration root exists).
    pub binary: PathBuf,
    /// Empty until [`probe_version`] asks the binary.
    pub version: String,
    pub config_root: PathBuf,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize)]
pub struct AgentConfigPaths {
    pub settings: Option<PathBuf>,
    pub hooks: Option<PathBuf>,
    pub mcp: Option<PathBuf>,
    pub prompt: Option<PathBuf>,
}

/// One object's standing in one agent.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum ObjectStatus {
    /// In place, as the team repository has it.
    Current,
    /// Not there yet.
    Missing,
    /// wf's copy, from an earlier release.
    Outdated,
    /// wf's copy, changed since wf wrote it.
    Drifted,
    /// Changed by a person, and left that way on purpose.
    Kept,
    /// wf's copy of something the team repository no longer has.
    Stale,
    /// Something of the same name that is not wf's; left alone.
    Conflict,
    /// Not applied, by policy.
    Skipped,
    /// Not applied, because a person on this machine said not to.
    ///
    /// Distinct from [`Skipped`](ObjectStatus::Skipped), which is the team's policy speaking
    /// and can change with the release. This one is a decision recorded on the machine, and
    /// only a person undoes it. It is settled: nothing is missing, nothing needs repairing,
    /// and the object is not an orphan — it is exactly what was asked for.
    SkippedByUser,
    /// Refused, or unreadable; left as it is.
    Blocked,
}

impl ObjectStatus {
    pub fn as_str(self) -> &'static str {
        match self {
            ObjectStatus::Current => "current",
            ObjectStatus::Missing => "missing",
            ObjectStatus::Outdated => "outdated",
            ObjectStatus::Drifted => "drifted",
            ObjectStatus::Kept => "kept",
            ObjectStatus::Stale => "stale",
            ObjectStatus::Conflict => "conflict",
            ObjectStatus::Skipped => "skipped",
            ObjectStatus::SkippedByUser => "skipped_by_user",
            ObjectStatus::Blocked => "blocked",
        }
    }

    /// Is the machine as it should be for this object, as far as wf can make it?
    ///
    /// Exhaustive rather than a `matches!`, so that adding a status is a compile error here
    /// instead of a silent `false` — a new status quietly counted as unsettled moves the
    /// `n/n` in `wf agents status` and puts a component nobody asked about into the doctor's
    /// list of things to deal with.
    pub fn is_settled(self) -> bool {
        match self {
            ObjectStatus::Current
            | ObjectStatus::Kept
            | ObjectStatus::Skipped
            | ObjectStatus::SkippedByUser => true,
            ObjectStatus::Missing
            | ObjectStatus::Outdated
            | ObjectStatus::Drifted
            | ObjectStatus::Stale
            | ObjectStatus::Conflict
            | ObjectStatus::Blocked => false,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct ObjectState {
    pub kind: ResourceKind,
    pub id: String,
    pub component_id: String,
    pub status: ObjectStatus,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub placement: Option<String>,
    #[serde(skip_serializing_if = "String::is_empty")]
    pub detail: String,
}

/// What `inspect` would do about one object.
#[derive(Debug, Clone, PartialEq)]
pub enum ResourceChange {
    Deploy {
        kind: ResourceKind,
        item: ResourceItem,
    },
    Remove {
        kind: ResourceKind,
        item: ResourceItem,
    },
    /// Record ownership of an object that is already exactly ours (a marker says so).
    Adopt {
        kind: ResourceKind,
        item: ResourceItem,
    },
    /// Stop owning an object without touching it.
    Forget { kind: ResourceKind, id: String },
}

/// One agent, read.
#[derive(Debug, Clone, Default, PartialEq, Serialize)]
pub struct AgentState {
    pub agent: String,
    pub display_name: String,
    pub objects: Vec<ObjectState>,
    pub findings: Vec<Finding>,
    #[serde(skip)]
    pub changes: Vec<ResourceChange>,
}

impl AgentState {
    /// Nothing to write and nothing wrong that wf could fix.
    pub fn is_current(&self) -> bool {
        self.objects.iter().all(|o| o.status.is_settled())
    }
}

/// What the team repository offers, scanned once per run. A kind whose definitions do not
/// read carries the reason instead of items, and nothing of that kind is added or removed.
#[derive(Debug, Clone, Default)]
pub struct Desired {
    pub items: BTreeMap<ResourceKind, std::result::Result<Vec<ResourceItem>, String>>,
}

impl Desired {
    pub fn scan(repo: &TeamRepo) -> Self {
        Self::scan_kinds(repo, &ResourceKind::ALL)
    }

    /// Only `kinds`. Inspection skips every kind not scanned, so a partial scan never reads
    /// as "the team repository dropped the rest".
    pub fn scan_kinds(repo: &TeamRepo, kinds: &[ResourceKind]) -> Self {
        Self {
            items: kinds
                .iter()
                .map(|&kind| (kind, repo.scan_resources(kind).map_err(|e| e.message)))
                .collect(),
        }
    }
}

fn policy_code(kind: ResourceKind) -> &'static str {
    match kind {
        ResourceKind::Mcp => "MCP-POLICY",
        ResourceKind::Env => "ENV-POLICY",
        ResourceKind::Hook => "HOOK-POLICY",
        _ => "RESOURCE-POLICY",
    }
}

/// What a person is told about a decision they made, when they ask. Their own words when
/// they gave a reason, our own host otherwise, and the date either way.
fn skip_detail(row: &SkippedMcp) -> String {
    let day = row.skipped_at.split('T').next().unwrap_or(&row.skipped_at);
    match (row.reason.is_empty(), row.host.is_empty()) {
        (false, _) => format!("skipped on {day}: {}", row.reason),
        (true, false) => format!("skipped on {day}; {} is reached another way", row.host),
        (true, true) => format!("skipped on {day}"),
    }
}

/// The inspection every adapter shares.
fn inspect_agent(
    agent: &dyn TeamAIAdapter,
    desired: &Desired,
    owned: &[ManagedResource],
    skipped: &[SkippedMcp],
) -> Result<AgentState> {
    use crate::resources::object::{self, Placement, Probe};
    use crate::resources::{handler, owned_item, POLICY_REFUSED, POLICY_SKIP};
    use crate::Severity;

    let mut state = AgentState {
        agent: agent.id().to_string(),
        display_name: agent.display_name().to_string(),
        ..Default::default()
    };
    // Every kind this agent takes now, plus every kind it still holds something of: an agent
    // that stopped supporting a kind has to be able to take back what it already wrote.
    let mut kinds: Vec<ResourceKind> = agent.supported_resources();
    for row in owned.iter().filter(|r| r.agent_id == agent.id()) {
        if let Some(kind) = ResourceKind::parse(&row.resource_kind) {
            if !kinds.contains(&kind) {
                kinds.push(kind);
            }
        }
    }
    for kind in kinds {
        let handler = handler(kind);
        let rows: Vec<&ManagedResource> = owned
            .iter()
            .filter(|r| r.agent_id == agent.id() && r.resource_kind == kind.as_str())
            .collect();
        let items: &[ResourceItem] = match desired.items.get(&kind) {
            // An agent that no longer takes the kind wants none of it, and the rows below
            // are then all orphans — the one path that can still clean them up.
            Some(Ok(items)) => handler
                .shape(agent)
                .map(|_| items.as_slice())
                .unwrap_or(&[]),
            Some(Err(message)) => {
                state.findings.push(Finding::new(
                    "RESOURCE-SCAN",
                    kind.as_str(),
                    format!(
                        "{}: {message}; nothing of this kind was changed",
                        kind.as_str()
                    ),
                    Severity::Error,
                ));
                continue;
            }
            // Not scanned this run: an unread kind is not a dropped one.
            None => continue,
        };
        let mut wanted = std::collections::BTreeSet::new();
        let push = |state: &mut AgentState,
                    item_id: &str,
                    component: String,
                    status,
                    placement,
                    detail: String| {
            state.objects.push(ObjectState {
                kind,
                id: item_id.to_string(),
                component_id: component,
                status,
                placement,
                detail,
            });
        };

        for item in items {
            let component = item.component_id();
            // Declined on this machine, for this agent. Inserted into `wanted` before
            // anything else: the orphan sweep below deletes every owned row this set does
            // not name, so leaving it out would make wf delete the very installation a
            // person kept — the opposite of what they asked for. Nothing is rendered, so
            // nothing is written, and no change is planned.
            if kind == ResourceKind::Mcp {
                if let Some(row) = skipped
                    .iter()
                    .find(|s| s.agent_id == agent.id() && s.component_id == component)
                {
                    wanted.insert(item.id.clone());
                    push(
                        &mut state,
                        &item.id,
                        component,
                        ObjectStatus::SkippedByUser,
                        None,
                        skip_detail(row),
                    );
                    continue;
                }
            }
            let rendered = match handler.render(item, agent) {
                Ok(Some(rendered)) => rendered,
                Ok(None) => continue,
                Err(e) if e.kind == POLICY_SKIP => {
                    wanted.insert(item.id.clone());
                    push(
                        &mut state,
                        &item.id,
                        component,
                        ObjectStatus::Skipped,
                        None,
                        e.message,
                    );
                    continue;
                }
                Err(e) if e.kind == POLICY_REFUSED => {
                    state.findings.push(
                        Finding::new(
                            policy_code(kind),
                            &component,
                            e.message.clone(),
                            Severity::Warn,
                        )
                        .with_zh(e.zh.clone()),
                    );
                    if !rows.iter().any(|r| r.resource_id == item.id) {
                        push(
                            &mut state,
                            &item.id,
                            component,
                            ObjectStatus::Blocked,
                            None,
                            e.message,
                        );
                    }
                    continue;
                }
                Err(e) => {
                    wanted.insert(item.id.clone());
                    state.findings.push(
                        Finding::new(
                            "RESOURCE-RENDER",
                            &component,
                            e.message.clone(),
                            Severity::Error,
                        )
                        .with_zh(e.zh.clone()),
                    );
                    push(
                        &mut state,
                        &item.id,
                        component,
                        ObjectStatus::Blocked,
                        None,
                        e.message,
                    );
                    continue;
                }
            };
            wanted.insert(item.id.clone());
            let placement = rendered.placement().render();
            if let Some(link) = rendered.symlinked(agent.config_root()) {
                let detail = format!(
                    "{} is a symlink; wf does not write through it",
                    link.display()
                );
                state.findings.push(
                    Finding::new("RESOURCE-CONFLICT", &component, detail.clone(), Severity::Error)
                        .with_zh(format!(
                            "{} 是一个符号链接，wf 不会透过它写入，这一项没有装上。想让 wf 管理它，就把链接换成普通文件后运行 `wf repair`。",
                            link.display()
                        )),
                );
                push(
                    &mut state,
                    &item.id,
                    component,
                    ObjectStatus::Conflict,
                    Some(placement),
                    detail,
                );
                continue;
            }
            let want = rendered.hash()?;
            let probe = match rendered.probe() {
                Ok(probe) => probe,
                Err(e) => {
                    state.findings.push(
                        Finding::new(
                            "RESOURCE-UNREADABLE",
                            &component,
                            e.message.clone(),
                            Severity::Error,
                        )
                        .with_zh(e.zh.clone()),
                    );
                    push(
                        &mut state,
                        &item.id,
                        component,
                        ObjectStatus::Blocked,
                        Some(placement),
                        e.message,
                    );
                    continue;
                }
            };
            let row = rows.iter().find(|r| r.resource_id == item.id);
            // A marker lives inside a document — a managed block, a hook handler. A whole
            // file or directory carries none, so finding one proves nothing about who wrote it.
            let marker_owned = handler.marker_owned()
                && matches!(
                    rendered.shape(),
                    object::Shape::Block { .. } | object::Shape::Hook(_)
                );
            let deploy = || ResourceChange::Deploy {
                kind,
                item: item.clone(),
            };
            let (status, change) = match (&probe, row) {
                (Probe::Present(have), row) if *have == want => {
                    let stale_row =
                        row.is_some_and(|r| r.content_hash != want || r.deployed_path != placement);
                    let adopt = (row.is_none() && marker_owned) || stale_row;
                    (
                        ObjectStatus::Current,
                        adopt.then(|| ResourceChange::Adopt {
                            kind,
                            item: item.clone(),
                        }),
                    )
                }
                (Probe::Absent, _) => (ObjectStatus::Missing, Some(deploy())),
                (Probe::Present(have), Some(row)) => {
                    let edited = *have != row.content_hash;
                    if edited
                        && kind == ResourceKind::Rule
                        && !agent.policies().rules.is_enforced(&item.id)
                    {
                        (ObjectStatus::Kept, None)
                    } else if edited {
                        (ObjectStatus::Drifted, Some(deploy()))
                    } else {
                        (ObjectStatus::Outdated, Some(deploy()))
                    }
                }
                (Probe::Present(_), None) if marker_owned => {
                    (ObjectStatus::Drifted, Some(deploy()))
                }
                (Probe::Present(_), None) => {
                    state.findings.push(
                        Finding::new(
                            "RESOURCE-CONFLICT",
                            &component,
                            format!(
                                "{} already has something wf did not put there; it was left alone",
                                rendered.placement().path.display()
                            ),
                            Severity::Error,
                        )
                        .with_zh(format!(
                            "{} 已经有一个不是 wf 放的同名{}，wf 没有覆盖它。把它改名或删掉后再运行 `wf sync`。",
                            rendered.placement().path.display(),
                            kind.as_str()
                        )),
                    );
                    (ObjectStatus::Conflict, None)
                }
            };
            if kind == ResourceKind::Prompt {
                if let crate::resources::object::Rendered::Block {
                    path,
                    id,
                    body,
                    placement: where_in_file,
                    shadow: Some(_),
                } = &rendered
                {
                    // What Codex will read once this object is in place, not what is there
                    // before it: the run that pushes the file over the budget is the run
                    // that has to say so.
                    let have = wf_core::paths::read_text_or_empty(path)?;
                    let size = wf_prompts::apply(&have, id, body, *where_in_file)?
                        .text
                        .len();
                    if size > crate::formats::codex::PROJECT_DOC_MAX_BYTES {
                        state.findings.push(Finding::new(
                            "CODEX-PROMPT-BUDGET",
                            &component,
                            format!(
                                "{} exceeds Codex's default instruction budget; shorten it or raise project_doc_max_bytes",
                                path.display()
                            ),
                            Severity::Warn,
                        ));
                    }
                }
            }
            if kind == ResourceKind::Hook {
                if let crate::resources::object::Rendered::Hook { path, format, .. } = &rendered {
                    let document = crate::resources::object::hook_document(*format, path);
                    let text = wf_core::paths::read_text_or_empty(&document)?;
                    if let Some(why) = crate::formats::get_hook_format(*format).dormant(&text) {
                        state.findings.push(Finding::new(
                            crate::formats::HOOKS_DISABLED,
                            &component,
                            why,
                            Severity::Warn,
                        ));
                    }
                }
            }
            state.changes.extend(change);
            push(
                &mut state,
                &item.id,
                component,
                status,
                Some(placement),
                String::new(),
            );
        }

        let orphans: Vec<&&ManagedResource> = rows
            .iter()
            .filter(|r| !wanted.contains(&r.resource_id))
            .collect();
        let stored = handler.stored_shape(agent);
        for row in orphans {
            let component = format!("team.{}.{}", kind.as_str(), row.resource_id);
            let placement = Some(row.deployed_path.clone());
            let Some(shape) = stored.clone() else {
                state.findings.push(Finding::new(
                    "RESOURCE-ORPHAN",
                    &component,
                    format!(
                        "{} was deployed as {}, which this agent no longer declares a format for, \
                         so wf cannot read it back; remove it by hand",
                        row.deployed_path,
                        kind.as_str()
                    ),
                    Severity::Error,
                ));
                push(
                    &mut state,
                    &row.resource_id,
                    component,
                    ObjectStatus::Blocked,
                    placement,
                    String::new(),
                );
                continue;
            };
            if object::is_symlink(&Placement::parse(&row.deployed_path).path) {
                // Replaced by a link since wf wrote it: not wf's to remove any more.
                state.changes.push(ResourceChange::Forget {
                    kind,
                    id: row.resource_id.clone(),
                });
                push(
                    &mut state,
                    &row.resource_id,
                    component,
                    ObjectStatus::Kept,
                    placement,
                    String::new(),
                );
                continue;
            }
            match object::probe(shape, &Placement::parse(&row.deployed_path)) {
                Ok(Probe::Absent) => {
                    state.changes.push(ResourceChange::Forget {
                        kind,
                        id: row.resource_id.clone(),
                    });
                    push(
                        &mut state,
                        &row.resource_id,
                        component,
                        ObjectStatus::Stale,
                        placement,
                        String::new(),
                    );
                }
                Ok(Probe::Present(have)) if have == row.content_hash => {
                    state.changes.push(ResourceChange::Remove {
                        kind,
                        item: owned_item(kind, row, have),
                    });
                    push(
                        &mut state,
                        &row.resource_id,
                        component,
                        ObjectStatus::Stale,
                        placement,
                        String::new(),
                    );
                }
                Ok(Probe::Present(_)) => {
                    state.changes.push(ResourceChange::Forget {
                        kind,
                        id: row.resource_id.clone(),
                    });
                    state.findings.push(Finding::new(
                        "RESOURCE-KEPT",
                        &component,
                        format!(
                            "{} left the team repository but was edited here, so it stays and wf stops managing it",
                            row.deployed_path
                        ),
                        Severity::Info,
                    ));
                    push(
                        &mut state,
                        &row.resource_id,
                        component,
                        ObjectStatus::Kept,
                        placement,
                        String::new(),
                    );
                }
                Err(e) => {
                    state.findings.push(Finding::new(
                        "RESOURCE-UNREADABLE",
                        &component,
                        e.message.clone(),
                        Severity::Error,
                    ));
                    push(
                        &mut state,
                        &row.resource_id,
                        component,
                        ObjectStatus::Blocked,
                        placement,
                        e.message,
                    );
                }
            }
        }
    }
    Ok(state)
}

fn apply_changes(
    agent: &dyn TeamAIAdapter,
    changes: &[ResourceChange],
    tx: &mut Transaction<'_>,
) -> Result<Vec<String>> {
    use crate::resources::{handler, ownership};
    let mut applied = Vec::new();
    for change in changes {
        let outcome = match change {
            ResourceChange::Deploy { kind, item } => handler(*kind)
                .deploy(item, agent, tx)
                .map(|changed| changed.then(|| item.component_id())),
            ResourceChange::Remove { kind, item } => handler(*kind)
                .remove(item, agent, tx)
                .map(|changed| changed.then(|| item.component_id())),
            ResourceChange::Adopt { kind, item } => {
                handler(*kind).render(item, agent).and_then(|r| {
                    if let Some(rendered) = r {
                        tx.record_resource(ownership(agent, item, &rendered)?);
                    }
                    Ok(None)
                })
            }
            ResourceChange::Forget { kind, id } => {
                tx.forget_resource(agent.id(), kind.as_str(), id);
                Ok(None)
            }
        };
        match outcome {
            Ok(Some(component)) => applied.push(component),
            Ok(None) => {}
            Err(mut e) => {
                e.message = format!("{}: {}", agent.id(), e.message);
                return Err(e);
            }
        }
    }
    applied.sort();
    applied.dedup();
    Ok(applied)
}

/// The agents `wf` manages until somebody registers another, and the two the 1.x plugin was
/// installed into. Which components reach an agent is not one of this list's questions: every
/// managed agent takes every component whose kind it supports (ADR-0007).
pub const FIRST_PARTY: [&str; 2] = ["claude-code", "codex"];

pub trait TeamAIAdapter: Send + Sync {
    /// Agent identifier (`claude-code`, `codex`, …).
    fn id(&self) -> &str;
    fn display_name(&self) -> &str;
    /// Is the agent on this machine? Spawn-free: a configuration root or a binary on PATH.
    fn detect(&self) -> Result<Option<AgentInstall>>;
    fn supported_resources(&self) -> Vec<ResourceKind>;
    fn skills_path(&self) -> Option<PathBuf> {
        self.path(PathKind::Skills)
    }
    fn rules_path(&self) -> Option<PathBuf> {
        self.path(PathKind::Rules)
    }
    fn config_paths(&self) -> AgentConfigPaths {
        AgentConfigPaths {
            settings: self.path(PathKind::Settings),
            hooks: self.path(PathKind::Hooks),
            mcp: self.path(PathKind::Mcp),
            prompt: self.path(PathKind::Prompt),
        }
    }
    fn hook_format(&self) -> Option<HookFormat> {
        self.formats().hook
    }
    fn mcp_format(&self) -> Option<McpFormat> {
        self.formats().mcp
    }

    // --- what the resource handlers read ---
    fn path(&self, kind: PathKind) -> Option<PathBuf>;
    fn formats(&self) -> AgentFormats;
    /// The name a hook passes back to `wf` as `--agent`.
    fn hook_name(&self) -> &str;
    /// The `wf` a hook runs.
    fn wf_binary(&self) -> &Path;
    /// The directory every object of this agent's lives under. A write that would leave it
    /// through a linked directory is a conflict.
    fn config_root(&self) -> &Path;
    fn policies(&self) -> &Policies;
    /// Where team documents go; only the machine has one.
    fn docs_dir(&self) -> Option<&Path> {
        None
    }

    /// This adapter as a trait object, which the shared lifecycle below hands to handlers.
    fn as_dyn(&self) -> &dyn TeamAIAdapter;

    /// Read the agent against what the team repository offers, what wf owns there, and what
    /// a person on this machine has declined.
    fn inspect(
        &self,
        desired: &Desired,
        owned: &[ManagedResource],
        skipped: &[SkippedMcp],
    ) -> Result<AgentState> {
        inspect_agent(self.as_dyn(), desired, owned, skipped)
    }

    /// Carry out changes inside the caller's transaction. Returns the components that
    /// changed on disk.
    fn apply(&self, changes: &[ResourceChange], tx: &mut Transaction<'_>) -> Result<Vec<String>> {
        apply_changes(self.as_dyn(), changes, tx)
    }

    /// Read back after applying. An object that should now be in place and is not is an
    /// error: a step that reports success without re-reading the machine has verified nothing.
    fn verify(
        &self,
        desired: &Desired,
        owned: &[ManagedResource],
        skipped: &[SkippedMcp],
    ) -> Result<AgentState> {
        let state = self.inspect(desired, owned, skipped)?;
        let unsettled: Vec<String> = state
            .objects
            .iter()
            .filter(|o| {
                matches!(
                    o.status,
                    ObjectStatus::Missing
                        | ObjectStatus::Outdated
                        | ObjectStatus::Drifted
                        | ObjectStatus::Stale
                )
            })
            .map(|o| format!("{} ({})", o.component_id, o.status.as_str()))
            .collect();
        if !unsettled.is_empty() {
            return Err(wf_core::Error::failure(
                "POST-VERIFY",
                format!(
                    "{}: {} did not reach the machine",
                    self.id(),
                    unsettled.join(", ")
                ),
            ));
        }
        Ok(state)
    }
}

/// An agent described by an `agents.yaml` entry — every agent `wf` manages.
#[derive(Debug, Clone)]
pub struct ConfigAdapter {
    spec: AgentSpec,
    location: AgentLocation,
    wf_binary: PathBuf,
    policies: Policies,
    /// A `PATH` to look for the agent's binary in, instead of the process's own.
    search_path: Option<String>,
}

impl ConfigAdapter {
    pub fn new(
        spec: AgentSpec,
        location: AgentLocation,
        wf_binary: PathBuf,
        policies: Policies,
    ) -> Self {
        Self {
            spec,
            location,
            wf_binary,
            policies,
            search_path: None,
        }
    }

    /// Detect the binary on `path` rather than the process `PATH`.
    pub fn with_search_path(mut self, path: Option<String>) -> Self {
        self.search_path = path;
        self
    }

    fn find_binary(&self, program: &str) -> Option<PathBuf> {
        match &self.search_path {
            None => wf_core::proc::which(program),
            Some(path) => std::env::split_paths(path)
                .map(|dir| dir.join(program))
                .find(|candidate| executable(candidate)),
        }
    }

    /// Located from this process's environment.
    pub fn here(spec: AgentSpec, home: &Path, wf_binary: PathBuf, policies: Policies) -> Self {
        let location = spec.locate_here(home);
        Self::new(spec, location, wf_binary, policies)
    }

    pub fn spec(&self) -> &AgentSpec {
        &self.spec
    }

    pub fn location(&self) -> &AgentLocation {
        &self.location
    }
}

impl TeamAIAdapter for ConfigAdapter {
    fn id(&self) -> &str {
        &self.spec.id
    }
    fn display_name(&self) -> &str {
        &self.spec.display_name
    }
    fn detect(&self) -> Result<Option<AgentInstall>> {
        let binary = self
            .spec
            .binary
            .as_deref()
            .and_then(|b| self.find_binary(b));
        if !self.location.root.is_dir() && binary.is_none() {
            return Ok(None);
        }
        Ok(Some(AgentInstall {
            binary: binary.unwrap_or_default(),
            version: String::new(),
            config_root: self.location.root.clone(),
        }))
    }
    fn supported_resources(&self) -> Vec<ResourceKind> {
        self.spec.supported_resources()
    }
    fn as_dyn(&self) -> &dyn TeamAIAdapter {
        self
    }
    fn path(&self, kind: PathKind) -> Option<PathBuf> {
        self.spec.path(&self.location, kind)
    }
    fn formats(&self) -> AgentFormats {
        self.spec.formats.clone()
    }
    fn hook_name(&self) -> &str {
        self.spec.hook_name()
    }
    fn wf_binary(&self) -> &Path {
        &self.wf_binary
    }
    fn config_root(&self) -> &Path {
        &self.location.root
    }
    fn policies(&self) -> &Policies {
        &self.policies
    }
}

/// The machine itself, as a target: where team documents go.
#[derive(Debug, Clone)]
pub struct MachineAdapter {
    docs_dir: PathBuf,
    wf_binary: PathBuf,
    policies: Policies,
}

pub const MACHINE_ID: &str = "wf";

impl MachineAdapter {
    pub fn new(docs_dir: PathBuf, wf_binary: PathBuf, policies: Policies) -> Self {
        Self {
            docs_dir,
            wf_binary,
            policies,
        }
    }
}

impl TeamAIAdapter for MachineAdapter {
    fn id(&self) -> &str {
        MACHINE_ID
    }
    fn display_name(&self) -> &str {
        "this machine"
    }
    fn detect(&self) -> Result<Option<AgentInstall>> {
        Ok(Some(AgentInstall {
            binary: self.wf_binary.clone(),
            version: wf_core::VERSION.into(),
            config_root: self.docs_dir.clone(),
        }))
    }
    fn supported_resources(&self) -> Vec<ResourceKind> {
        vec![ResourceKind::Doc]
    }
    fn as_dyn(&self) -> &dyn TeamAIAdapter {
        self
    }
    fn path(&self, _kind: PathKind) -> Option<PathBuf> {
        None
    }
    fn formats(&self) -> AgentFormats {
        AgentFormats::default()
    }
    fn hook_name(&self) -> &str {
        MACHINE_ID
    }
    fn wf_binary(&self) -> &Path {
        &self.wf_binary
    }
    fn config_root(&self) -> &Path {
        &self.docs_dir
    }
    fn policies(&self) -> &Policies {
        &self.policies
    }
    fn docs_dir(&self) -> Option<&Path> {
        Some(&self.docs_dir)
    }
}

#[cfg(unix)]
fn executable(path: &Path) -> bool {
    use std::os::unix::fs::PermissionsExt;
    std::fs::metadata(path).is_ok_and(|m| m.is_file() && m.permissions().mode() & 0o111 != 0)
}

#[cfg(not(unix))]
fn executable(path: &Path) -> bool {
    path.is_file()
}

/// Ask an installed agent its version. Runs the binary, so it is never on a budgeted path.
pub fn probe_version(spec: &AgentSpec, install: &AgentInstall) -> String {
    if install.binary.as_os_str().is_empty() {
        return String::new();
    }
    // Even `--version` may initialise state under the agent's root, and some agents refuse a
    // missing one: point the root at a scratch directory that is gone when this returns.
    let Ok(scratch) = tempfile::tempdir() else {
        return String::new();
    };
    let scratch_path = scratch.path().to_string_lossy().into_owned();
    let mut env: Vec<(&str, &str)> = vec![("CI", "1")];
    if let Some(key) = spec.root_env.as_deref() {
        env.push((key, &scratch_path));
    }
    wf_core::proc::run_in(
        &install.binary.to_string_lossy(),
        &["--version"],
        &env,
        Some(Path::new("/")),
        std::time::Duration::from_secs(10),
    )
    .ok()
    .filter(|out| out.ok())
    .and_then(|out| {
        out.stdout
            .split_whitespace()
            .find(|w| w.starts_with(|c: char| c.is_ascii_digit()))
            .map(String::from)
    })
    .unwrap_or_default()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::testing::{Machine, TeamFixture};
    use serde_json::Value;

    fn open() -> Policies {
        Policies::default()
    }

    /// inspect → apply → verify → commit, the way the engine drives it.
    fn converge(
        m: &Machine,
        a: &dyn TeamAIAdapter,
        team: &TeamFixture,
    ) -> (AgentState, Vec<String>) {
        let desired = Desired::scan(&team.repo());
        let owned = m.db.managed_resources(Some(a.id())).unwrap();
        let skipped = m.db.skipped_mcps().unwrap();
        let state = a.inspect(&desired, &owned, &skipped).unwrap();
        let mut tx = m.tx(false);
        let applied = a.apply(&state.changes, &mut tx).unwrap();
        let owned = tx.managed_resources(a.id()).unwrap();
        a.verify(&desired, &owned, &skipped).unwrap();
        tx.commit().unwrap();
        (state, applied)
    }

    fn inspect(m: &Machine, a: &dyn TeamAIAdapter, team: &TeamFixture) -> AgentState {
        a.inspect(
            &Desired::scan(&team.repo()),
            &m.db.managed_resources(Some(a.id())).unwrap(),
            &m.db.skipped_mcps().unwrap(),
        )
        .unwrap()
    }

    fn status(state: &AgentState, kind: ResourceKind, id: &str) -> ObjectStatus {
        state
            .objects
            .iter()
            .find(|o| o.kind == kind && o.id == id)
            .unwrap_or_else(|| panic!("no {kind:?} {id} in {:#?}", state.objects))
            .status
    }

    fn decline(m: &Machine, agent: &str, component: &str) {
        m.db.record_skipped_mcp(&wf_state::SkippedMcp {
            agent_id: agent.into(),
            component_id: component.into(),
            skipped_at: "2026-09-18T10:30:00.000Z".into(),
            reason: String::new(),
            host: "mcp.linear.app".into(),
            source: "user".into(),
        })
        .unwrap();
    }

    /// txe-workflow#50: the registry's startup limit reaches the server's table in Codex's
    /// `config.toml`, beside a person's own settings that keep their bytes, and leaves Claude
    /// Code's entry as it was, because Claude Code has no key for it.
    #[test]
    fn a_registry_startup_limit_reaches_codex_and_leaves_claude_alone() {
        let team = TeamFixture::new();
        team.write(
            "workflow/registry.yaml",
            &crate::testing::REGISTRY.replace(
                "login_host: mcp.linear.app",
                "login_host: mcp.linear.app\n    startup_timeout_sec: 120",
            ),
        );
        let m = Machine::new();
        m.write(".codex/config.toml", "model = \"gpt-5\"\n");
        converge(&m, &m.adapter(&team, "codex", open()), &team);
        let config: toml::Value = toml::from_str(&m.read(".codex/config.toml")).unwrap();
        assert_eq!(
            config["mcp_servers"]["capso-linear"]["startup_timeout_sec"].as_integer(),
            Some(120)
        );
        assert_eq!(config["model"].as_str(), Some("gpt-5"));

        converge(&m, &m.adapter(&team, "claude-code", open()), &team);
        let claude: Value = serde_json::from_str(&m.read(".claude.json")).unwrap();
        assert_eq!(claude["mcpServers"]["capso-linear"]["command"], "npx");
        assert!(claude["mcpServers"]["capso-linear"]
            .get("startup_timeout_sec")
            .is_none());
    }

    /// A declined server is settled, plans no work, and — the part that matters — stays in
    /// `wanted`, so the orphan sweep does not treat the installation somebody kept as
    /// something wf left behind and delete it.
    #[test]
    fn a_declined_server_is_settled_plans_nothing_and_is_never_an_orphan() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let claude = m.adapter(&team, "claude-code", open());
        converge(&m, &claude, &team);
        let owned_before = m.db.managed_resources(Some("claude-code")).unwrap().len();
        assert!(
            m.db.managed_resource("claude-code", "mcp", "capso-linear")
                .unwrap()
                .is_some(),
            "the fixture never installed the server this test is about"
        );

        decline(&m, "claude-code", "capso.mcp.linear");
        let state = inspect(&m, &claude, &team);
        assert_eq!(
            status(&state, ResourceKind::Mcp, "capso-linear"),
            ObjectStatus::SkippedByUser
        );
        assert!(
            ObjectStatus::SkippedByUser.is_settled(),
            "a decision is not something left to do"
        );
        // Nothing planned for it in either direction: not deployed again, not removed.
        for change in &state.changes {
            let touched = match change {
                ResourceChange::Deploy { item, .. }
                | ResourceChange::Remove { item, .. }
                | ResourceChange::Adopt { item, .. } => item.id == "capso-linear",
                ResourceChange::Forget { id, .. } => id == "capso-linear",
            };
            assert!(!touched, "a declined server was planned for: {change:?}");
        }

        // And applying that plan leaves the row and the entry exactly where they were.
        let mut tx = m.tx(false);
        claude.apply(&state.changes, &mut tx).unwrap();
        tx.commit().unwrap();
        assert_eq!(
            m.db.managed_resources(Some("claude-code")).unwrap().len(),
            owned_before,
            "applying a plan with a decision in it removed something"
        );
        assert!(m
            .db
            .managed_resource("claude-code", "mcp", "capso-linear")
            .unwrap()
            .is_some());
    }

    /// The decision is per agent: declining in one leaves the other alone.
    #[test]
    fn a_decision_about_one_agent_says_nothing_about_another() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let claude = m.adapter(&team, "claude-code", open());
        let codex = m.adapter(&team, "codex", open());
        decline(&m, "claude-code", "capso.mcp.linear");
        assert_eq!(
            status(
                &inspect(&m, &claude, &team),
                ResourceKind::Mcp,
                "capso-linear"
            ),
            ObjectStatus::SkippedByUser
        );
        assert_ne!(
            status(
                &inspect(&m, &codex, &team),
                ResourceKind::Mcp,
                "capso-linear"
            ),
            ObjectStatus::SkippedByUser,
            "a decision about Claude Code reached Codex"
        );
    }

    #[test]
    fn the_plan_surface_answers_from_the_spec() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let claude = m.adapter(&team, "claude-code", open());
        assert_eq!(claude.id(), "claude-code");
        assert_eq!(claude.display_name(), "Claude Code");
        assert_eq!(claude.skills_path(), Some(m.at(".claude/skills")));
        assert_eq!(claude.rules_path(), Some(m.at(".claude/rules")));
        assert_eq!(
            claude.config_paths(),
            AgentConfigPaths {
                settings: Some(m.at(".claude/settings.json")),
                hooks: Some(m.at(".claude/settings.json")),
                mcp: Some(m.at(".claude.json")),
                prompt: Some(m.at(".claude/CLAUDE.md")),
            }
        );
        assert_eq!(claude.hook_format(), Some(HookFormat::Claude));
        assert_eq!(claude.mcp_format(), Some(McpFormat::ClaudeJson));
        assert!(
            !claude.supported_resources().contains(&ResourceKind::Doc),
            "documents are the machine's"
        );
    }

    #[test]
    fn detection_is_a_directory_or_a_binary_on_path_and_nothing_is_run() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let kiro = m.adapter(&team, "kiro", open());
        assert_eq!(
            kiro.detect().unwrap(),
            None,
            "no root, and no kiro-cli here"
        );
        std::fs::create_dir_all(m.at(".kiro")).unwrap();
        let found = kiro.detect().unwrap().unwrap();
        assert_eq!(found.config_root, m.at(".kiro"));
        assert_eq!(
            found.version, "",
            "a version needs a spawn and detection does not spawn"
        );
        let started = std::time::Instant::now();
        for _ in 0..100 {
            kiro.detect().unwrap();
        }
        assert!(
            started.elapsed().as_millis() < 5_000,
            "detection is not free"
        );
    }

    #[test]
    fn a_fresh_claude_install_deploys_every_kind_and_a_second_pass_changes_nothing() {
        let team = TeamFixture::new();
        let m = Machine::new();
        m.write(".claude/CLAUDE.md", "my own notes\n");
        m.write(".claude/settings.json", "{\"model\": \"opus\"}\n");
        m.write(".claude.json", "{\"numStartups\": 3}\n");
        let claude = m.adapter(&team, "claude-code", open());
        let (state, applied) = converge(&m, &claude, &team);
        for (kind, id) in [
            (ResourceKind::Skill, "lfg"),
            (ResourceKind::Prompt, "capso.global"),
            (ResourceKind::Hook, "capso.hook.session-start"),
            (ResourceKind::Hook, "capso.hook.usage.post-tool-use"),
            (ResourceKind::Mcp, "capso-linear"),
            (ResourceKind::Rule, "security/secrets"),
            (ResourceKind::Rule, "style"),
            (ResourceKind::Agent, "code-reviewer"),
            (ResourceKind::Env, "TEAM_NAME"),
        ] {
            assert_eq!(
                status(&state, kind, id),
                ObjectStatus::Missing,
                "{kind:?} {id}"
            );
        }
        assert!(
            applied.contains(&"capso.skill.lfg".to_string()),
            "{applied:?}"
        );
        assert!(
            applied.contains(&"team.rule.style".to_string()),
            "{applied:?}"
        );

        assert!(m.read(".claude/skills/lfg/SKILL.md").contains("name: lfg"));
        let claude_md = m.read(".claude/CLAUDE.md");
        assert!(claude_md.starts_with("my own notes\n"));
        assert!(claude_md.contains("wf:managed-begin id=capso.global"));
        let settings: Value = serde_json::from_str(&m.read(".claude/settings.json")).unwrap();
        assert_eq!(settings["model"], "opus");
        assert_eq!(settings["env"]["TEAM_NAME"], "txe");
        let start = &settings["hooks"]["SessionStart"][0]["hooks"][0];
        assert_eq!(start["statusMessage"], "capso-wf-bootstrap");
        assert_eq!(
            start["command"],
            format!(
                "{} hook session-start --agent claude",
                m.wf_binary().display()
            )
        );
        assert_eq!(
            settings["hooks"]["PostToolUse"][0]["hooks"][0]["statusMessage"],
            "capso-wf-usage"
        );
        let dotclaude: Value = serde_json::from_str(&m.read(".claude.json")).unwrap();
        assert_eq!(dotclaude["numStartups"], 3);
        assert_eq!(
            dotclaude["mcpServers"]["capso-linear"]["env"]["LINEAR_API_TOKEN"],
            "${LINEAR_API_TOKEN}"
        );
        assert!(m
            .read(".claude/rules/security/secrets.md")
            .starts_with("---\ndescription: Never commit secrets"));
        assert!(m
            .read(".claude/agents/code-reviewer.md")
            .starts_with("---\nname: code-reviewer\n"));

        let again = inspect(&m, &claude, &team);
        assert!(again.changes.is_empty(), "{:#?}", again.changes);
        assert!(again.is_current(), "{:#?}", again.objects);
        assert_eq!(
            m.db.managed_resources(Some("claude-code")).unwrap().len(),
            9
        );
    }

    #[test]
    fn codex_gets_its_own_formats_and_no_rules() {
        let team = TeamFixture::new();
        let m = Machine::new();
        m.write(".codex/config.toml", "# mine\nmodel = \"gpt-5\"\n");
        let codex = m.adapter(&team, "codex", open());
        let (state, _) = converge(&m, &codex, &team);
        assert!(!state.objects.iter().any(|o| o.kind == ResourceKind::Rule));
        assert!(m.at(".codex/skills/lfg/SKILL.md").is_file());
        assert!(
            m.read(".codex/AGENTS.md")
                .starts_with("<!-- wf:managed-begin id=capso.global"),
            "prepended"
        );
        let hooks: Value = serde_json::from_str(&m.read(".codex/hooks.json")).unwrap();
        assert_eq!(
            serde_json::to_string(&hooks["hooks"]["SessionStart"][0]["hooks"][0]).unwrap(),
            format!(
                r#"{{"type":"command","command":"{} hook session-start --agent codex","statusMessage":"capso-wf-bootstrap"}}"#,
                m.wf_binary().display()
            ),
            "the dispatcher Codex already trusts, byte for byte"
        );
        let config = m.read(".codex/config.toml");
        assert!(
            config.starts_with("# mine\nmodel = \"gpt-5\"\n"),
            "{config}"
        );
        let parsed: toml::Value = toml::from_str(&config).unwrap();
        assert_eq!(
            parsed["mcp_servers"]["capso-linear"]["env_vars"]
                .as_array()
                .unwrap()[0]
                .as_str(),
            Some("LINEAR_API_TOKEN")
        );
        assert_eq!(
            parsed["shell_environment_policy"]["set"]["TEAM_NAME"].as_str(),
            Some("txe")
        );
        // The team restricted this subagent to Read and Grep, and a Codex role file has no
        // key for that: the object is blocked and named, not deployed unrestricted.
        assert!(!m.at(".codex/agents/code-reviewer.toml").exists());
        let after = inspect(&m, &codex, &team);
        assert!(after.changes.is_empty());
        assert!(
            after
                .findings
                .iter()
                .any(|f| f.message.contains("Read, Grep")),
            "{:?}",
            after.findings
        );
        assert!(after
            .objects
            .iter()
            .any(|o| o.kind == ResourceKind::Agent && o.status == ObjectStatus::Blocked));
    }

    #[test]
    fn a_codex_override_file_receives_the_block_and_the_plain_file_loses_it() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let codex = m.adapter(&team, "codex", open());
        converge(&m, &codex, &team);
        m.write(".codex/AGENTS.override.md", "local override\n");
        let state = inspect(&m, &codex, &team);
        // The block is now in the file Codex stopped reading: not as wf left the machine.
        assert_eq!(
            status(&state, ResourceKind::Prompt, "capso.global"),
            ObjectStatus::Drifted
        );
        converge(&m, &codex, &team);
        assert!(m
            .read(".codex/AGENTS.override.md")
            .contains("wf:managed-begin id=capso.global"));
        assert!(!m.read(".codex/AGENTS.md").contains("wf:managed-begin"));
    }

    #[test]
    fn cursor_and_kiro_take_what_their_formats_express() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let cursor = m.adapter(&team, "cursor", open());
        converge(&m, &cursor, &team);
        assert!(
            m.at(".cursor/skills/lfg/SKILL.md").is_file(),
            "registry skills reach config-driven agents"
        );
        // A leading `*` opens a YAML alias, so the glob list is quoted: Cursor reads this
        // front matter as YAML and would refuse the document otherwise.
        assert!(m
            .read(".cursor/rules/security/secrets.mdc")
            .contains("globs: '**/*.env'\nalwaysApply: false"));
        assert!(m
            .read(".cursor/agents/code-reviewer.md")
            .contains("agent_id: code-reviewer"));
        let hooks: Value = serde_json::from_str(&m.read(".cursor/hooks.json")).unwrap();
        assert_eq!(hooks["version"], 1);
        assert!(hooks["hooks"]["sessionStart"][0]["command"]
            .as_str()
            .unwrap()
            .ends_with("hook session-start --agent cursor"));
        assert!(hooks["hooks"]["postToolUse"].is_array());
        let mcp: Value = serde_json::from_str(&m.read(".cursor/mcp.json")).unwrap();
        assert_eq!(
            mcp["mcpServers"]["capso-linear"]["env"]["LINEAR_API_TOKEN"],
            "${env:LINEAR_API_TOKEN}"
        );
        assert!(inspect(&m, &cursor, &team).changes.is_empty());

        let kiro = m.adapter(&team, "kiro", open());
        converge(&m, &kiro, &team);
        assert!(m
            .read(".kiro/steering/security/secrets.md")
            .contains("inclusion: fileMatch"));
        assert!(m
            .read(".kiro/steering/capso-global.md")
            .starts_with("---\ninclusion: always\n---\n"));
        let kiro_hooks: Value = serde_json::from_str(&m.read(".kiro/hooks/capso-wf.json")).unwrap();
        assert_eq!(kiro_hooks["hooks"].as_array().unwrap().len(), 2);
        assert!(m.read(".kiro/settings/mcp.json").contains("capso-linear"));
        assert!(m
            .read(".kiro/agents/code-reviewer.json")
            .contains("\"prompt\""));
        assert!(inspect(&m, &kiro, &team).changes.is_empty());
    }

    #[test]
    fn zcode_and_openclaw_hooks_land_in_their_formats_for_the_events_they_have() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let zcode = m.adapter(&team, "zcode", open());
        converge(&m, &zcode, &team);
        let config: Value = serde_json::from_str(&m.read(".zcode/cli/config.json")).unwrap();
        // The switch that runs config-file hooks is the person's, and their own handlers
        // answer to it too, so wf reports it rather than setting it.
        assert_eq!(config["hooks"].get("enabled"), None);
        assert!(inspect(&m, &zcode, &team)
            .findings
            .iter()
            .any(|f| f.code == crate::formats::HOOKS_DISABLED));
        assert_eq!(
            config["hooks"]["events"]["SessionStart"][0]["hooks"][0]["type"],
            "process"
        );
        assert!(m.read(".agents/mcp.json").contains("capso-linear"));

        let openclaw = m.adapter(&team, "openclaw", open());
        let (state, _) = converge(&m, &openclaw, &team);
        assert!(m
            .read(".openclaw/workspace/hooks/capso-wf/HOOK.md")
            .contains("session:start"));
        assert!(m
            .at(".openclaw/workspace/hooks/capso-wf/handler.ts")
            .is_file());
        assert!(
            !state
                .objects
                .iter()
                .any(|o| o.id == "capso.hook.usage.post-tool-use"),
            "OpenClaw has no PostToolUse, so the object is not this agent's at all"
        );
        assert!(m
            .read(".openclaw/workspace/AGENTS.md")
            .contains("wf:managed-begin"));
    }

    #[test]
    fn an_unowned_object_of_the_same_name_is_a_conflict_and_is_left_alone() {
        let team = TeamFixture::new();
        let m = Machine::new();
        m.write(".claude/skills/lfg/SKILL.md", "my own lfg\n");
        let claude = m.adapter(&team, "claude-code", open());
        let (state, _) = converge(&m, &claude, &team);
        assert_eq!(
            status(&state, ResourceKind::Skill, "lfg"),
            ObjectStatus::Conflict
        );
        assert!(state
            .findings
            .iter()
            .any(|f| f.code == "RESOURCE-CONFLICT" && f.subject == "capso.skill.lfg"));
        assert_eq!(m.read(".claude/skills/lfg/SKILL.md"), "my own lfg\n");
        assert!(m
            .db
            .managed_resource("claude-code", "skill", "lfg")
            .unwrap()
            .is_none());
        assert!(
            m.at(".claude/rules/style.md").is_file(),
            "one conflict does not stop the rest"
        );
        assert!(!inspect(&m, &claude, &team).is_current());
    }

    #[test]
    fn an_identical_unowned_object_is_current_and_not_claimed() {
        let team = TeamFixture::new();
        let m = Machine::new();
        m.write(".claude/rules/style.md", "# Style\nBe brief.\n");
        let claude = m.adapter(&team, "claude-code", open());
        let (state, _) = converge(&m, &claude, &team);
        assert_eq!(
            status(&state, ResourceKind::Rule, "style"),
            ObjectStatus::Current
        );
        assert!(
            m.db.managed_resource("claude-code", "rule", "style")
                .unwrap()
                .is_none(),
            "uninstall must never take it"
        );
    }

    #[test]
    fn a_hook_carrying_our_marker_is_adopted_rather_than_duplicated() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let bootstrap = serde_json::json!({"hooks": {"SessionStart": [{"hooks": [{
            "type": "command",
            "command": format!("{} hook session-start --agent codex", m.wf_binary().display()),
            "statusMessage": "capso-wf-bootstrap"
        }]}]}});
        m.write(".codex/hooks.json", &bootstrap.to_string());
        let codex = m.adapter(&team, "codex", open());
        let (state, _) = converge(&m, &codex, &team);
        assert_eq!(
            status(&state, ResourceKind::Hook, "capso.hook.session-start"),
            ObjectStatus::Current
        );
        assert!(state
            .changes
            .iter()
            .any(|c| matches!(c, ResourceChange::Adopt { .. })));
        assert!(m
            .db
            .managed_resource("codex", "hook", "capso.hook.session-start")
            .unwrap()
            .is_some());
        let hooks: Value = serde_json::from_str(&m.read(".codex/hooks.json")).unwrap();
        assert_eq!(hooks["hooks"]["SessionStart"].as_array().unwrap().len(), 1);
    }

    #[test]
    fn drift_in_an_owned_object_is_repaired_and_the_edit_is_backed_up() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let claude = m.adapter(&team, "claude-code", open());
        converge(&m, &claude, &team);
        m.write(".claude/skills/lfg/SKILL.md", "edited\n");
        let state = inspect(&m, &claude, &team);
        assert_eq!(
            status(&state, ResourceKind::Skill, "lfg"),
            ObjectStatus::Drifted
        );
        converge(&m, &claude, &team);
        assert!(m.read(".claude/skills/lfg/SKILL.md").contains("name: lfg"));
        let store = wf_state::backup::Store::new(&m.db, m.dir.path().join("backups"));
        assert!(store
            .list()
            .unwrap()
            .iter()
            .any(|b| std::fs::read_to_string(&b.backup_path).is_ok_and(|t| t == "edited\n")));
    }

    #[test]
    fn a_new_release_of_an_owned_object_is_outdated_and_updated() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let claude = m.adapter(&team, "claude-code", open());
        converge(&m, &claude, &team);
        team.write(
            "skills/lfg/SKILL.md",
            "---\nname: lfg\ndescription: v2\n---\n",
        );
        assert_eq!(
            status(&inspect(&m, &claude, &team), ResourceKind::Skill, "lfg"),
            ObjectStatus::Outdated
        );
        converge(&m, &claude, &team);
        assert!(m.read(".claude/skills/lfg/SKILL.md").contains("v2"));
    }

    #[test]
    fn a_rule_a_person_edited_is_kept_unless_the_policy_enforces_it() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let claude = m.adapter(&team, "claude-code", open());
        converge(&m, &claude, &team);
        m.write(".claude/rules/style.md", "# Style\nMy way.\n");
        let state = inspect(&m, &claude, &team);
        assert_eq!(
            status(&state, ResourceKind::Rule, "style"),
            ObjectStatus::Kept
        );
        assert!(state.changes.is_empty());
        let mut enforced = open();
        enforced.rules.enforced = vec!["style".into()];
        let strict = m.adapter(&team, "claude-code", enforced);
        assert_eq!(
            status(&inspect(&m, &strict, &team), ResourceKind::Rule, "style"),
            ObjectStatus::Drifted
        );
        converge(&m, &strict, &team);
        assert_eq!(m.read(".claude/rules/style.md"), "# Style\nBe brief.\n");
    }

    #[test]
    fn what_leaves_the_team_repository_leaves_the_agent_unless_a_person_changed_it() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let claude = m.adapter(&team, "claude-code", open());
        converge(&m, &claude, &team);
        team.remove("workflow/rules/style.md");
        team.remove("workflow/agents/code-reviewer.yaml");
        m.write(".claude/agents/code-reviewer.md", "mine now\n");
        let state = inspect(&m, &claude, &team);
        assert_eq!(
            status(&state, ResourceKind::Rule, "style"),
            ObjectStatus::Stale
        );
        assert_eq!(
            status(&state, ResourceKind::Agent, "code-reviewer"),
            ObjectStatus::Kept
        );
        converge(&m, &claude, &team);
        assert!(!m.at(".claude/rules/style.md").exists());
        assert_eq!(m.read(".claude/agents/code-reviewer.md"), "mine now\n");
        assert!(m
            .db
            .managed_resource("claude-code", "rule", "style")
            .unwrap()
            .is_none());
        assert!(
            m.db.managed_resource("claude-code", "agent", "code-reviewer")
                .unwrap()
                .is_none(),
            "no longer ours"
        );
        assert!(inspect(&m, &claude, &team).changes.is_empty());
    }

    /// A whole-file prompt has no marker to prove it is `wf`'s: a person's own steering file of
    /// the same name is a conflict, not something to replace.
    #[test]
    fn a_persons_steering_file_of_the_same_name_is_a_conflict() {
        let team = TeamFixture::new();
        let m = Machine::new();
        m.write(".kiro/steering/capso-global.md", "# my own steering\n");
        let kiro = m.adapter(&team, "kiro", open());
        let (state, _) = converge(&m, &kiro, &team);
        assert_eq!(
            status(&state, ResourceKind::Prompt, "capso.global"),
            ObjectStatus::Conflict
        );
        assert_eq!(
            m.read(".kiro/steering/capso-global.md"),
            "# my own steering\n"
        );
    }

    /// Dotfiles tools symlink an agent's config into a repository. `wf` never writes through a
    /// link (WFR-015), and one linked document must not fail the apply for every other object
    /// and every other agent: it is a conflict, reported and left alone.
    #[cfg(unix)]
    #[test]
    fn a_symlinked_document_is_a_conflict_and_everything_else_still_lands() {
        let team = TeamFixture::new();
        let m = Machine::new();
        m.write("dotfiles/config.toml", "# mine\n");
        std::fs::create_dir_all(m.at(".codex")).unwrap();
        std::os::unix::fs::symlink(m.at("dotfiles/config.toml"), m.at(".codex/config.toml"))
            .unwrap();
        let codex = m.adapter(&team, "codex", open());
        let (state, _) = converge(&m, &codex, &team);
        assert_eq!(
            status(&state, ResourceKind::Mcp, "capso-linear"),
            ObjectStatus::Conflict
        );
        assert!(
            state
                .findings
                .iter()
                .any(|f| f.code == "RESOURCE-CONFLICT" && f.message.contains("symlink")),
            "{:#?}",
            state.findings
        );
        assert_eq!(m.read("dotfiles/config.toml"), "# mine\n");
        assert!(m.at(".codex/skills/lfg/SKILL.md").is_file());
        assert!(inspect(&m, &codex, &team).changes.is_empty());
    }

    #[cfg(unix)]
    #[test]
    fn a_symlinked_configuration_root_is_a_conflict_for_everything_under_it() {
        // A dotfiles manager's `ln -s ~/dotfiles/claude ~/.claude`. No leaf is a link, so
        // checking only the leaf let a tree write land in the person's git-tracked repository
        // — and delete the files there it did not recognise.
        let team = TeamFixture::new();
        let m = Machine::new();
        std::fs::create_dir_all(m.at("dotfiles/claude")).unwrap();
        std::os::unix::fs::symlink(m.at("dotfiles/claude"), m.at(".claude")).unwrap();
        let claude = m.adapter(&team, "claude-code", open());
        let (state, _) = converge(&m, &claude, &team);
        let root = format!("{}/", m.at(".claude").display());
        for object in &state.objects {
            let under_root = object
                .placement
                .as_deref()
                .is_none_or(|p| p.starts_with(&root));
            assert_eq!(
                object.status == ObjectStatus::Conflict,
                under_root,
                "{object:#?}"
            );
        }
        assert!(!m.at("dotfiles/claude/skills").exists());
        // `~/.claude.json` is beside the root, not under it, so it still lands.
        assert!(m.at(".claude.json").is_file());
        assert!(inspect(&m, &claude, &team).changes.is_empty());
    }

    #[test]
    fn a_kind_whose_definitions_do_not_read_is_left_exactly_as_it_is() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let claude = m.adapter(&team, "claude-code", open());
        converge(&m, &claude, &team);
        team.write("workflow/env/env.yaml", "variables: [unclosed\n");
        let state = inspect(&m, &claude, &team);
        assert!(state
            .findings
            .iter()
            .any(|f| f.code == "RESOURCE-SCAN" && f.subject == "env"));
        assert!(
            state.changes.is_empty(),
            "a bad file is not an empty set: {:#?}",
            state.changes
        );
        let settings: Value = serde_json::from_str(&m.read(".claude/settings.json")).unwrap();
        assert_eq!(settings["env"]["TEAM_NAME"], "txe");
    }

    #[test]
    fn mcp_policy_refuses_what_is_outside_the_allowlist_and_retires_what_became_so() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let claude = m.adapter(&team, "claude-code", open());
        converge(&m, &claude, &team);
        let mut tight = open();
        tight.mcp.allowed_hosts = vec!["*.txehq.com".into()];
        let strict = m.adapter(&team, "claude-code", tight);
        let state = inspect(&m, &strict, &team);
        let mcp = state
            .objects
            .iter()
            .find(|o| o.kind == ResourceKind::Mcp)
            .unwrap();
        assert_eq!(mcp.status, ObjectStatus::Stale, "{mcp:?}");
        assert!(state.findings.iter().any(|f| f.code == "MCP-POLICY"));
        converge(&m, &strict, &team);
        let dotclaude: Value = serde_json::from_str(&m.read(".claude.json")).unwrap();
        assert!(dotclaude["mcpServers"].get("capso-linear").is_none());
    }

    #[test]
    fn auto_apply_off_leaves_mcp_servers_as_they_are() {
        let team = TeamFixture::new();
        let m = Machine::new();
        converge(&m, &m.adapter(&team, "claude-code", open()), &team);
        team.write(
            "workflow/mcps/linear.yaml",
            "schema_version: 1\nname: capso-linear\ncommand: npx\nargs: [\"-y\", \"mcp-remote\", \"https://mcp.linear.app/v2\"]\n",
        );
        let mut manual = open();
        manual.mcp.auto_apply = false;
        let claude = m.adapter(&team, "claude-code", manual);
        let state = inspect(&m, &claude, &team);
        assert_eq!(
            status(&state, ResourceKind::Mcp, "capso-linear"),
            ObjectStatus::Skipped
        );
        assert!(state.changes.is_empty());
    }

    /// `wf history mcp serve` (ADR-0006) is a server like any other: the agent layer writes it
    /// into each agent's own MCP document, with `wf` resolved to the installed binary the way
    /// a hook's is, because an agent does not start MCP servers with the person's `PATH`.
    #[test]
    fn a_server_that_runs_wf_gets_the_installed_binary_whatever_the_command_allowlist_says() {
        let team = TeamFixture::new();
        team.write(
            "workflow/registry.yaml",
            &format!(
                "{}  - id: capso.mcp.history\n    kind: mcp\n    source: workflow/mcps/history.yaml\n    required: true\n    targets: [claude-code, codex]\n",
                crate::testing::REGISTRY.trim_start()
            ),
        );
        team.write(
            "workflow/mcps/history.yaml",
            "schema_version: 1\nname: wf-history\ntransport: stdio\ncommand: wf\nargs: [\"history\", \"mcp\", \"serve\"]\nenv_references: []\n",
        );
        let m = Machine::new();
        let mut npx_only = open();
        npx_only.mcp.allowed_commands = vec!["npx".into()];
        let wf = m.wf_binary().to_string_lossy().into_owned();
        for id in ["claude-code", "codex", "cursor"] {
            let a = m.adapter(&team, id, npx_only.clone());
            converge(&m, &a, &team);
            assert_eq!(
                status(&inspect(&m, &a, &team), ResourceKind::Mcp, "wf-history"),
                ObjectStatus::Current,
                "{id}"
            );
        }
        let claude: Value = serde_json::from_str(&m.read(".claude.json")).unwrap();
        assert_eq!(claude["mcpServers"]["wf-history"]["command"], wf.as_str());
        assert_eq!(
            claude["mcpServers"]["wf-history"]["args"],
            serde_json::json!(["history", "mcp", "serve"])
        );
        let codex: toml::Value = toml::from_str(&m.read(".codex/config.toml")).unwrap();
        assert_eq!(
            codex["mcp_servers"]["wf-history"]["command"].as_str(),
            Some(wf.as_str())
        );
        let cursor: Value = serde_json::from_str(&m.read(".cursor/mcp.json")).unwrap();
        assert_eq!(cursor["mcpServers"]["wf-history"]["command"], wf.as_str());
    }

    #[test]
    fn environment_outside_the_allowlist_is_refused_and_a_secret_value_fails_the_scan() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let mut narrow = open();
        narrow.env.allowed_keys = vec!["OTHER".into()];
        let claude = m.adapter(&team, "claude-code", narrow);
        let (state, _) = converge(&m, &claude, &team);
        assert_eq!(
            status(&state, ResourceKind::Env, "TEAM_NAME"),
            ObjectStatus::Blocked
        );
        assert!(!m.read(".claude/settings.json").contains("TEAM_NAME"));

        team.write(
            "workflow/env/env.yaml",
            "schema_version: 1\nvariables:\n  - key: LINEAR_API_TOKEN\n    value: lin_api_ABCDEFGHIJKLMNOPQRSTUVWXYZ012345\n",
        );
        let state = inspect(&m, &m.adapter(&team, "claude-code", open()), &team);
        let scan = state
            .findings
            .iter()
            .find(|f| f.code == "RESOURCE-SCAN")
            .unwrap();
        assert!(scan.message.contains("credential"), "{}", scan.message);
    }

    #[test]
    fn require_team_scripts_refuses_a_hook_that_does_not_run_wf() {
        let team = TeamFixture::new();
        let with_script = crate::testing::REGISTRY.replace(
            "  - id: capso.mcp.linear",
            "  - id: capso.hook.lint\n    kind: hook-dispatcher\n    required: true\n    event: Stop\n    executable: python3\n    arguments: [lint.py]\n    trust_contract: stable-definition\n    targets: [claude-code]\n  - id: capso.mcp.linear",
        );
        team.write("workflow/registry.yaml", &with_script);
        let m = Machine::new();
        let mut strict = open();
        strict.hooks.require_team_scripts = true;
        let state = inspect(&m, &m.adapter(&team, "claude-code", strict), &team);
        assert_eq!(
            status(&state, ResourceKind::Hook, "capso.hook.lint"),
            ObjectStatus::Blocked
        );
        let state = inspect(&m, &m.adapter(&team, "claude-code", open()), &team);
        assert_eq!(
            status(&state, ResourceKind::Hook, "capso.hook.lint"),
            ObjectStatus::Missing
        );
    }

    #[test]
    fn documents_go_to_the_machine() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let machine = m.machine(open());
        let (state, _) = converge(&m, &machine, &team);
        assert_eq!(
            status(&state, ResourceKind::Doc, "runbooks/deploy.md"),
            ObjectStatus::Missing
        );
        assert_eq!(
            std::fs::read_to_string(m.dir.path().join("state/docs/runbooks/deploy.md")).unwrap(),
            "# Deploy\n"
        );
        assert!(inspect(&m, &machine, &team).changes.is_empty());
    }

    #[test]
    fn a_step_that_cannot_write_fails_the_apply_and_the_rollback_restores_the_machine() {
        let team = TeamFixture::new();
        let m = Machine::new();
        m.write(".claude/CLAUDE.md", "mine\n");
        m.write(".claude/rules", "a file where a directory has to be");
        let claude = m.adapter(&team, "claude-code", open());
        let desired = Desired::scan(&team.repo());
        let state = claude.inspect(&desired, &[], &[]).unwrap();
        let mut tx = m.tx(false);
        assert!(claude.apply(&state.changes, &mut tx).is_err());
        tx.rollback();
        assert_eq!(m.read(".claude/CLAUDE.md"), "mine\n");
        assert!(!m.at(".claude/skills").exists());
        assert!(m.db.managed_resources(None).unwrap().is_empty());
    }

    #[test]
    fn verify_refuses_an_apply_that_did_not_land() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let claude = m.adapter(&team, "claude-code", open());
        let desired = Desired::scan(&team.repo());
        // Nothing applied: every object is still missing.
        let err = claude.verify(&desired, &[], &[]).unwrap_err();
        assert_eq!(err.kind, "POST-VERIFY");
    }

    #[test]
    fn a_dry_run_plans_every_change_and_writes_nothing() {
        let team = TeamFixture::new();
        let m = Machine::new();
        let claude = m.adapter(&team, "claude-code", open());
        let desired = Desired::scan(&team.repo());
        let state = claude.inspect(&desired, &[], &[]).unwrap();
        let mut tx = m.tx(true);
        let applied = claude.apply(&state.changes, &mut tx).unwrap();
        assert!(!applied.is_empty());
        assert!(!tx.plan.is_empty());
        tx.commit().unwrap();
        assert!(!m.at(".claude").exists());
        assert!(m.db.managed_resources(None).unwrap().is_empty());
    }

    #[test]
    fn a_version_probe_reads_the_first_number_and_survives_a_missing_binary() {
        let team = TeamFixture::new();
        let spec = team.agents().find("claude-code").unwrap().clone();
        let none = AgentInstall {
            binary: PathBuf::new(),
            version: String::new(),
            config_root: PathBuf::new(),
        };
        assert_eq!(probe_version(&spec, &none), "");
        #[cfg(unix)]
        {
            let dir = tempfile::tempdir().unwrap();
            let bin = dir.path().join("claude");
            std::fs::write(&bin, "#!/bin/sh\necho \"2.1.268 (Claude Code)\"\n").unwrap();
            use std::os::unix::fs::PermissionsExt;
            std::fs::set_permissions(&bin, std::fs::Permissions::from_mode(0o755)).unwrap();
            let install = AgentInstall {
                binary: bin,
                version: String::new(),
                config_root: dir.path().into(),
            };
            assert_eq!(probe_version(&spec, &install), "2.1.268");
        }
    }

    proptest::proptest! {
        #![proptest_config(proptest::prelude::ProptestConfig::with_cases(24))]

        /// Whichever agent, whatever subset of the team's resources exists, and whatever a
        /// person already had in the agent's instructions: one converge settles it, and the
        /// next finds nothing to do and writes nothing.
        #[test]
        fn one_converge_settles_any_agent_over_any_subset_of_resources(
            agent in proptest::sample::select(vec!["claude-code", "codex", "cursor", "kiro", "zcode", "openclaw"]),
            dropped in proptest::collection::btree_set(0usize..5, 0..5),
            mine in "[a-z ]{0,24}",
        ) {
            let team = TeamFixture::new();
            for i in &dropped {
                team.remove(["workflow/rules", "workflow/agents", "workflow/env", "workflow/docs", "skills/lfg/scripts"][*i]);
            }
            let m = Machine::new();
            let a = m.adapter(&team, agent, open());
            std::fs::create_dir_all(&a.location().root).unwrap();
            if let Some(prompt) = a.path(PathKind::Prompt) {
                m.write(prompt.strip_prefix(m.home()).unwrap().to_str().unwrap(), &format!("{mine}\n"));
            }
            converge(&m, &a, &team);
            let settled = inspect(&m, &a, &team);
            proptest::prop_assert!(settled.changes.is_empty(), "{agent}: {:#?}", settled.changes);
            let (_, applied) = converge(&m, &a, &team);
            proptest::prop_assert!(applied.is_empty(), "{agent}: {applied:?}");
        }
    }
}
