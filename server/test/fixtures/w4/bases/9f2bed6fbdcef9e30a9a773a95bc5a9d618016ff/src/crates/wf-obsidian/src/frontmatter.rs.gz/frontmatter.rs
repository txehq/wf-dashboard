use std::collections::BTreeMap;

/// The YAML block Obsidian reads for properties and Dataview queries.
///
/// Merged rather than replaced: a document rewritten later must keep the ticket somebody
/// set two weeks ago and did not pass again today.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Frontmatter(pub BTreeMap<String, String>);

/// Keeps the block stable across writes, so a re-file produces no spurious diff.
const FIELD_ORDER: [&str; 6] = [
    "kind",
    "product",
    "feature",
    "ticket",
    "published",
    "updated",
];

impl Frontmatter {
    pub fn from_pairs(pairs: &[(&str, &str)]) -> Self {
        Self(
            pairs
                .iter()
                .map(|(k, v)| (k.to_string(), v.to_string()))
                .collect(),
        )
    }

    pub fn get(&self, k: &str) -> &str {
        self.0.get(k).map(String::as_str).unwrap_or("")
    }

    /// Apply non-empty updates over existing values. An empty update never clears a field —
    /// the caller not mentioning something is not the caller deleting it.
    pub fn merge(&self, updates: &Frontmatter) -> Frontmatter {
        let mut out = self.0.clone();
        for (k, v) in &updates.0 {
            if !v.trim().is_empty() {
                out.insert(k.clone(), v.clone());
            }
        }
        Frontmatter(out)
    }

    pub fn render(&self) -> String {
        if self.0.is_empty() {
            return String::new();
        }
        let mut b = String::from("---\n");
        let mut written = Vec::new();
        for key in FIELD_ORDER {
            if let Some(v) = self.0.get(key).filter(|v| !v.is_empty()) {
                b.push_str(&format!("{key}: {}\n", quote_if_needed(v)));
                written.push(key);
            }
        }
        // Anything the tool does not own is preserved, in a stable order.
        for (k, v) in &self.0 {
            if written.contains(&k.as_str()) || v.is_empty() {
                continue;
            }
            b.push_str(&format!("{k}: {}\n", quote_if_needed(v)));
        }
        b.push_str("---\n\n");
        b
    }
}

/// Separate an existing block from the body. A document with no block is not an error —
/// most of this vault predates the convention.
pub fn split(text: &str) -> (Frontmatter, String) {
    let text = text.replace("\r\n", "\n");
    if !text.starts_with("---\n") {
        return (Frontmatter::default(), text);
    }
    let Some(end) = text[4..].find("\n---") else {
        // An unterminated block is not frontmatter; treat the whole file as body rather
        // than silently swallowing content into a header.
        return (Frontmatter::default(), text);
    };
    let block = &text[4..4 + end];
    // Trim ALL leading newlines, not one: `render` re-adds a blank line after the fence, so
    // stripping a single newline would grow the gap by one on every re-file.
    let body = text[4 + end + 4..].trim_start_matches('\n').to_string();

    let mut fm = BTreeMap::new();
    for line in block.split('\n') {
        let Some((key, value)) = line.split_once(':') else {
            continue;
        };
        let key = key.trim();
        if key.is_empty() || key.starts_with('#') {
            continue;
        }
        fm.insert(
            key.to_string(),
            value.trim().trim_matches(['"', '\'']).to_string(),
        );
    }
    (Frontmatter(fm), body)
}

/// Protect values YAML would otherwise reinterpret — a bare `2026-09-04` parses as a
/// timestamp, which is how a date field stops comparing equal to the string that wrote it.
fn quote_if_needed(v: &str) -> String {
    if v.is_empty() {
        return "\"\"".to_string();
    }
    if v.contains([
        ':', '#', '{', '}', '[', ']', ',', '&', '*', '?', '|', '<', '>', '=', '!', '%', '@', '`',
        '"', '\'',
    ]) || looks_like_date(v)
    {
        return format!("\"{}\"", v.replace('"', "\\\""));
    }
    v.to_string()
}

fn looks_like_date(v: &str) -> bool {
    let b = v.as_bytes();
    if b.len() != 10 {
        return false;
    }
    b.iter().enumerate().all(|(i, c)| match i {
        4 | 7 => *c == b'-',
        _ => c.is_ascii_digit(),
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_document_with_no_block_is_all_body() {
        let (fm, body) = split("# heading\n\ntext\n");
        assert!(fm.0.is_empty());
        assert_eq!(body, "# heading\n\ntext\n");
    }

    #[test]
    fn an_unterminated_block_is_body_not_a_swallowed_header() {
        let text = "---\nkind: brief\nand then nothing closes it\n";
        let (fm, body) = split(text);
        assert!(fm.0.is_empty());
        assert_eq!(body, text, "content must not vanish into a header");
    }

    #[test]
    fn a_merge_never_clears_a_field_the_caller_did_not_mention() {
        let existing = Frontmatter::from_pairs(&[("ticket", "TXE-123"), ("kind", "brief")]);
        let merged = existing.merge(&Frontmatter::from_pairs(&[
            ("ticket", ""),
            ("updated", "2026-09-04"),
        ]));
        assert_eq!(
            merged.get("ticket"),
            "TXE-123",
            "an empty update is not a deletion"
        );
        assert_eq!(merged.get("updated"), "2026-09-04");
    }

    #[test]
    fn a_date_is_quoted_so_it_stays_a_string() {
        let fm = Frontmatter::from_pairs(&[("updated", "2026-09-04")]);
        assert!(
            fm.render().contains("updated: \"2026-09-04\""),
            "{}",
            fm.render()
        );
    }

    #[test]
    fn refiling_is_byte_stable() {
        // The gap after the fence must not grow by a newline on every write.
        let fm = Frontmatter::from_pairs(&[("kind", "brief"), ("ticket", "TXE-1")]);
        let mut doc = format!("{}# body\n", fm.render());
        for _ in 0..5 {
            let (parsed, body) = split(&doc);
            doc = format!("{}{body}", parsed.render());
        }
        assert_eq!(doc, format!("{}# body\n", fm.render()));
    }

    #[test]
    fn the_owned_fields_come_first_in_a_stable_order() {
        let fm = Frontmatter::from_pairs(&[
            ("zzz", "last"),
            ("updated", "2026-09-04"),
            ("kind", "brief"),
            ("aaa", "other"),
        ]);
        let rendered = fm.render();
        let k = rendered.find("kind:").unwrap();
        let u = rendered.find("updated:").unwrap();
        let a = rendered.find("aaa:").unwrap();
        assert!(k < u && u < a, "{rendered}");
    }
}
