use serde::{Deserialize, Serialize};
use std::path::Path;

/// The schema version this build understands. A registry declaring a higher one is refused
/// rather than best-effort parsed — a newer field we silently drop is a component that
/// silently does not ship.
pub const SCHEMA_VERSION: u32 = 2;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Registry {
    pub schema_version: u32,
    pub organization: String,
    pub product: String,
    pub plugin: PluginIdentity,
    #[serde(default)]
    pub upstream: Upstream,
    pub components: Vec<Component>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PluginIdentity {
    pub id: String,
    pub name: String,
    pub marketplace: String,
    pub description: String,
    #[serde(default)]
    pub keywords: Vec<String>,
    #[serde(default)]
    pub category: String,
}

/// Where this build syncs from by default. Every field here is overridable per-invocation
/// (`--repo`, `--branch`, `--channel`), because the same binary has to be able to point at
/// a fork during a rehearsal and at the real repository in production.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Upstream {
    pub repo: String,
    pub branch: String,
    pub stable_branch: String,
    pub canary_branch: String,
}

impl Default for Upstream {
    fn default() -> Self {
        Self {
            repo: wf_core::DEFAULT_REPO.to_string(),
            branch: wf_core::DEFAULT_BRANCH.to_string(),
            stable_branch: "release/stable".to_string(),
            canary_branch: "release/canary".to_string(),
        }
    }
}

/// One deliverable. `kind` decides the shape of the rest, and adding a kind means adding an
/// adapter — the enum is closed on purpose.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Component {
    pub id: String,
    pub kind: Kind,
    /// Where the canonical bytes live, relative to the repository root. Absent for
    /// components that are pure declarations (a hook dispatcher is an argv, not a file).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub source: Option<String>,
    /// Always true in this release line; the field exists so the refusal is explicit
    /// rather than implied by its absence.
    pub required: bool,
    #[serde(default)]
    pub targets: Vec<Target>,
    /// When a change to this component takes effect in a running session.
    #[serde(default)]
    pub reload: Reload,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub conflict_policy: Option<ConflictPolicy>,
    /// hook-dispatcher only.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub event: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub executable: Option<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub arguments: Vec<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub trust_contract: Option<String>,
    /// mcp only. References only — a value here is a schema error, not a warning (D-018).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub credentials: Option<Credentials>,
    /// mcp only. Seconds the server may take from launch to answering `tools/list`, written
    /// wherever an agent reads a limit per server. It lives here and not in the definition
    /// file because every released `wf` refuses a field its definition parser does not know,
    /// and the previous release is the binary that installs the next one.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub startup_timeout_sec: Option<u32>,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub description: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum Kind {
    Skill,
    PromptBlock,
    HookDispatcher,
    HookPolicy,
    Mcp,
    ReadinessProfile,
}

impl Kind {
    pub fn as_str(self) -> &'static str {
        match self {
            Kind::Skill => "skill",
            Kind::PromptBlock => "prompt-block",
            Kind::HookDispatcher => "hook-dispatcher",
            Kind::HookPolicy => "hook-policy",
            Kind::Mcp => "mcp",
            Kind::ReadinessProfile => "readiness-profile",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum Agent {
    ClaudeCode,
    Codex,
}

impl Agent {
    pub fn as_str(self) -> &'static str {
        match self {
            Agent::ClaudeCode => "claude-code",
            Agent::Codex => "codex",
        }
    }
    pub fn short(self) -> &'static str {
        match self {
            Agent::ClaudeCode => "claude",
            Agent::Codex => "codex",
        }
    }
    pub fn parse(s: &str) -> Option<Self> {
        match s {
            "claude" | "claude-code" => Some(Agent::ClaudeCode),
            "codex" => Some(Agent::Codex),
            _ => None,
        }
    }
    pub const ALL: [Agent; 2] = [Agent::ClaudeCode, Agent::Codex];
}

/// A target is written either as a bare agent name or as a table with delivery detail. Both
/// spellings appear in the plan's example registry, so both parse.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(untagged)]
pub enum Target {
    Bare(Agent),
    Detailed {
        agent: Agent,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        delivery: Option<Delivery>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        scope: Option<String>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        destination: Option<Destination>,
    },
}

impl Target {
    pub fn agent(&self) -> Agent {
        match self {
            Target::Bare(a) => *a,
            Target::Detailed { agent, .. } => *agent,
        }
    }
    pub fn destination(&self) -> Option<Destination> {
        match self {
            Target::Bare(_) => None,
            Target::Detailed { destination, .. } => *destination,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum Delivery {
    NativePlugin,
    UserConfig,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum Destination {
    /// Whichever global CLAUDE.md this machine's Claude Code actually reads.
    EffectiveClaudeMd,
    /// Whichever of AGENTS.override.md / AGENTS.md this machine's Codex actually reads.
    EffectiveAgentsMd,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum Reload {
    /// Visible to the running session once the file is written.
    Immediate,
    /// Claude can rescan skills mid-session.
    ReloadSkills,
    /// Needs a new session.
    #[default]
    NextSession,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum ConflictPolicy {
    /// Back the user's version up, then write ours. The only policy in this release line —
    /// every organization resource is mandatory, and an unbacked-up overwrite is forbidden.
    #[default]
    BackupAndReplace,
}

/// The mode for a service that has no token route at all: this component's own server logs
/// in through the provider's OAuth flow in a browser and holds the result itself.
/// `references` is empty because there is no name to set, and `login_host` says where that
/// login goes so a report can name it.
///
/// The two modes are exhaustive and disjoint. A block that can be answered from this machine
/// names the variable and is `environment`; a block whose own server logs in through a browser
/// is this one, and reports what it could not observe.
pub const CREDENTIAL_MODE_AGENT_OAUTH: &str = "agent-oauth";

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Credentials {
    pub mode: String,
    /// Environment variable names or secret-store reference names. Never values.
    #[serde(default)]
    pub references: Vec<String>,
    /// Must be true. Present so the prohibition is visible in the file a human reads.
    #[serde(default = "default_true")]
    pub values_forbidden: bool,
    /// The host **this component's own server** authenticates against, named so a report can
    /// say where the browser login goes. Required, and only meaningful, under `agent-oauth`.
    ///
    /// One host, because a bridge has one URL, and this component's own — never a host some
    /// other connection on the machine happens to share (WFR-016). Empty is tolerated so that
    /// a bundle from a release predating the field still applies; the cost is the host's name
    /// in one message.
    #[serde(default)]
    pub login_host: String,
}

fn default_true() -> bool {
    true
}

impl Registry {
    pub fn parse(yaml: &str) -> wf_core::Result<Self> {
        let reg: Registry = serde_yaml_ng::from_str(yaml).map_err(|e| {
            wf_core::Error::usage("REGISTRY-PARSE", format!("workflow/registry.yaml: {e}")).with_zh(
                "workflow/registry.yaml 读不下来，可能是格式写错了。请检查一下缩进和引号。",
            )
        })?;
        if reg.schema_version != SCHEMA_VERSION {
            return Err(wf_core::Error::unsupported(
                "REGISTRY-SCHEMA",
                format!(
                    "registry declares schema_version {} but this build understands {}",
                    reg.schema_version, SCHEMA_VERSION
                ),
            )
            .with_zh("这份配置比当前的 wf 版本更新。请先运行 `wf sync` 升级 wf，再试一次。"));
        }
        Ok(reg)
    }

    pub fn load(root: &Path) -> wf_core::Result<Self> {
        let p = root.join("workflow/registry.yaml");
        let text = std::fs::read_to_string(&p)
            .map_err(|e| wf_core::Error::from(e).with_zh(format!("找不到 {}。", p.display())))?;
        Self::parse(&text)
    }

    pub fn component(&self, id: &str) -> Option<&Component> {
        self.components.iter().find(|c| c.id == id)
    }

    pub fn of_kind(&self, kind: Kind) -> impl Iterator<Item = &Component> {
        self.components.iter().filter(move |c| c.kind == kind)
    }

    pub fn for_agent(&self, agent: Agent) -> impl Iterator<Item = &Component> {
        self.components
            .iter()
            .filter(move |c| c.targets.iter().any(|t| t.agent() == agent))
    }

    /// The skill directory name for a `skill` component — `skills/interview` → `interview`.
    pub fn skill_name(c: &Component) -> Option<&str> {
        c.source.as_deref()?.strip_prefix("skills/")
    }
}
