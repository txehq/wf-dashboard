//! Format adapters: how one kind of resource is written in one agent's own file format.
//!
//! Each enum below is the closed vocabulary `agents.yaml` may name. An agent whose files look
//! like an existing format reuses it by name; a genuinely new format is a variant here and an
//! adapter beside it, never a guess.

pub mod claude;
pub mod codex;
pub mod cursor;
pub mod json_doc;
pub mod kiro;
pub mod openclaw;
pub mod toml_doc;
pub mod zcode;

use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::BTreeMap;
use std::path::Path;
use wf_core::{Error, Result};

/// Where and how hook handlers live.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum HookFormat {
    /// `settings.json` → `hooks.<Event>[] = {matcher?, hooks: [handler]}`.
    Claude,
    /// `hooks.json`, the Claude shape; trust is bound to the exact handler definition.
    Codex,
    /// `hooks.json` → `{version: 1, hooks: {sessionStart: [{command, matcher?}]}}`.
    Cursor,
    /// A standalone `hooks/*.json` file `wf` owns whole (`version: v1`).
    Kiro,
    /// `cli/config.json` → `hooks.events.<Event>[]`, process handlers with argv.
    Zcode,
    /// A hook directory holding `HOOK.md` and `handler.ts`.
    Openclaw,
}

/// Where and how MCP servers live.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum McpFormat {
    /// `mcpServers.<name>` with an explicit `type`; `${VAR}` expanded by the agent.
    ClaudeJson,
    /// `[mcp_servers.<name>]`; environment forwarded by name through `env_vars`.
    CodexToml,
    /// `mcpServers.<name>`; stdio has no `type`, references are `${env:VAR}`.
    CursorJson,
    /// `mcpServers.<name>` without `type`.
    KiroJson,
}

/// How a team rule (`rules/**/*.md`, optional `paths:` front matter) is written.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum RuleFormat {
    /// The file as authored.
    Markdown,
    /// `.mdc` with `globs` / `alwaysApply` front matter.
    CursorMdc,
    /// A steering document with `inclusion` front matter.
    KiroSteering,
}

/// How a custom subagent (`agents/<name>.yaml`) is written.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum AgentFormat {
    ClaudeMarkdown,
    CursorMarkdown,
    CodexToml,
    KiroJson,
}

/// How the organization prompt block reaches an instructions file.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum PromptFormat {
    /// A managed block appended to the file.
    Append,
    /// Codex: `AGENTS.override.md` when non-empty, else `AGENTS.md`; block prepended.
    CodexEffective,
    /// A whole steering file `wf` owns, always included.
    SteeringFile,
}

/// Where team environment variables are set for an agent.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum EnvFormat {
    /// `settings.json` → `env.<KEY>`.
    ClaudeSettings,
    /// `config.toml` → `[shell_environment_policy.set]`.
    CodexToml,
}

/// Which kind of document a keyed object lives in.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Document {
    Json,
    Toml,
}

// --- hooks ----------------------------------------------------------------------------

/// A lifecycle event, spelled the canonical (Claude) way.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub enum HookEvent {
    SessionStart,
    SessionEnd,
    UserPromptSubmit,
    PreToolUse,
    PostToolUse,
    Stop,
}

impl HookEvent {
    pub const ALL: [HookEvent; 6] = [
        HookEvent::SessionStart,
        HookEvent::SessionEnd,
        HookEvent::UserPromptSubmit,
        HookEvent::PreToolUse,
        HookEvent::PostToolUse,
        HookEvent::Stop,
    ];

    pub fn as_str(self) -> &'static str {
        match self {
            HookEvent::SessionStart => "SessionStart",
            HookEvent::SessionEnd => "SessionEnd",
            HookEvent::UserPromptSubmit => "UserPromptSubmit",
            HookEvent::PreToolUse => "PreToolUse",
            HookEvent::PostToolUse => "PostToolUse",
            HookEvent::Stop => "Stop",
        }
    }

    /// Any spelling an agent or a person uses: `SessionStart`, `sessionStart`,
    /// `session-start`, `session_start`; Cursor's `beforeSubmitPrompt` and teamai's
    /// `prompt-submit` are the prompt event.
    pub fn parse(text: &str) -> Option<Self> {
        let folded: String = text
            .chars()
            .filter(char::is_ascii_alphanumeric)
            .collect::<String>()
            .to_ascii_lowercase();
        Some(match folded.as_str() {
            "sessionstart" => HookEvent::SessionStart,
            "sessionend" => HookEvent::SessionEnd,
            "userpromptsubmit" | "promptsubmit" | "beforesubmitprompt" => {
                HookEvent::UserPromptSubmit
            }
            "pretooluse" => HookEvent::PreToolUse,
            "posttooluse" => HookEvent::PostToolUse,
            "stop" => HookEvent::Stop,
            _ => return None,
        })
    }
}

pub const MARKER_BOOTSTRAP: &str = "capso-wf-bootstrap";
pub const MARKER_USAGE: &str = "capso-wf-usage";

/// One handler `wf` writes: the fixed argv of `wf hook …`, under one event.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct HookEntry {
    pub event: HookEvent,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub matcher: Option<String>,
    pub argv: Vec<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub timeout_secs: Option<u64>,
}

impl HookEntry {
    /// `capso-wf-bootstrap` for the session-start dispatcher, `capso-wf-usage` otherwise.
    pub fn marker(&self) -> &'static str {
        marker_for_argv(&self.argv).unwrap_or(MARKER_USAGE)
    }

    /// Unique per document: one dispatcher of each kind per event.
    pub fn identity(&self) -> String {
        format!("{}/{}", self.event.as_str(), self.marker())
    }

    /// The argv as one shell command, each word quoted only when it has to be.
    pub fn command(&self) -> String {
        self.argv
            .iter()
            .map(|w| shell_word(w))
            .collect::<Vec<_>>()
            .join(" ")
    }
}

/// Quote one word for a POSIX shell, leaving plain words bare.
pub fn shell_word(word: &str) -> String {
    if !word.is_empty()
        && word
            .bytes()
            .all(|c| c.is_ascii_alphanumeric() || b"_./:-".contains(&c))
    {
        word.into()
    } else {
        format!("'{}'", word.replace('\'', "'\\''"))
    }
}

/// Split a command written by [`shell_word`] back into words. Anything that uses shell
/// syntax beyond single quotes and plain words is not ours, and is `None`.
pub fn shell_words(command: &str) -> Option<Vec<String>> {
    let mut words = Vec::new();
    let mut chars = command.chars().peekable();
    loop {
        while chars.peek() == Some(&' ') {
            chars.next();
        }
        if chars.peek().is_none() {
            return Some(words);
        }
        let mut word = String::new();
        while let Some(&c) = chars.peek() {
            match c {
                ' ' => break,
                '\'' => {
                    chars.next();
                    loop {
                        match chars.next()? {
                            '\'' => break,
                            ch => word.push(ch),
                        }
                    }
                }
                '\\' => {
                    chars.next();
                    if chars.next()? != '\'' {
                        return None;
                    }
                    word.push('\'');
                }
                c if c.is_ascii_alphanumeric() || "_./:-".contains(c) => {
                    word.push(c);
                    chars.next();
                }
                _ => return None,
            }
        }
        words.push(word);
    }
}

/// `…/wf hook session-start|dispatch …` — the only handlers `wf` ever writes.
pub fn marker_for_argv(argv: &[String]) -> Option<&'static str> {
    let exe = Path::new(argv.first()?).file_name()?.to_str()?;
    if exe != "wf" {
        return None;
    }
    match (argv.get(1)?.as_str(), argv.get(2)?.as_str()) {
        ("hook", "session-start") => Some(MARKER_BOOTSTRAP),
        ("hook", "dispatch") => Some(MARKER_USAGE),
        _ => None,
    }
}

/// The identity of a handler found in a document, if it is one of ours.
pub fn owned_identity(
    event: HookEvent,
    argv: Option<&[String]>,
    status: Option<&str>,
) -> Option<String> {
    let marker = match status {
        Some(MARKER_BOOTSTRAP) => MARKER_BOOTSTRAP,
        Some(MARKER_USAGE) => MARKER_USAGE,
        _ => marker_for_argv(argv?)?,
    };
    Some(format!("{}/{marker}", event.as_str()))
}

/// An agent whose own switch for config-file hooks is off, so what `wf` wrote is in place
/// and dormant. The switch governs the person's handlers too, so `wf` reports it rather
/// than setting it.
pub const HOOKS_DISABLED: &str = "HOOKS-DISABLED";

pub trait HookFormatAdapter: Send + Sync {
    fn supports(&self, event: HookEvent) -> bool;
    /// Does a handler in this format carry a field for `wf`'s marker? Where none does, a
    /// handler is `wf`'s again only by its `wf hook …` argv, and one that runs anything else
    /// could never be read back.
    fn marks_handlers(&self) -> bool {
        false
    }
    /// Why the handlers in `text` will not run, if this format has a switch and it is off.
    fn dormant(&self, _text: &str) -> Option<String> {
        None
    }
    /// The native value for one handler.
    fn render_hook(&self, entry: &HookEntry) -> Value;
    /// The handlers `wf` owns in a document: identity and native value.
    fn parse_hooks(&self, text: &str, path: &Path) -> Result<Vec<(String, Value)>>;
    /// The document with the handler named by `entry.identity()` replaced or added.
    fn upsert(&self, text: &str, entry: &HookEntry, path: &Path) -> Result<String>;
    /// The document without the handler named `identity`.
    fn remove(&self, text: &str, identity: &str, path: &Path) -> Result<String>;
}

pub fn get_hook_format(format: HookFormat) -> &'static dyn HookFormatAdapter {
    match format {
        HookFormat::Claude => &claude::ClaudeHooks,
        HookFormat::Codex => &codex::CodexHooks,
        HookFormat::Cursor => &cursor::CursorHooks,
        HookFormat::Kiro => &kiro::KiroHooks,
        HookFormat::Zcode => &zcode::ZcodeHooks,
        HookFormat::Openclaw => &openclaw::OpenclawHooks,
    }
}

// --- MCP ------------------------------------------------------------------------------

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum McpTransport {
    #[default]
    Stdio,
    Http,
    Sse,
}

/// One MCP server, as `workflow/mcps/*.yaml` declares it. References only: a value in here
/// would be copied into the lock, the bundle and every machine's backups (D-018).
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct McpDef {
    #[serde(default = "one")]
    pub schema_version: u32,
    pub name: String,
    #[serde(default)]
    pub description: String,
    #[serde(default)]
    pub transport: McpTransport,
    #[serde(default)]
    pub command: Option<String>,
    #[serde(default)]
    pub args: Vec<String>,
    #[serde(default)]
    pub url: Option<String>,
    /// Environment names the server needs, passed through by name.
    #[serde(default)]
    pub env_references: Vec<String>,
    /// Header values are literal or a `${VAR}` reference; never a credential.
    #[serde(default)]
    pub headers: BTreeMap<String, String>,
    /// Seconds the server may take from launch to answering `tools/list`, from the component's
    /// `startup_timeout_sec` in the registry. An agent that gives up sooner drops the server
    /// from the session without a word. Never read from the definition file: a released `wf`
    /// refuses a key there it does not know, and it is the binary that installs the next one.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub startup_timeout_sec: Option<u32>,
    /// The registry component this server installs, written into a stdio server's environment
    /// as [`COMPONENT_ENV`] so a process on this machine can be told apart as ours (WFR-016).
    /// Set from the registry, never read from the definition file, for the same reason as
    /// `startup_timeout_sec`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub component: Option<String>,
}

/// The environment variable every stdio server `wf` installs is launched with, holding its
/// component id. Every process of the server's chain inherits it: `npx`, its shell, node.
pub const COMPONENT_ENV: &str = "WF_MCP_COMPONENT";

/// A stdio server's environment: each referenced name, spelled by `reference`, and the
/// component it belongs to.
pub(crate) fn stdio_env(
    def: &McpDef,
    reference: impl Fn(&str) -> String,
) -> serde_json::Map<String, Value> {
    let mut env: serde_json::Map<String, Value> = def
        .env_references
        .iter()
        .map(|k| (k.clone(), reference(k).into()))
        .collect();
    if let Some(component) = &def.component {
        env.insert(COMPONENT_ENV.into(), component.clone().into());
    }
    env
}

fn one() -> u32 {
    1
}

impl McpDef {
    pub fn parse(yaml: &str, source: &Path) -> Result<Self> {
        let def: Self = serde_yaml_ng::from_str(yaml).map_err(|e| {
            Error::usage("MCP-PARSE", format!("{}: {e}", source.display()))
                .with_zh(format!("{} 读不下来，请检查格式。", source.display()))
        })?;
        for (key, present) in [
            ("startup_timeout_sec", def.startup_timeout_sec.is_some()),
            ("component", def.component.is_some()),
        ] {
            if present {
                return Err(Error::usage(
                    "MCP-PARSE",
                    format!(
                        "{}: {key} comes from the component in workflow/registry.yaml; the previous release's definition parser refuses it here",
                        source.display()
                    ),
                ));
            }
        }
        Ok(def)
    }

    /// Everything a definition must satisfy before any agent sees it.
    pub fn validate(&self) -> Result<()> {
        let refuse = |message: String| {
            Err(Error::usage(
                "MCP-INVALID",
                format!("{}: {message}", self.name),
            ))
        };
        if self.schema_version != 1 {
            return refuse(format!(
                "schema_version {} is not one this build understands",
                self.schema_version
            ));
        }
        if self.name.is_empty()
            || !self
                .name
                .bytes()
                .all(|b| b.is_ascii_alphanumeric() || b == b'_' || b == b'-')
        {
            return refuse("name must be letters, digits, '-' and '_'".into());
        }
        match self.transport {
            McpTransport::Stdio => {
                if self.command.as_deref().unwrap_or("").is_empty() {
                    return refuse("a stdio server needs a command".into());
                }
                if self.url.is_some() {
                    return refuse("a stdio server has no url".into());
                }
            }
            McpTransport::Http | McpTransport::Sse => {
                if self.url.as_deref().unwrap_or("").is_empty() {
                    return refuse("a remote server needs a url".into());
                }
                if self.command.is_some() {
                    return refuse("a remote server has no command".into());
                }
            }
        }
        if self.startup_timeout_sec == Some(0) {
            return refuse("startup_timeout_sec must be at least one second".into());
        }
        for name in self.env_references.iter().chain(
            self.headers
                .values()
                .flat_map(|v| references(v))
                .collect::<Vec<_>>()
                .iter(),
        ) {
            if !env_name(name) {
                return refuse(format!("env reference {name:?} is not an environment name"));
            }
        }
        let words = self
            .headers
            .values()
            .chain(self.args.iter())
            .flat_map(|v| v.split_whitespace());
        for word in words {
            if wf_core::redact::looks_like_secret(word) {
                return refuse(
                    "a header or argument carries what looks like a credential; reference it as ${NAME} instead"
                        .into(),
                );
            }
        }
        Ok(())
    }

    /// Every host this server reaches: its URL, and any http(s) URL among its arguments.
    pub fn hosts(&self) -> Vec<String> {
        let mut out: Vec<String> = Vec::new();
        for host in self
            .url
            .iter()
            .chain(self.args.iter())
            .filter_map(|u| url_host(u))
        {
            if !out.contains(&host) {
                out.push(host);
            }
        }
        out
    }
}

/// Every `${NAME}` in a value.
pub(crate) fn references(value: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut rest = value;
    while let Some(start) = rest.find("${") {
        let after = &rest[start + 2..];
        let Some(end) = after.find('}') else { break };
        out.push(after[..end].to_string());
        rest = &after[end + 1..];
    }
    out
}

pub(crate) fn env_name(name: &str) -> bool {
    !name.is_empty()
        && !name.starts_with(|c: char| c.is_ascii_digit())
        && name.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_')
}

pub trait McpFormatAdapter: Send + Sync {
    fn document(&self) -> Document;
    fn keys(&self, name: &str) -> Vec<String>;
    /// The native value, or `None` when this format cannot express the transport.
    fn render_server(&self, def: &McpDef) -> Result<Option<Value>>;

    /// What `document` already holds of ours: the host we publish, or the key we write.
    ///
    /// `targets` are our own definitions, so both halves of the answer are ours. The
    /// document is read as text and parsed here; an unreadable document is an error rather
    /// than an empty answer, because "nothing is there" and "nobody could look" must not
    /// leave through the same door.
    fn occupied(&self, document: &str, targets: &[&McpDef]) -> Result<Vec<Occupancy>> {
        if document.trim().is_empty() || targets.is_empty() {
            return Ok(Vec::new());
        }
        // The table every format in this build keeps its servers under, taken from the key
        // path the format itself declares rather than hard-coded a second time.
        let Some(table_key) = targets
            .first()
            .and_then(|def| self.keys(&def.name).first().cloned())
        else {
            return Ok(Vec::new());
        };
        let table = match self.document() {
            Document::Json => {
                let root = json_doc::parse_object(document, Path::new("mcp"))
                    .map_err(|_| survey_parse_error())?;
                root.get(&table_key).cloned()
            }
            Document::Toml => {
                let doc = toml_doc::parse(document, Path::new("mcp"))
                    .map_err(|_| survey_parse_error())?;
                toml_doc::get(&doc, &[table_key])
            }
        };
        let entries: Vec<(&String, &Value)> = match &table {
            Some(Value::Object(map)) => map.iter().collect(),
            None => Vec::new(),
            _ => return Err(survey_parse_error()),
        };
        let mut out: Vec<Occupancy> = Vec::new();
        for def in targets {
            if self.render_server(def)?.is_none() {
                continue;
            }
            // Our own key answers separately. The entry under it is the one an earlier run
            // of this same command wrote, and calling it a second connection would put "two
            // connections to the same service" in front of somebody who has one.
            let ours = self.keys(&def.name);
            let own = ours.get(1).map(String::as_str).unwrap_or(&def.name);
            let others: Vec<&Value> = entries
                .iter()
                .filter(|(key, _)| key.as_str() != own)
                .map(|(_, entry)| *entry)
                .collect();
            let hosts = def.hosts();
            let reached = hosts.iter().any(|host| {
                others
                    .iter()
                    .any(|e| entry_hosts(e).iter().any(|h| h == host))
            });
            if reached {
                out.push(Occupancy {
                    component: def.name.clone(),
                    by: Occupied::Host,
                });
            } else if entries.iter().any(|(key, _)| key.as_str() == own) {
                out.push(Occupancy {
                    component: def.name.clone(),
                    by: Occupied::Key,
                });
            }
        }
        out.sort_by(|a, b| a.component.cmp(&b.component));
        out.dedup();
        Ok(out)
    }
}

fn survey_parse_error() -> Error {
    Error::usage("MCP-SURVEY-PARSE", "cannot parse the MCP configuration")
        .with_zh("无法解析 MCP 配置，请检查配置文件的格式。")
}

pub fn get_mcp_format(format: McpFormat) -> &'static dyn McpFormatAdapter {
    match format {
        McpFormat::ClaudeJson => &claude::ClaudeMcp,
        McpFormat::CodexToml => &codex::CodexMcp,
        McpFormat::CursorJson => &cursor::CursorMcp,
        McpFormat::KiroJson => &kiro::KiroMcp,
    }
}

/// The host of an http(s) URL, lower-cased; `None` for anything else or a host that is
/// still a `${VAR}` reference — a host nobody can check is not an allowed host.
pub fn url_host(url: &str) -> Option<String> {
    let rest = url
        .strip_prefix("https://")
        .or_else(|| url.strip_prefix("http://"))?;
    let authority = &rest[..rest.find(['/', '?', '#']).unwrap_or(rest.len())];
    let host = authority.rsplit('@').next().unwrap_or(authority);
    let host = host.split(':').next().unwrap_or(host).to_ascii_lowercase();
    (!host.is_empty() && !host.contains('$') && !host.contains('{')).then_some(host)
}

/// Where one entry inside somebody's MCP document points: its `url`, and any http(s) URL
/// among its `args`. A raw entry is whatever the document holds — the same shape `McpDef`
/// renders into, not an `McpDef` itself, which carries `name` and refuses unknown fields.
///
/// Nothing but the host leaves this function. An entry's `env`, `headers` and token are not
/// read here and cannot be reached from what it returns (WFR-016).
pub fn entry_hosts(entry: &Value) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    let urls = entry.get("url").and_then(Value::as_str).into_iter().chain(
        entry
            .get("args")
            .and_then(Value::as_array)
            .into_iter()
            .flatten()
            .filter_map(Value::as_str),
    );
    for url in urls {
        if let Some(host) = url_host(url) {
            if !out.contains(&host) {
                out.push(host);
            }
        }
    }
    out
}

/// A server this machine already holds, named by what is ours rather than by what is theirs.
///
/// An entry's own key and its other fields are deliberately absent: this type says "our host
/// is already pointed at" or "our key is already there", and nothing about the connection
/// that answered (WFR-016, WFR-018).
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Occupancy {
    /// The definition of **ours** whose endpoint or key the document already holds. Ours
    /// because it came out of the registry, never because it was read off the document.
    pub component: String,
    pub by: Occupied,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum Occupied {
    /// Some entry in the document reaches the host we publish.
    Host,
    /// The key we write is already present, whatever it holds.
    Key,
}

// --- rules ----------------------------------------------------------------------------

/// A team rule split into what the formats care about.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RuleSource {
    pub description: Option<String>,
    /// Globs the rule is scoped to; empty means always.
    pub paths: Vec<String>,
    pub body: String,
}

pub fn parse_rule(text: &str) -> RuleSource {
    let bare = RuleSource {
        description: None,
        paths: vec![],
        body: text.to_string(),
    };
    let Some((front, body)) = split_front_matter(text) else {
        return bare;
    };
    let Ok(front) = serde_yaml_ng::from_str::<serde_yaml_ng::Value>(front) else {
        return bare;
    };
    let globs = |key: &str| -> Vec<String> {
        match front.get(key) {
            Some(serde_yaml_ng::Value::String(s)) => s
                .split(',')
                .map(str::trim)
                .filter(|s| !s.is_empty())
                .map(String::from)
                .collect(),
            Some(serde_yaml_ng::Value::Sequence(items)) => items
                .iter()
                .filter_map(|v| v.as_str())
                .map(String::from)
                .collect(),
            _ => vec![],
        }
    };
    let mut paths = globs("paths");
    if paths.is_empty() {
        paths = globs("globs");
    }
    RuleSource {
        description: front
            .get("description")
            .and_then(|v| v.as_str())
            .map(String::from),
        paths,
        body: body.to_string(),
    }
}

/// `(front matter, body)` when the text opens with a `---` fenced block.
fn split_front_matter(text: &str) -> Option<(&str, &str)> {
    let rest = text.strip_prefix("---\n")?;
    let end = rest.find("\n---\n").map(|i| (i, i + 5)).or_else(|| {
        rest.strip_suffix("\n---")
            .map(|front| (front.len(), rest.len()))
    })?;
    Some((&rest[..end.0], &rest[end.1..]))
}

/// Words YAML 1.1's core schema resolves to a boolean or to null, in any case. A plain
/// scalar spelling one of these reads back as that type, not as the string that went in.
const YAML_WORDS: [&str; 15] = [
    "true", "false", "yes", "no", "on", "off", "null", "~", "y", "n", "t", "f", "nan", "inf",
    "none",
];

/// A YAML scalar, plain when that reads back as the same string and single-quoted otherwise.
fn yaml_scalar(text: &str) -> String {
    let lower = text.to_ascii_lowercase();
    let numeric = || {
        let body = lower.trim_start_matches(['+', '-']);
        !body.is_empty()
            && (body.parse::<f64>().is_ok()
                || body.parse::<i64>().is_ok()
                || body.strip_prefix("0x").is_some_and(|d| !d.is_empty())
                || body.strip_prefix("0o").is_some_and(|d| !d.is_empty()))
    };
    let needs_quotes = text.is_empty()
        || text.starts_with(|c: char| "{[*&!|>%@`'\"#-?:,]} \t".contains(c))
        || text.ends_with([' ', ':'])
        || text.contains(": ")
        || text.contains(" #")
        || text.contains('\n')
        || YAML_WORDS.contains(&lower.as_str())
        || numeric();
    if needs_quotes {
        format!("'{}'", text.replace('\'', "''"))
    } else {
        text.to_string()
    }
}

/// The file extension and contents of a rule in `format`.
pub fn render_rule(format: RuleFormat, source_text: &str) -> (&'static str, String) {
    let rule = parse_rule(source_text);
    match format {
        RuleFormat::Markdown => ("md", source_text.to_string()),
        RuleFormat::CursorMdc => {
            let mut s = String::from("---\n");
            if let Some(d) = &rule.description {
                s.push_str(&format!("description: {}\n", yaml_scalar(d)));
            }
            if rule.paths.is_empty() {
                s.push_str("alwaysApply: true\n");
            } else {
                s.push_str(&format!(
                    "globs: {}\nalwaysApply: false\n",
                    yaml_scalar(&rule.paths.join(", "))
                ));
            }
            s.push_str("---\n\n");
            s.push_str(&rule.body);
            ("mdc", s)
        }
        RuleFormat::KiroSteering => {
            let mut s = String::from("---\n");
            match rule.paths.as_slice() {
                [] => s.push_str("inclusion: always\n"),
                [one] => s.push_str(&format!(
                    "inclusion: fileMatch\nfileMatchPattern: {}\n",
                    yaml_scalar(one)
                )),
                many => s.push_str(&format!(
                    "inclusion: fileMatch\nfileMatchPattern: {}\n",
                    yaml_scalar(&format!("{{{}}}", many.join(",")))
                )),
            }
            s.push_str("---\n\n");
            s.push_str(&rule.body);
            ("md", s)
        }
    }
}

// --- subagents ------------------------------------------------------------------------

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SubagentDef {
    pub name: String,
    pub description: String,
    pub instructions: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub model: Option<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub tools: Vec<String>,
}

/// The file extension and contents of a subagent in `format`.
pub fn render_agent(format: AgentFormat, def: &SubagentDef) -> Result<(&'static str, String)> {
    if def.name.is_empty()
        || !def
            .name
            .bytes()
            .all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_')
    {
        return Err(Error::usage(
            "AGENT-NAME",
            format!(
                "subagent name {:?} must be letters, digits, '-' and '_'",
                def.name
            ),
        ));
    }
    let body = format!("{}\n", def.instructions.trim_end());
    let front = |pairs: Vec<(&str, String)>| {
        let mut s = String::from("---\n");
        for (k, v) in pairs {
            s.push_str(&format!("{k}: {}\n", yaml_scalar(&v)));
        }
        s.push_str("---\n\n");
        s
    };
    Ok(match format {
        AgentFormat::ClaudeMarkdown => {
            let mut pairs = vec![
                ("name", def.name.clone()),
                ("description", def.description.clone()),
            ];
            if let Some(m) = &def.model {
                pairs.push(("model", m.clone()));
            }
            if !def.tools.is_empty() {
                pairs.push(("tools", def.tools.join(", ")));
            }
            ("md", front(pairs) + &body)
        }
        AgentFormat::CursorMarkdown => {
            let mut pairs = vec![
                ("agent_id", def.name.clone()),
                ("description", def.description.clone()),
            ];
            if !def.tools.is_empty() {
                pairs.push(("tools", def.tools.join(", ")));
            }
            ("md", front(pairs) + &body)
        }
        AgentFormat::CodexToml => {
            // A Codex role file refuses a key it does not define, and it defines none for a
            // tool allowlist. Writing the definition without one would hand Codex the whole
            // tool set under a name the team restricted.
            if !def.tools.is_empty() {
                return Err(Error::unsupported(
                    "AGENT-TOOLS",
                    format!(
                        "subagent {:?} restricts tools to {}, which a Codex role file cannot \
                         express; drop the restriction or do not deploy it to Codex",
                        def.name,
                        def.tools.join(", ")
                    ),
                ));
            }
            let mut doc = toml_edit::DocumentMut::new();
            doc["name"] = toml_edit::value(def.name.as_str());
            doc["description"] = toml_edit::value(def.description.as_str());
            doc["developer_instructions"] = toml_edit::value(def.instructions.trim_end());
            if let Some(m) = &def.model {
                doc["model"] = toml_edit::value(m.as_str());
            }
            ("toml", doc.to_string())
        }
        AgentFormat::KiroJson => {
            let mut obj = serde_json::Map::new();
            obj.insert("name".into(), def.name.clone().into());
            obj.insert("description".into(), def.description.clone().into());
            obj.insert("prompt".into(), def.instructions.trim_end().into());
            if let Some(m) = &def.model {
                obj.insert("model".into(), m.clone().into());
            }
            if !def.tools.is_empty() {
                obj.insert("tools".into(), def.tools.clone().into());
            }
            ("json", json_doc::render(&Value::Object(obj)))
        }
    })
}

// --- environment ------------------------------------------------------------------------

/// Where one environment key lives in `format`.
pub fn env_keys(format: EnvFormat, key: &str) -> (Document, Vec<String>) {
    match format {
        EnvFormat::ClaudeSettings => (Document::Json, vec!["env".into(), key.into()]),
        EnvFormat::CodexToml => (
            Document::Toml,
            vec!["shell_environment_policy".into(), "set".into(), key.into()],
        ),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn argv(words: &[&str]) -> Vec<String> {
        words.iter().map(|w| w.to_string()).collect()
    }

    #[test]
    fn events_parse_from_every_spelling_agents_use() {
        for (text, event) in [
            ("SessionStart", HookEvent::SessionStart),
            ("sessionStart", HookEvent::SessionStart),
            ("session-start", HookEvent::SessionStart),
            ("session_start", HookEvent::SessionStart),
            ("post-tool-use", HookEvent::PostToolUse),
            ("postToolUse", HookEvent::PostToolUse),
            ("beforeSubmitPrompt", HookEvent::UserPromptSubmit),
            ("prompt-submit", HookEvent::UserPromptSubmit),
            ("UserPromptSubmit", HookEvent::UserPromptSubmit),
            ("stop", HookEvent::Stop),
            ("SessionEnd", HookEvent::SessionEnd),
            ("PreToolUse", HookEvent::PreToolUse),
        ] {
            assert_eq!(HookEvent::parse(text), Some(event), "{text}");
        }
        assert_eq!(HookEvent::parse("fileEdited"), None);
        for e in HookEvent::ALL {
            assert_eq!(HookEvent::parse(e.as_str()), Some(e));
        }
    }

    #[test]
    fn shell_words_round_trip_every_argv_we_render() {
        for words in [
            argv(&[
                "/home/a/.local/bin/wf",
                "hook",
                "session-start",
                "--agent",
                "claude",
            ]),
            argv(&[
                "/home/a person's/bin/wf",
                "hook",
                "dispatch",
                "--event",
                "PostToolUse",
            ]),
            argv(&["wf", "", "a b", "it's", "$(nope)", "`x`"]),
        ] {
            let command = words
                .iter()
                .map(|w| shell_word(w))
                .collect::<Vec<_>>()
                .join(" ");
            assert_eq!(shell_words(&command), Some(words.clone()), "{command}");
        }
        assert_eq!(shell_word("plain/path-1.2_x:y"), "plain/path-1.2_x:y");
        assert_eq!(shell_word("a b"), "'a b'");
        assert_eq!(
            shell_words("echo \"double\""),
            None,
            "double quotes are not ours"
        );
        assert_eq!(shell_words("a && b"), None);
        assert_eq!(shell_words("'unterminated"), None);
    }

    #[test]
    fn only_wf_hook_commands_carry_a_marker() {
        assert_eq!(
            marker_for_argv(&argv(&[
                "/x/bin/wf",
                "hook",
                "session-start",
                "--agent",
                "codex"
            ])),
            Some(MARKER_BOOTSTRAP)
        );
        assert_eq!(
            marker_for_argv(&argv(&[
                "wf", "hook", "dispatch", "--event", "Stop", "--agent", "codex"
            ])),
            Some(MARKER_USAGE)
        );
        assert_eq!(
            marker_for_argv(&argv(&["/x/bin/notwf", "hook", "dispatch"])),
            None
        );
        assert_eq!(marker_for_argv(&argv(&["wf", "sync"])), None);
        assert_eq!(marker_for_argv(&argv(&["echo", "wf", "hook"])), None);
        assert_eq!(marker_for_argv(&[]), None);
    }

    #[test]
    fn identity_comes_from_the_status_marker_or_else_the_argv() {
        let ours = argv(&["/x/wf", "hook", "dispatch", "--event", "Stop"]);
        assert_eq!(
            owned_identity(HookEvent::Stop, Some(&ours), None).as_deref(),
            Some("Stop/capso-wf-usage")
        );
        assert_eq!(
            owned_identity(HookEvent::SessionStart, None, Some(MARKER_BOOTSTRAP)).as_deref(),
            Some("SessionStart/capso-wf-bootstrap")
        );
        assert_eq!(
            owned_identity(HookEvent::Stop, Some(&argv(&["echo", "hi"])), None),
            None
        );
        assert_eq!(
            owned_identity(HookEvent::Stop, None, Some("something else")),
            None
        );
    }

    #[test]
    fn a_hook_entry_names_itself_by_event_and_marker() {
        let entry = HookEntry {
            event: HookEvent::PostToolUse,
            matcher: None,
            argv: argv(&[
                "/opt/my tools/wf",
                "hook",
                "dispatch",
                "--event",
                "PostToolUse",
                "--agent",
                "claude",
            ]),
            timeout_secs: Some(10),
        };
        assert_eq!(entry.marker(), MARKER_USAGE);
        assert_eq!(entry.identity(), "PostToolUse/capso-wf-usage");
        assert_eq!(
            entry.command(),
            "'/opt/my tools/wf' hook dispatch --event PostToolUse --agent claude"
        );
    }

    fn linear() -> McpDef {
        McpDef::parse(
            "schema_version: 1\nname: capso-linear\ntransport: stdio\ncommand: npx\nargs: [\"-y\", \"mcp-remote\", \"https://mcp.linear.app/sse\"]\nenv_references: [LINEAR_API_TOKEN]\n",
            Path::new("workflow/mcps/linear.yaml"),
        )
        .unwrap()
    }

    #[test]
    fn the_shipped_mcp_definitions_parse_and_validate() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../workflow/mcps");
        for entry in std::fs::read_dir(root).unwrap() {
            let path = entry.unwrap().path();
            let def = McpDef::parse(&std::fs::read_to_string(&path).unwrap(), &path).unwrap();
            def.validate().unwrap();
        }
    }

    /// The two `mcp-remote` bridges launch through `npx` and a remote sign-in, which is
    /// seconds on a good day and past half a minute on a slow one (txe-workflow#50); the
    /// local history server is a binary on this machine and keeps the agent's default. The
    /// limit is the registry's, and the definition files stay readable by the previous release.
    #[test]
    fn every_shipped_bridge_carries_its_own_startup_limit() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
        let registry = wf_registry::Registry::load(&root).unwrap();
        let limit = |id: &str| {
            registry
                .components
                .iter()
                .find(|c| c.id == id)
                .unwrap()
                .startup_timeout_sec
        };
        assert_eq!(limit("capso.mcp.linear"), Some(120));
        assert_eq!(limit("capso.mcp.rackspace-spot"), Some(120));
        assert_eq!(limit("capso.mcp.history"), None);
        for file in ["linear.yaml", "rackspace-spot.yaml", "history.yaml"] {
            assert_eq!(serialized(Path::new(file)).startup_timeout_sec, None);
        }
    }

    #[test]
    fn a_startup_limit_in_a_definition_file_is_refused() {
        let yaml = "name: x\ncommand: npx\nstartup_timeout_sec: 120\n";
        let err = McpDef::parse(yaml, Path::new("x.yaml")).unwrap_err();
        assert!(err.message.contains("registry.yaml"), "{}", err.message);
    }

    #[test]
    fn a_definition_reaches_the_hosts_in_its_url_and_its_arguments() {
        assert_eq!(linear().hosts(), ["mcp.linear.app"]);
        let http = McpDef {
            transport: McpTransport::Http,
            command: None,
            args: vec![],
            url: Some("https://API.example.com:8443/mcp".into()),
            ..linear()
        };
        assert_eq!(http.hosts(), ["api.example.com"]);
        assert_eq!(url_host("https://${HOST}/mcp"), None);
        assert_eq!(url_host("file:///etc/passwd"), None);
    }

    /// A raw entry is whatever the document holds, so this reads the same two places a
    /// definition does — its `url` and its `args` — off a value nobody typed into `wf`.
    #[test]
    fn a_raw_entry_reaches_its_host() {
        let remote = json!({"type": "http", "url": "https://mcp.linear.app/mcp"});
        assert_eq!(entry_hosts(&remote), ["mcp.linear.app"]);

        let bridge =
            json!({"command": "npx", "args": ["-y", "mcp-remote", "https://mcp.linear.app/mcp"]});
        assert_eq!(entry_hosts(&bridge), ["mcp.linear.app"]);

        let with_env = json!({"command": "npx", "args": ["-y", "mcp-remote", "https://x.example.com/mcp"], "env": {"TOKEN": "${LINEAR_API_TOKEN}"}});
        assert_eq!(entry_hosts(&with_env), ["x.example.com"]);
    }

    /// Four shapes that must reach nothing, each for its own reason: no URL at all, a host
    /// nobody can check, a scheme that is not http(s), and a scheme cased as a person writes
    /// it. The last one is a miss, not a match — `url_host` compares prefixes literally.
    #[test]
    fn a_raw_entry_reaches_no_host_when_there_is_none_to_reach() {
        assert!(entry_hosts(&json!({"type": "sse", "url": null})).is_empty());
        assert!(
            entry_hosts(&json!({"command": "npx", "args": ["-y", "@some/linear-mcp"]})).is_empty()
        );
        assert!(entry_hosts(&json!({"url": "https://${HOST}/mcp"})).is_empty());
        assert!(entry_hosts(&json!({"url": "file:///etc/passwd"})).is_empty());
        assert!(entry_hosts(&json!({"url": "HTTPS://mcp.linear.app/mcp"})).is_empty());
        assert!(entry_hosts(&json!({"args": ["-y", "mcp-remote"]})).is_empty());
    }

    fn our_linear() -> McpDef {
        serialized(Path::new("workflow/mcps/linear.yaml"))
    }

    fn serialized(path: &Path) -> McpDef {
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../workflow/mcps");
        let path = root.join(path.file_name().unwrap());
        McpDef::parse(&std::fs::read_to_string(&path).unwrap(), &path).unwrap()
    }

    #[test]
    fn a_document_is_occupied_by_our_host_or_by_our_key() {
        use crate::formats::Occupied::{Host, Key};
        let linear = our_linear();
        let claude = get_mcp_format(McpFormat::ClaudeJson);
        let codex = get_mcp_format(McpFormat::CodexToml);

        // Somebody's own server under their own name, reaching the service we publish.
        let theirs =
            r#"{"mcpServers":{"mine":{"type":"http","url":"https://mcp.linear.app/mcp"}}}"#;
        assert_eq!(
            claude.occupied(theirs, &[&linear]).unwrap(),
            vec![Occupancy {
                component: "capso-linear".into(),
                by: Host
            }]
        );

        // Our key, holding something else entirely: still a collision, because we would
        // write over it.
        let ours = r#"{"mcpServers":{"capso-linear":{"command":"uvx","args":["other"]}}}"#;
        assert_eq!(
            claude.occupied(ours, &[&linear]).unwrap(),
            vec![Occupancy {
                component: "capso-linear".into(),
                by: Key
            }]
        );

        // Neither: somebody else's server, some other service.
        let neither = r#"{"mcpServers":{"personal":{"command":"uvx","args":["-y","x"]}}}"#;
        assert!(claude.occupied(neither, &[&linear]).unwrap().is_empty());
        assert!(claude.occupied("{}", &[&linear]).unwrap().is_empty());

        // The same shape in TOML, so Codex answers the same question the same way.
        let toml = "[mcp_servers.mine]\nurl = \"https://mcp.linear.app/mcp\"\n";
        assert_eq!(
            codex.occupied(toml, &[&linear]).unwrap(),
            vec![Occupancy {
                component: "capso-linear".into(),
                by: Host
            }]
        );
    }

    /// The answer carries our host and our key and nothing else — no other entry's name, no
    /// `env`, no `headers`, no token (WFR-016).
    #[test]
    fn a_document_holding_someone_elses_secret_yields_none_of_it() {
        let linear = our_linear();
        let claude = get_mcp_format(McpFormat::ClaudeJson);
        let document = r#"{"mcpServers":{"their-linear":{"type":"http","url":"https://mcp.linear.app/mcp","headers":{"Authorization":"Bearer sk-live-DO-NOT-PRINT"}},"unrelated":{"command":"npx","args":["-y","thing"],"env":{"SECRET":"hunter2"}}}}"#;
        let answer = claude.occupied(document, &[&linear]).unwrap();
        let printed = serde_json::to_string(&answer).unwrap();
        for forbidden in [
            "their-linear",
            "sk-live-DO-NOT-PRINT",
            "Authorization",
            "hunter2",
            "unrelated",
            "SECRET",
        ] {
            assert!(
                !printed.contains(forbidden),
                "{forbidden:?} left the document: {printed}"
            );
        }
    }

    /// A document nobody can read is an error, not an empty answer: "there is nothing there"
    /// and "nobody could look" must not be the same result.
    #[test]
    fn an_unreadable_document_is_an_error_rather_than_an_empty_answer() {
        let linear = our_linear();
        let claude = get_mcp_format(McpFormat::ClaudeJson);
        let codex = get_mcp_format(McpFormat::CodexToml);
        assert!(claude.occupied("{not json", &[&linear]).is_err());
        assert!(codex.occupied("not = = toml", &[&linear]).is_err());
        // Empty text is a document that says nothing, and says it successfully.
        assert!(claude.occupied("", &[&linear]).unwrap().is_empty());
    }

    /// The server that runs `wf` itself publishes no host, so only its key can be occupied —
    /// and a definition with no host must not be reported as reached by every entry.
    #[test]
    fn a_server_with_no_host_is_only_ever_occupied_by_its_key() {
        use crate::formats::Occupied::Key;
        let history = serialized(Path::new("workflow/mcps/history.yaml"));
        assert!(history.hosts().is_empty());
        let claude = get_mcp_format(McpFormat::ClaudeJson);
        let theirs = r#"{"mcpServers":{"mine":{"url":"https://mcp.linear.app/mcp"}}}"#;
        assert!(claude.occupied(theirs, &[&history]).unwrap().is_empty());
        let named = r#"{"mcpServers":{"wf-history":{"command":"wf"}}}"#;
        assert_eq!(
            claude.occupied(named, &[&history]).unwrap(),
            vec![Occupancy {
                component: "wf-history".into(),
                by: Key
            }]
        );
    }

    #[test]
    fn invalid_definitions_are_refused_by_name() {
        let cases: Vec<(McpDef, &str)> = vec![
            (
                McpDef {
                    name: "has space".into(),
                    ..linear()
                },
                "name",
            ),
            (
                McpDef {
                    command: None,
                    ..linear()
                },
                "command",
            ),
            (
                McpDef {
                    url: Some("https://x".into()),
                    ..linear()
                },
                "url",
            ),
            (
                McpDef {
                    transport: McpTransport::Http,
                    command: None,
                    url: None,
                    ..linear()
                },
                "url",
            ),
            (
                McpDef {
                    env_references: vec!["not-a-name".into()],
                    ..linear()
                },
                "env",
            ),
            (
                McpDef {
                    headers: [(
                        "Authorization".to_string(),
                        "Bearer lin_api_ABCDEFGHIJKLMNOPQRSTUV".to_string(),
                    )]
                    .into(),
                    ..linear()
                },
                "credential",
            ),
            (
                McpDef {
                    schema_version: 2,
                    ..linear()
                },
                "schema",
            ),
            (
                McpDef {
                    startup_timeout_sec: Some(0),
                    ..linear()
                },
                "startup_timeout_sec",
            ),
        ];
        for (def, word) in cases {
            let err = def.validate().unwrap_err();
            assert!(err.message.contains(word), "{word}: {}", err.message);
        }
        assert!(McpDef::parse("name: x\ncolour: blue\n", Path::new("x.yaml")).is_err());
    }

    #[test]
    fn a_rule_splits_into_scope_description_and_body() {
        let rule = parse_rule("---\ndescription: TS style\npaths: [\"src/**/*.ts\", \"test/**/*.ts\"]\n---\n# TS style\nUse strict.\n");
        assert_eq!(rule.description.as_deref(), Some("TS style"));
        assert_eq!(rule.paths, ["src/**/*.ts", "test/**/*.ts"]);
        assert_eq!(rule.body, "# TS style\nUse strict.\n");
        let bare = parse_rule("# Always\n");
        assert_eq!(
            bare,
            RuleSource {
                description: None,
                paths: vec![],
                body: "# Always\n".into()
            }
        );
        // `globs` is accepted as a spelling of `paths`, as a list or a comma-separated string.
        assert_eq!(
            parse_rule("---\nglobs: \"a/**, b/**\"\n---\nx\n").paths,
            ["a/**", "b/**"]
        );
    }

    #[test]
    fn rules_render_per_format() {
        let scoped = "---\ndescription: TS style\npaths: [\"src/**/*.ts\", \"test/**/*.ts\"]\n---\n# TS style\n";
        assert_eq!(
            render_rule(RuleFormat::Markdown, scoped),
            ("md", scoped.to_string())
        );
        assert_eq!(
            render_rule(RuleFormat::CursorMdc, scoped),
            ("mdc", "---\ndescription: TS style\nglobs: src/**/*.ts, test/**/*.ts\nalwaysApply: false\n---\n\n# TS style\n".to_string())
        );
        assert_eq!(
            render_rule(RuleFormat::CursorMdc, "# Everywhere\n"),
            (
                "mdc",
                "---\nalwaysApply: true\n---\n\n# Everywhere\n".to_string()
            )
        );
        assert_eq!(
            render_rule(RuleFormat::KiroSteering, scoped),
            ("md", "---\ninclusion: fileMatch\nfileMatchPattern: '{src/**/*.ts,test/**/*.ts}'\n---\n\n# TS style\n".to_string())
        );
        assert_eq!(
            render_rule(
                RuleFormat::KiroSteering,
                "---\npaths: [\"src/**\"]\n---\nx\n"
            ),
            (
                "md",
                "---\ninclusion: fileMatch\nfileMatchPattern: src/**\n---\n\nx\n".to_string()
            )
        );
        assert_eq!(
            render_rule(RuleFormat::KiroSteering, "x\n"),
            ("md", "---\ninclusion: always\n---\n\nx\n".to_string())
        );
    }

    /// Cursor parses `.mdc` front matter as YAML, so what is written has to read back as
    /// what went in. A glob list is the common case and almost always opens with `*`, which
    /// YAML reads as an alias indicator.
    #[test]
    fn front_matter_survives_a_yaml_parser() {
        let starred = "---\npaths: [\"**/*.env\"]\n---\n# Secrets\n";
        assert_eq!(
            render_rule(RuleFormat::CursorMdc, starred),
            (
                "mdc",
                "---\nglobs: '**/*.env'\nalwaysApply: false\n---\n\n# Secrets\n".to_string()
            )
        );
        // The words and numbers YAML resolves to another type.
        for word in ["no", "yes", "true", "False", "null", "~", "on", "off", "n"] {
            assert_eq!(yaml_scalar(word), format!("'{word}'"), "{word}");
        }
        for number in ["1.0", "007", "-3", "0x1f", ".5", "1e3"] {
            assert_eq!(yaml_scalar(number), format!("'{number}'"), "{number}");
        }
        assert_eq!(yaml_scalar("\tindented"), "'\tindented'");
        // And the plain scalars that are still plain.
        for plain in ["sonnet", "code-reviewer", "Reviews diffs", "gpt-5.1-codex"] {
            assert_eq!(yaml_scalar(plain), plain, "{plain}");
        }
    }

    fn reviewer() -> SubagentDef {
        SubagentDef {
            name: "code-reviewer".into(),
            description: "Reviews diffs: carefully".into(),
            instructions: "You review code.\nBe brief.".into(),
            model: Some("sonnet".into()),
            tools: vec!["Read".into(), "Grep".into()],
        }
    }

    #[test]
    fn subagents_render_per_format() {
        let (ext, text) = render_agent(AgentFormat::ClaudeMarkdown, &reviewer()).unwrap();
        assert_eq!(ext, "md");
        assert_eq!(
            text,
            "---\nname: code-reviewer\ndescription: 'Reviews diffs: carefully'\nmodel: sonnet\ntools: Read, Grep\n---\n\nYou review code.\nBe brief.\n"
        );
        let (ext, text) = render_agent(AgentFormat::CursorMarkdown, &reviewer()).unwrap();
        assert_eq!(ext, "md");
        assert!(text.starts_with("---\nagent_id: code-reviewer\n"), "{text}");
        assert!(
            !text.contains("model"),
            "Cursor subagents take no model: {text}"
        );
        // A Codex role file has no key for a tool allowlist and refuses an unknown one, so
        // a restricted subagent is refused rather than deployed unrestricted.
        assert_eq!(
            render_agent(AgentFormat::CodexToml, &reviewer())
                .unwrap_err()
                .kind,
            "AGENT-TOOLS"
        );
        let mut unrestricted = reviewer();
        unrestricted.tools.clear();
        let (ext, text) = render_agent(AgentFormat::CodexToml, &unrestricted).unwrap();
        assert_eq!(ext, "toml");
        let parsed: toml::Value = toml::from_str(&text).unwrap();
        assert_eq!(parsed["name"].as_str(), Some("code-reviewer"));
        assert_eq!(
            parsed["developer_instructions"].as_str(),
            Some("You review code.\nBe brief.")
        );
        assert_eq!(parsed["model"].as_str(), Some("sonnet"));
        assert!(parsed.get("tools").is_none());
        let (ext, text) = render_agent(AgentFormat::KiroJson, &reviewer()).unwrap();
        assert_eq!(ext, "json");
        let parsed: Value = serde_json::from_str(&text).unwrap();
        assert_eq!(parsed["prompt"], "You review code.\nBe brief.");
        assert_eq!(parsed["tools"], serde_json::json!(["Read", "Grep"]));
    }

    #[test]
    fn environment_keys_land_in_each_formats_own_table() {
        assert_eq!(
            env_keys(EnvFormat::ClaudeSettings, "TEAM"),
            (Document::Json, vec!["env".to_string(), "TEAM".to_string()])
        );
        assert_eq!(
            env_keys(EnvFormat::CodexToml, "TEAM"),
            (
                Document::Toml,
                vec![
                    "shell_environment_policy".to_string(),
                    "set".to_string(),
                    "TEAM".to_string()
                ]
            )
        );
    }
}
