//! Native tool names and version operations. Repository pins select versions; this table
//! only describes how to ask the installed tool and how to install a missing prerequisite.

#[derive(Clone, Copy)]
pub struct Tool {
    pub binaries: &'static [&'static str],
    pub version_args: &'static [&'static str],
    pub darwin: &'static str,
    pub linux: &'static str,
}

pub fn canonical(id: &str) -> &str {
    match id {
        "rustc" => "rust",
        "python3" => "python",
        "bazelisk" => "bazel",
        "golang" => "go",
        "nodejs" => "node",
        _ => id,
    }
}

pub fn tool(id: &str) -> Option<Tool> {
    let (binaries, version_args, darwin, linux): (
        &'static [&'static str],
        &'static [&'static str],
        _,
        _,
    ) = match canonical(id) {
        "go" => (
            &["go"],
            &["version"],
            "brew install go",
            "https://go.dev/dl/",
        ),
        "rust" => (
            &["rustc"],
            &["--version"],
            "https://rustup.rs",
            "https://rustup.rs",
        ),
        "cargo" => (
            &["cargo"],
            &["--version"],
            "rustup component add cargo",
            "rustup component add cargo",
        ),
        "python" => (
            &["python3", "python"],
            &["--version"],
            "brew install python",
            "apt-get install -y python3",
        ),
        "node" => (
            &["node"],
            &["--version"],
            "brew install node",
            "https://nodejs.org/en/download",
        ),
        "npm" => (
            &["npm"],
            &["--version"],
            "brew install node",
            "https://nodejs.org/en/download",
        ),
        "pnpm" => (
            &["pnpm"],
            &["--version"],
            "brew install pnpm",
            "corepack enable pnpm",
        ),
        "yarn" => (
            &["yarn"],
            &["--version"],
            "brew install yarn",
            "corepack enable yarn",
        ),
        "docker" => (
            &["docker"],
            &["--version"],
            "brew install --cask docker",
            "https://docs.docker.com/engine/install/",
        ),
        "bazel" => (
            &["bazel", "bazelisk"],
            &["--version"],
            "brew install bazelisk",
            "https://github.com/bazelbuild/bazelisk",
        ),
        "gh" => (
            &["gh"],
            &["--version"],
            "brew install gh",
            "https://github.com/cli/cli#installation",
        ),
        "kubectl" => (
            &["kubectl"],
            &["version", "--client"],
            "brew install kubectl",
            "https://kubernetes.io/docs/tasks/tools/",
        ),
        "git" => (
            &["git"],
            &["--version"],
            "brew install git",
            "apt-get install -y git",
        ),
        _ => return None,
    };
    Some(Tool {
        binaries,
        version_args,
        darwin,
        linux,
    })
}
