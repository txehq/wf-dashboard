//! `wf magi` — the overseer's commands. Stage 1 only: `measure`.

use super::emit;
use crate::flags::MagiCmd;
use std::path::PathBuf;
use wf_core::{envelope::Envelope, envelope::Note, ExitCode, Result};
use wf_magi::Ledger;

pub fn run(json: bool, cmd: MagiCmd) -> Result<ExitCode> {
    match cmd {
        MagiCmd::Measure { repo, since, limit } => measure(json, &repo, since.as_deref(), limit),
    }
}

/// Where the ledger lands: the local state directory, on the disposable-cache rule (Magi
/// Service S5). It is rebuilt in full every run, so losing it costs nothing but a re-read.
fn ledger_path(repo: &str) -> Result<PathBuf> {
    let paths = wf_core::paths::Paths::resolve()?;
    let dir = paths.state_dir.join("magi");
    std::fs::create_dir_all(&dir)?;
    Ok(dir.join(format!("{}.json", repo.replace('/', "_"))))
}

fn measure(json: bool, repo: &str, since: Option<&str>, limit: u32) -> Result<ExitCode> {
    // Every read below goes to GitHub; the former org name must not (TXE-1927).
    let repo = &wf_core::canonical_repo(repo);
    let root = super::tools::git_root();
    let ledger = wf_magi::gather(&root, repo, since, limit)?;

    let path = ledger_path(repo)?;
    wf_core::atomic::write_file(&path, serde_json::to_vec_pretty(&ledger)?.as_slice())?;

    let reviewed = ledger.rows.iter().filter(|r| !r.passes.is_empty()).count();
    let mut env = Envelope::new("magi measure").result(&ledger);
    if reviewed == 0 {
        env = env.warn(Note::new(
            "NO-PASSES",
            format!(
                "{} merged PR(s) read and none carries an RPR review — nothing to count. \
                 Either the range predates the reviewer or the repository is not reviewed by it.",
                ledger.rows.len()
            ),
        ));
    }
    let text = render(&ledger, &path);
    Ok(emit(json, env, move || text))
}

fn render(l: &Ledger, path: &std::path::Path) -> String {
    let reviewed: Vec<&wf_magi::PrRow> = l.rows.iter().filter(|r| !r.passes.is_empty()).collect();
    let mut s = format!(
        "{}  ·  {} merged PR(s), {} with RPR passes{}\n\n",
        l.repo,
        l.rows.len(),
        reviewed.len(),
        l.since
            .as_deref()
            .map(|d| format!(", merged since {d}"))
            .unwrap_or_default()
    );
    if !l.weeks.is_empty() {
        s.push_str(&format!(
            "  {:<12} {:>4} {:>5} {:>6} {:>6} {:>4} {:>9} {:>8}\n",
            "week", "prs", "revd", "mean", "median", "max", "find/pass", "lines"
        ));
        for w in &l.weeks {
            s.push_str(&format!(
                "  {:<12} {:>4} {:>5} {:>6.1} {:>6.1} {:>4} {:>9.1} {:>8.0}\n",
                w.week,
                w.prs,
                w.reviewed,
                w.mean_rounds,
                w.median_rounds,
                w.max_rounds,
                w.mean_findings_per_pass,
                w.mean_lines_changed
            ));
        }
    }
    if !reviewed.is_empty() {
        let mut rounds: Vec<u32> = reviewed.iter().map(|r| r.fix_rounds).collect();
        rounds.sort_unstable();
        let mean = rounds.iter().map(|&r| r as f64).sum::<f64>() / rounds.len() as f64;
        let median = if rounds.len() % 2 == 1 {
            rounds[rounds.len() / 2] as f64
        } else {
            (rounds[rounds.len() / 2 - 1] + rounds[rounds.len() / 2]) as f64 / 2.0
        };
        s.push_str(&format!(
            "\n  N — fix rounds to ship, over {} reviewed PR(s):  mean {:.1}  median {:.1}  max {}\n",
            rounds.len(),
            mean,
            median,
            rounds.last().copied().unwrap_or(0)
        ));
        let models: std::collections::BTreeSet<String> = reviewed
            .iter()
            .flat_map(|r| r.passes.iter().map(|p| format!("{}/{}", p.model, p.effort)))
            .filter(|m| !m.starts_with('/'))
            .collect();
        s.push_str(&format!(
            "  reviewed by: {}\n",
            models.into_iter().collect::<Vec<_>>().join(", ")
        ));
    }
    s.push_str(&format!(
        "\n  ledger {}\n  rebuilt from GitHub in full — no incremental state\n",
        path.display()
    ));
    s.push_str(
        "\nThis is the count, with its covariates. Attribution and proposals are stages 2 and 3;\n\
         a model change moves this number with no lever touched, so compare within a model.\n",
    );
    s
}
