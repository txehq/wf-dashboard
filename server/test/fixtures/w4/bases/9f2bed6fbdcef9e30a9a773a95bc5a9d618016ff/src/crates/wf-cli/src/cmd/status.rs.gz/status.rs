use super::{emit, options};
use crate::flags::{AgentsCmd, RemoteArgs};
use wf_core::{envelope::Envelope, envelope::Note, ExitCode, Result};
use wf_sync::Engine;

pub fn status(json: bool, remote: &RemoteArgs) -> Result<ExitCode> {
    let mut opts = options(remote)?;
    opts.offline = true; // status reports; sync fetches.
    let engine = Engine::open(opts)?;
    let st = engine.status()?;
    let mut env = Envelope::new("status").result(&st);
    if !st.healthy {
        env = env.error(
            Note::new(
                "UNHEALTHY",
                "one or more required components are not current",
            )
            .with_zh(
                "有组件没有就位。运行 `wf repair` 修复，或者 `wf doctor` 看详细情况。".to_string(),
            ),
        );
    }
    let rendered = st.render_zh();
    Ok(emit(json, env, move || rendered))
}

/// `doctor` is `status` plus everything that would stop a repair from working: the login,
/// the platform, the binary's own location, and the two agents' installations.
pub fn doctor(json: bool, remote: &RemoteArgs, strict: bool) -> Result<ExitCode> {
    let opts = options(remote)?;
    let engine = Engine::open(opts.clone())?;
    let st = engine.status()?;

    let mut findings: Vec<(String, String)> = Vec::new();

    if !wf_core::paths::platform_supported() {
        findings.push((
            "PLATFORM".into(),
            wf_core::zh::unsupported_platform(wf_core::paths::target_triple()),
        ));
    }
    if wf_core::proc::which("git").is_none() {
        findings.push(("GIT".into(), wf_core::zh::git_missing()));
    }
    match wf_core::proc::which("gh") {
        None => findings.push(("GH".into(), wf_core::zh::gh_missing())),
        Some(_) => {
            if let wf_release::source::ReleaseSource::GitHub { repo, .. } = &opts.source {
                if let Err(e) = wf_release::github::Gh::new(repo.clone()).preflight() {
                    findings.push((
                        e.kind.clone(),
                        if e.zh.is_empty() { e.message } else { e.zh },
                    ));
                }
            }
        }
    }

    // The binary must be where every agent's hooks and MCP servers point. A `wf` that only
    // exists in a build directory works from a terminal and never runs at session start.
    let installed = engine.paths.binary();
    if !installed.is_file() {
        findings.push((
            "BINARY-LOCATION".into(),
            format!(
                "{} 还不存在。各个 agent 的钩子和 wf-history MCP 指向的就是这个位置，请把 wf 装到那里（`wf install` 会做这件事）。",
                installed.display()
            ),
        ));
    } else if !engine
        .paths
        .bin_dir_on_path(&std::env::var("PATH").unwrap_or_default())
    {
        // Hooks and MCP servers are written with the absolute path, so agents do not need
        // this. Skills do: they tell a session to run `wf <command>` in its shell.
        let dir = engine.paths.bin_dir.display();
        findings.push((
            "WF-PATH".into(),
            format!(
                "{dir} 不在 PATH 里。技能会让会话在终端里运行 `wf …`，找不到它就会失败。\n    把这行加到 ~/.zshrc（或 ~/.bashrc）末尾，然后新开一个终端：export PATH=\"{dir}:$PATH\""
            ),
        ));
    }

    // The machine record says what wf did to ctx; only ctx can say whether it works now. A
    // daemon that lost its supervision or a semantic index that cannot load its runtime
    // leaves the record converged and every session's history search degraded or broken.
    // Only a ctx whose bytes are the ones the release pinned is asked; any other one is
    // already a `capso.ctx.binary` finding above, and is never run from here.
    if let Some(ctx) = engine.ctx_verified()? {
        findings.extend(ctx_health(&ctx));
    }

    // A bridge whose agent went away keeps the sign-in for its server, and every bridge
    // started after it waits on it without printing the page to open (txe-workflow#61).
    if let Some(bundle) = engine.active_bundle_dir() {
        let defs = wf_agents::bridges::shipped_definitions(&bundle)?;
        for leftover in wf_agents::bridges::ownerless(&defs) {
            let pids = leftover
                .pids
                .iter()
                .map(u32::to_string)
                .collect::<Vec<_>>()
                .join(" ");
            findings.push((
                "MCP-ORPHAN".into(),
                format!(
                    "{} 的 mcp-remote 还在运行，但已经没有 agent 在用它（进程 {pids}）。它占着 {} 的登录，之后启动的 bridge 都会等它，不会打印授权链接。\n    运行 `kill {pids}` 结束它，然后再登录。",
                    leftover.server, leftover.url
                ),
            ));
        }
    }

    for a in &st.agents {
        if !a.installed {
            findings.push((
                format!("{}-ABSENT", a.agent.to_uppercase()),
                format!(
                    "{} 没有安装在这台机器上，和它相关的部分都跳过了。不再用它的话运行 `wf agents unregister {}`。",
                    a.display_name, a.agent
                ),
            ));
        }
    }
    for c in &st.components {
        // A row restored from the state database carries no rendered sentence of its own, so
        // the state word stands in. A worse sentence than a finding's own, and a better one
        // than dropping a recorded fault from the report that exists to name it.
        if !wf_state::ComponentState::parse(&c.state).is_healthy() {
            let zh = if c.zh.is_empty() {
                wf_core::zh::state_word(&c.state)
            } else {
                c.zh.clone()
            };
            findings.push((c.id.clone(), zh));
        }
    }
    for w in &st.warnings {
        findings.push(("NOTE".into(), w.clone()));
    }

    let mut env = Envelope::new("doctor").result(serde_json::json!({
        "status": st,
        "findings": findings.iter().map(|(k, v)| serde_json::json!({"code": k, "zh": v})).collect::<Vec<_>>(),
    }));
    let blocking = !st.healthy;
    if blocking || (strict && !findings.is_empty()) {
        env = env.error(Note::new("DOCTOR", "findings").with_zh(String::new()));
    }

    let f = findings.clone();
    // `unverified` is healthy, so it never becomes a finding — which means "nothing was found"
    // would otherwise print directly under the list of components nobody looked at and read as
    // a verdict on it. This line says only that nothing *else* was wrong.
    let unobserved = st
        .components
        .iter()
        .any(|c| wf_state::ComponentState::parse(&c.state) == wf_state::ComponentState::Unverified);
    let rendered = st.render_zh();
    Ok(emit(json, env, move || {
        let mut s = rendered;
        if f.is_empty() {
            if unobserved {
                s.push_str(
                    "\n没有发现问题。上面那几项是装好了的，只是登录状态得你自己确认一次——发一次真实的只读调用。\n",
                );
            } else {
                s.push_str("\n没有发现问题。\n");
            }
        } else {
            s.push_str("\n检查结果：\n");
            for (code, zh) in &f {
                s.push_str(&format!("  [{code}] {zh}\n"));
            }
        }
        s
    }))
}

/// ctx's own verdict on itself: `ctx doctor` for the daemon, `ctx semantic status` for
/// semantic search, which `ctx doctor` does not always fail on.
fn ctx_health(ctx: &std::path::Path) -> Vec<(String, String)> {
    // Side by side, so a ctx that hangs costs `wf doctor` one deadline, never two.
    let (doctor, semantic) = std::thread::scope(|s| {
        let doctor = s.spawn(|| ctx_json(ctx, &["doctor", "--format", "json"]));
        let semantic = s.spawn(|| ctx_json(ctx, &["semantic", "status", "--format", "json"]));
        (
            doctor.join().expect("the ctx doctor probe panicked"),
            semantic.join().expect("the ctx semantic probe panicked"),
        )
    });
    ctx_findings(&doctor, &semantic)
}

/// The fields of `ctx doctor --format json` this verdict stands on (upstream
/// `docs/json-contracts.md`). Every one is required: an answer without them proves nothing.
#[derive(serde::Deserialize)]
struct DoctorReport {
    ok: bool,
    findings: Vec<serde_json::Value>,
    daemon: DaemonReport,
}

#[derive(serde::Deserialize)]
struct DaemonReport {
    enabled: bool,
    status: String,
    /// Absent when there is no heartbeat to judge, as after the daemon was killed.
    #[serde(default)]
    heartbeat_stale: Option<bool>,
}

/// The fields of `ctx semantic status --format json` this verdict stands on.
#[derive(serde::Deserialize)]
struct SemanticReport {
    status: String,
    #[serde(default)]
    reason: Option<String>,
    /// The last embedding run, which keeps a failure while the top level cycles between
    /// `failed` and `pending` on ctx's retries.
    #[serde(default)]
    catch_up: Option<CatchUp>,
}

#[derive(serde::Deserialize)]
struct CatchUp {
    #[serde(default)]
    status: Option<String>,
    #[serde(default)]
    reason: Option<String>,
    #[serde(default)]
    last_error: Option<String>,
}

/// What the two probes' answers amount to. A probe that gave no answer, or an answer
/// without the fields the verdict stands on, is a finding of its own: a verdict nobody
/// obtained is never read as a healthy one.
fn ctx_findings(
    doctor: &std::result::Result<serde_json::Value, String>,
    semantic: &std::result::Result<serde_json::Value, String>,
) -> Vec<(String, String)> {
    let unanswered = |command: &str, why: &str| {
        (
            "CTX-HEALTH".to_string(),
            format!(
                "`wf history {command} --format json` 没有给出能读懂的结果，本机历史检索可能用不了。运行 `wf install` 重新设置 ctx。\n    （技术细节：{why}）"
            ),
        )
    };
    fn read<T: serde::de::DeserializeOwned>(
        answer: &std::result::Result<serde_json::Value, String>,
    ) -> std::result::Result<T, String> {
        let value = answer.as_ref().map_err(String::clone)?;
        serde_json::from_value(value.clone()).map_err(|e| format!("{e}: {value}"))
    }

    let mut out = Vec::new();
    let doctor = match read::<DoctorReport>(doctor) {
        Ok(report) => Some(report),
        Err(why) => {
            out.push(unanswered("doctor", &why));
            None
        }
    };
    let said = doctor
        .as_ref()
        .map(|d| {
            d.findings
                .iter()
                .map(|v| v.as_str().map_or_else(|| v.to_string(), str::to_string))
                .collect::<Vec<_>>()
                .join("; ")
        })
        .unwrap_or_default();
    // wf sets indexing to automatic (`ctx index mode auto`), so a disabled daemon is as far
    // from what this release installs as one that stopped: new sessions go unindexed.
    let daemon_down = doctor.as_ref().is_some_and(|d| {
        !d.daemon.enabled || d.daemon.status != "running" || d.daemon.heartbeat_stale == Some(true)
    });
    if let Some(d) = &doctor {
        if daemon_down {
            out.push((
                "CTX-DAEMON".into(),
                format!(
                    "ctx 的后台索引没有在正常运行，检索可能会报 `start or recover daemon`，也看不到新的会话。运行 `wf history index mode auto` 修复它的后台进程，再运行 `wf doctor` 确认。\n    （技术细节：daemon {}；{said}）",
                    d.daemon.status
                ),
            ));
        }
    }

    match read::<SemanticReport>(semantic) {
        Err(why) => out.push(unanswered("semantic status", &why)),
        Ok(s) => {
            let catch_up = s.catch_up.as_ref();
            // This release turns semantic search on, so `disabled` is as short of it as
            // `failed`; `ready` and `pending` are the two states of a working index.
            let failed = matches!(s.status.as_str(), "failed" | "disabled")
                || catch_up.and_then(|c| c.status.as_deref()) == Some("failed");
            if !failed && !matches!(s.status.as_str(), "ready" | "pending") {
                out.push(unanswered(
                    "semantic status",
                    &format!("unexpected status {:?}", s.status),
                ));
            }
            if failed {
                let reason = catch_up
                    .and_then(|c| c.reason.clone())
                    .or(s.reason.clone())
                    .unwrap_or_else(|| s.status.clone());
                let error = catch_up
                    .and_then(|c| c.last_error.clone())
                    .unwrap_or_default();
                out.push((
                    "CTX-SEMANTIC".into(),
                    format!(
                        "语义检索没有启用，现在只按关键词检索。运行 `wf install`：它会装上这个版本锁定的 ONNX Runtime，再重新打开语义检索。\n    （技术细节：{reason}：{error}）"
                    ),
                ));
            }
        }
    }

    // ctx's own "not ok" is shown unless the daemon finding above is what it reports; a
    // semantic finding answers a different command and explains nothing about this one. A
    // running daemon in the middle of its periodic refresh also answers "not ok", with every
    // finding of the form "<what> is pending (<code>)" — `core_refresh_pending`,
    // `generation_not_acknowledged` — while search works. That is ctx working, the same way
    // `pending` is a working semantic index above, and it clears when the refresh lands.
    if let Some(d) = &doctor {
        let refreshing = |f: &serde_json::Value| {
            f.as_str()
                .and_then(|s| s.strip_suffix(')'))
                .and_then(|s| s.rsplit_once(" is pending ("))
                .is_some_and(|(what, code)| {
                    !what.is_empty()
                        && !what.contains(';')
                        && matches!(code, "core_refresh_pending" | "generation_not_acknowledged")
                })
        };
        let lasting = d.findings.iter().any(|f| !refreshing(f));
        if !d.ok && !daemon_down && (d.findings.is_empty() || lasting) {
            out.push(unanswered("doctor", &format!("ok: false; {said}")));
        }
    }
    out
}

/// Run one read-only ctx command and read its JSON. Bounded, because `wf doctor` is what a
/// person runs when something is already wrong, and a hung ctx must not hang it too.
fn ctx_json(
    ctx: &std::path::Path,
    args: &[&str],
) -> std::result::Result<serde_json::Value, String> {
    let out = wf_core::proc::run_with_env(
        &ctx.to_string_lossy(),
        args,
        &[("NO_COLOR", "1")],
        // Both answer in under 0.1 s on a healthy machine.
        std::time::Duration::from_secs(10),
    )
    .map_err(|e| e.message)?;
    serde_json::from_str(out.stdout.trim())
        .map_err(|e| format!("ctx {}: {e}; stderr: {}", args.join(" "), out.stderr.trim()))
}

pub fn agents(json: bool, cmd: AgentsCmd) -> Result<ExitCode> {
    match cmd {
        AgentsCmd::List => {
            let rows = super::install::agent_rows(false)?;
            let env = Envelope::new("agents list").result(&rows);
            Ok(emit(json, env, move || {
                let mut s = String::new();
                for r in &rows {
                    s.push_str(&format!(
                        "{:<12} {:<14} {:<6} {}\n",
                        r.id,
                        r.display_name,
                        if r.installed {
                            "已安装"
                        } else {
                            "未安装"
                        },
                        match r.managed {
                            Some(true) => "由 wf 管理",
                            Some(false) => "已停用",
                            None => "",
                        }
                    ));
                }
                s
            }))
        }
        AgentsCmd::Detect => {
            let rows = super::install::agent_rows(true)?;
            let env = Envelope::new("agents detect").result(&rows);
            Ok(emit(json, env, move || {
                let mut s = String::new();
                for r in rows.iter().filter(|r| r.installed) {
                    s.push_str(&format!(
                        "{:<12} {:<10} {}\n",
                        r.id,
                        if r.version.is_empty() {
                            "?"
                        } else {
                            &r.version
                        },
                        r.config_root
                    ));
                }
                if s.is_empty() {
                    s.push_str("这台机器上没有找到 wf 认识的 coding agent。\n");
                }
                s
            }))
        }
        AgentsCmd::Status { remote, agent } => {
            let mut opts = options(&remote)?;
            opts.offline = true;
            opts.agents = agent;
            let engine = Engine::open(opts)?;
            let st = engine.status()?;
            let env = Envelope::new("agents status").result(&st.agents);
            let rows = st.agents.clone();
            Ok(emit(json, env, move || {
                let mut s = String::new();
                for a in &rows {
                    s.push_str(&format!(
                        "{:<12} {}\n",
                        a.agent,
                        if !a.installed {
                            "未安装".to_string()
                        } else {
                            format!("{}/{} 项已就位", a.current, a.total)
                        }
                    ));
                }
                s
            }))
        }
        AgentsCmd::Register { id, dry_run } => super::install::register(json, &id, dry_run),
        AgentsCmd::Unregister { id, dry_run } => super::install::unregister(json, &id, dry_run),
    }
}

#[cfg(test)]
mod tests {
    use super::ctx_findings;
    use serde_json::json;

    // The shapes ctx 1.4.11 answered with on a real machine, trimmed to the fields read.
    fn healthy_doctor() -> serde_json::Value {
        json!({"ok": true, "findings": [], "daemon": {"enabled": true, "status": "running", "heartbeat_stale": false}})
    }
    fn healthy_semantic() -> serde_json::Value {
        json!({"status": "ready", "catch_up": {"status": "ready"}})
    }
    fn codes(found: &[(String, String)]) -> Vec<&str> {
        found.iter().map(|(code, _)| code.as_str()).collect()
    }

    #[test]
    fn two_healthy_answers_are_no_finding() {
        assert!(ctx_findings(&Ok(healthy_doctor()), &Ok(healthy_semantic())).is_empty());
    }

    /// A semantic verdict that never came back is not a healthy one.
    #[test]
    fn a_probe_without_an_answer_is_a_finding_of_its_own() {
        let found = ctx_findings(
            &Ok(healthy_doctor()),
            &Err("ctx semantic status: EOF while parsing a value at line 1 column 0".into()),
        );
        assert_eq!(codes(&found), ["CTX-HEALTH"]);
        assert!(found[0].1.contains("semantic status"), "{found:?}");

        let found = ctx_findings(
            &Err("did not finish within 10s".into()),
            &Ok(healthy_semantic()),
        );
        assert_eq!(codes(&found), ["CTX-HEALTH"]);
        assert!(found[0].1.contains("history doctor"), "{found:?}");
    }

    /// The runtime missing, read while ctx's retry shows `pending` at the top level: the last
    /// embedding run keeps the failure.
    #[test]
    fn a_failed_embedding_run_is_reported_while_the_top_level_says_pending() {
        let semantic = json!({
            "status": "pending",
            "reason": "generation_not_acknowledged",
            "catch_up": {
                "status": "failed",
                "reason": "model_load_failed",
                "last_error": "no ONNX Runtime dynamic library candidates were found for linux-x64"
            }
        });
        let found = ctx_findings(&Ok(healthy_doctor()), &Ok(semantic));
        assert_eq!(codes(&found), ["CTX-SEMANTIC"]);
        assert!(found[0].1.contains("model_load_failed"), "{found:?}");
    }

    /// Well-formed JSON that lacks what the verdict stands on is no verdict.
    #[test]
    fn an_answer_without_the_fields_the_verdict_needs_is_a_finding() {
        for doctor in [
            json!({}),
            json!(null),
            json!({"ok": true, "findings": [], "daemon": {}}),
            json!({"ok": true, "daemon": {"enabled": true, "status": "running"}}),
        ] {
            let found = ctx_findings(&Ok(doctor.clone()), &Ok(healthy_semantic()));
            assert_eq!(codes(&found), ["CTX-HEALTH"], "{doctor}");
        }
        for semantic in [json!({}), json!(null), json!({"status": "rebuilding"})] {
            let found = ctx_findings(&Ok(healthy_doctor()), &Ok(semantic.clone()));
            assert_eq!(codes(&found), ["CTX-HEALTH"], "{semantic}");
        }
    }

    /// ctx saying it is not ok, with nothing above explaining why, is reported as it is.
    #[test]
    fn a_not_ok_doctor_with_no_other_finding_is_reported() {
        let doctor = json!({"ok": false, "findings": ["daemon is running (heartbeat_stale)"], "daemon": {"enabled": true, "status": "running", "heartbeat_stale": false}});
        let found = ctx_findings(&Ok(doctor), &Ok(healthy_semantic()));
        assert_eq!(codes(&found), ["CTX-HEALTH"]);
        assert!(found[0].1.contains("heartbeat_stale"), "{found:?}");
    }

    /// The two answers ctx 1.6.3 gave a minute apart on a machine whose daemon was running a
    /// periodic refresh, while search returned hits: pending, not broken.
    #[test]
    fn a_refresh_in_progress_is_no_finding() {
        for pending in [
            "refresh is pending (core_refresh_pending)",
            "semantic is pending (generation_not_acknowledged)",
        ] {
            let doctor = json!({"ok": false, "findings": [pending], "daemon": {"enabled": true, "status": "running", "heartbeat_stale": false}});
            let found = ctx_findings(&Ok(doctor), &Ok(healthy_semantic()));
            assert!(found.is_empty(), "{pending}: {found:?}");
        }
    }

    /// A pending refresh beside anything else does not hide the anything else, and a "not ok"
    /// that names nothing is still reported.
    #[test]
    fn a_pending_refresh_does_not_hide_a_real_finding() {
        let doctor = json!({"ok": false, "findings": ["refresh is pending (core_refresh_pending)", "index generation is corrupt"], "daemon": {"enabled": true, "status": "running", "heartbeat_stale": false}});
        let found = ctx_findings(&Ok(doctor), &Ok(healthy_semantic()));
        assert_eq!(codes(&found), ["CTX-HEALTH"]);
        assert!(
            found[0].1.contains("index generation is corrupt"),
            "{found:?}"
        );

        let silent = json!({"ok": false, "findings": [], "daemon": {"enabled": true, "status": "running", "heartbeat_stale": false}});
        assert_eq!(
            codes(&ctx_findings(&Ok(silent), &Ok(healthy_semantic()))),
            ["CTX-HEALTH"]
        );
    }

    /// Only the two refresh codes read as working: another "pending" code, or a refresh code
    /// with something else in the same finding, is still reported.
    #[test]
    fn only_the_refresh_codes_read_as_pending() {
        for finding in [
            "repair is pending (database_corrupt)",
            "refresh is pending (core_refresh_pending); index generation is corrupt",
            "is pending (core_refresh_pending)",
            "refresh is pending (core_refresh_pending) since yesterday",
        ] {
            let doctor = json!({"ok": false, "findings": [finding], "daemon": {"enabled": true, "status": "running", "heartbeat_stale": false}});
            assert_eq!(
                codes(&ctx_findings(&Ok(doctor), &Ok(healthy_semantic()))),
                ["CTX-HEALTH"],
                "{finding}"
            );
        }
    }

    /// This release turns semantic search on; disabled is as short of it as failed.
    #[test]
    fn disabled_semantic_search_is_reported() {
        let found = ctx_findings(
            &Ok(healthy_doctor()),
            &Ok(json!({"status": "disabled", "reason": "semantic_disabled"})),
        );
        assert_eq!(codes(&found), ["CTX-SEMANTIC"]);
    }

    /// A semantic failure does not account for `ctx doctor` saying it is not ok: both stay
    /// visible.
    #[test]
    fn a_doctor_failure_beside_a_semantic_failure_is_still_reported() {
        let doctor = json!({"ok": false, "findings": ["index generation is corrupt"], "daemon": {"enabled": true, "status": "running", "heartbeat_stale": false}});
        let found = ctx_findings(
            &Ok(doctor),
            &Ok(json!({"status": "failed", "reason": "model_load_failed"})),
        );
        assert_eq!(codes(&found), ["CTX-SEMANTIC", "CTX-HEALTH"]);
        assert!(
            found[1].1.contains("index generation is corrupt"),
            "{found:?}"
        );
    }

    /// A daemon killed under its supervisor reads `unverified` with no stale flag at all.
    #[test]
    fn a_daemon_that_is_enabled_and_not_running_is_reported() {
        let doctor = json!({"ok": true, "findings": [], "daemon": {"enabled": true, "status": "unverified"}});
        let found = ctx_findings(&Ok(doctor), &Ok(healthy_semantic()));
        assert_eq!(codes(&found), ["CTX-DAEMON"]);
    }

    /// wf turns automatic indexing on; a daemon somebody disabled leaves new sessions
    /// unindexed, and `ok: true` from ctx does not make that healthy.
    #[test]
    fn a_disabled_daemon_is_reported() {
        let disabled =
            json!({"ok": true, "findings": [], "daemon": {"enabled": false, "status": "disabled"}});
        let found = ctx_findings(&Ok(disabled), &Ok(healthy_semantic()));
        assert_eq!(codes(&found), ["CTX-DAEMON"]);
        assert!(found[0].1.contains("index mode auto"), "{found:?}");
    }
}
