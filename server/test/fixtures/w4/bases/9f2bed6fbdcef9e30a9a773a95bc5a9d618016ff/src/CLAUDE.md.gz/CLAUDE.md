---
last-verified: 2026-09-16
---

# CLAUDE.md — session shim

This repository is the **Magi engineering workflow**: skill definitions, the contract they
answer to, `wf` — the Rust binary that installs and maintains them on every machine — and
the guard that keeps all three honest.

**Read [`docs/INDEX.md`](docs/INDEX.md) first.** It is the only router. Pick your document
by its read-trigger, not by guessing at folder names.

## Harness facts for a session in this repo

- Skills here reach a session as **copies** `wf` put into each agent's skills directory from a
  verified release — there is no plugin and no symlink. Editing a file under `skills/` changes
  nothing in a session until a release built from it is installed — see
  [`docs/operations/local-development.md`](docs/operations/local-development.md).
- `skills/` is the only copy of a skill in this repository. Which agents `wf` manages and how
  it writes into each is `workflow/teamai/`; the code is `crates/wf-agents`.
- There is one version, in `[workspace.package].version`. The binary, the bundle and the lock
  read it, and `wf guard --base-ref <ref>` fails a release-surface change that leaves it alone.
- `wf` is the CLI in this repository; `/lfg` is the workflow's architect entry point, a skill
  it installs. They shared a name until 1.1.0. The install-manager skill that used to live at
  `skills/lfg/` is `skills/install-manager/`; `skills/lfg/` is now the entry point itself, and
  `crates/lfg-*` is now `crates/wf-*`.
- There is no Go and no shell here any more. `cargo run -p wf-cli -- <command>` is the
  in-checkout spelling of everything a skill invokes as `wf <command>`.
- `docs/contract/rules.yaml` is the machine registry; `docs/contract/CONTRACT.md` is its
  prose home. A rule lives in exactly one of those homes and is pointed at from everywhere
  else.
- Generated surfaces are listed in `docs/index.yaml` with `surface: generated`. Do not edit
  them — run `wf guard --fix` (or `cargo run -p wf-cli -- guard --fix` in a checkout).
  CI fails a hand-edit.
- Design authority for any skill is its node in the Obsidian corpus
  (`Project Magi/Workflow/Specs/`). This repo records and implements; it does not fork the spec.

This file states no rule of its own. If you find one here, it is drift — move it to the
contract and leave a pointer.
