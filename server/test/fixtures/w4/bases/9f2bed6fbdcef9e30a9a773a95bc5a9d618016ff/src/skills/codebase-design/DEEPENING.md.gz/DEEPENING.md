# Deepening

How to deepen a cluster of shallow modules safely, given its dependencies. Uses the vocabulary in
[SKILL.md](SKILL.md): **module**, **interface**, **seam**, **adapter**.

## Dependency categories

When assessing a candidate for deepening, classify its dependencies. The category decides how
the deepened module is tested across its seam. Every category is tested against the real thing
or its real local instance.

### 1. In-process

Pure computation, in-memory state, no I/O. Always deepenable: merge the modules and test through
the new interface directly. No adapter needed.

### 2. Local-substitutable

Dependencies with a local instance the test suite can run — PGLite or a container for Postgres,
a temporary directory for a filesystem. Deepenable when that instance exists: the deepened module
is tested with it running in the suite. The seam is internal; the module's external interface
carries no port for it.

### 3. Remote but owned (ports and adapters)

Your own services across a network boundary — microservices, internal APIs. Define a **port**
(an interface) at the seam. The deep module owns the logic; the transport is injected as an
**adapter**. Production uses the HTTP, gRPC or queue adapter; tests use the same adapter against
a local instance of the service.

Recommendation shape: *"Define a port at the seam and inject the transport as an adapter, so
the logic sits in one deep module even though it is deployed across a network."*

### 4. True external

Third-party services you do not control — Stripe, Twilio and the like. The deepened module takes
the external dependency as an injected port; tests run against the service's own sandbox or test
mode through the production adapter.

## Seam discipline

- **One adapter means a hypothetical seam; two adapters mean a real one.** Introduce a port only
  where at least two adapters are justified. A single-adapter seam is just indirection. A
  network or process boundary is a real seam with its one production adapter, as in categories
  3 and 4.
- **Internal seams and the external seam.** A deep module can have internal seams, private to its
  implementation and used by its own tests, beside the external seam at its interface. Keep the
  internal ones out of the interface, even when tests use them.

## Testing strategy: replace the old tests

- Unit tests on the old shallow modules become waste once tests at the deepened module's
  interface cover every behaviour they checked; map them scenario by scenario, then delete them.
- Write the new tests at the deepened module's interface. The **interface is the test surface**.
- Tests assert observable outcomes through the interface, never internal state.
- Tests survive internal refactors, because they describe behaviour. A test that has to change
  when the implementation changes is testing past the interface.
