---
name: best-practice
description: Turn a recurring defect class into a published best-practice page — the practice, the evidence, its scope and non-scope, the concrete form, and whether anything enforces it. Use when the same mistake has happened twice and no mechanical check can catch it. Not for one-off bugs, and not for practices that already have a home in a contract.
---

# /best-practice — write the page only when it cannot be a gate

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Publishing/Best Practice.md` (WF-BP).
Where this file and the spec disagree, the spec wins: update this file to match it.

## 1. Try not to write it

Review Mining settled the order for actuating a defect class: **a CI predicate first, a
review-prompt line second, a checklist or a page third.** Answer the three questions below, in
order, before writing a word.

**Could a check catch it mechanically?** Then build the check. A page describing what a check
could enforce is a rule with no enforcement, and a rule with no enforcement goes stale and gets
broken. When in doubt, build the gate.

Signals a check is possible: the class is decidable from a diff, a file's contents, a
command's exit code, or a comparison between two artifacts. If you can describe the test in
a sentence, write the test.

**Does the practice already have a home?** Search the contracts and rule registries before
writing. If it is already a rule, the answer is a **pointer** to that rule. The second copy
of a rule is always the one that goes stale.

**Has it actually happened twice?** One instance is an anecdote. The recurrence *is* the
trigger. A practice written from a single incident encodes one situation's accident as
everyone's rule.

**Say no out loud.** If any of the three above disqualifies it, say which and stop, for
example: "This should be a CI check on X."

## 2. The six parts

If it survives §1, the page carries all six. The middle two are the ones that go missing,
and a page missing them is an opinion with formatting.

1. **The practice.** One sentence somebody can act on, written as an instruction: *"Run the
   version probe in the repo root"*.
2. **The evidence.** What actually happened, with dates and links. **Two instances minimum.**
   State what was measured.
3. **Scope — and explicitly the non-scope.** Where this applies, and where it does not. Good
   advice does damage when a claim true of one surface is relied on for another, and naming
   the boundary prevents it.
4. **The concrete form.** The command, the code shape, the exact thing to type. Advice that
   stops at the principle goes unapplied.
5. **Enforcement, stated honestly.** Is there a gate, a review-prompt line, or nothing? If
   nothing: what a gate *would* look like. **A page that does not say it is unenforced implies
   a floor that is not there.**
6. **What would change it.** The observation that would retire the practice. A practice that
   cannot be wrong cannot be improved.

## 3. Produce and publish

Write every working file into `.best-practice/` in the current directory. Create that
directory, with a `.gitignore` in it containing `*`, before writing the first file into it.

Render with **`/explainer`** into `.best-practice/best-practice.html`. It is the renderer, and
it owns the judgment about whether a diagram carries the mechanism. Do not hand-roll HTML.

```bash
wf publish-artifact .best-practice/best-practice.html --title "<the practice, stated>"
```

Title it with the **practice**, stated as an instruction: *"Probe toolchain versions in the
repo root"*. The title is what someone sees in a list six weeks later.

## 4. Link it from where the decision is made

A page nobody routes to is a page nobody reads. Link it from the surface a reader hits
**before** the decision it governs: the skill that will do the thing, the contract section it
supports, the spec node that will cite it. An index entry alone is not routing.
