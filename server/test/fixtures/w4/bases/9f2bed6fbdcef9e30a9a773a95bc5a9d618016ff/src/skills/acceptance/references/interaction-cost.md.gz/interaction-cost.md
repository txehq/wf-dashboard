# Interaction cost (GOMS-KLM)

An optional overlay for **UI rounds**: while you drive the product, record what a
person would have had to do to reach the same state. The round then carries a
_user-equivalent_ interaction cost, so a flow can also be judged on what it costs
to walk.

**Where it surfaces:** in that round's HTML report, as its own collapsible
section. Include the raw trace and the pricing model used.

**Skip it whenever it does not apply.** A CLI or backend round has no interaction
to price. A round that `agent-browser` does not drive records no trace. In both
cases you publish exactly as usual — no trace file, no cost
section, no warning. Never hand-write the numbers to fill the gap.

## Operator counts and the timing model

You never compute seconds. The driver appends one JSON atom per action to
`interaction-trace.jsonl` in the round directory, carrying raw **operator
counts**; the report template may summarize it with the declared timing model
(`goms-klm@lobe-v1`), and the raw trace is authoritative. Every round is priced by
that one model, and any published number can be recomputed from its trace.

```jsonl
{"schema":"lobehub.agentBrowserKlmTrace@1","type":"action","phase":{"id":"login","label":"Sign in"},"klm":{"category":"action","operators":{"P":1,"K":1}},"durationMs":840}
{"schema":"lobehub.agentBrowserKlmTrace@1","type":"mental_estimate","phase":{"id":"first-view"},"klm":{"category":"mental","operators":{"M":2}},"mentalEstimate":{"score":3,"confidence":0.75,"reason":"Reading the state and deciding the next action"}}
```

| Field                | Meaning                                                                    |
| -------------------- | -------------------------------------------------------------------------- |
| `schema`             | Must be `lobehub.agentBrowserKlmTrace@1`; a foreign tag is not summed      |
| `phase.id` / `label` | Groups atoms into a step of the journey; `phase.checkItemId` links a check |
| `klm.operators`      | Raw counts — see the operator table below                                  |
| `klm.category`       | `action` \| `mental` \| `blocked` — `blocked` charges nothing              |
| `durationMs`         | Agent wall-clock, reported separately from the user-equivalent price       |

## Operators

| Operator  | Counts                                    | Typical source                       |
| --------- | ----------------------------------------- | ------------------------------------ |
| `P`       | Pointing at a target                      | `click`, drag                        |
| `K`       | One keystroke / button press              | `click` (the press), `press`         |
| `T_chars` | Characters typed                          | `fill`, `type`                       |
| `H`       | Homing between keyboard and pointer       | Switching input device               |
| `M`       | Mental preparation — **estimated by you** | Deciding, locating, reading state    |
| `R_ms`    | Measured system wait, in ms — not modeled | Navigation / load the user waits out |

- **An action that did not happen costs nothing.** A failed, timed-out, or
  blocked command is recorded with `"category":"blocked"` and zero operators.
  Never charge a retry loop as if a person performed it.
- **`M` is an estimate, and it is yours.** Record it explicitly at the moments a
  person would actually have to think — first view of a screen, choosing between
  options, re-orienting after a state change — with a short reason. Do not
  sprinkle it on every action to inflate the total.

## Publishing

Leave `interaction-trace.jsonl` in the round directory and render it into
`report.html` with the Jinja2 template ([report.md](report.md) step 6), passing the
trace as a list:

```bash
uv run "$SKILL_DIR/scripts/render_report.py" "$REPORT_DIR/report.html.j2" "$REPORT_DIR/report.html" \
  result="$REPORT_DIR/result.json" publication="$REPORT_DIR/publication.json" \
  trace="$REPORT_DIR/interaction-trace.jsonl"
```

The template may calculate `interactionCost` from the trace. If no action is
priceable, omit the cost section. Keep any explicit `result.json.interactionCost`
and show its derivation.
