# /// script
# requires-python = ">=3.11"
# dependencies = ["markdown-it-py>=3"]
# ///

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import time

from markdown_it import MarkdownIt

SEVERITY_RE = re.compile(r"^(Critical|High|Medium|Low) \[([0-9]+)\]$")
FINDING_RE = re.compile(r"^[0-9]+\. ")
DISPOSED_RE = re.compile(r"<!-- fix-pr disposed review=([0-9]+) rev=([0-9a-f]{12}) head=([0-9a-f]{7,40}) -->")
REPO_RE = re.compile(r"^[A-Za-z0-9._-]+/[A-Za-z0-9._-]+$")
BLOCKING = ("Critical", "High")
CLEAN_VERDICT = "no actionable findings"
# 整段就是这句结论，后面最多跟一个短的限定语（"on this head"）。
CLEAN_RE = re.compile(rf"^{CLEAN_VERDICT}(\s+(on|in|for|within)\s+[^.]{{1,40}})?\.?$")

# 只有 /review-pr 写的 review 带这些标记，也只有它用 "### Critical [N]" 的 severity 语法。
# 其他 reviewer——人，或者别的 bot——写的是普通正文，一样要处置，只是没有可读的计数。
RPR_MARKERS = (
    "<!-- OpenAI Codex via RPR -->",
    "<!-- OpenAI Codex via RPRB -->",
    "Review by OpenAI Codex via RPRB",
)

# 标记只有仓库自己人写下才算数。外面的人复制一个标记，不能让 watcher 认为
# 意见已经处置，也不能让它把一份伪造的 review 当成 /review-pr 的干净结论。
TRUSTED = ("OWNER", "MEMBER", "COLLABORATOR")

FAILED_CONCLUSIONS = ("failure", "cancelled", "timed_out", "action_required", "startup_failure", "stale")
PASSED_CONCLUSIONS = ("success", "neutral", "skipped")

# 退出码各自独占一个含义。崩溃留给 1，因为未捕获的异常本来就退 1，
# 带着 traceback 落在 stderr 上；把 review-invalid 挪开，两者才分得清。
TERMINAL = {"quiet": 0, "review-invalid": 2}
EXPIRED_EXIT = 75
# 一轮 poll 要发一串 GitHub 请求。剩下的时间不够跑完一整轮，就在开始之前退休，
# 否则最后一轮会在半路上超时崩掉，而 watch-expired 永远发不出来。
POLL_BUDGET = 30.0
ATTEMPTS = 3
RETRY_PAUSE = 2.0

THREADS_QUERY = """
query($o: String!, $r: String!, $n: Int!, $endCursor: String) {
  repository(owner: $o, name: $r) {
    pullRequest(number: $n) {
      reviewThreads(first: 100, after: $endCursor) {
        nodes { id isResolved isOutdated path line }
        pageInfo { hasNextPage endCursor }
      }
    }
  }
}
"""

NEXT = {
    "review": "disposition every finding in this review — §2 of the /fix-pr skill",
    "ci-failed": "open each failure's url, reproduce it locally, fix it, push",
    "head-moved": "a new head is on the PR — the watch follows it, and the review it carries arrives as its own event",
    "quiet": "the loop is done — invoke /ready-for-review",
    "review-invalid": "the review on this head is empty or malformed, which is a failure — stop the run and report the review's state",
    "watch-expired": "re-arm the watch on the same PR",
}


# 这一轮 watch 的上下文，让任何一处时间耗尽都能发出同一个 watch-expired。
RUN: dict = {"head": None, "max_runtime": None}


def expire() -> None:
    # 时间耗尽只有这一个出口。散在各处 raise 一个字符串，退出码会和"watcher 崩了"
    # 撞在一起，而调用方等的那个重新挂载的信号就丢了。
    emit({"event": "watch-expired", "head": RUN["head"], "watched_s": RUN["max_runtime"]})
    raise SystemExit(EXPIRED_EXIT)


def gh(args: list[str], deadline: float, allowed: tuple[int, ...] = (0,)) -> subprocess.CompletedProcess[str]:
    # 每个请求试 ATTEMPTS 次。这里读的全是 GET，一次 `unexpected EOF` 是线路抖动，
    # 不是判断出了错——真让它终止整个 watch，PR 就又变成没有人看着了，
    # 而那正是这个 skill 要消灭的那种失败。试完还是不行就带着 stderr 退出。
    for attempt in range(ATTEMPTS):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            expire()
        proc = subprocess.run(["gh", *args], capture_output=True, text=True, timeout=min(60.0, remaining))
        if proc.returncode in allowed:
            return proc
        if attempt + 1 == ATTEMPTS:
            raise SystemExit(f"gh {' '.join(args)} exited {proc.returncode}: {proc.stderr.strip()}")
        pause = min(RETRY_PAUSE, deadline - time.monotonic())
        if pause <= 0:
            expire()
        time.sleep(pause)


def gh_json(args: list[str], deadline: float, allowed: tuple[int, ...] = (0,)) -> object:
    return json.loads(gh(args, deadline, allowed).stdout)


def pages(args: list[str], deadline: float) -> list:
    return gh_json([*args[:1], "--paginate", "--slurp", *args[1:]], deadline)


def parse_review(body: str, markdown: MarkdownIt) -> tuple[str, dict[str, int]]:
    # /review-pr 把严重级别写成 "### Critical [N]"，每条 finding 是它下面的 "#### 1. ..."。
    # 声明的数目和数出来的 finding 对不上、同一个级别出现两次、只有一个 [0]——
    # 都是一份被截断的 review，和"确实没有问题"必须分开表示。
    counts: dict[str, int] = {}
    order: list[str] = []
    found: dict[str, int] = {}
    clean = False
    current = None
    tokens = markdown.parse(body)
    for index, token in enumerate(tokens):
        if token.type != "inline" or index == 0:
            continue
        opener = tokens[index - 1]
        if opener.type == "paragraph_open" and opener.level == 0:
            # 干净结论只认顶层的一整段，而且那一段整个就是这句结论。代码块、引用、
            # finding 正文里出现同样的话不算数，"因为 review 被截断了所以 no actionable
            # findings 无从谈起"这种话也不算——它含有这句话，说的却是相反的意思。
            if CLEAN_RE.match(" ".join(token.content.casefold().split())):
                clean = True
            continue
        if opener.type != "heading_open":
            continue
        if opener.tag == "h3":
            match = SEVERITY_RE.match(token.content)
            current = match.group(1) if match else None
            if match:
                order.append(current)
                counts[current] = int(match.group(2))
                found.setdefault(current, 0)
        elif opener.tag == "h4" and current and FINDING_RE.match(token.content):
            found[current] += 1

    if len(order) != len(set(order)):
        return "malformed", {}
    if any(counts[name] != found[name] for name in counts):
        return "malformed", {}
    if sum(counts.values()):
        return "findings", counts
    # 声明了一个级别却一条 finding 都没有，同时又说"没有问题"，两句话是矛盾的，
    # 被截断的 review 正好长这样。
    if counts:
        return "malformed", {}
    if clean:
        return "clean", {}
    return "malformed", {}


def trusted(item: dict) -> bool:
    return item.get("author_association") in TRUSTED


def disposed_reviews(comments: list[dict]) -> set[tuple[str, str]]:
    # 处置标记留在 PR 的评论里，记录 review id、当时那份意见的修订号，以及修复所在的 head。
    # 覆盖关系不认 head：修复推上去之后 head 会变，而那条意见照样是被处置过的。
    # 认修订号：review id 不变的情况下正文可以被改掉，改完就是一份新的意见。
    marked: set[tuple[str, str]] = set()
    for comment in comments:
        if not trusted(comment):
            continue
        for review_id, rev, _head in DISPOSED_RE.findall(comment.get("body") or ""):
            marked.add((review_id, rev))
    return marked


def is_rpr(review: dict) -> bool:
    body = review.get("body") or ""
    return trusted(review) and any(marker in body for marker in RPR_MARKERS)


def revision(review: dict, inline: list[dict]) -> str:
    parts = [str(review.get("state")), str(review.get("submitted_at")), review.get("body") or ""]
    for comment in sorted(inline, key=lambda c: c["id"]):
        parts += [str(comment["id"]), str(comment.get("updated_at")), comment.get("body") or ""]
    return hashlib.sha256("\n".join(parts).encode()).hexdigest()[:12]


def has_findings(review: dict, verdict: str, inline: list[dict]) -> bool:
    if inline:
        return True
    if is_rpr(review):
        return verdict == "findings"
    # 人点一下 Approve 不写正文，没有什么要处置的。写了正文就是意见，
    # Approve 里附一句"顺手改一下这个"同样要处置。
    return bool((review.get("body") or "").strip())


def classify(checks: list[dict], required: list[str]) -> tuple[list[dict], bool, list[str]]:
    failed = []
    pending = False
    for check in checks:
        if check.get("status") != "completed":
            pending = True
        elif check.get("conclusion") in FAILED_CONCLUSIONS:
            failed.append(check)
        elif check.get("conclusion") not in PASSED_CONCLUSIONS:
            pending = True
    passed = {c["name"] for c in checks if c.get("status") == "completed" and c.get("conclusion") in PASSED_CONCLUSIONS}
    # 分批注册的 check suite：一条快的先绿，必需的那条还没有建出来，
    # 这时候宣布安静，等于在一个 CI 没有跑完的 head 上收工。
    return failed, pending, sorted(set(required) - passed)


def events(head: str, reviews: list[dict], checks: list[dict], comments: list[dict], inline: dict[str, list[dict]], unresolved: int, required: list[str], required_source: str, markdown: MarkdownIt) -> list[dict]:
    disposed = disposed_reviews(comments)
    read = [(r, *parse_review(r.get("body") or "", markdown)) for r in reviews]

    # 只判定当前 head 上最新的那份 RPR review。更早的一份坏掉，不该让 watcher
    # 从此一直报错——后来的一份有效 review 就是它的接替。
    rpr_here = [(r, v) for r, v, _ in read if is_rpr(r) and r.get("commit_id") == head]
    if rpr_here and rpr_here[-1][1] == "malformed":
        return [{"event": "review-invalid", "review_id": str(rpr_here[-1][0]["id"]), "head": head}]

    found: list[dict] = []
    for review, verdict, counts in read:
        rid = str(review["id"])
        comments_here = inline.get(rid, [])
        if not has_findings(review, verdict, comments_here):
            continue
        rev = revision(review, comments_here)
        if (rid, rev) in disposed:
            continue
        found.append(
            {
                "event": "review",
                "review_id": rid,
                "revision": rev,
                "head": head,
                "reviewed_head": review.get("commit_id"),
                "state": review.get("state"),
                "reviewer": (review.get("user") or {}).get("login"),
                "severities": counts,
                "blocking": sum(counts.get(name, 0) for name in BLOCKING),
                "inline_comments": len(comments_here),
                "graded": is_rpr(review),
                "marker": f"<!-- fix-pr disposed review={rid} rev={rev} head=<sha> -->",
            }
        )

    failed, pending, missing = classify(checks, required)
    if failed:
        found.append(
            {
                "event": "ci-failed",
                "head": head,
                "checks": sorted(c["name"] for c in failed),
                "urls": sorted(c["url"] for c in failed if c.get("url")),
                "runs": sorted(c["identity"] for c in failed),
            }
        )

    if found or pending or missing:
        return found
    # 一条 check 都没有观察到，和"全部通过"不是一回事：刚推完的那一刻 check suite
    # 还没有注册，把它读成绿的就是在一个没有跑过 CI 的 head 上宣布安静。
    if not checks or unresolved:
        return found
    on_head = [(r, v, c) for r, v, c in read if r.get("commit_id") == head]
    if not on_head:
        return found
    graded = [c for r, v, c in on_head if is_rpr(r)]
    if graded and sum(graded[-1].get(name, 0) for name in BLOCKING):
        return found
    return [
        {
            "event": "quiet",
            "head": head,
            "reviews_on_head": len(on_head),
            "checks": len(checks),
            "required_checks": required,
            "required_from": required_source,
        }
    ]


def key(event: dict) -> tuple:
    if event["event"] == "review":
        return ("review", event["review_id"], event["revision"])
    if event["event"] == "ci-failed":
        return ("ci-failed", event["head"], tuple(event["runs"]))
    return (event["event"], event["head"])


def emit(event: dict) -> None:
    # 每一行 stdout 都是 Monitor 的一个事件，所以整条事件写成一行，并且立刻冲出去。
    print(json.dumps({**event, "next": NEXT[event["event"]]}), flush=True)


def required_checks(repo: str, base: str, deadline: float) -> tuple[list[str], str]:
    # ruleset 和经典分支保护，对没有相应权限的人都是 404 或者 403。那是"读不到声明"，
    # 不是"没有必需检查"，而且读不到第一处绝不能挡住第二处。
    rules = gh_json(["api", f"repos/{repo}/rules/branches/{base}"], deadline, allowed=(0, 1))
    contexts = [
        check["context"]
        for rule in (rules if isinstance(rules, list) else [])
        if rule.get("type") == "required_status_checks"
        for check in rule["parameters"]["required_status_checks"]
    ]
    if contexts:
        return sorted(set(contexts)), "rulesets"

    protection = gh_json(["api", f"repos/{repo}/branches/{base}/protection"], deadline, allowed=(0, 1))
    declared = protection.get("required_status_checks") if isinstance(protection, dict) else None
    if declared:
        return sorted(set(declared["contexts"])), "branch-protection"
    return [], "undeclared"


def latest_executions(runs: list[dict], workflows: list[dict]) -> list[dict]:
    # 同一个 check 在同一个 head 上可以执行好几次：改一次 PR 正文，pull_request 事件就再触发一次
    # workflow，每次都是一个新的 check suite。filter=latest 只在一个 suite 里取最新，跨 suite 的
    # 旧执行照样返回——被 concurrency 取消的那一次也在里面。
    # 一个 check 的身份是 app + workflow + 触发事件 + 名字，和 gh pr checks 去重用的是同一组字段。
    # 查不到 workflow run 的 check suite（第三方 app 的，或者 workflow run 还没列出来的），
    # 来源不明，就用它自己的 check suite 当身份：来源不明的两次执行不能互相接替，
    # 否则一次无关的成功会盖掉一次真实的失败。
    # 同一身份只看 id 最大的那一次：id 在创建时分配，接替者总在被接替者之后创建，而 started_at
    # 可以为 null。被接替的执行不再参与判断；没有被接替的 cancelled 照样是失败。
    provenance = {w["check_suite_id"]: (w["workflow_id"], w["event"]) for w in workflows}
    latest: dict[tuple, dict] = {}
    for run in runs:
        suite = run["check_suite"]["id"]
        origin = provenance.get(suite, ("suite", suite))
        check = (run["app"]["id"], origin, run["name"])
        if check not in latest or run["id"] > latest[check]["id"]:
            latest[check] = run
    # identity 是这条 check 这一次运行的身份。重跑会换 check run id，也会换
    # completed_at；两者都留着，同名同 URL 的第二次失败才不会被当成第一次。
    return [
        {
            "name": run["name"],
            "status": run["status"],
            "conclusion": run["conclusion"],
            "url": run.get("html_url"),
            "identity": f"{run['id']}@{run.get('completed_at') or run.get('started_at')}",
        }
        for run in sorted(latest.values(), key=lambda r: r["id"])
    ]


def head_checks(repo: str, head: str, deadline: float) -> list[dict]:
    runs = [
        run
        for page in pages(["api", f"repos/{repo}/commits/{head}/check-runs?filter=latest&per_page=100"], deadline)
        for run in page["check_runs"]
    ]
    workflows = [
        workflow
        for page in pages(["api", f"repos/{repo}/actions/runs?head_sha={head}&per_page=100"], deadline)
        for workflow in page["workflow_runs"]
    ]
    checks = latest_executions(runs, workflows)
    # combined status 本身就只给每个 context 最新的那一条。
    combined = gh_json(["api", f"repos/{repo}/commits/{head}/status"], deadline)
    for status in combined["statuses"]:
        checks.append(
            {
                "name": status["context"],
                "status": "completed" if status["state"] != "pending" else "queued",
                "conclusion": {"success": "success", "failure": "failure", "error": "failure"}.get(status["state"]),
                "url": status.get("target_url"),
                "identity": f"{status['id']}@{status.get('updated_at')}",
            }
        )
    return checks


def poll(repo: str, pr: int, deadline: float, required: list[str], source: str, markdown: MarkdownIt) -> tuple[str, list[dict]]:
    owner, name = repo.split("/", 1)
    head = gh_json(["pr", "view", str(pr), "--repo", repo, "--json", "headRefOid"], deadline)["headRefOid"]

    reviews = [r for page in pages(["api", f"repos/{repo}/pulls/{pr}/reviews"], deadline) for r in page]
    comments = [c for page in pages(["api", f"repos/{repo}/issues/{pr}/comments"], deadline) for c in page]

    inline: dict[str, list[dict]] = {}
    for comment in (c for page in pages(["api", f"repos/{repo}/pulls/{pr}/comments"], deadline) for c in page):
        rid = comment.get("pull_request_review_id")
        if rid is not None:
            inline.setdefault(str(rid), []).append(comment)

    threads = pages(
        ["api", "graphql", "-f", f"query={THREADS_QUERY}", "-f", f"o={owner}", "-f", f"r={name}", "-F", f"n={pr}"],
        deadline,
    )
    unresolved = sum(
        1
        for page in threads
        for node in page["data"]["repository"]["pullRequest"]["reviewThreads"]["nodes"]
        if not node["isResolved"]
    )

    checks = head_checks(repo, head, deadline)

    # head 在收集途中动过，这份快照就不描述任何一个真实的 head，更不能拿它下终止判断。
    if gh_json(["pr", "view", str(pr), "--repo", repo, "--json", "headRefOid"], deadline)["headRefOid"] != head:
        return head, []

    return head, events(head, reviews, checks, comments, inline, unresolved, required, source, markdown)


def positive(value: str) -> int:
    number = int(value)
    if number <= 0:
        raise argparse.ArgumentTypeError(f"must be a positive integer, got {value}")
    return number


def repository(value: str) -> str:
    if not REPO_RE.match(value):
        raise argparse.ArgumentTypeError(f"must be OWNER/REPO, got {value}")
    return value


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=repository, required=True)
    parser.add_argument("--pr", type=positive, required=True)
    parser.add_argument("--interval", type=positive, default=30)
    parser.add_argument("--max-runtime", type=positive, default=1500)
    args = parser.parse_args()

    markdown = MarkdownIt("commonmark")
    expires = time.monotonic() + args.max_runtime
    seen: set[tuple] = set()
    head = None
    RUN["max_runtime"] = args.max_runtime

    # 启动这几个请求也要留出一轮 poll 的余量，否则慢启动会把时间用光，
    # 循环一次都没有进去，而 watch-expired 也就发不出来了。
    startup = expires - POLL_BUDGET
    base = gh_json(["pr", "view", str(args.pr), "--repo", args.repo, "--json", "baseRefName"], startup)["baseRefName"]
    required, source = required_checks(args.repo, base, startup)

    while True:
        if expires - time.monotonic() < POLL_BUDGET:
            expire()

        current, found = poll(args.repo, args.pr, expires, required, source, markdown)
        if head is not None and current != head:
            # head 换过一轮又换回来，check 的观察不再成立，重新开始报。
            seen = {k for k in seen if k[0] == "review"}
            moved = {"event": "head-moved", "head": current, "previous_head": head}
            if key(moved) not in seen:
                seen.add(key(moved))
                emit(moved)
        head = current
        RUN["head"] = current

        for event in found:
            if key(event) in seen:
                continue
            seen.add(key(event))
            emit(event)
            if event["event"] in TERMINAL:
                return TERMINAL[event["event"]]

        remaining = expires - time.monotonic() - POLL_BUDGET
        if remaining <= 0:
            expire()
        time.sleep(min(args.interval, remaining))


if __name__ == "__main__":
    raise SystemExit(main())
