# Codex model resolution

Resolve the Codex model once at the start of a session that runs `codex exec`, and use the
result for every later call in that session.

## Resolution

1. **Cache.** If `.review-pr/codex_resolved_model.txt` in the current directory exists and is
   non-empty, use the model it names and skip the probe.

2. **Model.** Read `references/codex-models.txt` in this skill's directory. The first line that
   is neither blank nor a comment names the model `M`.

3. **CLI.** When `command -v codex` prints nothing, install `codex-cli` with the machine's
   package manager (`brew install --cask codex` on macOS).

4. **Probe.** Run:

   ```bash
   codex exec -m M -s read-only -c approval_policy=never -c model_reasoning_effort=low \
     --disable apps --ephemeral --skip-git-repo-check "Reply with one word: ready"
   ```

   On success, create `.review-pr/` with a `.gitignore` containing `*` if it does not exist,
   write `M` to `.review-pr/codex_resolved_model.txt`, and use `M`.

   Any failure stops the review with its exact error: an `invalid_request_error` for the model
   (unknown, decommissioned, or `"requires a newer version of Codex"`), a network or auth
   error, a timeout, or a hang.

## Header truthfulness

Review and comment headers name the model that answered the probe: `(M, high)`.

## Clearing the cache

Delete `.review-pr/codex_resolved_model.txt` after changing `references/codex-models.txt`,
after upgrading `codex-cli`, and when the cached model starts failing.

## Changing the model

Put a new model on the first line of `references/codex-models.txt` once the probe above
succeeds with it on the installed `codex-cli`.
