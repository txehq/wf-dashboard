---
name: release-notes
description: Write and publish standard release notes for a version — what was added, changed, fixed and broken, with the metadata to trace any line to its PR and ticket. Use when cutting or promoting a release, when asked for release notes or a changelog for a version, or after a batch of PRs merges. Derives the commits, PRs, tickets and migrations with a tool; the grouping and wording are judgment.
---

# /release-notes — standard release notes, done properly

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Delivery/Release Notes.md` (WF-RELN).
Where this file and the spec disagree, the spec wins: update this file to match it.

## 1. Derive the facts

```bash
wf release-notes --from v1.1.0 --to HEAD     # --from defaults to the most recent tag
wf release-notes --json                      # the same facts, as JSON
```

It returns the commits in the range, the PR each came through, every ticket id, the surfaces
touched, and any migration files. **Do not run `git log` and transcribe it** — that is where
fabrication enters.

- **`MIGRATION`** — a migration in the range means the release is not freely reversible. It
  goes in Upgrade notes, said plainly.
- **`pr_bodies_read`** — in this organization the closing trailer lives in the **PR body**, so
  the ticket list is complete only when this is `true`. When it is `false`, `gh` is missing or
  not authenticated: install `gh` when `command -v gh` prints nothing, have the person run
  `gh auth login` when `gh auth status` shows no login, then run `wf release-notes` again.
  Nothing is written from a `false` result.

**The ctx pin.** For a `txe-workflow` release, state the ctx version its `workflow.lock.json`
pins (`ctx_upstream.version`) and whether it changed since the previous release — in Metadata
always, under Changed when it moved. A ctx bump has no diff of its own, so the range cannot show
it, and a lock with an empty `ctx_upstream.binaries` pins no ctx at all.

## 2. Write it in the conventional shape

Write every working file into `.release-notes/` in the current directory. Create that
directory, with a `.gitignore` in it containing `*`, before writing the first file into it.

```markdown
## v1.3.0 — 2026-09-07

### Breaking changes
- ...            ← first when present, and only when present

### Added
### Changed
### Fixed
### Deprecated / Removed / Security

### Upgrade notes
- migrations, config changes, anything an operator or user must do

### Metadata
range · PRs · tickets · contributors
```

**Omit empty groups.** Do not add groups the conventions do not have. A reader who has seen
release notes anywhere else recognises this shape at once, and finds the fix they have been
waiting for.

**Each line describes what the change does, for someone who did not write it**: "Orders placed
within a second of each other could be processed out of sequence; they are now serialised per
account." One line per user-visible change.

## 3. Publish

Render with **`/explainer`** into `.release-notes/release-notes.html`. Do not hand-roll HTML.

```bash
wf publish-artifact .release-notes/release-notes.html --title "<product> v1.3.0 — <headline change>"
```

Title with the version **and** the headline change: the headline change is what tells a reader
six weeks later what the release was.

## 4. Record it in Linear

Comment on each ticket in the range, dated, linking the page.

- **Do not summarise the notes in the comment.** A restatement in the ticket is a second home
  and it goes stale.
- **Do not change any ticket's status.** Shipping a change does not complete its ticket.

## What to refuse

- **An empty range.** The tool exits non-zero. Stop and ask which range was meant.
- **A change you cannot describe.** Find out what it does before writing its line.

## What this must never claim

**That anything is deployed.** These notes say what a release *contains*. Whether it is running
is `/deploy-summary`'s question, answered against an environment.
