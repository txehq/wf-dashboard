// engapp-artifacts — the publishing transport behind https://engapp.dev/artifacts
//
// - Route: engapp.dev/artifacts* (zone engapp.dev, Capso account).
// - Bucket: R2 `engapp-artifacts`, bound as ARTIFACTS.
// - Gate: Cloudflare Access, app *Session Artifacts*, 720h session.
//
// Access is the only gate. It covers reads (GET/HEAD), writes and the analytics export, and
// anyone it admits may publish.

const ID = /^[0-9a-z]{8}$/;
function esc(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}

export default {
  async fetch(req, env) {
    const seg = new URL(req.url).pathname.replace(/^\/artifacts\/?/, "").split("/").filter(Boolean);

    if (req.method === "PUT") {
      if (seg.length !== 2) return new Response("bad upload path\n", { status: 400 });
      const [kind, id] = seg;
      if (!["page","img"].includes(kind) || !ID.test(id)) return new Response("bad kind/id\n", { status: 400 });
      // `wf publish-artifact` sends all four headers on every upload.
      const missing = ["content-type", "x-artifact-title", "x-artifact-session", "x-artifact-meta"]
        .filter((name) => !req.headers.has(name));
      if (missing.length) return new Response("missing header: " + missing.join(", ") + "\n", { status: 400 });
      // Provenance must be valid JSON; it is stored re-serialised.
      let meta;
      try { meta = JSON.stringify(JSON.parse(req.headers.get("x-artifact-meta"))); }
      catch (e) { return new Response("x-artifact-meta is not valid JSON: " + e.message + "\n", { status: 400 }); }
      await env.ARTIFACTS.put(kind + "/" + id, req.body, {
        httpMetadata: { contentType: req.headers.get("content-type") },
        customMetadata: {
          title: req.headers.get("x-artifact-title").slice(0, 200),
          session: req.headers.get("x-artifact-session").slice(0, 80),
          uploaded: new Date().toISOString(),
          meta
        }
      });
      return Response.json({ ok: true, url: "https://engapp.dev/artifacts/" + kind + "/" + id });
    }

    if (req.method !== "GET" && req.method !== "HEAD")
      return new Response("method not allowed\n", { status: 405 });

    const collect = async () => {
      const out = []; let cursor;
      do {
        const ls = await env.ARTIFACTS.list({ limit: 1000, cursor, include: ["customMetadata"] });
        for (const o of ls.objects) {
          // Every object in this bucket carries the four keys below: uploads before the
          // headers became mandatory stored the empty string where a header was absent,
          // and `meta` is either that empty string or re-serialised JSON.
          const cm = o.customMetadata;
          out.push({ id: o.key.split("/")[1], kind: o.key.split("/")[0], key: o.key,
                     title: cm.title, session: cm.session,
                     uploaded: cm.uploaded, size: o.size,
                     ...(cm.meta === "" ? {} : JSON.parse(cm.meta)) });
        }
        cursor = ls.truncated ? ls.cursor : undefined;
      } while (cursor);
      return out.sort((a,b) => String(b.uploaded).localeCompare(String(a.uploaded)));
    };

    // ── analytics export ──
    if (seg.length === 1 && seg[0] === "_meta.json") {
      const rows = await collect();
      return Response.json({ generated: new Date().toISOString(), count: rows.length, artifacts: rows },
        { headers: { "cache-control": "no-store", "referrer-policy": "no-referrer" } });
    }

    if (seg.length === 0) {
      const who = req.headers.get("cf-access-authenticated-user-email");
      const rows = await collect();
      const cell = (r) => [r.repo, r.branch].filter(Boolean).join(" · ");
      const body = `<!doctype html><meta charset=utf-8><title>engapp artifacts</title>
<meta name=viewport content="width=device-width,initial-scale=1"><meta name=referrer content=no-referrer>
<style>
:root{--bg:#F7F8FA;--ink:#1A1F2B;--mut:#5A6474;--rule:#DADEE7;--acc:#3A4FA8}
@media(prefers-color-scheme:dark){:root{--bg:#12151B;--ink:#E4E8F0;--mut:#98A2B3;--rule:#262C38;--acc:#8FA2E8}}
*{box-sizing:border-box}
body{background:var(--bg);color:var(--ink);font:15px/1.55 ui-sans-serif,system-ui,-apple-system,sans-serif;margin:0;padding:2.5rem 1.25rem}
main{max-width:1080px;margin:0 auto}
h1{font-size:1.35rem;margin:0 0 .2rem;letter-spacing:-.01em}
p.sub{color:var(--mut);margin:0 0 1.9rem;font-size:.88rem}
p.sub a{color:var(--acc)}
table{width:100%;border-collapse:collapse}
th{text-align:left;font-size:.66rem;letter-spacing:.09em;text-transform:uppercase;color:var(--mut);border-bottom:1px solid var(--rule);padding:0 .7rem .45rem 0;white-space:nowrap}
td{border-bottom:1px solid var(--rule);padding:.65rem .7rem;vertical-align:top}
td:first-child,th:first-child{padding-left:0}
a{color:var(--acc);text-decoration:none}a:hover{text-decoration:underline}
.k{font:600 .6rem/1 ui-sans-serif;letter-spacing:.06em;text-transform:uppercase;color:var(--mut);border:1px solid var(--rule);border-radius:3px;padding:.25em .45em}
.m{font-family:ui-monospace,SFMono-Regular,monospace;font-size:.74rem;color:var(--mut)}
.d{color:#B4453A}
.e{color:var(--mut);padding:2.5rem 0;text-align:center}
footer{margin-top:2.5rem;padding-top:1rem;border-top:1px solid var(--rule);font-size:.76rem;color:var(--mut)}
</style>
<main><h1>engapp artifacts</h1>
<p class=sub>Explainers and screenshots published from coding sessions. ${rows.length} item${rows.length===1?"":"s"} · <a href="/artifacts/_meta.json">_meta.json</a></p>
${rows.length ? `<table><thead><tr><th>Artifact</th><th>Kind</th><th>Session</th><th>Repo · branch</th><th>Commit</th><th>Published</th></tr></thead><tbody>${
rows.map(r=>`<tr><td><a href="/artifacts/${esc(r.key)}">${esc(r.title)}</a><div class=m>/artifacts/${esc(r.key)}</div></td><td><span class=k>${esc(r.kind)}</span></td><td class=m>${esc(r.session)}</td><td class=m>${esc(cell(r))}</td><td class=m>${"sha" in r ? esc(r.sha) : ""}${r.dirty==="1"?' <span class=d>dirty</span>':''}</td><td class=m>${esc(String(r.uploaded).slice(0,16).replace("T"," "))}</td></tr>`).join("")
}</tbody></table>` : "<p class=e>Nothing published yet.</p>"}
<footer>Signed in as ${esc(who)} · gated by Cloudflare Access · 30-day session · anyone signed in may publish · provenance is self-reported at upload and visible to everyone here</footer></main>`;
      return new Response(body, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store", "referrer-policy": "no-referrer" } });
    }

    if (seg.length !== 2) return new Response("not found\n", { status: 404 });
    const [kind, id] = seg;
    if (!["page","img"].includes(kind) || !ID.test(id)) return new Response("not found\n", { status: 404 });
    const obj = await env.ARTIFACTS.get(kind + "/" + id);
    if (!obj) return new Response("not found\n", { status: 404 });
    const h = new Headers();
    obj.writeHttpMetadata(h);
    h.set("etag", obj.httpEtag);
    h.set("cache-control", "private, max-age=300");
    h.set("x-content-type-options", "nosniff");
    h.set("referrer-policy", "no-referrer");
    return new Response(req.method === "HEAD" ? null : obj.body, { headers: h });
  }
};
