# Web authentication with agent-browser

Use this reference only when the Web criterion is behind a login gate.
Authenticate the same named `agent-browser` session that will capture evidence, so
the evidence shows that the automated session reached the state.

This workflow is provider-neutral. Discover the target's actual endpoint, cookie
domain, and session mechanism before selecting a path.

## Decision flow

1. Open the protected target. If it renders without a login wall, stop here.
2. Sign in through a named session or a state file; use credential replay or the
   app's sign-in API when the app requires it.
3. Reopen a protected URL and verify that `agent-browser get url` did not return
   the sign-in route before capturing evidence.

## Built-in mechanisms

```bash
# Named session: persists cookies and localStorage.
agent-browser --session app open https://app.example.com/login
# Complete login once, then reuse the same session.
agent-browser --session app open https://app.example.com/dashboard

# Playwright-style storage state, kept in the round directory.
agent-browser state save "$REPORT_DIR/auth.json"
agent-browser state load "$REPORT_DIR/auth.json"

# Encrypted credential vault and form replay.
echo "$PASSWORD" | agent-browser auth save app \
  --url https://app.example.com/login --username user --password-stdin
agent-browser auth login app

# Dedicated persistent browser profile.
agent-browser --profile "$REPORT_DIR/browser-profile" open https://app.example.com/login
```

## Programmatic login

If the app exposes a sign-in API, POST credentials, capture the returned cookies,
write them into a storage-state file in the round directory, and load that state
into the evidence session. Endpoint shape, field names, and cookie names are
app-specific; inspect them in the app.

## Security boundaries

- Do not move production session cookies into automation state.
- Treat credentials, cookies, and tokens as secrets. Never place them in logs,
  evidence, commits, or PR descriptions.
- When the criterion is the sign-in UI itself, drive the real form.

Return to the selected Web flow after the authenticated session passes its
protected-route check.
