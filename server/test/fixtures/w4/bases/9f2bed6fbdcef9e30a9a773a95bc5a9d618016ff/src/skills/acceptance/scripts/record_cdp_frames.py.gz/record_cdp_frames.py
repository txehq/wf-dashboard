# /// script
# dependencies = []
# ///

import argparse
import subprocess
import time
from pathlib import Path

parser = argparse.ArgumentParser(
    description="Capture a numbered renderer frame sequence through agent-browser at a fixed interval."
)
parser.add_argument("--surface", required=True, choices=["web", "electron"])
parser.add_argument(
    "--target",
    required=True,
    help="web: the agent-browser session name; electron: the CDP port",
)
parser.add_argument(
    "--out",
    required=True,
    type=Path,
    help="frame directory to create; it must not exist yet",
)
parser.add_argument("--frames", required=True, type=int, help="number of frames to capture")
parser.add_argument("--interval", required=True, type=float, help="seconds between frames")
args = parser.parse_args()

# web 连接命名 session，electron 连接 app 打开的 CDP port
connection = ["--session", args.target] if args.surface == "web" else ["--cdp", args.target]

# 目录已存在时 mkdir 直接报错，保证每段录制使用新的帧目录
frame_dir = args.out.resolve()
frame_dir.mkdir(parents=True)

for index in range(args.frames):
    frame = frame_dir / f"frame_{index:06d}.png"
    subprocess.run(["agent-browser", *connection, "screenshot", str(frame)], check=True)
    time.sleep(args.interval)
