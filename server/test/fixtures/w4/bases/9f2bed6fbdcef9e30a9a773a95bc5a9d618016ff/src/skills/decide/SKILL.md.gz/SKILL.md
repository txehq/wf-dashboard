---
name: decide
description: Use when several open questions need the user's decisions and the user should pick from options — open design questions, unresolved gaps in a spec, a review that ended in "needs a call". Produces a selectable decision page, reads the selections back, and folds them into the governing documents.
---

# /decide — converge options, publish a ballot, fold the answers back in

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/Decision Ballot.md` (WF-BALLOT).
Where this file and the spec disagree, the spec wins: update this file to match it.

The deliverable is the updated decision and spec documents; the page is the auditable record
of what was offered and chosen.

---

## 1. When this applies — and when it does not

**Yes** when all three hold:
- Two or more open questions, each with **enumerable options** (2–4 real candidates).
- The decisions have a **durable home** — a decision doc, a spec, an ADR — that must be
  updated once chosen. No home yet? Create the home first; a ballot with nowhere to fold
  into is a survey.
- The decider decides; you recommend. If you can decide it yourself under standing
  authority, decide it and record it.

**No** when: one question (ask it in chat, with a recommendation); options cannot be
enumerated (that is a brainstorm); or the "options" are all the same choice dressed
differently.

---

## 2. Converge BEFORE the page

`.decide/` is this skill's working directory: create it with a `.gitignore` containing `*`
before writing its first file.

1. **Draft 2–4 options per question, the recommended one with its reason**, and write the
   draft to `.decide/draft.md`, the input to review.
2. **Adversarial consult.** Send `.decide/draft.md` to the standing reviewer, Codex, with
   `codex exec -s read-only`. Ask it to attack each recommendation, state amendments
   precisely, and — where you end up agreeing — state the **converged proposal in 2–4 plain
   sentences**.
3. **Converge.** Where the reviewer wins, your option changes and the page never shows
   the argument. Where you genuinely disagree, BOTH positions go on the page as separate
   options with the disagreement named in one line — the decider breaks ties.

**The page carries converged proposals only.** Do not add "my comment / reviewer comment"
columns. The full argument stays in the consult files under `.decide/`.

---

## 3. The page

Write the page to `.decide/ballot.html`. Structure per question, in this order, mirroring how
ballots read:

| Element | What it holds |
|---|---|
| id + short title | what is being decided, in the decider's language |
| one-line stake | why this needs them |
| 2–4 radio options | converged proposals; the recommended one FIRST and tagged; each option = bold claim + 1–3 sentences of consequence |
| optional notes box | free-text per question, for amendments |

Page-level: a running "N of M chosen" tally; a final **"Submitted — fold these in"**
checkbox row at the bottom (that checkbox is the signal the set is final, distinguishing
a browse from a decision); severity/dependency ordering if some answers constrain others,
with the dependency stated on the dependent question.

Craft rules come from `artifact-design` (load it; both themes, tokens on bare `:root`)
— this skill owns only the ballot shape.

---

## 4. Transport

**All pages — ballots included — publish to engapp.dev via `/publish-artifacts`. The
claude.ai `Artifact` tool is not used for this org's work.**

Pages on engapp.dev are static objects, and the write credentials never ride in a page, so
read-back goes through the **export block**:

- Selections + notes persist to `localStorage` (survives reload in that browser).
- A **"Copy selections"** button serializes the ballot — `Dn -> [value]`, notes, and the
  Submitted flag — into a textarea and the clipboard. The decider pastes it into chat.
- The **Submitted: YES** line in the pasted block is the finality signal. A pasted block
  without it is a browse: ask the decider whether the set is final, and fold nothing before
  they confirm.
- Publish with `ARTIFACT_VIA=decide` so ballots are distinguishable in `_meta.json`.
- Revisions republish with `--id <same 8-char id>` — a moved link forks the record.

**Never** embed the engapp upload credentials in a page to fake a write path — a page
that carries them hands publishing to every reader.

## 5. Folding back in — the deliverable

On receiving the pasted selections:

1. **Echo the picks** in one compact block and note any that diverge from the
   recommendation — divergences deserve one sentence of acknowledgment, and a note field
   may modify the option (record the synthesis of option and note as what they *meant*,
   verbatim where it matters).
2. **Write each decision into its owning document** as a **dated decision-log entry**:
   what was decided and the rationale (from the converged proposal). Supersede prior
   entries with a marker, and keep the trail.
   ⚠️ **That trail discipline is for DESIGN documents only**: orientation surfaces —
   primers, business docs, briefs — get a clean current-truth rewrite with no banners,
   strikethroughs or "superseded" annotations, because an edit trail there creates
   confusion. History lives in the decision log, the present lives everywhere else.
   Before folding into ANY existing document, read it whole: a head-and-tail read misses
   a contradicted claim in its middle.
3. **Sweep the stale surfaces.** Every supersession leaves at least one of these wrong:
   the document's **summary/callout block**, its **open-questions list**, and
   **cross-references in sibling documents** (including diagram labels and headlines,
   which regress even when body prose is corrected). Grep for the superseded claim's
   *class*. Sweep these classes as well:
   - **Implementing tickets that PARAPHRASE the governing docs.** A stale paraphrase gets
     the superseded design built by its assignee. Every ticket paraphrase ends with a
     pointer to its governing doc, and the sweep visits the *implementing* tickets as well
     as the ones that recorded the decision.
   - **Published explainer/summary pages.** A page that quotes a superseded formulation
     carries the exact stale sentence. Sweep and republish to the same id.
   - **Anything outside the audit boundary.** Rot concentrates in surfaces the fold
     process never lists — orientation briefs, primers, business docs. At fold time,
     enumerate EVERY surface that states the decided thing, then sweep that list.
4. **Verify closure on the folded text itself.** Corrective text reliably carries a
   fresh defect of the class it corrects. After folding, have the standing reviewer
   confirm each item is *closed by the landed text* before calling the set done.
5. **Close the loop**: update tracker items that carried the open questions; tell the
   decider what landed where, in a table with the columns question, document and entry.

---

## 6. Anti-patterns

- **The survey.** A page with no owning documents to fold into. Build the home first.
- **The transcript ballot.** Options annotated with the reviewer debate. Converge first;
  the page shows conclusions.
- **Acting on an unsubmitted ballot.** Selections without the submitted flag are a
  browse. Ask the decider whether the set is final.
- **Free-deciding disguised as a ballot.** If standing authority covers it, decide and
  record.
- **Folding into chat only.** A decision that lives in the transcript does not exist
  next month.
- **A second page for the same decision set.** Republish the same artifact; a moved link
  forks the record.

---

## Self-improvement

When a run shows that the ballot shape fought the decider (order, tags, notes), that the
transport gained a new fact (a capability change, an engapp write path), that read-back
parsing hit a markup shape this file does not cover, or that the fold-in sweep found a
stale-surface class §5.3 does not list, change this file through a pull request, following
the change-a-skill runbook.
