---
name: readiness
description: Verify this machine can actually do a ticket's work before any code is written — toolchains at the versions the repo pins, the services the ticket needs, and credentials checked for the capability they must carry. Use at the start of an IC session, when a build or test fails for an environment-shaped reason, after switching branches or machines, or whenever someone says "works on my machine".
---

# /readiness — verify the substrate before writing code

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/Readiness.md` (WF-READY).
Where this file and the spec disagree, the spec wins: update this file to match it.

The session starts on a verified substrate. This runs between `/ic` and the first line of
code, and again whenever something fails in a way that smells environmental.

| Command | What it does |
|---|---|
| `wf readiness` | check, using the cache |
| `wf readiness --repair` | check, and also install what is missing |
| `wf readiness --force` | check, ignoring the cache |
| `wf readiness --json` | check, printing the verdict as JSON |

Add what this ticket needs beyond the repo's baseline; `--need` takes a toolchain or a service:

```bash
wf readiness --need postgres --need redpanda --need bazel --need 'cargo>=1.85'
wf readiness --need postgres --compose deploy/docker-compose.local.yml
```

| Flag | What it does |
|---|---|
| `--compose <path>` | the compose file that defines the services asked for, relative to the repo root |
| `--agent <id>` | the agent the work runs in (`claude-code`, `codex`), when the command runs outside it |

## What it actually checks, and why each one earns its place

`wf` is a single precompiled binary, so there is no build step and no bootstrap script.

**Toolchains, in three contexts.** The check is whether a tool resolves in *the shell that
will run it*: Homebrew, `pyenv`, `nvm`, `asdf`/`mise` and `rustup` all install behind a profile
edit or a shim.

| context | stands for |
|---|---|
| session | what your tool calls see right now |
| login (`$SHELL -lc`) | what the developer sees when they type the command |
| minimal (`env -i`) | what a hook, a cron job or a bare spawned process sees |

A tool the login shell finds and the session does not is a **`TOOL-CONTEXT` failure with
the resolved path and the PATH edit**.

**Versions, derived from the file that already pins them.** `go.mod` states a floor;
`rust-toolchain.toml` and `.bazelversion` state pins, so a *newer* rustc or Bazel fails —
local and CI must resolve one compiler and one Bazel.

A tool is accepted under any of its real names: `bazelisk` satisfies the Bazel requirement,
because it *is* the launcher and reports the version it will run. Version probes execute in
the repo root, since rustup and bazelisk both resolve per-directory.

**Services the ticket declares.** The ticket's declaration makes a service a requirement, and
the compose file says how to reach it. A known toolchain, a tool the manifest declares and a name
with a version (`'cargo>=1.85'`) are tools and never read compose; `node`, `pnpm` and `bazel`
alone run in a repo with no compose file at all. Any other name is a service when compose
defines it, a tool when the session's `PATH` has it, and otherwise an error.

The compose file is the first of:

1. `--compose <path>`;
2. `services.from` in the manifest;
3. `compose.yaml`, `compose.yml`, `docker-compose.yaml` or `docker-compose.yml` — Compose's own
   names, in its order of preference — in the repo root, then `deploy/`, `deployments/`,
   `docker/` and `.devcontainer/`. The first directory holding one wins.

A service asked for with no compose file found fails with exit code `2` and names every place
it looked. A declared service that the compose file does not define is a hard error: name the
file that defines it with `--compose`.

Docker Compose itself reads the file (`docker compose -f <file> --profile '*' config --format
json`), so `${VAR:-default}`, the project's `.env`, `extends`, `include` and profiles mean what
they mean to `docker compose up`. Which names are services is read without interpolation; how
each one is reached is read with it, and a variable Compose cannot resolve — sub2api's
`POSTGRES_PASSWORD` before `deploy/.env` exists — is an `SVC-CONFIG` failure that quotes
Compose and points at that `.env`. A service published on a host port is probed there. A
service with no host port lives only on the compose network, so its container must be running
and, when it declares a healthcheck, healthy (`docker compose ps`). Either way a down service is
`SVC-DOWN`, and the reversible repair runs `docker compose -f <file> up -d --wait <service>`,
which returns once the container is healthy.

**Required components.** Linear reaches a session as the `capso-linear` MCP server that `wf`
writes into each agent (`capso.mcp.linear`), and without it a session cannot file, claim or
close a ticket. The manifest lists such registry components under `components:`, and the check
reads the agent's own configuration against the release `wf` installed, the way `wf status`
does. The agent is the one whose session runs the command — Claude Code sets `CLAUDECODE`,
Codex sets `CODEX_THREAD_ID` — or the one `--agent` names; run from a plain terminal, every
agent `wf` manages on the machine must carry the component. Only the entry this release
installs counts: a missing one (`COMPONENT-MISSING`) or a changed or older one
(`COMPONENT-DRIFT`) fails with `wf repair --component <id> --agent <agent>`; one the person
declined (`COMPONENT-DECLINED`) fails with `wf mcp unskip <id> --agent <agent>` followed by
that repair; a machine without `wf` fails with `wf install`. *In place* is all this checks: the server logs in through the browser on its
first call, so an object in place is never reported as a login that works.

**Credentials, by capability.** The check asks whether a credential can do the thing: scopes
are read where the provider discloses them, and a fine-grained token with no scope list
reports as **unverified**. Token values are never printed or stored; the state file keeps a
salted digest, which shows when a token was rotated.

## Reading the result

- `✓ ready` — proceed.
- `✗ NOT READY` — each blocking finding names its code, the subject, and the exact command.
- **warnings** leave the verdict ready and point at a later failure, usually your terminal and
  the session running different binaries.
- **resolution notes** record where each tool came from. This is what you re-read when a
  hook fails and everything "works" interactively.

Exit codes: `0` ready · `1` not ready · `2` the checker could not run.

## Repair — three tiers, by blast radius

1. **Reversible** — starting services, pulling images. Runs automatically.
2. **Install** — a missing toolchain. Runs only with `--repair`, and leaves a global version
   you pinned in place.
3. **Manual** — credentials and PATH edits. Printed for the person to run. A session does not
   edit someone's shell profile or mint a token on their behalf.

After a repair it re-checks **once** and reports the second verdict, so a repair that does not
fix what it claims to shows in that verdict.

## It does not run every session

An unchanged machine spawns **no processes**. A stat-only fingerprint (PATH, plus size, mtime
and inode of every resolved binary, plus a hash of the requirement sources) decides whether to
skip; network-backed checks additionally expire on a TTL, because a token is revoked
server-side with nothing local changing. Asking for a service adds one process: Compose
resolves its file against this environment and the project's `.env`, and a salted hash of
that result is part of the fingerprint, so an unset variable or a changed port re-runs the
check instead of reusing a pass.

The cache may only ever **skip a pass**. A recorded failure always re-runs, because you may
have fixed it by hand. When it re-runs it says why: `checking — go.mod changed`.

## Declaring what no file states

Most requirements need no declaration. A manifest covers the rest, and it is looked for in
this order:

1. `readiness.yaml` in the repository being checked — for a repo that wants the declaration
   next to its code;
2. **`manifests/<owner>/<repo>.yaml` shipped with the workflow** — the default. A manifest
   describes what a *machine* needs in order to work on a repo, which is workflow tooling, so
   the target repo carries nothing and runs no CI for a file none of its own code reads.

A manifest named with `--manifest` that does not exist is an error.

```yaml
version: 1
toolchains:
  - id: go
    version_from: go.mod # the version comes from the file that pins it
  - id: docker
    min: "24.0" # nothing in the repo pins it
services:
  from: deploy/docker-compose.yml # optional; discovered when absent
  need: [postgres, redpanda] # the compose file supplies the ports
components:
  - capso.mcp.linear # the Linear MCP server wf installs
credentials:
  - id: github
    env: [GH_TOKEN, GITHUB_TOKEN]
    capabilities: [repo, workflow]
```

A `version_from` pointing at a file that cannot be read is a **hard error**.

## The rule that makes this worth running

**A requirement discovered mid-task that none of the ticket, the manifest or the repo
declared is a ticketing defect.** File it back. Do not silently work around it: a readiness
stage exists so the next person meets a declared environment.
