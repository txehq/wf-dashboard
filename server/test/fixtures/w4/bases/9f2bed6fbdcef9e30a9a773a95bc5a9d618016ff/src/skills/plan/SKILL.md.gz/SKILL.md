---
name: plan
description: "Stage 3 of /lfg — turn the research into an implementation plan the way Claude Code plans, without entering plan mode: write the draft, put the implementation-detail questions to the user, hand the draft to a Plan agent to review and optimize, triage its findings, then hand the plan to the human for review and lock it into the feature's master document. Use after /research produced Research.md, or when someone says \"plan this\", \"how would you implement this\", \"write the implementation plan\", \"review my plan\"; invoke it proactively, saying so in one line, when research exists and no locked plan does. Never call EnterPlanMode or ExitPlanMode: the plan is a document in the vault."
---

# /plan — draft, review by an agent, review by a human, lock

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/LFG Session.md` (WF-LFG,
stage 3 — the corpus has no separate node), bound by
`Project Magi/Workflow/Decisions/Planning Corpus Standard.md` for the layout and the
convergence process. **Question bank:** Phase 4 of
[`skills/interview/references/question-bank.md`](../interview/references/question-bank.md).

Do not call `EnterPlanMode` or `ExitPlanMode`. The plan is a document in the vault that a
person reads and approves, and its gate is the human review in §4.

## Contract — what goes in, what comes out

| | |
|---|---|
| **In** | `Project <Product>/Features/<slug>/Research.md` (its parts, criteria and open decisions) and `Brief.md` (boundaries, authority ceiling); the repository checkout |
| **Out** | the **locked plan**, written into the feature's master document — the *Plan* section of `Research.md` at single-document scale, `System Design.md` at design-corpus scale — with a dated lock entry in its decision log; the decision ledger updated |
| **Next** | `/ticketing` selects tickets from the plan's parts |

The plan lives in the master document, and is reviewed and locked there: System Design §7
(ballot F27) fixes the feature folder's files.

## When this skill starts

- **On request:** `/plan`, or "plan this", "how would you implement this", "write the
  implementation plan", "review my plan".
- **From `/lfg`:** as stage 3, with the research's path.
- **Proactively:** `Research.md` exists and its plan is not locked. Say "running /plan" and
  begin.
- **Not** without research → `/research` first; a plan without evidence is the guess the
  research exists to replace.

## 1. Draft — from the research, down to the change itself

Start from the research's *Plan* section and take it one level down, to what an engineer
would open a ticket against. Work on a copy of the master document at `.plan/research.md`
(`.plan/system-design.md` at design-corpus scale), creating `.plan/` with a `.gitignore`
containing `*` before its first file, and write the draft into its *Plan* section in the
user's language, in this shape:

```markdown
## Plan
**Status:** draft · **From:** Research.md §Plan · **Brief:** <path>

### Goals and non-goals
<done-means from the brief; the out-of-scope list, verbatim>

### Approach
<the chosen shape and why>

### Parts, in order
For each part:
- **Outcome** — the observable behaviour when it is done
- **Changes** — modules, files, contracts, migrations touched; what is reused from §Local findings
- **Depends on** — parts that must land first
- **Verification** — the tests and checks that prove it, and the acceptance evidence required
- **Criteria** — inherited from Research.md, with verification method

### Decisions
<the ledger: confirmed · delegated (default stated) · deferred>

### Risks and rollback
<what could invalidate the plan, the probe that tests each risk, how each part is undone>

### Open for ticketing
<what /ticketing still has to decide: slice boundaries, cross-cutting work, release gates>
```

Plan each part with particular care for the system's architecture and its verification: a
design that stays clean and maintainable, and tests that cover every requirement the part
carries, derived by whichever of equivalence partitioning, boundary-value analysis, decision
tables and state transitions fit its behaviour.

Every step names a behaviour, and every part names its verification. Nothing outside the
brief's boundaries appears, even as "while we're here".

## 2. Ask back about implementation details

Planning's Q&A phase. Put to the user the questions the research could not close and the
draft surfaced — Phase 4 of the interview bank, each question's goal thought and never shown:
the decision criteria (speed, simplicity, maintainability, consistency, performance, cost);
the viable approaches with a marked recommendation, stated as observable behaviour, migration
cost, compatibility, risk and long-term ownership, each one a complete design; where
state, validation, authorization and side effects live; the guarantees the design must give;
how it is introduced (replacement, migration, shadow, flag, canary, staged). Weigh the
approaches against the quality attributes of ISO 25010 that matter here, and record the chosen
one under the plan's *Decisions* as an ADR: context, options, decision, consequences.

- Three to five questions per batch, blockers first, ordered by dependency.
- Several questions with enumerable options → one `/decide` ballot, folded back when answered.
- A scope question goes back to the brief, and the user is told so.
- Fold each answer into the draft and the ledger as it arrives.

## 3. Review by a Plan agent and by Codex

Hand the draft, the brief, the research and the repository to a **Plan agent** — Claude Code's
`Plan` sub-agent, or the equivalent — with one instruction: review this plan against the
criteria and the codebase, and return findings plus an optimized plan. It is to check, at
least:

- **completeness** — every criterion in the research maps to a part; every part to a
  verification;
- **feasibility** — the changes named exist where the plan says, and the reuse it claims is
  real (the agent reads the code to confirm both);
- **sequencing** — dependencies are honoured; the first part is the smallest slice that
  proves value;
- **scope** — nothing crosses the brief's boundaries, nothing the brief requires is missing;
- **assumptions** — anything the plan takes for granted that no evidence supports, named.

The same review prompt goes to Codex with `codex exec -s read-only`, so that a model other than
the author reviews the plan. **Triage the findings.** Fold
each accepted finding into the plan; a dropped finding leaves no record. Repeat §2–3 until
neither the user nor a review pass changes the plan.

## 4. Review by the human — then lock

Present the converged plan to the user for review: the file path, and in chat the approach,
the parts in order with their verification, the decisions taken and the risks — compact
enough to read in one sitting, with nothing that is only in the file. Ask the one question the
gate exists for (the bank's A6): *this is the plan, with these remaining risks — do you
approve it?* Edits are folded and the question asked again; approval is explicit.

On approval, **lock**: set the plan's status to `locked · <date>`, add the dated lock entry,
naming the reviews that ran, to the master document's decision log, and write it back:

```bash
wf obsidian --kind research --product "<Product>" --feature "<slug>" --file .plan/research.md \
  --title "<feature> — research" --replace
```

(at design-corpus scale, `--kind design` and `.plan/system-design.md`). Later changes to a
locked plan are dated entries. Echo the path; `/ticketing` reads it next.

## Not this

- Finding the evidence the plan rests on → `/research`.
- Splitting the locked plan into Linear tickets → `/ticketing`.
- Two or more open decisions with enumerable options and nothing else pending → `/decide`.
