# macOS Computer Use (osascript) toolkit

`agent-browser` drives Chromium surfaces (web, Electron). **macOS Computer Use**
via `osascript` (AppleScript) and `screencapture` reaches everything else: use it
to drive native apps, handle OS-level chrome, and read the screen when no CDP
target exists.

It is **macOS-only and not cloud-portable**. Use it for a target CDP cannot reach.

## Contents

- [When you need it](#when-you-need-it)
- [Core patterns](#core-patterns)
- [Capturing as evidence](#capturing-as-evidence)
- [Gotchas](#gotchas)

## When you need it

- **Native (non-Chromium) app under test** — the thing you're verifying is a native
  macOS app a Chromium driver cannot attach to. Drive it here.
- **OS-level steps inside a web/Electron flow** — a native file picker, a system
  permission prompt, a Save dialog, dock/menu-bar interaction, or a Spotlight/
  app-switch the page can't script. Drop to Computer Use for that step, then return
  to agent-browser.
- **Reading the screen** when no DOM/CDP is available — screenshot + visual read, or
  select-all-copy + `pbpaste`.

## Core patterns

### Activate an app

```bash
osascript -e 'tell application "AppName" to activate'
```

### Type / press keys

```bash
osascript -e 'tell application "System Events" to keystroke "Hello world"'
osascript -e 'tell application "System Events" to key code 36' # Enter (hardware code, layout-independent)
osascript -e 'tell application "System Events" to key code 48' # Tab
osascript -e 'tell application "System Events" to key code 53' # Escape
```

### Paste from clipboard (required for long / non-ASCII text)

```bash
osascript -e 'set the clipboard to "Your long or 中文 / emoji message"'
osascript -e 'tell application "System Events" to keystroke "v" using command down'
```

### Keyboard shortcuts (modifiers)

```bash
osascript -e 'tell application "System Events" to keystroke "f" using command down'               # Cmd+F
osascript -e 'tell application "System Events" to keystroke "k" using {command down, shift down}' # Cmd+Shift+K
```

### Click at screen coordinates

```bash
osascript -e 'tell application "System Events" to click at {500, 300}'
```

### Window position / size / id

`scripts/window-geometry.applescript` takes the process name and the window number:

```bash
osascript "$SKILL_DIR/scripts/window-geometry.applescript" "AppName" 1
```

### Screenshot (OS-level)

```bash
screencapture "$REPORT_DIR/assets/shot.png"                 # full screen
screencapture -i "$REPORT_DIR/assets/shot.png"              # interactive region select
screencapture -l "$WINDOW_ID" "$REPORT_DIR/assets/shot.png" # specific window
```

Get a window id:

```bash
osascript -e 'tell application "System Events" to tell process "AppName" to get id of window 1'
```

### Read accessibility elements

`scripts/read-text-field.applescript` takes the process name, the window number, and
the text field number:

```bash
osascript "$SKILL_DIR/scripts/read-text-field.applescript" "AppName" 1 1
```

> `entire contents of window 1` dumps the whole UI tree and is **extremely slow** on
> complex apps. Read the screen with a screenshot and a visual read, or with the
> clipboard read below.

### Read screen text via clipboard

`scripts/copy-screen-text.applescript` activates the app, then selects all and
copies; `pbpaste` reads the copied text:

```bash
osascript "$SKILL_DIR/scripts/copy-screen-text.applescript" "AppName"
sleep 0.5
pbpaste > "$REPORT_DIR/assets/screen-text.txt"
```

## Capturing as evidence

- Record a `screencapture` PNG as `{ "type": "screenshot", "by": "cli" }` in the round.
- For time-based native behavior, OS screen-record to MP4/GIF — see
  [recording-native-macos.md](./recording-native-macos.md).
- Save text read via `pbpaste` under `assets/` and record it as `{ "type": "text", "by": "cli" }`.

## Gotchas

- **Accessibility permission required.** First run prompts for it; grant the host
  (Terminal, iTerm or the agent runner) in the Accessibility list under Privacy &
  Security in System Settings, or every `System Events` call silently fails.
- **`keystroke` is slow and mangles non-ASCII** — use clipboard paste (`Cmd+V`) for
  anything long or for Chinese / emoji / special characters.
- **`key code 36` is Enter** by hardware code, so it works regardless of keyboard
  layout. Some apps send-on-Enter — use `Shift+Enter` for a newline within input.
- **Add a `delay`/`sleep` of about 0.5 seconds between actions** — native apps need
  time to process UI events; back-to-back commands drop.
- **App name varies by locale** — e.g. `微信` or `WeChat`; handle the name the
  running OS uses.
- **Not cloud-portable.** Everything here needs a real macOS session with a display.
  Keep evidence CDP-based when the target is reachable that way.
