# Supplied plans - preserve intent and check coverage

Use this path when given a plan file, exported verify state, or explicit criteria
in a PR/Issue. Read that artifact directly. An operation id is provenance only:
do not query LobeHub for it. If only an id is supplied, ask for the plan contents
or location while continuing independent preparation. Do not invent criteria.

An exported plan can have this upstream shape:

```json
{
  "verifyStatus": "planned",
  "verifyPlanConfirmedAt": "2026-09-06T07:00:00Z",
  "verifyPlan": [
    {
      "id": "vci_a1b2c3",
      "index": 0,
      "title": "Login reaches the workspace",
      "description": "After sign-in the home renders the workspace switcher",
      "required": true,
      "verifierType": "llm",
      "verifierConfig": {
        "requiredEvidence": [
          {"type": "screenshot", "hint": "Logged-in home with workspace switcher"}
        ]
      }
    }
  ]
}
```

Map it into `result.json` from [report.md](report.md):

| Supplied field | Local field |
| --- | --- |
| `verifyPlan[].id` | `plan[].id` and `cases[].id`, unchanged |
| `title`, `description` | `title` and `expected`, preserving meaning |
| `required` | `required`, unchanged |
| `verifierType` | `verifier` |
| `verifierConfig.requiredEvidence[].type` | `requiredEvidence[]` |
| `requiredEvidence[].hint` | Preserve beside method or in `evidenceHints` |

`index` gives the order; join on `id`. Preserve the original exported plan in the
round and include it in the report. Record the chosen capture method without
changing the expected outcome. Keep missing checks visible.

Capture every declared type with the surface guide. Store artifacts in `assets/`
with explicit `type`, `by`, and description, joined to the stable id. An empty
`requiredEvidence` means the deliverable text can suffice; do not fabricate media.

Use the same complete HTML publication flow as authored rounds. Confirm each
required type is present, nonempty, inspected, and accessible from the published
page. Missing evidence is `uncertain`; blocked execution is `blocked`. Return
coverage and engapp.dev URL.
