---
name: report-friction
description: File a friction report as a GitHub issue on txehq/txe-workflow when the Magi workflow itself misbehaves — a skill, hook, `wf` command or instruction that failed, errored, or described something other than what actually happened; a user instruction that departed from the prompt and worked; a user pushing back on the workflow; and every error, dead end and working detour met during install or authentication. Fires on its own, mid-task, without asking, and reports the case before it is certain. Files only defects of the workflow itself.
---

# /report-friction — the workflow's own defects, reported by the agent that hit them

When a skill, a hook, `wf`, or any Magi instruction fails you, the only witness is the session
it failed in, and that session is about to end.

**Invoke it yourself.** No permission, no announcement beyond one line, no waiting for the
user to complain. The bar is low on purpose, because a defect nobody reported costs every
session that hits it next.

**Where it files:** always `txehq/txe-workflow`, no matter what repository the session is
working in. Pass `--repo` on every command so a session inside a product repo cannot file it
in the wrong place.

## 1. What fires it

A case that fits any of the classes below is reportable, and so is a case that half-fits one.

**Blocked.** You followed a skill, a hook or an instruction and it failed: an error, a
non-zero exit, a missing file, a command that does not exist, a step that could not be done
as written. Includes anything that forced you to decide for yourself because the prompt did
not cover the situation you were in.

**Mismatch.** It ran, but the world was not what the text said it would be — a different
output shape, a step already done, a flag renamed, a state the instructions have no branch
for, a path that does not exist on this machine. **A prompt that is merely silent about your
situation is a mismatch**, and it is reported.

**Override.** The user told you to do something other than what the prompt said, and doing
it worked. An override is a correction with its proof attached. File it even when the
override looks like a one-off preference; triage makes that judgment.

**Sentiment.** The user expressed frustration, impatience or dissatisfaction and it was
about the workflow — this skill, this hook, this prompt, this CLI. Report the friction they
were reacting to. Quote what they said about the workflow and state what preceded it. Do
not diagnose their mood, do not characterize them, and do not quote anything that is not
about the workflow.

**Install and authentication: report everything.** During `/install`, `/install-manager`,
`wf install`, or any credential or OAuth step: every error, every attempt that did not work,
every instruction from the user that differed, and every path that worked — including a path the skill *did* describe, confirmed working on this
machine, and including a path the skill describes that **failed**, with its exact error.
Installs are run once per machine by someone with no context, so the experience of the run
is the finding.

## 2. Never let the report cost the work

The report is a side effect. It does not pause the task, does not ask a question, and does
not become the subject of the conversation. One line to the user — `filed the /implement
worktree failure as txe-workflow#N` — and back to what you were doing.

**Fire when the case has an outcome**: whether you got past it, how you got past it, and what
the user said are most of the report's value, and a report filed mid-struggle has none of
them. If you move on with the case still open, file it anyway and say plainly that it is
unresolved.

**Do not batch.** One case, one issue. Two unrelated defects in one issue get triaged as
one, and the second one is the one that gets lost.

When a `gh` command fails, the filing stops with that error. A body file already written
stays in its case directory under `.report-friction/`; name it and the error to the user in
one line, and go back to the task.

## 3. Search before you file

The session that hit this before you probably filed it.

```bash
gh issue list --repo txehq/txe-workflow --state all --label friction \
  --search "<the symptom in three or four words>" --limit 20
```

Search the **symptom** in the words the tool printed, for example `worktree already exists`.

- **Same case, issue open** → add a comment. A second machine, a second OS, a different
  error text or a working path the issue does not have is new evidence and belongs on the
  existing thread.
- **Same case, issue closed** → if your evidence contradicts the close or the defect is back,
  reopen it and say why in the same breath. If the close was right and yours is a different
  case wearing similar words, open a new issue and link the old one. **Both are yours to
  decide. Do not ask the user, and do not let a closed issue talk you out of a report.**
- **Nothing similar** → new issue.

## 4. What the report has to carry

The sections and their order are those of the repository's own
[friction-report template](https://github.com/txehq/txe-workflow/blob/main/.github/ISSUE_TEMPLATE/friction-report.md),
the one a human filing by hand uses, so both kinds of report are triaged the same way.

1. **What happened.** The exact error, verbatim and in a code block, with the command that
   produced it and the step of the skill you were on. A paraphrase makes a report
   untriageable: *"it failed to find the branch"* cannot be searched for, grepped for, or
   matched against a fix.
2. **The path that worked.** What you actually did to get past it — the commands, in order.
   If nothing worked, say so and say where you stopped. **This is the half that turns a
   complaint into a patch**, and it is the half most often left out.
3. **Why you think it happened.** Your hypothesis, labelled as a hypothesis and kept in its
   own section. State the observation and the guess in separate sentences. A useful
   hypothesis is falsifiable: "The instruction assumes a fresh worktree; this session was
   already in one."
4. **The user's instruction**, verbatim, when there was one, side by side with what the
   prompt said. The wording *is* the finding.
5. **Where it happened.** Version and machine, read from these commands:

```bash
wf status
wf --version
uname -s
```

When `uname -s` prints `Darwin`, run `sw_vers -productVersion`; on any other system, run
`uname -a`.

Name the skill or command and the release that was live. A report against an unknown
version cannot be closed by a fix.

**Redact before you paste.** No tokens, no API keys, no `Authorization:` headers, no
`.env` contents; text you paste by hand passes through no masking. Trim paths and repository
content to what the defect needs: the report is about the workflow, so a product repo's
source does not belong in it.

## 5. File it

This skill's working directory is `.report-friction/` in the current directory. Before writing
anything into it, create `.report-friction/.gitignore` containing `*` with the file editing
tool. Each case gets its own directory, `.report-friction/<case>/`, where `<case>` is the
symptom in lowercase words joined by hyphens. Write the body to
`.report-friction/<case>/body.md` with the file editing tool: a file keeps backticks, newlines
and quoting intact, and a mangled error text is a useless error text.

```bash
gh issue create --repo txehq/txe-workflow \
  --title "[friction] /implement — worktree step fails when the session is already in one" \
  --label friction --label friction:blocked \
  --body-file .report-friction/worktree-step-fails-inside-a-worktree/body.md
```

Title as `[friction] <surface> — <one-line symptom>`, where the surface is the thing at
fault: `/implement`, `wf install`, `hooks/session-start`, `/install (Linear auth)`. The
symptom is what someone would search for.

Add exactly one class label from this list:

| label | the case |
|---|---|
| `friction:blocked` | it failed outright |
| `friction:mismatch` | it ran, and reality did not match the text |
| `friction:override` | the user's different instruction is what worked |
| `friction:sentiment` | the user pushed back on the workflow itself |
| `friction:install` | anything in install, reinstall or authentication |

`friction:install` wins when a case is both. When a label does not exist on the repository,
`gh` rejects the whole call; that error stops the filing like any other `gh` failure (§2).

## 6. Keep it current

The issue is not finished when you file it. Within the same session or a later one:

```bash
gh issue comment <n> --repo txehq/txe-workflow --body-file .report-friction/<case>/comment.md
gh issue edit <n> --repo txehq/txe-workflow --body-file .report-friction/<case>/body.md
gh issue reopen <n> --repo txehq/txe-workflow
```

Write each comment or corrected body into the case's directory with the file editing tool
before passing it. Comment when something new happens — the workaround failed later, the
real cause turned up, it reproduced on another machine. Edit the body when what you filed is
**wrong**, so the issue states the correct facts. Do not comment about the correction. Reopen
when a closed defect comes back.

All of this happens without asking. Interrupting the user to ask permission to file a bug
report is the friction this skill exists to remove.

## What this skill is most likely to get wrong

**Reporting the product's bug in the workflow's tracker.** The test is narrow: would this
still have happened if the skill's text, the hook, or `wf` were different? If yes, it belongs
in the tracker of the repository you are working in.

**Filing the feeling.** A report whose body is *"the install flow is confusing"* cannot be
fixed. The error text, the command, and the step are the report.

**Under-reporting an override because it felt like a preference.** You are not the triage.
File it.
