---
last-verified: 2026-09-16
---

# txe-workflow

The **Magi engineering workflow**: the skills that walk a unit of work from an intent to
production, the contract they answer to, and `wf` — the local manager that keeps every
machine carrying the same version of them.

These files are the workflow, not a description of it.

Two doors into the workflow, and one tool underneath them:

| | what it is |
|---|---|
| `/lfg` | the architect's session entry point — scoping, research, planning, ticketing, then a deliberate stop at the dispatch gate |
| `/ic` | the engineer's session entry point — take a Linear ticket from readiness through branch, PR and the review loop |
| `wf` | the CLI that installs and maintains all of it on a machine; its skills are `/install` and `/install-manager` |

`/lfg` and `wf` shared a name until 1.1.0. Neither installs the other: if you are looking for
the tool, it is `wf`; if you are looking for the session that turns an intent into a plan,
that is `/lfg`.

## Install

`wf` installs itself and the workflow into every coding agent on the machine — Claude Code,
Codex, Cursor, Kiro, ZCode and OpenClaw — from one configuration. The release binaries support
Apple Silicon macOS and x86_64 Linux. Installing `wf` needs no administrator rights;
installing a missing system dependency may require a separate administrator step.

**Before you start**, prepare the accounts, the Obsidian vault and the publishing credential
listed in [getting started](docs/operations/getting-started.md); the install cannot create them
for you.

Hand the prompt below to a coding agent as one message. It sends the agent to
[`/install`](skills/install/SKILL.md), which carries the whole procedure: the platform and
tool check, a verified immutable stable release, `wf install` for every agent it finds, the
verification pass, and the Linear, Rackspace Spot and artifact-publishing setup.

```text
Install the Magi engineering workflow (CLI: `wf`) from txehq/txe-workflow for my user account. Make sure `gh` is installed and logged in, then read the install guide with `gh api repos/txehq/txe-workflow/contents/skills/install/SKILL.md -H "Accept: application/vnd.github.raw"` and follow it end to end. Tell me in one line whenever a step needs me to log in or approve something, keep going with everything else meanwhile, and finish with the three-part report the guide asks for.
```

## Everything else

**[`docs/INDEX.md`](docs/INDEX.md) is the router.** It lists every document with its
audience, its read-trigger and whether it is prose or generated. This README deliberately
carries no second table; a hand-maintained router that nobody regenerates is how the last
one drifted.

Three shortcuts, because they are what people arrive looking for:

- Setting a machine, an agent or a service up → [`/install`](skills/install/SKILL.md).
- Something is missing or stale on your machine → [`/install-manager`](skills/install-manager/SKILL.md),
  or just run `wf doctor`.
- Changing a skill → [the runbook](docs/operations/runbooks/change-a-skill.md).

## Trying a change without publishing anything

Build a local release and rehearse in disposable directories:

```bash
cargo run -p wf-cli -- release build-local --out dist --with-binary
audit_home=$(mktemp -d)
env WF_HOME="$audit_home/wf" CLAUDE_CONFIG_DIR="$audit_home/claude" CODEX_HOME="$audit_home/codex" \
  cargo run -p wf-cli -- install --source local:dist --agent claude,codex --dry-run
env WF_HOME="$audit_home/wf" CLAUDE_CONFIG_DIR="$audit_home/claude" CODEX_HOME="$audit_home/codex" \
  cargo run -p wf-cli -- install --source local:dist --agent claude,codex
```

`--agent claude,codex` keeps the rehearsal inside the directories the environment moved;
`--agent all` would also deploy into agents found under your real home, such as `~/.cursor`.
That build pins no ctx, so the rehearsal leaves this machine's ctx alone. A build with `--ctx`
would manage the machine's real ctx daemon even in disposable directories, because ctx
coordinates its daemon under the real `~/.ctx`.

`--dry-run` on `install`, `sync`, `repair`, `rollback` and `uninstall` previews managed
changes without applying them. An install rehearsal can still download and expand verified
assets in temporary directories; it leaves managed files and persistent state unchanged.
[`fresh_install`](crates/wf-cli/tests/fresh_install.rs) uses agent test doubles, so it verifies
the lifecycle without proving compatibility with a particular installed agent version.

`--repo` selects the GitHub release repository. `--channel` selects stable or canary
releases. `--branch` records the source branch; it does **not** install that branch's HEAD.
Use `--source local:<dir>` to try unpublished checkout changes. Local builds are unattested
and do not replace the verified stable installation procedure above.

## Uninstall

```bash
wf uninstall --dry-run   # what it would touch
wf uninstall --yes
```

It removes only objects it has a record of, in every agent it manages. Your own skills, MCP
definitions, prompt text and agent history are not touched, and everything it changes is
backed up before it is removed.

Two binaries stay: `~/.local/bin/wf`, so backups can still be restored, and `~/.local/bin/ctx`,
because deleting a running daemon's binary without its handoff leaves the daemon crash-looping.
To remove ctx, run its handoff first, then delete it:

```bash
~/.local/bin/ctx daemon disable --prepare-uninstall --format=json
rm ~/.local/bin/ctx    # only after the handoff exits 0 and every boolean in its receipt is true
```

ctx's index in `~/.ctx` stays until you delete it deliberately. Deleting `~/.local/bin/wf` is
the whole of the rest.
