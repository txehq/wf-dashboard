# ADR-0004 — one binary, one version

**Status:** Accepted (2026-09-05). Supersedes the scope of ADR-0001 and WFR-010; refines
ADR-0001 rather than replacing it. Its plugin packages, marketplaces and native plugin
managers are superseded by [ADR-0007](0007-one-agent-layer.md); one registry, one version and
one binary stand.

## Context

ADR-0001 settled distribution: skills ship as a Claude Code plugin installed from this
repository. That decision held, and its no-symlink half still holds. What changed is the
scope around it.

Four things arrived at once and none of them fits inside "a Claude Code plugin":

1. **A second agent.** Codex has its own plugin surface, its own marketplace root, its own
   hook trust model and its own instruction file. Claude's plugin manifest cannot describe
   it, and a second hand-maintained manifest would be a second authority.
2. **Components that are not skills.** A global prompt block, a session-start dispatcher,
   MCP definitions and readiness profiles all have to reach a machine, and none of them is
   a file inside a plugin package.
3. **Nothing kept a machine current.** The runbook said: update the marketplace, update the
   plugin, restart. Whether anyone did was unobservable, and Claude's own auto-update is
   off by default for third-party marketplaces and checks after a session has already
   started.
4. **Four Go commands and a shell bootstrap**, each with its own argument handling, none
   installable without a Go toolchain on the machine.

## Decision

**One registry.** `workflow/registry.yaml` lists every shipped component once. Both plugin
packages, both marketplaces, the bundle and the lock are rendered from it. `wf guard`
regenerates them and fails a diff, so the duplicated skill trees are mechanical products
rather than a second place to edit.

**One version.** `[workspace.package].version` is the only SemVer. Everything a user can
observe carries it, and a change to a release surface that does not move it fails CI.

**One binary.** `wf` replaces `docsguard`, `readiness`, `obsidian`, `publish-artifact` and
`bin/magi`. It is precompiled and installed at `~/.local/bin/wf`.

**Native managers keep their own state.** `wf` drives Claude's and Codex's public commands
and then verifies the result. It never writes into a plugin cache.

**A fixed dispatcher.** The session-start hook's argv is frozen at
`wf hook session-start --agent <agent>`. Every policy a release wants to vary lives in the
bundle that dispatcher reads.

## Why Rust, when ADR-0001's era chose Go

The old reasoning was sound for what it decided: the failure class was text at process
boundaries, Go handled it, and a second toolchain would have doubled what a machine needed
before the plugin could run. Two of those three premises moved.

The second one moved because the work changed. What `wf` does now is verify archives from
a network, replace files in a user's home directory transactionally, and run inside every
session start under a hundred-millisecond budget. That is a different failure class:
partial writes, hostile archives, and a cold-start cost paid on every terminal a person
opens. A single statically-linked binary with no runtime and no GC pause is a better fit
than it was for parsing a branch name.

The third moved because of the distribution change. The old cost of a toolchain was that
developers needed Go installed to run a skill — which is exactly what `bin/magi` existed to
report on. A precompiled release asset removes the toolchain from every machine except the
release runner's, so "a second toolchain doubles what a machine needs" is no longer true:
it is now zero either way.

The first premise did not move, and it is why the port had to prove itself rather than
assert itself. Every Go tool was ported with its finding codes and messages intact, the
generated documents were compared byte-for-byte before anything under `docs/` was allowed
to change, and each of the three measured shell defects came across as a named regression
test.

## Consequences

- Editing one skill rebuilds two platform binaries, a bundle and two plugin packages. This
  is the chosen cost of a version that means something; see WFR-013.
- `wf` runs at every session start on every machine, with the ability to rewrite agent
  configuration. That is a large blast radius, and it is why WFR-014 and WFR-015 exist as
  contract rules rather than as implementation notes.
- The marketplace source moves from `./` to `./plugins/magi`. With `./`, installing the
  plugin copied the entire repository — every crate and every test fixture — into the
  plugin cache.
- Adding a component of a known kind is a registry edit and nothing else. Adding a new
  *kind* still requires an adapter, deliberately.
- Go is gone: no `go.mod`, no `cmd/`, no `bin/magi`. A machine needs `git`, `gh` and the
  `wf` binary.

## Alternatives considered

**Keep Go, add a Codex manifest by hand.** Cheapest today. It leaves two hand-maintained
manifests that drift, and does nothing about the machines that never update.

**Keep the four commands separate, add a fifth for sync.** Each would need its own install
path, its own version and its own way of being found by a hook. The version problem is the
whole problem; five binaries is five versions.

**A daemon.** Would make currency easy and is the wrong shape for a developer laptop:
something that survives logout, needs its own lifecycle, and is one more thing to explain
when it goes wrong. Bounded work at session start plus a finite updater achieves the same
convergence with nothing left running.
