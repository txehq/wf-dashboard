---
last-verified: 2026-09-17
---

# /postmortem — a severe incident, processed to its class

**Node:** WF-PM · **Spec (authority):** `Project Magi/Workflow/Specs/Session/Postmortem.md`
**Status:** shipped (carried text) · **Skill:** [`skills/postmortem/SKILL.md`](../../../skills/postmortem/SKILL.md)

An incident is not done when it is fixed; it is done when the *class* can no longer recur
silently. Ten ordered steps: scope → ground-truthed timeline → impact → proximate cause →
five whys to the class → detection gap → what went well → owned action items → file it →
close the loop.

## Carried, not rebuilt — and what that means

The text comes from the machine store rather than from its node, so it has **not** been
through the corpus's author ⇄ review ⇄ converge loop. It is here because it works and is in
daily use, not because it is finished. WF-PM stays `not started` as a *node*: the spec still
owes behaviour notes, a test plan and acceptance criteria.

Two changes were made on the way in, both necessary rather than cosmetic:

- **A live path bug.** Step 9 wrote postmortems to `~/Documents/Obsidian/TXE/Postmortems/`,
  which does not exist — that directory holds only `Capso` and `Personal`, and the vault is
  at `~/Projects/Obsidian/TXE` (measured 2026-09-04). Anything written there went somewhere
  nobody reads. It now routes through `/obsidian`, which resolves the home itself, so no
  path is hardcoded in a skill at all.
- **Chained to the v3 tail:** `/publish-artifacts` → `/obsidian` → Linear, matching the
  workflow diagram.

## Ground truth in step 2

Step 2 states its discipline inline and depends on no other skill: check the system's own
source of truth before asserting, and again before claiming a fix.

## Acceptance criteria

The node carries none yet, so there is nothing to verify against. That gap is the node's,
and inventing criteria here would put them in the wrong home. What the skill does enforce on
its own terms: a severity bar for triggering, action items that are owned and filed rather
than enumerated, and a bias to class fixes — a CI gate, a skill change, a definition-of-done
amendment — over instance fixes.
