---
last-verified: 2026-09-17
---

# /explainer — explain something properly, on a page

**Node:** WF-EXP · **Spec (authority):** `Project Magi/Workflow/Specs/Publishing/Explainer.md`
**Status:** shipped · **Skill:** [`skills/explainer/SKILL.md`](../../../skills/explainer/SKILL.md)

Renders a mechanism, an investigation or a long document as a published page with diagrams
where they carry the mechanism. Used by Research and Deep Research to present a design, and
by Decisions to publish a per-decision explainer.

**The one deliberate carry-over** from the pre-v3 skill pile
([WFR-006](../../contract/CONTRACT.md#clean-slate--skill-text-is-authored-from-its-node)) —
carried as-is, by name, in the DL decision that set clean slate for everything else.

## Acceptance criteria

The node records purpose and carry-over status; it does **not** yet carry a test plan or
acceptance criteria, which the Planning Corpus Standard requires of every node (log #21).
That gap is in the corpus, and this record does not paper over it by inventing criteria
here — criteria written in the record rather than the node would be exactly the second
spec home [ADR-0003](../../architecture/adr/0003-spec-authority-stays-in-the-vault.md)
exists to prevent.

Working obligations the skill text enforces: build and publish a page only when someone asks
for one, and publish it through `/publish-artifacts`; draw diagrams in mermaid; refuse the
cases that do not warrant a page.
