# ADR-0007 — one agent layer, and the plugin is retired

**Status:** Accepted (2026-09-16). Supersedes ADR-0001, the plugin-package half of ADR-0004,
and the plugin delivery of the `wf-history` server in ADR-0006. Spec:
`Project Magi/Features/TeamAI-CLI Adapter Integration Plan.md` in the vault.

## Context

Until 2.0 a skill reached a session one way and everything else reached it another. Skills
rode in two generated plugin packages that `wf` asked Claude Code's and Codex's plugin
managers to install. The prompt block, the session-start dispatcher and the MCP servers were
objects `wf` wrote itself, except where they were not: the `wf-history` server that ADR-0006
added reached agents through the plugin's `.mcp.json`, while its instructions arrived in the
prompt block `wf` wrote directly. Three things made that shape the wrong one to extend.

- **Two agents was the ceiling.** People on the team also work in Cursor, Kiro, ZCode and
  OpenClaw. None of them installs a Claude or Codex plugin package, so each would have needed
  a delivery path of its own beside the plugin, and every resource a second implementation.
- **The plugin was a copy wf could not see into.** An installed plugin is a copy in the
  agent's cache that refreshes only when the version moves, through a manager `wf` runs as a
  process and then has to verify from outside. A skill that drifted inside that cache was
  invisible to `wf status`.
- **The team repository had more to say than the registry.** The integration plan adds
  rules, subagents, environment and team documents, a policy file, and local usage and
  session tracking — the capabilities of `teamai-cli`, which already manages all of those
  agents from one configuration.

## Decision

**One layer manages every agent.** `crates/wf-agents` replaces `wf-agent`, `wf-agent-claude`
and `wf-agent-codex`. An agent is data: `workflow/teamai/agents.yaml` says where it keeps
skills, rules, subagents, hooks, MCP servers, instructions and environment, and which file
format each takes. There is one adapter, built from an entry, and one lifecycle —
inspect, apply, verify — inside the transaction every write already went through. A new agent
whose files look like a known format is a registry edit; a new format is an adapter first.

**Resources are handlers, and each one is the only implementation of its kind.** Skills are
copied whole from the verified generation into each agent's skills directory. MCP servers are
one named key in the agent's own MCP document — JSON with `${VAR}` references for Claude Code
and Kiro, `${env:VAR}` for Cursor, `env_vars` and `bearer_token_env_var` in Codex's TOML — and
never a resolved secret. Hooks are native handlers in each agent's hook format. The prompt is
the managed block, or a whole steering file where an agent reads steering. Rules, subagents
and environment come from the directories `workflow/teamai/team-config.yaml` names; team
documents go to the machine's state directory.

**The registry is still the list.** Skills, MCP servers, hook dispatchers, the prompt block
and readiness profiles stay components of `workflow/registry.yaml`. A component reaches every
managed agent that supports its kind; narrowing is a question about an agent's `agents.yaml`
entry, which declares the paths and formats it has, not about a list in the registry.
The bundle carries the registry, each component's source, `workflow/teamai` and the
directories the team configuration names — and no plugin package: `wf guard` fails one with
PLG005.

**Ownership is recorded, not inferred.** Every object `wf` deploys is a row in
`managed_resources`, written when the transaction commits. Objects that carry `wf`'s marker —
the prompt block, a handler whose command is `wf hook …` — are adopted when found. Anything
else of the same name is a conflict and is left alone; a rule a person edited is kept unless
the policy enforces it. `wf uninstall` and `wf agents unregister` remove owned objects only.

**Policy is a file the team owns.** `workflow/teamai/policies.yaml` allowlists MCP launchers
and hosts, restricts hooks to handlers that run `wf`, allowlists environment keys and refuses
secret-looking values, and turns usage tracking and session collection on or off. `wf`
itself is always an allowed launcher and is always written as the installed binary's absolute
path, because an agent does not start a server with a person's login `PATH`.

**Usage stays on the machine.** Four more dispatchers on the same fixed argv —
`wf hook dispatch --event <event> --agent <agent>` — record skills, tools, prompts and session
boundaries into the state database, `usage.jsonl` and `known-skills.json`. A session's summary
is kept at every turn's end; one worth keeping by the policy's bar goes into
`sessions/YYYY-MM.md`, updated in place. `wf usage` and `wf sessions` read them. Nothing is
uploaded, and the only prompt text kept is a redacted, shortened first prompt.

**ctx's surfaces are components like any other.** `capso.mcp.history` (`wf history mcp
serve`) is deployed by the MCP handler into every agent with an MCP document, and the prompt
paragraph that tells a session to use it is part of the prompt block. In Claude Code the tools
are `mcp__wf-history__<tool>`. ctx's binary, pin and daemon handoff stay where ADR-0006 put
them, outside any apply.

**1.x machines cross over by themselves.** The updater that installs 2.0 is the 1.x binary,
so the registry keeps schema version 2, the `plugin:` block and `delivery: native-plugin`
targets that 1.x parses. Its commit hashes each skill at `plugins/magi/<source>`, so the bundle
carries a copy of every skill tree there — the trees and no manifest, so 1.x can commit the
release but cannot install it as a plugin. Its plugin step fails soft, restoring the old
plugin, and its commit installs the new binary. A binary whose version differs from
`last_applied_binary` applies the active generation again:
session start starts `wf repair` beside the session, and `wf sync` does not treat the version
as current. That first 2.0 apply uninstalls `magi@capsohq` and its marketplace through the
receipts 1.x wrote, and adopts the prompt block and Codex dispatcher 1.x left. Rolling back to
a generation that still delivers skills as a plugin is refused with
GENERATION-PREDATES-AGENTS, because the 1.x binary would install every skill a second time.

**The command surface follows.** `wf agents` lists, detects, reports, registers and
unregisters agents (`wf agent` is an alias); `--agent` scopes `install`, `sync` and `repair`;
`wf usage` and `wf sessions` are new; `wf plugin` is gone.

## Consequences

- The version moves to 2.0.0: the plugin, `magi@capsohq` and `wf plugin` are removed, and
  Claude Code's `wf-history` tool names change.
- A skill edit reaches a session the next time that session starts. There is no plugin cache
  and no `/reload-plugins` step.
- Every file in a skill is a transactional write with a receipt, and an overwrite is backed up
  first. The budget is a thousand skills in under five seconds; the first apply of a thousand
  one-file skills measured 3.1 s (1.2 s with nothing to change) on a machine whose system calls
  cost about 40 µs, roughly a hundred times a laptop's. The CI Linux runner's overlay
  filesystem makes a durable write slow enough that the same apply took 7.2 s, so the test
  states that budget in durable writes measured on the disk it runs on, and separately fails a
  cost per skill that grows with the number of skills. Creating a file records no backup —
  undoing it is deleting it — and an apply that wrote nothing does not read everything back.
- A rollback puts back only bytes that are still the ones it wrote. An agent that rewrote its
  own file meanwhile — Claude Code keeps counters in `.claude.json` — keeps its change, and the
  rollback reports the file instead of reverting it.
- Asking Codex whether it trusts the dispatcher starts Codex's app server, so it happens before
  the commit: the commit holds the state database's write lock, which every hook waits on.
- Session start reads the generation's agent configuration and records a usage row before it
  checks the prompt block. The installed no-change path measured about 25 ms in-process in a
  debug build, inside the 100 ms p95 budget that `session_start_budget` now also measures on
  an installed machine and on one with 400,000 usage rows — a hook reads the database where it
  is, because the read-only snapshot other commands take copies the whole file.
- Which agents a machine manages: Claude Code and Codex wherever they appear, as 1.x did,
  unless unregistered; any other agent once registered.
- Detection is a directory check and a `PATH` lookup, never a process; an agent's version is
  asked only by `wf agents detect`.
- Codex's trust is unchanged: the session-start handler is the same bytes 1.x wrote (CLM-003).
- The crossover is tested against the real latest release, not a double: CI downloads it,
  installs it with its own binary, lets that binary update to the build under test, and checks
  the new binary applies the agent layer (`a_machine_on_the_previous_release_crosses_over_to_this_one`).
  Without the skill trees above, 1.7.0's commit fails with `IO-NOT-FOUND` and rolls back.
- Every skill is in the bundle twice while 1.x machines may still update. Dropping the copy
  is a later release's decision, once none remain.
- Claude Code 2.1.268 and Codex 0.154.0 were each observed reading the `wf-history` server
  this layer wrote into an isolated home (`real_agents_read_the_servers_wf_deployed`).
- Git and HTTP team repositories are parsed and refused. This release manages the team
  resources that ship in its own verified generation.

## Alternatives considered

**Keep the plugin for Claude Code and Codex, and add adapters for the other agents.** Every
resource kind would have two implementations, one of them a package manager `wf` cannot see
into. The `wf-history` server already showed the result: one server, two delivery paths,
depending on the agent.

**Run `teamai-cli` itself.** It manages these agents today, but as a Node runtime with shell
hook commands, its own configuration store and its own update path — a second installer and
a second version beside `wf`, and shell in the session path that WFR-011 excludes. Its
formats, detection rules and usage events are carried here as the reference instead.

**Symlink skills into each agent.** Cheap, and the failure WFR-001 was written against: an
edit in place changes every agent at once with no version, no receipt and no way to tell a
person's change from the team's.
