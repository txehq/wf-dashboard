---
last-verified: 2026-10-05
---

# /ic — the engineer's entry point, as an orchestrator of step skills

**Node:** WF-IC · **Spec (authority):** `Project Magi/Workflow/Specs/Session/IC Session.md`
**Status:** shipped v1 · **Skill:** [`skills/ic/SKILL.md`](../../../skills/ic/SKILL.md) · **Tool:** none — it orchestrates `/claim`, `/readiness`, `/implement`, `/acceptance`, `/open-pr`, `/fix-pr`, `/ready-for-review`, and `/handover` on the way out

Starts a dev session from a Linear ticket and runs it to a PR marked ready for review —
**autonomously**: one confirmation of the goal after `/claim`, then every step invoked by `/ic`
itself with nothing asked until `/ready-for-review` has marked the PR, at which point the user
is handed the PR to review (ding, 2026-09-08). A lane dispatched by `/ticketing` skips even the
confirmation. Since 2026-09-08 it is an orchestrator: each step is a skill with an In/Out that names a file or a
Linear object, and `/ic` hands each step the previous one's output and reads the result back
rather than trusting the conversation. It never re-scopes and never merges. `/ticketing`'s
dispatch, at the end of `/lfg`, runs this same path in a sub-agent, which is the point: one
coding path for a human IC and for a lane.

## The steps

| # | step | record |
|---|---|---|
| 1 | `/claim` — claim, read the ticket whole with attachments and the vault documents, post the requirements checklist on the ticket | [claim](claim.md) |
| 2 | `/readiness` — verify the machine against the declared toolchains and infrastructure | [readiness](readiness.md) |
| 3 | `/implement` — worktree only if not already in one; every requirement built and proven; ticks written back with the head SHA | [implement](implement.md) |
| 4 | `/acceptance` — walk the surface with screenshots, publish the report | [acceptance](acceptance.md) |
| 5 | `/open-pr` — draft PR from the template or the six sections, `gh image` screenshots, `Closes TXE-<n>` | [open-pr](open-pr.md) |
| 6 | `/fix-pr` — wait for review and CI on the current head, disposition every finding, fix every red check, until the PR is quiet | [fix-pr](fix-pr.md) |
| 7 | `/ready-for-review` — three conditions on the current head, then `gh pr ready` and the ticket's review state | [ready-for-review](ready-for-review.md) |

Between steps `/ic` stops the run when the artifact a step should have left is missing.

Frontend tasks invoke [ui-text-simplify](ui-text-simplify.md) after `/implement` sets up the
worktree and checklist, before frontend edits. Acceptance reads the persisted state checks;
after a later frontend fix, `/acceptance` republishes its report for the new head at the same
URL and the PR's affected screenshots are replaced. The route covers resumed work;
backend-only tasks are unaffected. It adds no approval gate or whole-app audit.

## Acceptance criteria

From the node:

| # | Criterion | State |
|---|---|---|
| 1 | `/ic` on a real epic claims a ticket and produces a session that starts coding without asking scoping questions. *(verify: transcript audit)* | **not yet exercised** on a real epic |
| 2 | A second `/ic` cannot claim the same ticket. *(verify: concurrent claim test)* | met for any gap wider than one Linear round trip; **not proven below that** — see `/claim` |

For the orchestration itself, authored here:

| # | Criterion | State |
|---|---|---|
| 3 | Entered mid-way, the run starts at the first step whose artifact is missing, derived from Linear, the worktree and GitHub, and says which. *(verify: transcript)* | not yet exercised |
| 4 | The run does not end at the PR URL: once `/open-pr` has commented it on the ticket, `/fix-pr` is invoked in the same turn. *(verify: transcript — the tool call after the ticket comment)* | not yet exercised |
| 5 | The loop's own criteria — disposition, oscillation, the exit condition — belong to [fix-pr](fix-pr.md). | — |
| 6 | Between the goal confirmation and the ready-for-review hand-over, no question reaches the user except the enumerated exceptions — an unmeetable requirement, a readiness failure outside the ceiling, an unreadable attachment, an action beyond the ceiling, or an oscillating finding. *(verify: transcript audit)* | not yet exercised |
| 7 | A lane dispatched by `/ticketing` asks nothing at all, including the goal confirmation. *(verify: lane transcript)* | not yet exercised |

The step-level criteria live in each step's record.

## Divergences from the node — recorded, not normalized

- **The claim is not atomic** — see `/claim`.
- **No journal lane** — the claim comment, the checklist comment, the worktree, the PR and
  `/fix-pr`'s disposition markers are the record until Orchestration State exists.
- **`/devpod` is not shipped** — `/implement` tests locally.
- **Only an empty or errored PR review stops the run** (linhaoz, 2026-10-05); an
  implementation review in `/implement` that did not run is noted and the run goes on.

## Status notes

TXE-1674 noted on 2026-09-04 that "someone else is building" `/ic`; nothing had reached a branch
of this repository by 2026-09-08, so this v1 should be reconciled with that work rather than
assumed to replace it.
