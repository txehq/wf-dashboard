---
last-verified: 2026-09-04
---

# /decide — decision ballots

**Node:** WF-BALLOT · **Spec (authority):** `Project Magi/Workflow/Specs/Session/Decision Ballot.md`
**Status:** shipped · **Skill:** [`skills/decide/SKILL.md`](../../../skills/decide/SKILL.md)

Turns a set of open questions into converged proposals on a selectable page, reads the
selections back without the decider re-typing anything, and writes each selection into the
document that governs it as a dated entry. Used in planning's Q&A phase and anywhere
several calls are pending at once.

## Acceptance criteria (from the node)

1. A submitted ballot's every selection lands as a dated entry in its owning document.
   *(verify: question → document → entry table matches the ballot)*
2. No surface that states a decided thing retains the superseded form after fold-in.
   *(verify: grep the decided claim's class across corpus + published pages)*
3. Re-issue preserves the URL. *(verify: id unchanged across revisions)*

## The name, settled

The node used to say **`/ballot` (name open)** while System Design §3 and the skill both
said `/decide`. Flagged here rather than normalized silently, and then settled in the
corpus — the node now reads `/decide` (workflow decision log #51). The fix went where
[WFR-002](../../contract/CONTRACT.md#the-spec-is-in-the-vault-this-repo-does-not-fork-it)
says it must: in the node, not in this record.

## Status notes

Proven across four ballot rounds of the workflow corpus itself before being formalized here;
the node's remaining test is a scripted round with a deliberately divergent pick, where the
fold must record the divergence instead of normalizing it to the recommendation.
