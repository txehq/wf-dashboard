# ADR-0001 — Skills ship as a Claude Code plugin from this repo

**Date:** 2026-09-04 · **Status:** superseded by [ADR-0004](0004-one-binary-one-version.md), then retired by [ADR-0007](0007-one-agent-layer.md) · **Rule:** [WFR-001](../../contract/CONTRACT.md#distribution-is-the-agent-layer)

The historical root-plugin layout below was replaced by a generated package under
`plugins/magi/`, registered from a verified local generation by `wf`, and in 2.0 the plugin
was retired: skills reach every agent through `wf`'s agent layer
([ADR-0007](0007-one-agent-layer.md)).

Two names in this document are read as of its date. The organization was `capsohq` until
2026-09-13 and is now **`txehq`** (TXE-1927); the repository is `txehq/txe-workflow`. The
plugin identity `magi@capsohq` is *not* a stale name — it is the local name every installed
machine registered the plugin under, never resolved against GitHub, and `workflow/registry.yaml`
records why renaming it would cost a re-registration on every install and buy nothing.

## Context

Until now the workflow skills lived in `~/.coding_skills/` and were symlinked into each
`~/.claude1..5/skills/`. The System Design decision log (#33, 2026-09-03) retired that
model, naming two failure classes it had actually produced:

- skill text drifting away from the contract it implements, with no CI able to see it —
  the skills were not in any repository, so nothing reviewed them;
- a skill missing from some installs after a rename, because the symlink set was
  maintained by hand, per install.

#33 named the destination loosely: "project-level skills dir / plugin". Putting the skills
in `capsohq/txe` would have made them project-level, but they orchestrate work across
repositories — a workflow skill is not a `capsohq/txe` artifact. Connor's direction
(2026-09-04) is a dedicated repository, `capsohq/txe-workflow`, which forces the choice
this ADR records: a separate repo cannot be a project-level skills directory for anything.

## Decision

This repository is both a Claude Code **marketplace** and the **plugin** it serves.
`.claude-plugin/marketplace.json` lists one plugin, `magi`, sourced from the repo root;
`.claude-plugin/plugin.json` declares it; `skills/` is discovered by the harness.

Installation, as this ADR recorded it in 2026-09-04 — **do not run these**:

```text
/plugin marketplace add capsohq/txe-workflow      # superseded; `capsohq` is now a freed name
/plugin install magi@capsohq
```

The first line is kept verbatim rather than corrected because it is the decision this document
records — and it is the reason the block carries a warning at all: `capsohq` is a *freed* GitHub
name. It resolves today only through GitHub's rename redirect, which stops the moment anyone
registers it — at which point that command adds a stranger's marketplace. `wf-core`'s
`FORMER_ORG` exists so the old name is read as the new one locally and **never reaches a GitHub
lookup**; a command pasted out of this block bypasses that entirely.

Installation today is `wf install`, which resolves a verified immutable release and registers
the marketplace from a local generation directory — no mutable Git branch, and no marketplace
name resolved against GitHub. See [ADR-0004](0004-one-binary-one-version.md),
[deployment](../../operations/deployment.md) and [`skills/install/SKILL.md`](../../../skills/install/SKILL.md).

## Consequences

- **Versioned.** `plugin.json` carries a version; an install pins to what it pulled and
  updates deliberately. The symlink model had no version at all.
- **Reviewed.** A skill change is a PR against this repo, and CI (`docsguard`) sees it.
- **Uniform.** Every install gets the same set. There is no per-install link step to forget.
- **Namespaced invocation.** Plugin skills are addressed as `magi:<skill>`; the bare
  `/<skill>` form resolves when it is unambiguous. The workflow diagram's `/lfg`, `/ic`,
  `/review-pr` are the bare forms and stay valid so long as nothing else claims those names.
- **A running session does not see an edit.** Editing `skills/foo/SKILL.md` on disk changes
  nothing until the plugin is updated — see [local-development](../../operations/local-development.md).
  This is a real cost of the plugin model, paid for the version pinning it buys.

## Alternatives rejected

- **Plain repo + symlinks into each `~/.claudeN/skills`.** Moves the store under git — which
  fixes reviewability — but keeps the per-install hand-maintained link set, so it keeps the
  "missing after a rename" class #33 set out to kill.
- **Both, plugin plus a symlink fallback.** Two distribution paths mean two things to keep
  consistent and a silent question every time they disagree about which one a session used.
- **Skills inside `capsohq/txe`.** They would be versioned with one product's code while
  orchestrating work in several repositories, and every workflow change would land in the
  busiest repo in the org.
