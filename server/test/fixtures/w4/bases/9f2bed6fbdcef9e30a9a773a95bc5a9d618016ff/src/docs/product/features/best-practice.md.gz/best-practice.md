---
last-verified: 2026-09-05
---

# /best-practice — a recurring class becomes a page, when it cannot become a gate

**Node:** WF-BP · **Spec (authority):** `Project Magi/Workflow/Specs/Publishing/Best Practice.md`
**Status:** shipped · **Skill:** [`skills/best-practice/SKILL.md`](../../../skills/best-practice/SKILL.md) · **Tool:** none, deliberately

Turns a recurring defect class into a published page the next planning run reads. Review
Mining names the class; this is where it becomes something someone can follow.

## The design decision that shapes it

Review Mining settled the order for actuating a class: **a CI predicate beats a
review-prompt line beats a checklist.** A best-practice page is the *third*. So the skill's
first section exists to talk the author out of writing one — three bars, in order:

1. **Could a check catch it?** Then build the check. A page describing what a check could
   enforce is a rule with no enforcement, and the cost is measured here rather than
   theorised: the Docs Atlas found a freshness rule no check could see with two guidelines
   five months stale *inside the guarded set*, and two rules written in this repo were broken
   by their own author within a merge (TXE-1663, TXE-1665).
2. **Does it already have a home?** Then a pointer, not a page. The second copy is the one
   that goes stale.
3. **Has it happened twice?** One instance is an anecdote. The recurrence is the trigger.

Saying "this should be a CI check on X, not a page" is a success, not a refusal to work.

## Why there is no tool

`/readiness` and `/handover` use `wf` because there is repository state to derive, and
having a model run commands and transcribe results is where fabrication enters. Here nothing
is derivable — the input is judgment and evidence a person holds. A binary would be
ceremony, and the reasoning is recorded so the next skill does not build one reflexively.

## Acceptance criteria (from the node)

| # | Criterion | State |
|---|---|---|
| 1 | Refuses when a mechanical check could enforce the class, naming the check | in the skill's §1; **not exercised** — no scripted refusal has been run |
| 2 | Refuses when the practice already has a home, naming it | in §1; **not exercised** |
| 3 | Refuses a single instance, naming the recurrence bar | in §1; **not exercised** |
| 4 | Every page carries all six parts, with enforcement stated plainly | ✅ the first real page does |
| 5 | Linked from a surface a reader reaches before the decision it governs | ✅ linked below and from the skill |

**Criteria 1–3 are written but unverified.** They are behaviours of a prose skill, so a
"scripted refusal" means running the skill against a planted case and reading the transcript
— worth doing, not yet done. Recorded as a gap rather than checked off because the text
exists.

## The first page

[**Confirm a stated mechanism before you build on it**](https://engapp.dev/artifacts/page/3z4pyewl)
— written from a class this session measured twice in one day: a stated mechanism encoded
into a shipped requirement before the one-command observation that would have refuted it. It
survives its own §1 (no check can decide whether someone verified a premise), carries all
six parts, and its enforcement section says plainly that nothing enforces it and nothing can.
