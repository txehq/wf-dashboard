---
last-verified: 2026-09-07
---

# /deploy-summary — brief the person who asked for it

**Node:** WF-DEPS · **Spec (authority):** `Project Magi/Workflow/Specs/Delivery/Deploy Summary.md`
**Status:** shipped · **Skill:** [`skills/deploy-summary/SKILL.md`](../../../skills/deploy-summary/SKILL.md) · **Tool:** `wf deploy-summary` ([`crates/wf-deploy-summary`](../../../crates/wf-deploy-summary))

Derives what a merged change is and whether it is actually running on staging, for a
**stakeholder** — somebody who asked for a thing and wants to know if it is done and where to
look at it.

## The correction this was rebuilt around

The first implementation was an operator's cluster-divergence report: image digests, rollout
state, restart counts, replica mismatches. Connor, 2026-09-07: *"you had it in the wrong
direction. Basically, that is to summarize the specific PR and all relevant information. Give
the stakeholder a brief summary of what has been shipped and what's been deployed to staging."*

That is a different document for a different reader, and the rewrite is not cosmetic — the
input changed from a cluster context to a **pull request**, and the cluster read went from
being the subject to being one supporting fact. The divergence machinery was deleted rather
than kept: it is a real artifact for whoever is on call, and shipping it under this name would
have kept answering the wrong question convincingly.

## The one piece of rigour kept

**Merged is not deployed**, and the difference is what the reader is actually asking about.
Three states, never inferred into each other:

| state | meaning |
|---|---|
| `on-staging` | found running, with the evidence |
| `not-yet` | the environment was read, and it is not there |
| `unknown` | the environment could not be read |

`unknown` must never render as `not-yet`. A failed read finds no matching image, and no
matching image is exactly what a genuinely undeployed change looks like — so the sentence says
so in words: *"That is not the same as 'not deployed'."*

## What is verified

| # | Criterion | Verified by |
|---|---|---|
| 1 | A commit-tagged image is recognised, in the tag forms actually used | `an_image_tagged_with_the_commit_is_recognised` |
| 2 | An unrelated image is not a match | `an_unrelated_image_is_not_a_match` — the control without which a matcher that says yes to everything would pass criterion 1 |
| 3 | A commit too short to be distinctive never matches | `a_commit_too_short_to_be_distinctive_never_matches` — a coincidental match tells a stakeholder their change is live |
| 4 | An unreadable environment is `unknown`, and says so in words | `an_unreadable_environment_is_unknown_and_not_undeployed`, plus **live** against a wedged Rackspace Spot control plane returning `EOF` |
| 5 | The three states read differently | `the_three_states_read_differently` |
| 6 | An open PR is refused clearly, not as a parse error | `an_open_pull_request_is_refused_clearly_not_as_a_parse_error` — `gh` returns `null` for `mergedAt`/`mergeCommit` on an open PR, and `#[serde(default)]` does not cover an explicit null for a struct, so this first surfaced as "gh returned something unexpected", exit 1 |
| 7 | A merged PR parses with its tickets | `a_merged_pull_request_parses_with_its_tickets` — the control for 6 |
| 8 | A truncated environment read is an error, not a missing change | `a_truncated_environment_read_is_an_error_not_a_missing_change`, with a positive control |
| 9 | Production is named, never inferred into | `production_contexts_are_recognised_by_segment`, `a_word_merely_containing_prod_is_not_production` — `reproducible` contains "prod" |
| 10 | The whole derivation works on real data | run against PRs #20 and #21 with `capso-txe-devcontainers`: both changes read from GitHub with tickets, environment read (84 images), state `not-yet` — correct, this repository does not deploy there |

## Why the read is a projection, not `-o json`

`kubectl get -o json` on a real cluster returned **625 KiB**, mostly `managedFields` this never
reads, against a shared **256 KiB** capture cap — so the read came back a truncated document.
The projected fields are **8.6 KiB**. A truncation guard rejects any read not ending on a
record boundary, because here a partial read makes *a shipped change look unshipped*.

## What is not claimed

- **No brief has been published or recorded in Linear through this skill.** The derivation is
  verified against real PRs and two real clusters; the publish and Linear steps are instructed
  but not exercised.
- **`on-staging` has never fired against a real deployment.** The commit-in-image-tag link is
  unit-tested; the only reachable cluster does not run anything from this repository, and the
  staging cluster this is meant for has a wedged control plane. So the positive case is proven
  by test, not by observation.
- **The link depends on a tagging convention.** Where images are not tagged with the commit,
  the tool cannot see the link and reports `not-yet` — which would be wrong. The skill is
  instructed to treat an untagged product as unknown, but nothing enforces that; it is an open
  question on the node.
- **Migration state is not read.** It is a required part of the page, gathered separately.
- **Correctness is not established**, only whether the change is running.
