---
last-verified: 2026-09-22
---

# /ci-optimise

**Node:** WF-CIO · **Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/CI Optimise.md`
**Status:** shipped in 2.2.0; installation requires a release containing it.
**Skill:** [skills/ci-optimise/SKILL.md](../../../skills/ci-optimise/SKILL.md)

The skill applies before creating, optimising or modifying CI pipelines, including direct
requests and review fixes. The shared agent prompt and `/ic`, `/implement`, `/fix-pr`
entry points route applicable work to it. `/ci-optimise` also invokes it explicitly.

It makes developer waiting time the primary optimisation objective, reconstructs the
critical path from dependencies and real run timing, and checks which work can execute
independently of merge readiness. Required verification retains its correctness guarantees.
The skill attributes its source observations and adds an operational measurement and
validation procedure.

## Acceptance criteria

| Criterion | Verification |
| --- | --- |
| New, modified and slow pipelines activate the skill, including review fixes. | Description, shared prompt and caller inspection. |
| Critical-path analysis includes required endpoints, queueing, dependency edges and parallel branches. | Read the procedure against a pipeline with multiple converging paths. |
| Moving optional work preserves required verdicts and observable failures. | Dependency and failure-semantics review scenario. |
| Cache, sharding and setup changes retain validation correctness. | Mechanism-specific proof obligations in the skill. |
| Speedup claims require comparable measured runs. | New-pipeline and unavailable-remote scenarios. |
| The agent distribution includes the skill. | Registry, generated catalog, guard and workspace tests. |

Automatic invocation is agent guidance. Packaging checks establish discoverability;
live agent invocation requires installing the containing release. The node carries the same
contract, trigger and acceptance criteria as this record and the skill.
