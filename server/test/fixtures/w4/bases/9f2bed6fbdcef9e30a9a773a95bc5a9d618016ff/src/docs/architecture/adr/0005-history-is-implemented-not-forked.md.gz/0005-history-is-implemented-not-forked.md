# ADR-0005 — local history is implemented here, not forked from upstream

**Status:** superseded by [ADR-0006](0006-history-is-ctx.md) (2026-09-16).

The reimplementation below is deleted: `crates/wf-history`, `wf vendor ctx`, `UPSTREAM.toml` and
the monthly vendor job are gone, and `wf history` now runs ctx itself at the version each
release's lock pins. ADR-0006 answers this record's rejection of an external binary point by
point.

## Context

`wf history` searches this machine's own coding-agent transcripts. The design that led here
specified vendoring the Apache-2.0 core of [`ctxrs/ctx`](https://github.com/ctxrs/ctx) — a
pinned upstream commit copied into `third_party/ctx/upstream`, wrapped by a `wf-history`
crate, exposed as `wf history …`.

Two facts about that upstream decided against copying it:

- **Size.** The repository is roughly 60 MB. Committing it would put that in every clone,
  every CI checkout and every plugin-package build, for a dependency this build does not
  link against.
- **The runtime.** Its semantic search depends on an ONNX/transformer runtime whose build
  downloads platform binaries. That is a build-time network dependency inside a release
  chain whose entire premise is that nothing executes before its digest matches a lock.

Neither is a criticism of the upstream project. They are reasons a fork is the wrong shape
*here*, in a repository whose release must be reproducible on two platforms from a pinned
toolchain.

## Decision

**Implement the capability; pin the upstream as a reference.**

`crates/wf-history` is written here. It covers what this organization actually needs: the
eight providers, a SQLite FTS5 lexical index, a vector index, and reciprocal-rank fusion
over the two.

`third_party/ctx/` keeps `UPSTREAM.toml` (the pinned commit, version, license and tree
digest), the Apache-2.0 license text, and an attribution note. `wf vendor ctx --fetch`
materialises the snapshot on demand for comparison work; the snapshot itself is
gitignored. The pin is what makes "which providers are supported" a claim about a specific
upstream commit rather than a claim about the present.

**The embedding backend is named for what it is.** It is a hashed n-gram vector space
model: word tokens plus character 4-grams, hashed into 512 dimensions, sublinearly weighted
and L2 normalised. It matches across morphology, tolerates typos and ignores word order.
It is not a transformer, and nothing in the code, the docs or the skill says it is.
`wf history status` prints the backend in use.

`embed::Backend::Model` and `embed::ModelReceipt` state the contract a model backend must
satisfy before it may be used: a pinned revision, a SHA-256 per asset, and a stored license
receipt. Adding one is then an implementation rather than a redesign.

## Consequences

- No 60 MB of vendored source, no build-time model download, no fork to keep merged.
- The provider matrix is ours to maintain. When an agent changes its transcript format, the
  fix is here — which is also true of a fork, but without the merge.
- Semantic quality is below what a sentence transformer would give. This is stated in the
  feature record and in the skill, so the gap is visible rather than implied away.
- `ctx pro`, the upstream's private companion, is out of scope in either design.

## Alternatives considered

**Vendor the full workspace as specified.** Rejected on the two facts above. If the release
chain ever tolerates a build-time network dependency, this is worth reopening — the pin in
`UPSTREAM.toml` is what makes reopening it cheap.

**Depend on `ctx` as an external binary.** Rejected in the original design and still
rejected: it puts a second install, a second version and a second update path on every
machine, which is the problem `wf` exists to remove.

**Ship no semantic search at all.** Considered. Lexical alone answers "the error string I
remember" and not "the session I can only describe", and the second is most of why anybody
searches their own history.
