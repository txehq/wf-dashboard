---
last-verified: 2026-10-07
---

# /codebase-design — deep modules

**Node:** WF-IC (no separate node) · **Spec (authority):** `Project Magi/Workflow/Specs/Session/IC Session.md`
**Status:** shipped · **Skill:** [`skills/codebase-design/SKILL.md`](../../../skills/codebase-design/SKILL.md) · **Tool:** none

Shared vocabulary and principles for designing deep modules, wherever code is designed or
restructured. It asks nothing and never becomes a session of its own; when someone asks for
alternative interfaces, DESIGN-IT-TWICE.md starts design-only sub-agents.

## What it holds

- **A glossary** — module, interface, implementation, depth, seam, adapter, leverage, locality —
  used exactly, so a design discussion means one thing by each word.
- **Deep and shallow** — a small interface over a lot of implementation, drawn, with the three
  questions that shape an interface.
- **Four principles** — depth is a property of the interface; the deletion test; the interface
  is the test surface; one adapter means a hypothetical seam, two a real one.
- **Designing for testability** — accept dependencies, return results, keep the surface small.
- **Going deeper** — [DEEPENING.md](../../../skills/codebase-design/DEEPENING.md) (dependency
  categories, seam discipline, replacing the old tests) and
  [DESIGN-IT-TWICE.md](../../../skills/codebase-design/DESIGN-IT-TWICE.md) (sub-agents designing
  very different interfaces, compared on depth, locality and seam placement).

## Who reads it

- `/implement`, before writing code that creates a module or reshapes one's interface.
- `/implement`'s implementation review, which pastes `SKILL.md` into the Codex prompt as the
  standard for modules.
- Anyone designing or restructuring code, on request.

## Acceptance criteria

Authored here; the skill has no node to inherit from.

| # | Criterion | State |
|---|---|---|
| 1 | `wf` installs the skill with `DEEPENING.md` and `DESIGN-IT-TWICE.md` beside it into every agent it manages. *(verify: `wf status` and the installed directory)* | not yet exercised |
| 2 | `/implement` reads `SKILL.md` before a change that creates a module or reshapes one's interface. *(verify: transcript)* | not yet exercised |
| 3 | The implementation review's prompt carries `SKILL.md` in full, and its module findings cite these principles. *(verify: `.ic/implementation-review.prompt.txt` and `.ic/implementation-review.md`, rehearsed 2026-10-07 on a fixture repository)* | **met** |
| 4 | A request for alternative interfaces starts at least three design-only sub-agents, and their designs are compared on depth, locality and seam placement. *(verify: transcript)* | not yet exercised |

## Divergences from the node

- **No node.** Adapted on 2026-10-05 at linhaoz's direction from mattpocock's `codebase-design`
  (commit `24fe0ef`). Every dependency category is tested against the real thing or its local
  instance — a service's sandbox for a third party — in line with the workflow's no-mock rule;
  the diagrams are mermaid; the design-it-twice sub-agents design only and start no agents of
  their own.
