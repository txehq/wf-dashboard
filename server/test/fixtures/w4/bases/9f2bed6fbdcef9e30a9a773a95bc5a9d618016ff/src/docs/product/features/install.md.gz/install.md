---
last-verified: 2026-10-04
---

# /install — the guided install

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/LFG Session.md` (WF-LFG).
Where this record and the node disagree, the node wins.

## What it is

The procedure a coding agent follows to put the workflow on a machine: check the platform and
the tools, download and verify the latest immutable stable release, install `wf` into every
coding agent on the machine, verify what landed, connect Linear, Rackspace Spot and artifact publishing,
and report what is live and what is still waiting on a person.

It used to be the README's install prompt — one screen of Chinese prose carrying the whole
procedure, its constraints and its reasoning, which every reader copied and nobody could
review as a unit. The procedure is now [`skills/install/SKILL.md`](../../../skills/install/SKILL.md)
and the prompt is one English line that points an agent at it. The prompt says what to do; the
skill says how; this record says what the skill is for and what it does not prove.

## Two halves of one node

| | what it is |
|---|---|
| `/install` | set a machine up: release, `wf install`, verification, services — this record |
| [`/install-manager`](install-manager.md) | read, repair and roll back an install that already exists |
| [`/lfg`](lfg.md) | the architect's session entry point, which installs nothing |

WF-LFG is one node in the corpus and appears once per half in the [roster](../README.md).
Splitting it is a change to the spec, not to this repository.

## The six steps

1. **The machine** — platform triple, tool versions, `gh auth status`, `codex login status`
   and `claude auth status`, a `codex exec` probe with `/review-pr`'s model, read access to the
   release, the `gh-image` extension, and what the machine already carries.
2. **The release** — the latest release is immutable, not a draft, not a prerelease;
   `gh release verify`, `gh release verify-asset` for each of the three assets, digests and
   sizes against the lock, and one top-level `wf` in the binary archive.
3. **Install** — back up an existing binary, install the new one, then
   `wf install --source github:txehq/txe-workflow --agent all`, which copies the skills into
   every agent it finds, writes the prompt block, the hooks and the MCP servers — the
   `wf-history` server among them — into each agent's own configuration
   ([agent layer](agents.md)), retires a 1.x `magi@capsohq` plugin, and installs ctx at the
   version the lock pins. Before it, the person answers once — the vault Obsidian lists, Spot,
   any missing publishing value — and the Linear sign-in starts; after it, `MAGI_VAULT` is
   written to the shell profile and proven in a new shell.
4. **Verify** — `wf doctor --strict --json` read at exact `jq` paths, every agent managed in
   `wf agents` and no
   `magi@capsohq` plugin left, one pair of managed markers in each effective prompt file, a
   journal record from each manual dispatcher call, the Codex `/hooks` trust prompt when trust is not yet granted, and the
   history MCP check in a new session of each agent: visible, then usable.
5. **The services** — leftover bridges cleared from `wf doctor`'s `MCP-ORPHAN` findings, the
   browser sign-in (relayed through the agent on a machine with no browser), Linear and
   Rackspace Spot probed by name in each agent (in Codex, as a mention), and the
   artifact-publishing credential file, each confirmed with a real call.
6. **The report** — the full report in `.install/report.md`, then a short Chinese report in
   the chat: the install's state, what to do now with the restart first, and how to use `/lfg`
   and `/ic`.

## Rackspace Spot

`capso.mcp.rackspace-spot` ships in the registry beside Linear, so `wf install` puts the
server into every managed agent that has an MCP configuration. Spot has no token route: it authenticates through OAuth in the
browser on the first tool call, which is what the registry's `agent-oauth` credential mode
describes — a credential with a host and no reference, because there is no environment name
for a person to set. `wf install`'s next-step list names that login, and names nothing else:
a connection the person holds to the same host is not installed, managed or reported by `wf`.

The definition bridges the remote server with `mcp-remote`, the form Rackspace documents for
clients that hold a remote server through a local command. It is the one installation path: a
connection the person adds themselves is theirs (WFR-016).

## Acceptance criteria

- The README's install section is one English prompt that sends an agent to this skill, and
  the procedure itself lives in exactly one file.
- A machine that runs the skill end to end reaches `wf doctor --strict` with every agent on it
  managed, every managed object current, and no `magi@capsohq` plugin left in Claude Code or
  Codex.
- `wf install` lists the bridge's own browser login as a next step for every `agent-oauth`
  MCP, answered from `wf_agents::credentials::credential_status` — the same rule `wf doctor` and the
  session-start hook use — and names no server it did not install. The report contains no
  `mcp add` or `mcp login` command
  (`the_install_report_names_only_the_servers_this_workflow_manages`, WFR-016).
- The credential answer reads the environment and no agent's MCP configuration, so a server
  somebody else configured for the same service — a `linear` beside `wf`'s own in
  `.claude.json` — reaches neither the answer nor the report
  (`the_install_report_names_only_the_servers_this_workflow_manages`).
- Every step ends in an observed command result; a step that needs a person is reported as
  open rather than assumed.
- A login command exiting 0 is never reported as an authenticated service; the report says
  authenticated only where a read-only tool call through that agent's own server returned.
- Session start and `wf doctor` agree about a credential: the hook re-asks
  `wf_agents::credentials::credential_status` before it warns, so a stale row for a component that declares
  no reference is dropped rather than reprinted in every terminal, while a row the re-check
  cannot answer still stands
  (`session_start_re_asks_a_stale_credential_row_rather_than_reprinting_it`).
- Recommended diagnostics print a field whitelist; no `env`, header, token or OAuth parameter
  reaches the transcript.
- The skills list comes from `skills/*/SKILL.md` in the active generation's bundle, and an
  empty match is reported as a failed lookup.
- Each installed agent is checked for the history MCP in a new session of its own. Visible:
  Claude Code lists `mcp__wf-history__*`, and every other agent shows an observed call to the
  `wf-history` server's `status` tool, with no tool name asserted. Usable: `status` reports at
  least one source and `search` for `wf install` with limit 1 returns a hit. The report carries
  one `history MCP: visible / usable` line per agent.
- A `CTX-HANDOFF` or `CTX-FOREIGN` from ctx's convergence is reported with the fix `wf doctor`
  names, and does not undo the rest of the install.
- A `ctx-agent-history-search@ctx` Claude Code plugin already on the machine is reported to the
  person as stale and is never removed by the skill.
- Step 1 checks that Codex and Claude Code are logged in (`codex login status`,
  `claude auth status`, exit 0 when logged in and 1 when not), and a missing login leaves that
  agent's checks open in the report.
- Step 4 names the exact `jq` paths of `wf doctor --strict --json` and `wf agents --json`, and
  each path returns data from the real output of both the released and the built binary.
- The procedure starts no server to read its configuration: the Claude Code entries are read
  from `.claude.json`, never through `claude mcp get`.
- `wf doctor` reports every leftover bridge an agent launched from the entries `wf` wrote —
  tagged `WF_MCP_COMPONENT` — as `MCP-ORPHAN`, with its processes and the `kill` command, and
  step 5 clears them before any sign-in; a detached bridge to the same service without the tag
  is never reported (`a_real_orphaned_bridge_is_found_in_the_live_process_table`,
  `a_bridge_without_our_tag_is_never_reported`).
- A sign-in bridge the guide starts by hand stops when its `sleep` is ended.
- On a machine with no browser, step 5 keeps a bridge waiting per service and hands the person
  the page; the callback reaches the bridge through the person's own SSH port forward, or the
  person delivers it on the machine in a terminal of their own. The callback address, which
  carries the sign-in code, never passes through the conversation or a command line.
- Codex carries `startup_timeout_sec = 120` for both bridges, from the registry
  (`a_registry_startup_limit_reaches_codex_and_leaves_claude_alone`), and its probes name the
  server as a mention.

## What it does not prove

- That a service is authenticated. A configured MCP server, on any agent, is configuration
  — `wf doctor` cannot see an OAuth login, and neither can this skill until a read-only call
  through the server returns.
- That the session-start hook fires automatically. The manual dispatcher call proves the
  dispatcher; only an observed new session proves the trigger.
- That one agent's login covers another's tools. The browser sign-in is per machine —
  `mcp-remote` keeps the token under `~/.mcp-auth`, keyed by service URL — but each agent's
  server and its tool calls are checked separately.
- Spot's own prerequisites — an account, an organization, a payment method before the first
  bid — belong to the person, not to the install.
- That semantic search is ready. The `wf install` query is a keyword hit; ctx's daemon embeds
  in the background after the install, and `wf history semantic status` shows how far it has got.
- That the other agents name the history tools the way Claude Code does. Their naming is not
  recorded in this repository, which is why their check is an observed call.

## What the first real install found (1.6.1)

On 2026-09-15 the procedure was walked end to end from the README prompt on Apple Silicon
macOS with Claude Code 2.1.272 and Codex 0.154.0, against immutable stable 1.6.0. It finished:
`wf 1.6.0` installed, both agents carrying `magi@capsohq`, strict doctor `ok: true`, both
native Linear servers returning the TXE team, both agents' Spot connections returning
organizations, and an artifact published and read back. The friction it recorded is
[issue #35](https://github.com/txehq/txe-workflow/issues/35), and this is what changed:

| What happened | What the skill now says |
|---|---|
| `claude mcp login` in a pipe: `stdin isn't a terminal, so authentication can't be completed here` | run it under a PTY, or hand it to the person's terminal or `/mcp` |
| `claude mcp login` on a half-configured cloud connector exited 0 and left `Needs authentication` | configured, login started and authenticated are three states; only a returning tool call is the third |
| `codex mcp list --json` printed other servers' `env`, secrets included | diagnostics print a field whitelist |
| `skills/*/SKILL.md` matched nothing in the installed package | the 1.6 package kept them at `plugins/magi/skills/*/SKILL.md`; from 2.0 the active bundle keeps them at `skills/*/SKILL.md`; an empty match is a failed lookup |
| `PUBLISH-NETWORK ... Connection refused` behind a local proxy | `wf` names the proxy variables in effect; the session reports the error with them and stops the artifact check |
| A plain fetch of the published URL saved a 302 page | the publish already reads the page back with Access headers; a content check needs them too |
| Session start kept asking for `LINEAR_API_TOKEN` after the agent was logged in | one credential rule for the hook and doctor — see [`/install-manager`](install-manager.md) |

Rackspace Spot's OAuth login is no longer theoretical: it completed through the `mcp-remote`
bridge and both agents' plugin connections returned organizations. The bridge's
`saveDiscoveryState()` warnings and the idle `SSE stream disconnected` are recorded as
observed and benign, not as proof of long-running connection stability.

## Friction is now reported as it happens

The table above is the argument for wiring [`/report-friction`](report-friction.md) into this
skill. Every row of it was collected **after** the run, in one lump, because the person asked
for a write-up at the end — and issue #35 says so itself: it went looking for a repository
issue template, found `.github` held only workflows, and fell back to a skill's five-section
shape. The exact error text survived that run only because one session happened to still hold
it.

The skill now carries a standing instruction, ahead of step 1, to file each case as it is hit
— failures, described paths that did not work, working paths this file does not have,
confirmations of claims the file hedges about, and the person's own instruction where theirs
is what finished the install. It files at a lower bar than anywhere else in the workflow,
labelled `friction:install`, without asking and without pausing the install. Step 6 closes
the loop: a line on the open-items list that names a defect in the procedure should already
carry its issue number, and the end of the run is the last moment the error text exists
anywhere.

The repository now has the template #35 went looking for.

**Unverified.** No install has been walked since the wiring landed, so the claim that an agent
mid-install actually files rather than absorbing is written and not yet observed. The next
real install is the test.

## What 1.7.1 found

`capso-linear` pointed at `https://mcp.linear.app/sse` from the first commit. Linear had
removed that endpoint: it answers 404 — before any authentication — so the bridge could not
connect on any machine, and never had. `/mcp`, Linear's Streamable HTTP endpoint, needs no
token at all: on 2026-09-16 the same `mcp-remote` argv with `/sse` replaced by `/mcp`
completed OAuth in the browser, and a JSON-RPC round trip returned `Linear MCP 1.0.0` and 66
tools.

Three things kept it invisible from the first commit to 1.7.0:

| What was wrong | What changed |
|---|---|
| `workflow/mcps/linear.yaml` said `/sse` while every command in the skill and every fixture in the workspace said `/mcp`, and nothing compared the two | a test asserts every MCP's endpoint appears in `skills/install/SKILL.md` |
| `LINEAR_API_TOKEN` was declared as one of two credential routes; `mcp-remote` consumes no such variable, so that route never existed | Linear is `agent-oauth`, the same shape as Spot; the reference is gone, and the packaging test asserts the registry's references instead of one name |
| The skill told the installer the bridge's `CONNECTION_CLOSED` was expected noise from a missing token, and not to look further | that paragraph is gone. A bridge that will not connect is a finding: run step 5's probe and report what it returned |

The third row is the one worth keeping. The failure was visible in every `claude mcp list` on
every machine; the instruction that explained it away is why nobody read it as a defect —
including [#35](https://github.com/txehq/txe-workflow/issues/35), which recorded the symptom
and stopped at "未证明具体根因". **A prompt that supplies an explanation for a failure it has
not diagnosed is worse than one that says nothing**, because it converts a visible error into
a known-benign one.

### The second half: a doctor that stated what it had not observed

Filed as [#39](https://github.com/txehq/txe-workflow/issues/39) and
[#40](https://github.com/txehq/txe-workflow/issues/40). Both are fixed in 1.7.1.

`wf doctor` reported a component as `current` whenever a server in the *agent's own*
configuration merely pointed at the same host — configuration, never a credential store, so a
server that had never been logged into read as a working capability. On the machine that found
this, all three Linear servers were unusable (that one never logged in, the bridge 404,
`claude.ai Linear` never authenticated) and the doctor read `current`.

Fixing #39 made it worse before it made it better: with `references: []`, `credential_status`
returned `Satisfied` on its first line, before the mode was ever read, so even the notice about
a host carried elsewhere stopped being produced. The early return was the bug — an `agent-oauth` block declares
no reference *because* there is nothing checkable, and that is a different answer from being
satisfied.

| What was wrong | What changed |
|---|---|
| `credential_status` returned `Satisfied` for any block with no reference, which is every `agent-oauth` block | the reference check no longer short-circuits; `agent-oauth` always reaches the OAuth branch and answers `LoginUnverified` |
| there was no state for "installed, login not observed", so it fell through to `current` | `unverified` — healthy, never blocking, and listed by `wf doctor` under what it did not look at |
| a test asserted `Satisfied` for the Rackspace Spot shape, pinning the defect green | it asserts `LoginUnverified`, and a second test pins every shipped MCP to that answer |
| a server in the agent's own configuration was read, and the report named it as though it replaced the bridge | `wf` reads no server entry but its own (WFR-016) |

**`wf` installs and manages `capso-linear` and `capso-rackspace-spot`, and nothing else.** Not
a server the person added, not one their account carries, not one pointing at the same service.
`credentials.login_host` names where *our* server's login goes and nothing more. A machine may
well hold three Linear connections; two of them are not this report's subject, and the
operator's first question when a Linear tool fails is which server answered.

The token store belongs to `mcp-remote`, keyed by service URL under `~/.mcp-auth` — **per
machine, shared by both agents** — which is why two rows for one component frequently describe
a single login.

`unverified` does **not** reach the session-start hook. `credential_missing` names something a
person can set; `unverified` names something they may already have done and cannot act on from
a terminal banner, so printing it every session would reproduce the noise 1.6.1 removed. It
belongs to `wf doctor`, which someone runs on purpose. A test holds the hook to that silence,
with a control row so the test cannot pass against a hook that reports nothing at all.

It is also deliberately not a *finding*: `/install`'s acceptance criterion is a strict doctor
returning `ok: true`, and every machine carries two `agent-oauth` MCPs. A state that failed
that criterion on every machine would create pressure to report `current` again — the defect
it exists to remove. A test pins that too.

**Rejected:** reading mcp-remote's own token cache at
`~/.mcp-auth/<mcp-remote-*>/<md5(url)>_tokens.json` to upgrade `unverified` to "logged in".
The directory name moves with the mcp-remote version — the machine that found this bug had
five of them side by side — `MCP_REMOTE_CONFIG_DIR` can move the base, and "logged in once" is
not "works now". Trading "I did not look" for a weak signal is the same mistake in a new
place; the probe is the answer.

**Unverified, still.** The session diagnosed the 404 unprompted but filed both reports on the
user's instruction. The claim in the section above — that an agent mid-install files rather
than absorbing — remains written and not yet observed.

## What a cloud host with no browser found (2.2.0)

A run on a Debian cloud host reached over SSH (`wf 2.1.0`, Claude Code 2.1.278, Codex 0.155.1)
filed [#59](https://github.com/txehq/txe-workflow/issues/59),
[#60](https://github.com/txehq/txe-workflow/issues/60),
[#61](https://github.com/txehq/txe-workflow/issues/61) and
[#62](https://github.com/txehq/txe-workflow/issues/62); a Codex monitoring run on macOS filed
[#50](https://github.com/txehq/txe-workflow/issues/50). Each was reproduced on the same Debian
host on 2026-09-22 before it was changed.

| What happened | What changed |
|---|---|
| `claude mcp get` and `claude -p` started the bridges of servers not yet signed in; each bridge waited for its page, outlived the command under PID 1 and held the sign-in, so the terminal bridge in step 5 printed `Another instance is running the sign-in for this server on port 22227` and no page (#61) | the procedure reads Claude Code's entries from `.claude.json`; `wf doctor` reports each leftover as `MCP-ORPHAN` with its processes and the `kill` command; step 5 clears them before any sign-in |
| On a host with no browser the approved page redirected to `localhost:22227` on the person's own computer and the bridge never heard of it (#59) | step 5 keeps a bridge waiting per service and hands the person the page; the callback reaches the bridge through the person's `ssh -L` forward of the callback ports, or the person delivers it on the host with `read … | curl --config -` in their own terminal, so the code never enters the conversation; the port comes from the URL, `3335 + (first four hex digits of MD5(url)) mod 45816`: 22227 for Linear, 45024 for Spot |
| Step 1 checked that `codex` existed; step 4's `codex exec` then failed with `401 Unauthorized` (#60) | step 1 runs `codex login status` and `claude auth status` and leaves a logged-out agent's checks open |
| Step 4 named fields without paths, and `.result.agents[]` read nothing (#62) | step 4 gives the `jq` paths: `.result.status.agents[]`, `.result.status.components[]` (rows that are not `current`), `.result.findings[]`, `.errors[]`, and `id` in `wf agents --json` |
| Codex answered as though `capso-rackspace-spot` did not exist while `wf doctor` said installed (#50) | Codex lists in a session's first step only the servers that answered within 1 s (`mcp_optional_startup_grace_ms`); the Spot bridge takes 3.6-4.8 s, and a server that misses `startup_timeout_sec` (30 s by default) is absent for the whole session with no message. `wf` writes `startup_timeout_sec = 120` for both bridges, and Codex probes mention the server, which makes Codex wait for it |

The Linear callback carries an `iss` parameter, and `mcp-remote` 0.14.3 refuses a callback
without it (`IssuerMismatchError`), which is why the person delivers the whole address.

## What a first-time member found (2.2.2)

A member new to the workflow ran the README prompt on macOS with `wf 2.2.0` and wrote down
what stopped them (feedback document, 2026-10). Each line below is what the procedure does now.

| What happened | What changed |
|---|---|
| No document said what to prepare before the prompt, why, or what the end looks like | [getting started](../../operations/getting-started.md), with the prompt in it: GitHub in txehq, Linear in the team, the vault synced, both CLIs logged in, the publishing credential filled in; Spot only on demand; the project repository before the first `/lfg` |
| The final report was a page of release, ctx and finding detail; the next step was unclear | the full report goes to `.install/report.md`; the chat ends with a short Chinese report — the install's state, what to do now (restart first), and how to use `/lfg` and `/ic` |
| The Linear sign-in ended as "run `npx -y mcp-remote …` in your own terminal" after the agent's bridge was denied | the agent starts the bridge in the background, opens the page, and says in one line which prompt to allow and what to click |
| `/lfg` did not exist right after the install | restarting Claude Code is always the first thing to do |
| The vault was not found: `MAGI_VAULT` was unset and the default path did not exist | step 3 reads the vaults Obsidian lists, confirms the one holding `Project Magi/`, writes `MAGI_VAULT` to the shell profile and proves a new shell sees it |
| The Spot sign-in page kept opening, Allow included | step 3 asks whether the person uses Spot and records a "no" with `wf mcp skip`; who uses it signs in through the terminal bridge |
| Codex reviews were skipped with "the CLI is too old", and no error was kept | step 1 records `codex --version` and probes `codex exec` with `/review-pr`'s model, keeping the exact error |
| `/lfg` ran in a folder with no git repository, so the gate asked about `git init` | `/lfg` asks which repository when the directory has no GitHub remote |

A rehearsal of the new procedure on 2026-10-04, on a machine already at 2.2.0, found two more:

| What happened | What changed |
|---|---|
| "What to do now" listed six items, four of them checks that only confirm (a Codex probe, a ZCode probe, a journal record) | the chat lists only what the person must do before `/lfg` and `/ic` work; confirmations stay in `.install/report.md` |
| `wf doctor --strict` reported `CTX-HEALTH` and "run `wf install`" while ctx's daemon ran a periodic refresh and search returned hits; ctx answered `ok: false` with `refresh is pending (core_refresh_pending)`, then `semantic is pending (generation_not_acknowledged)` | a "not ok" whose every finding is `<what> is pending (<code>)` is ctx working, and is no finding (`a_refresh_in_progress_is_no_finding`); anything else beside it still is |

## Verification limits

The browser sign-in itself was not completed on 2026-09-22: it needs a person's account. What
was run is everything around it — the derived ports, a waiting bridge printing its page, and a
delivered callback reaching the bridge, which then took the stand-in code to the service and
was refused (`Invalid authorization code format` from Linear, `unknown or already-used
authorization code` from Spot); the `read … | curl --config -` line returned `200` with the
whole address, `iss` included, and the address in no command line. A real code completing the
exchange is the step the issue's own run observed and this record did not, and the `ssh -L`
route was not run from a second computer.

The Codex CIMD failure and the GUI double-launch race are carried from their sources
([Codex OAuth client registration](https://developers.openai.com/codex/mcp#oauth-client-registration),
[Rackspace Spot MCP](https://spot.rackspace.com/docs/en/modelcontextprotocol)); neither was
reproduced on 2026-09-15, and neither is claimed as a current defect. One thing stayed
unexplained: a Python `urllib` fetch of the published artifact with the same credentials, from
the same machine, returned 403 where `curl` returned 200. The skill states the difference,
makes its byte check with `curl`, and names no cause.
