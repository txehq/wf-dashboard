---
last-verified: 2026-09-05
---

# /obsidian — file a document in its standard vault home

**Node:** WF-OBS · **Spec (authority):** `Project Magi/Workflow/Specs/Publishing/Obsidian Writer.md`
**Status:** shipped · **Skill:** [`skills/obsidian/SKILL.md`](../../../skills/obsidian/SKILL.md) · **Tool:** `wf obsidian` ([`crates/wf-obsidian`](../../../crates/wf-obsidian))

The shared tail every document skill chains into: content → `/publish-artifacts` →
**`/obsidian`** → Linear. It exists because "write it to the vault" is where a standard
quietly stops being followed — the folder gets guessed, the index never gets updated, and
the ticket id lives only in the conversation.

## The three properties worth knowing

1. **The kind → path table is closed.** An unrecognised kind is refused rather than filed
   somewhere plausible. Inventing a location is how a vault grows a second home for the
   same thing.
2. **`+Index.md` is rendered from the folder**, every write. A maintained index remembers
   additions and forgets removals; a rendered one cannot.
3. **Nothing is overwritten or erased silently.** An existing document needs `--replace`;
   frontmatter merges, so a later write that omits `--ticket` keeps it.

## Acceptance criteria (from the node)

| # | Criterion | Verified by |
|---|---|---|
| 1 | Each known kind lands at exactly its documented path | `TestEveryKindLandsAtItsDocumentedPath`, plus dry-runs of all six shapes against the real vault |
| 2 | An existing file is refused by default; `--replace` overwrites | `TestExistingDocumentIsRefusedThenReplaced` |
| 3 | The index lists what is in the folder, including after a removal | `TestIndexReflectsTheFolderIncludingRemovals` |
| 4 | Frontmatter merges across writes | `TestFrontmatterMergesAcrossWrites` |
| 5 | Unknown kind, absent vault and missing slug each fail by name | `TestRefusalsNameWhatIsMissing` (8 cases), confirmed live |
| 6 | The source file is unmodified and still in place | `TestSourceFileIsUnmodified` |

Beyond the node: a mistyped `--product` creates nothing (`TestAMistypedProductCreatesNothing`),
and repeated re-filing converges rather than accumulating blank lines
(`TestRepeatedWritesConverge` — which caught a real defect, since the first version stripped
one newline after the fence while the renderer re-added one).

## What is deliberately not claimed

- **Nested corpora cannot be filed.** `spec` and `decision` assume the standing folders sit
  directly under the product. The Magi workflow corpus does not — it lives at
  `Project Magi/Workflow/Specs/Publishing/…`, nested inside the product with a group folder
  below `Specs/`. A dry run resolves that document to the wrong place, so v1 cannot file
  into it. Not fixed by adding a free-form path flag: that turns a closed table into "write
  anywhere" and loses the property that makes the tool worth having. Open on the node.
- **No production write yet.** Every kind is verified by dry-run against the real vault and
  by tests against a temp one; the first real write is the next `/interview` brief, which is
  the node's own test plan. `Features/` does not yet exist anywhere in the vault — this is
  the first implementation of that structure, not an adaptation to it.
