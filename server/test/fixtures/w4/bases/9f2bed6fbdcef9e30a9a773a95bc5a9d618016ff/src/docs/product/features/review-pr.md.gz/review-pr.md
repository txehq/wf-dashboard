---
last-verified: 2026-09-17
---

# /review-pr — one independent review pass, posted to the pull request

**Node:** WF-RPR · **Spec (authority):** `Project Magi/Workflow/Specs/Review/Review PR.md`
**Status:** shipped · **Skill:** [`skills/review-pr/SKILL.md`](../../../skills/review-pr/SKILL.md) · **Tool:** `wf review-pr` ([`crates/wf-review-pr`](../../../crates/wf-review-pr))

Runs one Codex review pass against a pull request and posts the findings. It changes no code,
branch, metadata or status. A finding already live in the base branch also gets a Linear
ticket, which is the only write outside GitHub.

## How it is built

The contract lives in the skill. The SQLite-backed detector in `scripts/review_monitor.py`
watches one repository's open PRs under launchd. `wf review-pr install` derives every
machine-specific path — `uv`, `gh`, `codex`, `node`, the script through `wf`'s active
generation, and the state directory — writes them into the plist with a `PATH` for the
workers, and refuses a repository the GitHub credentials cannot read, so one install command
works on every machine.

The detector is a Python script that `uv run --script` starts with the Markdown parser its
inline metadata declares. It fails fast. An expected outcome — an ineligible PR, a covered
head, a diff GitHub will not serve, an oversized diff, a failed worker, an invalid review —
becomes a recorded job state. A failed job opens a circuit that only an exact-job reset clears,
a review's circuit opens before it is posted, and an unexpected error ends the process for
launchd to restart while the workers, in their own process group, keep running.

## What is verified

| # | Criterion | Verified by |
|---|---|---|
| 1 | Every Codex invocation disables apps and approvals | `CodexCommandTest.test_every_codex_invocation_disables_apps_and_approvals` |
| 2 | The review pass is read-only and writes only its final message | `test_the_review_pass_is_read_only_and_writes_only_its_final_message` |
| 3 | Every review runs at high reasoning effort | `test_the_review_pass_uses_high_reasoning_effort` and `the_review_pass_is_pinned_to_high_reasoning_effort` |
| 4 | A head is preflighted against GitHub once its debounce has passed, and a merged PR is recorded as ineligible | `test_a_merged_pr_is_preflighted_after_the_debounce_and_found_ineligible`, against PR #32 on GitHub |
| 5 | A failed reviewer opens the circuit, the job is never dispatched again, and an exact-job reset leads to a fresh preflight; the worker runs in its own process group | `test_a_failed_reviewer_opens_the_circuit_and_runs_again_only_after_an_exact_reset`, with a real `codex` process; **mutation-tested** — returning the failed job to `ready` fails it, and so does starting the worker in the detector's process group |
| 6 | Review structure is validated with a Markdown parser, and headings inside a code block are not findings | `ValidationTest` |
| 7 | Retention deletes expired jobs and evidence and keeps an active job's evidence and its diff | `test_maintenance_deletes_expired_jobs_and_evidence_and_keeps_the_active_job` |
| 8 | The static prompt carries the complete diff and refuses evidence that changed | `test_the_static_prompt_embeds_the_complete_hash_verified_diff` |
| 9 | The detector receives absolute `uv`, `gh` and `codex`, and the workers' `PATH` holds each resolved directory once, `node` first | `the_plist_passes_the_detector_absolute_binaries`, `workers_run_with_a_path_that_holds_each_resolved_directory_once` |
| 10 | The plist and the detector agree on every flag | `every_flag_the_plist_passes_is_one_the_detector_accepts` |
| 11 | An update does not break a running monitor | `the_script_path_goes_through_the_active_symlink` |
| 12 | A second monitor cannot be installed onto a repository that already has one | `the_label_never_collides_with_the_pre_port_job` |
| 13 | A malformed repository is refused before anything is written | `a_malformed_repo_is_refused_before_anything_is_written` |
| 14 | A repository the GitHub credentials cannot read is refused | `a_repository_the_github_credentials_cannot_read_is_refused`, against GitHub, run with `--ignored` |
| 15 | A diff GitHub refuses to serve comes back as the reason | `test_a_diff_github_refuses_to_serve_comes_back_as_the_reason`, against rust-lang/rust#160692 (1,105 files); **mutation-tested** — raising on the refusal fails it |
| 16 | A cancelled job is preflighted again when its head returns | `test_a_cancelled_job_is_preflighted_again_when_its_head_returns`; **mutation-tested** — preflighting only new and reset jobs fails it |

The detector's tests run from the repository root with an authenticated `gh` and the `codex`
CLI:

```bash
uv run --with 'markdown-it-py>=3' python -m unittest discover -s skills/review-pr/scripts -p 'test_*.py'
```

## The marker name

`<!-- OpenAI Codex via RPR -->` is coverage truth for every head reviewed in every repository,
and the detector reviews every head that lacks it. A renamed marker would send every reviewed
head back through review, so the marker keeps the name `RPR`, and the `RPRB` marker counts as
coverage too.

## Open items

- No full cycle — install, poll, detect an uncovered head, review, post — has been run end to
  end.
- Untested: the circuit that opens before a review is posted, and the ineligible outcome for a
  PR that changes no files.
- The hang that `--disable apps` prevents has not been observed; the flag is verified in the
  argv.
- The follow-up coordinator runs at `danger-full-access`.
- Supervision exists for launchd only.
