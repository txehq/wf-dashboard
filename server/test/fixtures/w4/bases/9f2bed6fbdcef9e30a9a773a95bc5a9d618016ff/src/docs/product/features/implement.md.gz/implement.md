---
last-verified: 2026-10-07
---

# /implement — every requirement, nothing else, proven locally

**Node:** WF-IC (step 3; no separate node yet) · **Spec (authority):** `Project Magi/Workflow/Specs/Session/IC Session.md`, System Design §2 *Branch & Coding* and *Local Build & Test*
**Status:** shipped v1 · **Skill:** [`skills/implement/SKILL.md`](../../../skills/implement/SKILL.md) · **Tool:** none — `git`, the repository's own test commands, the Linear MCP

The first of v3's two coding-plane boxes, as a step skill. It finds out whether the session is
already in an isolated worktree and creates one from the remote's latest development branch
only if not; mirrors the ticket's checklist into the worktree; implements every line strictly
and completely with the test that proves it; runs the inner loop and then the repository's
canonical verdict; and writes the ticks back to the ticket's checklist comment with the head
SHA.

Frontend implementation invokes [ui-text-simplify](ui-text-simplify.md) after worktree and
checklist setup, before editing, including direct or resumed entry. It persists UI state
checks in the local and ticket checklists with the head SHA for acceptance to consume.

## The contract it presents to its callers

| | |
|---|---|
| In | the claimed ticket with its checklist comment; the feature documents; a verified machine |
| Out | an isolated branch with the work committed; `.ic/checklist.md` fully ticked; the ticket's checklist comment updated with `head=<sha>`; the canonical verdict green |
| Next | `/acceptance` for a visible surface or declared evidence; then `/open-pr` |

## The rules it builds by

- **Look before creating a worktree** (ding, 2026-09-07): a linked worktree is used as is; the
  main checkout gets a new branch cut from the remote's latest development branch and a
  worktree for it; no checkout at all is cloned first. A dirty worktree from someone else is
  surfaced, never built on.
- **Omission and drift are the two failures**, and they are opposite: nothing skipped, stubbed
  or "covered by" a neighbour; nothing outside the slice boundary touched.
- **A requirement that cannot be met is the bank's M5** on the ticket — evidence, impact, the
  three ways out — never a widened or narrowed ticket.
- **Evidence is the canonical verdict**, run locally before anything leaves the machine; the
  native inner loop is for iteration only.
- **The feature documents are copied into `.ic/`** (linhaoz, 2026-10-07): `Brief.md`,
  `Research.md` and `Tickets.md` sit beside the checklist.
- **`.ic/progress.md` is the run's engineering log** (linhaoz, 2026-10-07): one line after each
  requirement, decision and dead end — what, why, what next — and only what the code and the
  ticket do not say. After a compaction and on every resumed entry it is read, with the
  checklist and the copied documents, before anything else.
- **The ticket governs; `Research.md` is questioned** (linhaoz, 2026-10-07): its claims are
  checked against the code as it is now, and a better way to deliver the ticket's
  requirements is taken — working functionality first.
- **Code is built by software-engineering principles** (linhaoz, 2026-10-05): high cohesion, low
  coupling, single responsibility, separation of concerns, information hiding, DRY, YAGNI, honest
  names, no code smells; a change that creates or reshapes a module reads
  [codebase-design](codebase-design.md) first.
- **An implementation review follows the green verdict** (linhaoz, 2026-10-05): Codex reads the
  committed change against the ticket, for defects, and, separately, against the repository's
  standards, a fixed set of code smells and the module principles. It informs and never blocks:
  the session decides once, fixes every Critical or High defect that holds, records each
  decision in `.ic/implementation-review.md`, and reruns the verdict after any fix.
- **The branch is rebased before the verdict** (linhaoz, 2026-10-07): while it has never been
  pushed, onto the development branch's latest state, conflicts resolved there and its changes
  checked against this one, so the verdict, the review, the checklist's head and the acceptance
  evidence all read the head that will merge.

## Acceptance criteria

Authored here; the step has no node to inherit from.

| # | Criterion | State |
|---|---|---|
| 1 | A session already in a linked worktree starts on that branch; one in the main checkout fetches the development branch, cuts the ticket branch from it, and makes a worktree for it. *(verify: transcript + `git worktree list`)* | **not yet exercised** |
| 2 | Every checklist line is ticked with the file and test that satisfies it, or the ticket carries a comment naming the blocked requirement. *(verify: the checklist against the diff)* | not yet exercised |
| 3 | The diff touches nothing outside the ticket's slice boundary. *(verify: read the diff against the ticket)* | not yet exercised |
| 4 | The canonical verdict is green locally before `/open-pr`, and the ticket's checklist comment carries the head SHA that was verified. *(verify: transcript + the comment)* | not yet exercised |

## Divergences — recorded, not normalized

- **`/devpod` is not shipped**; end-to-end tests run locally.
- **No journal.**
- **No node of its own.** Authored from WF-IC and System Design §2; a node is owed.

## Status notes

Built 2026-09-08 as the third step of decomposing `/ic`; not yet run on a real ticket.
