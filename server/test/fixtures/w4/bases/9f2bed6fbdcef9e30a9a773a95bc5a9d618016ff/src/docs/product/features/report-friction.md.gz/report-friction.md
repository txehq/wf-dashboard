---
last-verified: 2026-09-17
---

# /report-friction — the workflow's own defects, reported by the session that hit them

**Node:** WF-MAGI · **Spec (authority):** `Project Magi/Workflow/Specs/Magi/Magi.md`
**Status:** shipped · **Skill:** [`skills/report-friction/SKILL.md`](../../../skills/report-friction/SKILL.md) · **Tool:** none, deliberately

A GitHub issue on `txehq/txe-workflow` for each time a skill, a hook, `wf` or a Magi
instruction failed a session, described something other than what happened, or was overridden
by a user instruction that worked better. The session that hits it is the only witness, and
it is about to end.

## Why this is a sensor and not a chore

`wf magi measure` counts review rounds because the number was not measured anywhere. This
counts the workflow's *own* defects for the same reason: until now the only record of a skill
failing on a real machine was a transcript on one laptop, and the only detector was the same
defect happening to someone else.

It is the first sensor that reads a surface GitHub does not already hold. Review rounds are
derived from the event log; friction is not in any log — it exists only in the session that
hit it, which is why the reporter has to be the agent rather than a periodic job.

## The five classes, and why the bar is low

| class | the case |
|---|---|
| `friction:blocked` | the instruction failed outright — error, missing file, a step that could not be done as written |
| `friction:mismatch` | it ran, and the world was not what the text said; **silence about the situation counts** |
| `friction:override` | the user's different instruction is what worked |
| `friction:sentiment` | the user pushed back on the workflow itself |
| `friction:install` | anything in install, reinstall or authentication — wins when a case is both |

The skill is told to over-report, on purpose. A report nobody needed costs a minute of
triage; a defect nobody reported costs every session that meets it next. The install class
sits at a lower bar again: an install is run once per machine by someone with no context, so
the experience of the run *is* the finding — including the paths that worked, which no
failure-only tracker would ever collect.

The evidence for the install class is [issue #35](https://github.com/txehq/txe-workflow/issues/35):
the first real install of 1.6.1, written up after the fact because the person asked for it at
the end, carrying seven findings that changed the skill. It is the shape this skill exists to
produce without anyone asking, and per case rather than in one retrospective lump —
[`/install`](install.md) now invokes it inline for exactly that reason.

**Override is the highest-value class in the set**: it is a correction with its proof
attached, which is exactly the input `/best-practice` and the Magi loop need and the one
thing no automated sensor can derive.

## The design decisions

**The agent files it, without asking.** Interrupting a user to request permission to report a
bug is the friction this exists to remove. It is authorized standing, and the skill spends
its restraint on *what* goes in rather than on *whether* to write.

**Observation and hypothesis in separate sections.** The template splits "what happened" from
"why I think it happened", the same separation Magi stage 2 makes for case records: a guess
that narrates the observation contaminates the only durable evidence in the report.

**One case, one issue.** Two defects in one issue are triaged as one, and the second is the
one that gets lost.

**Fire when the case has an outcome.** The path that worked is the half that turns a
complaint into a patch, and a report filed at the first retry does not have it. A case still
open when the work moves on is filed anyway, marked unresolved.

**The report never costs the work.** One line to the user, then back to the task. When a `gh`
command fails, the filing stops with that error, the body file stays in `.report-friction/`,
and the session goes back to the task.

**Always `--repo txehq/txe-workflow`.** Sessions run this skill from inside product
repositories; without an explicit repo the report lands in the wrong tracker, where nobody
who can fix it will read it.

## Acceptance criteria

| # | Criterion | State |
|---|---|---|
| 1 | Fires on all four classes without asking the user | in the skill's §1–2; **not exercised** — no planted case has been run end to end |
| 2 | Searches existing issues and comments rather than duplicating | in §3; **not exercised** |
| 3 | Reopens or cross-links a closed issue on its own judgment | in §3; **not exercised** |
| 4 | Every report carries error text verbatim, the working path, the hypothesis and the user's words | in §4, and the repository template mirrors it |
| 5 | Files to `txehq/txe-workflow` from inside any repository | `--repo` on every command in §5–6 |
| 6 | A missing label stops the filing with `gh`'s error, and the body file stays in `.report-friction/` | stated in §5 |
| 7 | Secrets never reach an issue body | instructed in §4; **unenforced** — `wf` is not in the path, so [`wf-core::redact`](../../../crates/wf-core/src/redact.rs) does not fence it |

**Criteria 1–3 are written and unverified**, the same honest state `/best-practice` records:
they are behaviours of a prose skill, so verifying them means running the skill against a
planted case and reading the transcript. Worth doing; not yet done.

## Why there is no tool

Nothing here is derivable. The inputs are the error text, what the agent tried, what the user
said and a hypothesis — all of them held by the session, none of them in a file `wf` could
read. `gh` already does the transport. A binary would add a version to keep in step for no
fact it could establish.

The one thing a tool would buy is criterion 7: redaction in the path rather than in an
instruction. If friction reports start carrying transcript excerpts at volume, `wf report
friction` wrapping [`redact`](../../../crates/wf-core/src/redact.rs) is the reason to build
one — and until then this record says plainly that the fence is prose.

## What it does not claim

- **No dedup guarantee.** Search is lexical and the agent chooses the terms; two sessions
  describing the same defect differently will file it twice. Over-reporting is the accepted
  cost.
- **No counting, no ledger, no digest.** Issues are the artifact. Turning them into a defect
  class ledger is Magi stage 2's job (M2 cases, M8 windowed digest), not this skill's.
- **No triage.** It never labels severity, never assigns, never closes. A report is evidence,
  and deciding what it means is a human's or Magi's call.
- **No product bugs.** The narrow test — would this have happened if the skill's text, the
  hook or `wf` were different — is stated twice in the skill because it is the failure mode
  most likely to fill the tracker with noise.
