---
last-verified: 2026-09-16
---

# The agent layer — every coding agent, one configuration

**Spec (authority):** Obsidian `Project Magi/Features/TeamAI-CLI Adapter Integration Plan.md`.
Where this record and the plan disagree, the plan wins.
[ADR-0007](../../architecture/adr/0007-one-agent-layer.md) records why the plugin gave way to it.

## What it is

The part of `wf` that puts the team's resources into each coding agent on a machine and keeps
them there: `crates/wf-agents`, configured by `workflow/teamai/`. It reads what the verified
release offers, compares it with what each agent has, writes the difference inside one
transaction, reads the result back, and records every object it owns.

| agent | id / alias | skills | rules | subagents | hooks | MCP | instructions | environment |
|---|---|---|---|---|---|---|---|---|
| Claude Code | `claude-code` / `claude` | ✓ | ✓ | ✓ | `settings.json` | `.claude.json` | block in `CLAUDE.md` | `settings.json` |
| Codex CLI | `codex` | ✓ | — | ✓ | `hooks.json` | `config.toml` | block in the effective `AGENTS.md` | `config.toml` |
| Cursor | `cursor` | ✓ | `.mdc` | ✓ | `hooks.json` | `mcp.json` | — | — |
| Kiro | `kiro` | ✓ | steering | ✓ | `hooks/capso-wf.json` | `settings/mcp.json` | steering file | — |
| ZCode | `zcode` | ✓ | — | ✓ | `cli/config.json` | `~/.agents/mcp.json` | — | — |
| OpenClaw | `openclaw` | ✓ | — | — | a `workspace/hooks` hook | — | block in `workspace/AGENTS.md` | — |

`workflow/teamai/agents.yaml` is the table above as data, and an overlay at
`<wf config dir>/agents.yaml` adds or overrides an entry on one machine. Adding an agent is
[a runbook](../../operations/runbooks/add-an-agent.md).

## What reaches an agent

- **From the registry** (`workflow/registry.yaml`): skills, the organization prompt block, the
  hook dispatchers — session start, and usage on prompt submit, tool use, turn end and session
  end — and the MCP servers, `wf-history` among them. A component reaches every managed agent
  that supports its kind.
- **From the team configuration** (`workflow/teamai/team-config.yaml`, self-repo mode): rules
  from `workflow/rules/**/*.md`, subagents from `workflow/agents/*.yaml`, environment from
  `workflow/env/env.yaml`, and documents from `workflow/docs/**`, which go to the machine's
  state directory rather than an agent. A directory that does not exist is an empty set; this
  release ships none of them yet.

MCP definitions carry references, never values: `${VAR}` where the agent expands it (Claude
Code, Kiro), `${env:VAR}` for Cursor, variable names in Codex's `env_vars` and
`bearer_token_env_var`. A server that runs `wf` gets the installed binary's absolute path.

The one literal value is not a credential: every stdio server `wf` writes is launched with
`WF_MCP_COMPONENT=<component id>` in its environment (the entry's `env`; Codex's `env` table),
set from the registry the way `startup_timeout_sec` is. Every process of the server's chain
inherits it, which is how `wf doctor` tells a leftover bridge it installed (`MCP-ORPHAN`) from
one the person started to the same service (WFR-016).

A server that is slow to start carries its own limit: `startup_timeout_sec` on its MCP
component in the registry (the two `mcp-remote` bridges declare 120), carried into the
definition when the registry is scanned. It lives in the registry because every released `wf`
refuses a key its definition parser does not know, and the previous release installs the next
one; the definition parser refuses the key in a definition file for the same reason. Where each
agent takes it:

| agent | per-server startup limit | what `wf` writes |
|---|---|---|
| Codex | `startup_timeout_sec` in the server's table, 30 s by default (0.155.1); a server that misses it is absent from the whole session with no message | `startup_timeout_sec = 120` |
| Claude Code | none: `MCP_TIMEOUT` in its environment, 30 000 ms by default, covers every server | nothing |
| Cursor, Kiro, ZCode | not carried: the registry targets the bridges at Claude Code and Codex only | nothing |

Codex has a second wait that no server key reaches: the first step of a session lists only the
servers that answered within `mcp_optional_startup_grace_ms` (1000 by default), a setting for
the whole agent. A request that mentions a server as `[$name](mcp://name)` makes Codex wait for
that server, which is how `/install` probes the bridges.

## What it owns, and what it leaves

Every object deployed is a `managed_resources` row, written when the transaction commits;
every write leaves a receipt and every overwrite a backup (WFR-015). Objects that carry `wf`'s marker — the
managed prompt block, a hook handler whose command is `wf hook …` — are adopted when found.

- **A same-name object `wf` did not put there** is a conflict: reported, never overwritten.
  A whole file carries no marker, so an existing Kiro steering file of the prompt's name is
  one too.
- **A symlinked document or skill directory** is a conflict: `wf` never writes through a link,
  and one linked file does not stop the rest of the apply.
- **A rule a person edited** is kept and no longer managed, unless `rules.enforced` in the
  policy lists it.
- **A file that does not parse** is reported unreadable and left exactly as it is.
- **A kind whose team definitions do not read** changes nothing of that kind: a broken file is
  not an empty set, so nothing is removed because of it.
- **Something the team repository dropped** is removed if unchanged, and forgotten but kept if a
  person changed it.

## What the policy decides

`workflow/teamai/policies.yaml`, validated by `wf guard` and refused whole by a machine when
invalid:

| section | decides |
|---|---|
| `mcp` | whether servers are applied at all, the launchers a stdio server may run (`wf` always may), the hosts a remote server may reach (`*.txehq.com` covers the apex and its subdomains) |
| `hooks` | whether usage hooks are applied, and that only handlers running `wf` are written |
| `rules` | which rules are restored over a person's edit |
| `env` | which environment keys may be set; `PATH`, `HOME`, `LD_*` and `DYLD_*` never, nor a secret-looking value |
| `usage` / `sessions` | whether usage is tracked, how long it is kept, and what makes a session worth logging |

## Usage and sessions, kept on the machine

The usage dispatchers record skills, tools, prompts and session boundaries into the state
database, `usage.jsonl` (rotated at 16 MB) and `known-skills.json`. A prompt is a count and a
correction flag; only a session's first prompt is kept as text, redacted and shortened to 160
characters. A session's summary is updated at every turn's end; one with enough distinct tools
or an intervention goes into `sessions/YYYY-MM.md`, one entry per session, updated in place.
Events past `retention_days` are pruned once a day.

```bash
wf usage --since 30d --agent claude   # top skills, tools and agents, by day
wf sessions                           # recent sessions, newest first
wf sessions show <id>
wf sessions save                      # log the latest session regardless of the bar
wf sessions prune
```

## Commands

| command | what it does |
|---|---|
| `wf agents` (`wf agent`) | every known agent: installed here, managed, disabled |
| `wf agents detect` | the same, with each installed agent's version |
| `wf agents status [--agent <id>]` | objects in place per agent |
| `wf agents register <id>` | manage an agent and deploy the active release into it |
| `wf agents unregister <id>` | remove what `wf` owns there and stop managing it |
| `wf install --agent <ids>` / `wf sync --agent` / `wf repair --agent` | the lifecycle, scoped |

Which agents a machine manages: Claude Code and Codex wherever they appear, as 1.x did,
unless a person unregisters one; any other agent once it is registered.
`wf install --agent all` registers every agent it finds; an agent installed later is picked
up by `wf agents register <id>`.

## Acceptance criteria

- One install deploys skills, hooks with the installed binary's absolute path, the
  `wf-history` server and the prompt into every detected agent, and a second apply changes
  nothing (`install_deploys_every_resource_into_every_detected_agent`).
- For any agent and any subset of the team's resources, one converge settles it
  (`one_converge_settles_any_agent_over_any_subset_of_resources`, property-tested).
- A server that runs `wf` is written with the installed binary's path even under a launcher
  allowlist that names only `npx`
  (`a_server_that_runs_wf_gets_the_installed_binary_whatever_the_command_allowlist_says`).
- Usage hooks print nothing, and what they record is what `wf usage` and `wf sessions` report
  (`usage_hooks_record_sessions_that_wf_usage_and_wf_sessions_report`).
- An unregistered agent keeps nothing of `wf`'s, repair leaves it alone, and registering it
  again restores everything
  (`an_unregistered_agent_is_cleared_and_left_alone_until_registered_again`).
- A binary that did not apply the active generation applies it again, from session start in the
  background and from `wf sync` (`a_generation_the_running_binary_did_not_apply_is_applied_again`).
- `wf uninstall` removes every deployed object and keeps a person's own servers and comments
  byte for byte (`uninstall_removes_only_owned_objects_and_preserves_the_executable`).
- A machine on the latest published release crosses over: that release's own binary commits
  this one, and this binary then applies the agent layer
  (`a_machine_on_the_previous_release_crosses_over_to_this_one`, run in CI against the real
  release).
- One symlinked document is a conflict and every other object still lands
  (`a_symlinked_document_is_a_conflict_and_everything_else_still_lands`); a rollback never
  reverts a file changed after `wf` wrote it
  (`a_rollback_leaves_a_file_that_changed_after_wf_wrote_it`).
- Hooks stay fast while an apply waits on a slow Codex
  (`a_slow_codex_does_not_stall_hooks_while_an_apply_runs`) and with a long usage history
  (`a_long_usage_history_does_not_slow_the_session_start`); parallel sessions lose no log
  entry (`concurrent_saves_lose_no_session`, `appends_during_the_daily_trim_are_never_lost`).
- Budgets, measured against a database on disk: an agent detected in under 50 ms, a usage hook
  recorded in under 10 ms, a thousand skills deployed in under 5 s — both counted in durable
  writes on a disk slower than a developer's, such as a CI container's — and an installed
  machine's session start inside 100 ms at p95 (`crates/wf-agents/src/budgets.rs`,
  `an_installed_machine_stays_inside_the_budget`).
- Real Claude Code and Codex read the servers the layer wrote into an isolated home
  (`real_agents_read_the_servers_wf_deployed`, run with `--ignored`; CLM-009).

## What it does not do, and does not verify

- **Pull a team repository.** Git and HTTP modes are parsed and refused; team resources are the
  ones that ship in the verified release.
- **Upload anything.** `usage.storage: remote` is refused until an uploader exists.
- **Prove an agent loads what is on disk.** Only Claude Code's and Codex's MCP documents were
  observed read by the real agent. Skills, rules, subagents and hooks in Cursor, Kiro, ZCode and
  OpenClaw follow those agents' documented and `teamai-cli`'s observed formats, and are checked
  by the files `wf` wrote, not by a session.
- **Emit agent-specific hook output.** Every agent's session-start hook receives the Claude
  Code–shaped JSON that Codex also reads; an agent that ignores it loses the session-start
  notices, not the hook.
- **Resolve a secret** or write one, or install, upgrade or configure an agent beyond the
  objects above.
- **Switch ZCode's hooks back on.** ZCode runs config-file hooks only when `hooks.enabled` is
  true; `wf` sets it where it is absent and leaves a person's `false`, so `wf`'s hooks do not
  run there either.
- **Delete a document it emptied.** Removing `wf`'s keys, handlers or block leaves the file:
  an agent `wf` created `mcp.json` or `CLAUDE.md` for keeps `{"mcpServers": {}}` or an empty
  file after `wf uninstall`, and an emptied `skills/` directory stays.
