---
last-verified: 2026-09-17
---

# /acceptance - builder self-evidence

**Node:** WF-ACC · **Spec (authority):** `Project Magi/Workflow/Specs/Session/Acceptance.md`
**Status:** shipped · **Skill:** [`skills/acceptance/SKILL.md`](../../../skills/acceptance/SKILL.md)

Acceptance drives the real delivery surface, captures evidence, checks complete
coverage, renders a complete local report with Jinja2, and publishes it to
engapp.dev with `publish-artifacts`. Each delivery has one published report: the
first round records its URL and artifact id, and each repair round republishes the
complete current report in place at that URL. It supports CLI, web, Electron,
native macOS, and iOS Simulator surfaces, and reads a repository's
`.agents/acceptance/` adapter first. Error states come from real conditions: a
stopped service, requests blocked through CDP `Network.setBlockedURLs`, or invalid
input.

For frontend deliveries it applies [ui-text-simplify](ui-text-simplify.md) to the affected
rendered states and interactions. `/ic` deliveries read the persisted UI text checks
from the local or ticket checklist, reconstructing stale or missing checks before
verification; a frontend review fix runs a new round, which republishes the report
and updates the PR screenshots.

It does not use LobeHub's server or `lh` CLI. Plans and reviewer decisions remain
local and are carried into the complete HTML report of each round. For GitHub PRs
and Issues, the skill installs/uses `gh-image` when needed, inserts returned
screenshot Markdown into a matching template section, and links the full
engapp.dev report in the associated PR body.

## Acceptance criteria

1. A real delivery surface is driven and every required check has the declared,
   inspected evidence type.
2. The complete report includes requirement, plan, outcomes, provenance,
   evidence, coverage, limitations, and follow-ups, and renders without local
   or private-machine dependencies.
3. The report is published and read back from engapp.dev at the one URL recorded
   for the delivery, and a repair republishes it in place; failed publication is
   reported as blocked and never presented as acceptance.
4. A matching GitHub template receives inspected screenshots in its screenshot
   section, and an associated PR body contains the complete report URL.

Upstream provenance and the adaptation boundary are recorded in
[`references/upstream.md`](../../../skills/acceptance/references/upstream.md).

Publishing dependencies use the installed Magi sibling skill and a verified immutable
`wf` release. The dependency guide does not install standalone skills from `main` or
compile a source fallback. A successful publish dry-run is not an authentication check;
report an unavailable compatible release or Access login as a publishing blocker.
