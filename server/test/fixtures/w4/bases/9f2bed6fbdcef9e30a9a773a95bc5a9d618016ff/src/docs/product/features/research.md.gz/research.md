---
last-verified: 2026-09-28
---

# /research — reference lookup that ends in a plan

**Node:** WF-RES · **Spec (authority):** `Project Magi/Workflow/Specs/Research/Research.md`
**Status:** shipped v1 · **Skill:** [`skills/research/SKILL.md`](../../../skills/research/SKILL.md) · **Tool:** none — it composes explorer sub-agents, `/history`, `/decide`, `/publish-artifacts` and `wf obsidian`

Stage 2 of `/lfg`, stage 3 of the spine by default. Finds the precedent locally and on the
web and turns the brief into a spec and plan where every recommendation carries its source
and every part carries test plan and acceptance criteria. The tier call to `/deep-research` is
made at entry and written down.

## The contract it presents to its callers

| | |
|---|---|
| In | `Project <Product>/Features/<slug>/Brief.md`; the repository checkout |
| Out | `Project <Product>/Features/<slug>/Research.md`, filed through `wf obsidian --kind research` |
| Next | `/plan` takes the plan section to a locked plan; `/ticketing` then selects tickets from its parts |

## The shape it was built to

Refined on 2026-09-07 at ding's direction, as the second step of decomposing `/lfg` into step
skills:

- **Local research is a fan-out of three explorer sub-agents**, one lens each — *reuse*
  (what exists to build on), *coverage* (everything the requirement must touch, and the
  adjacent behaviour that must not change), *gaps* (what is missing or in the way). Each
  claim carries a path or the command that showed it; the lead reconciles disagreements by
  reading the code, and reads `/history`, the corpus and Linear itself.
- **Web research has two kinds.** Targeted lookups the lead does itself, primary sources first.
  And **Deep Research handed to the user as one clickable ChatGPT link**
  (`https://chatgpt.com/?model=gpt-6-pro&hints=research&prompt=<url-encoded prompt>`), whose
  prompt carries the intent, the project's constraints with the refactorable parts flagged,
  the open questions, an instruction to search widely and multilingually and compare, and a
  request for one complete markdown document. The user brings the markdown back; it is read
  in full, by one reader sub-agent when long, and folded in with its references.
- **Every recommendation carries its reference**, path or URL with version and date read.
- **Convergence through review passes** (Planning Corpus Standard): draft, Q&A, adversarial
  review by a different model, converge, lock.
- **The tail is the standard chain**: publish → `wf obsidian --kind research` → one Linear
  comment with the vault path and URL.

## Acceptance criteria

The node carries none; these are authored from its contract, the corpus standard and the
direction of 2026-09-07. The node owes them.

| # | Criterion | State |
|---|---|---|
| 1 | On a real brief, the output has all nine sections, and every recommendation names a reference. *(verify: read the document)* | **not yet exercised** |
| 2 | The tier call is stated at the top with its reasoning. *(verify: read the document)* | not yet exercised |
| 3 | Three explorer digests exist — reuse, coverage, gaps — each claim with a path or command, and disagreements between them are resolved by reading the code. *(verify: transcript + the local-findings section)* | not yet exercised |
| 4 | When Deep Research was used, the user received one clickable link, the prompt carried the five required parts, and the returned markdown was read in full — by a reader sub-agent when long — with its references preserved. *(verify: transcript + the web-findings section)* | not yet exercised |
| 5 | Every buildable part carries criteria with a verification method, so ticketing selects rather than authors. *(verify: hand the plan cold to /lfg's ticketing)* | not yet exercised |
| 6 | An adversarial review by a different model ran before the lock and its findings were triaged on record. *(verify: transcript)* | not yet exercised |
| 7 | The vault holds `Research.md` and the epic carries the comment. *(verify: the vault, Linear)* | not yet exercised |

## Divergences from the node — recorded, not normalized

- **`/deep-research` is not shipped.** The escalation is made and recorded; the Deep Research
  handoff supplies breadth, not the adversarial multi-agent corpus the deep tier specifies.
- **The ChatGPT link is the one route to Deep Research.** It relies on `hints=research` and
  `model=gpt-6-pro`, which are not a published API.
- **The explorer fan-out requires sub-agents.** A harness without them stops the run with
  that error.
- **Markdown cannot be published directly** (TXE-1672); the vault copy is the durable record.
- **The spec opens with the complete story and its goals, functional and non-functional**,
  before the parts (linhaoz, 2026-09-28). The node does not say this yet.

## Status notes

TXE-1674 (Backlog) covers this skill and suggested building it first, because its chain is the
one the other document skills copy. Built and refined here without that ticket being claimed;
the ticket should be updated when this lands.
