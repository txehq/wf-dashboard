---
last-verified: 2026-09-08
---

# Magi — stage 1, the sensor

**Node:** WF-MAGI · **Spec (authority):** `Project Magi/Workflow/Specs/Magi/Magi.md`
**Status:** stage 1 shipped (TXE-1805); stages 2–5 not started · **Tool:** `wf magi measure` ([`crates/wf-magi`](../../../crates/wf-magi)) · **Skill:** none — Magi has no invocation

Counts review/fix rounds per merged pull request, with the covariates any later comparison
needs, and does nothing else. The whole Magi design is a control loop on this number, and until
this shipped it was not measured anywhere.

## The idea it is built on

**Derived, not collected.** A round is a review at head H followed by a push. That is already in
every PR's timeline, so the baseline needs no webhook, no service and no Actions — a read of
merged PRs produces it. This is the consequence of the ingestion rule (Magi Service S1): GitHub
is the event log, and Magi observes it.

**Rebuilt in full on every run.** No incremental state, so nothing to corrupt and nothing to
migrate. The ledger at `<state>/magi/<owner>_<repo>.json` is always a fresh derivation from
GitHub — the rebuild test from the ingestion design, embodied rather than promised.

## The first measurements

| repository | window | merged | reviewed | N mean | median | max |
|---|---|---|---|---|---|---|
| `capsohq/txe` | last 40 merged | 40 | 24 | **1.2** | 1 | 7 |
| `capsohq/tokun-cn` | last 60 merged | 60 | 6 | 2.3 | 0 | 9 |

The "five" in the design brief is the tail, not the centre. On the main repository most reviewed
PRs clear in one round; `#2032` took seven on the largest diff in the window (+2,509 / −15,548),
`#2030` took five. On tokun-cn, `#347` took nine.

## Two things the first run found

**The main repository was invisible.** The sensor first recognised only `/review-pr`'s format
and reported **0 of 40** txe PRs as reviewed — the `NO-PASSES` guard fired rather than a clean
zero, which is the point of having it. The main repository's reviews come from the fix loop in a
second dialect: `## Codex review — pass N (…)` with one `### HIGH n —` heading per finding, no
marker, and three header spellings in eight consecutive PRs. The sensor now parses both, with
the real headers as test fixtures. **The fix loop has no machine contract** — TXE-1806.

**The loop declares more passes than it posts.** `#2033`: 2 rounds pushed, 8 declared. `#2027`:
2 versus 6. The push-derived count is a lower bound on the loop's real iteration; the declared
number is the loop's own. Both are recorded, and where they disagree that is data — not noise
to reconcile away.

## What is verified

| # | Criterion | Verified by |
|---|---|---|
| 1 | A real PR counts correctly | `the_real_pr_counts_ten_passes_and_nine_rounds` — `tokun-cn#347` as read from GitHub: 10 passes, 9 followed by a push, hand-counted first |
| 2 | A clean pass is zero rounds | `a_single_clean_pass_is_zero_rounds` — the positive control; a matcher that always says "followed" passes criterion 1 and makes every clean PR look like a round |
| 3 | A force-pushed head counts as followed | `a_review_at_a_force_pushed_head_counts_as_followed` — treating an absent head as clean makes a history rewrite look like a perfect pass |
| 4 | Only marked or headed reviews are passes | `only_marked_reviews_are_passes` — a human's LGTM is not a pass; neither is a review that mentions the reviewer |
| 5 | Both dialects parse, all header spellings | `the_fix_loops_three_header_spellings_all_parse`, `the_detector_dialect_still_parses_unchanged` |
| 6 | A terminal summary is not a pass | `the_fix_loops_terminal_summary_is_not_a_pass` — `txe#2038` posted only "5 passes, 44 findings" |
| 7 | Severity counts per dialect, prose headings excluded | `severity_parses_the_contract_headings_and_nothing_else`, `the_fix_loop_severity_is_one_heading_per_finding` |
| 8 | A continuation pass inherits its model | `a_same_thread_pass_inherits_the_previous_model` — the loop writes `(same thread, …)`, which stratifies nothing |
| 9 | Weekly aggregation counts reviewed PRs only | `weekly_aggregates_reviewed_prs_only` — an unreviewed PR in the denominator makes an unreviewed week look perfect |
| 10 | Weeks start on Monday | `a_week_starts_on_monday` |
| 11 | The whole derivation works on real repositories | the table above; two minutes for 60 PRs |

## What is not claimed

- **No attribution.** Stage 2 is a **case record** per finding — observations kept apart from hypotheses, citations pinned by revision — written by `/fix-pr` at triage, and a windowed digest built from them (Magi node M2, M8, ballot 2026-09-08). Not a label: labels are derived from cases for counting and are never the artifact.
- **No loop-dynamics tag.** Separating a real-defect round from a finding-inside-the-previous-fix
  round needs the finding-to-diff intersection. Stage 2. Until then N is the total.
- **No lead time, no escaped defects.** Both need Linear; both are guards on the node, not
  derivable here.
- **The declared pass count is trusted as written.** It comes from prose the loop wrote; where
  it says 8 and 3 reviews were posted, the sensor cannot tell whether five passes ran
  unposted or the loop miscounted.
- **Pull requests are matched to tickets by id in title and body only.** No Linear read.
- **Two minutes per 60 PRs**, two `gh api` calls per PR. Fine for a periodic job; not a
  dashboard read.
