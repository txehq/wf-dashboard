---
last-verified: 2026-10-05
---

# /claim — take the ticket, and read everything it points at

**Node:** WF-IC (step 1; no separate node yet) · **Spec (authority):** `Project Magi/Workflow/Specs/Session/IC Session.md`
**Status:** shipped v1 · **Skill:** [`skills/claim/SKILL.md`](../../../skills/claim/SKILL.md) · **Tool:** none — it composes the Linear MCP and `/history`

The IC's first act, as a step skill: pick an eligible ticket if none was named; claim it with
check-write-recheck; read the ticket whole — description, every comment, every attachment and
inline image, the parent epic; read the Obsidian documents behind it and the repository's own
instructions; then write the **requirements checklist** and post it on the ticket with the
marker `<!-- ic:checklist -->`, so every later step and every later session reads one list.
It builds nothing and re-scopes nothing.

## The contract it presents to its callers

| | |
|---|---|
| In | a ticket id, a Linear URL, or the pool; Linear through the agent's MCP |
| Out | ticket In Progress with a claim comment; the checklist comment; the declared toolchains echoed for `/readiness` |
| Next | `/readiness`, then `/implement` |

## Design decision — the checklist lives on the ticket

The earlier `/ic` kept the checklist only in the worktree. That is state on one machine, which
is what the Fix PR design (TXE-1750, ballot S5) ruled out: GitHub and Linear are authoritative,
a local file is a disposable cache. So `/claim` posts the checklist as a ticket comment,
`/implement` mirrors it into the worktree and writes the ticks back to the same comment with the
head SHA, and `/ready-for-review` reads that comment as one of its three conditions.

## Acceptance criteria

From the node, for the claim half:

| # | Criterion | State |
|---|---|---|
| 1 | A second `/claim` cannot claim the same ticket. *(verify: concurrent claim test)* | met for any gap wider than one Linear round trip; **not proven below that** |

Authored here:

| # | Criterion | State |
|---|---|---|
| 2 | Every attachment and inline image on the ticket was read, or the one that could not be is named in a comment on the ticket and the run stopped there. *(verify: transcript)* | **not yet exercised** |
| 3 | The checklist comment exists, carries the marker, and has one line per requirement drawn from criteria, description, comments and attachments, each with a verification method. *(verify: the comment against the ticket)* | not yet exercised |
| 4 | A ticket without criteria ends in a comment naming the gap and no checklist, not in invented criteria. *(verify: planted ticket)* | not yet exercised |

## Divergences — recorded, not normalized

- **Not atomic.** Linear's API has no transaction; the journal that would make the claim one
  step is not built.
- **No node of its own.** Authored from WF-IC; a node is owed.
- **Inspect and adapt at the start** (linhaoz, 2026-10-05): before the checklist, the ticket's
  premises are checked against the code as it is now and open tickets and PRs are searched for
  the same work; a moved premise or work under way elsewhere is an M5 comment, and the run stops
  until the LFG answers.

## Status notes

Built 2026-09-08 as the first step of decomposing `/ic`; not yet run on a real epic.
