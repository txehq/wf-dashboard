---
last-verified: 2026-09-16
---

# Architecture — why the repo is shaped like this

Seven structural choices carry the repo, each recorded as an ADR with the alternative it
beat. ADRs are dated and immutable: a choice that changes gets a **new** ADR that
supersedes the old one, and the old one keeps its text. That is the difference between a
decision record and a wiki page — and why ADR-0001 is still here, superseded in scope and
intact in substance.

| ADR | Decision | Date |
|---|---|---|
| [0001](adr/0001-skills-ship-as-a-plugin.md) | Skills reach a session as a Claude Code plugin installed from this repo *(scope superseded by 0004, retired by 0007)* | 2026-09-04 |
| [0002](adr/0002-documentation-structure.md) | Audience-first docs tree, with the index pair and the generated-surface property | 2026-09-04 |
| [0003](adr/0003-spec-authority-stays-in-the-vault.md) | The Obsidian spec node is authority; in-repo records point, never copy | 2026-09-04 |
| [0004](adr/0004-one-binary-one-version.md) | One registry, one version, one binary — and why Rust replaced Go | 2026-09-05 |
| [0005](adr/0005-history-is-implemented-not-forked.md) | Local history search is written here rather than vendored from `ctxrs/ctx` *(superseded by 0006)* | 2026-09-05 |
| [0006](adr/0006-history-is-ctx.md) | Local history is ctx — pinned per `wf` release, installed and handed off by `wf`, exposed to agents as the `wf-history` MCP server | 2026-09-16 |
| [0007](adr/0007-one-agent-layer.md) | One agent layer deploys skills, rules, hooks, MCP servers, prompts and environment into every coding agent from configuration; the plugin is retired | 2026-09-16 |

Design authority for the workflow the skills implement is **not** here — it is the Obsidian
corpus `Project Magi/Workflow/`. These ADRs govern the repository.
