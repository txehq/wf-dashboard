---
last-verified: 2026-10-07
---

# /ticketing — reconcile with Linear, split by dependency, file, stop at the gate

**Node:** WF-LFG (stage 4 and the dispatch gate; no separate node yet) · **Spec (authority):** `Project Magi/Workflow/Specs/Session/LFG Session.md`, System Design §1–2, decision log #28
**Status:** shipped v1 · **Skill:** [`skills/ticketing/SKILL.md`](../../../skills/ticketing/SKILL.md) · **Tool:** none — it composes the Linear MCP, `wf obsidian` and `/ic` sub-agents

The end of `/lfg`'s pre-code half as one step skill: connect to Linear and learn the team's
shape; search what already exists and decide, per part of the plan, whether to **update** an
existing ticket, **relate** to one, **create** a new one, or **surface** a conflict; split new
work so that **dependent pieces share a ticket and independent pieces get their own**; write
each from the ticket template with an estimate and a recommended assignee from Linear history;
file the epic and `Tickets.md`; present the dispatch gate and stop; on "go", dispatch `/ic`
lanes wave by wave. There is no separate dispatch skill, by decision (ding, 2026-09-07).

## The contract it presents to its callers

| | |
|---|---|
| In | the locked plan and `Brief.md`; Linear through the agent's MCP |
| Out | the epic and its issues, each updated, related or created; `Tickets.md` with the reconciliation table, map and DAG; the plan at the gate; dispatched lanes on "go" |
| Next | `/ic`, per ticket |

## The rules it splits and reconciles by

- **Search before writing.** Every part is checked against open and recently closed tickets
  and the vault's synced `Linear Issues/` folder; a duplicate ticket and an update that
  swallows someone's open work are the two failures the reconciliation table prevents. A
  conflicting ticket is surfaced to the user, never overridden.
- **Dependent together, independent apart** (ding, 2026-09-07). Connected components of the
  plan's dependency graph become tickets; unconnected components become the parallel lanes
  the gate offers. A component larger than one PR is cut at its narrowest dependency edge
  with `blocked by` set and the reason recorded; each ticket aims at under 500 changed lines
  (generated and lock files aside) and under 15 changed functions (linhaoz, 2026-10-05).
- **The bank's Phase 4-ext checks the cut** — smallest valuable slice first, genuine
  foundations, exact outcomes and out-of-scope, testable scenarios, visible cross-cutting
  work, release gates apart from order, external blockers named. Its confirmation question
  is the gate itself.
- **The [ticket template](../../../skills/ticketing/references/ticket-template.md)'s
  sections** — background, goals, scope, constraints (optional), acceptance criteria, expected
  artifacts — then the planning notes and the prior research `/ic` reads; fields set on the
  issue, never only in a comment. Estimate and
  assignee are read from Linear's record; the assignee is recommended, not set.
- **The gate is the last human question before execution.** go / go wave N / nothing.

## Acceptance criteria

Authored here; the step has no node to inherit from.

| # | Criterion | State |
|---|---|---|
| 1 | Linear is proven reachable before anything is written, and an unauthenticated MCP stops the run with the one-line fix. *(verify: transcript)* | **not yet exercised** |
| 2 | Every part of the plan has exactly one reconciliation decision — update, relate, create, or surfaced — recorded in `Tickets.md`, and no duplicate of an existing open ticket is created. *(verify: `Tickets.md` against Linear)* | not yet exercised |
| 3 | No two tickets in the same wave depend on each other, and every dependency between tickets is a Linear relation. *(verify: the DAG against the issues)* | not yet exercised |
| 4 | Every created or updated issue carries the ticket template's sections in order, the planning notes and the prior research, with estimate and recommended assignee reasoned from Linear history and no assignee set. *(verify: the Linear epic)* | not yet exercised |
| 5 | The run stops at the gate; nothing is dispatched without "go" or "go wave N"; lanes run `/ic` in their own worktrees, respect the waves and the cap, park on failure, and ask nothing between waves. *(verify: transcript, scripted failure)* | not yet exercised |

## Divergences — recorded, not normalized

- **No node.** Authored from WF-LFG stage 4, System Design §1–2, log #28 and the bank; a node
  is owed.
- **The split rule and the estimate/assignee recommendations are extensions** of the corpus,
  from ding's direction of 2026-09-07.
- **The ticket template's five sections are an extension** too, from ding's direction of
  2026-09-14; they replace the nine sections, and the planning notes carry what the five have
  no home for.
- **The optional constraints section, the prior research and the exhaustive acceptance
  criteria are extensions** too, from linhaoz's direction of 2026-09-28.
- **No journal.** Lane state is Linear status and PRs until Orchestration State exists.
- **`/devpod` is not shipped.**

## Status notes

Built 2026-09-07 as the fourth step of decomposing `/lfg`; not yet run against a real Linear
team.

Linear authentication follows `/install-manager`: use DCR when initiating Codex OAuth,
reuse an existing authenticated connection, and verify it with a read before filing work.
