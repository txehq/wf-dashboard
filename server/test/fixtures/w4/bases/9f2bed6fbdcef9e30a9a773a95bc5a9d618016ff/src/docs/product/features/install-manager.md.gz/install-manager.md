---
last-verified: 2026-09-16
---

# /install-manager — the workflow's own control surface

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/LFG Session.md` (WF-LFG).
Where this record and the node disagree, the node wins.

## What it is

`wf` is the local manager for everything this organization installs into a coding agent:
skills, rules, subagents, the global prompt block, hooks, MCP servers, environment and the
readiness profiles — into every agent it manages, through one agent layer
([record](agents.md)). `/install-manager` is the skill that tells a session how to read it and what to run when
something is missing.

The skill is the smaller half of the node. WF-LFG describes an umbrella session — scoping,
planning, ticketing, then a dispatch gate — and that half is [`/lfg`](lfg.md). This is the
half a session needs at the moment a skill turns out to be absent or stale.

## `/lfg` and `wf` are not the same thing

They were, for one release, and the collision is why this skill was renamed.

| | what it is | state |
|---|---|---|
| `/lfg` | the architect's session entry point: scoping, research, ticketing, then the dispatch gate | shipped v1 — [record](lfg.md) |
| `wf` | the CLI that installs and maintains everything this organization ships into a coding agent | shipped |
| `/install-manager` | the skill that tells a session how to read `wf` and what to run when something is missing | shipped — this record |

`/lfg` is not an installation command and never was. Until 1.1.0 the binary was called `lfg`
and this skill was invoked as `/lfg`, so the name pointed at an install manager while the
workflow diagram pointed it at an entry point. The binary is now `wf`, this skill is
`/install-manager`, and `/lfg` is free for the node that owns it.

One node still covers both halves in the corpus, which is why `WF-LFG` appears twice in the
[product roster](../README.md). Splitting it is a change to the spec, not to this repository.

## What it covers

| Command | Answers |
|---|---|
| `wf status` | which release is active, what has drifted, what needs a reload |
| `wf doctor` | the above, plus everything that would block a repair |
| `wf agents` | which agents are on this machine and which ones `wf` manages; `register` / `unregister` change that |
| `wf repair [--agent <id>]` | put the organization's version back, in every managed agent or one |
| `wf usage` / `wf sessions` | what this machine's sessions used, and the sessions worth keeping |
| `wf rollback --to <ver>` | return the machine to an earlier release |
| `wf backup list` / `restore <id>` | every file overwritten, and how to undo one |

Each of the eleven component states names an action rather than a severity. Two surprise
people. `credential_missing` is a degraded capability, not a failure, and a session still
starts. `unverified` is not even a degradation: it is what an `agent-oauth`
component reports because its login lives in a browser and a token store `wf` does not open.
Both shipped MCPs are that shape, so every machine carries two, and the action it names is a
real read through the server rather than another look at the status.

## Two findings outside the state table

`wf doctor` reports ctx, `PATH` and leftover bridges beside the component states. None of these means the
workflow install failed, and each names its fix.

| Finding | What it means | Fix |
|---|---|---|
| `capso.ctx.binary` | the last convergence of ctx recorded an error; `wf status` shows the row as `blocked` | the finding's text names the fix for the recorded code |
| `NOTE` about ctx | `~/.local/bin/ctx` is missing, differs from the pin, or its setup has not finished | `wf install` |
| `CTX-DAEMON` | ctx reports its daemon disabled, not running, or its heartbeat stale | `wf history index mode auto` |
| `CTX-SEMANTIC` | `ctx semantic status` reports `failed`; `model_load_failed` means the ONNX Runtime is missing | `wf install` |
| `CTX-HEALTH` | `ctx doctor --format json` gave no answer | `wf install` |
| `WF-PATH` | the directory holding `wf` is not on `PATH`. Hooks and MCP servers use `wf`'s absolute path, but skills tell a session to run `wf …` in its shell | put `~/.local/bin` on `PATH`, then start a new session |
| `MCP-ORPHAN` | a bridge of `capso-linear` or `capso-rackspace-spot` outlived the agent that started it and holds that service's sign-in; later bridges wait on it and print no page | the `kill` command the finding names, then the sign-in again |

Two ctx codes need more than `wf install`, because `wf` does not replace a ctx whose daemon it
could not hand off:

- **`CTX-HANDOFF`** — the installed ctx has a daemon, and its handoff did not report a
  quiescent installation. The old ctx is left in place; a ctx before 1.0 has no daemon and is
  replaced without a handoff. Stop its daemon once by hand (`systemctl --user disable --now ctx.service` on Linux,
  `launchctl bootout gui/$(id -u)/rs.ctx.daemon` on macOS), move `~/.local/bin/ctx` and
  `~/.local/bin/ctx.install.json` aside, and rerun `wf install`.
- **`CTX-FOREIGN`** — `~/.local/bin/ctx` is absent and another ctx is on `PATH`, and `wf` does
  not install a second copy beside a live one. Run that ctx's own handoff,
  `ctx daemon disable --prepare-uninstall --format=json`, remove it with the tool that installed
  it (Homebrew, mise, cargo) once the receipt reports success, then rerun `wf install`.

`CTX-INTEGRITY` means a download did not match the lock and GitHub's digest for it: nothing
ran, the file is gone, the existing ctx is untouched, and a later convergence retries it.
`CTX-SETUP` means a lifecycle command failed, and `CTX-RUNTIME` that the pinned ONNX Runtime
could not be expanded; the next convergence retries either.
`wf repair` and `wf rollback` stay offline and never touch ctx; the next session start
converges it to the active release.

## Acceptance criteria

- Every state `wf status` can print appears in the skill's table with the command that
  resolves it.
- `--dry-run` on `install`, `sync`, `repair`, `rollback` and `uninstall` previews managed
  changes without applying them. Install/sync can still download and expand assets in
  temporary directories, while leaving managed files and persistent state unchanged.
- `wf release build-local` plus `wf install --source local:<dir>` completes an install
  with no GitHub release involved, and `wf status` reports the result as unattested.
- Install/sync remember the release repository and channel. `--branch` is recorded
  metadata, not a selector for unpublished branch contents; repair/rollback use local generations.
- `wf uninstall` removes only objects it has a receipt or a `managed_resources` row for, and
  leaves user skills, MCP definitions and history sources untouched. It keeps `~/.local/bin/wf` and
  `~/.local/bin/ctx`: deleting ctx's binary without its handoff leaves the daemon crash-looping.
- `wf status` and `wf doctor` show a recorded ctx convergence error as a `blocked`
  `capso.ctx.binary` row, so the verdict is not 一切正常; a missing or unpinned binary is a
  `NOTE`. `wf doctor` reports `CTX-DAEMON`, `CTX-SEMANTIC` and `CTX-HEALTH` from ctx's own
  verdict, and `WF-PATH` when `wf`'s directory is not on `PATH`. The skill carries every one
  with its fix, including the manual step for `CTX-HANDOFF`.

## What it does not yet do

- The scoping, planning and ticketing half of WF-LFG — that is [`/lfg`](lfg.md). `/install-manager`
  is the control surface, not the session entry point.
- Report on machines other than this one. There is no fleet view and no telemetry; every
  number `wf` knows is local.
- Repair an agent's own installation. The agent layer writes and verifies the objects `wf`
  owns in an agent's configuration; it never installs, upgrades or configures the agent
  beyond them.

## Verification limits

A healthy doctor result can include `credential_missing` and `unverified`. The second states
the absence of an observation rather than filling it in: a definition read as `current` before
any OAuth login is a capability the doctor is reporting without having seen it, which on the
machine that found [#40](https://github.com/txehq/txe-workflow/issues/40) meant three unusable
Linear servers under a doctor saying `current`.

What has not changed is the limit itself: no state proves connectivity. Verify in each agent
separately; one agent's login is not shared with the other. The installer's next-step text
must say "configured" until a connection was actually checked.

Session start and doctor answer the credential question with one rule
(`wf_agents::credentials::credential_status`), so the two cannot disagree on the same machine — a doctor that
recomputes while the hook reads a row written at install time leaves a terminal repeating a
warning the doctor has already withdrawn. The rule is shared; what it returns is not a claim
that anything works — `unverified` is the answer for both shipped MCPs, on every
machine.

Manual `wf hook session-start` calls prove the dispatcher runs. Automatic dispatch needs
an observed new agent session as well. Skills are directories in each agent's skills folder;
`wf agents status` counts what is in place per agent.

On 2026-09-11, the README path was exercised on Apple Silicon macOS with immutable stable
1.5.0: release and all three downloaded assets verified, binary backed up, install run,
and both Claude Code 2.1.259 and Codex 0.154.0 reported Magi 1.5.0 enabled. Strict doctor
passed with Codex Linear marked `credential_missing`. The two prompts each had one managed
block; both manual dispatchers returned JSON and added a journal record. Codex hook trust
was already granted. New-session automatic dispatch and Linear OAuth remain separate,
unverified checks; Claude's connection probe reported authentication required.

## Linear OAuth registration (1.5.2)

Codex setup and recovery commands explicitly select DCR for Linear, including the
immediate OAuth flow launched by `mcp add`. Already configured servers use `mcp login`;
already authenticated servers are reused. The installed Codex must advertise the flag in
both commands' help. The choice is per-login and is not persisted in `config.toml`.

Evidence: on 2026-09-11, Codex 0.154.0's auto/CIMD flow produced Linear's “Invalid client.
The clientId provided does not match to this client.” Re-running the login with
`--oauth-client-registration dcr` completed successfully. Claude Code 2.1.259's native
`claude mcp login linear` also succeeded. This does not establish that every provider
requires DCR; the installer's override is scoped to `mcp.linear.app`.

See [Codex MCP documentation](https://developers.openai.com/codex/mcp#oauth-client-registration).
