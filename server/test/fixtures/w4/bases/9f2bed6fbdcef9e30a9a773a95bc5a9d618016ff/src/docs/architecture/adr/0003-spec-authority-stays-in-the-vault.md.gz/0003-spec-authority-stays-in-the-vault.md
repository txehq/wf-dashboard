# ADR-0003 — Spec authority stays in the Obsidian corpus

**Date:** 2026-09-04 · **Status:** accepted · **Rule:** [WFR-002](../../contract/CONTRACT.md#the-spec-is-in-the-vault-this-repo-does-not-fork-it)

## Context

Every skill in this repo implements a spec node in the Obsidian corpus
`Project Magi/Workflow/Specs/` — eighteen nodes, each with its purpose, contract, test plan
and acceptance criteria, converged through the Planning Corpus Standard's author ⇄ user ⇄
adversarial-review loop.

The obvious move is to copy those nodes into `docs/product/features/` so a skill and its
spec are reviewed in the same PR. The Docs Atlas is the argument against: `capsohq/txe`
grew a second spec home (`docs/superpowers/` beside `docs/specs/`), listed in no router,
and removing it cost a dedicated cleanup PR. A copy is not a copy for long.

## Decision

The vault node is authority. `docs/product/features/<skill>.md` is a **record**, not a
copy: what the skill is, how it is invoked, its status, its acceptance criteria as
implemented, and a pointer to the node. Where the record and the node disagree, the node
wins and the record is corrected.

`docs/index.yaml` carries each skill's node code (`WF-*`) and vault-relative spec path, so
the pointer is machine-readable and the roster can be rendered.

## Consequences

- One spec home. The failure the Atlas found cannot be reproduced here by construction.
- The repo is **not** self-contained: a reader without the vault can see what a skill does
  and how it is invoked, but not the full design and its rejected alternatives. That is the
  accepted cost.
- CI cannot verify a vault path resolves — the vault is not checked out in CI. `docsguard`
  checks the pointer is present and well-formed; a human check catches a moved node. This
  is a stated limit, not an oversight.

## Alternatives rejected

- **Mirror the nodes into `docs/specs/`.** Self-contained and PR-reviewable, at the price of
  two homes that drift — and the drift is silent, because both copies look authoritative.
- **Move the corpus out of Obsidian into this repo.** The corpus is a live planning surface
  worked in Obsidian with backlinks and Dataview across projects; extracting one project's
  workflow folder would split the vault instead of the repo.
