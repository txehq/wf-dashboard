---
last-verified: 2026-09-05
---

# /handover — transfer a ticket to another person

**Node:** WF-HAND · **Spec (authority):** `Project Magi/Workflow/Specs/Publishing/Handover.md`
**Status:** shipped · **Skill:** [`skills/handover/SKILL.md`](../../../skills/handover/SKILL.md) · **Tool:** `wf handover` ([`crates/wf-handover`](../../../crates/wf-handover))

Hands **ownership of a ticket** to someone else, at whatever stage the work has reached —
before it starts, mid-development, at a review boundary, or because a session is ending.

**Not `session-handoff`.** That skill files new `[CC<n>-<ws>]` issues so *my next session*
can resume *my* work. This transfers an *existing* ticket to *another person*, and the stage
is a variable rather than always "the end".

## The idea it is built on

A handover fails when the receiver reconstructs what the sender already knew. Three things
are expensive to reconstruct and cheap to write down — what is *verified* versus what merely
looks done, what was already tried and rejected, and why decisions were made. Everything
else is **derived, not narrated**: branch, HEAD, pushed-or-not, divergence, uncommitted
files, PR, checks, review decision.

That split is why there is a tool at all. Having the model run `git` and `gh` and transcribe
the output is where fabrication enters, and the failure mode is identical to a postmortem
written from memory.

## Acceptance criteria (from the node)

| # | Criterion | Verified by |
|---|---|---|
| 1 | Stage inferred correctly across the stages | `TestStageOnACleanCheckout`, `TestStageOnABranchWithWork`, `TestStageInReviewWhenAPRIsOpen` — real git fixtures for the first two |
| 2 | A dirty tree blocks, naming the count | `TestDirtyTreeIsBlockingAndCounted`; unpushed commits block too (`TestUnpushedWorkIsBlocking`) |
| 3 | Linear shows assignee change + dated comment linking the page | **not yet verified** — see below |
| 4 | Every derived fact carries the command that reproduces it | `TestRenderGivesTheReceiverAWayToCheckEveryFact` |
| 5 | Nothing asked that a command could answer | structural: the skill forbids re-gathering, and the tool emits every derivable field |

## What is not claimed

- **Criterion 3 is unverified.** The Linear half — reassign, `Instance` label, dated comment
  — is instructed in the skill but has not been exercised on a real transfer, because doing
  so means actually handing a live ticket to a real person. It stays open until a genuine
  handover happens.
- **The `in review` stage is unit-tested, not fixture-tested.** `gh` cannot be exercised
  against a local fixture repo, so the inference is tested directly while the other two
  stages run against real repositories. The gap is in the fixture, not the logic.
- **The receiver is assumed to be a person.** Returning a ticket to an unassigned pool is a
  different Linear operation (clear the assignee rather than set one) and is an open question
  on the node.
