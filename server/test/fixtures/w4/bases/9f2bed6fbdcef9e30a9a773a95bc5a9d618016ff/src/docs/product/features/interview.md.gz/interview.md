---
last-verified: 2026-10-05
---

# /interview — scoping

**Node:** WF-INT · **Spec (authority):** `Project Magi/Workflow/Specs/Session/Interview.md`
**Status:** shipped · **Skill:** [`skills/interview/SKILL.md`](../../../skills/interview/SKILL.md) · **Tool:** none — it files through `wf obsidian`

Stage 1 of `/lfg` and the first thing it runs; also standalone. Turns an idea into a
one-page brief the planning stage can work from without asking a single scoping question of
its own: listen → look before asking → ask only what changes the build → play back →
converge. Its particular job is the **boundaries** — an explicit, item-by-item out-of-scope
list — and a brief without one is not finished.

The shape is deliberately small. The battery-of-standard-questions machinery an earlier
draft carried was rejected (decision log #11): a question whose answer is discoverable in
the repo, memory or the corpus is friction, not diligence.

## The three phases, and the rule under every question

Distilled on 2026-09-07 from the vault note `+Inbox/+++ Workflow WIP.md` at ding's direction:

- **Phase 1, initiation and discovery** — asked before exploration only when the request is
  unclear; ends at a confirmation gate.
- **Phase 2, post-exploration confirmation** — the agent explores first (entry points, flows,
  storage, integrations, similar features) and every question carries the evidence; users
  are never asked to reconstruct the repository.
- **Phase 3, requirements and scope clarification** — only what materially changes external
  behaviour, contracts, risk or acceptance; closes with "which decisions do you keep, which
  do you delegate".

Every question has a **goal** the asker thinks through and never shows. Four treatments
decide whether to ask at all: investigable → investigate; changes the product outcome →
ask; changes an irreversible risk → must ask and record; low-risk implementation detail →
decide and record as a reversible default. Answers land in a ledger as confirmed, delegated
(with the default stated) or deferred, because silence is not agreement.

The full bank — Phases 1–6 with a goal per question, the angles table and the operating
rules — is [`skills/interview/references/question-bank.md`](../../../skills/interview/references/question-bank.md).
Phases 4–6 are asked by `/lfg`'s later stages and by `/ic`; the file says which.

## The contract it presents to its callers

| | |
|---|---|
| In | an idea, use case or change request in the user's words; product and feature slug when known |
| Out | `Project <Product>/Features/<slug>/Brief.md`, filed through `wf obsidian --kind brief`, standing alone |
| Next | `/research` reads it from that path; `/lfg` continues at stage 2 |

This is the interface every step skill in the spine is being given (2026-09-07): one owner
per step, an In/Out that names a file, and a caller that reads the file back rather than the
conversation.

## Acceptance criteria (from the node)

1. On a real use case, a run produces a brief answering all six standing topics,
   standalone-readable by someone who missed the conversation. *(verify: hand the brief
   cold to a second session; it plans without asking scoping questions)*
2. No question is asked whose answer was discoverable or obvious from context — inferred
   answers appear in the brief with their source. *(verify: transcript audit against the
   brief's inferred entries)*
3. The final playback was confirmed by the user before the brief was written. *(verify:
   transcript order)*
4. The interview ends at convergence — no filler rounds after an uncorrected playback.
   *(verify: transcript audit)*

Authored here, 2026-09-07:

5. The brief's out-of-scope list is non-empty and item-by-item. *(verify: read the brief)*
6. The brief is at `Project <Product>/Features/<slug>/Brief.md` with `wf obsidian`'s
   frontmatter and the folder index regenerated. *(verify: the vault)*
7. No goal text is shown to the user; every displayed question maps to a goal the transcript
   can be audited against. *(verify: transcript against the bank)*
8. Phase 2 questions carry evidence from exploration, and no engineering fact answerable
   from the repository was asked. *(verify: transcript audit)*
9. Every answer appears in the brief's decision ledger with one of the three states.
   *(verify: read the brief)*

## Status notes

Built under TXE-1601; first-production-run validation is still pending, which is the node's
own test plan. The node's open question — repo `docs/specs/<feature>/` vs the vault feature
folder — is answered by System Design §7 (ballot F27): the vault is the home, and a repo copy
is optional and secondary. The node should record that and close the question. The node is also thinner than the WIP
note the phases and bank come from; per WFR-002 the node should absorb them so the skill is
authored from its authority rather than from an inbox note.

Polished 2026-09-07 as the first step of decomposing `/lfg` and `/ic` into step skills:
triggers and proactive start added, a `/coding-session` journal reference removed (it does
not exist in v3), filing moved onto `wf obsidian`, and the run-time self-edit replaced by the
change-a-skill runbook, since the installed copy is a read-only cache.

Adjusted 2026-09-28 at linhaoz's direction: phase 3 also asks for non-functional
requirements; *How to ask* gains three habits — sharpen fuzzy words, check claims against the
code, and an optional concrete scenario; after the playback the agent restates what the user
said apart from what it inferred. The node does not carry these yet.

Adjusted 2026-10-05 at linhaoz's direction: before the playback, each requirement is held to
ISO/IEC/IEEE 29148 — necessary, unambiguous, singular, feasible, verifiable — and the set to
complete and consistent. The node does not carry this yet.

Adjusted 2026-10-07 at linhaoz's direction: questions are asked Socratically — the reasons,
assumptions and evidence behind a request, and the consequences of each answer. The node does
not carry this yet.
