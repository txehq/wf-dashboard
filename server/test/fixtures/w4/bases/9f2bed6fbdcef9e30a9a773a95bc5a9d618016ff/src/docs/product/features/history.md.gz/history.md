---
last-verified: 2026-09-22
---

# /history — what this machine already knows

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Research/Research.md` (WF-RES).
`/history` is the local-evidence half of that node; the reference-lookup half is
[`/research`](research.md), which calls this first.

## What it is

Every coding agent on a laptop writes a transcript, and nothing reads them.
[ctx](https://github.com/ctxrs/ctx) (Apache-2.0) indexes all of them into one place and searches
across them, so "didn't we already fix this?" becomes a question with an answer. It recognises
42 providers at v1.4.7, according to upstream's `docs/provider-support-matrix.json`. The
reimplementation it replaced recognised eight;
[ADR-0006](../../architecture/adr/0006-history-is-ctx.md) records why ctx replaced it.

`wf` installs ctx on every machine and gives it to agents two ways.

- **MCP tools, for search.** The `wf-history` server (component `capso.mcp.history`, command
  `wf history mcp serve`) is written by the agent layer into the MCP configuration of every
  agent `wf` manages that has one — Claude Code, Codex, Cursor, Kiro and ZCode — with `wf`
  as the installed binary's absolute path ([ADR-0007](../../architecture/adr/0007-one-agent-layer.md)).
  It exposes ctx's read-only tools: `status`, `sources`, `search`, `show_session`,
  `show_event` and `query_events`. In Claude Code they are `mcp__wf-history__<tool>`. The
  global prompt block tells every session to search with them when it hits a problem, an
  error, or friction with the user. When they are not loaded in a session, the skill has the
  session report that together with `wf doctor`'s result, and stop.
- **The CLI, for JSON output.** `wf history …` is exactly `ctx …`. `wf` execs
  `~/.local/bin/ctx` with the arguments unchanged, or `ctx` on `PATH` when its own copy is
  absent, and fails with `CTX-MISSING` when there is neither. Flags, help and output are ctx's,
  and JSON is `--format json`. When the ctx it runs is the one on `PATH`, `wf history` says so on
  stderr first, because that ctx's flags may differ: a ctx before 1.0 takes `--json` and rejects
  `--format`.

## What keeps it current

ctx's own daemon refreshes the index as agents write — a systemd user service on Linux, a
launchd agent on macOS. `wf` refreshes nothing at session start.

`wf` keeps ctx itself current. Each release's `workflow.lock.json` pins one ctx version and, for
each platform, the SHA-256 of the upstream binary and of the CPU ONNX Runtime sidecar published
beside it (`ctx-onnxruntime-<platform>.tar.gz`). A downloaded asset is used only after its digest
matches both the lock and GitHub's API. `wf install` converges ctx inline, and `wf sync`
converges it after an update. Session start starts the background updater, at most once an hour,
when the state database says ctx has not reached the active release's pin. ctx never upgrades
itself: the install has no hosted-installer marker, so ctx treats it as unmanaged and its
automatic upgrade is off.

Replacing a ctx that is already there starts with upstream's handoff,
`ctx daemon disable --prepare-uninstall --format=json`, and the binary is replaced only when its
receipt reports a quiescent installation. A ctx from before 1.0 has no daemon and no `daemon`
command; its argument parser refuses the handoff with `unrecognized subcommand 'daemon'`, and
that ctx is replaced directly, since nothing of it runs on. A refusal that needs a person
(`CTX-HANDOFF`, `CTX-FOREIGN`) stops the hourly retries of the `wf` that recorded it; a newer
`wf` retries once, because it may know how to lift it.

`wf status` carries ctx as the `capso.ctx.binary` row of the machine (`wf`). A recorded failure
makes it `blocked`, so the verdict cannot read 一切正常 while history is not the ctx this
release pins; a convergence still under way is a warning line. `wf doctor` adds ctx's own
verdict on itself, read from `ctx doctor --format json` and `ctx semantic status --format json`,
and asks only a ctx whose bytes hash to the pin with its convergence and runtime complete; any
other ctx is already a finding and is never run from `wf doctor`. The findings:
`CTX-DAEMON` when the daemon is disabled, not running, or its heartbeat is stale (repair:
`wf history index mode auto`), `CTX-SEMANTIC` when semantic search failed or is disabled
(repair: `wf install`), and `CTX-HEALTH` when ctx gave no answer, an answer without the fields
the verdict needs, an unknown state, or `ok: false` that nothing else explains.

## Semantic search

On for every machine. ctx loads a native ONNX Runtime and does not install one into an unmanaged
installation (upstream `docs/unmanaged-installs.md`), so `wf` does: before `ctx semantic enable`,
convergence expands the pinned sidecar into `~/.local/bin/onnxruntime/<VERSION_NUMBER>/<platform>/`,
the runtime cache ctx's loader searches beside its own executable. `~/.local/bin/onnxruntime` is
checked before anything is staged in it — not a link, not a mount point — and the archive is
expanded into a scratch directory there. The runtime then goes in whole, never file by file:
the old tree is checked for links and mount points (a bind mount included, which Linux reports
as `STATX_ATTR_MOUNT_ROOT`) before the handoff and again after it, renamed into
`~/.local/bin/onnxruntime/.previous/`, and the new tree renamed into its place, in the same
transaction as the ctx binary. `ctx setup` runs inside that transaction, before its commit: a
setup that fails hands the new daemon off, puts the previous binary and the previous runtime
tree back, and gives the previous daemon its setup back. The state database records the
archive's digest, the version and the library's digest inside the commit, and every later check
hashes the library on disk against that record. `.previous` is removed only once the update has
converged; an update interrupted before that is finished at the next convergence, under the
ctx lock, from the record — the displaced tree whose library the record still names goes back
in place, any other is removed. A release that pins no runtime, reached by a rollback, moves
the recorded one out of the loader's way and clears its record in one commit. Without a runtime,
`ctx semantic status` reports `failed` with `model_load_failed` and search stays keyword-only.

A process of the same user that swaps a checked directory in the instant between the second
check and the rename is outside what this guards: a process that can write `~/.local/bin` as
this user can already replace `~/.local/bin/ctx` and `~/.local/bin/wf` themselves. The checks
protect against the person's own links and mounts.

`ctx semantic enable` records the opt-in. ctx's daemon then downloads the
`multilingual-e5-small` model, about 0.5 GB, from ctx's RSA-signed release catalog, and embeds
in the background. Keyword search works from the first `ctx setup`; hybrid ranking uses the
semantic index once its coverage is complete, and `wf history semantic status` shows how far it
has got. ctx verifies the model itself; it is not in `wf`'s lock.

## What it sends

ctx sends content-free usage analytics by default: five versioned event families, which never
include queries, results, paths, repository names or transcript text. Upstream documents them in
`docs/storage.md`. `wf` leaves that default as upstream ships it.

To turn analytics off, set `[analytics] enabled = false` in `~/.ctx/config.toml`, which every
ctx process reads, the daemon included. `CTX_ANALYTICS_ENABLED=false` does the same for the
processes that inherit it.

This record used to say there was no telemetry and nothing was uploaded. That was true of the
reimplementation and is not true of ctx at its default, so the statement is withdrawn rather
than carried over.

## Acceptance criteria

- A fresh install leaves ctx at `~/.local/bin/ctx`, mode 0755, with the SHA-256 the active lock
  pins for this platform, and the pinned runtime at
  `~/.local/bin/onnxruntime/<VERSION_NUMBER>/<platform>/lib/`, after running
  `ctx index mode auto`, `ctx setup` and `ctx semantic enable` in that order. Once a transcript is
  indexed, `ctx semantic status` does not report `model_load_failed`.
- The state database's `ctx_current` names both digests, `<binary>:<runtime>`, `-` for a release
  that pins no runtime; a machine whose record names the binary alone converges again.
- A ctx before 1.0 in `~/.local/bin` is replaced without a handoff, and `wf history search …
  --format json` works afterwards.
- A recorded ctx failure is a `blocked` `capso.ctx.binary` row in `wf status` and `wf doctor`.
- A runtime root or old runtime tree holding a symlink or a mount point is refused before the
  daemon is touched, and nothing under it changes. The bind-mount case needs an unprivileged
  mount namespace, which CI containers deny, so it runs by name on a Linux host:
  `cargo test -p wf-cli --test lifecycle_regressions a_bind_mount -- --ignored`. It passed on
  2026-09-23, and failed with the mount check disabled.
- A download whose digest differs from the lock or from GitHub's API is deleted and never
  executed, and the ctx already on the machine is untouched (`CTX-INTEGRITY`).
- An existing ctx is replaced only after its own handoff receipt reports a quiescent
  installation. Otherwise it stays in place, the `wf` release stays active, and ctx is not
  marked converged (`CTX-HANDOFF`).
- A leftover hosted-installer marker, `ctx.install.json`, is removed with a backup when the
  binary is replaced.
- A lifecycle command that fails leaves ctx unconverged, and the next convergence finishes it
  (`CTX-SETUP`).
- `wf history` forwards its arguments verbatim, `--help` and `--format json` included, and
  falls back to `ctx` on `PATH`.
- Session start spawns the ctx convergence only when ctx is not converged, at most once an hour,
  and within the session-start budget.
- In a new session of each installed agent the `wf-history` tools are visible, `status` reports
  at least one source, and `search` finds `wf install` — the per-agent check in
  [`/install`](install.md).
- `wf uninstall` leaves ctx in place.

## What it does not do, and does not verify

- **Leave the calling session out of MCP search.** ctx's CLI search excludes the current
  session when it can identify it; its MCP search does not, so a session can find its own
  recent turns.
- **Record the other agents' tool names.** Claude Code's naming is recorded above. What Codex,
  Cursor, Kiro and ZCode call the same tools is not recorded in this repository, so their
  visibility is proven by an observed call, not by a name.
- **Replace a ctx whose daemon does not report a quiescent handoff.** Its daemon has to be
  stopped by hand once: `wf doctor`'s `capso.ctx.binary` finding names the steps.
- **Repair ctx's daemon on its own.** `wf doctor` reports `CTX-DAEMON` with the command; running
  it is the person's or the session's call.
- **Install a second ctx beside a live one.** When `~/.local/bin/ctx` is absent and another ctx is
  on `PATH`, convergence stops at `CTX-FOREIGN`.
- **Converge offline.** `wf repair` and `wf rollback` never touch ctx; the next session start
  converges it to the active release.
- **Pin the semantic model.** The model is ctx's download, checked against ctx's own catalog.
- **Provision an accelerator runtime.** The CUDA bundle is the hosted installer's; `wf` installs
  the CPU sidecar.
- **Accept `--json` on ctx's behalf.** ctx has no `--json`. A `--json` placed straight after
  `wf history` is `wf`'s own global flag and never reaches ctx.
- **Remove ctx's data.** `~/.ctx` survives reinstalls and `wf uninstall` until someone deletes it.
