---
last-verified: 2026-09-16
---

# Getting a change to every machine

"Deployed" means *installed sessions are running your change*. Until `wf` existed, the
second half of that was a runbook nobody could verify anyone had followed, and a stale
install was invisible from here. It is now a pull that converges on its own, and this
document is the four steps that put a change into the pull.

## 1. Move the version

There is one, in `[workspace.package].version` in the root `Cargo.toml`
([WFR-013](../contract/CONTRACT.md#one-version-for-the-whole-product)). The binary, the
bundle and the lock read it; none of them carries a version of its own.

Move it for **any** change a session can observe — skill text included. `wf guard
--base-ref origin/main` fails a change under `skills/`, `workflow/` or `crates/` that leaves
the version alone, so this is enforced rather than remembered.

```bash
cargo run -p wf-cli -- guard --fix   # re-render the generated documents
```

## 2. Merge, then tag

```bash
git tag v1.2.3 && git push origin v1.2.3
```

The tag starts [`release.yml`](../../.github/workflows/release.yml). It refuses to build if
the tag and the workspace version disagree, or if any generated surface is stale at the tag
— a release that has to be fixed up afterwards is a release whose version means nothing.

## 3. What the release workflow does

In order, and none of it is optional:

1. Builds `wf` for `aarch64-apple-darwin` and `x86_64-unknown-linux-gnu` with `--locked`,
   from the toolchain pinned in `rust-toolchain.toml`.
2. Compiles the registry into `workflow.lock.json` and a deterministic bundle. The lock
   includes both binary archives; strict verification checks every declared asset. With
   `--ctx latest` it also pins ctxrs/ctx's latest release: the version, and each platform's
   upstream asset with its SHA-256. A missing asset or digest fails the build (`CTX-UPSTREAM`).
   When the latest ctx is bad, `--ctx vX.Y.Z` in `release.yml` pins a known one instead.
3. Attaches an SBOM and the third-party licence archive.
4. Creates the release, then requires `gh release verify` and `gh release verify-asset` to
   pass for the release and for **every** asset.
5. Only then fast-forwards `release/stable` (or `release/canary` for an `-rc.N`) to the tag.

Nothing reaches an agent from a Git branch. The agent layer copies every component from the
verified generation `wf` selected, which is exactly what the release lock covers
([ADR-0007](../architecture/adr/0007-one-agent-layer.md)); the channel branches only record
promotion.

Immutable releases are a **blocker**, not an enhancement. This project deliberately has no
signing key of its own, so a SHA-256 proves the bytes match GitHub's record and nothing
more; if that record can be rewritten, the verification proves nothing. See
[WFR-014](../contract/CONTRACT.md#a-release-is-verified-before-it-is-run) for what that
choice does and does not buy.

## 4. How it reaches a machine

Nobody runs anything. `wf` checks at session start — at most once per machine per fifteen
minutes, under a two-second deadline — and when a newer release exists it starts one finite
updater that downloads, verifies, backs up, applies, verifies again and exits. The apply writes
into every agent `wf` manages on that machine, and a failure at any write or at publication
restores every file it touched. An object that is not `wf`'s to write — something of the same
name a person put there, a file that does not parse — is reported and left alone rather than
failing the update.

The first update to 2.0 is applied by the 1.x updater, which knows nothing of the agent layer.
The new binary notices that it did not apply the active generation itself and applies it again:
the next session start starts `wf repair` beside the session, and `wf sync` does not treat the
version as current. That apply retires the `magi@capsohq` plugin 1.x installed.

After the apply, the same updater converges ctx to the new lock's pin. That is a separate step,
so a ctx failure neither rolls back nor blocks the `wf` update: the release stays applied, and
ctx is retried later.

The session that triggered the update keeps the skills and instructions it loaded at startup.
Start a new session to load the new ones. Status verifies what is on disk in each agent; it
cannot inspect what another process already loaded.

ctx has its own trigger as well. Applying a release writes the lock's ctx pin — the binary's
digest and the runtime's, `<binary>:<runtime>` — to the state database as `ctx_desired`, and a
full convergence writes `ctx_current`. When `ctx_desired` is absent or differs from
`ctx_current` — after an update that an older `wf` applied, after a failed attempt, after a
rollback, which stays offline — session start starts the background updater at most once an
hour. A `CTX-HANDOFF` or `CTX-FOREIGN` stops those attempts only for the `wf` version that
recorded it (`ctx_error_by`). The check is a few reads from the state database with no hashing
and no process started, so it fits the session-start budget. A failure is kept as `ctx_error`
and shown by `wf status` and `wf doctor` as a `blocked` `capso.ctx.binary` row.

The index itself is kept fresh by ctx's own daemon. `wf` no longer refreshes history at session
start, and `install --skip-history` is gone.

Every ctx replacement backs up the previous binary like any other overwrite: 45 to 52 MB each
time the pin moves, at v1.4.7's sizes. `wf backup prune` drops backups outside the retention
window.

To answer "is this machine current?" on the machine:

```bash
wf status          # active version, each managed agent, what has drifted
wf doctor          # the above plus everything that would block a repair
```

## Rehearsing without publishing

```bash
cargo run -p wf-cli -- release build-local --out dist --with-binary
mkdir -p .dev && printf '*\n' > .dev/.gitignore
WF_HOME="$PWD/.dev/rehearse" CLAUDE_CONFIG_DIR="$PWD/.dev/rehearse/claude" \
  CODEX_HOME="$PWD/.dev/rehearse/codex" \
  cargo run -p wf-cli -- install --source local:dist --agent claude,codex
```

This runs the same verification the real path does; what it cannot do is prove a release
was immutable, and `wf status` says so rather than reporting itself as verified. The build
above has no `--ctx`, so its lock pins no ctx and the install leaves this machine's ctx alone.
A build with `--ctx` manages the real ctx daemon even under a disposable `WF_HOME`, because ctx
coordinates its daemon under the real `~/.ctx`.
[`fresh_install`](../../crates/wf-cli/tests/fresh_install.rs) exercises this lifecycle on
every PR with agent test doubles. It does not establish compatibility with real installed
agent versions; `real_agents_read_the_servers_wf_deployed` in
[`lifecycle_regressions`](../../crates/wf-cli/tests/lifecycle_regressions.rs) runs the real
Claude Code and Codex against an isolated home when they are installed.

## Rolling back

```bash
wf rollback --dry-run     # which version, and what it would change
wf rollback               # to the last known good
wf rollback --to 1.1.4    # to a specific one still on this machine
```

A rollback uses the same transaction as an install, including the executable. It refuses a
generation from before 2.0 (`GENERATION-PREDATES-AGENTS`): that release delivers skills as a
plugin, and every skill would load twice. It does not touch ctx: the next session start converges
ctx to the rolled-back release's pin, which needs the network. To restore known-good content
across the fleet, publish that content as a new release on the channel; moving a Git branch
alone does not select an older GitHub release for clients.

## What CI does and does not do

[`ci.yml`](../../.github/workflows/ci.yml) runs on pull requests and on
`workflow_dispatch`, not on pushes to `main`: PR checks are the merge gate, and re-running
the same suite on the merge commit gates nothing while doubling Actions minutes.

It does not publish, tag or notify. Distribution is a pull, and the tag is a person's
decision.
