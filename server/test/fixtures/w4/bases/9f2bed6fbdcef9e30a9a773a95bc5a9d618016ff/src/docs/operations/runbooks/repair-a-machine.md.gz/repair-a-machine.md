---
last-verified: 2026-09-16
---

# Runbook — a machine is missing, stale or broken

**Trigger:** a skill is absent or behaves like an old version; a session start reports
something out of date; `wf doctor` is unhappy; an agent was reinstalled.

Everything here is safe to run twice. Every step that writes backs up first and leaves a
receipt.

## 0. Read the verdict before doing anything

```bash
wf doctor
```

It reports what `wf status` does plus everything that would *block* a repair — the `gh`
login, the platform, whether `wf` is where the session-start hook expects it. Each finding
carries the one command that fixes it. If `doctor` is quiet and something still seems
wrong, the problem is not one of the things `wf` manages; skip to
[§ When it is not wf](#when-it-is-not-wf).

## 1. The four things that actually cause "my skill is gone"

In the order they occur:

| What you see | What happened | Fix |
|---|---|---|
| `wf agents` does not list the agent as managed | `wf` does not deploy into that agent on this machine | `wf agents register <id>` |
| `drifted` | the organization's copy was edited or deleted | `wf repair` |
| `reload_required` | the files are new; this session loaded the old ones | a new session |
| `update_pending` / `stale` | the release has not reached this machine | `wf sync` |

A `blocked` object with a conflict finding is a fifth, rarer cause: something of the same name
that `wf` did not put there — a personal skill, a hand-added MCP server — is in the way, and
`wf` never overwrites it. Rename or remove yours, then `wf repair`.

`credential_missing` is not in the table on purpose: it is a degraded capability, not a
failure, and it never stops a session from starting. Set the named variable in your shell
configuration and reopen the terminal.

`unverified` is not in it either, and for a stronger reason: it is not a fault at all. It is
what `wf` says about a component whose login lives in a browser and a token store it does not
open — both shipped MCPs, on every machine, which is why `wf status` prints them under their
own heading rather than under 需要处理. There is nothing to repair. Make one real read through
the server — `capso-linear` or `capso-rackspace-spot` by name. Nothing else settles it, and a
result from any other connection to the same service settles nothing at all: `wf` manages those
two servers and does not look at, report on or repair any other.

## 2. Repair

```bash
wf repair --dry-run   # the exact plan, touching nothing
wf repair
```

`repair` works from what is already on the machine — it does not fetch. It reinstates the
skills, the managed prompt block, the hooks, MCP servers, rules, subagents and environment in
every managed agent (`--agent <id>` for one), and it keeps everything of yours that is not the
object it owns. It never touches
ctx; that is [§ 6](#6-history-search-the-ctx-and-wf-path-findings).

Do **not** repair by hand-editing an agent's configuration. `wf repair` records what it
changed and can undo it; a hand edit is invisible to the next sync, which will overwrite it.

The plugin 1.x installed, `magi@capsohq`, is retired by the first 2.0 apply through the
ownership receipts 1.x wrote. One without a receipt — installed by hand — is preserved, and
the skills it carries then load twice. After confirming it is the old team installation,
remove it with the agent's own manager — Claude uses `plugin uninstall`, Codex uses
`plugin remove` — and its `capsohq` marketplace only if no other plugins use it. Do not
remove a shared or personal marketplace to resolve a name collision.

For Codex, the dispatcher remains untrusted until you approve it in `/hooks`. `wf`
reads trust through Codex's public hook API and never writes or bypasses the trust decision.

Managed file paths that are symlinks are preserved and reported as conflicts. Their link
targets are not inferred or overwritten. Ownership is recorded per agent and per location, so
changing `CODEX_HOME` or `CLAUDE_CONFIG_DIR` does not grant permission to replace a personal
object in the new location.

## 3. Fetch, if the machine is behind

```bash
wf sync            # check now, rather than waiting for the next session start
wf sync --offline  # retain the last known good without checking the remote
wf repair         # repair drift from the verified generation already on disk
```

A sync that cannot reach GitHub keeps the last known good generation and says so. That is
not an error state, and it does not need action beyond fixing the network.

## 4. Undo something

```bash
wf backup list                  # every file wf has overwritten, newest first
wf backup restore <id>          # put one back
wf rollback --to <version>      # the whole machine, to an earlier release
```

`backup restore` backs up what it is about to replace, so restoring the wrong one is itself
recoverable.

## 5. When the machine has nothing usable

`blocked` means no verified generation can be used. `wf doctor` names the single reason.
The usual ones:

- **The `gh` login expired.** `gh auth login`. This is by far the most common.
- **`wf` is not at `~/.local/bin/wf`.** Every agent's hooks and MCP servers name that absolute
  path; a binary somewhere else works from a terminal and never at session start.
- **No release has been published on this channel yet.** For a stable installation, wait
  for a verified immutable release. Maintainers can rehearse an unattested local build in
  disposable homes using [local development](../local-development.md).

## 6. History search: the ctx and `WF-PATH` findings

ctx converges as a step of its own, so none of these findings means the workflow install
failed. `capso.ctx.binary` (agent `wf`, state `blocked`) means the last convergence recorded an
error; its text names the fix for that error's code. A `NOTE` saying `~/.local/bin/ctx` is
missing, is not the pinned bytes, or has not finished its setup is a convergence under way.

| Code | What happened | Fix |
|---|---|---|
| `CTX-HANDOFF` | the installed ctx has a daemon, and its handoff did not report a quiescent installation; it was left in place (a ctx before 1.0 has no daemon and is replaced without one) | stop its daemon — `systemctl --user disable --now ctx.service` on Linux, `launchctl bootout gui/$(id -u)/rs.ctx.daemon` on macOS — move `~/.local/bin/ctx` and `~/.local/bin/ctx.install.json` aside, then `wf install` |
| `CTX-FOREIGN` | `~/.local/bin/ctx` is absent and another ctx is on `PATH`; `wf` does not install a second copy beside a live one | run that ctx's own `ctx daemon disable --prepare-uninstall --format=json`, remove it with the tool that installed it (Homebrew, mise, cargo) once the receipt reports success, then `wf install` |
| `CTX-INTEGRITY` | a downloaded ctx did not match the lock and GitHub's digest for it; nothing ran, the file is deleted, the existing ctx is untouched | nothing: it is retried automatically, or `wf install` now; if it repeats, report it — ctx's releases are not immutable, and only a new `wf` release can pin different bytes |
| `CTX-SETUP` | a lifecycle command failed after the binary was in place | nothing: the first session start after the hourly throttle retries it, and `wf install` retries now; the command logs are under `ctx/` in `wf`'s state directory, and `wf history doctor --format json` shows ctx's own diagnosis |

| `CTX-RUNTIME` | the pinned ONNX Runtime archive could not be expanded beside ctx | nothing: retried like `CTX-SETUP`, or `wf install` now |

`wf doctor` also reads ctx's own verdict on itself:

| Code | What happened | Fix |
|---|---|---|
| `CTX-DAEMON` | ctx's daemon is disabled, not running, or its heartbeat is stale; searches fail with `start or recover daemon`, MCP search answers `source_unavailable` | `wf history index mode auto`, then `wf doctor` |
| `CTX-SEMANTIC` | semantic search failed, `model_load_failed` when the ONNX Runtime is missing; search is keyword-only | `wf install` |
| `CTX-HEALTH` | `ctx doctor --format json` gave no answer | `wf install` |

With no recorded code — ctx missing, or not the pinned bytes — the fix is `wf install`.
`wf repair` and `wf rollback` never touch ctx; the next session start converges it to the
active release.

`WF-PATH` means the directory holding `wf` is not on `PATH`. Hooks and the `wf-history` MCP
server run `wf` by its absolute path and keep working, but a skill that tells a session to run
`wf …` in its shell fails. Put `~/.local/bin` on `PATH` and start a new session.

## When it is not wf

`wf` manages the organization's objects and nothing else. If `doctor` is quiet, check in
this order: the agent's own version, a skill *you* added, and whether the behaviour you
expect is in the spec node at all. `/install-manager` has the state table; the node has the intent.

## Uninstalling

```bash
wf uninstall --dry-run
wf uninstall --yes
```

Only objects `wf` has a record of are removed: what the agent layer deployed into each agent,
and what a 1.x release left a receipt for. `wf agents unregister <id>` does the same for one
agent and stops managing it.
Your own skills, MCP definitions, prompt text and agent history stay. `~/.local/bin/wf`
is retained so backups can still be restored after uninstall.

`~/.local/bin/ctx` is retained too: deleting a running daemon's binary without its handoff
leaves the daemon crash-looping. To remove ctx, run
`~/.local/bin/ctx daemon disable --prepare-uninstall --format=json`, and delete the binary
only after it exits 0 with every boolean in its receipt true. ctx's index in `~/.ctx` stays
until it is deleted deliberately.
