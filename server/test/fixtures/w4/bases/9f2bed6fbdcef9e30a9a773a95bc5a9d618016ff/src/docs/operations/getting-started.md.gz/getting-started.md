---
last-verified: 2026-10-04
---

# 开始前：装 Magi 工作流要先准备什么

Magi 工作流让 Claude Code 和 Codex 帮你做两件事：用 `/lfg` 把一个想法变成 Linear 上的工单，用 `/ic`
把一张工单做成可以 review 的 PR。安装由一个 Claude Code 会话替你完成，但下面这些它替你做不了：账号要
管理员开通，vault 要你自己同步，凭据要找人申请。先把它们准备好，安装时就只需要点几次允许。

## 必须先完成

1. **GitHub**：账号已经加入 txehq 组织。装好 `gh`（macOS：`brew install gh`；Linux：用发行版的包管理器，
   比如 `sudo apt install gh`），运行 `gh auth login` 登录。
2. **Linear**：有账号，并已加入团队。
3. **Obsidian**：装好 Obsidian，把团队的 vault 同步到本机，并在 Obsidian 里打开过它一次。安装时会从
   Obsidian 的记录里找到它。
4. **Claude Code 和 Codex 的命令行**：两个都装好，建议装最新版（Codex 可以用 `brew install --cask codex`，
   已经装过的用 `brew upgrade --cask codex` 更新），各登录一次：
   运行 `claude` 按提示登录，运行 `codex login`。
5. **发布网页的凭据**：向团队的 Cloudflare 管理员申请 Session Artifacts 的 Access service token，会拿到
   Client ID 和 Client Secret 两个值。然后在终端里运行（文件已经存在时不会被覆盖）：

   ```bash
   mkdir -p ~/.config/engapp-artifacts
   f=~/.config/engapp-artifacts/env
   [ -e "$f" ] || printf 'ENGAPP_ARTIFACTS_BASE=https://engapp.dev/artifacts\nCF_ACCESS_CLIENT_ID=\nCF_ACCESS_CLIENT_SECRET=\n' > "$f"
   chmod 600 "$f"
   ```

   再用编辑器打开它，macOS：

   ```bash
   open -e ~/.config/engapp-artifacts/env
   ```

   Linux：

   ```bash
   ${EDITOR:-nano} ~/.config/engapp-artifacts/env
   ```

   把两个值填在等号后面，保存。不要把这两个值发到聊天窗口或群里。`/ic` 做验收时要用它
   发布验收报告。

## 按需准备

- **Rackspace Spot**：只有要开云资源（cloudspace、虚拟机）的人需要。要用的话，账号要加入团队的
  organization。安装时会问你用不用，不用就不装，以后也不会弹它的登录页。

## 怎么开始

打开终端，运行 `claude`，把下面这段整段粘贴进去：

```text
Install the Magi engineering workflow (CLI: `wf`) from txehq/txe-workflow for my user account. Make sure `gh` is installed and logged in, then read the install guide with `gh api repos/txehq/txe-workflow/contents/skills/install/SKILL.md -H "Accept: application/vnd.github.raw"` and follow it end to end. Tell me in one line whenever a step needs me to log in or approve something, keep going with everything else meanwhile, and finish with the three-part report the guide asks for.
```

过程中你要做的：

- 批准 Claude Code 弹出的权限提示；
- 在浏览器里点 Allow：Linear 一次，选了 Spot 的话 Spot 一次；
- 回答两个问题：用不用 Spot，vault 是不是它找到的那个；
- 只有 Codex 提示有新的启动钩子要确认时，在 Codex 里输入 `/hooks` 确认一次。不确认也能用，只是 Codex
  开会话时不会自动检查更新。

## 做完是什么样

最后会看到一段中文，分三部分：

- **安装情况**：每一项装好了没有；
- **你现在要做的事**：第一条是退出 Claude Code、新开终端、在项目仓库里重新运行 `claude`，后面是还没完成的事；
- **怎么用**：`/lfg` 和 `/ic` 的用法和例子。

照"你现在要做的事"做完就可以用了。

## 之后怎么用

- 要做的项目在 txehq 下有 GitHub 仓库，先把它 clone 到本机，每次都在这个仓库目录里启动 `claude`。工单最后由
  `/ic` 在仓库里建分支、开 PR，所以一定要在仓库里做。
- `/lfg <一个想法>`：先问清需求和边界，再调研、写计划，然后在 Linear 上建好工单，派发前停下来问你。
- `/ic <工单号>`：领一张工单，实现、测试、截图验收、开 PR，再处理审查意见和 CI，直到可以请人 review。
- 需求文档（Brief、Research、Tickets）存在 vault 的 `Project <产品>/Features/<名字>/`，代码在项目仓库里。
