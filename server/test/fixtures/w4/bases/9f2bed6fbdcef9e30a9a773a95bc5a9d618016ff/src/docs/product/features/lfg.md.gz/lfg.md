---
last-verified: 2026-10-04
---

# /lfg — from a new idea to tickets, stopping at the dispatch gate

**Node:** WF-LFG · **Spec (authority):** `Project Magi/Workflow/Specs/Session/LFG Session.md`
**Status:** shipped v1 · **Skill:** [`skills/lfg/SKILL.md`](../../../skills/lfg/SKILL.md) · **Tool:** none — it orchestrates the step skills `/interview`, `/research`, `/plan` and `/ticketing`

Magi's complete path from a new idea to a filed set of Linear issues: interview the user to
fix the boundaries, research the current state locally and the state of the art on the web,
ask back about implementation details, split the work into tickets that carry criteria, an
estimate and a recommended assignee drawn from Linear's history — then **always stop** at the
dispatch gate. "Go" dispatches sub-agents running the `/ic` path; silence leaves the tickets
filed for people to pick up. A session may start it proactively when a new idea arrives with
no ticket.

It is not an installation command — that collision is what TXE-1775 removed, and the CLI's
skill is [`/install-manager`](install-manager.md).

## Decomposed into step skills (2026-09-07)

`/lfg` is now an orchestrator: each stage is a skill with an In/Out that names a vault file,
and `/lfg` reads the file back rather than the conversation. Stage 1 [`/interview`](interview.md),
stage 2 [`/research`](research.md), stage 3 [`/plan`](plan.md), stage 4 and the dispatch gate
[`/ticketing`](ticketing.md). There is no separate dispatch skill.

## The shape it was built to

- **The do-not-ask contract, with two stations.** Scope and the authority ceiling are declared
  once, in the interview. Implementation-detail questions have a station of their own — stage
  3, planning's Q&A phase, through `/decide` when options are enumerable — and the dispatch
  gate is the only other human question (decision log #28).
- **Research has two halves, in order.** Local first — the repository, `/history`, the corpus
  and Linear's past tickets — then the web for current best practice, every recommendation
  carrying its reference.
- **Estimates and assignees come from Linear's record**, not from a guess: recent completed
  work by area, current In Progress load, cycle time on comparable tickets. The assignee is a
  recommendation until a human confirms it at the gate or a lane claims the ticket.
- **Dispatch runs the `/ic` path** — one implementation for a human IC and a sub-agent lane.

## Acceptance criteria

The node carries none yet; these are authored from its contract, its behaviour notes, and
the scope stated by ding on 2026-09-07. The node owes them.

| # | Criterion | State |
|---|---|---|
| 1 | On a real idea, a run produces a brief with a stated out-of-scope, a research document with both a local and a web half and referenced recommendations, and stops at the gate with the plan. *(verify: the vault folder + transcript)* | **not yet exercised** on a real feature |
| 2 | Every filed ticket carries the [ticket template](../../../skills/ticketing/references/ticket-template.md)'s sections in order — background, goals, scope, constraints (optional), acceptance criteria, expected artifacts — then the planning notes and the prior research `/ticketing` adds, with the relations, estimate field, project and labels set; and no assignee is *set* without a human's confirmation. *(verify: the Linear epic)* | not yet exercised |
| 3 | Implementation-detail questions are asked after research, not before, and scope questions are routed back to the brief. *(verify: transcript order)* | not yet exercised |
| 4 | Entered with an existing brief, the run does not re-interview. *(verify: transcript audit)* | not yet exercised |
| 5 | After ticketing the run stops; no dispatch without "go" or "go wave N"; on "go", every lane is a worktree of its own running `/ic`, waves respect the DAG, a parked lane does not block the others, and nothing is asked between waves. *(verify: scripted — one lane made to fail)* | not yet exercised |
| 6 | A user describing a new idea with no ticket gets `/lfg` started proactively, announced in one line. *(verify: transcript)* | not yet exercised |

## Divergences from the node — recorded, not normalized

- **No journal and no checkpoints.** The node binds `/lfg` to Orchestration State (a
  PostgreSQL session-events table) and Checkpoints; neither is built. v1 derives its stage
  from the vault feature folder and Linear and parks by writing to them — Linear as recovery
  data, which Orchestration State forbids once the journal exists. A stated stopgap.
- **Estimates and assignee recommendations are an extension.** The node's ticketing carries
  criteria and toolchains; the estimate, the assignee recommendation and the Linear-history
  reading behind them were asked for on 2026-09-07 and are recorded here for the node to
  absorb.
- **`/deep-research` and `/devpod` are not shipped.** The tier call is still made and
  recorded, and deep work runs through `/research` at design-corpus scale.
- **Entry validation** checks presence and completeness, not quality. The node lists the
  depth of this as an open question.
- **Entry asks for the repository** when the current directory is not a git checkout with a
  GitHub remote (2026-10-04), because the lanes need one to branch and open PRs in.

## Status notes

Built without a ticket of its own; TXE-1775 recorded the naming decision this builds on. The
notes on TXE-1674 and TXE-1775 say a colleague was building `/lfg` and `/ic`; nothing had
landed on any branch when this was written, so this v1 should be reconciled with theirs rather
than assumed to be the only one.
