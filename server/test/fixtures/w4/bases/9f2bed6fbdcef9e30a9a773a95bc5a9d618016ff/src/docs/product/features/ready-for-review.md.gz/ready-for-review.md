---
last-verified: 2026-09-17
---

# /ready-for-review — three conditions, then two writes

**Node:** WF-IC (last step; no separate node yet) · **Spec (authority):** `Project Magi/Workflow/Specs/Session/IC Session.md`, System Design §2 *PR* and *Auto Merge*
**Status:** shipped v1 · **Skill:** [`skills/ready-for-review/SKILL.md`](../../../skills/ready-for-review/SKILL.md) · **Tool:** none — `gh` with the skill's `unresolved-threads.graphql` query, the Linear MCP

The gate at the end of `/ic`. On the PR's **current head** it checks three things — every
review thread resolved with a fix, a reason or a follow-up ticket; every CI check green; the
ticket's requirements checklist fully ticked and stamped with this head — plus the loop's exit
condition that the latest review carries no Critical or High finding. When all hold, it runs
`gh pr ready`, moves the ticket to the team's review state, and comments with the PR URL, the
acceptance report and the deferred findings' tickets. When one fails, it names it and stops.
It never merges.

## The contract it presents to its callers

| | |
|---|---|
| In | the draft PR after the loops; the ticket with its checklist comment |
| Out | the PR marked ready and the ticket in the review state with a comment — or a stop naming the failed condition |
| Next | Auto Merge, or the repository's owner; not this skill |

## Acceptance criteria

Authored here; the step has no node to inherit from.

| # | Criterion | State |
|---|---|---|
| 1 | The PR is marked ready only when, on the same head, zero review threads are unresolved, zero checks are outside `pass`, and the checklist comment is fully ticked with `head=` equal to that head. *(verify: PR timeline vs. check runs vs. the comment)* | **not yet exercised** |
| 2 | A failing condition produces a stop that names it with the command output, and no `gh pr ready`. *(verify: planted red check)* | not yet exercised |
| 3 | The ticket moves to a review state the team actually defines, and its comment carries the PR URL, the report URL and every deferred ticket. *(verify: Linear)* | not yet exercised |
| 4 | Nothing is merged and the ticket is not closed by this skill. *(verify: PR and ticket state afterwards)* | not yet exercised |

## Divergences — recorded, not normalized

- **The bank's R3 is not asked in team mode** — the human review the PR enters is the
  acceptance; in solo mode the LFG's own review of the PR answers it.
- **No node of its own.** Authored from WF-IC and System Design §2; a node is owed.

## Status notes

Built 2026-09-08 as the last step of decomposing `/ic`; not yet run on a real PR.
