# ADR-0006 — local history is ctx, integrated rather than reimplemented

**Status:** Accepted (2026-09-16). Supersedes ADR-0005. How the `wf-history` server reaches an
agent is [ADR-0007](0007-one-agent-layer.md)'s: the agent layer writes it into every managed
agent's own MCP configuration.

## Context

[ADR-0005](0005-history-is-implemented-not-forked.md) chose to write history search here:
`crates/wf-history`, 2,003 lines covering eight providers, pinned for reference against
`ctxrs/ctx` commit `4338adb` (v1.3.2). By 2026-09-16 four things had gone wrong with it.

- **Agents did not reach for it.** The index was a CLI behind a skill name. The global prompt
  listed `/history` once among thirteen shared skills and never said when to use it, and no MCP
  tool exposed it, so a session that did not think of the skill by name never searched.
- **Its coverage lagged.** Eight providers against the 42 in upstream's
  `docs/provider-support-matrix.json` at v1.4.7. Cursor sessions were counted and not searchable.
- **It was a second index.** On the first machine measured, ctx was already installed from
  upstream's hosted installer, with its own index under `~/.ctx`. The reimplementation kept
  another 1.5 GB of the same transcripts under `wf`'s state directory.
- **The pin fell behind, and nothing could move it.** `UPSTREAM.toml` said v1.3.2 while
  upstream published v1.4.7. The monthly `vendor-ctx` job could only open an issue; closing the
  gap meant porting upstream's provider adapters by hand.

ADR-0005 was decided on two facts about *vendoring source*: 60 MB in every clone, and a
build-time download of the ONNX runtime. Installing upstream's release binary has neither.
Nothing is compiled here, and ctx downloads its model on the machine, after installation.

## Decision

**`wf history` is ctx.** `wf history …` execs `~/.local/bin/ctx` with its arguments unchanged,
or `ctx` on `PATH` when `wf`'s copy is absent, and fails with `CTX-MISSING` when there is
neither. Flags, help and output are ctx's own; JSON is `--format json`, because ctx has no
`--json`.

**Latest, locked per `wf` release.** `release.yml` runs `wf release build-local --ctx latest`.
It resolves ctxrs/ctx's latest published release and writes `ctx_upstream` into
`workflow.lock.json`: the version, its commit, and for each supported target the upstream
asset and its SHA-256 — `ctx-macos-arm64` for `aarch64-apple-darwin`, `ctx-linux-x64` for
`x86_64-unknown-linux-gnu`. A missing asset or digest fails the build with `CTX-UPSTREAM`.
`--ctx vX.Y.Z` in place of `latest` is the emergency pin. A machine downloads the asset from
ctxrs/ctx's GitHub release and executes it only after its SHA-256 matches both the lock and
GitHub's API digest for that asset. On a mismatch nothing is executed, the file is deleted and
the existing ctx is untouched (`CTX-INTEGRITY`). A build without `--ctx` pins nothing, and an
install from it leaves ctx alone.

**An unmanaged install that `wf` owns.** ctx lives at `~/.local/bin/ctx` under receipt
`capso.ctx.binary`. `wf` follows upstream's documented lifecycle for unmanaged installs
(`docs/unmanaged-installs.md`, recorded as CLM-007):

1. Hand off with the *installed* binary: `ctx daemon disable --prepare-uninstall --format=json`.
   Continue only when the receipt reports `ok`, `installation_quiescent`, `supervisor_removed`,
   `owner_lock_released`, `endpoint_released`, `coordination_state_removed` and
   `binary_retained` all true, and `scope` equal to `installation`. Extra fields are ignored.
   Anything else is `CTX-HANDOFF`, and the old ctx stays in place.
2. Replace the binary, backing the old one up like any overwrite. A leftover hosted-installer
   marker, `ctx.install.json`, is removed in the same transaction with its own backup, because
   upstream refuses an executable and marker that do not match.
3. Run `ctx index mode auto`, `ctx setup --format json`, then `ctx semantic enable`. A failure
   is `CTX-SETUP`; ctx is not converged, and the next attempt retries.

Upstream's list also runs `ctx integrations install skill`. `wf` does not. That command writes
ctx's own skill into each agent's skill folders, and WFR-012 makes the registry the only list of
what this organization installs into an agent; `/history` and the `wf-history` server are the
workflow's instructions for ctx. The first machine shows what a second set of instructions
turns into: the `ctx-agent-history-search@ctx` Claude Code plugin there documents flags that
current ctx rejects.

**One update path.** An unmanaged ctx never upgrades itself: without the hosted installer's
marker its effective automatic-upgrade mode is `off` (upstream `docs/upgrade.md`, recorded as
CLM-008). A new ctx reaches a machine through a new `wf` release and no other way.

**Convergence is a step of its own, never part of an apply.** A ctx problem therefore cannot
roll back or block a `wf` update.

- `wf install` converges inline, and always re-verifies and re-runs the lifecycle commands.
- `wf sync` converges after its update.
- `apply` writes the pin's SHA-256 to the state database as `ctx_desired`; a full convergence
  writes `ctx_current`. At session start, when `ctx_desired` is absent or differs from
  `ctx_current`, the background updater (`wf sync --from-hook …`) starts, at most once an hour.
  The check is two meta reads, with no hashing and no exec, so session start stays inside its
  100 ms p95 budget.
- `wf repair` and `wf rollback` stay offline and never touch ctx. The next session start
  converges ctx to whichever release is then active.
- A failure is stored as `ctx_error` and reported by `wf doctor` under `CTX`.
- When `~/.local/bin/ctx` is absent and another ctx is on `PATH`, convergence stops with
  `CTX-FOREIGN` rather than install a second copy beside a live one.

**ctx's daemon keeps the index fresh.** It is ctx's systemd user service on Linux and its
launchd agent on macOS. `wf`'s session-start history refresh and `wf install --skip-history`
are removed. ADR-0004 rejected a daemon *for `wf`*, and `wf` still leaves nothing of its own
running; this daemon is ctx's, with a lifecycle upstream defines. `wf` only hands it off before
a replacement.

**Agents get tools, and the prompt says when to use them.** The MCP server `wf-history`
(component `capso.mcp.history`, source `workflow/mcps/history.yaml`) runs `wf history mcp serve`
over stdio with no credentials. The agent layer writes it into every managed agent's own MCP
configuration ([ADR-0007](0007-one-agent-layer.md)). Its tools are ctx's read-only `status`,
`sources`, `search`, `show_session`, `show_event` and `query_events`; in Claude Code they are
`mcp__wf-history__<tool>`.
The global prompt block tells every session to search past sessions with them when it hits a
problem, an error, or friction with the user.

**Semantic search is on for every machine.** `ctx semantic enable` records the opt-in. ctx's
daemon then downloads the `multilingual-e5-small` model and ONNX runtime, about 0.5 GB, from
ctx's RSA-signed release catalog and embeds in the background. Keyword search works meanwhile.
These assets are downloaded and verified by ctx, outside `wf`'s lock.

**Analytics stay at upstream's default.** ctx sends content-free usage analytics: five
versioned event families that never carry queries, paths or transcripts.
`CTX_ANALYTICS_ENABLED=false`, or `[analytics] enabled = false` in `~/.ctx/config.toml`, turns
them off. The history docs stated that nothing is uploaded. That was true of the
reimplementation and is not true of ctx at its default, so the statement is replaced.

**WFR-014 is scoped, not relaxed.** ctx's GitHub releases are not immutable, so an upstream
binary that the lock pins is exempt from the immutable-release clause and from nothing else.
Its digest comes from `wf`'s immutable lock, it is checked against both the lock and upstream's
API digest before it runs, and an integrity failure stops that step with nothing left on disk.

## What this answers in ADR-0005

ADR-0005 rejected depending on ctx as an external binary because "it puts a second install, a
second version and a second update path on every machine, which is the problem `wf` exists to
remove." Each is answered by construction.

- **A second install.** `wf install` installs ctx. There is no other installer to run or
  forget, and `wf doctor` reports a missing or wrong ctx as `CTX`.
- **A second version.** The lock pins ctx per `wf` version, so "roll back to X" still names one
  ctx, and WFR-013 holds.
- **A second update path.** An unmanaged ctx never upgrades itself. `wf` is the only path.

## Consequences

- A machine downloads about 50 MB each time the pin moves: `ctx-linux-x64` is 51.7 MB and
  `ctx-macos-arm64` 45.2 MB at v1.4.7. A `wf` release that keeps the same ctx downloads
  nothing more.
- Each machine holds about 0.5 GB of semantic assets, fetched by ctx's daemon and verified
  against ctx's own catalog, not against `wf`'s lock.
- Every replacement backs up the previous binary: 48.3 MB for the hosted installer's 1.1.1 on
  the first machine. `wf backup prune` drops backups outside the retention window.
- A ctx older than the handoff command cannot hand off its daemon. The hosted installer's 1.1.1
  is one. Its first convergence stops at `CTX-HANDOFF`, and it needs one manual step: stop the
  old daemon (`systemctl --user disable --now ctx.service` on Linux,
  `launchctl bootout gui/$(id -u)/rs.ctx.daemon` on macOS), move `~/.local/bin/ctx` and
  `~/.local/bin/ctx.install.json` aside, and rerun `wf install`.
- The provider matrix and search quality are upstream's. A regression is fixed by a later ctx
  release reaching machines through a later `wf` release, or sooner by an emergency pin.
- A rollback does not restore ctx offline. `wf rollback` changes no ctx bytes; the next session
  start, with the network, converges ctx to the rolled-back release's pin.
- `wf uninstall` leaves ctx in place, as it leaves `wf`. Deleting a daemon's binary without the
  handoff leaves the daemon crash-looping. To remove ctx, run its handoff, then delete it; its
  data in `~/.ctx` stays until someone deletes it deliberately.
- A rehearsal of a build made with `--ctx` manages the machine's real ctx daemon even under a
  disposable `WF_HOME`, because ctx coordinates its daemon under the real `~/.ctx`. A build
  without `--ctx` is the rehearsal that leaves ctx alone.
- The reimplementation's index under `wf`'s state directory is deleted after the first full
  convergence. A rollback to a lock that pins no ctx never deletes anything.
- How Codex names the `wf-history` tools is not recorded here. Codex visibility is proven by an
  observed call, not by a name.

## Alternatives considered

**Keep the reimplementation.** Rejected. Agents did not reach for it, and its provider matrix
trailed upstream's by 34 providers, with no way to close the gap except porting each adapter by
hand.

**Upstream's hosted installer and its self-upgrade.** Rejected. `curl -fsSL https://ctx.rs/install | sh`
puts shell in the install path, which WFR-011 forbids, and self-upgrade is the second update
path ADR-0005 warned about. On the first machine it had also failed 88 consecutive times —
"ctx daemon registration remains live after installation quiescence" — leaving 1.1.1 installed
while its stable channel offered 1.3.2.

**Let each machine resolve latest itself.** Rejected. The version would leave the lock, so
WFR-013's single version and WFR-014's digest check would no longer cover ctx. Two machines on
one `wf` version could run different ctx, and a rollback could not name the ctx it restores.

**Re-host ctx's binaries in `wf`'s own release.** Rejected. It adds about 97 MB per release for
two platforms, and every machine would download ctx again with every `wf` update. Pinning
upstream's own assets in the lock gives the same integrity check without the copy.
