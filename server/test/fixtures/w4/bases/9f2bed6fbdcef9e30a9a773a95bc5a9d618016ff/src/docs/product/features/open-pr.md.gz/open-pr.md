---
last-verified: 2026-09-17
---

# /open-pr — a draft PR whose body says why, what, and how it was proven

**Node:** WF-IC (step 5; no separate node yet) · **Spec (authority):** `Project Magi/Workflow/Specs/Session/IC Session.md`, System Design §2 *PR*, WFR-007
**Status:** shipped v1 · **Skill:** [`skills/open-pr/SKILL.md`](../../../skills/open-pr/SKILL.md) · **Tool:** none — `gh`, `gh image`, the Linear MCP

Pushes the tested branch and opens a **draft** PR against the development branch. The body
follows the repository's PR template when one exists and otherwise the six sections ding
fixed on 2026-09-07 — why, what changed, before/after, progress, tests run, open items — with
the acceptance screenshots embedded through `gh image` and `Closes TXE-<n>` for exactly one
ticket in the body (WFR-007). It comments the PR URL on the ticket and requests the first
review. It never marks ready and never merges.

## The contract it presents to its callers

| | |
|---|---|
| In | the branch, head SHA and ticked checklist from `/implement`; the acceptance report URL and inspected screenshots from `/acceptance`; the ticket |
| Out | a draft PR with the body convention and the trailer; PR URL on the ticket; first review requested |
| Next | [fix-pr](fix-pr.md), invoked in the same turn, then `/ready-for-review` |

## Acceptance criteria

Authored here; the step has no node to inherit from.

| # | Criterion | State |
|---|---|---|
| 1 | The PR is opened as a draft against the development branch, and its body follows the repository template when one exists, otherwise carries the six sections in order. *(verify: the PR)* | **not yet exercised** |
| 2 | The body carries `Closes TXE-<n>` for exactly one ticket. *(verify: the PR)* | not yet exercised |
| 3 | Every screenshot in the body was uploaded through `gh image` and its URL checked; a before/after surface is one stitched image. *(verify: the PR)* | not yet exercised |
| 4 | The ticket carries the PR URL and a first review was requested. *(verify: Linear + the PR timeline)* | not yet exercised |

## Divergences — recorded, not normalized

- **No node of its own.** Authored from WF-IC, System Design §2 and WFR-007; a node is owed.

## Status notes

Built 2026-09-08 as the fifth step of decomposing `/ic`; not yet run on a real ticket.
