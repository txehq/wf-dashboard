---
last-verified: 2026-09-16
---

# The workflow contract

The rules this repository owns. Nine of them, each with a machine row in
[`rules.yaml`](rules.yaml) and exactly one prose home — this file. Every other surface in
the repo may point here; none may restate a rule without pointing.

Design authority for the workflow *itself* is the Obsidian corpus
(`Project Magi/Workflow/System Design.md` and its `Decisions/` + `Specs/`). This contract
governs the **repository**: how skills get distributed, where documents live, and what CI
refuses.

## Distribution is the agent layer

**WFR-017.** Skills — and every other component — reach a session through `wf`'s agent
layer: copied from the verified generation into each coding agent `wf` manages, as objects
`wf` owns and records. There is no plugin package, no supported symlink install, and no copy
of a skill in this repository outside `skills/`.

**WFR-001**, which this replaces, shipped skills as a Claude Code plugin. Its no-symlink half
carries over unchanged. The model before it — a canonical folder symlinked into each
`~/.claude*/skills` — produced two measured failure classes: skill text drifting from the
contract with no CI able to see it, and a skill missing from some installs after a rename. The
plugin fixed both for two agents and reached no third;
[ADR-0007](../architecture/adr/0007-one-agent-layer.md) records why one layer replaced it.

## The spec is in the vault; this repo does not fork it

**WFR-002.** Every skill's design authority is its node in `Project Magi/Workflow/Specs/`.
The in-repo record under `docs/product/features/` states what the skill is, how it is
invoked, its status, and its acceptance criteria — and points at the node. It never copies
the node's content.

A second spec home is not a convenience; it is the defect that a full cleanup wave was
spent removing from `capsohq/txe`. Where a record and its node disagree, **the node wins**
and the record is corrected.

## A document exists only if the registry lists it

**WFR-003.** [`docs/index.yaml`](../index.yaml) is the registry of documents: path,
audience, read-trigger, owner, prose-or-generated, stamp policy. `wf guard` enforces that
the registry and the tree are the same set — a file nobody registered fails CI, and a
registered file that does not exist fails CI.

This is what makes orphans structurally impossible rather than periodically discovered.

## Generated surfaces are never hand-edited

**WFR-004.** A document whose registry row says `surface: generated` is rendered by
`wf guard`. Change the source (`docs/index.yaml`, skill frontmatter), then run
`wf guard --fix`. CI re-renders and diffs; a hand-edit fails.

Enforcement is by **registry property, not by folder**, so a generated surface can live
where a reader needs it (the router at `docs/INDEX.md`) instead of being exiled to a
directory nobody browses.

## A stamped document is re-verified, or it fails

**WFR-005.** A document whose registry row says `stamp: required` carries
`last-verified: YYYY-MM-DD` in its frontmatter, and `wf guard` fails when that date is
older than `policy.stamp_max_age_days` in the registry (90 days).

The rule this replaces existed in `capsohq/txe` and was unenforced on the very stamps that
carried it — two guidelines sat five months stale, in plain sight, inside the guarded set.
A freshness rule that no check can see is a comment.

## Clean slate — skill text is authored from its node

**WFR-006.** New skill text is written from its spec node. It is not ported from the
pre-v3 skill pile in `~/.coding_skills`. The single deliberate carry-over is
`/explainer`; invariants and test fixtures earned by incidents may be carried, mechanisms
presumed-good may not.

## One ticket, one merge

**WFR-007.** A change lands through a PR that carries exactly one Linear ticket, and the
closing trailer goes in the **PR body** — the surface that is observed to close and stamp.
A ticket cited but not closed by this PR appears as a bare id with no verb in front of it.

## Skill frontmatter is the catalog

**WFR-008.** A skill's `name` and `description` in `SKILL.md` frontmatter are the source
for the catalog at [`docs/generated/skills.md`](../generated/skills.md), and `name` must
equal the directory name. The description is what a session matches on when deciding
whether to invoke the skill; it is written for that job, not as a title.

## Shell is for bootstrap, and nothing else

**WFR-010.** Every piece of executable logic lives in the Rust workspace, and there is no
shell in the runtime or the install path at all. `policy.shell.allow` in
[`docs/index.yaml`](../index.yaml) is empty, and `wf guard` fails any shell script that
appears — which is the strongest form this rule has ever taken.

It used to have one exception. `bin/magi` existed because a Go program cannot report that
Go is missing, so *something* had to find the toolchain first. `wf` is a single
precompiled binary: there is no toolchain to find, and the exception has nothing left to
protect. [ADR-0004](../architecture/adr/0004-one-binary-one-version.md) records the move.

The rule itself is measured, not a taste. One 122-line script carried three parsing defects
at once: a ticket id invented out of the word "feat" and stored in real metadata, a
generated id never checked against the format its own `--id` path enforced, and a missing
`--title` that exited with no message at all. It also built its JSON by passing 24
positional arguments to `python3` — the script had already outgrown its language and
reached for a third one. None of it was tested, and in shell most of it was awkward to test
at all. All three defects are regression tests in
[`crates/wf-publish-artifact`](../../crates/wf-publish-artifact/src/parse.rs) now.

Go was the first answer and is no longer the answer; the reasoning is in ADR-0004. What
does not change is the shape of the rule: text at process boundaries belongs somewhere it
can be tested.

## The registry is the only list of what ships

**WFR-012.** [`workflow/registry.yaml`](../../workflow/registry.yaml) declares every
component this organization installs into a coding agent: skills, the global prompt block,
the hook dispatchers, hook policies, MCP definitions, readiness profiles. The release bundle
and the lock are built from it, and every machine's agent layer deploys each component into
the agents it manages. The kinds a team repository adds — rules, subagents, environment,
documents — come from the directories `workflow/teamai/team-config.yaml` names, and nowhere
else. A registered component with nothing on disk fails CI, and so does a plugin package.

Two things the schema refuses rather than defaults. `required: false` is rejected — every
organization resource is mandatory in this release line, and a component that can be
optional is a component half the fleet quietly lacks. An unknown `kind` is an error rather
than a skip: adding a new primitive means writing an adapter first, because a tool that
guesses at the semantics of an unfamiliar config file writes plausible-looking garbage into
somebody's agent.

## One version for the whole product

**WFR-013.** There is one SemVer, in `[workspace.package].version`. The binary, the bundle,
the lock and the release all carry it, and they move together. No
component has a version of its own, which is what makes "roll back to 1.0.2" a complete
instruction rather than a starting point.

`wf guard --base-ref <ref>` fails a change that touches `skills/`, `workflow/` or `crates/`
without moving that version. This is the half TXE-1664 named and nothing
implemented: manifests that *disagreed* were already caught, and a change that forgot to
bump anything was not.

The cost is real — editing one skill rebuilds two platform binaries and a bundle — and it is
the chosen cost. Reintroducing per-component versions to save a build
brings back the state where two machines both report themselves current and are running
different things.

## A release is verified before it is run

**WFR-014.** Nothing downloaded is executed, or even expanded, before its digest matches
the lock. The order is fixed: the GitHub release is verified and required to be immutable,
the lock is verified as an asset and parsed, each asset's digest is checked against *both*
the lock and GitHub's own API metadata, and only then is the bundle expanded — into a
staging directory, under the size and file-count ceilings the lock declares, refusing
traversal, links, devices and case-folded duplicates.

Any failure short of an integrity failure keeps the last known good generation and says so.
An integrity failure stops, and leaves nothing on disk. There is no half-applied
generation: either every required object reached its target and verified, or the machine is
byte-for-byte where it started.

An upstream binary that the lock pins — ctx, whose GitHub releases are not immutable — is
exempt from the immutable-release clause and from nothing else: its digest comes from `wf`'s
immutable lock, it is checked against both the lock and upstream's API digest before it runs,
and an integrity failure stops that step with nothing left on disk
([ADR-0006](../architecture/adr/0006-history-is-ctx.md)).

This release line has no organization signing key, which is a deliberate and bounded
choice. A SHA-256 proves the bytes match GitHub's immutable record; it does not establish a
publisher identity independent of the GitHub account, the repository permissions and the
Actions workflow. Protected release branches, CODEOWNERS, minimal Actions permissions,
environment approval and immutable releases are therefore release *blockers*, not optional
hardening.

## wf owns objects, not files

**WFR-015.** An agent's instruction, settings, hook and MCP files belong to the person whose
machine this is. Inside `CLAUDE.md` and `AGENTS.md`, `wf` owns the bytes between one pair of
markers and nothing else; in JSON and TOML it owns named keys, and in a hook document the
handlers whose command is `wf`, and nothing else. A skill directory, rule or subagent file
`wf` deployed is `wf`'s whole; one of the same name that `wf` did not deploy is left alone.
Outside a well-formed managed block, the bytes come out exactly as they went in — BOM, line
endings, trailing newline and all.

Every overwrite is backed up first and leaves a receipt naming the path, the object, the
before and after hashes, the release and the backup id. `wf backup restore <id>` puts it
back, and backs up what it is about to replace on the way, so a mistaken restore is
recoverable too.

What `wf` owns is recorded: a receipt for every write, and a `managed_resources` row for
every object, written when the transaction commits. `wf uninstall` removes only objects it
has a record of. It never touches a user's own skills, MCP definitions, prompt text or
history sources.

## wf answers for the servers it installs

**WFR-016.** The MCP servers `wf` is accountable for are exactly the ones the registry ships
and it writes into each managed agent's own MCP configuration — today `capso-linear` and
`capso-rackspace-spot`. For any other server pointing at the same service — one the person
added themselves, one their account carries, one that merely shares a name — `wf` and every
skill in this workflow **do not create it, do not log into it, do not repair or replace it, do
not change its entry — even in a document that also holds ours — and do not report on its
state**. No procedure here emits an
`mcp add` or `mcp login` command for a server this workflow did not install.

**WFR-018.** During installation and an explicit `wf mcp survey`, `wf` may parse an agent's
MCP document to compare the published hosts in our definitions against structured `url` and
URL arguments in `args`, and test whether a key we would write exists. The host comparison
excludes that same key. Reports identify our component, agent, published hosts and match
type. Parser diagnostics are replaced with an error naming the agent and file. Other entry
names, `env`, `headers`, tokens and login state are never inspected for this comparison or
included in its output. The comparison makes no claim about another connection's health.

`credentials.login_host` names where *our* server's browser login goes, and nothing else. A
diagnostic asks after our two servers by name rather than printing an inventory, because an
inventory is also somebody else's secrets in a transcript.

The reason is not tidiness. A machine can hold three connections to one service, and reporting
on the two you cannot check is how a report comes to name a server that was never logged into
while the one you installed answers 404
([#40](https://github.com/txehq/txe-workflow/issues/40)). When a tool fails, the operator's
first question is which server answered; `wf` can only speak for its own.

## One purpose per folder

**WFR-009.** `docs/contract/` holds rules. `docs/product/` holds what the workflow is and
what each skill does. `docs/architecture/` holds why it is built this way (ADRs — dated,
immutable, superseded rather than edited). `docs/operations/` holds how to run and change
it, with `runbooks/` for procedures triggered by a moment. `docs/generated/` holds what CI
renders. A document that fits two of those is in the wrong shape, not the wrong folder.
