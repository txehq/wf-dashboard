---
last-verified: 2026-09-17
---

# /ui-text-simplify — copy and presentation within a frontend task

**Node:** WF-UIC · **Spec (authority):** `Project Magi/Workflow/Specs/Session/UI Text Simplify.md`
**Status:** implemented in source · **Release:** v1.5.0; check [published versions](https://github.com/txehq/txe-workflow/releases) for availability.
**Skill:** [skills/ui-text-simplify/SKILL.md](../../../skills/ui-text-simplify/SKILL.md)

`/ic` routes frontend work through this skill after `/implement` sets up the isolated
worktree and checklist, before frontend edits. Acceptance consumes the persisted state
checks; after a frontend review fix, `/acceptance` republishes its report for the new head at
the same URL and the PR's affected screenshots are replaced. Direct
`/implement` and `/acceptance` entry points carry the same routing. A frontend task
need not request wording changes to trigger a scoped check. Backend-only tasks without
a frontend effect do not trigger it.

The skill decides which information stays visible, which belongs in a tooltip or
disclosure, and how to present empty states without changing their meaning. It follows
the affected product's components and localization conventions, and does not expand
the task into a whole-app copy audit. PR #239 examples are an optional reference.

## Acceptance criteria

| Criterion | Verification |
| --- | --- |
| Frontend work activates the skill after worktree setup, before edits and during acceptance. Backend-only work does not. | Caller-routing inspection; a live `/ic` session remains to be exercised after installation. |
| UI state checks survive a resume or a fresh checkout. | Local and ticket checklist sections carry the head; acceptance reads or reconstructs them before verification. |
| Frontend review fixes cannot advance using only pre-fix evidence. | The review loop returns to `/acceptance`, which republishes the report for the new head at the same URL, and the PR's affected screenshots are replaced. |
| Removing explanation preserves necessary facts, labels, validation and action consequences. | Reason-form, deletion and payment-control scenarios in the [examples](../../../skills/ui-text-simplify/references/examples.md). |
| Optional formulas can move to a tooltip while current data limitations stay visible. | Metric and partial-coverage scenarios. |
| Empty, failed, disabled and unmeasured states remain distinct; wording invents no activity or delivery promise. | Empty-state scenarios. |
| The release bundle carries the skill and its references, and all registries agree. | `wf guard` and workspace tests. |

Routing is an instruction to the agent, not a runtime file-extension detector. Structural
checks prove packaging and references; they do not prove every future editorial judgment.
