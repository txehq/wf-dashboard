# ADR-0002 — Audience-first docs tree, index pair, generated-by-property

**Date:** 2026-09-04 · **Status:** accepted · **Rules:** [WFR-003](../../contract/CONTRACT.md#a-document-exists-only-if-the-registry-lists-it), [WFR-004](../../contract/CONTRACT.md#generated-surfaces-are-never-hand-edited), [WFR-009](../../contract/CONTRACT.md#one-purpose-per-folder)

## Context

Two inputs, and they agree more than they differ.

The **Docs Atlas** (surveyed 2026-08-30, `capsohq/txe`) diagnosed a two-ring system: a
guarded core where a rule registry and a CI linter enforce one-home-per-rule, and an
unguarded periphery where nothing does — with every finding at the boundary. Its target
shape was a machine-readable index pair at the top, one purpose per folder, generated
surfaces separated from prose, and root files demoted to thin shims.

**Connor's tree** (2026-09-04) named the folders by audience instead: `product/`,
`architecture/adr/`, `operations/runbooks/`.

The Atlas's contribution is a set of *invariants*; Connor's is a set of *names*. Names by
audience are the better names — a reader knows whether they want "what it does", "why it is
like this", or "how to run it" long before they know whether a document is a "guideline".

## Decision

```
docs/
  INDEX.md            generated router
  index.yaml          the document + skill registry (the source)
  contract/           the only home a rule may live in  (CONTRACT.md, rules.yaml)
  product/            what the workflow is; features/<skill>.md records
  architecture/       why it is built this way; adr/ dated and immutable
  operations/         how to run and change it; runbooks/ for triggered procedures
  generated/          what CI renders
```

Root `README.md`, `CLAUDE.md` and `AGENTS.md` are thin shims carrying a single pointer to
`docs/INDEX.md`. None of them carries a router table.

**Generated is a registry property, not a folder.** `docs/index.yaml` marks each document
`surface: prose` or `surface: generated`; `docsguard` re-renders the generated ones and
fails on a diff. This is what lets the router live at `docs/INDEX.md`, where a reader
lands, instead of being exiled into `generated/` to satisfy a naming rule.

## Consequences

- Adding a document means adding a registry row; forgetting means CI fails. Orphans — the
  Atlas found three — become structurally impossible rather than periodically discovered.
- The three-diverging-router-tables failure cannot recur: there is one router and it is
  rendered.
- `docs/generated/` still exists, for surfaces with no better home (the skill catalog).

## Alternatives rejected

- **The Atlas naming verbatim** (`guidelines/`, `runbooks/`, `specs/`). "Guidelines" is the
  bucket that accumulates anything normative-but-unowned — exactly the file the Atlas found
  as the largest unguarded surface in `capsohq/txe`.
- **Enforce generated-ness by folder.** Simpler to implement, and it forces the router into
  a folder nobody browses. The property check costs one field.
- **No `contract/`, rules inside `architecture/`.** A rule and the reasoning behind it have
  different lifetimes: the ADR is immutable and dated, the rule is live and enforced.
