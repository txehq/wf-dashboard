---
last-verified: 2026-09-17
---

# /release-notes — standard release notes, done properly

**Node:** WF-RELN · **Spec (authority):** `Project Magi/Workflow/Specs/Delivery/Release Notes.md`
**Status:** shipped · **Skill:** [`skills/release-notes/SKILL.md`](../../../skills/release-notes/SKILL.md) · **Tool:** `wf release-notes` ([`crates/wf-release-notes`](../../../crates/wf-release-notes))

Derives what a range of changes contains — commits, pull requests, tickets, surfaces,
migrations — and hands the writing to whoever is shipping. Publishes to engapp.dev and records
the page against every ticket in the range.

## The idea it is built on

**These are ordinary release notes** (Connor, 2026-09-07) — version, date, changes grouped by
kind, and the metadata to trace any line to its change. An earlier draft of this node replaced
those conventions with invented sections; that is a worse document for the same effort, because
a reader is not looking for a novel format, they are looking for the fix they are waiting for.

What survives from that draft is the split, which is [`/handover`](handover.md)'s: the **facts
are derived** and the **grouping and wording are judgment**. So the tool emits no prose at all.
A model that runs `git log` and transcribes it is where fabrication enters; a tool that writes
the prose produces a changelog nobody reads.

## Two findings from building it, both measured on this repository

**The ticket list is systematically incomplete without reading PR bodies.** In this
organization the closing trailer lives in the PR body, not the commit message. Measured: PR
#20's squash commit names no ticket, while its body says `Fixes TXE-1783`. A commit-only
derivation found 1 ticket for `v1.1.0..HEAD`; reading PR bodies found 2. Since the Linear step
at the end of this chain writes to exactly that list, a commit-only read silently drops
tickets from the record. The tool treats `gh` as best-effort, since it may be absent or
unauthenticated, and `pr_bodies_read` reports whether PR bodies were read. When it is
`false`, the skill stops the run until `gh` is authenticated.

**A root-level file is not a surface.** The first implementation took the first path segment,
so `Cargo.lock` and `.gitignore` were reported as surfaces alongside `crates` and `docs` —
eleven "areas touched" where there were eight.

## What is verified

| # | Criterion | Verified by |
|---|---|---|
| 1 | An empty range is refused, naming both refs | `RELEASE-NOTES-EMPTY-RANGE`, exit 2 |
| 2 | Both merge shapes yield their PR number | `a_squash_merge_subject_yields_its_pr`, `a_real_merge_commit_yields_its_pr_too` — a squash-merging repository has no merge commits, so reading one shape returns nothing for half the repositories |
| 3 | A number quoted in the subject does not displace the merge's own | `the_merges_own_number_wins_over_one_quoted_in_the_text` |
| 4 | Ticket ids are found bare and not inside longer words | `ticket_ids_are_found_bare_and_uppercased`, `a_ticket_id_inside_a_longer_word_is_not_a_ticket` — `TESTXE-1` must not yield `TXE-1`, which would point a reader at somebody else's work |
| 5 | Migrations are recognised wherever they sit, with no false positives | `migrations_are_recognised_wherever_they_sit` (both directions) |
| 6 | The log parser survives any subject | `the_log_parser_survives_a_subject_containing_anything` — NUL-delimited fields, `0x1e` records |
| 7 | A truncated record is dropped, not half-read | `a_truncated_record_is_dropped_rather_than_half_read` |
| 8 | Root-level files are not surfaces | `a_root_level_file_is_not_a_surface` |
| 9 | The whole derivation works on real history | run against `v1.1.0..HEAD` in this repository: 4 commits, 4 PRs, 2 tickets, 8 surfaces |

## What is not claimed

- **No release notes have been written and published through this skill.** The derivation is
  verified against real history; the publish and Linear steps are instructed but not
  exercised. Criteria 4 and 5 of the node stay open until a real release runs.
- **Ticket detection has no repository-specific key list.** It accepts any 2–5 letter key
  followed by digits, so a string shaped like a ticket id in prose will be collected. Erring
  toward over-collection is deliberate — a missing ticket loses the record silently, while an
  extra one is visible and correctable — but it is not precision.
- **`--from` defaults to `git describe --abbrev=0`**, the most recent *reachable* tag. On a
  branch cut before the latest release that is not the tag a reader would assume, and nothing
  detects the mismatch. Pass `--from` explicitly when the range matters.
- **The range is git refs, not a train.** Once the release train is live it knows what it
  contains, and reading that is better than re-deriving from tags. Open question on the node.
