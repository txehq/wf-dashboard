---
last-verified: 2026-09-04
---

# Runbook — change a skill

**Trigger:** a skill's behaviour is wrong, out of date, or a spec node has moved ahead of it.

## 1. Check the spec first

The Obsidian node is authority
([WFR-002](../../contract/CONTRACT.md#the-spec-is-in-the-vault-this-repo-does-not-fork-it)).
If the change is a *design* change, it belongs in the node first — change the node, then
follow it here. If the skill merely fails to implement what the node already says, go
straight on.

Its path is in the roster: [`docs/product/README.md`](../../product/README.md).

## 2. Ticket it

One ticket, one merge ([WFR-007](../../contract/CONTRACT.md#one-ticket-one-merge)). Set it
In Progress when you start — not when you finish.

## 3. Change the skill, and its record

- `skills/<name>/SKILL.md` — the text a session reads.
- `docs/product/features/<name>.md` — the record: status, acceptance criteria, and any
  divergence from the node, which is **recorded, not silently normalized**.
- Restamp `last-verified` in the record you touched. That date means "someone read this and
  it was true"; do not roll it forward for an edit that did not check.

## 4. Verify

```bash
cargo run -p wf-cli -- guard --fix && cargo test --workspace
```

Then actually run the skill against the scenario that prompted the change — the guard
checks structure, never behaviour.

## 5. Ship

Bump the version and land the PR: [deployment](../deployment.md). A merged change that
nobody's install pulled has not shipped.

## Adding a new skill

Same path, plus: add its `skills:` row to [`docs/index.yaml`](../../index.yaml) with the
node code and spec path, flip `status: planned` → `shipped`, and register the new feature
record in `docs:`. The guard fails until all three agree — a rostered-but-missing skill and
an unregistered directory are both findings, on purpose.
