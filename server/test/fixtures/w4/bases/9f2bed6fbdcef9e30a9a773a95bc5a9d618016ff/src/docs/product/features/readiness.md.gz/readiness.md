---
last-verified: 2026-09-22
---

# /readiness — verify the substrate before coding

**Node:** WF-READY · **Spec (authority):** `Project Magi/Workflow/Specs/Session/Readiness.md`
**Status:** shipped · **Skill:** [`skills/readiness/SKILL.md`](../../../skills/readiness/SKILL.md) · **Checker:** `wf readiness` ([`crates/wf-readiness`](../../../crates/wf-readiness))

The first act of an `/ic` session. Verifies the toolchains at the versions the repo pins,
the services the ticket declares, and the credentials it needs — checked for capability,
not existence — then repairs what is safe to repair.

## The three decisions that shape it

1. **Derive, don't restate.** `go.mod` and `rust-toolchain.toml` already own their versions;
   `readiness.yaml` points at them rather than copying them, because the copy is what drifts.
2. **Resolve in three contexts.** Session, login shell, and a minimal environment. A tool the
   developer's terminal finds and the session cannot is the failure this stage exists to
   catch, and it reports as a context divergence with the PATH edit — not as "missing".
3. **Skip when nothing changed.** A stat-only fingerprint gates the whole run; network-backed
   checks expire on a TTL of their own.

## Services and components

- **A toolchain need never reads compose.** Known toolchains (`node`, `pnpm`, `bazel`, …),
  tools a manifest declares and names with a version are tools. Any other name is a service
  when the compose file defines it, a tool when the session's `PATH` has it, and otherwise a
  usage error (exit `2`) that names where compose was looked for.
- **The compose file is found where repositories keep it.** `--compose`, then the manifest's
  `services.from`, then Compose's own four names in its order of preference, in the root,
  `deploy/`, `deployments/`, `docker/` and `.devcontainer/`. Verified by the `manifest` tests
  in `crates/wf-readiness` and `crates/wf-cli/tests/readiness_needs.rs`.
- **Compose reads the compose file.** `docker compose config --format json` supplies the
  model, so interpolation, the project's `.env` and profiles are Compose's own. A variable it
  cannot resolve is an `SVC-CONFIG` failure quoting Compose. A published service is probed on
  its host address; one with no host port must have a running container that passes its
  healthcheck. The repair is `docker compose up -d --wait <service>`. Verified by the
  `services` tests against real Compose projects, and live on a clone of `Wei-Shaw/sub2api`
  (txe-workflow#51): its postgres publishes no port and needs `POSTGRES_PASSWORD`; without
  `deploy/.env` readiness names the variable, and with the `.env` the repo's Quick Start makes
  it starts postgres, waits for it to be healthy and passes it.
- **Linear is the component `wf` installs.** A manifest's `components:` names registry
  components the agent running the check must carry; `capso.mcp.linear` is read from that
  agent's own MCP configuration against the active generation, the way `wf status` reads it.
  The agent is the one whose session runs the command (`CLAUDECODE`, `CODEX_THREAD_ID`) or
  the one `--agent` names, and every managed agent on the machine when neither is known.
  Only the entry this release installs passes: a missing, changed, older or declined entry
  fails, each with the command that restores it. Verified by the `components` tests, which
  deploy this checkout into a disposable home with the real agent layer, and change an entry
  back to Linear's retired endpoint (txe-workflow#52).
- **A cached pass follows what Compose resolves.** The fingerprint includes a salted hash of
  `docker compose config` for each file a requested service comes from, so an environment
  variable that goes away or a port that changes re-runs the check
  (`a_cached_pass_is_not_reused_when_the_environment_compose_reads_changes`).

## Acceptance criteria (from the node)

| # | Criterion | Verified by |
|---|---|---|
| 1 | A declared-but-missing service fails by name with its setup step; `--repair` starts it and the re-run passes | `TestMissingServiceFailsThenRepairs`, and a live run against `capsohq/txe` that started redpanda |
| 2 | A tool present only via a login-shell profile edit is a context divergence, not a pass | `TestLoginOnlyToolIsReportedAsContextDivergence` |
| 3 | A credential lacking the declared capability fails with the capability named, and the token appears in neither output nor state | `TestCredentialMissingScopeFailsAndNamesIt`, `TestStateFileNeverContainsACredential` |
| 4 | An unchanged second run spawns no toolchain process; touching `go.mod` invalidates | `TestSecondRunIsCachedAndSpawnsNothing` — and measured live: 7ms / 0 spawns vs 1.5s |
| 5 | A green readiness is journaled and the coding stage can require it | Partial — v1 writes the local state file; the PG session journal is not built |

## What is deliberately not claimed

- **Criterion 5 is half-met.** The verdict is recorded per (repo, machine) under
  `~/.cache/wf/readiness/`, and `--json` emits it. The shared session journal
  ([[Orchestration State]]) does not exist yet, so no other stage can *require* it today.
- **Cloudflare capabilities are unverified, by design.** The token-verify endpoint reports
  status, not permissions. The report says so rather than passing a token nobody checked.
- **Fine-grained GitHub tokens disclose no scopes.** Those report as unverified, not as a
  pass. The first API call that needs the permission is still the real test.
- **The probe fallback is specified but not built.** Where introspection cannot answer, the
  node allows an opt-in self-cleaning probe; v1 reports the gap instead of writing to a real
  system.

## Adoption

No manifest is needed to get value — a repo with a `go.mod`, a `rust-toolchain.toml` or a
`.bazelversion` already gets version and context checks from those files alone. A manifest
adds only what no file states: credentials and their capabilities, tools nothing pins, and
which compose services a ticket actually needs.

**Manifests live here, in [`manifests/<owner>/<repo>.yaml`](../../../manifests)** — the
target repo carries nothing. A repo may still adopt a root `readiness.yaml`, which wins.
Shipped so far: `txehq/txe` and this repository.

Against `capsohq/txe` the derived half alone reports `bazel 9.2.0 · go 1.26.5 · rust 1.90.0`,
and the first production run found a real divergence: the session resolves `python3` through
the pyenv shim (3.13.8) while the login shell resolves Homebrew's (3.14.6) — a major version
apart, and invisible to any check that only asks "is Python installed".
