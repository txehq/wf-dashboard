---
last-verified: 2026-09-22
---

# /publish-artifacts — publish to engapp.dev and hand over the link

**Node:** WF-PUB · **Spec (authority):** `Project Magi/Workflow/Specs/Publishing/Publish Artifacts.md`
**Status:** shipped (transport only) · **Skill:** [`skills/publish-artifacts/SKILL.md`](../../../skills/publish-artifacts/SKILL.md)

The publishing transport: an HTML page, PDF or screenshot goes to
`https://engapp.dev/artifacts` behind Cloudflare Access, and the skill returns the stable
URL. Re-publishing with `--id` keeps the link already handed out, which is the point of
having one.

Every document-producing skill ends here — `/explainer`, `/decide`, `/interview` and the
research pair all chain into it.

## What is shipped, and what is not

- **Shipped:** the transport, including collision-checked id generation and in-place
  republish — as `wf publish-artifact` since TXE-1665, in Go first and in Rust since ADR-0004. The shell version it replaced
  carried three measured parsing defects: a ticket id invented out of the word "feat", a
  generated id never checked against the format its own `--id` path enforced, and a missing
  `--title` that exited with no message. Invoked as ``wf publish-artifact``.
- **Not shipped:** the two spine-triggered generators the node also defines — the
  **Engineer Report** (after staging deploy) and the **Release Notes** (after prod, once
  stable). Both depend on release-train bookkeeping ([[Release Train Storage]]) that does
  not exist yet.

## Acceptance criteria (transport half, from the node's contract)

1. Any supported file publishes and returns one stable `engapp.dev/artifacts` URL.
   *(verify: publish a fixture page, fetch it back with the CF Access service token)*
2. Republishing with `--id` replaces in place and preserves the URL. *(verify: id unchanged
   across two publishes; fetched content is the second version)*
3. Candidate ids are checked with HEAD before PUT; observed collisions retry up to five
   times. This is not atomic and concurrent publishers can race. *(verify:
   HEAD probes in `free_id`; there is no forced-collision transport regression test yet)*
4. A branch named `feat-99-x` yields no ticket id. *(verify: `a_ticket_is_not_invented_out_of_the_word_feat`, the
   defect that motivated the port)*

## Proxies

`wf publish-artifact` uses the proxy ureq takes from the environment: the first of
`ALL_PROXY`, `all_proxy`, `HTTPS_PROXY`, `https_proxy`, `HTTP_PROXY`, `http_proxy` whose value
parses as a proxy URL, with `NO_PROXY` / `no_proxy` exempting hosts. `crates/wf-publish-artifact/src/proxy.rs`
reads the same variables in the same order, hands that one proxy to every request, and
reports a failure against it. HTTP, HTTPS and SOCKS (4, 4a, 5, 5h) proxies are supported: the
workspace builds ureq with its `socks-proxy` feature.

A failure at the proxy names the variable that won and its URL, with credentials shown as
`***`, and the variable that takes over once it is unset:

| class | evidence in the request error | advice |
|---|---|---|
| `PUBLISH-PROXY-DOWN` | the TCP connection was refused; with a proxy in effect every connection goes to the proxy | start the proxy, point the variable at a running one, or unset it |
| `PUBLISH-PROXY-REFUSED` | an HTTP status other than 200 to `CONNECT`, or a SOCKS reply code | the proxy will not carry engapp.dev: point the variable at one that will, or unset it |
| `PUBLISH-PROXY-CLOSED` | end of stream, a reset or a broken pipe on the connection to the proxy | the proxy does not carry engapp.dev: point the variable at one that does, or unset it |

Any other failure through a proxy stays `PUBLISH-NETWORK` and names the proxy. A read-back
failure stays `PUBLISH-NOT-SERVABLE` and carries the same proxy advice.

*(verify: the `proxy::tests` in `crates/wf-publish-artifact`, which run real requests through
local listeners: a closed port, `CONNECT` answered with 403 and 502, a listener that closes at
once and one that closes after reading the `CONNECT`, a SOCKS5 listener that answers "not
allowed by ruleset", and `ALL_PROXY` (SOCKS) beside `HTTPS_PROXY` (HTTP), where the request
reaches the SOCKS listener and never the HTTP one)*

## Divergences from the node

### One shared secret, not two (2026-09-10)

The node describes the transport as writing to R2 behind Access. The Worker had grown a
second check on top — a static `X-Upload-Token` compared in the Worker, on top of the
Access service token the request already carried. **Removed on 2026-09-10 at the
maintainer's direction.**

Recorded here rather than silently normalised, because it *is* a reduction in defence:

- Access is unchanged and still the only gate. Reads, writes and `_meta.json` all sit
  behind it; the Worker now adds nothing.
- The boundary that was lost is **read-vs-write**: anyone Access admits can now publish,
  where before publishing additionally required a second secret held in a file. That
  distinction was already weak — the same file held both secrets on every machine that
  could publish — and it is now explicitly not pretended to exist.
- The thing it cost was real: rotating the shared string broke every publisher at once,
  and an `HTTP 403` from it was indistinguishable from an Access rejection.
- `ENGAPP_UPLOAD_TOKEN` is no longer read. A stale line in an existing env file is
  ignored, so machines converge without an edit (`a_stale_upload_token_in_the_env_file_is_not_an_error`).

If a write privilege separate from read is wanted again, it belongs in an Access
*policy* (a service-token-only write scope) or attributed per-user in the Worker — not in
a shared string that leaks as soon as it is copied to a second laptop.

The generators' criteria belong to the node and stay open there.

## Installation audit (2026-09-11)

Stable 1.5.0 still rejects a credential file without `ENGAPP_UPLOAD_TOKEN`, before any
network request. The Worker change and CLI release rollout are separate: use a verified
stable release containing the removal, and do not provision the retired token as a workaround.
The Access client ID and secret remain required.

`--dry-run` needs a file and `--title`, but succeeds even if the credential file is absent.
It validates local input and collects provenance, including a possible GitHub PR query;
it does not verify Access or upload anything. A real publish and body comparison are the
acceptance check. CLI read-back currently checks HTTP 200 only, so content equality remains
an explicit verification step.

The audit's non-sensitive [fixture](https://engapp.dev/artifacts/page/2rdfz0kc) was published
with a checkout build and the existing Access credential file, without an upload-token
key. Republishing with the returned id preserved the URL; an authenticated GET returned
HTTP 200 and bytes identical to the second fixture. This verifies the live Worker and
checkout transport, not distribution in stable 1.5.0. A refused local proxy was excluded
only for these subprocesses; machine proxy settings were not changed.
