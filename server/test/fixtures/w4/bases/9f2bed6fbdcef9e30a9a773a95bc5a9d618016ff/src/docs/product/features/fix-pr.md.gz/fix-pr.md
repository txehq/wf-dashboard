---
last-verified: 2026-10-07
---

# /fix-pr — the loop between a draft PR and a PR worth a human's time

**Node:** WF-FPR · **Spec (authority):** `Project Magi/Workflow/Specs/Review/Fix PR.md`
**Status:** shipped v1 · **Skill:** [`skills/fix-pr/SKILL.md`](../../../skills/fix-pr/SKILL.md) · **Tool:** `skills/fix-pr/scripts/watch_pr.py`

Step 6 of [`/ic`](ic.md). It waits for review and CI on the current head, gives every finding
one disposition, fixes every red check from its log, and repeats until the latest review on
the current head has no Critical or High finding and every check is green. `/review-pr`
produces the reviews it consumes; the two never overlap, because `/review-pr` changes no code
and `/fix-pr` writes no review.

Until 2026-09-20 this was step 6 of `/ic` written as prose inside the orchestrator's own
`SKILL.md` — the only one of the seven steps without a skill of its own.

## Why the watcher is a background event stream

An agent finishes a turn two ways: it calls a tool, or it stops. "Poll until the head you
pushed has a review" names no tool, so the turn ends, and a turn that ends looks exactly like
a step that finished. This is the whole failure: sessions opened the PR, said "waiting for
review", and handed back.

`watch_pr.py` is a resident process. It polls the PR, prints one JSON line per state change,
and exits when the PR is quiet. Armed as a background monitor, each line wakes the session
with the event and a `next` field naming the action, so the instruction sits in a fresh
notification rather than in a file read hundreds of thousands of tokens earlier — and the
session stays free the whole time, because nothing is blocked on the watch.

The alternatives, and where each one fails:

| mechanism | why not |
|---|---|
| a blocking wait that returns one verdict | removes the turn boundary, and takes the session with it: the agent can do nothing else until the call returns, which is most of the loop's wall-clock. |
| `gh pr checks --watch` | covers CI only, never reviews; unbounded, so the harness kills it. It is at best one signal inside the watcher. |
| a `Stop` hook that refuses to let the turn end | the agent layer can deploy one (`crates/wf-agents`), and Claude Code alone honours it. It would fire on every session on the machine, and the other five agents `wf` manages would keep the bug. |
| a launchd detector | `/review-pr` already has one, and it produces reviews. A second machine-wide daemon consuming them cannot wake the particular session holding the branch. |

Events are emitted once, keyed by the review's revision or by the failing checks, so an
unchanged PR is silent across polls while an edited review, a new inline comment and a re-run
check are new events. Every outcome has its own exit code — **0** quiet, **2** review-invalid,
**75** expired, **1** the watcher itself failed with its traceback on stderr — because a caller
reading only the process status would otherwise take one for another. `--max-runtime` defaults
to 1500 seconds, and a poll without room to finish is not started, so the watcher retires with
`watch-expired` rather than timing out halfway.

## Which execution of a check counts

One check can execute several times on the same head. Every edit to a PR body fires another
`pull_request` event, each workflow run it starts is a new check suite, and a concurrency group
cancels the older run. `GET commits/{sha}/check-runs` with `filter=latest` keeps only the newest
run of a name *inside one check suite*, so the older executions from other suites still come
back: on txehq/txe#2307 at `93bd8c1c` it returned five `artifactlint` rows, one cancelled and
four successful.

The watcher reads the head's workflow runs (`GET actions/runs?head_sha=`) to learn which
workflow and event produced each check suite, and treats check runs with the same app id,
workflow id, triggering event and name as one check — the fields `gh pr checks` also uses to
collapse duplicates. A check suite that no listed workflow run owns — a third-party app's, or
one whose workflow run is not listed yet — has an unknown origin and is its own check: its
suite id takes the workflow's place, so no success from another suite can replace a failure
in it. Within one check it keeps the run with the highest check run id: GitHub
assigns the id when the run is created, a replacement is always created after the run it
replaces, and the id is never null where `started_at` can be. Only that run is classified.
Commit statuses need no such step, because the combined status already returns one entry per
context.

A cancellation a later run of the same check replaced is therefore silent, and the same head
reaches `quiet` once everything else allows it. A cancellation nothing replaced is still
`ci-failed`, a failure newer than a success is `ci-failed`, a replacement still running holds
the loop as pending, and a run of the same name from another workflow, another event or another
app replaces nothing.

## What it refuses to call quiet

Every one of these was a way the first draft got it wrong, and each is now a test:

- **A review on an older head.** Coverage is by review id and revision, never by head. A fix
  moves the head, so matching a marker against the current head would uncover every review the
  instant it did its job — and the window where the fix is pushed and the marker is not is
  precisely the crash case ballot S5 named.
- **A review that was edited after its marker.** `rev` is a digest over the review's state,
  timestamp, body and every inline comment on it. A reviewer can add a reply without changing
  the review id, and that is new findings the old marker must not cover.
- **A review body that is empty while its findings sit inline.** The watcher reads review
  comments and GraphQL review threads, so a `CHANGES_REQUESTED` with everything written inline
  counts as findings, and an open thread holds the loop.
- **An approval that asks for something.** Only an `APPROVED` review with an empty body and no
  inline comments is nothing to answer.
- **A head with no checks, or with a required check that has not appeared.** No check runs
  observed is its own state, separate from every check passing. The watcher reads the base
  branch's required contexts from its rulesets or from classic branch protection and requires
  each to have passed on this head, which is the staggered-registration case: one fast check
  green while the required workflow has not been created yet. The `quiet` event records the
  contexts and where the list came from, `undeclared` included.
- **A snapshot whose head moved while it was being collected.** The head is re-read after
  collection and a moved snapshot is discarded, so no terminal verdict is ever passed on a
  commit that stopped being the head mid-poll.

Markers are read only from comments whose author association is `OWNER`, `MEMBER` or
`COLLABORATOR`, and the same gate decides whether a review carrying RPR's marker is treated as
`/review-pr`'s own. The strings are public; the authorship is not.

Only the **latest** RPR review on the current head is judged for malformation, and the clean
verdict is recognised only as a paragraph of its own. One broken review in a PR's history
stopped every later session, and a hedged sentence containing the verdict's words inside a
finding title rescued a truncated review.

The `SessionStart` hook keeps the role ballot S5 gave it: across sessions, it asks GitHub
whether any branch on this machine has a PR with reviews newer than its last disposition
marker. It detects; it does not loop.

Where a harness has no background monitor, the same script runs under that agent's own
background facility, appending to `.fix-pr/events.jsonl`, and the skill reads that file at
every step boundary and before ending any turn. The watcher does not change; **the wake-up
does not exist there**, and the skill states that rather than implying otherwise — see the
divergence below.

## State — settled by ballot S5

GitHub is authoritative and there is no durable local state. The record is the PR: its
reviews, its commits, and the disposition comments carrying
`<!-- fix-pr disposed review=<id> rev=<revision> head=<sha> -->`, where `rev` is the revision
the watcher's own `review` event carried and every event prints the marker to post. Job
identity is `OWNER/REPO#PR@HEAD` plus
the review id, the scheme `/review-pr` already uses. Any local cursor is a disposable cache
and is never migrated into shared history — Postgres owns events and checkpoints once
Orchestration State exists (D1).

The marker carries the review id **and** the head it was fixed at, which is what makes the
awkward crash window recoverable: pushed-but-undisposed looks unprocessed to a naive resume,
and the head in the marker tells the next session that the fix is already in and only the
comment is owed.

## Acceptance criteria

From the node:

| # | Criterion | State |
|---|---|---|
| 1 | After a PR is submitted, new review feedback is detected and fixed without the user asking. *(verify: a real PR with a posted review)* | not yet exercised on a real PR |
| 2 | Killing the session mid-loop loses nothing — the next session detects the outstanding review from GitHub alone, with the local cache deleted. *(verify: scripted)* | met by construction — there is no cache to delete; **not yet exercised** |
| 3 | A dirty tree or unpushed commits on resume are surfaced, not silently continued. *(verify: scripted)* | stated in the skill; **not yet exercised** |
| 4 | Pushed-but-undisposed does not redo the fix; it posts the missing disposition. *(verify: scripted against a fixture PR state)* | coverage is by review id, so the review keeps being reported until its marker exists — `test_a_marker_still_covers_its_review_after_the_head_moved`, `test_a_review_on_an_older_head_is_still_owed_a_disposition`. The agent checking the pushed head before re-fixing is **not yet exercised** |
| 5 | Every finding gets a disposition — fix, defer-with-ticket, or reject-with-reason — and deferred findings are filed as tickets. *(verify: read the posted summary against the review)* | not yet exercised |

For the watcher itself, authored here:

| # | Criterion | State |
|---|---|---|
| 6 | The session is free while the watch runs: the watcher is a background process and the events reach the session as notifications. *(verify: the `Monitor` call in a transcript, with work between its events)* | **met in Claude Code** — armed on PR #53, it delivered its expiry as a notification while the session worked. The other five agents have no wake-up; see the divergence |
| 7 | An event is emitted once — an unchanged PR is silent, an edited review and a re-run check are new events. *(verify: `test_the_same_review_keeps_its_key`, `test_an_edited_review_gets_a_new_key`, `test_a_new_inline_comment_gets_a_new_key`, `test_a_rerun_of_the_same_check_gets_a_new_key`, and the live runs below)* | **met** |
| 8 | An expiry is its own event and asks for a re-arm, including when the runtime left is too small for one poll. *(verify: `test_an_expiry_is_not_terminal_and_asks_for_a_re_arm`, `test_a_poll_never_starts_without_room_to_finish`, and exit 75 in both live runs)* | **met** |
| 9 | An RPR review with neither findings nor an explicit clean verdict is a failure, and so is a truncated one — a miscounted severity heading, a repeated section, a bare `### Critical [0]`. *(verify: `test_an_empty_rpr_review_is_a_failure`, `test_a_zero_count_heading_is_not_a_clean_verdict`, `test_a_declared_count_that_misses_its_findings_is_rejected`, `test_a_repeated_severity_section_is_rejected`)* | **met** |
| 10 | A bare approval, a human's prose and another bot's format are reviews to disposition. *(verify: `test_a_bare_approval_is_not_a_failure`, `test_a_human_review_is_dispositioned_rather_than_graded`, `test_another_bots_format_is_not_a_failure`)* | **met** |
| 11 | A severity heading inside a code fence is not counted as a finding. *(verify: `test_a_heading_inside_a_code_fence_is_not_a_finding`)* | **met** |
| 12 | A review and a red check are two events, and neither hides the other. *(verify: `test_a_review_and_a_red_check_are_both_reported`)* | **met** |
| 13 | A review owed a disposition survives the push that fixes it, and an edit after its marker uncovers it. *(verify: `test_a_review_is_still_owed_after_the_head_moved`, `test_an_edited_review_is_no_longer_covered`, `test_a_new_inline_comment_uncovers_the_review`)* | **met** |
| 14 | An empty review body with inline findings, an approval that asks for something, and an open review thread each hold the loop. *(verify: `test_an_empty_review_carrying_inline_comments_is_an_event`, `test_an_approval_that_asks_for_something_is_an_event`, `test_an_unresolved_thread_is_never_quiet`)* | **met** |
| 15 | A head with no checks observed, and one whose required context has not registered, are never quiet. *(verify: `test_no_checks_observed_is_never_quiet`, `test_a_required_check_that_has_not_registered_is_never_quiet`, `test_quiet_once_every_required_check_passed`)* | **met** |
| 16 | A marker or an RPR review from outside the repository carries no weight. *(verify: `test_a_marker_from_outside_the_repository_is_ignored`, `test_a_forged_marker_does_not_suppress_a_review`, `test_an_rpr_marker_from_outside_the_repository_is_not_an_rpr_review`)* | **met** |
| 17 | A malformed review in the PR's history does not stop every later session. *(verify: `test_a_later_valid_review_supersedes_an_earlier_malformed_one`, `test_a_malformed_review_on_an_older_head_does_not_poison_this_one`)* | **met** |
| 18 | The clean verdict is read only as a paragraph of its own. *(verify: `test_the_verdict_is_not_read_out_of_a_quotation`, `test_the_verdict_is_not_read_out_of_a_finding_title`)* | **met** |
| 19 | A failing check carries somewhere the agent can actually open. *(verify: `test_a_failing_check_carries_a_url_to_open`)* | **met** |
| 20 | Quiet, review-invalid, expiry and a crash each have their own exit code. *(verify: `test_every_outcome_has_its_own_exit_code`)* | **met** |
| 21 | `--repo` and every number are refused as argument errors before polling. *(verify: `test_a_repository_needs_exactly_two_components`, `test_zero_and_negative_are_refused`, and the live runs)* | **met** |
| 22 | `quiet` is the only event that leaves the loop. *(verify: `test_quiet_is_the_only_event_that_leaves_the_loop`)* | **met** |
| 23 | A check is judged by its latest execution on the head: a cancellation a later run of the same check replaced is not a failure, while an unreplaced cancellation, a failure newer than a success, and a same-named run from another workflow, event or app are. *(verify: the `Supersession` tests on rows copied from txehq/txe#2307, and the retest below)* | **met** |

```bash
uv run --with 'markdown-it-py>=3' python -m unittest discover -s skills/fix-pr/scripts -p 'test_*.py'
```

Live runs against `txehq/txe-workflow` on 2026-09-20, all on PR #53 — this skill's own PR,
whose loop found these defects. It read both posted reviews as `graded: true` with their
severity counts and `blocking: 6`, printed the marker to post for each, stayed silent on the
following poll, and exited 75 with `watch-expired`; a run given less runtime than one poll
retired immediately rather than timing out mid-collection. Earlier runs against PR #49, whose
review comes from the GitHub Codex connector, returned `graded: false` with the reviewer's
login; PR #41, with no review on its head, emitted nothing at all until its expiry.

Retest against txehq/txe#2307 on 2026-09-22, read-only. On the check runs GitHub returns for
head `93bd8c1c`, the classification kept 30 of 42 rows — one per check, which with the two
commit statuses matches the 32 that `gh pr checks` lists — and nothing failed where cancelled
`artifactlint` run `106138670027` had failed before; the one pending row left is `review-fix`,
still in progress. One live `poll()` on the PR's current head `dba92c14` reported `ci-failed`
for `bazel-pgtest` and `tokun-pgtest`, each the only execution of its check on that head and
each a real failure.

Two findings from that loop were resolved as false positives with evidence, and two oscillated
and are carried as divergences below: whether WFR-010 reaches a Python script in a skill's
`scripts/`, and the wake-up existing in one agent of six.

## Known open findings — shipped with these, deliberately

Four review rounds ran on this skill's own PR (#53) before it merged: 6, 6, 5 and 5 High
findings, every round's fixes producing the next round's findings. Twenty-one were fixed. The
eight below were confirmed and **left open**, because the loop was not converging and patching
a fifth round was not different in kind from patching the fourth (ding, 2026-09-20). They are
here rather than only in a PR comment so that the next person reads them before touching the
watcher.

Every one narrows to the same shape: the watcher decides `quiet` from text and from
loosely-typed API data, and each additional guard written in Python is another place to get it
wrong. Read this list as the argument for the Rust move below, not as a backlog to grind down.

| # | Finding | Effect |
|---|---|---|
| 1 | The clean verdict may be followed by other prose | `no actionable findings on this head.` and then `Please fix the unsafe retry handling.` parses as clean, and the request is never dispositioned |
| 2 | An empty `CHANGES_REQUESTED` is skipped | `has_findings()` reads the body and the inline comments, never the state, so a blocking review with neither can reach `quiet` |
| 3 | A base branch with a slash breaks the required-checks lookup | `repos/{repo}/rules/branches/{base}` is interpolated unencoded, so `release/foo` resolves wrong, reports `undeclared`, and a non-required green check can reach `quiet` |
| 4 | A slow request ends the watch | `subprocess.run(timeout=)` raises `TimeoutExpired`, which the retry loop never sees, so a single 60-second request kills a watch that had time left |
| 5 | Quoted and unrelated headings count as findings | A severity heading inside a blockquote, and a `#### 1.` under an unrelated `### Appendix`, are both attributed to a severity section |
| 6 | Argument errors and `review-invalid` share exit 2 | `argparse` exits 2; moving `review-invalid` off 1 to separate it from a crash put it on top of that |
| 7 | Exit 1 carries no traceback | `raise SystemExit(str)` prints the string only, so the protocol this record documents is not what the process does |
| 8 | WFR-010 against the Python watcher | Below, as a divergence: it survived both a resolution with evidence and a recorded divergence, across three of the four rounds |

## Divergences from the node — recorded, not normalized

- **A fix starts at the root cause** (linhaoz, 2026-10-05): the finding is reproduced and its
  root cause found before code changes, and a defect class that has recurred is a /postmortem
  trigger.
- **One push per review** (linhaoz, 2026-10-07): a fix covers the same defect wherever else the
  diff has it, and the review's fixes are pushed together, once the canonical suite is green
  and they are checked for new problems.
- **Threads are resolved without a reply** (linhaoz, 2026-10-07): a reply is an inline comment
  the watcher reads as a new review, so each finding's reason, commit or ticket goes in the
  summary comment that carries the marker.

- **No case record at triage.** Magi stage 2 (`magi.md`) expects `/fix-pr` to write a case
  record per finding. This v1 writes the disposition comment and the deferred tickets; the
  case record arrives with stage 2.
- **Oscillation is counted by the session, not by a stored history.** Two fix rounds with the
  same finding stops the run. With no durable local state, a session that dies mid-loop
  restarts that count.
- **Resumption detection is not yet in the `SessionStart` hook.** The skill's entry conditions
  cover a session that starts inside the loop; the machine-wide "any branch with a newer
  review" question the node describes is not yet asked by `capso.hook.session-start`.
- **The watcher is Python in a skill's `scripts/`, and a reviewer reads WFR-010 as forbidding
  that.** The rule is titled "Shell is for bootstrap, and nothing else"; its machine half is
  `check_shell`/`ShellPolicy` in `crates/wf-guard`, which flags shell scripts and flagged one
  in this tree while never flagging either Python file. `skills/review-pr/scripts/review_monitor.py`
  is the standing precedent, 61 KB invoked the same way through `uv run --script`, shipped in a
  skill beside its own Rust crate. The finding returned across two review rounds, so it is
  recorded as a reading of WFR-010 that the rule's text does not settle, rather than resolved.
  The `uv` and Python 3.11 prerequisite is real and already carried by `/review-pr`.
- **The wake-up exists in one of the six agents.** Claude Code has a background monitor that
  turns the watcher's stdout into a notification. Codex, Cursor, Kiro, ZCode and OpenClaw have
  no equivalent, and the registry component ships the script rather than an integration. There
  the skill directs the agent to read `.fix-pr/events.jsonl` at every step boundary and before
  ending a turn, which is discipline where Claude Code has a mechanism. Closing this means
  either an event-delivery primitive in the agent layer or, per the review's own suggestion, a
  `wf` subcommand the skill can wait on; both are larger than this skill.
