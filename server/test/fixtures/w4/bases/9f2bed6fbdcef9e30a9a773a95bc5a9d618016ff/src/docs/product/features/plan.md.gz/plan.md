---
last-verified: 2026-10-05
---

# /plan — draft, agent review, human review, lock

**Node:** WF-LFG (stage 3; no separate node yet) · **Spec (authority):** `Project Magi/Workflow/Specs/Session/LFG Session.md`, bound by `Decisions/Planning Corpus Standard.md`
**Status:** shipped v1 · **Skill:** [`skills/plan/SKILL.md`](../../../skills/plan/SKILL.md) · **Tool:** none — it composes a Plan sub-agent, `/decide` and `wf obsidian`

Turns `Research.md` into a locked implementation plan the way Claude Code plans — write the
draft, have a Plan agent review and optimize it, hand it to the human — **without plan mode**
(ding, 2026-09-07). The plan lives in the feature's master document, not in a new file:
System Design §7 fixes the feature folder's files, so the plan is the master document's plan
section, reviewed and locked with a dated entry.

## The contract it presents to its callers

| | |
|---|---|
| In | `Research.md` and `Brief.md`; the repository checkout |
| Out | the locked plan in `Research.md` (or `System Design.md` at corpus scale), written back through `wf obsidian --replace`, decision ledger updated |
| Next | `/ticketing` selects tickets from the plan's parts |

## The shape it was built to

1. **Draft** — the research's plan taken one level down: per part an outcome, the changes,
   dependencies, verification and inherited criteria; goals and non-goals from the brief;
   the approach and why; ledger; risks and rollback; what is left for ticketing.
2. **Ask back** — Phase 4 of the interview bank, goal thought and never shown; `/decide` for
   enumerable options; scope questions routed back to the brief.
3. **Plan-agent review** — completeness, feasibility against the code, sequencing, scope,
   unsupported assumptions; the same prompt to Codex read-only, honouring the
   corpus standard's author/reviewer split; findings triaged, never obeyed.
4. **Human review, then lock** — the plan presented compactly, the bank's A6 asked, approval
   explicit, then `locked · <date>` and a decision-log entry written back to the vault.

## Acceptance criteria

Authored here; the step has no node to inherit from.

| # | Criterion | State |
|---|---|---|
| 1 | Every criterion in `Research.md` maps to a part in the plan, and every part names its verification. *(verify: read the two documents side by side)* | **not yet exercised** |
| 2 | A Plan agent reviewed the draft and each accepted finding was folded into the plan. *(verify: transcript + the plan)* | not yet exercised |
| 3 | The human approved explicitly before the lock, and the master document carries `locked · <date>` and a decision-log entry. *(verify: transcript order + the vault)* | not yet exercised |
| 4 | Neither `EnterPlanMode` nor `ExitPlanMode` was called. *(verify: transcript)* | not yet exercised |
| 5 | No step in the plan crosses the brief's out-of-scope list. *(verify: read the plan against the brief)* | not yet exercised |

## Divergences — recorded, not normalized

- **No node.** The corpus treats planning as stage 3 of WF-LFG under the Planning Corpus
  Standard; this skill gives the stage its own front door. A node should be written.
- **No new file.** A separate `Plan.md` would have been convenient and would have broken §7;
  the plan is the master document's section instead.
- **Each part is planned with particular care for the architecture and the verification**
  (linhaoz, 2026-09-28), an extension of the corpus; its tests are derived by equivalence
  partitioning, boundary-value analysis, decision tables and state transitions, and the
  approaches are weighed against ISO 25010 quality attributes, the choice recorded as an ADR
  (linhaoz, 2026-10-05).

## Status notes

Built 2026-09-07 as the third step of decomposing `/lfg`; not yet run on a real feature.
