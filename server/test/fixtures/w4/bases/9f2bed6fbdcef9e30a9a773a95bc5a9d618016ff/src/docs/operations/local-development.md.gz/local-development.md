---
last-verified: 2026-09-16
---

# Working on a skill locally

**The thing that will confuse you first:** a skill a session loads is a **copy**, not a link.
`wf` copies each skill from the verified generation it installed into every managed agent's
skills directory — `<config-dir>/skills/<name>/` for Claude Code, `$CODEX_HOME/skills/<name>/`
for Codex, `~/.cursor/skills/<name>/` for Cursor, and so on
([ADR-0007](../architecture/adr/0007-one-agent-layer.md)). Editing your working tree changes
nothing a session can see until a release built from it is installed.

Editing an agent's copy in place does not work either: `wf status` reports it as drifted, and
the next apply puts the release's copy back, with your edit in a backup.

## The loop that works

Edit the canonical skill under `skills/`, then move the single version in
`[workspace.package].version`. Generate and install a local release into disposable homes:

```bash
cargo run -p wf-cli -- guard --fix
mkdir -p .dev && printf '*\n' > .dev/.gitignore
cargo run -p wf-cli -- release build-local --out .dev/release --with-binary
export WF_HOME="$PWD/.dev/home"
export CLAUDE_CONFIG_DIR="$WF_HOME/claude"
export CODEX_HOME="$WF_HOME/codex"
cargo run -p wf-cli -- install --source "local:$PWD/.dev/release" --agent claude,codex
cargo run -p wf-cli -- doctor
```

`--agent claude,codex` keeps the rehearsal inside the two roots the environment moved. With
`--agent all`, `wf` also deploys into every other agent it finds under your real home —
`~/.cursor`, `~/.kiro` — because those agents have no variable that relocates them. Start a new
session to load what was installed. Codex also requires approval of the fixed dispatcher in
`/hooks`.

That build has no `--ctx`, so its lock pins no ctx and the install leaves this machine's ctx
alone. Add `--ctx latest` only when ctx's convergence is what you are testing. `WF_HOME` moves
`wf`'s copy of ctx to `$WF_HOME/bin`, but ctx coordinates its daemon under the real `~/.ctx`,
so the install manages this machine's real ctx daemon; with another ctx already on `PATH` it
stops at `CTX-FOREIGN` instead. Before deleting a disposable home that received ctx, run
`$WF_HOME/bin/ctx daemon disable --prepare-uninstall --format=json`, or the daemon is left
pointing at a binary that no longer exists.

A version identifies one immutable generation. After further edits, bump the workspace
version and rebuild before installing again; an existing generation is deliberately reused.

## Before you push

```bash
cargo run -p wf-cli -- guard --fix   # re-render every generated surface
cargo test --workspace                # including the guard's own negative fixtures
```

`wf guard` is the same command CI runs. A finding names its check code and its file; fix
the source rather than the rendered surface. `--fix` regenerates the documents rendered from
`docs/index.yaml` and skill frontmatter. The guard also validates `workflow/teamai` — the
agent registry, the policy and the team configuration — and every resource they name, which is
what a machine would otherwise refuse at apply time.

## What a skill may assume about its own location

A skill invokes a tool by name:

```
wf <command> [args...]
```

`wf` is installed at `~/.local/bin/wf` and is on PATH; `wf doctor` reports `WF-PATH` when it
is not. There is no build step, no cache directory and no bootstrap script; the first run costs
what the hundredth costs.

A hardcoded `~/Projects/...` or `~/.coding_skills/...` path is a bug; the retired store is
exactly what [WFR-017](../contract/CONTRACT.md#distribution-is-the-agent-layer) keeps out. So
is `${CLAUDE_PLUGIN_ROOT}`: there is no plugin, so no session has that variable, and
`wf guard`'s CMD001 fails every skill that names it. A skill's data files are in its own
directory, which every agent copies whole.
