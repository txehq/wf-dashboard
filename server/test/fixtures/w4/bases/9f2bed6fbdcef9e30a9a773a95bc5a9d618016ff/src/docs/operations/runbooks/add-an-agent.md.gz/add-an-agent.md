---
last-verified: 2026-09-16
---

# Runbook — add an agent

**Trigger:** a teammate works in a coding agent `wf` does not manage yet, and the team's
skills, rules and MCP servers should reach it the way they reach the others.

An agent is data. The work is almost always an entry in
[`workflow/teamai/agents.yaml`](../../../workflow/teamai/agents.yaml); a new *file format* is
the one case that needs code, deliberately — see
[ADR-0007](../../architecture/adr/0007-one-agent-layer.md).

## 1. Find out where the agent keeps things

From the agent's own documentation, and then from a real install, for each of: skills, rules
(instructions scoped to files), subagents, hooks, MCP servers, the user-level instructions
file, and environment. For each one note the path relative to the agent's configuration
root, whether a variable relocates that root (`CODEX_HOME`-style), and the file's format.

Write down what the agent does **not** have. An absent path is a resource `wf` never
writes — Codex has no rules path on purpose, because its rules directory holds execution
policy, not instructions.

## 2. Match every format to an existing one

The formats `wf` can already write are the enums in
[`crates/wf-agents/src/formats/mod.rs`](../../../crates/wf-agents/src/formats/mod.rs): hook
formats (`claude`, `codex`, `cursor`, `kiro`, `zcode`, `openclaw`), MCP formats
(`claude-json`, `cursor-json`, `kiro-json`, `codex-toml`), rule, subagent, prompt and
environment formats. An agent whose files have the same shape as one of them reuses it by
name.

When one of its files matches none of them, stop here and write the adapter first, with its
tests, in `formats/` — a guessed format writes plausible-looking garbage into somebody's
agent. Then continue.

## 3. Add the entry

```yaml
  - id: windsurf               # lowercase kebab-case; what `--agent` and the rows use
    display_name: Windsurf
    aliases: []                # the first alias is what its hooks pass as `--agent`
    root: .codeium/windsurf    # relative to the home directory
    binary: windsurf           # detection also accepts the root existing
    paths:
      skills: skills
      mcp: mcp_config.json
    formats:
      mcp: claude-json
```

Only name paths the agent reads. A resource kind reaches the agent only when both its path
and its format are present.

## 4. Prove it on one machine before shipping it

An overlay at `<wf config dir>/agents.yaml` merges into the shipped registry by `id`, so the
entry can be tried without a release:

```bash
wf agents detect                 # the new agent is found, with its version
wf agents register windsurf      # deploys the active release into it
wf agents status --agent windsurf
wf doctor
```

Start a new session in the agent and observe each resource: a skill it can invoke, an MCP
server's tool it can call, a hook that fires. Configuration on disk is not evidence that the
agent reads it.

## 5. Ship it

Move the entry from the overlay into `workflow/teamai/agents.yaml`, run the guard — it
validates the registry the way a machine will (`TAI-AGT…` findings) — and bump the version:

```bash
cargo run -p wf-cli -- guard --fix
cargo test -p wf-agents
```

Record what was observed in step 4 in the [agent layer's record](../../product/features/agents.md),
and land it with one ticket. Machines pick the agent up at their next update, and each
person registers it with `wf agents register <id>` — `wf` manages the agents a machine
registered, so a new entry never starts writing into an agent nobody asked it to manage.
