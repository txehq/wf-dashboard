---
last-verified: 2026-09-05
---

# AGENTS.md — session shim

Same content as [`CLAUDE.md`](CLAUDE.md), for agents that read this filename instead:
this repo is the Magi engineering workflow, and **[`docs/INDEX.md`](docs/INDEX.md) is the
only router**. Harness facts, the generated-surface rule, and where design authority lives
are all in `CLAUDE.md`; they are not restated here.
