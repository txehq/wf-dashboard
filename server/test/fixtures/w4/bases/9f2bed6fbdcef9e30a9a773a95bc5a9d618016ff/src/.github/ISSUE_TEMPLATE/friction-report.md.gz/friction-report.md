---
name: Friction report
about: The workflow itself misbehaved — a skill, hook, `wf` command or instruction that failed, described something other than what happened, or was overridden by a better instruction.
title: "[friction] <surface> — <one-line symptom>"
labels: friction
---

<!--
Filed by hand or by an agent running /report-friction. Same shape either way.
This tracker is for the workflow. A bug in the product repository you were working in
belongs in that repository — the test is whether it would still have happened if the
skill's text, the hook, or `wf` were different.
Redact before pasting: no tokens, no API keys, no Authorization headers, no .env contents.
-->

**Surface:** <!-- /implement, wf install, hooks/session-start, /install (Linear auth) … -->
**Class:** <!-- blocked | mismatch | override | sentiment | install -->

## What happened

<!-- The exact error, verbatim, with the command that produced it and the step you were on.
     Paraphrase makes a report untriageable — it cannot be searched for or matched to a fix. -->

```
```

## The path that worked

<!-- What actually got past it — the commands, in order. If nothing did, say where you
     stopped. This is the half that turns a complaint into a patch. -->

## Why I think it happened

<!-- Hypothesis, kept apart from the observation above and labelled as a guess.
     Falsifiable beats sweeping: "the instruction assumes a fresh worktree; this session was
     already in one" can be checked. "Something is wrong with worktree handling" cannot. -->

## The user's instruction

<!-- Verbatim, if there was one, with what the prompt said instead, side by side.
     The wording is the finding — quote it, do not summarize it. Delete if not applicable. -->

## Where it happened

<!-- Derived, not remembered: `wf status`, `wf --version`, and the OS. -->

```
```
