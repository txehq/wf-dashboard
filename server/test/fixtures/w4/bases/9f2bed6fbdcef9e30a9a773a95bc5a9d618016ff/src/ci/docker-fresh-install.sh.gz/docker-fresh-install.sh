#!/usr/bin/env bash
# Run the install rehearsal inside a clean Linux container.
#
# The rehearsal itself is a Rust test (crates/wf-cli/tests/fresh_install.rs) — this only
# provides the machine to run it on, which is the part a laptop cannot: no prior state, no
# agent installed, no `gh` login, and a non-root user.
#
# One caveat worth knowing before reading a green result here: the container inherits the
# host's architecture. On an Apple Silicon machine that is arm64 Linux, which this release
# line does not ship for — so the rehearsal exercises the unsupported-platform refusal
# rather than the full install. The full path runs natively on macOS arm64 and, in CI, on
# x86_64 Linux, which are the two targets that exist.
#
# CI-only. It is never installed, never runs at session start, and is not part of the
# runtime, which is what keeps WFR-011 intact.
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"

docker build -q -t wf-fresh-install -f "$root/ci/Dockerfile.fresh" "$root/ci" >/dev/null

# Read-only source, container-local target: a rehearsal cannot write into the host checkout.
exec docker run --rm \
  -v "$root:/home/dev/src:ro" \
  -e CARGO_TARGET_DIR=/tmp/target \
  wf-fresh-install \
  cargo test --release -p wf-cli --test fresh_install -- --ignored --nocapture
