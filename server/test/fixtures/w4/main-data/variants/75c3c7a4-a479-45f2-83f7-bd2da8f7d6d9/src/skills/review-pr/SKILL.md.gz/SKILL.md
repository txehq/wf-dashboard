---
name: review-pr
description: 'Review a pull request with an independent Codex pass and post the findings, without changing a line of code. Use when the user says "review-pr", "rpr", asks for a Codex-powered PR review without fixes, asks for review follow-ups to be monitored, or has given standing authorization covering this epic or PR set. Review-only: never edit code, commit, push, change PR metadata or statuses, merge, or deploy; a request to fix the findings is a separate task.'
---

# /review-pr — one independent review pass, posted, and nothing else

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Review/Review PR.md` (WF-RPR).
Where this file and the spec disagree, the spec wins: update this file to match it.

## Names

`/review-pr` invokes this skill. On GitHub its markers carry the name `RPR`: the deduplication
marker, the reply markers and the review attribution. Keep every marker name as it is.
`<!-- OpenAI Codex via RPR -->` is coverage truth for every head reviewed in every repository,
and the detector reviews every head that lacks it, so a renamed marker sends every reviewed head
back through review.

## The gate verdict

This skill writes no merge-ready gate verdict. In `capsohq/txe` the gate (`review-fix`) is a
check-run that a CI workflow writes after reading the posted review. The authority boundary
below forbids statuses outright.

## Authority boundary

Treat this boundary as absolute:

- Post at most one substantive RPR GitHub COMMENT review per exact head SHA.
- In monitored mode, post at most one deduplicated reply per qualifying author
  follow-up event when the head is already reviewed and unchanged.
- Do not edit repository files or generated artifacts.
- Do not commit or push.
- Do not update the PR title, body, labels, reviewers, checks, or commit statuses.
- Do not post a triage response promising fixes. A follow-up reply may answer a
  question, request a pushed commit, or explain review state; it never claims
  that RPR will implement changes.
- Do not merge, close, mark ready, release, or deploy.
- Do not fix findings. Fixing them is `/fix-pr`, the other half of this pair.
- You MAY **create** Linear issues, and only Linear issues, for pre-existing
  findings (§5a). This is the single enumerated write outside the read-only
  posture, and it touches no GitHub object: no PR, branch, status, label, or
  review changes. Creation only: do not update, reassign, relabel, or
  close an existing issue. Everything else in this list still holds absolutely.

For durable deduplication, a review whose `commit_id` equals the current head SHA covers that
head when its body contains `<!-- OpenAI Codex via RPR -->`, `<!-- OpenAI Codex via RPRB -->`
or the visible footer `Review by OpenAI Codex via RPRB`. Emit only the `RPR` marker in new
reviews. When deduplicating author follow-up events, recognize both
`OpenAI Codex via RPR reply-to:` and `OpenAI Codex via RPRB reply-to:` markers, and emit only
the `RPR` reply marker.

Read-only inspection is allowed: repository documentation, Git history, PR metadata, diffs,
existing reviews, and CI results. Avoid commands that may mutate the checkout. Codex itself
uses a read-only sandbox with approvals disabled.

## Execution model

Run each review in a sub-agent that holds the diff and the review context. Give the sub-agent
this complete skill contract, the repository path or name, and the target PR. The coordinating
agent does not repeat the review. When an OS monitor has launched the current process as an
isolated event worker, perform the review in that worker without spawning another outer
worker; inner static-review calls from §3 stay non-delegating.

In monitored mode, the deterministic detector dispatches work as soon as it finds it. It may
spawn one isolated event worker per uncovered PR head or new same-head author follow-up, up to
the worker cap, and it reserves and deduplicates the job identity before spawning. The detector
itself never invokes a model or reviews code while polling.

If the sub-agent fails after the review was posted, inspect GitHub and report the durable
result. If no substantive review was posted, report the failure to the user and stop.

## Workflow

### 1. Resolve the repository and open PR

Use the repository named by the user. Discover a local checkout with `rg --files` or GitHub access when necessary. Resolve the repository identity with:

```bash
gh repo view --json owner,name,defaultBranchRef
```

List only open PRs:

```bash
gh pr list --state open --json number,title,url,headRefName,headRefOid,baseRefName,isDraft
```

Never use an implicit or closed PR. If exactly one PR is open and the user says “the open PR,” review it. If several are open and no target can be inferred safely, ask which one.

Record the PR number, URL, base branch, and exact head SHA. Write this review's files under
`.review-pr/` in the current directory, created with a `.gitignore` containing `*`, and put the
repository, PR number and head SHA in each file name.

### 2. Read project instructions and collect evidence

Read the repository’s applicable `AGENTS.md`, `CLAUDE.md`, code-review guide, workflow contract, and files directly referenced by those instructions. Follow freshness and path-specific rules.

Fetch:

- PR title and body
- complete `base...head` diff
- changed-file list
- relevant helper implementations omitted from small diff hunks
- existing CI/check results
- existing review comments when they materially affect correctness

Do not build, test, format, generate, or otherwise touch the checkout. Cite existing CI results
as evidence of what CI ran; this review establishes correctness.

### 3. Run one Codex review

Resolve the model with `references/codex-model.md` and `references/codex-models.txt`, both of
which ship with this skill.

Write the prompt below to `.review-pr/OWNER_REPO_N_HEAD.prompt.txt`, then run one static
reviewer on it with the resolved model:

```bash
codex exec -m <model> -s read-only -c approval_policy=never -c model_reasoning_effort=high \
  --disable apps --ephemeral --skip-git-repo-check \
  --output-last-message .review-pr/OWNER_REPO_N_HEAD.md < .review-pr/OWNER_REPO_N_HEAD.prompt.txt
```

Embed the complete diff in the prompt. Codex reviews statically from the provided evidence:
tell it that it cannot run commands, fetch GitHub, or read the checkout.
Never use `head`, `tail`, `sed` ranges, line limits, or excerpts to fit a diff.
If the complete evidence exceeds the partition threshold below, partition it with a verified
complete-file manifest; truncation is always a failed review. The review artifact is the file
`--output-last-message` writes; stdout carries diagnostics and is never the review. After
`codex exec` exits, wait up to 30 seconds for that file to have content: the CLI can write it
just after the process ends.

Use a prompt with these requirements:

```text
Review PR #N at PR_URL at exact head HEAD_SHA.

Perform a code review only. Analyze the complete embedded diff for correctness,
security, data loss, concurrency, API/behavioral contract violations, missing
error handling, and adherence to the supplied project conventions. Separate
issues introduced by this PR from pre-existing issues. Do not suggest broad
refactors or style-only changes unless they hide a correctness risk.

For Go changes, inspect context propagation, wrapped/sentinel errors, nil paths,
goroutine/resource cleanup, SQL parameterization, transaction boundaries, and
project logger conventions. Cross-check any API Changes section and referenced
spec/code-path contracts.

Group actionable findings into severity sections in this exact order:
"### Critical [N]", "### High [N]", "### Medium [N]", then "### Low [N]",
where `N` is the exact number of findings in that section. Include only sections
that have findings. Within each section, number findings consecutively from 1,
restarting at 1 for each severity, and give every finding a concise, descriptive
heading in the form "#### 1. Finding title". Do not repeat the severity in each
finding title. For every finding, include a specific file and line or diff hunk,
the failure scenario, and the correct fix. Do not claim a finding without tracing
the relevant path.

For every finding, also include a line reading exactly
"Origin: Introduced by this PR" or "Origin: Pre-existing". Put it inside the
finding body — do not add a section, change the severity grouping, or renumber
anything for it. "Pre-existing" means the defect is already live in the base
branch and would remain after this PR merges.

You cannot run commands or modify files. Return the full review text only.
Header: "## Codex Code Review (MODEL, high)"
Immediately after the header, include exactly one hidden deduplication marker:
"<!-- OpenAI Codex via RPR -->"
Do not include a visible RPR attribution footer or end the review with
"Review by OpenAI Codex via RPR" in any Markdown form.
If there are no actionable findings, say so explicitly and list the areas
checked. Do not say the PR was fixed, merged, or approved.

PROJECT INSTRUCTIONS:
...

PR BODY:
...

COMPLETE DIFF:
...
```

A blank response, a transport error, a request for the diff, or a non-substantive answer is a
failed review: report the failure to the user and post nothing. A stalled response may be
partially rendered, so never triage findings from it; a review truncated before its last
finding reads as complete.

Measure the evidence before invoking Codex. If the assembled prompt exceeds 750 KiB or its
estimated tokens approach 70% of the resolved model's context window, partition the diff
deterministically into coherent complete-file groups, record a manifest proving that every
changed file and hunk is covered, review every group independently with the same model and
effort, then run one final synthesis and deduplication pass. Post nothing unless every group
succeeded and the coverage manifest is complete. The final GitHub artifact is one COMMENT
review for the exact head; chunk outputs stay internal evidence.

Run chunk and synthesis Codex calls as non-delegating inner reviewers. Isolate them from
user-installed skill auto-triggering (for example with a clean Codex home or the supported
ignore-user-config option), and explicitly forbid them from invoking RPR, spawning agents,
fetching GitHub, or posting artifacts. If an inner call attempts to re-enter the outer RPR
workflow, terminate it, accept no output from it, report the failure to the user, and post
nothing.

### 4. Guard against a stale review

Before posting, resolve the PR head SHA again. If it differs from the reviewed SHA, discard the result and review the new exact head. Never knowingly post findings against stale code without labeling them stale.

### 5. Post the review only

Verify `.review-pr/OWNER_REPO_N_HEAD.md`, the review `codex exec` wrote, and post it as a
COMMENT review:

```bash
gh api repos/OWNER/REPO/pulls/N/reviews -X POST \
  -f event=COMMENT \
  -F body=@.review-pr/OWNER_REPO_N_HEAD.md
```

Codex returns the text and the coordinating agent posts it, because connector review writes may be unavailable. Post the review verbatim. Do not add a second triage review, issue comment, status, or metadata change.

Before posting, verify that the required header and hidden deduplication marker
each occur exactly once, that no visible RPR attribution footer is present,
that the final line contains review content, and that findings are grouped under
descending severity headings. Verify every severity header uses the
`### Severity [N]` form, its bracketed count exactly matches the number of
findings in that section, and its `####` finding headings are numbered
consecutively from 1. Also verify numbering restarts at 1 in each section and no
finding heading repeats its severity label.

### 5a. File a ticket for each pre-existing finding

A finding tagged `Origin: Pre-existing` is a real defect already live in the base branch.
Nobody fixes it in the PR under review, and RPR posts one review and stops, so the finding
gets a Linear ticket that someone will query.

**The procedure lives in `references/follow-up-admission.md`. Follow it verbatim; do not
restate any of it here.** It carries the ladder (leave it in the review → search for an existing
issue → consolidate → admit), the exposure gate that decides filing at every severity, the mandatory
priority, and the ticket body, including how to construct the `Observed evidence` permalink
from the base tree.

**Do not post the filed ids to the PR.** §5's one-review-per-head rule and the authority
boundary both still hold: the review is the only GitHub artifact. The ticket is the durable
record; the user hears about it in step 6.

### 6. Report completion

Tell the user:

- which PR and exact head were reviewed
- whether actionable findings were posted, grouped by severity
- the GitHub review identifier or URL when available
- **every Linear ticket filed under §5a, by id**, and every pre-existing finding that was not
  filed, with the existing issue that already tracks it when there is one
- the writes this run made: the COMMENT review, and the Linear issues filed under §5a

### 7. Monitor and respond to author follow-ups

In monitored mode, watch these events for every eligible open PR:

- `pull_request` opened, reopened, synchronized, or head changed
- `issue_comment` created or edited
- `pull_request_review_comment` created or edited
- `pull_request_review` submitted or edited when it contains author feedback

Process only comments from the PR author that materially respond to RPR,
report a code fix, request re-review, or ask a review-related question. Ignore
RPR's own comments, unrelated chatter, and already handled event identities.
Continue monitoring after every response so author replies are handled
recursively.

For every event, re-fetch the authoritative open/merged state, author, exact
head SHA, reviews, conversation comments, and inline comments. Then choose
exactly one path:

1. **New uncovered head**: reserve `OWNER/REPO#PR@HEAD`, include the relevant
   author follow-ups as review context, and immediately spawn one isolated RPR
   review worker. Post no acknowledgement unless the author asked a separate
   question that the review cannot answer.
2. **Reviewed unchanged head, author asks a question**: post one concise direct
   answer. Reply inline when the source is an inline review comment; otherwise
   reply in the PR conversation. Do not post a second review for the same head.
3. **Reviewed unchanged head, author reports fixes or requests re-review**:
   state that the remote head is still `HEAD` and that a fresh review will run
   after a new commit is pushed. Do not validate local or unpushed claims.
4. **No actionable question, fix claim, or new head**: post nothing.

Deduplicate replies using the source type, comment/review ID, and `updated_at`.
Include exactly one hidden raw-body marker in each reply:

```text
<!-- OpenAI Codex via RPR reply-to:SOURCE_TYPE:SOURCE_ID:UPDATED_AT -->
```

Do not show a visible RPR attribution. Before posting, confirm no existing
reply contains the same event marker. After posting, fetch the durable comment
or inline reply and verify its body and target thread directly.

Post PR-conversation replies with:

```bash
gh api repos/OWNER/REPO/issues/N/comments -X POST -F body=@REPLY_FILE
```

Post inline replies with:

```bash
gh api repos/OWNER/REPO/pulls/N/comments -X POST \
  -F in_reply_to=SOURCE_COMMENT_ID -F body=@REPLY_FILE
```

### 8. Self-heal monitored mode without idle model usage

Do not keep a model-backed monitor, coordinator, or watchdog alive. Use the
SQLite-backed deterministic detector in `scripts/review_monitor.py`, supervised
by the OS (for example, `launchd`). The detector polls GitHub, debounces exact
heads, preflights the complete diff, persists leases, circuits, attempts and
usage, writes heartbeats, and consumes no Codex quota while it polls. GitHub's
exact-head marker is completion truth; SQLite is the local operational control
plane.

**Do not hand-write the supervisor.** `wf` owns provisioning, because every path in a launchd
job is machine-specific — `uv`, `gh`, `codex`, the script, the state directory — and a
hand-written plist is how a working monitor becomes a machine that silently reviews nothing:

```bash
wf review-pr install --repo txehq/tokun-cn   # resolve paths, write the plist, load the job
wf review-pr status                            # per repo: loaded, last heartbeat
wf review-pr logs --repo txehq/tokun-cn      # where the supervisor writes, and the tail
wf review-pr uninstall --repo txehq/tokun-cn # unload and remove; state is left in place
```

`install` resolves `uv`, `gh`, `codex` and `node` the way `/readiness` does — login shell,
session, then a minimal environment. The detector receives `uv`, `gh` and `codex` as absolute
paths, because launchd runs with a `PATH` that resolves almost nothing, and the job's `PATH`
holds the directories of all four for the workers: npm's `codex` runs `#!/usr/bin/env node`,
and a follow-up worker runs `gh`. The job runs the detector with `uv run --script`, which
installs the dependency the script declares (`markdown-it-py`). `install` refuses when any of
the four is missing, and refuses a repository `gh api repos/OWNER/REPO` cannot read with the
current GitHub credentials: a monitor that installs cleanly and then cannot poll is the failure
this command exists to prevent.

**An open circuit is cleared with the detector's own flag.** A failed job opens a durable
circuit, and only an explicit exact-job reset clears it. Read the job's `last_error` before
resetting it. Reset keeps the attempt and token history; a review job gets a fresh preflight,
and a follow-up job is dispatched again. The detector holds a single-instance lock, so unload
the job, run the reset, and install the job again:

```bash
wf review-pr uninstall --repo OWNER/REPO
uv run --script <script> --repo OWNER/REPO --state-dir <dir> --reset-job 'OWNER/REPO#PR@HEAD' --once
wf review-pr install --repo OWNER/REPO
```

`<script>` is `bundle/skills/review-pr/scripts/review_monitor.py` under `wf`'s active
generation, and `<dir>` is the state directory `wf review-pr install` printed.

One supervised process per repository. That is the isolation boundary in the detector —
leases, circuits and the database are per state directory — and `install` keeps it.

**`status` reads the heartbeat.** The detector writes `heartbeat.json` after each validated
poll, and a wedged detector stops writing it while its process stays alive.

For an uncovered exact head, launch one ephemeral strongest-model/high-reasoning
static reviewer directly. Stream the complete prompt on stdin, capture only
`--output-last-message`, validate the review structure with a Markdown parser,
re-fetch the exact head and deduplication marker, then post and verify one
COMMENT review deterministically. If a valid review contains a pre-existing
Medium+ finding, open the circuit for manual Linear triage before posting. After
filing the §5a tickets, post the held review with the §5 command: it is
`jobs-v2/<job>.attempt-<n>.review.md` in the state directory, where `<job>` is the
job id with `/`, `#` and `@` written as `_`. The next poll sees the head covered
and completes the job.
Launch an ephemeral `gpt-5.6-luna` low-reasoning worker only for semantic author
follow-ups; do not nest a Sol CLI process inside Luna for ordinary review jobs.

Apply these recovery rules:

- Run at most one job per durable identity: `OWNER/REPO#PR@HEAD` for reviews and
  `SOURCE_TYPE:SOURCE_ID:UPDATED_AT` for replies. Permit concurrent jobs for
  distinct PRs up to the configured worker cap.
- A worker that exits with a non-zero code, a reviewer that leaves no final-message
  artifact, and a review that fails structure validation each open a durable
  circuit for the job. No job is retried: only an explicit exact-job reset clears a
  circuit, and reset keeps attempt and token history, runs a fresh deterministic
  preflight for a review job, and dispatches a follow-up job again.
- The circuit opens before a review is posted: a detector that stops mid-post
  never posts the review twice, a verified post completes the job, and the next
  poll completes a job whose head GitHub shows covered.
- Preflight outcomes are recorded states: a closed, draft or own PR, or one that
  changes no files, is ineligible; a covered head completes its job; a diff
  GitHub will not serve, or one above the single-review limit, opens the circuit
  for a chunked review with `/review-pr`. A cancelled or stale job whose head
  returns is preflighted again.
- Workers run in their own process group, so a detector restart leaves them
  running and the next process reaps them.
- An unexpected error — a GitHub error, invalid JSON, an empty diff for a PR that
  changes files, corrupted evidence — ends the detector process, and the OS
  restarts it. On startup,
  acquire the single-instance file lock, reconstruct all eligible PRs from
  GitHub, reconcile dead leases, and baseline historical author comments. Jobs
  found in a `state.json` state file are imported with their circuits open.
- Emit a heartbeat after each validated poll and persist reservations before
  dispatch. Use exact-head reviews and reply markers on GitHub as the source of
  truth after any restart.
- Reap completed workers, and discard jobs whose head changed or whose PR closed.
- Keep worker sessions ephemeral and logs file-backed. Never invoke a model for
  heartbeat checks, ordinary polling, queue management, or process recovery.
- Run daily retention only while idle: preserve active jobs and their evidence,
  compact usage aggregates, expire detailed attempts, events and evidence by
  policy, checkpoint WAL, incrementally vacuum, and pause dispatch at the
  database-size guard.

The detector's tests run from the repository root and need an authenticated `gh` and the
`codex` CLI:

```bash
uv run --with 'markdown-it-py>=3' python -m unittest discover -s skills/review-pr/scripts -p 'test_*.py'
```

The detector and OS supervisor may recover operational control only. They must
not weaken review-only authority, bypass exact-head guards, or introduce code,
branch, metadata, status, merge, release, or deployment changes.

## Review quality rules

- Make severity visually scannable: use one `### Severity [N]` heading per
  non-empty severity, with the exact finding count in brackets. Use consecutively
  numbered, descriptive `####` finding headings, restarting at 1 per section.
- Report reproducible findings, and leave speculative ones out.
- Do not flag pre-existing behavior as introduced by the PR.
- Do not infer that passing tests eliminate uncovered failure modes.
- Check source-order and lifecycle behavior for migrations and state machines.
- Treat money movement, authorization, destructive operations, and irreversible migrations as high-risk surfaces.
- Respect the PR’s documented scope while still reporting correctness or safety defects.
- Never post a commit status from RPR.

## Assert the artifact

| Signal that looked conclusive | Artifact that showed the real state |
|---|---|
| `next build` printed `● /[locale]/marketplace/[...slug]` | `.next/prerender-manifest.json` → **0 routes** |
| `gh pr checks` → "all 21 pass" | required contexts diffed against the reported ones → one **absent** |
| `pnpm test` green | the implementation mutated → **2 tests never fired** |
| "the page is faster now" | `x-envoy-upstream-service-time` → p50 **2099 ms** |
| a CI wait loop reported done | `gh` had returned `EOF`; the loop exited on **no output** |

**Never accept a summary as evidence of the thing it summarises.** For each claim, name the artifact that would differ if the claim were false, and read that. If the only evidence is an exit code or a status word, the claim is unverified.

Apply while reviewing:

1. **Absence is invisible in summaries.** A check summary cannot show a required check that never reported; diff required-vs-reported. Same shape: a config key that silently does nothing, a param list that yields zero output.
2. **A condition that consumes command output fails open.** A tool error yields empty output, which matches "nothing pending". Test for the positive signal, and treat a tool error as an error.
3. **A guard is only proven by breaking what it guards.** A test written to FAIL proves nothing until it is seen failing. When a diff adds or edits a gate, guard, fail-closed assertion or conformance check, ask for the mutation evidence (TXE-1131); its absence is itself a finding.

## Self-improvement

After execution, update this skill only when a concrete review-only workflow assumption proved wrong. Never weaken the authority boundary as a convenience.
