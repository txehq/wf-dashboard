# Copy and presentation examples

Use these when a paragraph mixes explanation with information the user needs.
The examples illustrate decisions; adapt their wording to each product.

## Remove the explanation, keep the task

| Before | Better result | What must remain |
| --- | --- | --- |
| Reason placeholder: “为什么改 —— 季度末对账时用得上” | Remove the placeholder. | Visible reason label, required/optional state and validation. If the audience affects privacy expectations, show “申请人可见”. |
| “删除「{name}」只是删掉规则本身。它此前批过的申请是已经发生的事实，不会被撤回。” | “删除规则「{name}」？已批准的额度将保留。” | The object and the consequence. |
| A paragraph about workers, polling and payment queues | “停止新的自动充值；进行中的扣款会继续完成。” | The actual boundary of the stop action. |
| A formula permanently below a metric | Keep the metric name, value, unit and range visible; disclose the formula beside it. | Any current coverage limitation that changes how the value should be interpreted. |
| “点击复制” beside a button already named “复制” | Remove the duplicated instruction. | “已复制” after a successful copy. |

## Keep different states different

| Evidence | Suitable short presentation | Misleading simplification |
| --- | --- | --- |
| Request succeeded, list is empty | “还没有自动提额规则” + existing create action | Explaining all future routing behavior in the empty state. |
| Search returned no matches | “没有找到匹配的成员” + clear filters | “还没有成员”, which suggests the organization is empty. |
| Loading failed | “资讯加载失败” + retry | “暂时没有资讯”. |
| Body capture is disabled | “尚未开启正文留存”; settings entry when authorized | “本次调用未留存正文”, which describes a different condition. |
| Requested dates exceed retained data | “已统计 {date} 起的数据”; explain an entirely unavailable range explicitly | A complete-looking total for the full selected range. |
| Failure logging was disabled | Mark the affected health metric unavailable or visibly incomplete. | An unqualified success rate, even with a tooltip defining its formula. |
| Session data does not cover a client | “会话数据未覆盖此客户端” when known; otherwise state that data was not obtained. | “没有会话” or an inference about the person's work. |
| A savings amount covers only part of the cached tokens | “已确认节省 {amount} · 覆盖 {percent}% 缓存 Token” | Presenting the lower bound as total savings. |
| Payment evidence needed for release is incomplete | State the missing evidence before the release decision; keep details available. | Hiding the missing evidence in a generic empty illustration. |
| Feature is unreleased but its card is retained | “此功能暂未开放” with a quiet illustration if useful. | A fake switch or a promise that normal user activity will populate it. |

## Warmth without invented claims

- “没有需要你决定的事” can suit a successfully loaded, empty approval queue.
- “第一次调用，等你开启” can suit onboarding, with an action appropriate to the
  actual setup state: create a key if needed, otherwise open the connection guide.
- “暂时没有新资讯” is accurate without promising a delivery. PR #239's “新鲜资讯正在
  赶来的路上” requires a real update expectation and must not be mistaken for loading.
- “没有公开事件” alone cannot establish “一切正常”.

## Sources

These examples derive from [sub2api PR #239](https://github.com/txehq/sub2api/pull/239),
base `58b8de71f3185dc1582e9fc0eba503cbc78e1a75` to head
`1ba8ac0816089cfe40450f477bbc608019bcf8b9`. The before/after patterns were checked against
the diff; the partial-data and state-conflation risks also appear in its inline review.
The recommendations above are not a claim that every PR edit was correct or that its
review scenarios were reproduced in production.

Interaction references: [WCAG content on hover or focus](https://www.w3.org/WAI/WCAG22/Understanding/content-on-hover-or-focus.html),
[GOV.UK text inputs](https://design-system.service.gov.uk/components/text-input/),
[Carbon empty states](https://carbondesignsystem.com/patterns/empty-states-pattern/).
