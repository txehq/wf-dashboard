# State-forcing and probe patterns (generic layer)

> **This is the GENERIC layer of the living log.** It ships with the skill, so a
> consumer repo's copy is materialized and read-only — change it by PR to the
> skill source. Every recipe here must be **product-independent**: framework-level
> or tool-level, no project's stores, routes, tables, env vars, or file paths.
> Project-specific probes go to `.agents/acceptance/probe-mock-patterns.md`, the
> writable project layer.
>
> **Read this before any run that must force an error state or inspect runtime
> state.** Each item: Situation / Works.
>
> **Do not add mocks, fake implementations or injected failures to the product
> under test.** Section A produces error states from real conditions.
>
> **Run a JavaScript snippet from this file** by writing it to a `.js` file in the
> round directory with the file editing tool and passing it on stdin:
> `agent-browser eval --stdin < "$REPORT_DIR/<name>.js"`.
>
> **Separate the observation from the explanation.** When you add an item, cite the
> exact mechanism (a `file:line`, a measured A/B); when you only saw a symptom,
> write "cause not established". A wrong mechanism sends the next reader to fix the
> wrong thing.

---

## A. Forcing a request to FAIL (error-state testing)

### A1. Judge interception by the fetch's own outcome

- Apps commonly **swallow** a failed fetch: a store action can resolve successfully
  even when its underlying request was aborted, so the UI and the action's promise
  both "look like" a 200. Never judge whether your fault landed by the action or the
  UI.
- **Works**: wrap `window.fetch` post-load and record each request's own resolve /
  reject. Use a guard so a second `eval` doesn't wrap the wrapper (stack overflow):
  ```js
  if (!window.__W) {
    window.__W = 1;
    window.__R = [];
    const of = window.fetch;
    window.fetch = function (...a) {
      const p = of.apply(this, a);
      if (String(a[0]).includes('<url-fragment>'))
        p.then(
          (r) => window.__R.push('resolved_' + r.status),
          (e) => window.__R.push('REJECTED_' + e.message),
        );
      return p;
    };
  }
  ```
- **`agent-browser network requests` under-reports.** Decide whether a request happened
  from the wrapper's `window.__R` record.

### A3. WORKS — block the request through CDP `Network.setBlockedURLs`

- `scripts/cdp_block_urls.py` attaches to one page target, enables the Network
  domain, and blocks every request matching the given absolute URLPattern strings
  for as long as it runs. It blocks at the network stack (below `fetch`, so it also
  catches requests a page-realm `fetch` override might miss). Run it in its own
  shell, drive the scenario, capture, then stop it with Ctrl-C; the block ends with
  its CDP session.
  ```bash
  # Web: the session's CDP endpoint. Electron: --cdp-url http://127.0.0.1:<CDP port>
  uv run "$SKILL_DIR/scripts/cdp_block_urls.py" \
    --cdp-url "$(agent-browser --session "$SESSION" get cdp-url)" \
    --page-url http://localhost:3000/ \
    --block 'http://localhost:3000/api/items*'
  ```
- Block a mutation's endpoint the same way to exercise a failed-save state.

### A4. WORKS — failures the server produces

- **Service stopped** — stop a backing service this run started (`PROJECT.md` §2),
  capture the unavailable state, then start it again and confirm its health check
  passes before the next case.
- **Invalid input** — submit input the server rejects, such as a value that fails
  validation or a missing required field, and capture its error state.

### A5. Remove a temporary probe edit with the file editing tool

- A temporary probe edit (such as the C1 debug global) often goes into a file the
  branch has **already modified (uncommitted)** — the common case for a pre-PR
  review. Check `git status --short` before the edit so you know which files are
  dirty, save the file's diff, and mark every inserted line with `AGENT-TEST`.
  After capture, delete exactly those lines with the file editing tool and prove the
  removal is exact:
  ```bash
  git diff -- <file> > "$REPORT_DIR/probe-before.diff"      # BEFORE the edit
  # ... insert the probe, capture, delete the AGENT-TEST lines with the file editing tool ...
  git diff -- <file> | diff "$REPORT_DIR/probe-before.diff" -
  grep -rn AGENT-TEST
  ```
  Both checks print nothing when the file is back to its state before the probe.

### A6. WORKS — before/after renders from a separate worktree, gated on a measured version signal

- Render the "before" state from the base version in its own worktree, and the
  "after" state from the working tree under review:
  ```bash
  git worktree add --detach "$REPORT_DIR/base-worktree" <base>
  # ... start the base instance on its own port (PROJECT.md §2), capture the same view from both instances ...
  git worktree remove "$REPORT_DIR/base-worktree"
  ```
- **Works — gate every capture on a measured version signal.** Pick a property that
  differs between the two versions and read it back with `getComputedStyle` before
  shooting; capture only when it has the value expected for that instance.
- **Corollary — a layout change may be invisible at the default size.** A
  right-alignment / `flex` fix can render identically to the broken version in a
  narrow container (content already fills the row); drive the app's own resize
  affordance with real mouse events before concluding "no visual change".

---

## B. Cache / stale state that MASKS the failure

### B1. A failed revalidation cannot show an error once the data has settled

- A surface that loaded successfully once caches the last-good value. On a later
  failed fetch, a well-behaved error boundary keeps the settled content (a
  background error must not replace loaded content), so a blocked request shows the
  old content.
- **Works**: to see a genuine FIRST-LOAD error, clear all client storage, then
  cold-load. `scripts/clear-client-storage.js` clears localStorage, sessionStorage,
  IndexedDB and the Cache API, and rejects when a database deletion fails or an
  open connection blocks it:
  ```bash
  agent-browser --session "$SESSION" eval --stdin < "$SKILL_DIR/scripts/clear-client-storage.js"
  ```
  Clearing usually signs you out, so re-seed auth, open `about:blank`, and open the
  target.

### B2. SWR-style clients retry for \~30s before the error settles

- A data client with retry/backoff keeps `isLoading` true during retries, so a
  screenshot taken during them shows a skeleton. A typical config (5 attempts,
  exponential backoff capped at 30s) settles the error only after \~30s.
- **Works**: wait \~35s after load for retries to exhaust, THEN screenshot.

### B3. In-memory cache survives `open`; persisted cache survives everything

- `open about:blank` then `open <target>` forces a fresh JS context and clears the
  in-memory cache; persisted storage stays, so a true cold load needs B1. Verify the
  fresh context with a marker set via `eval`: the page's own script re-runs on the
  second `open` and re-creates its own markers, which reads as a preserved context.
  Persisted caches commonly live in **two tiers** — IndexedDB for collections and
  localStorage for app shells — which is why B1 clears both plus the Cache API.

### B4. Component-local state seeded from a cached item does NOT reset when fresh data arrives

- A row component that initializes local state from its item
  (`useState(() => derive(item))`) captures the value at first render. When a
  persisted cache hydrates the list with a stale item first, `useState` captures the
  stale value; when the fresh server response replaces the data, the row does not
  remount (same React key), so the stale local state sticks. No amount of waiting
  fixes it.
- **Works**: for any assertion on an initial-render flag that flows through
  `useState(init)`, force a clean first frame by clearing only the persisted-cache
  tier and reloading (login usually survives if you don't touch the session cookie),
  and verify the underlying data separately so a stale render is attributed to the
  cache.

### B5. A persisted SWR cache replays an earlier terminal result under the same key

- **Situation**: capturing a polling flow's successive UI states (processing /
  failed / done) across full page reloads, with the failed state produced by A3 or
  A4. The persisted SWR cache (B3) hydrates the previous capture's terminal result
  under the same SWR key at mount, and a "done"-triggered effect (auto-advance) can
  fire \~1s after load.
- **Works**: clear the persisted-cache tier (B4) before each reload, so every
  capture starts with no cached entry under that key. Read the contract fields the
  UI actually sent (e.g. per-provider retry ids) from a HAR
  (`agent-browser network har start` / `network har stop`).

---

## C. Probing app / runtime state

### C1. WORKS — read live component state with a temporary debug global

- The decisive way to read a component's live props / store / fetched values: add a
  debug global in the render, reload, read it, and remove it with the file editing
  tool (A5).
  ```tsx
  // AGENT-TEST 临时调试 global，采集后删除
  if (typeof window !== 'undefined')
    (window as any).__DBG = { data: /* ... */, hasError: !!error, isLoading };
  ```
  ```bash
  agent-browser --session $S eval 'JSON.stringify(window.__DBG)'
  ```
  This surfaces cases where the data looks settled even on error.

### C2. `agent-browser console` capture works — use it for log output

- Console capture is reliable on current agent-browser (a page-script `[log]` and one
  emitted later from `eval` both appear). An empty console means the page logged
  nothing. Read structured component state with the debug global (C1), and log
  output with `agent-browser console`.

### C3. `document.body.innerText` keyword grep false-positives on fixture text

- Asserting a state via `body.innerText.includes('<phrase>')` matches your own fixture
  content if it happens to contain that substring (e.g. a fixture literally named
  "…failure…" when you assert on "failure") — a false pass on a state that never
  rendered.
- **Works**: scope the check to the actual UI element (`querySelectorAll` on the
  specific tag/toast/alert), and name fixtures without any state keyword you assert
  on.

### C4. `innerText` can be 0 on a rendered page — use it to tell a stuck renderer from a blank page

- On some app shells `document.body.innerText` reads `""` even on a fully rendered
  page (some ancestor collapses the layout-dependent computation); probe a specific
  container such as the app root element.
- **Diagnostic**: `innerText` needs layout; `textContent` reads the DOM alone. When
  the root gives `innerText === 0` and `textContent > 0`, the DOM is fine and the
  RENDERER is not painting (a stuck compositor — see D9). When both are 0, the DOM is
  genuinely empty.

### C5. A successful upload does not prove a complete acceptance handoff

- A static publisher can store a summary while the evidence remains on the
  agent's machine. Verify the complete report and every referenced medium.
- Read back the PR/Issue body after editing. Confirm that the delivery's engapp.dev
  report link is present and screenshot Markdown is in the requested template
  section.

---

## D. agent-browser / CDP mechanics

- **D1. Pass `screenshot` an absolute path.** A relative path saves to the caller's
  cwd, and the cwd of a step inside a script can differ from the one you expect.
- **D2. The CDP port can be ephemeral.** A browser launched with
  `--remote-debugging-port=0` picks a random port; read `DevToolsActivePort` in the
  user-data-dir, or use `agent-browser get cdp-url` (`cdp-url` is a subject of
  `get`). Electron dev instances usually pin a known port (e.g. 9222) — the project
  adapter says which.
- **D3. `wait --load networkidle` HANGS during a retry loop** (the network never
  idles) and can exceed the command timeout — use a fixed `wait <ms>` when a fetch is
  stuck retrying. (macOS has no `timeout(1)` to bound it.)
- **D4. Portal toasts auto-dismiss (\~5s) and `snapshot -i` may miss their buttons.** A
  base-ui / portal-rendered toast lives outside the main tree and can be occluded by a
  dev overlay; `snapshot -i` does not reliably surface its action buttons. Read the
  toast via an `eval` DOM query, and because it dismisses in \~5s, re-trigger it
  immediately before the screenshot or query; to press one of its buttons, call
  `.click()` on it inside the same `eval`.
- **D5. `agent-browser screenshot` can leave the session stuck; `eval`/`get` still
  work.** Each session is one daemon socket, so the stuck state is scoped to that
  session. An interrupted screenshot RPC (a killed command, a bad flag, `--full` on a
  page many screens tall) can leave the socket half-consumed, after which every later
  `screenshot` fails (`Resource temporarily unavailable` /
  `CDP response channel closed`) while `eval`/`get url` keep working. Reset with
  `agent-browser close --all`.
- **D6. WORKS — raw-CDP screenshot bypasses the daemon.**
  `scripts/cdp_screenshot.py` opens its own DevTools connection to one page target,
  does one `Page.captureScreenshot`, and closes. It is unaffected by the D5 stuck
  session and **robust when the display is asleep or the window is
  minimized/occluded** (the engine forces a compositor frame). Use it as the
  preflight: a capture whose brightest pixel, measured as in D7, is above `0` is a
  real frame.
  ```bash
  uv run "$SKILL_DIR/scripts/cdp_screenshot.py" --cdp-url http://127.0.0.1:9222 \
    --page-url http://localhost:3000/ --out "$REPORT_DIR/preflight.png"
  ```
- **D7. OS `screencapture` is BLACK when the display is asleep/locked/screensaver.**
  `screencapture` (and osascript grabs) captures the physical framebuffer, so a
  display that slept when idle produces a uniformly black PNG (mean/max = 0) while
  the permission is granted. Keep the display awake for the whole run and gate it
  with a probe capture's brightest pixel:
  ```bash
  caffeinate -dimsu &
  screencapture -x "$REPORT_DIR/probe.png"
  magick "$REPORT_DIR/probe.png" -colorspace Gray -format '%[fx:maxima]\n' info:
  ```
  A probe at `0` stops the run: report the measurement and its cause as confirmed or
  suspected ([SKILL.md](../SKILL.md) M4).
- **D8. The daemon serializes commands — `open` queues behind a screenshot loop.**
  While a recording loop (`scripts/record_cdp_frames.py`) is running,
  `agent-browser open <url>` lands late/out of order, and your "during navigation"
  screenshot can show the PREVIOUS page (which may look identical to the expected end
  state — a false read). **Works**: during any recording loop, navigate with
  `agent-browser eval 'location.href="<url>"'` (fire-and-forget).
- **D9. A mid-session bundler dependency re-optimize can leave the renderer
  compositor stuck.** Symptom: capture returns black, the app root's `innerText` is 0
  while `textContent` still holds the full DOM (C4), and `visibilityState` is
  `visible` with real dimensions. It often follows a "re-optimizing dependencies" /
  "failed to fetch dynamically imported module" log line. **Works**: restart the dev
  instance.
- **D10. Virtualized lists: driving `scrollTop` by hand blanks the pane — keep the
  target on the first screen.** A virtualizer unmounts nodes as you scroll past (a
  `TreeWalker` search then "loses" a node that was there a second ago), and forcing
  `scrollTop` far outside the rendered window can make the scroll container itself
  disappear — reading exactly like a render bug. **Works**: pick a fixture whose
  target renders on the first screen.
- **D11. React controlled inputs ignore synthetic events — use `agent-browser click`
  (trusted CDP input).** `el.click()` and even a full synthetic
  `pointerdown/mousedown/pointerup/click` sequence are `isTrusted: false`, so a
  React-controlled checkbox/toggle never updates its state. **Works**: `snapshot -i`
  for the ref, then `agent-browser click <ref>` — it goes through CDP
  `Input.dispatchMouseEvent`, which the page sees as a real user click. The snapshot
  also reveals when a control is `[disabled]` (the app deliberately refusing).
- **D12. Disambiguate elements by geometry or an identifying attribute.** A page can
  render a hidden zero-size duplicate of a subtree (e.g. an offscreen measurement
  copy) at `(0,0)`, first in DOM order, so a singular
  `querySelector` grabs the phantom: a `fill` reports success while the visible box
  stays empty, a click on the phantom button is a silent no-op, and an `innerText`/aria
  grep "finds" a control the user can't see. **Works**: enumerate and filter by a
  non-zero `getBoundingClientRect()`, or target by the component's own `aria-label`;
  tag the resolved element with a `data-probe` attribute and drive it with
  `agent-browser click '[data-probe=...]'`.
- **D13. A blank page at `about:blank` with a 1280px viewport usually means the
  previous `open` failed** (exited non-zero without navigating — e.g. an unrecognized
  global flag). The session still exists and answers every later probe — against the
  fresh page it was born with, at the default viewport. Treat the fingerprint as "the
  navigation failed", and read the `open` exit code and stderr to learn _why_.

---

## E. Environment / shell gotchas

- **E1. Not every layer hot-reloads — restart and prove which code the process runs.**
  A dev server's HMR typically covers the renderer/client only. Server code,
  main-process code, and adapters that run out-of-process are often NOT recompiled on
  edit, so reloading the client verifies nothing — the old code is still running, and
  the failure looks exactly like a logic bug in your own diff. **Works**: after an
  edit to a non-client layer, restart before drawing a conclusion, and prove the
  process has your code before debugging it — e.g. curl the dev bundler for the source
  and grep for a marker (renderer), or grep the built bundle for the marker (server /
  main).
- **E2. The shell's `grep` may honor `.gitignore` — "not found anywhere" can be a
  false negative.** Some environments alias `grep` to a wrapper (e.g. `ugrep --ignore-files`) that skips `.gitignore`d paths, silently omitting `node_modules`.
  Before asserting "X exists nowhere", name the ignored directory explicitly
  (`grep -rl X node_modules`) or call `/usr/bin/grep` directly.
- **E3. In zsh, a loop variable named `path` overwrites the command search path.** zsh
  ties `path` to `PATH` as a special array; assigning it (e.g. parsing a cookie jar's
  path field) replaces the process command search path, and the next executable fails
  with `command not found`. Name the field something else (`cookie_path`); this is a
  shell failure. zsh also does not word-split unquoted variables: stashing
  `S="--session x --cdp 9226"` and then running `agent-browser $S` fails; inline the
  flags or use an array.
- **E4. A curl "502" from a local port with nothing listening can be a shell proxy
  env.** If `HTTP_PROXY`/`HTTPS_PROXY` are set and `NO_PROXY` does not exempt
  localhost, a dead local host is forced through the proxy and returns the proxy's
  502, which looks like a running but broken server. Pass `curl --noproxy '*'` for
  local requests, and when a local port returns 502, check `NO_PROXY` before
  concluding the server is up.
- **E5. Dev servers can write managed files on start — check `git status` before
  reporting the tree clean.** Some frameworks append a managed block to a repo file on
  `dev` start (once, idempotently). Commit the block or opt out per the framework,
  and always check `git status` before claiming a clean tree.
- **E6. Persistent resource exhaustion (e.g. Vite `EMFILE: too many open files`) is a
  stop-and-ask.** If a surface exits at startup with a
  file-watcher/resource-exhaustion error while the port is free, the likely cause is
  other running watchers (extra worktrees, surviving terminals, an editor window) that
  you must not kill. Terminate the run, report the exact error, and ask the user to
  clean up other processes — do not change watch mode, fall back to a static build, or
  publish a report from a degraded surface.
- **E7. The default `lobehub-dev` browser session is shared — a parallel run can steal
  your tab.** `agent-browser` sessions are keyed by name, so two runs both using
  `--session lobehub-dev` drive the **same** browser. The other run navigates the tab to
  _its_ dev server, after which your `eval` reads that page while `screenshot` may still
  show yours — a screenshot that renders your fixture next to a
  `document.body.innerText` from the same moment containing none of its strings, every
  assertion `false`. The cause is two runs sharing one browser. **Works**: give every
  run its own session name, seed auth into it, and confirm the tab is yours before
  asserting — `agent-browser --session <name> tab list` must print YOUR port and path.
  Same applies to ports: a worktree allocates its own `SERVER_PORT`/`SPA_PORT`, so
  re-run `test-env.sh` inside the worktree you are testing.
