// 返回 renderer 的 URL、readyState，以及 app 自己加到 window 上的 global 名称，用来找到真实的 state handle
(function () {
  const frame = document.createElement('iframe');
  frame.style.display = 'none';
  document.body.appendChild(frame);
  const builtIn = new Set(Object.getOwnPropertyNames(frame.contentWindow));
  frame.remove();
  return JSON.stringify({
    url: location.href,
    pathname: location.pathname,
    hash: location.hash,
    readyState: document.readyState,
    appGlobals: Object.getOwnPropertyNames(window).filter((name) => !builtIn.has(name)),
  });
})();
