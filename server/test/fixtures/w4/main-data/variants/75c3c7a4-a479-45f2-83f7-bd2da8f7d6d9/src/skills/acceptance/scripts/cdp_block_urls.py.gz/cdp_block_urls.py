# /// script
# dependencies = ["websockets>=15"]
# ///

import argparse
import json
import signal
import sys
from urllib.parse import urlsplit
from urllib.request import ProxyHandler, build_opener

from websockets.sync.client import connect

parser = argparse.ArgumentParser(
    description=(
        "Block requests in one page target with CDP Network.setBlockedURLs "
        "until SIGINT or SIGTERM ends the CDP session."
    )
)
parser.add_argument(
    "--cdp-url",
    required=True,
    help="the output of `agent-browser get cdp-url`, or http://127.0.0.1:<port> for an app's CDP port",
)
parser.add_argument(
    "--page-url",
    required=True,
    help="URL prefix that matches exactly one page target",
)
parser.add_argument(
    "--block",
    required=True,
    action="append",
    help="absolute URLPattern string to block, such as http://localhost:3000/api/items*; repeat for more patterns",
)
args = parser.parse_args()


def stop(signum, frame):
    # 收到 SIGINT 或 SIGTERM 时正常退出，with 块关闭 CDP session，Chrome 随之解除 blocking
    sys.exit(0)


signal.signal(signal.SIGINT, stop)
signal.signal(signal.SIGTERM, stop)

# 本地 DevTools endpoint 不经过环境变量里的 HTTP proxy
opener = build_opener(ProxyHandler({}))
with opener.open(f"http://{urlsplit(args.cdp_url).netloc}/json/list") as response:
    targets = json.load(response)
pages = [
    target
    for target in targets
    if target["type"] == "page" and target["url"].startswith(args.page_url)
]
if len(pages) != 1:
    sys.exit(
        f"--page-url {args.page_url} matches {len(pages)} page targets: "
        f"{[page['url'] for page in pages]}"
    )
page = pages[0]

# ping_interval=None 关闭 keepalive ping，proxy=None 让 websocket 直连本地 CDP port
with connect(page["webSocketDebuggerUrl"], max_size=None, ping_interval=None, proxy=None) as websocket:
    commands = [
        (1, "Network.enable", {}),
        (
            2,
            "Network.setBlockedURLs",
            {"urlPatterns": [{"urlPattern": pattern, "block": True} for pattern in args.block]},
        ),
    ]
    for message_id, method, params in commands:
        websocket.send(json.dumps({"id": message_id, "method": method, "params": params}))
        # 跳过 Network event，直到收到同 id 的响应
        reply = json.loads(websocket.recv())
        while reply.get("id") != message_id:
            reply = json.loads(websocket.recv())
        if "error" in reply:
            sys.exit(f"{method} failed: {reply['error']}")
    print(f"blocking {args.block} in {page['url']}; stop with Ctrl-C", flush=True)
    # 持续读取 event，直到信号退出或连接关闭
    for _ in websocket:
        pass

sys.exit(f"the page target {page['url']} closed the CDP connection")
