---
name: deploy-summary
description: Brief a stakeholder on a shipped change — what it does, why, where to see it on staging, and whether it is actually running there. Use after merging a PR that someone is waiting on, when someone asks for a deploy summary, or to summarise what a deployment carried. Written for a non-engineer; the merge and the deployment are each reported as a fact of their own.
---

# /deploy-summary — brief the person who asked for it

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Delivery/Deploy Summary.md` (WF-DEPS).
Where this file and the spec disagree, the spec wins: update this file to match it.

## Who this is for

**A stakeholder**: somebody who asked for a thing and wants to know whether it is done and where
to look at it.

## 1. Derive the facts

```bash
wf deploy-summary --pr 20 --context <staging-ctx>    # repeat --pr for a batch
wf deploy-summary --pr 20                            # no environment named → state is unknown
```

It returns each PR's title, author, merge time, size, tickets, URL and the author's own
description — plus the deployment state. **Do not run `gh` and `kubectl` yourself and
transcribe the results.**

## 2. Report the deployment state

Whether the change is running is the question actually being asked. The tool reports one of
exactly three states, decided by what it read:

| state | what it means |
|---|---|
| **on staging** | found running, with the evidence |
| **not yet** | the environment was read, and it is not there |
| **unknown** | **the environment could not be read** |

**Report `unknown` as "we could not check".** A failed read finds no matching image, and no
matching image is exactly what a genuinely undeployed change looks like.

The link between a merge and a running container is the commit appearing in an image tag. A
product that does not tag that way makes the link invisible: report its state as `unknown`.

## 3. Write the six parts

Write every working file into `.deploy-summary/` in the current directory. Create that
directory, with a `.gitignore` in it containing `*`, before writing the first file into it.

The tool supplies none of the prose.

1. **What shipped**, in one sentence a non-engineer can act on, describing the change: "Bulk
   CSV export now handles files over 50 MB".
2. **Why**, and the ticket it answers. Close the loop on the request.
3. **Where to see it on staging** — the actual surface, and how to reach it.
4. **The deployment fact**, in the honest form from §2.
5. **Anything the reader must do** — a migration, a config change, a re-login, or explicitly
   nothing.
6. **The meta**: PR number and link, tickets, author, merge time.

**Write from the author's description**: the PR body says what they meant.

## 4. Publish, then record

Render with **`/explainer`** into `.deploy-summary/deploy-summary.html`, then:

```bash
wf publish-artifact .deploy-summary/deploy-summary.html --title "<what shipped> — on staging"
```

Then comment the link on each ticket the change carries. **Do not change their status.** This
run does not establish that the change is accepted.

## What this must never do

- **Claim it works.** This says what is *running*. Whether it behaves correctly is
  `/acceptance`'s question.
- **Put cluster internals on the page** unless they change what the reader should do. "It has
  restarted twice since deploy" is worth a sentence.
- **Touch production by accident.** A context that looks like production is refused without
  `--production`.
- **Deploy anything.** It observes.
