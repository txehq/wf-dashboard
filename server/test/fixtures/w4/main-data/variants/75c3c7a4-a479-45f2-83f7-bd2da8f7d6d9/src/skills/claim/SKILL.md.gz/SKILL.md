---
name: claim
description: "Step 1 of /ic — claim a Linear ticket and load everything it points at: check-write-recheck the claim, read the ticket whole with every comment, attachment and inline image, read the Obsidian documents behind it and the repository's own instructions, then post the requirements checklist on the ticket as the artifact the rest of /ic works from. Use when someone says \"claim TXE-N\", \"take TXE-N\", \"read this ticket properly\". Never re-scopes and never invents criteria: a ticket without criteria is a planning defect."
---

# /claim — take the ticket, and read everything it points at

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/IC Session.md` (WF-IC — the
corpus has no separate node for this step), with the stage table in
`Project Magi/Workflow/System Design.md` §2. Where this file and the spec disagree, the spec
wins: update this file to match it.

## Contract — what goes in, what comes out

| | |
|---|---|
| **In** | a ticket id, a Linear issue URL, or nothing (pick from the pool); Linear through the agent's MCP |
| **Out** | the ticket **In Progress**, assigned to you, with a claim comment; the **requirements checklist** posted as a ticket comment carrying the marker `<!-- ic:checklist -->`; the declared toolchains and infrastructure, echoed for `/readiness` |
| **Next** | `/readiness` with the declared needs, then `/implement` |

## When this skill starts

- **On request:** `/claim TXE-N`, "claim TXE-N", "take TXE-N", "read this ticket properly".
- **From `/ic`:** as step 1, with the ticket id or the pool.
- **Not** for an idea without a ticket → `/lfg`.

## 1. Pick, if nothing was named

When the branch or a handed brief names an epic, the pool is that epic. When neither does,
the pool is the epics with unclaimed, unblocked tickets; ask **which epic**, once, only if it
cannot be inferred. A ticket is **eligible** when it is not Done or Canceled, is unassigned or
assigned to you, and every ticket it is blocked by is Done. Never pick a blocked ticket "to get ahead";
the DAG exists because the order matters.

## 2. Claim — check, write, re-read

Read the ticket's state, assignee and blockers. Then claim it in one Linear write, so two
people cannot silently hold one ticket: assignee → you, state → **In Progress**, and a comment:

```
claimed by <handle> on <host> · <ISO time> · /ic
```

**Re-read after writing.** If the assignee is now someone else, they got there first: touch
nothing further and pick another ticket. Linear's API has no transaction, so the re-read is
what detects a concurrent claim.

## 3. Read the ticket whole

- the **description** and **every comment**, newest last — a later comment may supersede the
  description, and says so if the LFG did their job;
- the **acceptance criteria** with their verification methods; the **toolchains and
  infrastructure** declared; **rigor** and **authority ceiling**; the **dependencies**;
- **every attachment and inline image** — mock-ups, logs, spreadsheets, links. Fetch them
  through the Linear MCP. When the MCP is unreachable, stop with its error. An attachment you
  cannot open is requirements material you do not have: name it in a comment on the ticket
  and stop there; the LFG supplies it, and in solo mode that is the user. Do not guess what it
  showed;
- the **parent epic** — the whole this ticket belongs to; its criteria are met by the feature as
  a whole.

## 4. Read the documents behind it

1. The vault's `Linear Issues/` folder carries a synced copy of the ticket for text search;
   the live ticket is the authority.
2. The feature folder `Project <Product>/Features/<slug>/`: `Brief.md` for the boundaries and
   the authority ceiling, `Research.md` or `System Design.md` with the `Specs/` node for this
   part, `Tickets.md` for where this ticket sits in the DAG and what the reconciliation decided.
3. The standing `Decisions/` and `Specs/` for anything the feature documents assume.
4. The repository's own instructions — `CLAUDE.md`, `AGENTS.md`, the contract they point at,
   the PR template if there is one.
5. `/history` for earlier attempts at the same thing on this machine.

Then inspect and adapt: check the ticket's premises against the code as it is now, and look for
open tickets and PRs doing the same work. A premise that no longer holds, or work already under
way elsewhere, gets an M5 comment on the ticket, and the run stops there until the LFG answers,
as `/implement`'s M5 does.

## 5. Write the requirements checklist — and post it on the ticket

One line per requirement, drawn from the criteria **and** from every sentence of the
description, the comments and the attachments that states a behaviour. Each line carries the
requirement, its verification method, and empty slots for the file and the test that will
satisfy it. This list is what "complete" means for `/implement`, and it lives on the ticket,
where every later step and every later session reads the same list:

```markdown
<!-- ic:checklist head=<none yet> -->
## Requirements checklist · /ic · <ISO time>
- [ ] R1 <requirement, in one sentence> — verify: <test | visual | measurement> — file: — test:
- [ ] R2 …
Source: criteria 1–4; description ¶2, ¶5; attachment mockup-v2.png; comment by <who> on <date>.
```

Post it as a comment. `/implement` mirrors it into the worktree, ticks it, and updates this
same comment; `/ready-for-review` reads it back as one of its three conditions.

**A ticket with no criteria is a planning defect.** Comment naming the gap, leave the claim in
place, and stop — do not invent criteria, do not start building.

## Handing off

Echo, for the caller: the ticket id and its state, the checklist comment's URL, and the
declared toolchains and infrastructure in the words `wf readiness --need` accepts. Then
`/readiness` verifies the machine against exactly that list. The claim comment and the
checklist comment are this step's record.

## Not this

- Verifying the machine → `/readiness`. Building → `/implement`.
- Scoping or planning → `/lfg`.
- Handing the ticket to someone else → `/handover`.
