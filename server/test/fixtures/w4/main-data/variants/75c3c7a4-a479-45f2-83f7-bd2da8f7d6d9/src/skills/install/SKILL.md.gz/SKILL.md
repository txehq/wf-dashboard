---
name: install
description: Install the Magi workflow on a machine from scratch and connect the services it uses — verify the platform and tools, download and verify the latest stable release, install `wf` into every coding agent on the machine (Claude Code, Codex, Cursor, Kiro, ZCode, OpenClaw) along with ctx history search, then set up Linear, Rackspace Spot and artifact publishing, and report what is live and what is still waiting on a human. Use when someone pastes the README install prompt, sets up a new laptop or a second agent, asks to install or reinstall `wf`, or asks to connect one of those services. Repair and rollback on a machine that already carries the workflow are /install-manager.
---

# /install — set a machine up

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/LFG Session.md` (WF-LFG).
Where this file and the spec disagree, the spec wins: update this file to match it.

This is the procedure the README's install prompt hands to an agent. Run it end to end on a
machine that does not carry the workflow yet, or on one where an agent or a service is
missing. `/install-manager` is the other half of the node: reading, repairing and rolling
back an install that already exists.

Work through the six steps in order. Each ends in an observation: a command ran and its output
said so. Where a step needs the person at the keyboard — a browser login, a trust prompt — say
in one line what they have to do, continue with everything that does not depend on it, and
list what is still open in the final report.

This skill's working directory is `.install/` in the current directory. Before writing
anything into it, create `.install/.gitignore` containing `*` with the file editing tool.

Install from a verified immutable stable release. Keep every credential in the file that
holds it: the official client or `wf` reads it from disk, and no value is pasted into chat,
printed to a log, or passed as a command argument.

The same holds for what you *read out*. `codex mcp list --json` prints every server's
`transport.env`, `http_headers` and `bearer_token_env_var`, which puts other people's secrets
into the transcript. Do not print that whole list. Read the two servers this workflow manages
by name, from the configuration itself:

```bash
jq '.mcpServers | with_entries(select(.key | startswith("capso-"))) | map_values({type, command, args, url})' "${CLAUDE_CONFIG_DIR:-$HOME}/.claude.json"
codex mcp list --json | jq '[.[] | select(.name | startswith("capso-")) | {name, enabled, auth_status, type: .transport.type, url: .transport.url, startup_timeout_sec}]'
```

`auth_status` names the scheme a server uses, such as `o_auth` or `unsupported`. Do not read
it as a login state. Keep `claude mcp get` and `claude mcp list` out of this procedure: both
start the servers they report on, and a bridge that is still waiting for its browser sign-in
keeps running after the command exits and holds that sign-in (step 5, "Clear leftover
bridges").

## Report the friction as you hit it

An install runs once per machine, driven by an agent that will never run it again, for a
person with no context. The *experience of the run* is itself a finding.

Invoke **/report-friction** yourself for each of these, mid-procedure, without asking and
without waiting for the run to end:

- a command in this file that failed, errored or is missing on this machine, with its exact
  output;
- a described path that **did not work**, with the error it produced;
- a working path this file does not have — the flag, the terminal wrapper, the order that
  turned out to matter;
- a path this file describes that worked, where the file hedges: a confirmation is evidence
  too;
- an instruction from the person that departs from this file, quoted, when it is what got the
  install done;
- anything that made you decide for yourself because this procedure did not cover the
  machine in front of you.

File it and carry straight on: one line naming the issue, then back to the step. Do not pause
the install for a friction report, and do not put it to the person as a question. Label it
`friction:install`.

## 1. The machine

```bash
uname -sm && sw_vers            # Linux: cat /etc/os-release
```

Darwin arm64 is `aarch64-apple-darwin`; Linux x86_64 is `x86_64-unknown-linux-gnu`. Another
platform: stop and report it.

Check each tool and its version before calling it: `git`, `gh`, `jq`, `node` (18 or newer),
`npx`, `python3`, `uv`, `claude`, `codex`. `uv` runs the `/review-pr` detector. Install or
upgrade the ones that are missing or too old,
keeping every working version in place. `gh` has to support `release verify` and
`release verify-asset`. On macOS use an
existing `brew`; on Linux install in user scope, and where a system package needs an
administrator, report the dependency and the step they run.

```bash
gh auth status
gh api repos/txehq/txe-workflow/releases/latest --jq .tag_name
gh extension list
```

- `gh auth status` shows no login: log in with `gh auth login`.
- The release query needs read access to the repository. An account that cannot read the
  release needs access from a repository administrator.
- `gh extension list` has no `gh-image`: add it with `gh extension install drogers0/gh-image`.

Both agents have to be logged in before step 4 runs them. `wf doctor` checks what `wf` put into
an agent, and says nothing about whether the agent can reach its own model:

```bash
codex login status                                  # exit 0: "Logged in using …"; exit 1: "Not logged in"
claude auth status | jq '{loggedIn, authMethod}'     # read loggedIn: the pipe's exit code is jq's
```

`codex login status` prints its line on stderr. `claude auth status` prints the account's email
too, which is why the `jq` keeps two fields. For an agent that is not logged in, ask the person
to run the login in their own terminal: `codex login` (on a machine with no browser,
`codex login --device-auth`, which prints a code to enter on another device) or
`claude auth login`. Carry on with the steps that do not run that agent. Its history check in
step 4 and its probes in step 5 wait for the login, and the report lists it as open. An agent
that is not logged in fails at its first request: `codex exec` exits 1 with
`401 Unauthorized: Missing bearer or basic authentication in header`.

`/research`, `/plan` and `/review-pr` hand their reviews to Codex, so prove a logged-in Codex
answers, with the model the release about to be installed gives `/review-pr` — the first line
that is not a comment of `skills/review-pr/references/codex-models.txt` at the release's tag.
Read the latest release's metadata once, here, keep it in `.install/release.json` and pin
`<tag>` from it; step 2 verifies and installs that same tag:

```bash
gh api "repos/txehq/txe-workflow/contents/skills/review-pr/references/codex-models.txt?ref=<tag>" -H "Accept: application/vnd.github.raw"
codex --version
codex exec -m <model> -s read-only -c approval_policy=never --ephemeral --skip-git-repo-check "Reply with one word: ready"
```

Keep the version and, on failure, the exact error for the report. Fix what the error names —
upgrade the CLI when it asks for a newer one (`brew upgrade --cask codex`, or the package manager
that installed it) — and probe again.

Then look at what this machine already has: `~/.local/bin/wf`, the older `~/.local/bin/lfg`,
and `wf agents` when `wf` is there. A 1.x install also shows `magi@capsohq` in
`claude plugin list` and `codex plugin list --json`; `wf install` retires that plugin, because
skills now reach every agent without it. Absent is the ordinary first-install answer,
and the `ls` that says so exits non-zero: read that as "nothing here yet". When `wf` is
present, run `wf status --json` and keep the whole result and its exit code — an unhealthy
status is something to repair, and `wf install` upgrades an existing install in place. Leave
existing `LINEAR_API_TOKEN`, `ENGAPP_*` and `CF_ACCESS_*` configuration as it is.

Note any ctx already here, because `wf install` manages it: `ls -la ~/.local/bin/ctx*`,
`command -v ctx`, and `ctx --version` when there is one. Absent is again the ordinary answer. A
ctx from upstream's hosted installer has a `ctx.install.json` beside it. A ctx before 1.0 has no
daemon and is replaced directly; a ctx whose daemon does not report a quiescent handoff stops the
install's ctx step at `CTX-HANDOFF`. A ctx elsewhere on
`PATH`, with none in `~/.local/bin`, stops it at `CTX-FOREIGN`. Either way the workflow install
goes ahead; tell the person early that ctx will need the step `wf doctor` names.

### Ask everything at once

Gather what only the person can answer, and put it to them in **one message**, so they answer
once and the rest runs without them:

- **The vault** — read the vaults Obsidian lists, with the command in step 3, "Where the vault
  is", and propose the one holding `Project Magi/`: is it the team's? With none holding it, ask
  them to open the team vault in Obsidian once, or, on a machine with no browser, for its path.
- **Spot** — do they use Rackspace Spot (step 3), unless `wf mcp survey` already shows it
  skipped?
- **A connection they already have** — each candidate `wf mcp survey` names (step 3).
- **The publishing credential** — when a value in `~/.config/engapp-artifacts/env` is missing,
  prepare the file as step 5, "Artifacts", says and ask them to fill it in.
- **Linear** — no question, a notice: unless they keep their own Linear on every agent, a
  Linear page will open in the browser, and they click Allow there.

A question stops the session until it is answered, so send the message at the first step that
needs an answer: in step 3, after `wf mcp survey` and before `wf mcp skip`, with step 2 and the
binary install done by then. Start the Linear sign-in as step 5, "Linear", says, as soon as the
answers are in. The later steps use these answers and ask nothing again. Codex's `/hooks` trust
exists only after `wf install`, so it goes in the report.

## 2. Download and verify the release

Use the release metadata step 1 kept, with its `<tag>`, and pin `<target>` from it.
Require `draft=false`, `prerelease=false`, `immutable=true`.

```bash
gh release verify <tag> -R txehq/txe-workflow
chmod 700 .install
gh release download <tag> -R txehq/txe-workflow -D .install --clobber \
  --pattern 'wf-<tag>-<target>.tar.gz' --pattern 'workflow.lock.json' --pattern 'workflow-<tag>.tar.gz'
gh release verify-asset <tag> .install/<file> -R txehq/txe-workflow    # each of the three
```

Check each file's SHA-256 against the digest in the release metadata. With `jq`, check that
`workflow.lock.json` carries `release_version` equal to `<tag>` without its `v`, and exactly
one `binaries` entry for `<target>`; that the binary archive and the workflow bundle match
their names and digests in the lock; and that the download sizes match the release metadata.

```bash
tar -tzvf .install/wf-<tag>-<target>.tar.gz
```

Expect one top-level regular file named `wf` — absolute paths, `..`, symlinks, hardlinks or
repeated paths mean stop. Unpack the binary into `.install/` once that holds. The workflow
bundle is expanded by `wf`'s own installer, which verifies it.

## 3. Install

```bash
mkdir -p ~/.local/bin
cp -p ~/.local/bin/wf ~/.local/bin/wf.bak-$(date +%Y%m%d%H%M%S)   # when one is already there
install -m755 .install/wf ~/.local/bin/wf.new && mv -f ~/.local/bin/wf.new ~/.local/bin/wf
command -v wf && wf --version
```

### Ask before installing a server the machine already reaches

Before `wf install` writes anything, ask `wf` what this machine already holds:

```bash
wf mcp survey --source github:txehq/txe-workflow --repo txehq/txe-workflow \
  --branch main --channel stable --agent all --json
```

`result.candidates` is one row per agent × server where installing ours would put a **second
connection to the same service** in front of the person — their own Linear server, one their
ADE ships, a connector on their account. `by` is `host` when the service is already reached
and `key` when only the name we would write is taken. `result.skipped` is what they have
already decided; never ask about those again.

For each candidate, ask the person in step 1's "Ask everything at once" message, and **name the
agent** — the decision is per agent, and
somebody may well want their own Linear in Claude Code and ours in Codex:

> Claude Code already reaches `mcp.linear.app`. Install the workflow's `capso-linear` there
> as well, or leave yours as the only one?

Record a "leave mine" answer before installing, so the install never writes it:

```bash
wf mcp skip <component> --agent <agent> --host <host> --reason "<their words>"
```

`<component>` and `<host>` come from the candidate row. Nothing about the connection that
prompted the question is passed, asked for, or written down — not its name, not its token
(WFR-016, WFR-018).

**Nobody to ask is not a decision.** On an unattended machine, or when the person does not
answer, install everything as usual: the install report carries an
`MCP-ALREADY-CONNECTED` warning naming only our own servers, and they can decide later. Never
record a skip on somebody's behalf.

### Ask whether they use Rackspace Spot

Spot is for people who run cloudspaces and VMs; most never call it, and an unsigned Spot bridge
opens its sign-in page at every new session. The question goes out in step 1's "Ask everything at once" message,
unless `result.skipped` already answers:

> Do you use Rackspace Spot? It needs a Spot account in the team's organization. If not, I'll
> leave it out, and nothing will ask you to sign in to it.

On "no", record it before installing; without `--agent` it covers every agent that keeps MCP
servers (OpenClaw keeps none):

```bash
wf mcp skip capso.mcp.rackspace-spot --host mcp.spot.rackspace.com --reason "<their words>"
```

`wf mcp unskip capso.mcp.rackspace-spot` brings it back later.

Then install:

```bash
wf install --source github:txehq/txe-workflow --repo txehq/txe-workflow \
  --branch main --channel stable --agent all
```

`--source` and `--repo` are explicit so an older install's remembered source or fork does not
carry over. Add `~/.local/bin` to `PATH` when `command -v wf` does not find it, backing up the
shell configuration first. Read the whole output, including its warnings and its "接下来"
list: the install copies the skills into every agent it finds, writes the managed prompt block,
the session-start and usage hooks and the MCP servers — `wf-history` among them — into each
agent's own configuration, retires a 1.x `magi@capsohq` plugin, and installs ctx.

ctx is a step of its own inside `wf install`: its output says which ctx version it installed, or
names a `CTX-*` code. A code there leaves the rest of the install in place. Carry on, and follow
the fix `wf doctor` names for it in step 4.

A download, an attestation check and `wf install` each go quiet while they work. Inside
`wf install`, ctx's first `setup` indexes every agent's history before the install returns. Let
the process finish and read its exit status. Do not start a second install while the first one
is still running.

If `latest` moved while this ran, re-check the release and assets of the version that was
actually installed.

### Where the vault is

Every document skill files into the team's Obsidian vault through `wf obsidian`, which finds it
through `$MAGI_VAULT`. Obsidian lists the vaults it has opened:

```bash
cfg="$HOME/Library/Application Support/obsidian/obsidian.json"
[ "$(uname -s)" = Linux ] && cfg="${XDG_CONFIG_HOME:-$HOME/.config}/obsidian/obsidian.json"
jq -r '.vaults[].path' "$cfg"
```

The team's vault is the one holding `Project Magi/`, which step 1's "Ask everything at once" message asked the person
to confirm; with none listed, that message asked them to open the team vault in Obsidian once,
so read the list again. A machine with no browser has no Obsidian to open: the message asks for
the vault's path instead, and the path counts once it holds `Project Magi/`. Back up the profile the login shell `$SHELL` reads (`~/.zshrc` for zsh,
`~/.bashrc` for bash), add `export MAGI_VAULT='<path>'` to it with the file editing tool — single
quotes, a `'` in the path written as `'\''`, so nothing in the path is expanded — and
prove a new shell of that kind prints that exact path; another login shell gets its own syntax in its own
profile (fish: `set -gx MAGI_VAULT '<path>'` in `~/.config/fish/config.fish`) and is proven
through itself:

```bash
zsh -ic 'wf obsidian --kind brief --product Magi --feature install-check --title Check --dry-run'   # bash -ic, fish -ic …
```

The printed path starts with the vault. A session started before the profile changed does not
see the variable, which is why the report's first line is to restart.

## 4. Verify the install

```bash
wf doctor --strict --json > .install/doctor.json; echo "exit=$?"
wf agents --json > .install/agents.json
wf hook session-start --agent claude
wf hook session-start --agent codex
```

Read the doctor result with these paths:

```bash
jq '{ok, errors, warnings, active_version: .result.status.active_version, healthy: .result.status.healthy}' .install/doctor.json
jq '.result.findings[]' .install/doctor.json            # {code, zh}; empty when nothing is wrong
jq '.result.status.agents[] | {agent, installed, current, total, effective_prompt_file, hook_trusted}' .install/doctor.json
jq '.result.status.components[] | {id, agent, kind, state, detail, skipped_at}' .install/doctor.json
jq '.result[] | {id, installed, managed}' .install/agents.json
```

`.errors[]` and `.warnings[]` are `{code, message}` notes; a strict run with any finding carries
the error `DOCTOR` and exits 1. Each agent row counts its objects: `current` equal to `total` is
an agent with everything in place. `.result.status.components[]` lists only the rows that are
not `current`, plus any server the person declined — `state` `current` with a `skipped_at`, the
day they said no — so an empty array beside `current` equal to
`total` is the complete answer. In that list, `credential_missing` means the capability is
waiting on a named credential, and `unverified` means it is installed and this binary did not
look at whether its browser login was ever completed. That is the normal state for both shipped
MCPs. Do not report it as a finding.

`wf agents --json` names each agent by `id` (`claude-code`, `codex`, …), where the doctor's rows
say `agent`. It must list every agent on this machine with `installed` and `managed` both true;
`managed` is `null` for an agent `wf` has never been installed into and `false` for one taken out
with `wf agents unregister`. Neither `claude plugin list` nor `codex plugin list --json` may
still show `magi@capsohq` — a skill loaded from both would load twice. Read the doctor's `effective_prompt_file` for each
agent that has one and confirm exactly one pair of `capso.global` `wf:managed` markers in each —
honouring `CLAUDE_CONFIG_DIR`, `CODEX_HOME` and a non-empty `AGENTS.override.md`.

Each manual `hook session-start` call returns JSON and adds a record to the journal:
`~/Library/Application Support/wf/state/journal.log` on macOS,
`${XDG_STATE_HOME:-~/.local/state}/wf/journal.log` on Linux, `state/journal.log` under
`WF_HOME` when that is set. Automatic dispatch is a separate observation: open a new session
in each agent and look for the new record. Report it as pending when that is not observed.

Codex binds hook trust to the exact definition. When `hook_trusted` is not yet true, ask the
person to run `/hooks` in Codex and trust the session-start hook that points at the installed
`wf`, then re-run the doctor.

Doctor success says the components are in place. Service logins and publishing are checked in
step 5.

### The history MCP, per agent

`wf install` writes the `wf-history` server into the MCP configuration of every managed agent
that has one. Check each installed agent on its own, in a **new** session of that agent: a session that started before the install has not
loaded the server. The new session that observes the automatic hook can make these calls too.
An agent passes when that session observes both levels:

- **Visible** — the agent has the server's tools. Claude Code lists them as
  `mcp__wf-history__status`, `mcp__wf-history__search` and the rest. How the other agents name
  them is not recorded here, so assert no tool name for them: one is visible when an observed
  call reaches the `wf-history` server's `status` tool.
- **Usable** — `status` reports at least one source, and `search` with query `wf install` and
  limit 1 returns a hit. The install you just ran is in this machine's history, so an empty
  result is a failure.

For Codex, a non-interactive run counts when its output shows the tool calls themselves:

```bash
codex exec "Call the status tool of the wf-history MCP server, then its search tool with query 'wf install' and limit 1. Report the number of sources and whether search returned a hit."
```

When the reply describes the server and shows no call, ask the person to send the same request
in a new interactive Codex session.

When a level fails:

- **Not visible** — run `wf agents status --json` and `wf doctor`, and check that
  `capso.mcp.history` is current on that agent. The server runs `wf` by its absolute path, so it
  starts the same way with any `PATH`. The finding that explains an absent server is a
  `conflict`: a server of the same name that `wf` did not write, which `wf` leaves alone.
- **Visible, and a call fails or finds nothing** — run `wf history doctor --format json` and
  `wf doctor`, and report their findings beside the failing call's output. `CTX-DAEMON` is
  repaired with `wf history index mode auto`; `CTX-SEMANTIC` with `wf install`.
- **`wf doctor` reports `capso.ctx.binary` with `CTX-HANDOFF` or `CTX-FOREIGN`** — follow the finding's text,
  then rerun `wf install` and this check. The handoff step moves the files aside and keeps them;
  a foreign ctx is removed with the tool that installed it (Homebrew, mise, cargo), after its own
  handoff.

`claude plugin list` may show `ctx-agent-history-search@ctx`, a plugin from ctx's own
distribution. Its skill uses flags that current ctx rejects — `--json`, `--include-subagents`,
`ctx sql` — so it steers a session wrong. Report it to the person with that reason, and do not
remove it.

## 5. The services

Probe from each agent separately: the server is installed per agent. The browser login behind
it is **per machine**: `mcp-remote` keeps its token under `~/.mcp-auth`, keyed by service URL,
so one completed page serves both.

- **Installed** — `wf doctor` lists the component. It says the definition is in place.
- **Login started** — a browser page opened. That is all it proves; a page can be opened and
  abandoned, and nothing on this machine records the difference.
- **Authenticated** — a tool call through `capso-linear` or `capso-rackspace-spot` returned
  data. Report this state: it settles whether the service works.

Make one probe per server, in a new session of the agent under test, and **probe the server by
its own name**: the person may have another server pointing at the same service.

| Server | Probe |
| --- | --- |
| `capso-linear` | `capso-linear.list_teams({limit: 1})` |
| `capso-rackspace-spot` | `capso-rackspace-spot.listOrganizations` |

Only a result from `capso-linear` or `capso-rackspace-spot` counts for these two. A server the
person declined — Spot in step 3, or our Linear on an agent where they kept their own — carries
`skipped_at`, is not installed there, and gets no probe.
`linear.list_teams` answering shows somebody else's connection working, and reporting it as
this one hides a dead bridge. That session also observes the automatic hook; keep its service
calls to those two.

In Codex, name the server in the request as a mention:

```bash
codex exec --json --skip-git-repo-check 'Call the list_teams tool of the [$capso-linear](mcp://capso-linear) MCP server with limit 1 and report how many teams it returned.'
codex exec --json --skip-git-repo-check 'Call the listOrganizations tool of the [$capso-rackspace-spot](mcp://capso-rackspace-spot) MCP server and report how many organizations it returned.'
```

Codex builds the first step's tool list from the servers that answered within one second of the
session starting (`mcp_optional_startup_grace_ms`, default 1000). The Spot bridge takes three to
five seconds to list its tools, so a request that does not mention it finds no Spot tool in
that step and is answered as though the server were missing. A mention makes Codex wait for that server,
up to its `startup_timeout_sec` (120 for both, written by `wf`). The `--json` output carries an
`mcp_tool_call` item with `server`, `tool` and `status: "completed"` for a call that returned.

When the person says a service is already connected, re-probe **`capso-linear` and
`capso-rackspace-spot`** before saying anything about them.

### Clear leftover bridges

Do this before any sign-in. A session that starts while a service is not signed in yet launches
its bridge, and the bridge sits waiting for the browser page it printed. When the session ends
— a `claude -p` that has answered, a `claude mcp get` that gave up after 30 seconds — the bridge
keeps running under the init process and holds the sign-in for its service. Every bridge started
after it, in the terminal or in any agent, waits on it with
`Another instance is running the sign-in for this server on port <port>` and prints no page.

```bash
wf doctor --json | jq -r '.result.findings[] | select(.code == "MCP-ORPHAN") | .zh'
```

Each `MCP-ORPHAN` finding names the server, its leftover processes and the `kill` command that
ends them. Run that command, then run the doctor again: no `MCP-ORPHAN` is left. The finding
covers only bridges an agent launched from the entries `wf` wrote — each carries
`WF_MCP_COMPONENT` in its environment — and only those whose agent has exited; a bridge that a
running session holds is that session's, and a bridge to the same service that `wf` did not
launch is the person's (WFR-016). When the doctor lists nothing and a bridge still reports
`Another instance is running the sign-in`, that other instance is theirs: tell them which
service it holds, and leave it to them.

### Sign in on a machine with no browser

A machine reached over SSH (`SSH_CONNECTION` is set), or a Linux machine with neither `DISPLAY`
nor `WAYLAND_DISPLAY`, has no browser the person can see. `mcp-remote` sends the browser back to
`http://localhost:<port>/oauth/callback` on the machine that runs the bridge, so the page the
person approves on their own computer ends at an address that does not load there. The bridge
is still waiting for that address on this machine, and it has to reach it without passing
through the conversation: the address carries the sign-in code, and a conversation and its tool
log are kept. The person routes it themselves, one of two ways below.

The port comes from the server URL: `3335 + (the first four hex digits of the MD5 of the URL)
mod 45816` — 22227 for `https://mcp.linear.app/mcp`, 45024 for
`https://mcp.spot.rackspace.com/mcp`. When an unrelated program holds that port, `mcp-remote`
tries the next seven. The bridge's log names the port it took.

After clearing leftover bridges, start one bridge per service that is not signed in yet:

```bash
nohup sh -c 'sleep 1800 | npx -y mcp-remote https://mcp.linear.app/mcp' > .install/login-linear.log 2>&1 &
echo $! > .install/login-linear.pid
nohup sh -c 'sleep 1800 | npx -y mcp-remote https://mcp.spot.rackspace.com/mcp' > .install/login-spot.log 2>&1 &
echo $! > .install/login-spot.pid
```

`sleep` holds the bridge's input open for 30 minutes; a bridge whose input closes exits. Within
a few seconds each log shows `This instance is running the sign-in for this server (callback
port <port>)` and, after `Please authorize this client by visiting:`, the page to open. A log
showing `Another instance is running the sign-in` means a leftover is still there: clear it and
start again.

Give the person each page to open — the authorization page itself carries no secret — and one
of these, with the ports the logs named. Never ask them to paste the address the page ends at
back into the conversation.

- **Reached over SSH** — before they approve the page, they forward the callback ports from
  their own computer, in a terminal of their own, and keep it open until both logs show the
  sign-in:

  ```bash
  ssh -N -L 22227:localhost:22227 -L 45024:localhost:45024 <this host>
  ```

  Their browser's redirect to `localhost:<port>` then arrives at the waiting bridge directly.
- **No SSH from their computer** (a web console, a remote desktop into another machine) — after
  approving, they copy the whole address of the page that fails to load, every parameter
  included (Linear adds `iss`, and the bridge refuses a callback without it), and deliver it on
  this machine in a terminal of their own. `read` keeps it off the command line and out of the
  shell history:

  ```bash
  read -r -p 'callback address: ' url && printf 'url = "%s"\n' "$url" | curl -sS -o /dev/null -w '%{http_code}\n' --config -
  ```

  Expect `200`.

Either way, read the logs, never the address: each shows `Auth code received` followed by
`Proxy established successfully`, and an `Authorization error` line instead names what the
service refused. The code is used once, and only by the waiting bridge, which holds the
matching verifier. The token is now under `~/.mcp-auth` for every agent on the machine. The
bridge stops by itself when `sleep` ends. To stop it sooner, end its `sleep`, which closes the
bridge's input; the log then ends with `Shutting down...` and none of its processes is left:

```bash
pkill -P "$(cat .install/login-linear.pid)" -x sleep
pkill -P "$(cat .install/login-spot.pid)" -x sleep
```

Then probe each server from a new session of each agent.

### Linear

`wf install` ships the server as `capso-linear`, bridged with `mcp-remote`, so every agent the
person did not keep their own Linear on carries it after step 3. It logs in through the browser
on first use, with no token. When they kept their own on every agent, skip this section and the
notice in step 1.

Start that sign-in yourself, right after step 1's "Ask everything at once" message has told the person a Linear page
will open in the browser and to click Allow there. After clearing leftover bridges (on a machine
that already has `wf`), start the Linear bridge in the background
with the `nohup` line in "Sign in on a machine with no browser"; it opens the page itself. Open
the page from its log (`open <page>`; `xdg-open` on Linux) only when none appeared. The log's
`Proxy established successfully` is the sign-in done. On a machine with no browser, route the
callback as that section says.

A bridge that will not connect is a finding: run step 5's `capso-linear` probe, the one in that
server's own namespace, and report what it returned.

If it will not connect, reproduce it outside the agent — this is the exact command every agent
runs, and its error is the one to put in the report:

```bash
npx -y mcp-remote https://mcp.linear.app/mcp
```

**The only Linear server this install is accountable for is `capso-linear`** (WFR-016). A
`linear` server the person added themselves, a `claude.ai Linear` connector on their account,
an entry reading `Needs authentication` — do not add one, do not log into one, do not repair or
replace one, and do not report on its state. If one is in the way, say what you saw in one line
and let them decide.

Report every connection failure with what its probe returned. An explanation attached to a
failure nobody has diagnosed turns a visible error into a known-benign one, and nobody looks
again. If you have a theory, mark it as one.

### Rackspace Spot

Skip this section when the person declined Spot in step 3.

`wf install` ships the server as `capso-rackspace-spot`, bridged with `mcp-remote`, so every
managed agent with an MCP configuration carries it after step 3. Spot authenticates through OAuth in the browser on the first
tool call. Sign in the way Linear does above, with the Spot bridge, then confirm with a
read-only call such as listing organizations.

A connection the person holds to the same host is theirs: do not add it, log into it or report
on it.

Authenticate once in a terminal (on a machine with no browser, through "Sign in on a machine
with no browser" above): the client then reuses the cached token. This is also
Rackspace's workaround for GUI clients that launch `mcp-remote` twice and take down the callback
listener before the redirect lands:

```bash
npx -y mcp-remote https://mcp.spot.rackspace.com/mcp
```

That bridge prints two messages in normal operation: `mcp-remote` warns that the SDK's
`saveDiscoveryState()` / `discoveryState()` are not implemented and that the credential has no
issuer stamp, and an idle connection ends with `SSE stream disconnected: TypeError:
terminated`. The probe returning organizations settles authentication, and the calls that
returned before a disconnect stand.

Spot's own prerequisites are the person's: a Spot account, an organization to hold
cloudspaces and VMs, and a payment method on file before the first bid.
Source: [Rackspace Spot MCP](https://spot.rackspace.com/docs/en/modelcontextprotocol).

### Artifacts

Publishing reads `~/.config/engapp-artifacts/env` — mode 600, or wherever
`ENGAPP_ARTIFACTS_CRED` points — with three lines:

```text
ENGAPP_ARTIFACTS_BASE=https://engapp.dev/artifacts
CF_ACCESS_CLIENT_ID=...
CF_ACCESS_CLIENT_SECRET=...
```

`wf` reads these values from that file and ignores shell exports of them. Keep existing
values; the publish below is the check. Name a missing or empty value by its key only, and never
print the file:

```bash
for k in ENGAPP_ARTIFACTS_BASE CF_ACCESS_CLIENT_ID CF_ACCESS_CLIENT_SECRET; do
  grep -q "^$k=." ~/.config/engapp-artifacts/env || echo "$k"
done
```

When a value is missing, the person asks a Capso Cloudflare administrator for a Session Artifacts
Access service token. A file that is absent is created with the file editing tool — the base
line filled in, the two values empty — and `chmod 600`; a file that exists is never recreated.
Either way, in step 1's "Ask everything at once" message ask the person to
open it in an editor (`open -e ~/.config/engapp-artifacts/env` on macOS), fill in the empty
values, save, and say so. The values stay in their editor, never in the conversation. Since 1.5.1 no upload
token is involved; a CLI still asking for `ENGAPP_UPLOAD_TOKEN` is an old one, so upgrade it.

Then prove the path with a throwaway HTML page: write `.install/fixture.html` with the file
editing tool, then run:

```bash
wf publish-artifact .install/fixture.html --title "Workflow installation check" --dry-run
wf publish-artifact .install/fixture.html --title "Workflow installation check"
```

The dry run rehearses the file, type, arguments and metadata. The real publish reads the page
back with the Access headers before it hands out the URL, so a successful publish is the
servability check. The page sits behind Cloudflare Access, which answers a request without
those headers with a redirect to the login.

When `wf publish-artifact` fails with a `PUBLISH-PROXY-*` class, stop the artifact check and
report the error with the proxy variable and URL it names; `/publish-artifacts` §Behind a proxy
says what each class means and which variable to change.

To confirm the bytes, load the credential file with the shell and pass the headers to `curl` on
stdin; `printf` is a shell builtin, so the values never reach a process argument list:

```bash
. ~/.config/engapp-artifacts/env && printf 'header = "CF-Access-Client-Id: %s"\nheader = "CF-Access-Client-Secret: %s"\n' "$CF_ACCESS_CLIENT_ID" "$CF_ACCESS_CLIENT_SECRET" | curl -sS -L -o .install/fetched.html -w '%{http_code}\n' --config - "<url>"
```

Expect `200` and a file matching the fixture. A 302 means the headers did not arrive, and a
403 means they arrived and were not accepted. Make this check with `curl`.

## 6. Report

Two reports. The full one goes to `.install/report.md`, written from what the commands returned:

1. **Install and verification** — the version, the doctor result, the managed agents, the Codex
   probe, the vault path, and one `history MCP: visible / usable` line per installed agent, from
   what step 4 observed. Say the workflow is installed once the checks in step 4 have passed.
2. **What this machine now has** — the skills, read from `skills/*/SKILL.md` frontmatter in the
   active generation's bundle (`active/bundle/` under `wf`'s state directory), which is what each
   agent's skills directory carries, and the `wf` commands from `wf --help` (plus
   `gh image --help`). Report an empty match as a failure: say the glob found nothing.
3. **What is not finished** — each on its own line with the one thing that moves it: a login
   or trust prompt still owed, an automatic dispatch not yet observed, a check stopped by an
   error together with that error's text, a warning that is still printed, a root cause that
   stayed unknown, and any step of this procedure that was done differently. An observation made
   along the way stays on this list after a green `wf doctor`.

Every line on that list that names a defect in *this procedure* carries its issue number from
**/report-friction**. File any that has none before you write the report: the end of the run is
the last moment the exact error text still exists anywhere.

Then end the run with a short report in the chat, in Chinese, for a person who has never used
the workflow: plain words, no finding codes, nothing about releases or ctx. In this shape:

```markdown
**安装情况**
- 工作流 <版本>：已装进 <wf agents 里 installed 和 managed 都为 true 的每个 agent>
- Linear：已登录 / 还没登录 / 连不上（<探测返回的原话>）/ 没有安装（你选了用自己的连接）；各个 agent 不同时，按 agent 分别写
- Rackspace Spot：已登录 / 还没登录 / 连不上（<探测返回的原话>）/ 没有安装（你选了不用）
- Obsidian vault：<路径>
- 发布网页：已验证 / 还差凭据 / 发布失败（<报错的原话>）

**你现在要做的事**
1. 退出 Claude Code，新开一个终端，进入项目的 GitHub 仓库目录，再运行 `claude`。新会话才会加载刚装好的技能和 vault 设置。
2. <还没完成的事，每条写清在哪里做、做什么、做完是什么样子>
完整的安装记录在 `<.install/report.md 的完整路径>`。

**怎么用**
- `/lfg <一个想法>`：先问清需求和边界，再调研、写计划，然后在 Linear 上建好工单，派发前停下来问你。例：`/lfg 给模型列表页加按供应商筛选`
- `/ic <工单号>`：领一张工单，实现、测试、截图验收、开 PR，再处理审查意见和 CI，直到可以请人 review。例：`/ic TXE-1234`
- 需求文档存在 vault 的 `Project <产品>/Features/<名字>/`，代码在项目仓库里。
```

The first item of the second part is always the restart. After it, list only what the person
has to do before `/lfg` and `/ic` work; a check that would only confirm something already working
stays in the full report, and so do the friction reports, which are for the people who maintain
this procedure.
