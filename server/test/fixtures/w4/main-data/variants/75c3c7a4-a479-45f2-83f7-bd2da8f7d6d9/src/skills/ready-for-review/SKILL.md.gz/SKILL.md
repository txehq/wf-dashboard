---
name: ready-for-review
description: "The last step of /ic — the gate that turns a draft PR into one a human should look at: verify on the current head that every review thread is resolved, every CI check is green, and the ticket's requirements checklist is fully ticked; then, and only then, mark the PR ready with gh pr ready, move the Linear ticket to the team's review state, and comment with the PR URL, the acceptance report and the deferred findings' tickets. Use when someone says \"mark it ready\", \"ready for review\"; invoke it proactively, saying so in one line, when /fix-pr has gone quiet on a draft PR. Never merges. If any condition fails, it names the one that did and stops."
---

# /ready-for-review — three conditions, then two writes

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/IC Session.md` (WF-IC — the
corpus has no separate node for this step), with the *PR* and *Auto Merge* rows of
`Project Magi/Workflow/System Design.md` §2. Where this file and the spec disagree, the spec
wins: update this file to match it. **Question bank:** Phase 6 (R3, R4) of
[`skills/interview/references/question-bank.md`](../interview/references/question-bank.md).

## Contract — what goes in, what comes out

| | |
|---|---|
| **In** | the draft PR, after `/fix-pr` returned `quiet`; the ticket with its `<!-- ic:checklist -->` comment |
| **Out** | the PR marked ready for review; the ticket in the team's review state with a comment carrying the PR URL, the acceptance report URL and one line per deferred finding's ticket — or a stop naming the failed condition |
| **Next** | Auto Merge, or the human who owns the repository. Not this skill. |

## When this skill starts

- **On request:** `/ready-for-review`, "mark it ready", "ready for review".
- **From `/ic`:** as the last step, when `/fix-pr` reports quiet.
- **Proactively:** `/fix-pr` has gone quiet on a draft PR — the latest review has no
  Critical or High finding, every thread has a disposition, the checks are green. Say
  "running /ready-for-review" and begin.
- **Not** while a review round is in flight or a fix push is unpushed.

## 1. Three conditions, on the current head

The review-thread query ships with this skill as `unresolved-threads.graphql`;
`<this skill's directory>` below is the directory this `SKILL.md` was loaded from.

```bash
head=$(gh pr view <n> --json headRefOid -q .headRefOid)

# 1 — every review thread resolved: prints one line per unresolved thread
gh api graphql --paginate -F "query=@<this skill's directory>/unresolved-threads.graphql" \
  -f o=<owner> -f r=<repo> -F n=<n> \
  --jq '.data.repository.pullRequest.reviewThreads.nodes[] | select(.isResolved|not) | "\(.path):\(.line) \(.id)"'

# 2 — every check green on this head
gh pr checks <n> --json name,bucket,state --jq '[.[] | select(.bucket!="pass")] | length'

# 3 — the checklist fully ticked, stamped with this head
# read the ticket's `<!-- ic:checklist head=… -->` comment through the Linear MCP:
#   no "- [ ]" lines remain, and head= equals $head
```

| condition | passes when |
|---|---|
| **threads** | the thread query prints nothing; each resolution was a fix, a stated false-positive reason, or a follow-up ticket — a thread resolved without one of those is reopened |
| **checks** | zero checks outside `pass` for the current head; a `skipping` check counts only if the repository's contract says it may |
| **checklist** | every line ticked with its file and test; the comment's `head=` equals the PR's current head |

Also: the latest review has **no Critical or High finding** — the loop's exit condition — and
every commit after the head it reviewed names one of its findings; and the PR body's *Open
items* section lists every deferred finding with its ticket. A body that says less than the
threads do is fixed before marking: edit `.open-pr/body.md` and run
`gh pr edit <n> --body-file .open-pr/body.md`.

**Any condition failing is a stop.** Say which, with the command output, and hand back to the
step that owns it: an unresolved thread, a red check or a stale `head=` to `/fix-pr`, an
unticked line to `/implement`. Do not mark. Do not ask the user to override a red check. A PR
marked ready with a red check or an open thread spends a reviewer's time finding what a
command would have found.

## 2. Two writes, in this order

```bash
gh pr ready <n>
```

Then Linear, through the MCP: move the ticket to the team's **review state** — the workflow
state named `Ready for Review` or `In Review`, whichever the team defines (read the states;
do not invent one) — and comment:

```
Ready for review · PR <url> · head <sha>
Acceptance: <report URL>
Deferred: TXE-<m> <one line> · TXE-<k> <one line>
```

Moving to the review state is inside the IC's ceiling. **Closing the ticket is outside it**:
the PR's `Closes` trailer closes it at merge, and Auto Merge or the repository's owner decides
the merge (the bank's R4: a ticket-state change beyond what the workflow already authorized is
asked for). Where the team has no review state, comment naming the missing state. Do not pick
a plausible substitute.

## 3. Report, and stop

One line to the caller: the PR URL, ready; the ticket, in review; anything deferred. Then
stop. Nothing here merges, and nothing here waits for the merge; Auto Merge is the
repository's gate.

Do not ask the bank's R3 ("do you accept the feature as complete?"). The human review the PR
now enters answers it; in solo mode, that review is the LFG's own.

## Not this

- Fixing review findings or red checks → `/fix-pr`.
- Opening the PR → `/open-pr`. Leaving the work → `/handover`.
