---
name: research
description: "Stage 2 of /lfg and stage 3 of the spine by default — turn a brief into a spec and plan grounded in evidence. Local research fans out three explorer agents over the codebase with three lenses (what can be reused, what the requirement must cover, where the gaps are); web research is either targeted lookups you do yourself or a Deep Research prompt assembled into a ChatGPT link the user clicks, whose markdown result you read in full. Every recommendation carries its source. Use after /interview produced a brief, when someone asks \"how do others do this\", \"what library should we use\", \"research this before we build\", or when a plan needs its choices justified; invoke it proactively, saying so in one line, when a brief exists and nobody has looked before planning. When there is no reference to find and the ambiguity or blast radius is high, the tier call runs it at design-corpus scale."
---

# /research — find the precedent, then plan on it

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Research/Research.md` (WF-RES),
bound by `Project Magi/Workflow/Decisions/Planning Corpus Standard.md` for the output layout
and the convergence process.

## Contract — what goes in, what comes out

| | |
|---|---|
| **In** | the brief at `Project <Product>/Features/<slug>/Brief.md`; the repository checkout |
| **Out** | `Project <Product>/Features/<slug>/Research.md`, filed by `wf obsidian`: findings, referenced recommendations, a spec split into parts, a plan with per-part test plan and acceptance criteria, open decisions, risks |
| **Next** | `/plan` takes the plan section to a locked plan; `/ticketing` then selects tickets from its parts |

`.research/` is this skill's working directory: create it with a `.gitignore` containing `*`
before writing its first file.

## When this skill starts

- **On request:** `/research`, or "how do others do this", "what library should we use",
  "research this before we build", "justify the plan".
- **From `/lfg`:** as stage 2, with the brief's path.
- **Proactively:** a brief exists and planning is about to start without anyone having
  looked. Say "running /research" and begin.
- **Not** without a brief → `/interview` first; inferring one here is how scope drifts.

## 0. The tier call — make it first, write it down

`/research` assumes the answers exist somewhere and the job is to find and apply them. Check
that against three signals: **no reference** to pattern-match; **high ambiguity** lookup
cannot close; **a high blast radius**. All three, or the first plus either other, means the
call is deep: say so at the top of the output, run this skill at design-corpus scale
(narrative with a decision log, `Decisions/`, `Specs/`, an ambiguity register, a risk
register), take the breadth from the Deep Research handoff in §3b, and mark the result as
produced without a multi-agent adversarial fan-out.

## 1. Read the brief

Its *open questions* are your first work list; its *boundaries* say what the plan must not
touch; its *authority ceiling* bounds what the plan may commit a session to; its *verified
current behaviour* is the starting point the explorers extend.

## 2. Local research — three explorers, three lenses

The codebase is read by **three explorer sub-agents in parallel** (Claude Code's `Explore`
agent or the equivalent), each given the brief, the repository root, and exactly one lens.
The fan-out requires a harness with sub-agents; without one, stop the run with that error. The
explorers are read-only. Each returns a written digest in which every claim carries a path —
and a line or symbol — or the command that showed it.

| lens | the explorer answers |
|---|---|
| **Reuse** | What already exists that this work can build on: implementations of the adjacent thing, abstractions, utilities, patterns, test fixtures, infrastructure, configuration. How each is used today, and what would break if it changed. |
| **Coverage** | What the requirement has to touch to be complete: every entry point, surface, state, data path, permission check and consumer the brief's done-means implies — and the adjacent behaviour the brief's boundaries say must not change, mapped to the code that implements it. |
| **Gaps** | What is missing or in the way: capabilities absent, mismatches between the brief and what the code assumes, tests or infrastructure that do not exist, debt that blocks the straightforward path, conventions the change would have to follow or break. |

While they run, the lead reads what explorers cannot: `/history` for earlier attempts on
this machine, the corpus (`Project <Product>/Decisions/`, `Specs/`) for decisions that bind,
and Linear — including the synced `Linear Issues/` folder — for tickets in the area, their
estimates and how they ended. Then merge: where two digests disagree, read the code yourself
and keep what it shows. A recommendation that contradicts a settled decision in the corpus is
a proposal to change the decision, and says so.

## 3. Web research — two kinds

### 3a. Targeted lookups, done by you

Targeted questions with a findable answer: what a library's current API is, which version
fixed the bug, what the official recommendation says, what the changelog changed. Primary
sources first — the documentation, the RFC, the release notes — then reputable secondary
ones. Note the version and the date read; references age.

### 3b. Deep research, handed to the user as a link

For the open questions that need breadth — current best practice, how others solved this,
which framework and why, what the community has learned — assemble a Deep Research prompt
and give it to the user as **one clickable link**. They run it in ChatGPT, and bring the
result back to you.

**The prompt** is written in the user's language and contains, in this order:

1. **The intent** — what we are building and for whom, from the brief, in two or three
   sentences.
2. **The project's constraints** — the existing stack, the features and dependencies already
   in place, the conventions that bind; and, flagged as such, the parts that *may* be
   refactored, optimized or iterated within this task.
3. **The questions** — the open questions from the brief and the gaps from §2, as a list.
4. **How to research** — open the aperture: the latest information, the most official and
   reliable documentation *and* broad community practice; search as widely as possible, in
   several languages, then compare what was found before concluding.
5. **What to return** — one complete markdown document: findings per question with their
   sources, a comparison of the viable options with trade-offs, a recommendation with the
   reasoning, and everything that contradicts itself across sources called out.

Write the prompt to `.research/deep-research-prompt.md`.

**The link** URL-encodes that prompt into ChatGPT's Deep Research entry: `hints=research`
opens the Deep Research interface and `model=gpt-6-pro` selects GPT-6 Pro.

```bash
jq -sRr '@uri "https://chatgpt.com/?model=gpt-6-pro&hints=research&prompt=\(.)"' .research/deep-research-prompt.md
```

Present it as a markdown link the user can click; the link is the one route to Deep Research.

Then **wait for the user** to hand the result back — a file path or the pasted markdown.
This is a legitimate wait: the user is the bridge to a tool this session cannot drive.

**Read the whole result.** Never skim, never summarize from the first screen. When it is
long — more than a few hundred lines — hand it to one reader sub-agent whose only job is to
read every line and return: the findings per question, every reference with its URL, the
recommendations, the disagreements between sources, and anything that contradicts what §2
found locally. Fold that digest into §5 with the references intact.

## 4. Every recommendation carries its reference

A file path with a line or symbol for a local fact; a URL with version and date read for an
external one. An unreferenced recommendation is an opinion, and the document says so when
one is unavoidable.

## 5. The output — `Research.md`

Write its sections in this order:

1. **Context** — one paragraph, and a link to the brief.
2. **The tier call** — and why.
3. **Local findings** — three sections, one per lens: *reuse*, *coverage*, *gaps*, each
   with its evidence.
4. **Web findings** — the targeted lookups, and the Deep Research digest with its references.
5. **Recommendations** — the framework chosen and why; the practices followed and where
   they are documented; the dependencies chosen and why; what to reuse and what to build.
6. **Spec** — the complete story and the goals it must meet, functional and non-functional;
   then what will be built, part by part, each part with one observable outcome, each naming
   what it reuses from §3.
7. **Plan** — order, dependencies between parts, and per part a **test plan and acceptance
   criteria**, every criterion naming its verification method (test / visual comparison /
   measurement). This is what ticketing selects from.
8. **Open decisions** — questions the evidence could not close, each with options and a
   recommendation, filed through `/decide`.
9. **Risks** — what could invalidate the plan, and the probe that tests each one.

## 6. Converge before you publish

The plan converges through review passes:

1. **Draft** from the brief and the findings.
2. **Q&A** with the user — fold input in as it arrives; use `/decide` when several questions
   are pending with real options.
3. **Adversarial review by a different model than the author.** Hand the draft and the brief
   to Codex with `codex exec -s read-only` and ask for findings; **triage them**.
4. **Converge** — fold accepted findings; repeat 2–3 until neither the user nor a review pass
   produces changes.
5. **Lock** — mark the document locked with the date; later changes are dated entries.

## 7. The tail — publish, file in the vault, comment on Linear

Write the document to `.research/research.md` and file it:

```bash
wf obsidian --kind research --product "<Product>" --feature "<slug>" --file .research/research.md \
  --title "<feature> — research" --ticket <epic or ticket id> --url <published URL>
```

Publish through `/publish-artifacts` when an HTML rendering exists — `/explainer` when the
plan has shape worth a page. The markdown goes to the vault in every case, and the vault copy
is the durable record; Linear gets one comment on the epic with the vault path and the URL.
Echo the vault path; it is what `/plan` reads next.

## Not this

- Turning an intent into a brief → `/interview`.
- Two or more open decisions with enumerable options, nothing to look up → `/decide`.
- A visual page for something already understood → `/explainer`.
