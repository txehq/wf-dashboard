# Follow-up admission — when a finding earns a Linear ticket, and what the ticket must carry

**The one home for this rule.** `/review-pr` §5a files a ticket for a pre-existing finding
through this procedure. **Do not restate any of it in a skill file.**

Owner: TXE-1337. Design and measurements: Obsidian, `TXE/DevOps/Workflow Improvement/Connor Wang/
August 20, 2026 — Proposal, Follow-up Ticket Admission (cc2-txe_improve-workflow-5c5dc0)`.

---

## Why there is a bar at all

Nothing in the system removes a ticket except doing the work, so the bar is what bounds the
queue. In the measured window (the design note above), review-discovered follow-ups were
roughly 85% of net backlog growth in Linear team TXE, and tickets filed with no priority had
the lowest close rate of any bucket.

---

## Step 1 — the ladder, in order. Only the last rung files.

1. **Leave it in the review** when it belongs to the current ticket's contracted change: the PR
   author fixes it, and nothing files. An unrelated pre-existing defect is never folded into this
   PR; that breaks one-ticket-one-merge.
2. **Search.** Query the Linear MCP's `list_issues` on the finding's subject. If it is already
   tracked, file nothing and name that issue in the completion report. A duplicate makes the
   label's count meaningless.
3. **Consolidate.** Combine related findings **only** when they describe one coherent future
   remediation, i.e. one future merge. Do not batch unrelated findings merely to reduce ticket count.
4. **Admit** — only if it clears the exposure gate below.

---

## Step 2 — the exposure gate

> **Admit the finding only if, in the system as it exists now, you can name a reachable input or
> event, trace it to a concrete wrong outcome or failed control, and name the user, operator, data,
> money, or invariant that bears the consequence — without inventing a future producer,
> configuration, or use case.**

The gate admits real latent failures: an alert whose qualifying event can occur and reaches
nobody; a guard that accepts reachable invalid input; a billing path that can mischarge. It
rejects speculative extensibility ("this abstraction permits X" where nothing produces X),
drifted comments, missing headers, and style.

**The gate decides whether a finding files, and severity orders the admitted work.** A Codex
`Low` that clears the gate files. A Codex `Medium` that fails it does not. The exposure gate is
the whole admission control.

---

## Step 3 — priority is mandatory

**`No priority` is never filed.** If you cannot choose Urgent / High / Medium / Low, that is a
**failed admission** — the finding does not get a ticket.

---

## Step 4 — the ticket body

Five fields and an optional sixth. **The procedure constructs the first two.**

```
Source:            PR #<N> · <direct URL to the review comment carrying the finding>
Observed evidence: <immutable permalink(s), see below>
Still applies if:  <one falsifiable condition>
To decide:         <the symbol, test, query, or external evidence to inspect>
Priority:          Urgent | High | Medium | Low
Check:             <optional — a read-only command with a clear expected result>
```

Then the finding verbatim, and the existing `**Deliverable consumer:**` line that routes the
workstream label.

### `Observed evidence` — for a code finding

An immutable GitHub blob permalink:

```
https://github.com/<owner>/<repo>/blob/<40-char-sha>/<path>#L<start>-L<end>
```

It carries the revision, the path, the line range **and the exact text as it read** in one
clickable artifact, and survives rebase and squash. Construct it; do not ask the agent for it.

⚠️ **Do NOT record a bare `anchor: <sha>` or a hand-maintained `paths:` list.** Both duplicate what
the permalink already contains and add a copying opportunity without adding evidence.

⚠️ **Pick the SHA of the tree the finding is about.** For a finding in the diff under review, that
is the reviewed head. For a **pre-existing** finding, use the base branch's commit, where the
defect lives: `ops/merge-pr.sh` rebases by default, so the reviewed head commit is absent from
`main` after the merge.

The procedure constructs the permalink because a prose requirement on the filer does not hold
under load.

### `Observed evidence` — for a finding about a running system

No blob to link. Capture a dated, self-contained capsule:

```
observed-at:  <ISO-8601 with offset>
environment:  <cluster / namespace>
identity:     <kind>/<name>, uid=<uid>, resourceVersion=<rv>, generation=<n>
query:        <the exact read-only command or API query>
result:       <sanitised relevant output>
```

The UID identifies the object; the **captured result** is what lets a future reader re-run the
query and compare. Never include credentials or secret values.

### `Still applies if` — required. `Check:` — optional.

`Still applies if` is a falsifiable condition in prose. **If you cannot state one, the finding is
not resumable enough to earn a ticket** — that is the quality gate, and it keeps out both `N/A`
and fake predicates.

Add `Check:` **only** when a real, already-existing, read-only command has a clear expected result.
Roughly a quarter of findings qualify; the rest are design judgements, ownership questions, or
operational claims needing interpretation.

⚠️ **Never make a runnable command mandatory.** A mandatory command degrades into a brittle
`grep` that matches today for reasons unrelated to the claim, and a scheduled job may act on
`Check:`, so a fake predicate misleads it.

Worked example, for the shape:

```
Still applies if: the verifier can accept a same-name CronJob owned by a different controller.
To decide:        inspect the unmanaged-exemption path at the permalink above; disproved only by
                  an ownership check or a regression test covering the wrong-owner case.
```

### Filing call

The Linear MCP's `save_issue`:

```
save_issue(
  team:    "TXE",
  title:   "[CC<n>-<ws>] <the defect, stated as what is actually wrong>",
  project: "<DevOps | TokenFeeds | Tokun | TXE>",
  state:   "Backlog",
  priority: <1|2|3|4>,                              // never 0
  labels:  ["cc<n>", "<workstream>", "found-in-review", "Bug"],
  description: "<the five-field block, then the finding verbatim>"
)
```

`found-in-review` is mandatory for a review-discovered finding; use `found-in-work` when the
finding came out of implementation, investigation, an incident or an audit. Add `Bug` only when the
finding really is a defect — without it the ticket reads as scope the spec missed, and that pairing
is what makes discovered-vs-planned work countable.

---

## Step 5 — a finding that does not clear the bar

It gets no ticket. ⚠️ **Do not create a rolling per-subsystem ticket, a checked-in ledger, or any
other durable home for it.** Each would be a shadow backlog with worse ownership and worse
retrieval than Linear. The completion report names every finding that was not filed. If a later
change supplies the missing reachability link, that new state earns a fresh finding on its own
merits.

---

## Citing the ticket afterwards

Cite the id **bare, with no verb in front of it** — `TXE-1325`, never `Refs TXE-1325`. A linking
keyword drags a completed issue back to In Progress and nulls its `completedAt`. See
`docs/workflow/CONTRACT.md` §"Citing a ticket you are not closing" in the txe repo, which is the
normative home.
