# CLI / backend surface

The default surface for backend, CLI, library, and data-logic changes. The proof
is the command's own text output — a passing assertion or a correct JSON result —
and it runs anywhere, with no browser and no display.

Use this surface when your change is verifiable by running something and reading
what it prints. Return to the surface router only when the criterion is actually
about rendered UI.

## How to verify

1. Run the command, test, or query that exercises the change. Use a machine output
   mode (`--json`, a structured dump) so the proof is assertable.
2. Capture the output as `text` evidence in the round. Keep both the exact
   execution record and a separate explanation of what it proves.

```bash
your-cli command --json > "$REPORT_DIR/assets/result.json"
```

Record the actual command, exit status, and observed output, then reference the
file from the matching `cases[].evidence` with `type: "text"`. Suite output is
a shipping precondition and goes into the one-line verification narrative. Publish
the complete report using [report.md](../references/report.md).

Provenance: `cli` for command stdout, `program` for a deterministic probe. See
[../references/evidence.md](../references/evidence.md) for the evidence contract.

## Auth

Publishing uses the credentials described in
[dependencies.md](../references/dependencies.md). The product CLI under test
carries its own auth (API key or stored login) - configure it before
capturing its output, and verify the credential belongs to the intended test
environment.

## Boundaries

- **Don't open a browser for a backend change.** When output satisfies the
  criterion, a screenshot adds noise.
- **Make the assertion legible.** Upload the specific lines/fields that prove the
  criterion, and describe them in the report.
- **Never upload secrets.** Strip tokens/keys from output before uploading — see
  [../references/evidence.md](../references/evidence.md#artifact-safety).
