// 在操作功能之前安装 console.error interceptor，错误文本收集到 window.__ERRORS__
(function () {
  window.__ERRORS__ = [];
  const original = console.error;
  console.error = function (...values) {
    window.__ERRORS__.push(values.map(String).join(' '));
    original.apply(console, values);
  };
  return 'installed';
})();
