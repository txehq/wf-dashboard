---
name: ci-optimise
description: "Create, optimise or modify CI pipelines with developer waiting time as the primary performance objective. Invoke automatically before CI workflow, job dependency, runner, cache, setup or test-sharding edits, including review fixes. Find the critical path, move nonessential work off merge gates, preserve required verification, and measure the result. Also use on explicit /ci-optimise requests."
---

# /ci-optimise

Read this skill before creating or changing a CI pipeline, including direct requests and
changes made through `/implement` or `/fix-pr`. Apply it within the requested scope.
Ordinary application fixes discovered by CI only trigger it when they change the pipeline.

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/CI Optimise.md` (WF-CIO).
Where this file and the spec disagree, the spec wins: update this file to match it.

## Transferable observations

[Linear's CI article](https://linear.app/now/ci-bottleneck-reworked), Mufeez Amjad,
21 September 2026, reports these reusable techniques:

- Measure PR waiting time and machine consumption separately.
- Examine small prerequisite jobs; trim checkout and history to their actual needs.
- Move cache bookkeeping outside the merge gate.
- Reduce repeated setup with prepared images, scoped dependency installation and schema snapshots.
- Compare cache transfer cost with rebuilding; combine short checks that share setup.
- Balance test partitions using the runner's scheduling unit, and reduce setup before adding shards.
- Benchmark hardware and toolchains. Syntax-only lint can avoid type-analysis cost where semantics permit.
- Sharing test module state requires explicit eligibility, cleanup and isolation checks.
- Bound network stalls and investigate their cause.

These are workload-dependent observations. The procedure below is wf's operational guidance
for applying them; article results are evidence for investigation, never promised speedups.

## Establish what the developer waits for

Read the affected workflow definitions, invoked scripts, reusable workflows and current
required-check settings. Record the event and exact commit being validated: PR head,
synthetic merge commit, merge queue or release. Establish three timestamps from real runs:

1. Change submitted to first actionable failure feedback.
2. Change submitted to all required merge checks completing.
3. Change submitted to deployment readiness, when deployment is in scope.

Record queue time, runner startup, setup, execution and finalisation separately. Include
runner-minutes, price where known, failure rate and reruns as supporting measurements.
Compare matched workload classes, runner types, cache states and test counts; retain sample
size and run URLs. Report median and p90/p95 only when the sample supports them. For a new
pipeline, label estimates and establish the first measured baseline before claiming gains.
Missing access or timing data remains an explicit unknown.

## Find the critical path

Build the dependency DAG through the selected endpoint. Include job dependencies, sequential
steps, artifact consumers, reusable-workflow completion, final aggregators and required
check names. Draw a Mermaid diagram when the dependency structure needs one.

For each node, record its duration and prerequisites. Compute earliest completion as
`finish(node) = duration(node) + max(finish(prerequisites))`, taking the maximum over an
empty set as zero. Backtrack from the endpoint through the latest-finishing prerequisites.
Include the submission-to-root delay. Mark tied paths and record slack on other branches.
This is the dependency lower bound; compare it with the real timeline to expose queueing,
runner scarcity, concurrency limits, service contention and delayed scheduling.

Name the actual chain holding the developer, with evidence for each dependency edge.
Prioritise changes by expected endpoint time saved, execution frequency and tail delay.
Savings on a branch with spare time may leave the endpoint unchanged. After each change,
recompute: another branch can become critical.

## Remove unnecessary waiting

For every edge on the measured path, state the correctness reason the consumer must wait.
Run independent validation concurrently. A task that consumes test results may begin after
those results exist while remaining independent of merge readiness.

For example, tests can feed both the required verdict and a cache-marker writer. The
verdict depends on the tests alone; the writer has no dependency edge into that verdict.
Check the complete path: an enclosing workflow, aggregator or branch rule can still wait
for the writer. Resource competition can also delay required jobs even without a DAG edge.

Classify each candidate using repository policy and its consumers. Cache bookkeeping,
telemetry and optional reports are candidates only when no required consumer needs them.
Signing, deployment artifacts, security checks and required test evidence retain their
required dependency whenever they establish the endpoint's correctness. Preserve failure
visibility and ownership for asynchronous work. Use a separately scheduled job or workflow
whose completion and resource needs cannot hold the selected endpoint.

For GitHub Actions, verify the provider's current dependency and status semantics before
editing: required jobs must report on every applicable event; an aggregator must inspect
all required outcomes. Failed, cancelled, missing or unexpectedly skipped checks must never
produce success. Exercise legitimate path-filter skips explicitly. Avoid success masking
with `continue-on-error` or an unconditional green terminal job. Keep externally required
check names stable unless their consumers are deliberately updated in the same change.

## Choose optimisations from measured evidence

Use the observations above to select a change that addresses the measured bottleneck.
Apply these correctness checks to the selected mechanism:

| Mechanism | Proof needed before accepting the change |
| --- | --- |
| Checkout or change detection | Correct base and head for every supported event; required ancestry and files present; API pagination handled; incomplete diff information fails visibly. |
| Caching or reusing a passed result | Identity includes all relevant sources, dependencies, tools, configuration and environment; untrusted writes cannot satisfy trusted checks; a miss still executes validation. Measure restore, save, hit rate and invalidation cost. |
| Prepared image or schema snapshot | Reproducible inputs and refresh ownership; invalidate on relevant changes; migration changes still exercise the migration path. |
| Concurrent checks or additional shards | CPU, memory, database and runner capacity support concurrency; all failures propagate; outputs remain attributable; wall time and total machine consumption are both measured. |
| Compiler, lint or runner change | Supported platform and configuration, equivalent required diagnostics, and representative performance evidence. |
| Shared test process or module state | Explicit eligible files, teardown of globals/timers/environment/services, repeated and reordered execution, and independent isolation for ineligible tests. |
| Network timeout | Measured stall cause and a finite failure deadline; preserve the failure and diagnostics. Any retries must follow repository policy and have a finite budget. |

Select shard boundaries from actual durations and the scheduler's unit of work. Include
each shard's fixed costs in the estimate and benchmark the slowest shard under realistic
concurrency. Limit outdated-run cancellation to events where cancelling loses no required
merge-queue, release or deployment work.

## Verify and report

Validate configuration with the repository's native tooling. Run the affected commands and
exercise real representative pipeline runs within existing authorization. Cover success,
an actual failed validation, supported event types, intended skips, cache hits/misses and
cancellation where changed. Verify that optional work can finish later or fail while the
required verdict still accurately reflects every required check.

Record the before/after endpoint times, sample sizes, queue/setup breakdown, machine
consumption, run links and remaining critical path. Separate measured results from
estimates. If remote execution is unavailable, report local verification and the exact
remaining validation; never claim a CI speedup from configuration inspection alone.
For `/ic`, persist this evidence with the checklist and head SHA, and refresh it after
pipeline review fixes. Standalone calls return the same evidence with the changed files.

Do not broaden a pipeline edit into infrastructure migration, weaken a required check or
change repository protection without task authorization. Recommendations should identify
the evidence and expected effect on the developer's waiting time.
