# Native macOS app surface (Computer Use)

Use this surface when the thing under test is a **native macOS app** that `agent-browser`
can't drive — anything not Chromium-based: a native desktop app, a chat client you
verify against (Slack/WeChat/…), Finder/system UI, or any OS-level behavior. You
drive it with macOS Computer Use (osascript + screencapture) — the toolkit is in
[../references/computer-use.md](../references/computer-use.md).

Return to the router when Chromium automation or command output can reach the
target. Native runs on **local macOS only**: it needs a real display and
Accessibility permission, and it is not cloud-portable.

## How to verify

1. Activate the app and navigate to the state under test (keystrokes / shortcuts /
   clicks — see the toolkit).
2. Drive the action that exercises your change.
3. Capture proof: a `screencapture` PNG, a screen recording for time-based
   behavior
   ([../references/recording-native-macos.md](../references/recording-native-macos.md)),
   or screen text via select-all-copy + `pbpaste`.

```bash
APP="YourApp"
osascript -e "tell application \"$APP\" to activate"
sleep 1
# ... navigate + act via osascript (see computer-use.md) ...
sleep 2 # let the result settle
screencapture -l "$(osascript -e "tell application \"System Events\" to tell process \"$APP\" to get id of window 1")" "$REPORT_DIR/assets/native-result.png"
```

Store the capture in the round and record it as evidence (provenance `cli`,
since osascript/screencapture are shell-driven):

```json
{"path": "assets/native-result.png", "type": "screenshot", "by": "cli", "description": "Native app after the planned action"}
```

Publish it within the complete [report](../references/report.md) on engapp.dev.

## Mid-flow use from another surface

A web or Electron flow can drop into Computer Use for a single OS-level step it
can't script — a native file picker, a system permission prompt, a Save dialog —
then hand control back to agent-browser. Capture the proof on whichever surface owns
the criterion.

## Boundaries

- **macOS + display only.** No headless/cloud — see
  [../references/computer-use.md](../references/computer-use.md#gotchas).
- **Accessibility permission is mandatory** or every `System Events` call silently
  no-ops. Grant it to the host once.
