---
name: interview
description: "Scoping conversation that turns an idea into a one-page brief with its boundaries fixed — discover only if the request is unclear, explore the repository before asking anything, confirm the verified current behaviour, then clarify scope with questions whose answers change the build, each chosen for a goal you think through and never show — and file the brief at Project <Product>/Features/<slug>/Brief.md. Stage 1 of /lfg and the first thing /lfg runs; also standalone. Invoke when someone types /interview or says \"interview me\", \"help me scope this\", \"clarify the requirements\", \"what's in and out of scope\", \"write a brief\"; invoke it proactively, saying so in one line, when the user wants only scoping done for an idea that has no brief yet — a new idea that wants the whole spine goes to /lfg, which starts here."
---

# /interview — scoping, with as little ceremony as the ambiguity allows

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/Interview.md` (WF-INT).
**Question bank and operating rules:** [`references/question-bank.md`](references/question-bank.md),
distilled from the vault's `+++ Workflow WIP` note.

## Contract — what goes in, what comes out

| | |
|---|---|
| **In** | an idea, a use case or a change request, in the user's words; optionally a product name and a feature slug |
| **Out** | `Project <Product>/Features/<slug>/Brief.md` in the vault, answering the six topics below and standing alone; its path echoed to the caller |
| **Next** | `/research` reads the brief from that path; `/lfg` continues at its stage 2 |

The procedure is the same whether it runs standalone or as `/lfg`'s first stage.

## When this skill starts

- **On request:** `/interview`, or "interview me", "help me scope this", "clarify the
  requirements", "what is in and out of scope", "write a brief".
- **From `/lfg`:** as stage 1, with the intent handed over.
- **Proactively:** the user wants only scoping for an idea that has no brief. Say "running
  /interview" and begin. A new idea that should go all the way to tickets goes to `/lfg`,
  which starts here.
- **Not** when a brief already exists for the feature: read it, play it back, amend only what
  the user corrects. Not when the ask is already a ticket → `/ic`.

## The rule under every question: think the goal, show the question

Every question you ask has a **goal** — the thing you need to learn and the reason it
changes the work. Think it through *before* choosing the question, check it against the four
treatments below, and then show the user **only the question**, in their language, adapted
to their case. The goal is never displayed and never explained unless they ask why. The
bank in `references/question-bank.md` carries a goal for every question; use them as the
standard to hold your own questions to.

| the open point | treatment |
|---|---|
| can be found out — code, tests, config, history, runtime | **investigate it yourself** |
| changes the product outcome | **ask** |
| changes an irreversible risk — data, money, external effects, prod | **must ask**, and record the answer |
| a low-risk implementation detail | **decide yourself**, record it as a reversible default |

Skip any question the request, the authoritative spec, the repository, its documentation,
tests, runtime evidence, conventions, or a prior confirmed decision already answers.

## The shape: three phases, then play back and converge

Listen first, uninterrupted, in the user's words.

### Phase 1 — Initiation and discovery *(only when the request is unclear)*

If the request already states the problem, who has it, the outcome and the constraints, skip
this phase entirely and explore. Otherwise ask, in one batch, from the bank's I-questions:
the problem and what prompted it now, who experiences it and in which workflow, what they
should be able to do afterwards, how success will be judged, the non-negotiables. Close with
the **first confirmation gate** — "my understanding is …; what is incorrect or missing?" —
so exploration does not proceed from a misunderstood objective.

### Phase 2 — Explore, then confirm against evidence

This phase is mostly your own work. Before asking anything, read the repository
(`README`, `CLAUDE.md`, `docs/`, the adjacent code), trace entry points, control flow, data
flow, storage, integrations, conventions and similar features; read `/history` for earlier
attempts on this machine; read the vault (`Project <Product>/Decisions/`, `Specs/`,
`Features/`, the synced `Linear Issues/`) and Linear for tickets in the area. **Answer
engineering facts from code, tests, configuration, history and runtime evidence.**

Then confirm, with evidence in the question (the bank's E-questions): *the system currently
does X — which part is the gap?*; which behaviours must stay and which may change; which
found components to reuse, replace or leave; which source is authoritative when they
disagree; what exists in production that the repository does not show.

### Phase 3 — Requirements and scope clarification

Ask only what materially changes external behaviour, contracts, risk or acceptance (the
bank's S-questions): actors and environments in and out; the externally visible surface;
**what is explicitly out of scope or safe to defer**; user-visible states; failure policy;
cancellation, timeout and duplicate delivery; the data lifecycle; who may do what to the
data; compatibility or breakage; the scale and cost envelope; what is needed to operate it;
every capability the complete feature includes. When the work carries non-functional
requirements — performance, availability, security, cost — ask for them too. The bank's
**angles table** lists where the undecided decision usually hides when a request looks
complete.

Close the phase with the bank's S13: *here are the remaining decisions and my
recommendations — which do you decide, which do you delegate to me?* A delegated decision
gets its default stated and is confirmed only if it changes product behaviour, risk,
compatibility or external effects.

### How to ask

Question Socratically: probe the reasons, assumptions and evidence behind what the user asks
for, and the consequences of each answer, until the requirement holds up.

- Blockers first; **three to five questions per batch, ordered by dependency**.
- When alternatives exist, **two or three mutually exclusive options**, their consequences,
  one marked recommendation. State each option as its observable behaviour, migration cost,
  compatibility, risk and long-term ownership. Do not name an option by a style such as
  "minimal" or "clean".
- **Sharpen fuzzy words** — propose the precise term for a vague or overloaded one, and ask
  which is meant: *"account" — the customer, or the user?*
- **Check claims against the code** — when the user says how something works, look it up, and
  put any contradiction to them with the evidence: *the code cancels whole orders, but you said
  partial cancellation is possible — which is right?*
- When a boundary is unclear, a **concrete scenario** can help: invent an edge case and ask
  what should happen there.
- **Silence is not agreement.** An option label like `A` means the first option listed.
  Every answer lands in the ledger as `confirmed`, `delegated` (with its default stated) or
  `deferred`.
- Reopen a settled question only when new evidence invalidates its premise.
- Implementation details belong to planning's Q&A (`/lfg` stage 3, the bank's A-questions).

### Play back, then converge

Before playing back, hold each requirement to ISO/IEC/IEEE 29148 — necessary, unambiguous,
singular, feasible, verifiable — and the set to complete and consistent; ask about any that
falls short.

Restate the understanding and let the user correct it. **The progress meter is the playback
surviving uncorrected**: the point where the user would say "yes, that's what I meant". Keep
it to this shape so a correction has somewhere obvious to land:

- **Problem / for whom:** …
- **Done when:** …
- **Verified today:** … (what exploration showed, in one line)
- **In scope:** …
- **Out of scope:** …
- **Session may, without asking:** …
- **Session must ask before:** …
- **Still open:** …

After it, restate separately what the user said and what you inferred, so they can judge the
inferences.

When a playback survives uncorrected, confirm ("that's the brief I'll write — anything to
add?"), write and file the brief, stop. No filler rounds after convergence.

## What the brief always answers

Every brief covers all six — **inferred silently when obvious** (recorded with the source of
the inference), **asked only when genuinely open**:

- **Problem + consumer** — what, for whom, why now.
- **Done means** — the observable outcome and the minimum evidence that will count; the seed
  of the acceptance criteria planning authors part-wise.
- **Where it lives** — new repository or existing one; which product and surface; and the
  **authoritative source** — the issue or specification this brief answers to, with its
  prerequisites and follow-ups named.
- **Boundaries** — what is explicitly **out of scope**, named item by item, and the
  constraints (time, cost, dependencies, compatibility). This is the section `/lfg` exists
  to get right; "nothing" is not an answer.
- **Authority ceiling** — how far the session runs without asking (PR? merge? staging?);
  prod is always a human act. Declared once, here, and read from the brief by every later
  stage.
- **Open questions** — what planning must resolve; each becomes an ambiguity-register entry
  for `/research`.

## Output — write, then file

After the user confirms the final playback, create `.interview/` with a `.gitignore`
containing `*`, then write the brief in the user's language to `.interview/brief.md`, with
these sections:

```markdown
# Brief: <name>
**Date:** YYYY-MM-DD · **Interviewed:** <user> · **By:** <agent handle>

## Problem & consumer
## Done means
## Where it lives <!-- repo/product/surface · authoritative issue or spec · prerequisites · follow-ups -->
## Verified current behaviour <!-- what exploration established, with the evidence -->
## Out of scope & constraints
## Authority ceiling <!-- without-asking list · ceiling · named hard gates -->
## Open questions <!-- for planning; one line each -->
## Decision ledger <!-- each answer: confirmed · delegated (default stated) · deferred -->
## Inferred answers & sources <!-- every topic answered without asking, and from what -->
```

Then file it — the vault feature folder is the brief's home (System Design §7, confirmed by
ballot F27), and `wf obsidian` owns the path, the frontmatter and the folder index:

```bash
wf obsidian --kind brief --product "<Product>" --feature "<slug>" --file .interview/brief.md \
  --title "<name>" --ticket <TXE-N when one exists>
```

Echo the resulting path; it is what `/research` and `/lfg` read. When the work is
repo-scoped and the repository keeps briefs under `docs/specs/<slug>/`, commit a copy there
too and say so in the brief; the workflow reads the vault copy. Publish through
`/publish-artifacts` when an HTML rendering exists (`/explainer` when the brief has shape).

The brief must **stand alone**: a cold session reading only the brief can start planning
without asking scoping questions.

## Invariants

- Scoping produces the *authority declaration once*; re-asking permission later for anything
  inside the ceiling is a defect.
- An inferred answer is an answer: it appears in the brief with its source, so a wrong
  inference is visible and correctable.
- This skill produces only the brief.

## Where the later phases live

Phase 4 of the bank (architecture) is asked by `/plan` over `/research`'s output; Phase 4-ext
(ticket decomposition) by `/ticketing`; Phase 5 (implementation approval) is `/ticketing`'s
dispatch gate and `/implement`'s planning-assumption check; Phase 6 (review disposition and
completion) is `/ic`'s review loop and `/ready-for-review`. Do not ask them here.

## Learning from a run

A question that earned nothing, or an inference that was wrong, is a finding about this
skill. Correct this file or the bank through a pull request, following the change-a-skill
runbook; the brief carries only the corrected answer. The installed copy is a read-only
cache, and editing it in place changes nothing.
