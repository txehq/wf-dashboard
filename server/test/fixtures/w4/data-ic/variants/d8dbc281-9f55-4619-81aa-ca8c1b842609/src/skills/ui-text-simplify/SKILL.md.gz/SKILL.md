---
name: ui-text-simplify
description: >-
  Write and review UI copy: decide what stays visible, what belongs in a tooltip
  or disclosure, and how to present accurate, friendly empty states. Invoke
  automatically during /ic frontend tasks, including pages, components, layout,
  client-side behavior, styling, localization and accessibility, even when copy
  changes were not requested. Also use for explicit UI wording reviews. Keep the
  check within the task's affected surfaces; backend-only work without a frontend
  effect does not trigger it.
---

# /ui-text-simplify — useful words, in the right place

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/UI Text Simplify.md` (WF-UIC).
Where this file and the spec disagree, the spec wins: update this file to match it.

## Apply within the task

Read the affected interface, its user role and state branches before changing words.
Include templates, dynamic locale keys, interpolated values and accessible names.
Use the repository's existing components, illustrations and localization conventions.

In `/ic`, `/implement` invokes this skill after worktree and checklist setup, before
frontend edits. Earlier classification is read-only. Apply it again during acceptance,
including resumed work. Before a frontend review fix advances, `/acceptance` republishes
its report for the new head at the same URL, and the PR's affected screenshots are replaced.
A frontend task may need no copy changes; do not manufacture edits or audit unrelated
pages. In a review-only task, report findings without editing.

## Decide whether the information is needed

Ask: **Would removing this make the user act incorrectly, misread the result, or be
unable to continue?** Name the user, their task and the specific consequence.

- Keep necessary labels, units, time ranges, input constraints, permission boundaries,
  authorization, action consequences and current errors near the relevant object.
- Express a state the user must understand as an explicit control or state label. For
  example, offer “不限 / 单次 / 自定义” so users do not have to infer that an invite count
  of zero means unlimited. Do not change product behavior to achieve a copy preference.
- Remove duplicated interaction instructions, reasons why users should fill a form,
  author commentary, design debates and irrelevant implementation or development notes.
  A copied-state confirmation stays after “click to copy” is removed.
- Technical terms depend on the task: database configuration needs host and port; a
  database table name is irrelevant to checking a balance.
- Split mixed paragraphs into facts, consequences and explanations before deciding what
  to remove. Never bulk-delete by key names such as `hint`, `note` or `description`.

## Choose the presentation

| Presentation | Use when |
| --- | --- |
| Control, label, unit or inline sentence | The user needs it for the current decision or action. |
| Tooltip | A short definition or formula is optional for completing the main task correctly. |
| Disclosure, popover or help view | The content needs steps, examples, links, copying or interaction. |
| Illustration and a short sentence | A substantial content region is empty and needs a clear state or next action. |
| Remove | The information is redundant, irrelevant to the task, or has no useful lookup value. |

Tooltips must not carry required input constraints, payment authorization, destructive
consequences or an important limitation of the current result. If people must repeatedly
open one to operate a control, make the needed information visible or improve the control.
Support keyboard focus, Escape dismissal, hovering over the tooltip itself, and a touch
equivalent. Associate the description with its trigger; keep a visible label on every
input, including inputs with a placeholder. Reusing a component does not prove these
interactions work.

## Preserve the state while shortening the text

Distinguish no content, no search matches, loading, failure, denied access, disabled
collection, missing coverage, expired content and an unreleased feature. Unknown or
unmeasured data must not become zero activity, a complete result or a healthy status.
Keep range, approximation, negation and action consequences accurate. If the cause is
not known, do not invent one.

Replace generic disclaimers with short, conditional facts where they affect the result:
“已统计 {date} 起的数据” belongs beside the selected period; the retention mechanism
can be disclosed separately. Full coverage does not need a permanent warning.

Use a relevant illustration, one friendly sentence and a real next action when available.
Small cells may only need a label or `—`; reduce illustrations when many empty panels
appear together. Decorative images stay out of the accessibility tree. Meaningful state
stays in text. Avoid charts that resemble measured data when none exists.

Friendly copy is concrete and considerate. Light personification may suit news or first
use. Financial, permission, failure and analytical states need calm precision. “正在赶来”
needs a real expectation of future content. No published incidents alone does not justify
“一切正常”. A retained feature card must not imply an unavailable capability can be used.

For ambiguous deletion or disclosure choices, read [examples](references/examples.md).
They include the PR #239 cases behind these decisions; no network lookup is required.

## Check the changed surface

Review the rendered result in the states the task changes, including relevant empty,
failure and partial-data branches. Check label/validation/action continuity, locale
meaning and interpolation, narrow layouts, and tooltip interaction where applicable.
Use the existing test and acceptance workflow; add behavioral checks when a state or
interaction could regress. Removed-word counts or assertions that a sentence disappeared
do not prove correctness.

For `/ic`, persist consequential decisions and affected states under `UI text checks` in
`.ic/checklist.md`; `/implement` mirrors the section to the ticket checklist comment with
the head SHA. Record the surface/state, evidence or reproduction steps, the expected copy
and presentation, and unresolved facts. `/acceptance` consumes it on direct or resumed
entry. Standalone review or acceptance uses its existing local artifact. Keep these notes
out of the product UI. Apply concise defaults and optional detail to rendered reports.
