# Cross-surface evidence contract

Capture commands are in the selected surface guide.

## Evidence media

| Type           | Use when                                                                                          |
| -------------- | ------------------------------------------------------------------------------------------------- |
| `text`         | Command output, logs, focused request/response data, or computed assertions prove the criterion   |
| `markdown`     | Reviewer-facing prose (a reasoning write-up, structured findings) should render as body text      |
| `dom_snapshot` | The structure of the content is the claim                                                         |
| `screenshot`   | A settled visual state, layout, or native rendering is the claim                                  |
| `gif`          | A short temporal state should render inline, usually no more than about 10 seconds                |
| `video`        | An animation, transition, gesture, or multi-step flow over about 10 seconds needs a video player  |
| `audio`        | The deliverable is something the user **hears** — TTS output, a voice reply, an alert tone        |
| `transcript`   | A conversation, event stream, or request log is itself the proof                                  |

The declared `requiredEvidence` type is binding. Do not replace a required video
with a final screenshot or a required DOM snapshot with prose.

## Audio deliverables

Keep the original clip as `audio` evidence and embed it in the HTML report with an
audio player; the publisher cannot upload raw audio files.

```json
{"path": "assets/tts.mp3", "type": "audio", "by": "program", "description": "Original TTS output, measured duration 2.4s"}
```

- Preserve the source format (`mp3`, `wav`, `m4a`, `aac`, `flac`, `ogg`, `opus`)
  and set the evidence type explicitly. Test browser playback for the chosen format.
- **Listen before citing it.** Confirm the clip is non-silent and is the right
  content (duration + a transcription pass, or a spectral check) — an empty or
  truncated file looks identical to a good one in the file list.
- Pair the clip with a short `text` artifact when the claim is about _what was
  said_ (the input text, the voice/model, the measured duration). The player
  proves it plays; the text artifact makes it auditable.
- Capture what the product produced. A screen recording with system audio proves
  "the UI plays it at the right moment"; the file itself proves "the output is
  correct".

## Dual text evidence for non-visual behavior

CLI, API, backend, policy, security, and migration claims normally need two
separate `text` artifacts on the same check:

1. A reasoning artifact: claim, setup or threat model, method, pass criteria,
   interpretation, and limitations.
2. An execution artifact: exact command or request, relevant raw observations,
   exit/status values, and a short mapping back to the pass criteria.

Keep both artifacts in the current round.

## Files and inline content

- Save binary and text/DOM/transcript artifacts under the current round's `assets/`.
- Record each file in `cases[].evidence` with explicit `path`, `type`, and `by`.
  Inline short assertions in the report as well as retaining their source file.
- Keep the description factual: identify the action, observed state, and relevant
  target. Do not place the verdict in the description unless explicitly asked.

```json
{"path": "assets/response.json", "type": "text", "by": "cli", "description": "Observed response after the planned action"}
```

## Provenance (`by`)

Set `by` to the producer named by the selected surface guide. Use the direct
capture source for an unmodified artifact and `program` for a deterministic test,
script, or media transform. Do not infer provenance from the file extension.

Render and publish all evidence through [report.md](report.md). Save image URLs
returned by `publish-artifacts`; inline escaped text and original audio/video
data in the complete report. Never call a separate evidence server.

## Artifact safety

- Inspect every image, clip, and generated document before citing it.
- Never upload credentials, cookies, tokens, private user data, unrelated host
  windows, or notifications.
- Upload the focused part of a log or recording that proves the claim.
- Retain the raw source when submitting a derived chart, contact sheet, GIF, or
  edited comparison image.
