# /// script
# dependencies = ["Jinja2", "markdown-it-py>=3"]
# ///

import argparse
import base64
import json
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, StrictUndefined
from markdown_it import MarkdownIt
from markupsafe import Markup


def data_entry(text: str) -> tuple[str, Path]:
    # 解析 name=path 形式的 context 参数
    name, separator, path = text.partition("=")
    if not separator or not name or not path:
        raise argparse.ArgumentTypeError(f"expected name=path, got {text!r}")
    return name, Path(path)


def load_data(path: Path):
    # .jsonl 每行是一个 JSON 值，其余文件整体是一个 JSON 值
    text = path.read_text(encoding="utf-8")
    if path.suffix == ".jsonl":
        return [json.loads(line) for line in text.splitlines()]
    return json.loads(text)


parser = argparse.ArgumentParser(
    description="Render an acceptance report from a Jinja2 template in the round directory."
)
parser.add_argument("template", type=Path, help="Jinja2 template inside the round directory")
parser.add_argument("output", type=Path, help="HTML file to write")
parser.add_argument(
    "data",
    nargs="+",
    type=data_entry,
    help="name=path of a .json or .jsonl file, exposed to the template as the variable name",
)
args = parser.parse_args()

names = [name for name, _ in args.data]
if len(set(names)) != len(names):
    parser.error(f"data names must be unique, got {names}")

# 模板所在目录就是 round 目录，evidence 路径都相对于它解析
round_dir = args.template.parent


def read_text(relative_path: str) -> str:
    # 读取 round 目录内的文本 evidence，输出时由 autoescape 转义
    return (round_dir / relative_path).read_text(encoding="utf-8")


def data_url(relative_path: str, mime_type: str) -> str:
    # 把 round 目录内的文件编码为 data URL，用于内嵌 audio、video 和可下载的原始内容
    content = base64.b64encode((round_dir / relative_path).read_bytes()).decode("ascii")
    return f"data:{mime_type};base64,{content}"


markdown_renderer = MarkdownIt("commonmark", {"html": False})


def read_markdown(relative_path: str) -> Markup:
    # 把 round 目录内的 Markdown evidence 渲染成 HTML；html=False 让其中的原始 HTML 按文本转义
    return Markup(markdown_renderer.render((round_dir / relative_path).read_text(encoding="utf-8")))


environment = Environment(
    loader=FileSystemLoader(round_dir),
    autoescape=True,
    undefined=StrictUndefined,
)
environment.globals.update(read_text=read_text, data_url=data_url, read_markdown=read_markdown)
context = {name: load_data(path) for name, path in args.data}
html = environment.get_template(args.template.name).render(context)
args.output.write_text(html, encoding="utf-8")
