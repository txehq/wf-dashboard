# GitHub bodies: screenshots and acceptance reports

Use when the task includes creating/updating a PR or Issue. The report stays on
engapp.dev, and a GitHub screenshot complements it. Do not send comments or modify
unrelated issues.

## Discover target and template

Resolve the repository/current PR with `gh repo view` and `gh pr view --json
number,url,body,headRefName,headRefOid,baseRefName`. For an Issue, use the named
Issue and `gh issue view <number> --json title,body,url`. Do not guess from a
similar branch name.

Read the selected template from the target/base branch. Check
`.github/pull_request_template.md`, case variants, root or `docs/` PR templates,
`.github/PULL_REQUEST_TEMPLATE/`, and `.github/ISSUE_TEMPLATE/` Markdown or YAML
forms. Check the organization's
`.github` repository for inherited defaults when local templates are absent.
For multiple templates, use the one selected by the task or represented in the
body. YAML Issue forms render their field labels as body sections. A new Issue
in a repository with no issue template starts from the workflow's
[ticket template](../../ticketing/references/ticket-template.md).

Locate the corresponding screenshot/evidence section, including localized
headings and before/after fields. Preserve headings, checklists, closing trailers,
and unrelated text. No screenshot section means no template requirement to
invent screenshots for a nonvisual change. Real visual evidence may still help.

## Upload actual screenshots

Use [dependencies.md](dependencies.md). If the extension is missing, execute:

```bash
gh extension install drogers0/gh-image
```

Open each screenshot with the image-viewing tool and confirm the asserted state
and absence of secrets. Upload to the intended repository:

```bash
gh image "$SCREENSHOT" --repo "$REPOSITORY"
```

Each successful image upload prints Markdown such as
`![state.png](https://github.com/user-attachments/assets/<id>)`. Capture stdout
as data; check the exit status and every URL. **gh-image does not edit the body.**
Insert its returned image Markdown directly into the matching section with a
factual caption, preserving before/after labels. On a repair round, replace the
screenshots of rerun checks in that section with the new uploads.

Auth normally uses the `gh` account for image/video uploads with push access.
Other cases may need an existing GitHub browser session or `GH_SESSION_TOKEN`.
Session cookies are secrets: never print them, put them in command arguments,
or take them from an unrelated account. Missing auth is an upload blocker;
do not claim the section is complete or use an alternate upload service.

## Include the complete acceptance URL

If the current PR has an acceptance report, include its verified
`https://engapp.dev/artifacts/page/<id>` URL in the **PR body**, even without a
screenshot section. Check repository, branch, commit, requirement, and subject;
do not attach another task's report. Record dirty-tree provenance when tests
preceded the commit. An unchanged tested diff may be linked after committing.

When the template has an acceptance or test-evidence section, put the report link
there; when it has none, append a short `## Acceptance` section with the report
link, coverage, and limits. For an Issue with an acceptance report, put the same
link in its evidence section. The body carries the delivery's one report URL from
`acceptance.json`; a repair republishes the report at that URL, so the link stays
as it is and the coverage and limits beside it are updated. Never fabricate a URL
if publication failed; say publication is blocked.

## Save and verify

Write the complete body as UTF-8 to `body.md` in the round directory with the file
editing tool. Re-read the remote body immediately before saving; reapply additions
if someone changed it. Preserve newlines and literal backticks; never evaluate
body/image Markdown as shell code.

```bash
gh pr edit "$PR_NUMBER" --repo "$REPOSITORY" --body-file "$REPORT_DIR/body.md"
gh pr view "$PR_NUMBER" --repo "$REPOSITORY" --json body,url
```

For Issues, use `gh issue edit ... --body-file` and `gh issue view ... --json
body,url`. Pass the prepared file to `gh pr create` or `gh issue create` for a
new object only when creation is in scope.

Verify saved image Markdown is inside the intended section and the full report
URL is present. Open the rendered page with Agent Browser and check attachments.
An attachment may be uploader-only until referenced in rendered content, so
verify after saving. Body readback proves persistence; the rendered page proves
image rendering. Report upload, edit, and rendered-page failures separately.
