import argparse
import atexit
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import time
import unittest
from pathlib import Path

import review_monitor

# 测试状态写在临时目录里，退出时删掉。写进 skills/review-pr 会把任务数据库、完整 PR diff
# 和日志留在发布树里，下一次 `wf release build-local` 就会把它们打进 bundle，发布也就不再可复现。
WORK = Path(tempfile.mkdtemp(prefix="review-pr-tests-"))
REPO = "txehq/txe-workflow"
# PR #32 由 connorwang 提交且已经合并：作者不是运行测试的账号，状态固定为 closed
MERGED_PR = 32


def remove_work() -> None:
    shutil.rmtree(WORK, ignore_errors=True)


atexit.register(remove_work)


def work_dir(name: str) -> Path:
    path = WORK / name
    path.mkdir(parents=True)
    return path


def gh_api(*args: str) -> str:
    return subprocess.run(["gh", "api", *args], capture_output=True, text=True, check=True).stdout


def args_for(state_dir: Path, **overrides: object) -> argparse.Namespace:
    values: dict[str, object] = {
        "repo": REPO,
        "state_dir": str(state_dir),
        "poll_seconds": 30,
        "debounce_seconds": 0,
        "preflight_timeout": 180,
        "max_workers": 2,
        "job_timeout_seconds": 1800,
        "coordinator_model": "gpt-5.6-luna",
        "coordinator_effort": "low",
        "coordinator_sandbox": "danger-full-access",
        "review_model": "gpt-5.6-sol",
        "review_effort": "high",
        "max_single_review_bytes": 750 * 1024,
        "gh": "gh",
        "codex": "codex",
        "reset_job": [],
        "once": False,
        "observe_only": True,
        "maintenance_interval": 86400,
        "attempt_retention_days": 30,
        "event_retention_days": 90,
        "job_retention_days": 90,
        "artifact_retention_days": 365,
        "evidence_retention_days": 7,
        "warn_db_bytes": 100 * 1024 * 1024,
        "pause_db_bytes": 500 * 1024 * 1024,
    }
    values.update(overrides)
    return argparse.Namespace(**values)


def merged_pr() -> tuple[dict[str, object], dict[str, object], str]:
    raw = json.loads(gh_api(f"repos/{REPO}/pulls/{MERGED_PR}"))
    diff = gh_api("-H", "Accept: application/vnd.github.v3.diff", f"repos/{REPO}/pulls/{MERGED_PR}")
    pr: dict[str, object] = {
        "number": MERGED_PR,
        "url": raw["html_url"],
        "author": raw["user"]["login"],
        "head": raw["head"]["sha"],
        "covered": False,
        "has_any_rpr": False,
        "reply_bodies": "",
        "followups": [],
    }
    return pr, raw, diff


def job_row(monitor: review_monitor.Monitor, job_id: str) -> object:
    return monitor.store.db.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()


class CodexCommandTest(unittest.TestCase):
    # 断言的是实际拼出的 argv：注释里写着某个参数，不能证明进程带着它启动

    def monitor(self) -> review_monitor.Monitor:
        monitor = review_monitor.Monitor(args_for(work_dir(self.id())))
        self.addCleanup(monitor.close)
        return monitor

    def test_every_codex_invocation_disables_apps_and_approvals(self) -> None:
        monitor = self.monitor()
        commands = {
            "review": monitor.codex_command("review", artifact_path=monitor.state_dir / "out.md"),
            "reply": monitor.codex_command("reply", prompt="answer the author"),
        }
        for kind, command in commands.items():
            with self.subTest(kind=kind):
                self.assertIn("--disable", command, f"{kind}: eager MCP discovery can hang the run")
                self.assertEqual("apps", command[command.index("--disable") + 1])
                self.assertIn("approval_policy=never", command, f"{kind}: an approval prompt blocks forever")
                self.assertIn("--ephemeral", command)
                self.assertIn("--skip-git-repo-check", command)

    def test_the_review_pass_is_read_only_and_writes_only_its_final_message(self) -> None:
        monitor = self.monitor()
        artifact = monitor.state_dir / "out.md"
        command = monitor.codex_command("review", artifact_path=artifact)
        self.assertEqual("read-only", command[command.index("-s") + 1])
        self.assertEqual(str(artifact), command[command.index("--output-last-message") + 1])
        self.assertEqual("gpt-5.6-sol", command[command.index("-m") + 1])
        self.assertNotIn("-C", command, "a static review needs no working directory")

    def test_the_review_pass_uses_high_reasoning_effort(self) -> None:
        command = self.monitor().codex_command("review", artifact_path=Path("o.md"))
        self.assertIn("model_reasoning_effort=high", command)


class StoreTest(unittest.TestCase):
    def test_a_new_database_uses_wal_and_incremental_vacuum(self) -> None:
        monitor = review_monitor.Monitor(args_for(work_dir(self.id())))
        self.addCleanup(monitor.close)
        self.assertEqual("wal", monitor.store.db.execute("PRAGMA journal_mode").fetchone()[0])
        self.assertEqual(2, monitor.store.db.execute("PRAGMA auto_vacuum").fetchone()[0])

    def test_jobs_from_state_json_import_with_their_circuits_open(self) -> None:
        state_dir = work_dir(self.id())
        (state_dir / "state.json").write_text(
            json.dumps(
                {
                    "initialized": True,
                    "repo": REPO,
                    "prs": {"12": {"head": "head", "covered": False, "seen_followups": []}},
                    "jobs": {
                        f"{REPO}#12@head": {
                            "kind": "review",
                            "pr": 12,
                            "head": "head",
                            "attempts": 24,
                            "status": "failed",
                        }
                    },
                }
            ),
            encoding="utf-8",
        )
        monitor = review_monitor.Monitor(args_for(state_dir))
        self.addCleanup(monitor.close)
        row = monitor.store.db.execute("SELECT status,attempts FROM jobs").fetchone()
        self.assertEqual("circuit_open", row["status"])
        self.assertEqual(24, row["attempts"])


class GitHubTest(unittest.TestCase):
    # 这些测试调用真实的 GitHub API，需要已登录的 gh

    def test_a_merged_pr_is_preflighted_after_the_debounce_and_found_ineligible(self) -> None:
        monitor = review_monitor.Monitor(args_for(work_dir(self.id()), debounce_seconds=2))
        self.addCleanup(monitor.close)
        pr, _raw, _diff = merged_pr()
        auth = json.loads(gh_api("user"))["login"]
        monitor.upsert_heads([pr])
        monitor.prepare_jobs(auth, [pr])
        head = "SELECT last_error FROM pr_heads WHERE pr_number=?"
        self.assertIsNone(monitor.store.db.execute(head, (MERGED_PR,)).fetchone()[0], "preflight ran inside the debounce")
        time.sleep(2.5)
        monitor.prepare_jobs(auth, [pr])
        self.assertEqual("PR is closed or draft", monitor.store.db.execute(head, (MERGED_PR,)).fetchone()[0])
        self.assertEqual(0, monitor.store.db.execute("SELECT count(*) FROM jobs").fetchone()[0])

    def test_the_static_prompt_embeds_the_complete_hash_verified_diff(self) -> None:
        monitor = review_monitor.Monitor(args_for(work_dir(self.id())))
        self.addCleanup(monitor.close)
        pr, raw, diff = merged_pr()
        monitor.upsert_heads([pr])
        monitor.apply_preflight(pr, None, "ready", None, monitor.write_evidence(pr, raw, diff))
        row = job_row(monitor, monitor.review_job_id(pr))
        prompt = monitor.static_review_prompt(row)
        self.assertIn(diff, prompt)
        self.assertIn(hashlib.sha256(diff.encode("utf-8")).hexdigest(), prompt)
        meta = json.loads(Path(row["evidence_path"]).read_text(encoding="utf-8"))
        Path(meta["diff_path"]).write_text(diff + "+tampered\n", encoding="utf-8")
        with self.assertRaises(RuntimeError):
            monitor.static_review_prompt(row)

    def test_maintenance_deletes_expired_jobs_and_evidence_and_keeps_the_active_job(self) -> None:
        monitor = review_monitor.Monitor(
            args_for(work_dir(self.id()), maintenance_interval=0, job_retention_days=0, evidence_retention_days=0)
        )
        self.addCleanup(monitor.close)
        pr, raw, diff = merged_pr()
        monitor.upsert_heads([pr])
        old_evidence = monitor.write_evidence(pr, raw, diff)
        monitor.apply_preflight(pr, None, "ready", None, old_evidence)
        old_job = monitor.review_job_id(pr)
        # 同一个 PR 出现新的头提交：旧任务变成 stale，新任务等待派发
        moved = dict(pr, head="0" * 40)
        monitor.upsert_heads([moved])
        active_evidence = monitor.write_evidence(moved, raw, diff)
        monitor.apply_preflight(moved, None, "ready", None, active_evidence)
        active_job = monitor.review_job_id(moved)
        self.assertEqual("stale", job_row(monitor, old_job)["status"])
        time.sleep(0.1)
        monitor.maybe_maintain()
        self.assertIsNone(job_row(monitor, old_job))
        self.assertIsNotNone(job_row(monitor, active_job))
        self.assertFalse(old_evidence.exists())
        self.assertTrue(active_evidence.exists())
        active_diff = json.loads(active_evidence.read_text(encoding="utf-8"))["diff_path"]
        self.assertTrue(Path(active_diff).exists(), "the active job's diff was deleted with the expired evidence")

    def test_a_diff_github_refuses_to_serve_comes_back_as_the_reason(self) -> None:
        # rust-lang/rust#160692 已经合并，改动 1105 个文件，超过 GitHub diff 的 300 个文件上限
        refusing = review_monitor.Monitor(args_for(work_dir(self.id() + ".refused"), repo="rust-lang/rust"))
        self.addCleanup(refusing.close)
        diff, refused = refusing.fetch_diff(160692)
        self.assertIsNone(diff)
        self.assertIn("(HTTP 406)", str(refused))
        serving = review_monitor.Monitor(args_for(work_dir(self.id() + ".served")))
        self.addCleanup(serving.close)
        diff, refused = serving.fetch_diff(MERGED_PR)
        self.assertIsNone(refused)
        self.assertEqual(merged_pr()[2], diff)

    def test_a_cancelled_job_is_preflighted_again_when_its_head_returns(self) -> None:
        monitor = review_monitor.Monitor(args_for(work_dir(self.id())))
        self.addCleanup(monitor.close)
        pr, raw, diff = merged_pr()
        monitor.upsert_heads([pr])
        monitor.apply_preflight(pr, None, "ready", None, monitor.write_evidence(pr, raw, diff))
        job_id = monitor.review_job_id(pr)
        # PR 从轮询结果里消失，例如转为 draft：等待派发的任务取消
        monitor.upsert_heads([])
        self.assertEqual("cancelled", job_row(monitor, job_id)["status"])
        # 同一个头提交回到轮询结果：任务重新做一次真实的 preflight，这个 PR 已经合并，所以结果是 ineligible
        monitor.upsert_heads([pr])
        monitor.prepare_jobs(json.loads(gh_api("user"))["login"], [pr])
        self.assertEqual("PR is closed or draft", job_row(monitor, job_id)["last_error"])


class CircuitTest(unittest.TestCase):
    # 启动真实的 codex CLI：模型名不存在，codex 以非零状态退出

    def test_a_failed_reviewer_opens_the_circuit_and_runs_again_only_after_an_exact_reset(self) -> None:
        codex = shutil.which("codex")
        self.assertIsNotNone(codex, "this test launches the codex CLI")
        monitor = review_monitor.Monitor(
            args_for(
                work_dir(self.id()),
                observe_only=False,
                codex=codex,
                review_model="rpr-test-model-that-does-not-exist",
            )
        )
        self.addCleanup(monitor.close)
        pr, raw, diff = merged_pr()
        monitor.upsert_heads([pr])
        monitor.apply_preflight(pr, None, "ready", None, monitor.write_evidence(pr, raw, diff))
        job_id = monitor.review_job_id(pr)

        monitor.dispatch_ready()
        self.assertEqual("running", job_row(monitor, job_id)["status"])
        worker = monitor.processes[job_id]
        self.assertNotEqual(
            os.getpgrp(),
            os.getpgid(worker.pid),
            "the worker leads its own process group, so launchd restarting the detector does not "
            "kill a review in flight; `wf review-pr uninstall` is what ends one",
        )
        worker.wait(timeout=600)
        monitor.reap([pr])
        row = job_row(monitor, job_id)
        self.assertEqual("circuit_open", row["status"])
        self.assertEqual(1, row["attempts"])
        self.assertIn("reviewer exited with code", row["last_error"])
        attempt = monitor.store.db.execute("SELECT status,exit_code FROM attempts WHERE job_id=?", (job_id,)).fetchone()
        self.assertEqual("failed", attempt["status"])
        self.assertNotEqual(0, attempt["exit_code"])

        monitor.dispatch_ready()
        self.assertEqual("circuit_open", job_row(monitor, job_id)["status"], "a failed job was dispatched again")
        self.assertEqual({}, monitor.processes)

        monitor.args.reset_job = [f"{job_id}-unknown"]
        with self.assertRaises(RuntimeError):
            monitor.reset_jobs()
        monitor.args.reset_job = [job_id]
        monitor.reset_jobs()
        row = job_row(monitor, job_id)
        self.assertEqual("circuit_open", row["status"])
        self.assertEqual(1, row["reset_requested"])
        self.assertIsNone(row["evidence_path"])

        # 重置后的下一次轮询做一次真实的 preflight：PR 已经合并，任务取消
        monitor.prepare_jobs(json.loads(gh_api("user"))["login"], [pr])
        row = job_row(monitor, job_id)
        self.assertEqual("cancelled", row["status"])
        self.assertEqual(0, row["reset_requested"])
        self.assertEqual("PR is closed or draft", row["last_error"])
        self.assertEqual(1, row["attempts"])


class ValidationTest(unittest.TestCase):
    VALID = """## Codex Code Review (gpt-5.6-sol, high)
<!-- OpenAI Codex via RPR -->

### Medium [1]

#### 1. A real defect

File: x.ts:10

Failure and correction.
Origin: Introduced by this PR
"""

    def test_review_validation_counts_findings_and_holds_a_preexisting_medium(self) -> None:
        monitor = review_monitor.Monitor(args_for(work_dir(self.id())))
        self.addCleanup(monitor.close)
        self.assertEqual(("valid", None, 1), monitor.validate_review_body(self.VALID))
        self.assertEqual(
            "manual",
            monitor.validate_review_body(self.VALID.replace("Introduced by this PR", "Pre-existing"))[0],
        )
        self.assertEqual("invalid", monitor.validate_review_body(self.VALID.replace("### Medium [1]", "### Medium [2]"))[0])
        low = self.VALID.replace("### Medium [1]", "### Low [1]").replace("Introduced by this PR", "Pre-existing")
        self.assertEqual(("valid", None, 1), monitor.validate_review_body(low))

    def test_headings_inside_a_code_block_are_not_findings(self) -> None:
        monitor = review_monitor.Monitor(args_for(work_dir(self.id())))
        self.addCleanup(monitor.close)
        fenced = self.VALID + "\n```\n### High [3]\n#### 1. quoted from the diff\nOrigin: Pre-existing\n```\n"
        self.assertEqual(("valid", None, 1), monitor.validate_review_body(fenced))


if __name__ == "__main__":
    unittest.main()
