# /// script
# dependencies = ["websockets>=15"]
# ///

import argparse
import base64
import json
import sys
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import ProxyHandler, build_opener

from websockets.sync.client import connect

parser = argparse.ArgumentParser(
    description="Capture one page target with CDP Page.captureScreenshot over its own DevTools connection."
)
parser.add_argument(
    "--cdp-url",
    required=True,
    help="the output of `agent-browser get cdp-url`, or http://127.0.0.1:<port> for an app's CDP port",
)
parser.add_argument(
    "--page-url",
    required=True,
    help="URL prefix that matches exactly one page target",
)
parser.add_argument("--out", required=True, type=Path, help="PNG file to write")
args = parser.parse_args()

# 本地 DevTools endpoint 不经过环境变量里的 HTTP proxy
opener = build_opener(ProxyHandler({}))
with opener.open(f"http://{urlsplit(args.cdp_url).netloc}/json/list") as response:
    targets = json.load(response)
pages = [
    target
    for target in targets
    if target["type"] == "page" and target["url"].startswith(args.page_url)
]
if len(pages) != 1:
    sys.exit(
        f"--page-url {args.page_url} matches {len(pages)} page targets: "
        f"{[page['url'] for page in pages]}"
    )

# 每次截图建立独立的 CDP 连接，不经过 agent-browser daemon
with connect(pages[0]["webSocketDebuggerUrl"], max_size=None, ping_interval=None, proxy=None) as websocket:
    websocket.send(json.dumps({"id": 1, "method": "Page.captureScreenshot", "params": {"format": "png"}}))
    # 跳过 event，直到收到 id 为 1 的响应
    reply = json.loads(websocket.recv())
    while reply.get("id") != 1:
        reply = json.loads(websocket.recv())
if "error" in reply:
    sys.exit(f"Page.captureScreenshot failed: {reply['error']}")
args.out.write_bytes(base64.b64decode(reply["result"]["data"]))
