---
name: history
description: Search the past sessions of every coding agent on this machine — Claude Code, Codex, Cursor, Gemini and the rest ctx indexes — for what was already tried, how an error looked last time, and which session landed the fix, with the `wf-history` MCP tools (`search`, then `show_session`), and `wf history` on the command line for JSON output. Use whenever you hit a problem, an error, or friction with the user; before re-deriving something that may already have been worked out; when reconstructing why something was built a particular way; or when someone asks "didn't we already fix this?".
---

# /history — what this machine already knows

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Research/Research.md` (WF-RES).
Where this file and the spec disagree, the spec wins: update this file to match it.

## When to reach for it

- **A problem or an error.** Search the exact error text before debugging from scratch.
- **Friction with the user.** They correct you, repeat themselves, or say "we already did
  this": find the earlier session before you answer.
- **Something that may already be worked out** — a build flag, a workaround, why a design went
  the way it did.

## Search with the MCP tools

The `wf-history` server exposes ctx's read-only tools. In Claude Code they are
`mcp__wf-history__<tool>`; in Codex, Cursor and the other agents `wf` manages, use the
`wf-history` server's tools of the same names. When they are not loaded in this session, run
`wf doctor` and apply the repair it names; the tools load in the next session, so report the
repair and stop.

1. **`search`** — a `query` in plain words or the exact error string, and a small `limit`. It
   returns the strongest hit from each conversation, best first.
2. **`show_session`** with a hit's `ctx_session_id` to read that conversation, or
   **`show_event`** with its `ctx_event_id` and a window to read the turns around the match.
   `show_session` returns pages: continue with `next_cursor` while `has_more` is true.
3. **`query_events`** when the question is a time range — what happened on this machine
   yesterday afternoon — one bounded page at a time.
4. **`status`** and **`sources`** when results look thin: which agents were found, how much is
   indexed, and whether a refresh or embedding is still running.

MCP search does **not** leave out the session you are in, so your own recent turns can come back
as hits. Skip them; they are not earlier evidence.

## JSON on the command line

`wf history …` is exactly `ctx …`, with the same flags and output. Use it when you want JSON to
filter:

```bash
wf history search "<query>" --format json --limit 5
wf history show session <ctx-session-id>
wf history show event <ctx-event-id> --window 5
wf history status
wf history doctor --format json
wf history semantic status
```

Pass `--format json` for JSON. Command-line search leaves out the current session when it can
identify it.

These are the flags of the ctx this release pins. When ctx answers
`unexpected argument '--format' found`, the ctx that ran is another one — a ctx before 1.0 takes
`--json` — and `wf history` says on stderr when the ctx it runs is not the one `wf` installed. Run
`wf doctor`: its `capso.ctx.binary` finding names the repair.

## Reading and citing a result

A hit carries the provider, the ctx session id, the event id, a timestamp and the matching
snippet. Cite the ctx session id whenever a result shapes what you do, and the event id when one
turn is the evidence, so the person can open exactly what you read. Label a conclusion drawn from
several hits as your own synthesis, and do not attribute a decision to a session whose text does
not state it.

Results are private local history: paths, snippets, transcript text. Quote only what supports
the point, and do not paste secrets into a report.

## How current it is

ctx's daemon refreshes the index as agents write. Keyword search works as soon as ctx is set
up. Semantic search is on, and fills in while the daemon embeds in the background: until
`wf history semantic status` shows coverage complete, a session you can only describe may not
match yet, so try the words it would have used as well. When it shows `failed` with
`model_load_failed`, semantic search cannot load its ONNX Runtime and search is keyword-only;
`wf doctor` reports `CTX-SEMANTIC`, and `wf install` puts the runtime this release pins in place.

When results look stale or empty, `wf history doctor --format json` names the cause.

When a search fails, read which of these it is:

- **`start or recover daemon before source-backed refresh`** from the CLI, or
  `source_unavailable` from the MCP `search` — ctx's background daemon has lost its supervision.
  Run `wf history index mode auto`, which re-registers and starts it, and search again. When it
  still fails, `wf doctor` reports `CTX-DAEMON`; put that finding in your report. A task that
  may not change the machine searches the index as it stands with `--refresh off` and says so.
- **A JSON result whose `freshness.status` is `failed`** — the search succeeded against the index
  as it stood, and the refresh before it did not. Use the results, and quote `freshness.error`
  when you report.
- **`CTX-MISSING` from `wf history`**, or a `capso.ctx.binary`, `CTX-HEALTH` or `CTX-SEMANTIC`
  finding from `wf doctor` — ctx itself is not what this release installs. `wf doctor` names
  the repair; the rest is `/install-manager`.

## What it sends

ctx sends content-free usage analytics by default: five versioned event families that never
carry your queries, results, paths or transcripts. `[analytics] enabled = false` in
`~/.ctx/config.toml` turns them off for every ctx process, and `CTX_ANALYTICS_ENABLED=false` for
the processes that inherit it. If someone asks, say exactly that.
