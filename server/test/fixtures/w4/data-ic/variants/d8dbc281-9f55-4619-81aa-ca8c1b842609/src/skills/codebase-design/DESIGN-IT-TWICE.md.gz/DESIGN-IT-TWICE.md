# Design it twice

When a deepening candidate's interface is still an open question, design it several ways in
parallel and compare. Based on Ousterhout's "design it twice": the first idea is unlikely to be
the best. Uses the vocabulary in [SKILL.md](SKILL.md): **module**, **interface**, **seam**,
**adapter**, **leverage**.

## 1. Frame the problem space

Before starting any sub-agent, write a short explanation of the problem space for the chosen
candidate:

- the constraints any new interface has to satisfy;
- the dependencies it relies on, and the category of each ([DEEPENING.md](DEEPENING.md));
- a rough code sketch that makes the constraints concrete — an illustration, still short of a
  proposal.

Share it, then go straight to step 2; the sub-agents work while it is read.

## 2. Start the sub-agents

Start three or more sub-agents in parallel. Each produces a **very different** interface for the
deepened module, and each gets its own technical brief — file paths, coupling details, the
dependency category, what sits behind the seam — with the vocabulary of [SKILL.md](SKILL.md) and
the project's own domain terms, so every design names things the same way. Give each a
different constraint:

- Agent 1: "Minimise the interface: one to three entry points, maximum leverage per entry
  point."
- Agent 2: "Maximise flexibility: support many use cases and extension."
- Agent 3: "Optimise for the most common caller: make the default case trivial."
- Agent 4, when it applies: "Design around ports and adapters for the dependencies across the
  seam."

Each brief also says: design only — write no code into the repository, and start no agent of
your own. Each sub-agent returns:

1. the interface — types, methods, parameters, and its invariants, ordering and error modes;
2. a usage example showing how callers use it;
3. what the implementation hides behind the seam;
4. the dependency strategy and adapters ([DEEPENING.md](DEEPENING.md));
5. the trade-offs: where leverage is high, where it is thin.

## 3. Present and compare

Present the designs one after another, then compare them in prose by **depth** (leverage at the
interface), **locality** (where change concentrates) and **seam placement**. Then recommend one,
and say why; where parts of different designs combine well, propose the combination. Be
opinionated: the reader wants a strong read, and a menu leaves the work undone.
