// 清空当前 origin 的 localStorage、sessionStorage、IndexedDB 和 Cache API；删除 database 出错或被 blocked 时 reject
(async () => {
  localStorage.clear();
  sessionStorage.clear();
  const databases = await indexedDB.databases();
  await Promise.all(
    databases.map(
      (database) =>
        new Promise((resolve, reject) => {
          const request = indexedDB.deleteDatabase(database.name);
          request.onsuccess = () => resolve();
          request.onerror = () => reject(request.error);
          request.onblocked = () =>
            reject(new Error(`deleteDatabase blocked by an open connection: ${database.name}`));
        }),
    ),
  );
  const cacheNames = await caches.keys();
  await Promise.all(cacheNames.map((name) => caches.delete(name)));
  return 1;
})();
