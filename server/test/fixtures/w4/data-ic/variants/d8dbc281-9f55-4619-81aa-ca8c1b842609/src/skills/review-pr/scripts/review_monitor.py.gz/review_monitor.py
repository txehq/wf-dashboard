# /// script
# requires-python = ">=3.11"
# dependencies = ["markdown-it-py>=3"]
# ///

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import re
import signal
import sqlite3
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from markdown_it import MarkdownIt

RPR_MARKERS = (
    "<!-- OpenAI Codex via RPR -->",
    "<!-- OpenAI Codex via RPRB -->",
    "Review by OpenAI Codex via RPRB",
)
REPLY_MARKER_PREFIX = "<!-- OpenAI Codex via RPR reply-to:"
RPRB_REPLY_MARKER_PREFIX = "<!-- OpenAI Codex via RPRB reply-to:"
TOKEN_RE = re.compile(r"^tokens used\s*\n([0-9,]+)\s*$", re.MULTILINE)
SEVERITY_RE = re.compile(r"^(Critical|High|Medium|Low) \[([0-9]+)\]$")
FINDING_RE = re.compile(r"^[0-9]+\. ")
ORIGIN_RE = re.compile(r"^Origin: (Introduced by this PR|Pre-existing)$")
SCHEMA_VERSION = 3


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def atomic_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(value, encoding="utf-8")
    os.replace(tmp, path)


def atomic_json(path: Path, value: Any) -> None:
    atomic_text(path, json.dumps(value, indent=2, sort_keys=True) + "\n")


def append_event(path: Path, event: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        handle.write(json.dumps(event, separators=(",", ":"), sort_keys=True) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
        fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def run_command(command: list[str], timeout: int = 90) -> subprocess.CompletedProcess[str]:
    completed = subprocess.run(command, text=True, capture_output=True, timeout=timeout, check=False)
    if completed.returncode != 0:
        raise RuntimeError(
            f"{' '.join(command[:4])}: exit {completed.returncode}\n"
            f"stdout: {completed.stdout.strip()}\nstderr: {completed.stderr.strip()}"
        )
    return completed


def run_json(command: list[str], timeout: int = 90) -> Any:
    return json.loads(run_command(command, timeout=timeout).stdout)


def gh_pages(gh: str, endpoint: str) -> list[dict[str, Any]]:
    payload = run_json([gh, "api", endpoint, "--paginate", "--slurp"])
    if not isinstance(payload, list) or any(not isinstance(page, list) for page in payload):
        raise RuntimeError(f"unexpected paginated response for {endpoint}")
    return [item for page in payload for item in page]


def has_marker(body: str) -> bool:
    return any(marker in body for marker in RPR_MARKERS)


def pid_alive(pid: int) -> bool:
    # ps 的退出码回答进程是否存在
    return subprocess.run(["ps", "-p", str(pid)], capture_output=True, check=False).returncode == 0


def event_key(event: dict[str, Any]) -> str:
    return f"{event['source']}:{event['id']}:{event['updated_at']}"


def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value)


class Store:
    def __init__(self, path: Path, state_json: Path, repo: str) -> None:
        self.path = path
        self.repo = repo
        self.path.parent.mkdir(parents=True, exist_ok=True)
        new_db = not self.path.exists()
        self.db = sqlite3.connect(self.path, timeout=5, isolation_level=None)
        self.db.row_factory = sqlite3.Row
        if new_db:
            # auto_vacuum 必须在切换 WAL 和建表之前设置
            self.db.execute("PRAGMA auto_vacuum=INCREMENTAL")
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.execute("PRAGMA busy_timeout=5000")
        self._create_schema()
        os.chmod(self.path, 0o600)
        self.set_meta("repo", repo)
        self.import_state_json_once(state_json)

    def close(self) -> None:
        self.db.close()

    def _create_schema(self) -> None:
        self.db.executescript(
            """
            CREATE TABLE IF NOT EXISTS metadata (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS pr_heads (
                repo TEXT NOT NULL,
                pr_number INTEGER NOT NULL,
                head TEXT NOT NULL,
                url TEXT,
                author TEXT,
                status TEXT NOT NULL DEFAULT 'open',
                covered INTEGER NOT NULL DEFAULT 0,
                has_any_rpr INTEGER NOT NULL DEFAULT 0,
                first_seen_at REAL NOT NULL,
                last_seen_at REAL NOT NULL,
                stable_after REAL NOT NULL,
                last_error TEXT,
                seen_followups_json TEXT NOT NULL DEFAULT '[]',
                PRIMARY KEY (repo, pr_number, head)
            );
            CREATE INDEX IF NOT EXISTS idx_pr_heads_current
                ON pr_heads(repo, status, stable_after);
            CREATE TABLE IF NOT EXISTS jobs (
                job_id TEXT PRIMARY KEY,
                repo TEXT NOT NULL,
                pr_number INTEGER NOT NULL,
                head TEXT NOT NULL,
                kind TEXT NOT NULL CHECK(kind IN ('review','followup')),
                event_key TEXT,
                event_json TEXT,
                status TEXT NOT NULL CHECK(status IN (
                    'ready','running','completed','stale','cancelled','circuit_open'
                )),
                attempts INTEGER NOT NULL DEFAULT 0,
                reset_requested INTEGER NOT NULL DEFAULT 0,
                pid INTEGER,
                lease_owner TEXT,
                lease_expires_at REAL,
                log_path TEXT,
                evidence_path TEXT,
                last_error TEXT,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_jobs_dispatch
                ON jobs(status, created_at);
            CREATE TABLE IF NOT EXISTS attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id TEXT NOT NULL REFERENCES jobs(job_id) ON DELETE CASCADE,
                attempt_no INTEGER NOT NULL,
                model TEXT NOT NULL,
                effort TEXT NOT NULL,
                pid INTEGER,
                log_path TEXT,
                prompt_path TEXT,
                artifact_path TEXT,
                started_at REAL NOT NULL,
                finished_at REAL,
                exit_code INTEGER,
                tokens_total INTEGER,
                status TEXT NOT NULL DEFAULT 'running',
                error TEXT,
                UNIQUE(job_id, attempt_no)
            );
            CREATE TABLE IF NOT EXISTS events (
                event_key TEXT PRIMARY KEY,
                repo TEXT NOT NULL,
                pr_number INTEGER NOT NULL,
                source TEXT NOT NULL,
                source_id INTEGER NOT NULL,
                source_updated_at TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                first_seen_at REAL NOT NULL,
                handled_at REAL
            );
            CREATE TABLE IF NOT EXISTS artifacts (
                identity TEXT PRIMARY KEY,
                repo TEXT NOT NULL,
                pr_number INTEGER NOT NULL,
                head TEXT,
                event_key TEXT,
                kind TEXT NOT NULL,
                github_id TEXT,
                body_sha256 TEXT,
                verified_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS usage_daily (
                day TEXT NOT NULL,
                model TEXT NOT NULL,
                attempts INTEGER NOT NULL DEFAULT 0,
                tokens_total INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY(day, model)
            );
            CREATE TABLE IF NOT EXISTS maintenance_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                started_at REAL NOT NULL,
                completed_at REAL,
                deleted_rows INTEGER NOT NULL DEFAULT 0,
                deleted_files INTEGER NOT NULL DEFAULT 0,
                db_bytes INTEGER,
                status TEXT NOT NULL,
                detail TEXT
            );
            """
        )
        # 较早版本创建的数据库缺少这些列
        job_columns = {str(row[1]) for row in self.db.execute("PRAGMA table_info(jobs)").fetchall()}
        if "reset_requested" not in job_columns:
            self.db.execute("ALTER TABLE jobs ADD COLUMN reset_requested INTEGER NOT NULL DEFAULT 0")
        attempt_columns = {str(row[1]) for row in self.db.execute("PRAGMA table_info(attempts)").fetchall()}
        if "prompt_path" not in attempt_columns:
            self.db.execute("ALTER TABLE attempts ADD COLUMN prompt_path TEXT")
        if "artifact_path" not in attempt_columns:
            self.db.execute("ALTER TABLE attempts ADD COLUMN artifact_path TEXT")
        # 等待重试的任务在这里打开熔断：失败的任务只由人工重置恢复
        self.db.execute(
            """UPDATE jobs SET status='circuit_open',last_error='worker failed; reset the job to review it again'
               WHERE status='retry_wait'"""
        )
        self.set_meta("schema_version", str(SCHEMA_VERSION))

    def set_meta(self, key: str, value: str) -> None:
        self.db.execute(
            "INSERT INTO metadata(key,value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )

    def get_meta(self, key: str) -> str | None:
        row = self.db.execute("SELECT value FROM metadata WHERE key=?", (key,)).fetchone()
        return None if row is None else str(row[0])

    def import_state_json_once(self, path: Path) -> None:
        if self.get_meta("legacy_imported_at") is not None or not path.exists():
            return
        value = json.loads(path.read_text(encoding="utf-8"))
        now = time.time()
        with self.db:
            for pr_number, pr in value["prs"].items():
                self.db.execute(
                    """INSERT OR IGNORE INTO pr_heads(
                           repo,pr_number,head,status,covered,first_seen_at,last_seen_at,
                           stable_after,seen_followups_json,last_error
                       ) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                    (
                        self.repo,
                        int(pr_number),
                        pr["head"],
                        "open",
                        int(bool(pr["covered"])),
                        now,
                        now,
                        now,
                        json.dumps(pr["seen_followups"]),
                        "imported from state.json",
                    ),
                )
            for job_id, job in value["jobs"].items():
                self.db.execute(
                    """INSERT OR IGNORE INTO jobs(
                           job_id,repo,pr_number,head,kind,event_key,event_json,status,
                           attempts,pid,log_path,last_error,created_at,updated_at
                       ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        job_id,
                        self.repo,
                        int(job["pr"]),
                        job["head"],
                        job["kind"],
                        job.get("event_key"),
                        json.dumps(job["event"]) if "event" in job else None,
                        "circuit_open",
                        int(job["attempts"]),
                        job.get("pid"),
                        job.get("log"),
                        "imported from state.json with its circuit open",
                        now,
                        now,
                    ),
                )
        self.set_meta("legacy_imported_at", utc_now())
        self.set_meta("initialized", str(bool(value["initialized"])).lower())


class Monitor:
    def __init__(self, args: argparse.Namespace) -> None:
        self.args = args
        self.state_dir = Path(args.state_dir).expanduser()
        self.heartbeat_path = self.state_dir / "heartbeat.json"
        self.event_log = self.state_dir / "events.jsonl"
        self.jobs_dir = self.state_dir / "jobs-v2"
        self.evidence_dir = self.state_dir / "evidence"
        for directory in (self.state_dir, self.jobs_dir, self.evidence_dir):
            directory.mkdir(parents=True, exist_ok=True)
        self.store = Store(self.state_dir / "monitor.sqlite3", self.state_dir / "state.json", args.repo)
        self.processes: dict[str, subprocess.Popen[str]] = {}
        self.stop = False
        self.markdown = MarkdownIt("commonmark")

    def close(self) -> None:
        self.store.close()

    def log(self, kind: str, **fields: Any) -> None:
        event = {"at": utc_now(), "event": kind, **fields}
        append_event(self.event_log, event)
        print(json.dumps(event, separators=(",", ":"), sort_keys=True), flush=True)

    def gh_json(self, endpoint: str) -> Any:
        return run_json([self.args.gh, "api", endpoint])

    def review_job_id(self, pr: dict[str, Any]) -> str:
        return f"{self.args.repo}#{pr['number']}@{pr['head']}"

    def fetch_snapshot(self) -> tuple[str, list[dict[str, Any]]]:
        auth = self.gh_json("user")["login"]
        raw_prs = gh_pages(self.args.gh, f"repos/{self.args.repo}/pulls?state=open&per_page=100")
        snapshot: list[dict[str, Any]] = []
        for raw in raw_prs:
            author = raw["user"]["login"]
            if author.casefold() == auth.casefold() or raw["draft"]:
                continue
            number = int(raw["number"])
            head = raw["head"]["sha"]
            reviews = gh_pages(self.args.gh, f"repos/{self.args.repo}/pulls/{number}/reviews?per_page=100")
            issue_comments = gh_pages(self.args.gh, f"repos/{self.args.repo}/issues/{number}/comments?per_page=100")
            inline_comments = gh_pages(self.args.gh, f"repos/{self.args.repo}/pulls/{number}/comments?per_page=100")
            covered = any(review["commit_id"] == head and has_marker(review["body"]) for review in reviews)
            has_any_rpr = any(has_marker(review["body"]) for review in reviews)
            replies = "\n".join(item["body"] for item in [*reviews, *issue_comments, *inline_comments])
            followups: list[dict[str, Any]] = []
            for source, items, time_field in (
                ("issue_comment", issue_comments, "updated_at"),
                ("review_comment", inline_comments, "updated_at"),
                ("review", reviews, "submitted_at"),
            ):
                for item in items:
                    # 已删除账号的评论 user 为 null，它不是 PR 作者的评论
                    if item["user"] is None or item["user"]["login"] != author:
                        continue
                    if not item["body"].strip() or has_marker(item["body"]):
                        continue
                    followups.append(
                        {
                            "source": source,
                            "id": int(item["id"]),
                            "updated_at": item[time_field],
                            "body": item["body"],
                            "url": item["html_url"],
                        }
                    )
            snapshot.append(
                {
                    "number": number,
                    "url": raw["html_url"],
                    "author": author,
                    "head": head,
                    "covered": covered,
                    "has_any_rpr": has_any_rpr,
                    "reply_bodies": replies,
                    "followups": followups,
                }
            )
        return auth, sorted(snapshot, key=lambda item: item["number"])

    def upsert_heads(self, prs: list[dict[str, Any]]) -> None:
        now = time.time()
        current = {(int(pr["number"]), str(pr["head"])) for pr in prs}
        with self.store.db:
            for pr in prs:
                row = self.store.db.execute(
                    "SELECT first_seen_at FROM pr_heads WHERE repo=? AND pr_number=? AND head=?",
                    (self.args.repo, pr["number"], pr["head"]),
                ).fetchone()
                if row is None:
                    self.store.db.execute(
                        """INSERT INTO pr_heads(
                               repo,pr_number,head,url,author,status,covered,has_any_rpr,
                               first_seen_at,last_seen_at,stable_after,seen_followups_json
                           ) VALUES(?,?,?,?,?,'open',?,?,?,?,?,?)""",
                        (
                            self.args.repo,
                            pr["number"],
                            pr["head"],
                            pr["url"],
                            pr["author"],
                            int(pr["covered"]),
                            int(pr["has_any_rpr"]),
                            now,
                            now,
                            now + self.args.debounce_seconds,
                            json.dumps(sorted(event_key(e) for e in pr["followups"])),
                        ),
                    )
                    self.log("head_detected", pr=pr["number"], head=pr["head"], stable_after=now + self.args.debounce_seconds)
                else:
                    self.store.db.execute(
                        """UPDATE pr_heads SET url=?,author=?,status='open',covered=?,has_any_rpr=?,
                               last_seen_at=? WHERE repo=? AND pr_number=? AND head=?""",
                        (
                            pr["url"],
                            pr["author"],
                            int(pr["covered"]),
                            int(pr["has_any_rpr"]),
                            now,
                            self.args.repo,
                            pr["number"],
                            pr["head"],
                        ),
                    )
                self.store.db.execute(
                    """UPDATE pr_heads SET status='stale',last_seen_at=?
                       WHERE repo=? AND pr_number=? AND head<>? AND status='open'""",
                    (now, self.args.repo, pr["number"], pr["head"]),
                )
                self.store.db.execute(
                    """UPDATE jobs SET status='stale',updated_at=?,last_error='head changed'
                       WHERE repo=? AND pr_number=? AND head<>?
                         AND status IN ('ready','circuit_open')""",
                    (now, self.args.repo, pr["number"], pr["head"]),
                )
            for row in self.store.db.execute(
                "SELECT pr_number,head FROM pr_heads WHERE repo=? AND status='open'",
                (self.args.repo,),
            ).fetchall():
                identity = (int(row["pr_number"]), str(row["head"]))
                if identity not in current:
                    self.store.db.execute(
                        "UPDATE pr_heads SET status='closed',last_seen_at=? WHERE repo=? AND pr_number=? AND head=?",
                        (now, self.args.repo, *identity),
                    )
                    self.store.db.execute(
                        """UPDATE jobs SET status='cancelled',updated_at=?,last_error='PR no longer eligible'
                           WHERE repo=? AND pr_number=? AND head=?
                             AND status IN ('ready','circuit_open')""",
                        (now, self.args.repo, *identity),
                    )

        # 头提交变化或 PR 关闭时立即终止对应的 worker，reap() 记录最终状态
        for row in self.store.db.execute(
            "SELECT job_id,pr_number,head,pid FROM jobs WHERE status='running'"
        ).fetchall():
            if (int(row["pr_number"]), str(row["head"])) in current:
                continue
            proc = self.processes.get(row["job_id"])
            if proc is not None:
                if proc.poll() is None:
                    proc.terminate()
            elif row["pid"] is not None and pid_alive(int(row["pid"])):
                os.kill(int(row["pid"]), signal.SIGTERM)
            self.log("worker_cancel_requested", job_id=row["job_id"], reason="head changed or PR closed")

    def write_evidence(self, pr: dict[str, Any], raw: dict[str, Any], diff: str) -> Path:
        number = int(pr["number"])
        stem = safe_name(f"{self.args.repo}_{number}_{pr['head']}")
        diff_path = self.evidence_dir / f"{stem}.diff"
        meta_path = self.evidence_dir / f"{stem}.json"
        atomic_text(diff_path, diff)
        atomic_json(
            meta_path,
            {
                "repo": self.args.repo,
                "pr": number,
                "head": pr["head"],
                "url": pr["url"],
                "title": raw["title"],
                "body": raw["body"],
                "diff_path": str(diff_path),
                "diff_bytes": len(diff.encode("utf-8")),
                "diff_sha256": hashlib.sha256(diff.encode("utf-8")).hexdigest(),
                "preflighted_at": utc_now(),
            },
        )
        return meta_path

    def fetch_diff(self, number: int) -> tuple[str | None, str | None]:
        # GitHub 拒绝提供超出文件数或行数上限的 diff 时返回 HTTP 406，这是记录下来的结果；其他失败直接抛出
        completed = subprocess.run(
            [
                self.args.gh,
                "api",
                "-H",
                "Accept: application/vnd.github.v3.diff",
                f"repos/{self.args.repo}/pulls/{number}",
            ],
            capture_output=True,
            timeout=self.args.preflight_timeout,
            check=False,
        )
        stderr = completed.stderr.decode("utf-8", errors="backslashreplace").strip()
        if completed.returncode != 0:
            if "(HTTP 406)" in stderr:
                return None, stderr
            raise RuntimeError(f"gh api diff for PR #{number}: exit {completed.returncode}\nstderr: {stderr}")
        # diff 里不是 UTF-8 的字节转义成文本，原样进入 evidence 和 prompt
        return completed.stdout.decode("utf-8", errors="backslashreplace"), None

    def preflight_review(self, pr: dict[str, Any], auth: str) -> tuple[str, str | None, Path | None]:
        number = int(pr["number"])
        raw = self.gh_json(f"repos/{self.args.repo}/pulls/{number}")
        if raw["state"] != "open" or raw["draft"]:
            return "ineligible", "PR is closed or draft", None
        if raw["head"]["sha"] != pr["head"]:
            return "ineligible", "head changed during preflight", None
        if raw["user"]["login"].casefold() == auth.casefold():
            return "ineligible", "the authenticated user's own PR", None
        if raw["changed_files"] == 0:
            return "ineligible", "the PR changes no files", None
        reviews = gh_pages(self.args.gh, f"repos/{self.args.repo}/pulls/{number}/reviews?per_page=100")
        if any(review["commit_id"] == pr["head"] and has_marker(review["body"]) for review in reviews):
            return "covered", "the exact head is already covered", None
        diff, refused = self.fetch_diff(number)
        if diff is None:
            return "manual", f"GitHub does not serve this diff; review it in chunks with /review-pr: {refused}", None
        if not diff.strip():
            raise RuntimeError(f"GitHub returned an empty diff for PR #{number}, which changes {raw['changed_files']} files")
        meta_path = self.write_evidence(pr, raw, diff)
        diff_bytes = len(diff.encode("utf-8"))
        if diff_bytes > self.args.max_single_review_bytes:
            return (
                "manual",
                f"diff is {diff_bytes} bytes, above {self.args.max_single_review_bytes}; review it in chunks with /review-pr",
                meta_path,
            )
        return "ready", None, meta_path

    def apply_preflight(
        self,
        pr: dict[str, Any],
        existing: sqlite3.Row | None,
        status: str,
        detail: str | None,
        evidence: Path | None,
    ) -> None:
        now = time.time()
        job_id = self.review_job_id(pr)
        if status in ("ready", "manual"):
            job_status = "ready" if status == "ready" else "circuit_open"
            # GitHub 不提供 diff 时没有 evidence 文件
            evidence_path = None if evidence is None else str(evidence)
            with self.store.db:
                if existing is None:
                    self.store.db.execute(
                        """INSERT INTO jobs(
                               job_id,repo,pr_number,head,kind,status,evidence_path,last_error,created_at,updated_at
                           ) VALUES(?,?,?,?,'review',?,?,?,?,?)""",
                        (job_id, self.args.repo, pr["number"], pr["head"], job_status, evidence_path, detail, now, now),
                    )
                else:
                    self.store.db.execute(
                        """UPDATE jobs SET status=?,reset_requested=0,evidence_path=?,pid=NULL,
                               lease_owner=NULL,lease_expires_at=NULL,last_error=?,updated_at=? WHERE job_id=?""",
                        (job_status, evidence_path, detail, now, job_id),
                    )
            self.log(f"review_{job_status}", job_id=job_id, pr=pr["number"], head=pr["head"], detail=detail)
            return
        with self.store.db:
            self.store.db.execute(
                "UPDATE pr_heads SET last_error=? WHERE repo=? AND pr_number=? AND head=?",
                (detail, self.args.repo, pr["number"], pr["head"]),
            )
            if existing is not None:
                self.store.db.execute(
                    "UPDATE jobs SET status=?,reset_requested=0,last_error=?,updated_at=? WHERE job_id=?",
                    ("completed" if status == "covered" else "cancelled", detail, now, job_id),
                )
        self.log(f"preflight_{status}", pr=pr["number"], head=pr["head"], detail=detail)

    def reserve_followup(self, pr: dict[str, Any], event: dict[str, Any]) -> None:
        key = event_key(event)
        now = time.time()
        job_id = f"{self.args.repo}#{pr['number']}:{key}"
        with self.store.db:
            self.store.db.execute(
                """INSERT OR IGNORE INTO events(
                       event_key,repo,pr_number,source,source_id,source_updated_at,payload_json,first_seen_at
                   ) VALUES(?,?,?,?,?,?,?,?)""",
                (key, self.args.repo, pr["number"], event["source"], event["id"], event["updated_at"], json.dumps(event), now),
            )
            self.store.db.execute(
                """INSERT OR IGNORE INTO jobs(
                       job_id,repo,pr_number,head,kind,event_key,event_json,status,created_at,updated_at
                   ) VALUES(?,?,?,?,?,?,?,'ready',?,?)""",
                (job_id, self.args.repo, pr["number"], pr["head"], "followup", key, json.dumps(event), now, now),
            )
        self.log("followup_ready", job_id=job_id, pr=pr["number"], event_key=key, observe_only=self.args.observe_only)

    def prepare_jobs(self, auth: str, prs: list[dict[str, Any]]) -> None:
        now = time.time()
        initialized = self.store.get_meta("initialized") == "true"
        for pr in prs:
            head_row = self.store.db.execute(
                "SELECT * FROM pr_heads WHERE repo=? AND pr_number=? AND head=?",
                (self.args.repo, pr["number"], pr["head"]),
            ).fetchone()
            job_id = self.review_job_id(pr)
            if pr["covered"]:
                with self.store.db:
                    self.store.db.execute(
                        """UPDATE jobs SET status='completed',updated_at=?,last_error=NULL
                           WHERE job_id=? AND status IN ('ready','circuit_open')""",
                        (now, job_id),
                    )
            elif now >= float(head_row["stable_after"]):
                existing = self.store.db.execute(
                    "SELECT status,reset_requested FROM jobs WHERE job_id=?",
                    (job_id,),
                ).fetchone()
                # PR 关闭后重新打开，或从 draft 回到可评审状态时，同一个头提交的任务重新做 preflight
                if existing is None or int(existing["reset_requested"]) or existing["status"] in ("cancelled", "stale"):
                    status, detail, evidence = self.preflight_review(pr, auth)
                    self.apply_preflight(pr, existing, status, detail, evidence)
            if initialized and pr["covered"] and pr["has_any_rpr"]:
                seen = set(json.loads(head_row["seen_followups_json"]))
                for event in pr["followups"]:
                    if event_key(event) not in seen:
                        self.reserve_followup(pr, event)
            with self.store.db:
                self.store.db.execute(
                    """UPDATE pr_heads SET seen_followups_json=?
                       WHERE repo=? AND pr_number=? AND head=?""",
                    (json.dumps(sorted(event_key(e) for e in pr["followups"])), self.args.repo, pr["number"], pr["head"]),
                )
        self.store.set_meta("initialized", "true")

    def review_is_durable(self, row: sqlite3.Row, prs: list[dict[str, Any]]) -> bool:
        return any(pr["number"] == row["pr_number"] and pr["head"] == row["head"] and pr["covered"] for pr in prs)

    def reply_is_durable(self, row: sqlite3.Row, prs: list[dict[str, Any]]) -> bool:
        marker = f"{REPLY_MARKER_PREFIX}{row['event_key']} -->"
        rprb_marker = f"{RPRB_REPLY_MARKER_PREFIX}{row['event_key']} -->"
        return any(
            pr["number"] == row["pr_number"] and (marker in pr["reply_bodies"] or rprb_marker in pr["reply_bodies"])
            for pr in prs
        )

    def wait_for_artifact(self, path: Path, timeout: int = 30) -> bool:
        # codex 退出后最后一条消息的文件可能稍晚才出现
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if path.exists() and path.stat().st_size > 0:
                return True
            time.sleep(1)
        return False

    def validate_review_body(self, body: str) -> tuple[str, str | None, int]:
        expected_header = f"## Codex Code Review ({self.args.review_model}, {self.args.review_effort})"
        if not body.startswith(expected_header + "\n" + RPR_MARKERS[0] + "\n"):
            return "invalid", "review header or marker is missing or not first", 0
        if body.count(RPR_MARKERS[0]) != 1:
            return "invalid", "review marker count is not exactly one", 0
        if "Review by OpenAI Codex via RPR" in body:
            return "invalid", "review contains a visible RPR footer", 0
        tokens = self.markdown.parse(body)
        # 每个严重级别标题开始一段，段内统计 #### 标题和 Origin 行；代码块里的内容不是标题
        sections: list[dict[str, Any]] = []
        for index, token in enumerate(tokens):
            if token.type != "inline":
                continue
            opener = tokens[index - 1]
            if opener.type == "heading_open" and opener.tag == "h3":
                match = SEVERITY_RE.match(token.content)
                if match:
                    sections.append({"severity": match.group(1), "declared": int(match.group(2)), "findings": 0, "origins": []})
                continue
            if not sections:
                continue
            if opener.type == "heading_open" and opener.tag == "h4" and FINDING_RE.match(token.content):
                sections[-1]["findings"] += 1
            elif opener.type == "paragraph_open":
                for line in token.content.split("\n"):
                    origin = ORIGIN_RE.match(line)
                    if origin:
                        sections[-1]["origins"].append(origin.group(1))
        if not sections and "no actionable findings" not in body.casefold():
            return "invalid", "review has neither findings nor an explicit clean verdict", 0
        total = 0
        for section in sections:
            if section["findings"] != section["declared"]:
                return (
                    "invalid",
                    f"{section['severity']} count says {section['declared']}, found {section['findings']} headings",
                    0,
                )
            if len(section["origins"]) != section["findings"]:
                return (
                    "invalid",
                    f"{section['severity']} has {section['findings']} findings but {len(section['origins'])} origins",
                    0,
                )
            total += section["findings"]
        if any(section["severity"] != "Low" and "Pre-existing" in section["origins"] for section in sections):
            return "manual", "a pre-existing Medium+ finding needs Linear triage before posting", total
        return "valid", None, total

    def publish_review_artifact(self, row: sqlite3.Row, artifact_path: Path) -> tuple[str, str | None]:
        if not self.wait_for_artifact(artifact_path):
            return "failed", "the reviewer produced no final-message artifact"
        body = artifact_path.read_text(encoding="utf-8")
        outcome, detail, findings = self.validate_review_body(body)
        if outcome == "manual":
            return "manual", detail
        if outcome == "invalid":
            return "failed", detail
        raw = self.gh_json(f"repos/{self.args.repo}/pulls/{row['pr_number']}")
        if raw["state"] != "open" or raw["draft"] or raw["head"]["sha"] != row["head"]:
            return "stale", "PR head or state changed before the review was posted"
        reviews = gh_pages(self.args.gh, f"repos/{self.args.repo}/pulls/{row['pr_number']}/reviews?per_page=100")
        if any(review["commit_id"] == row["head"] and has_marker(review["body"]) for review in reviews):
            return "completed", "the exact head was already covered"
        body_sha = hashlib.sha256(body.encode("utf-8")).hexdigest()
        # 发布前先打开熔断：发布失败时进程结束，重启后不会再次发布；发布成功后 complete_job 覆盖这个状态
        self.set_job_status(row, "circuit_open", "the detector stopped while posting this review; check the PR, then reset the job")
        # 不带 commit_id 时 GitHub 会把评审挂到发布那一刻的 head 上。作者在这几次请求之间
        # 推了新提交，评审就会记在一个没人看过的 sha 上，prepare_jobs 从此跳过它。
        posted = run_json(
            [
                self.args.gh,
                "api",
                f"repos/{self.args.repo}/pulls/{row['pr_number']}/reviews",
                "-X",
                "POST",
                "-f",
                "event=COMMENT",
                "-f",
                f"commit_id={row['head']}",
                "-F",
                f"body=@{artifact_path}",
            ]
        )
        review_id = str(posted["id"])
        durable = self.gh_json(f"repos/{self.args.repo}/pulls/{row['pr_number']}/reviews/{review_id}")
        if durable["commit_id"] != row["head"] or hashlib.sha256(durable["body"].encode("utf-8")).hexdigest() != body_sha:
            raise RuntimeError(f"posted review {review_id} failed exact-head or body verification")
        with self.store.db:
            self.store.db.execute(
                """INSERT OR REPLACE INTO artifacts(
                       identity,repo,pr_number,head,kind,github_id,body_sha256,verified_at
                   ) VALUES(?,?,?,?,?,?,?,?)""",
                (
                    f"review:{row['repo']}#{row['pr_number']}@{row['head']}",
                    row["repo"],
                    row["pr_number"],
                    row["head"],
                    "review",
                    review_id,
                    body_sha,
                    time.time(),
                ),
            )
        self.log("review_posted", job_id=row["job_id"], review_id=review_id, findings=findings, body_sha256=body_sha)
        return "completed", None

    # 一个没写成的日志只是没有 token 数可读。在这里抛出，reap 就写不下任何状态，
    # 任务永远停在 running，launchd 每十秒重启一次，永远发不出评审。
    def parse_tokens(self, log_path: str | None) -> int | None:
        if not log_path or not Path(log_path).is_file():
            return None
        matches = TOKEN_RE.findall(Path(log_path).read_text(encoding="utf-8"))
        return int(matches[-1].replace(",", "")) if matches else None

    def finish_attempt(self, row: sqlite3.Row, exit_code: int | None, status: str, error: str | None) -> None:
        now = time.time()
        tokens = self.parse_tokens(row["log_path"])
        with self.store.db:
            self.store.db.execute(
                """UPDATE attempts SET finished_at=?,exit_code=?,tokens_total=?,status=?,error=?
                   WHERE job_id=? AND attempt_no=?""",
                (now, exit_code, tokens, status, error, row["job_id"], row["attempts"]),
            )
            if tokens is not None:
                attempt_model = self.store.db.execute(
                    "SELECT model FROM attempts WHERE job_id=? AND attempt_no=?",
                    (row["job_id"], row["attempts"]),
                ).fetchone()[0]
                day = datetime.fromtimestamp(now, timezone.utc).date().isoformat()
                self.store.db.execute(
                    """INSERT INTO usage_daily(day,model,attempts,tokens_total) VALUES(?,?,1,?)
                       ON CONFLICT(day,model) DO UPDATE SET
                         attempts=attempts+1,tokens_total=tokens_total+excluded.tokens_total""",
                    (day, attempt_model, tokens),
                )

    def set_job_status(self, row: sqlite3.Row, status: str, error: str | None) -> None:
        with self.store.db:
            self.store.db.execute(
                """UPDATE jobs SET status=?,updated_at=?,pid=NULL,lease_owner=NULL,lease_expires_at=NULL,
                       last_error=? WHERE job_id=?""",
                (status, time.time(), error, row["job_id"]),
            )

    def complete_job(self, row: sqlite3.Row, exit_code: int | None) -> None:
        now = time.time()
        self.finish_attempt(row, exit_code, "completed", None)
        self.set_job_status(row, "completed", None)
        with self.store.db:
            if row["event_key"] is not None:
                self.store.db.execute("UPDATE events SET handled_at=? WHERE event_key=?", (now, row["event_key"]))
            identity = (
                f"review:{row['repo']}#{row['pr_number']}@{row['head']}"
                if row["kind"] == "review"
                else f"followup:{row['repo']}#{row['pr_number']}:{row['event_key']}"
            )
            self.store.db.execute(
                """INSERT INTO artifacts(
                       identity,repo,pr_number,head,event_key,kind,verified_at
                   ) VALUES(?,?,?,?,?,?,?)
                   ON CONFLICT(identity) DO UPDATE SET verified_at=excluded.verified_at""",
                (identity, row["repo"], row["pr_number"], row["head"], row["event_key"], row["kind"], now),
            )
        self.log("job_completed", job_id=row["job_id"], exit_code=exit_code)

    def open_circuit(self, row: sqlite3.Row, exit_code: int | None, attempt_status: str, error: str) -> None:
        self.finish_attempt(row, exit_code, attempt_status, error)
        self.set_job_status(row, "circuit_open", error)
        self.log("circuit_opened", job_id=row["job_id"], attempts=row["attempts"], exit_code=exit_code, error=error)

    def reap(self, prs: list[dict[str, Any]]) -> None:
        now = time.time()
        current = {(pr["number"], pr["head"]) for pr in prs}
        for row in self.store.db.execute("SELECT * FROM jobs WHERE status='running'").fetchall():
            job_id = row["job_id"]
            proc = self.processes.get(job_id)
            if proc is not None:
                alive = proc.poll() is None
            else:
                alive = row["pid"] is not None and pid_alive(int(row["pid"]))
            if alive:
                if row["lease_expires_at"] is not None and now >= float(row["lease_expires_at"]):
                    if proc is not None:
                        proc.terminate()
                    else:
                        os.kill(int(row["pid"]), signal.SIGTERM)
                    self.log("worker_lease_expired", job_id=job_id)
                continue
            attempt = self.store.db.execute(
                "SELECT artifact_path FROM attempts WHERE job_id=? AND attempt_no=?",
                (job_id, row["attempts"]),
            ).fetchone()
            if attempt is None:
                self.set_job_status(row, "circuit_open", "the worker never started")
                self.log("circuit_opened", job_id=job_id, attempts=row["attempts"], error="the worker never started")
                continue
            if proc is not None:
                del self.processes[job_id]
                exit_code: int | None = proc.returncode
            else:
                # 监控进程重启后拿不到子进程的退出码
                exit_code = None
            if row["kind"] == "review":
                self.reap_review(row, exit_code, Path(attempt["artifact_path"]), prs, current)
            else:
                self.reap_followup(row, exit_code, prs)

    def reap_review(
        self,
        row: sqlite3.Row,
        exit_code: int | None,
        artifact_path: Path,
        prs: list[dict[str, Any]],
        current: set[tuple[Any, Any]],
    ) -> None:
        if (row["pr_number"], row["head"]) not in current:
            self.finish_attempt(row, exit_code, "stale", None)
            self.set_job_status(row, "stale", "head changed or PR closed")
            self.log("job_stale", job_id=row["job_id"])
            return
        if exit_code is not None and exit_code != 0:
            self.open_circuit(row, exit_code, "failed", f"reviewer exited with code {exit_code}")
            return
        if self.review_is_durable(row, prs):
            self.complete_job(row, exit_code)
            return
        outcome, detail = self.publish_review_artifact(row, artifact_path)
        if outcome == "completed":
            self.complete_job(row, exit_code)
        elif outcome == "stale":
            self.finish_attempt(row, exit_code, "stale", detail)
            self.set_job_status(row, "stale", detail)
            self.log("job_stale", job_id=row["job_id"], detail=detail)
        elif outcome == "manual":
            self.open_circuit(row, exit_code, "manual_required", str(detail))
        else:
            self.open_circuit(row, exit_code, "failed", str(detail))

    def reap_followup(self, row: sqlite3.Row, exit_code: int | None, prs: list[dict[str, Any]]) -> None:
        if exit_code == 0 or (exit_code is None and self.reply_is_durable(row, prs)):
            self.complete_job(row, exit_code)
            return
        if exit_code is None:
            self.open_circuit(row, exit_code, "failed", "follow-up worker ended without a durable reply")
        else:
            self.open_circuit(row, exit_code, "failed", f"follow-up worker exited with code {exit_code}")

    def active_count(self) -> int:
        return int(self.store.db.execute("SELECT count(*) FROM jobs WHERE status='running'").fetchone()[0])

    def prompt_for(self, row: sqlite3.Row) -> str:
        event = json.loads(row["event_json"])
        return (
            f"Use $review-pr step 7 to process exactly one PR-author follow-up for {self.args.repo} PR "
            f"#{row['pr_number']}. Event identity: {row['event_key']}. Event URL: {event['url']}. "
            f"Event body: {json.dumps(event['body'])}. Use explicit --repo/-R {self.args.repo} "
            "on gh commands. Do not spawn another worker or start monitoring. Post one deduplicated reply "
            "only when required; otherwise post nothing. Never edit code or PR metadata."
        )

    def static_review_prompt(self, row: sqlite3.Row) -> str:
        if row["evidence_path"] is None:
            raise RuntimeError(f"review job {row['job_id']} has no preflight evidence")
        meta = json.loads(Path(row["evidence_path"]).read_text(encoding="utf-8"))
        diff = Path(meta["diff_path"]).read_text(encoding="utf-8")
        digest = hashlib.sha256(diff.encode("utf-8")).hexdigest()
        if digest != meta["diff_sha256"] or len(diff.encode("utf-8")) != int(meta["diff_bytes"]):
            raise RuntimeError(f"preflight diff size or hash changed for {row['job_id']}")
        # PR 没有描述时 GitHub 返回 null
        pr_body = "" if meta["body"] is None else meta["body"]
        return f"""Review PR #{row['pr_number']} at {meta['url']} at exact head {row['head']}.

Perform a code review only. Analyze the complete embedded diff for correctness,
security, data loss, concurrency, API/behavioral contract violations, missing
error handling, state transitions, URL routing, accessibility, export behavior,
and adherence to supplied conventions. Separate defects introduced by this PR
from pre-existing defects. Do not suggest style-only changes.

Group actionable findings into non-empty severity sections in this exact order:
"### Critical [N]", "### High [N]", "### Medium [N]", "### Low [N]". Number
findings from 1 within each section using "#### 1. Finding title". Every finding
must cite a file and line or diff hunk, explain the failure scenario, give the
correct fix, and contain exactly one line:
"Origin: Introduced by this PR" or "Origin: Pre-existing".

Return review text only. Start with exactly:
## Codex Code Review ({self.args.review_model}, {self.args.review_effort})
<!-- OpenAI Codex via RPR -->

Do not include a visible RPR footer. If no actionable findings exist, say so and
list the areas checked. Do not run commands, invoke skills, spawn agents,
fetch GitHub, modify files, or post artifacts.

PR TITLE:
{meta['title']}

PR BODY:
{pr_body}

COMPLETE DIFF ({meta['diff_bytes']} bytes, sha256 {meta['diff_sha256']}):
{diff}
"""

    # 每次调用 Codex 都带 `--disable apps`：MCP `list_all_tools` 探测可能让进程挂起，
    # 挂起会耗尽任务超时并打开熔断
    def codex_command(
        self,
        kind: str,
        prompt: str | None = None,
        artifact_path: Path | None = None,
    ) -> list[str]:
        if kind == "review":
            # 静态评审：只读、不联网读取仓库、不检出代码；由本进程发布评审结果
            return [
                self.args.codex, "exec",
                "-m", self.args.review_model,
                "-s", "read-only",
                "-c", "approval_policy=never",
                "-c", f"model_reasoning_effort={self.args.review_effort}",
                "--disable", "apps",
                "--ephemeral",
                "--skip-git-repo-check",
                "--output-last-message", str(artifact_path),
            ]
        return [
            self.args.codex, "exec",
            "-m", self.args.coordinator_model,
            "-s", self.args.coordinator_sandbox,
            "-c", "approval_policy=never",
            "-c", f"model_reasoning_effort={self.args.coordinator_effort}",
            "--disable", "apps",
            "--ephemeral",
            "--skip-git-repo-check",
            "-C", str(self.state_dir),
            str(prompt),
        ]

    def launch_claimed(self, row: sqlite3.Row) -> None:
        attempt = int(row["attempts"])
        stem = f"{safe_name(row['job_id'])}.attempt-{attempt}"
        log_path = self.jobs_dir / f"{stem}.log"
        if row["kind"] == "review":
            prompt_path: Path | None = self.jobs_dir / f"{stem}.prompt.txt"
            artifact_path: Path | None = self.jobs_dir / f"{stem}.review.md"
            atomic_text(prompt_path, self.static_review_prompt(row))
            command = self.codex_command("review", artifact_path=artifact_path)
            model = self.args.review_model
            effort = self.args.review_effort
            with log_path.open("a", encoding="utf-8") as output, prompt_path.open("r", encoding="utf-8") as prompt_input:
                # worker 在自己的 session 里运行：监控进程退出时 launchd 结束它的进程组，worker 不受影响
                proc = subprocess.Popen(
                    command,
                    stdin=prompt_input,
                    stdout=output,
                    stderr=subprocess.STDOUT,
                    text=True,
                    start_new_session=True,
                )
        else:
            prompt_path = None
            artifact_path = None
            command = self.codex_command("reply", prompt=self.prompt_for(row))
            model = self.args.coordinator_model
            effort = self.args.coordinator_effort
            with log_path.open("a", encoding="utf-8") as output:
                proc = subprocess.Popen(
                    command,
                    stdin=subprocess.DEVNULL,
                    stdout=output,
                    stderr=subprocess.STDOUT,
                    text=True,
                    start_new_session=True,
                )
        now = time.time()
        with self.store.db:
            self.store.db.execute(
                """UPDATE jobs SET pid=?,log_path=?,lease_owner=?,lease_expires_at=?,updated_at=?
                   WHERE job_id=?""",
                (proc.pid, str(log_path), f"pid:{proc.pid}", now + self.args.job_timeout_seconds, now, row["job_id"]),
            )
            self.store.db.execute(
                """INSERT INTO attempts(
                       job_id,attempt_no,model,effort,pid,log_path,prompt_path,artifact_path,started_at
                   ) VALUES(?,?,?,?,?,?,?,?,?)""",
                (
                    row["job_id"],
                    attempt,
                    model,
                    effort,
                    proc.pid,
                    str(log_path),
                    None if prompt_path is None else str(prompt_path),
                    None if artifact_path is None else str(artifact_path),
                    now,
                ),
            )
        self.processes[row["job_id"]] = proc
        self.log("worker_started", job_id=row["job_id"], job_kind=row["kind"], pr=row["pr_number"], pid=proc.pid, attempt=attempt)

    def dispatch_ready(self) -> None:
        if self.args.observe_only or self.store.get_meta("dispatch_paused") == "true":
            return
        while self.active_count() < self.args.max_workers:
            with self.store.db:
                self.store.db.execute("BEGIN IMMEDIATE")
                row = self.store.db.execute(
                    "SELECT job_id FROM jobs WHERE status='ready' ORDER BY created_at LIMIT 1"
                ).fetchone()
                if row is not None:
                    self.store.db.execute(
                        "UPDATE jobs SET status='running',attempts=attempts+1,updated_at=?,pid=NULL WHERE job_id=?",
                        (time.time(), row["job_id"]),
                    )
            if row is None:
                return
            claimed = self.store.db.execute("SELECT * FROM jobs WHERE job_id=?", (row["job_id"],)).fetchone()
            self.launch_claimed(claimed)

    def maybe_maintain(self) -> None:
        now = time.time()
        last = self.store.get_meta("last_maintenance_at")
        if last is not None and now - float(last) < self.args.maintenance_interval:
            return
        if self.active_count() != 0:
            return
        run_id = self.store.db.execute(
            "INSERT INTO maintenance_runs(started_at,status) VALUES(?,'running')", (now,)
        ).lastrowid
        deleted_rows = 0
        deleted_files = 0
        with self.store.db:
            for sql, cutoff in (
                ("DELETE FROM attempts WHERE finished_at<? AND job_id IN (SELECT job_id FROM jobs WHERE status IN ('completed','stale','cancelled','circuit_open'))", now - self.args.attempt_retention_days * 86400),
                ("DELETE FROM events WHERE handled_at IS NOT NULL AND handled_at<?", now - self.args.event_retention_days * 86400),
                ("DELETE FROM artifacts WHERE verified_at<?", now - self.args.artifact_retention_days * 86400),
                ("DELETE FROM jobs WHERE updated_at<? AND status IN ('completed','stale','cancelled')", now - self.args.job_retention_days * 86400),
                ("DELETE FROM pr_heads WHERE last_seen_at<? AND status<>'open'", now - self.args.job_retention_days * 86400),
            ):
                deleted_rows += self.store.db.execute(sql, (cutoff,)).rowcount
        # 等待派发或正在运行的任务要保留证据的元数据文件和它指向的 diff
        active_evidence: set[str] = set()
        for (evidence_path,) in self.store.db.execute(
            "SELECT evidence_path FROM jobs WHERE status IN ('ready','running') AND evidence_path IS NOT NULL"
        ).fetchall():
            active_evidence.add(str(evidence_path))
            active_evidence.add(json.loads(Path(evidence_path).read_text(encoding="utf-8"))["diff_path"])
        evidence_cutoff = now - self.args.evidence_retention_days * 86400
        for path in self.evidence_dir.iterdir():
            if path.is_file() and str(path) not in active_evidence and path.stat().st_mtime < evidence_cutoff:
                path.unlink()
                deleted_files += 1
        # 每次尝试都在 jobs-v2 下留一份日志、一份评审和一份嵌了完整 diff 的 prompt。
        # 尝试记录本身按 attempt_retention_days 清理，这些文件跟着一起走。
        attempt_cutoff = now - self.args.attempt_retention_days * 86400
        live_attempts: set[str] = set()
        for row in self.store.db.execute(
            "SELECT log_path,prompt_path,artifact_path FROM attempts"
        ).fetchall():
            live_attempts.update(str(p) for p in row if p)
        for path in self.jobs_dir.iterdir():
            if path.is_file() and str(path) not in live_attempts and path.stat().st_mtime < attempt_cutoff:
                path.unlink()
                deleted_files += 1
        self.store.db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        self.store.db.execute("PRAGMA incremental_vacuum(200)")
        db_bytes = self.store.path.stat().st_size
        if db_bytes >= self.args.pause_db_bytes:
            self.store.set_meta("dispatch_paused", "true")
            self.log("dispatch_paused_db_size", db_bytes=db_bytes)
        elif db_bytes >= self.args.warn_db_bytes:
            self.log("db_size_warning", db_bytes=db_bytes)
        self.store.db.execute(
            """UPDATE maintenance_runs SET completed_at=?,deleted_rows=?,deleted_files=?,
                   db_bytes=?,status='completed' WHERE id=?""",
            (time.time(), deleted_rows, deleted_files, db_bytes, run_id),
        )
        self.store.set_meta("last_maintenance_at", str(now))

    def heartbeat(self, prs: list[dict[str, Any]]) -> None:
        ready = int(self.store.db.execute("SELECT count(*) FROM jobs WHERE status='ready'").fetchone()[0])
        circuits = int(self.store.db.execute("SELECT count(*) FROM jobs WHERE status='circuit_open'").fetchone()[0])
        atomic_json(
            self.heartbeat_path,
            {
                "at": utc_now(),
                "repo": self.args.repo,
                "mode": "observe-only" if self.args.observe_only else "armed",
                "open_eligible_prs": len(prs),
                "active_workers": self.active_count(),
                "ready_jobs": ready,
                "open_circuits": circuits,
                "model_invoked_for_idle_poll": False,
            },
        )

    def cycle(self) -> None:
        auth, prs = self.fetch_snapshot()
        self.upsert_heads(prs)
        self.reap(prs)
        self.prepare_jobs(auth, prs)
        self.dispatch_ready()
        self.maybe_maintain()
        self.heartbeat(prs)
        self.store.set_meta("last_successful_poll_at", utc_now())

    def reset_jobs(self) -> None:
        for job_id in self.args.reset_job:
            row = self.store.db.execute(
                "SELECT status,kind,repo,pr_number,head FROM jobs WHERE job_id=?", (job_id,)
            ).fetchone()
            if row is None:
                raise RuntimeError(f"cannot reset unknown job {job_id}")
            if row["status"] != "circuit_open":
                raise RuntimeError(f"cannot reset {job_id}: status is {row['status']}, not circuit_open")
            now = time.time()
            with self.store.db:
                if row["kind"] == "review":
                    # 评审任务在下一次轮询时重新做 preflight
                    self.store.db.execute(
                        """UPDATE jobs SET reset_requested=1,pid=NULL,lease_owner=NULL,lease_expires_at=NULL,
                               evidence_path=NULL,last_error='manual reset pending fresh preflight',updated_at=?
                           WHERE job_id=?""",
                        (now, job_id),
                    )
                    self.store.db.execute(
                        "UPDATE pr_heads SET last_error=NULL WHERE repo=? AND pr_number=? AND head=?",
                        (row["repo"], row["pr_number"], row["head"]),
                    )
                else:
                    self.store.db.execute(
                        """UPDATE jobs SET status='ready',pid=NULL,lease_owner=NULL,lease_expires_at=NULL,
                               last_error=NULL,updated_at=? WHERE job_id=?""",
                        (now, job_id),
                    )
            self.log("circuit_reset", job_id=job_id)

    def run(self) -> int:
        lock = (self.state_dir / "monitor-v2.lock").open("w", encoding="utf-8")
        # 另一个监控进程持有锁时 flock 抛出 BlockingIOError，本进程随之退出
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)

        def request_stop(_signum: int, _frame: Any) -> None:
            self.stop = True

        signal.signal(signal.SIGTERM, request_stop)
        signal.signal(signal.SIGINT, request_stop)
        # 意外错误直接结束进程，由 launchd 重新拉起
        self.reset_jobs()
        while not self.stop:
            self.cycle()
            if self.args.once:
                break
            time.sleep(self.args.poll_seconds)
        self.log("monitor_stopped", requested=self.stop)
        self.close()
        lock.close()
        return 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="SQLite-backed detector that dispatches /review-pr work for one repository's open PRs."
    )
    parser.add_argument("--repo", required=True, help="GitHub OWNER/REPO")
    parser.add_argument("--state-dir", required=True)
    parser.add_argument("--poll-seconds", type=int, default=30)
    parser.add_argument("--debounce-seconds", type=int, default=90)
    parser.add_argument("--preflight-timeout", type=int, default=180)
    parser.add_argument("--max-workers", type=int, default=2)
    parser.add_argument("--job-timeout-seconds", type=int, default=1800)
    parser.add_argument("--coordinator-model", default="gpt-5.6-luna")
    parser.add_argument("--coordinator-effort", choices=("low", "medium", "high"), default="low")
    parser.add_argument("--coordinator-sandbox", default="danger-full-access")
    parser.add_argument("--review-model", default="gpt-5.6-sol")
    parser.add_argument("--review-effort", default="high")
    parser.add_argument("--max-single-review-bytes", type=int, default=750 * 1024)
    parser.add_argument("--gh", default="gh")
    parser.add_argument("--codex", default="codex")
    parser.add_argument("--reset-job", action="append", default=[])
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--observe-only", action="store_true")
    parser.add_argument("--maintenance-interval", type=int, default=86400)
    parser.add_argument("--attempt-retention-days", type=int, default=30)
    parser.add_argument("--event-retention-days", type=int, default=90)
    parser.add_argument("--job-retention-days", type=int, default=90)
    parser.add_argument("--artifact-retention-days", type=int, default=365)
    parser.add_argument("--evidence-retention-days", type=int, default=7)
    parser.add_argument("--warn-db-bytes", type=int, default=100 * 1024 * 1024)
    parser.add_argument("--pause-db-bytes", type=int, default=500 * 1024 * 1024)
    return parser.parse_args()


if __name__ == "__main__":
    raise SystemExit(Monitor(parse_args()).run())
