# Dependencies and automatic installation

Run this preflight on first use and when a required tool is missing. Perform
installation as part of the task. Reuse working tools and existing package managers,
keep changes in the current user's scope, and verify real capabilities after
installation. Credentials,
permission denials, unsupported platforms, and failed downloads are separate
blockers; never fabricate credentials or hide failures.

## Required components

| Dependency | When required | Probe | Install when absent |
| --- | --- | --- | --- |
| Node.js LTS and npm/npx | Browser/skill bootstrap | `node --version`, `npm --version` | Existing Node manager: `fnm install --lts` then `fnm use lts-latest`, or `nvm install --lts`. |
| Git and GitHub CLI | GitHub work/dependency retrieval | `git --version`, `gh --version`, `gh auth status` | Existing supported package manager, e.g. `brew install git gh`. Report unavailable admin permission; authentication is separate. |
| Agent Browser and Chromium | Web/Electron and report rendering | `agent-browser --version`, open a disposable page | `npm install -g agent-browser@latest`, then `agent-browser install` |
| gh-image | GitHub screenshot insertion | `gh extension list`, `gh image --version` | `gh extension install drogers0/gh-image` |
| uv | Running this skill's Python scripts: report rendering with Jinja2, frame capture, CDP screenshots, request blocking | `uv --version` | Existing supported package manager, e.g. `brew install uv`. `uv run` installs each script's declared dependencies. |
| ImageMagick 7 | Measuring a capture's brightest pixel ([probe-mock-patterns.md](probe-mock-patterns.md) D6, D7) | `magick --version` | Existing supported package manager, e.g. `brew install imagemagick`. |
| jq | Electron DevTools target cleanup | `jq --version` | Existing supported package manager, e.g. `brew install jq`. |
| FFmpeg | GIF and video assembly and checks ([recording-cdp.md](recording-cdp.md), [recording-native-macos.md](recording-native-macos.md), [recording-ios-simulator.md](recording-ios-simulator.md)) | `ffmpeg -version`, `ffprobe -version` | Existing supported package manager, e.g. `brew install ffmpeg`. |
| ripgrep | Living-log heading index | `rg --version` | Existing supported package manager, e.g. `brew install ripgrep`. |
| publish-artifacts skill | Every published report | Read installed `SKILL.md` | Install the exact dependency below. |
| `wf` executable | Publishing transport | `wf --version`, `wf publish-artifact --help` | Verified stable immutable release; see below. |
| Cloudflare Access credentials | engapp.dev publication | Readability/key-presence check without values | Reuse provisioned credential file; request its location/provisioning if absent. |

When Agent Browser is installed and Chromium is missing, run `agent-browser install`.
On Linux, inspect launch errors before adding OS dependencies;
`agent-browser install --with-deps` may need administrator permission. Load the
installed guide with `agent-browser skills get core` when available.
Native macOS requires a display and Accessibility permission; iOS also requires
Xcode, `xcrun simctl`, and AXe, installed when missing with
`brew install cameroncooke/axe/axe`. An unavailable native platform is a blocker.

## Install publish-artifacts

Use the sibling `publish-artifacts` skill that `wf` installed beside this one. Skills in
this repository ship together through `wf`. Do not install a separate copy or symlink
from `main` with `skills add`: it can shadow the verified version.

If Magi is missing, follow the repository's
[README installation prompt](https://github.com/txehq/txe-workflow#install) for the agents
in use. If an installed Magi has drifted, run `wf doctor` and `wf repair`.
Respect `CLAUDE_CONFIG_DIR` and `CODEX_HOME`. Read the skill from this agent's skills
directory and confirm it invokes `wf publish-artifact` for engapp.dev.

## Install the publisher executable

Use the latest stable immutable release of `txehq/txe-workflow`. The README verifies
Release metadata, `gh release verify`, `gh release verify-asset`, lock digests and archive
paths before installing the binary. Back up any existing `~/.local/bin/wf` first.
If the matching release is already installed and only its executable is missing, restore
the verified binary; a second installation is unnecessary.

If no verified stable release is available, report the dependency as blocked. Do not
clone `main` or compile an unverified checkout as an automatic installation fallback.
Maintainer testing of unpublished changes uses disposable homes, as described in
[local development](https://github.com/txehq/txe-workflow/blob/main/docs/operations/local-development.md).

## Credentials and capability checks

`publish-artifacts` reads `ENGAPP_ARTIFACTS_CRED`, defaulting to
`~/.config/engapp-artifacts/env`. Required keys:

```text
ENGAPP_ARTIFACTS_BASE=https://engapp.dev/artifacts
CF_ACCESS_CLIENT_ID
CF_ACCESS_CLIENT_SECRET
```

The last two lines are key names only. Never write this block as a credential file.
Keep real credentials outside repositories with mode 600, and do not print them;
`wf publish-artifact` reads the file itself. Verify the base is the engapp.dev artifacts
service. The returned link is access-controlled.

A local `wf publish-artifact ... --dry-run` proves CLI syntax. Publishing the actual
acceptance report proves transport and authentication. Test gh-image with an
inspected screenshot and verify its Markdown in the rendered PR/Issue body. See
[github.md](github.md).
