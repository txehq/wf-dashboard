# Structured report rounds on engapp.dev

An acceptance round is a local structured report plus captured evidence, rendered
as a complete HTML page. Each delivery has one published page: the first round
publishes it with `publish-artifacts`, and each repair round replaces it in place.
The publisher stores the page as a static object, so the session itself filters
out gate checks, calculates coverage, renders charts from the data, and records
review decisions in the report.

## Directory layout

Allocate a fresh round directory before every round. `REPORT_DIR` names it in
every command of this skill.

- `.acceptances/`
  - `.gitignore` — contains `*`
  - `<subject-key>/` — `repo-branch`, `pr-123`, `issue-456`, or the caller's subject
    - `acceptance.json` — requirement, the published report URL and its artifact id
    - `<YYYYMMDD-HHMMSS>-<slug>/` — the round directory, `REPORT_DIR`
      - `result.json` — plan, outcomes, provenance, evidence mapping
      - `report.md` — narrative and limits
      - `report.html.j2` — the Jinja2 template for this round's report
      - `report.html` — complete human-readable report
      - `publication.json` — returned URLs and publication time
      - `assets/` — original evidence, including raw data
      - `frames/` — frame sequences captured or decoded for temporal evidence
      - working files of the run: `auth.json`, `body.md`, batch and JavaScript input
        files, `probe-before.diff`, and the `base-worktree/` of a before/after render

Use a collision-free directory name and write `.acceptances/.gitignore` yourself.
Keep evidence out of git. Keep all rounds for one delivery under the same subject
key. If a PR is created later, record its URL in `acceptance.json` and link the
existing report in the PR; do not republish merely to rename the directory.

`acceptance.json` holds the delivery's requirement and its one published report:

```json
{
  "subject": "checkout-recovery",
  "requirement": "A declined payment leaves the cart available for retry.",
  "reportUrl": "https://engapp.dev/artifacts/page/<artifact id>",
  "artifactId": "<artifact id>",
  "pullRequest": "<PR URL when known>"
}
```

## Workflow

1. Write the durable `requirement` and `plan[]` before testing. Each check is a
   user-observable outcome, as the hard rule in [SKILL.md](../SKILL.md) defines.
   Preserve supplied plan ids and requirements; see [plan-format.md](plan-format.md).
2. Capture evidence into `assets/` as you test. Open every screenshot with the
   agent's image-viewing tool before citing it. Listen to audio and inspect
   representative video frames. Keep raw execution records alongside concise
   reasoning for non-visual claims.
3. Fill `cases[]` with the same stable ids as `plan[]`. Use `pass`, `fail`,
   `blocked`, or `uncertain`. A planned item without a result remains visible as
   not run. Missing required evidence makes a case `uncertain`.
4. Calculate the summary from the complete plan, including unexecuted items.
   Overall `pass` requires all required checks to pass with complete evidence;
   use `fail` for a failed required check and `partial` for blocked, uncertain,
   or unexecuted required checks. Report optional failures explicitly too.
5. Write the narrative in the user's language. Automated gates belong in one
   verification sentence.
6. Publish each screenshot and GIF with
   `wf publish-artifact "$REPORT_DIR/assets/<file>" --title "<caption>"`, and write each
   returned `/artifacts/img/<id>` URL with its description to `publication.json`. Then
   write `report.html.j2` in the round directory with the file editing tool, following
   the complete-content contract below, and render it with Jinja2:

   ```bash
   uv run "$SKILL_DIR/scripts/render_report.py" "$REPORT_DIR/report.html.j2" "$REPORT_DIR/report.html" \
     result="$REPORT_DIR/result.json" publication="$REPORT_DIR/publication.json"
   ```

   Each `name=path` argument becomes a template variable: a `.json` file as its
   value, a `.jsonl` file such as `interaction-trace.jsonl` as a list. Pass
   `publication.json` when the round has published images. Autoescaping is on, and a
   missing variable stops the render with its error. The template also gets
   `read_text(path)` for text evidence, `read_markdown(path)` for Markdown evidence
   rendered as HTML with any raw HTML in it escaped, and `data_url(path, mime_type)`
   for embedded audio, video and downloads, all resolving paths inside the round
   directory; `{{ result | tojson }}` embeds the escaped JSON data block.
   Open `report.html` with Agent Browser, check images/media and desktop/mobile
   layout, and inspect screenshots of the rendered report. Fix unreadable or
   missing content before publication. A successful upload cannot prove that the
   report renders.
7. Publish through the installed `publish-artifacts` skill. The first round of a
   delivery creates the report:

   ```bash
   wf publish-artifact "$REPORT_DIR/report.html" --title "<delivery> - acceptance"
   ```

   A repair round replaces it in place with the artifact id recorded in
   `acceptance.json`:

   ```bash
   wf publish-artifact "$REPORT_DIR/report.html" --title "<delivery> - acceptance" --id <artifact id>
   ```

   Use the actual returned URL; a repair returns the URL already in
   `acceptance.json`. A command failure is a publication failure; `--dry-run`
   does not publish.
8. Verify the returned report and media with the authorized Access session or
   service-token client. `wf` requires an authenticated GET 200 after uploading;
   additionally confirm the retrieved document is this round's report and that
   media render. Human readers may need Cloudflare Access email login.
9. After verification, add the report URL and publication time to
   `publication.json`; on the first publication, also record the report URL and
   its artifact id in `acceptance.json`. Follow
   [github.md](github.md) for PR/Issue body updates. End with the complete report
   URL, coverage, failures, and untested scope.

## result.json schema

`result.json` is a local reporting contract. Include it inside the HTML as an
escaped JSON data block or downloadable data URL as well as the readable content.
The example values below must be replaced with actual observations.

```json
{
  "title": "Checkout recovery - acceptance",
  "requirement": "A declined payment leaves the cart available for retry.",
  "createdAt": "2026-09-06T12:00:00Z",
  "subject": "checkout-recovery",
  "branch": "fix/checkout-retry",
  "commit": "<tested commit>",
  "pullRequest": "<PR URL when known>",
  "surfaces": ["web"],
  "plan": [
    {
      "id": "cart-survives-decline",
      "title": "Declined payment preserves the cart",
      "category": "Checkout recovery",
      "required": true,
      "verifier": "agent",
      "method": "Decline a sandbox payment and return to the cart.",
      "expected": "The error is visible and the same cart items remain.",
      "requiredEvidence": ["screenshot", "text"]
    }
  ],
  "cases": [
    {
      "id": "cart-survives-decline",
      "name": "Declined payment preserves the cart",
      "category": "Checkout recovery",
      "surface": "web",
      "status": "pass",
      "verifiedAt": "2026-09-06T12:00:00Z",
      "observation": "The decline message and original cart are visible.",
      "evidence": [
        {"path": "assets/declined.png", "type": "screenshot", "by": "agent-browser", "description": "Decline state with retained cart"},
        {"path": "assets/cart-response.txt", "type": "text", "by": "cli", "description": "Cart response after decline"}
      ]
    }
  ],
  "summary": {
    "total": 1, "passed": 1, "failed": 0, "blocked": 0,
    "uncertain": 0, "notRun": 0, "verdict": "pass"
  }
}
```

Ids are unique in each list; every case maps to a plan item. Evidence paths
resolve inside the current round, must exist and be nonempty, and have explicit
types: `screenshot`, `gif`, `video`, `audio`, `text`, `markdown`, `dom_snapshot`,
or `transcript`. Do not infer `dom_snapshot` from `.txt`. `by` identifies the
producer (`agent-browser`, `cdp`, `cli`, `program`). Status is the builder's
assessment. `verifiedAt` is when the case was run; a case carried forward by a
repair keeps its original value. Surfaces: `web`, `desktop`, `cli`, `mobile`,
`bot`; Electron maps to `desktop`. Verifiers: `program`, `agent`, `llm`.

## Complete-content contract

The page must contain the requirement, tested branch/commit and dirty state when
relevant, PR/Issue association, environment/preconditions, complete plan, each
result and observation, per-check evidence, coverage, verdict, verification
sentence, limitations, and follow-ups. Show planned-but-unexecuted checks.

- Inline CSS and rendering code. Escape user text and JSON; never place raw
  logs, HTML evidence, or untrusted report text into executable markup.
- Publish screenshots/GIFs with `wf publish-artifact <asset> --title <caption>`
  and use the returned `/artifacts/img/<id>` URLs in HTML. Keep descriptions
  and the asset URL mapping in `publication.json`.
- Render text, Markdown, DOM snapshots, and transcripts as readable sections or
  expandable preformatted text, with escaped original content downloadable too.
  No local `file://`, localhost, or relative asset links in the published page.
- `wf` does not accept raw audio/video/JSON/ZIP uploads. Embed original audio
  or video bytes as correctly typed data URLs with native player controls in
  the HTML. Never replace required audio/video with a screenshot. If size
  limits prevent complete media publication, report publication blocked with
  the concrete limit; do not switch to LobeHub or another host.
- Include raw structured data as escaped text or embedded downloads. Test all
  links and media. The report must not need access to the agent's machine.

## Structured visualizations

Use `cases[].datasets` and `cases[].visualizations` for metrics, time series,
comparisons, distributions, or matrices. A dataset has unique `id`, declared
`fields[]` (`key`, `type`), and `rows[]`. Field types are `boolean`, `category`,
`number`, `string`, `temporal`; rows contain declared keys and scalar/null values.
Keep inline summaries review-sized (at most 10,000 rows) and retain raw CSV/JSON
as evidence.

A visualization declares unique `id`, `version: 1`, `type`, `dataset`, `title`,
and `encoding`. Each `type` takes these `encoding` fields:

| Type | Encoding |
| --- | --- |
| `metric-comparison` | `label`, `before`, `after` |
| `line-chart` | `x`, nonempty `series[]` with `field` |
| `bar-chart` | `category`, nonempty `series[]` with `field` |
| `scatter-plot` | `x`, `y`, optional `color`/`label` |
| `heatmap` | `x`, `y`, `value` |
| `table` | optional `columns[]` and `highlights[]` |

Declarations do not render themselves. Produce a self-contained chart with
accessible labels and a table of values, or an HTML table when sufficient.
Never claim a server renderer processed them. For scientific/exportable charts
use a standard plotting tool and retain source data and the generated artifact.

## Before/after comparison pairs

Use one view in two states, with the same `comparison.id` and exactly one
`before` and one `after`. Sequential steps are captioned evidence. Render labels
explicitly in HTML.

```json
[
  {"path": "assets/before.png", "type": "screenshot", "by": "agent-browser", "comparison": {"id": "cart", "role": "before", "layout": "horizontal", "label": "Before decline"}},
  {"path": "assets/after.png", "type": "screenshot", "by": "agent-browser", "comparison": {"id": "cart", "role": "after", "layout": "horizontal", "label": "After decline"}}
]
```

Use `horizontal` for side-by-side comparison, `vertical` to preserve width;
stack at narrow widths. Never silently drop one half.

## Repairs and coverage

Every required evidence type must be present on its check, readable, and included
in the page. Count coverage by plan item. Non-visual claims need both reasoning
and execution artifacts in this round. Review title/category/method for gate
checks before publication; the static transport performs no semantic validation.

Read `acceptance.json`, the previous round's `result.json` and `publication.json`, and
explicit reviewer decisions before a repair. Preserve stable ids. Carry accepted
unchanged checks forward: copy their evidence files into this round's `assets/`, copy
their image URLs into this round's `publication.json`, and keep their `verifiedAt`
date; do not claim to have rerun them.
The repair round's report is the complete current state of the delivery, and
step 7 republishes it at the URL recorded in `acceptance.json`.

If credentials/network block publication, keep the complete local round, report
verification and publication separately, and resume publishing the same unchanged
evidence when access returns. Never mark upload failures as successful delivery.
