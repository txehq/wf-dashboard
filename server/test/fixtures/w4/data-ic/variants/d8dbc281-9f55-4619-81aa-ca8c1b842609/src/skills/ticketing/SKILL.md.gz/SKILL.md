---
name: ticketing
description: "Stage 4 of /lfg — connect to Linear, search what already exists, decide per work item whether to update an existing ticket, relate to one, or create a new one; split new work so that dependent pieces share a ticket and independent pieces get their own, write each from the ticket template, file the epic and issues with estimates and recommended assignees from Linear history, record Tickets.md, then stop at the dispatch gate and, on \"go\", dispatch /ic lanes wave by wave. Use after /plan locked a plan, or when someone says \"ticket this\", \"file the tickets\", \"break this into issues\", \"create the Linear issues\"; invoke it proactively, saying so in one line, when a locked plan exists and no tickets do. Not for scoping, research or planning."
---

# /ticketing — reconcile with Linear, split by dependency, file, stop at the gate

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/LFG Session.md` (WF-LFG,
stage 4 and the dispatch gate of decision log #28 — the corpus has no separate node), with
the ticketing semantics in `Project Magi/Workflow/System Design.md` §1–2. **Question
bank:** Phases 4-ext
and 5 of [`skills/interview/references/question-bank.md`](../interview/references/question-bank.md).

## Contract — what goes in, what comes out

| | |
|---|---|
| **In** | the locked plan in the feature's master document (`Research.md` or `System Design.md`) and `Brief.md`; Linear, through the agent's MCP |
| **Out** | a Linear epic (project or parent issue) whose issues are each *updated*, *related* or *created*; `Project <Product>/Features/<slug>/Tickets.md` recording the reconciliation, the map and the DAG; the execution plan presented at the gate; on "go", dispatched `/ic` lanes |
| **Next** | `/ic`, per ticket — by a person, or by the lanes this skill dispatches |

## When this skill starts

- **On request:** `/ticketing`, or "ticket this", "file the tickets", "break this into
  issues", "create the Linear issues".
- **From `/lfg`:** as stage 4, with the master document's path.
- **Proactively:** a locked plan exists and no tickets do. Say "running /ticketing" and begin.
- **Not** without a locked plan → `/plan`; tickets cut from a draft are tickets cut twice.

## 0. Connect to Linear, and learn the team's shape

Use whichever Linear MCP this session has — `capso-linear`, or a `linear` server the person
configured themselves — and prove it with one read of the team list before anything else.
Reuse the existing server name; do not add one. **Not authenticated is a stop**: say which
server you tried and what it returned, and wait. `capso-linear` logs in through the browser on
first use, so the fix is usually to complete that page once; a server the person added is
theirs to reconnect. For a missing `capso-linear`, follow `/install-manager`.

Then read what the tickets will have to fit: the **team** and its **workflow states**, the
**project or parent issue** that is this feature's epic (the brief or research may name it;
otherwise it is created in §4), the **labels** the team uses for areas, and the **estimate
scale** (points, t-shirt, or none).

## 1. Search first — what already exists

Before writing anything, search for every part of the plan and for the feature as a whole.
Query Linear by the part's outcome in the team's words, by the feature slug, by the labels and
project, by the module or area names the plan touches — open tickets and those closed in the
last few months — and grep the vault's synced `Linear Issues/` folder. Then classify each hit
against each part:

| the existing ticket… | decision | what happens to it |
|---|---|---|
| **is** this work — same outcome, open, perhaps stale or thinner than the plan | **update** | keep its id; rewrite its description to the template with the plan's criteria, toolchains and dependencies, so it shows only the current state |
| **overlaps** partially, or is a prerequisite or a consequence | **relate** | leave its scope alone; link it (`blocked by`, `blocks`, `related`) and reference it from the new ticket's dependencies |
| covers **none** of it | **new** | written in §3, created in §4 |
| **conflicts** — already being done another way, or Done with a different outcome | **surface** | not yours to override: put it to the user with the two ways out before filing anything that touches it |

Every part ends with exactly one decision, and the table of them is the first section of
`Tickets.md`. A duplicate ticket is the failure this section exists to prevent; an
over-eager *update* that swallows someone's open work is the other one.

## 2. Split — dependent together, independent apart

**Work that depends on other work in this feature shares a ticket; work that can proceed
independently gets its own.** A ticket is a lane; lanes run in parallel; a dependency between
two lanes is a wait.

1. Build the dependency graph of the plan's parts.
2. Each **connected component** of that graph is a candidate ticket — the pieces that need
   each other land together and are reviewed together.
3. Components that do not touch are **separate tickets**, and they are the parallelism the
   gate will offer.
4. A component that does not fit **one PR that one person finishes in a bounded stretch**
   (WFR-007: one ticket, one merge) is cut at its narrowest dependency edge into a chain,
   with `blocked by` set and the reason recorded. Aim each ticket at under 500 changed lines,
   generated files and lock files aside, and under 15 changed functions.

Then check the cut with the bank's Phase 4-ext, goal thought and never shown: the first
ticket is the smallest slice that shows value (T1); foundations are genuine (T2); the graph is
explicit (T3); each ticket has an exact outcome and an exact out-of-scope, and names behaviour
(T4); its scenarios are testable (T5); cross-cutting work — migrations, backfills,
observability, rollout controls, docs, cleanup — is visible, in a ticket or tracked
separately (T6); release gates are separated from implementation order (T7); external
blockers are named (T8). T9's confirmation of the map is the gate in §5. Where a Phase 4-ext
check disagrees with the split rule above, the split rule decides the cut.

## 3. Write each ticket

Write each ticket so an IC needs no other document. **Write the description from the
[ticket template](references/ticket-template.md)**, the body a team installs as its Linear issue
template, filled from the plan:

1. **Background** — the complete story: the problem the part solves, who hits it, its urgency,
   and the brief, epic or incident it comes from.
2. **Goals** — the user story this ticket delivers.
3. **Scope** — the slice boundary: what this ticket does, and what it leaves to a sibling or a
   follow-up.
4. **Acceptance criteria** — inherited from the part, each naming the check that proves it
   (E2E, integration or unit test, visual comparison, measurement); `/ic` builds its checklist
   from this.
5. **Expected artifacts** — what the ticket leaves behind: the PR, its tests, the evidence
   `/acceptance` must publish, and any docs, migrations or dashboards.

**Acceptance criteria decide whether the ticket is done.** Write them from the whole
requirement this ticket carries, and make them exhaustive: every test that must pass, each
naming the scenario it verifies, e.g. the normal path, the boundaries, the error cases. The
epic is a ticket too: its criteria verify the feature as a whole, every requirement it carries
met together.

Then one more section, **Planning notes**, for what `/ic` reads and the template has no home
for:

- **References** — the plan's part, the research references, the code areas touched, the
  decisions that bind.
- **Toolchains and infrastructure** — in the words `wf readiness --need` accepts.
- **Dependencies** — tickets that must merge first and those waiting on this; also set as
  Linear relations; the wave.
- **Estimate and recommended assignee** — one line of reasoning each (below).
- **Rigor** — review depth and the authority ceiling from the brief.
- **Open questions** — what the IC must not settle alone.

Last, **Prior research**: the paths of the brief, `Research.md` and any other document behind
the ticket.

Fields outside the description: an imperative **title** stating the outcome, in the team's
prefix convention; **project or parent** = the epic; **labels** for the area; **priority**;
the **estimate** field; the relations from *Dependencies*. Nothing lives only in a comment.

**Estimate and assignee come from Linear's history.** Read the team's issues completed in
roughly the last ninety days and those In Progress now — assignee, labels, project, estimate,
cycle time. The **estimate** is in the team's scale, calibrated on comparable completed
tickets, written to the estimate field with one line of reasoning in the description. The **recommended assignee** is the person with the most recent completed
work in this area *and* the lightest current load, with a runner-up — a recommendation
carried in the description and the gate. **Do not set the assignee yourself**; a human
confirms it at the gate, or a dispatched lane claims the ticket through `/ic`.

## 4. File, and record

Create the epic if none exists; then, in dependency order, apply the §1 decisions — updates,
relations, creations — so that every `blocked by` points at a ticket that already has an id.
Re-read each written issue to catch a description the API truncated or a relation it dropped.

Write the reconciliation table, the ticket map, the dependency DAG, the estimates and the
recommendations to `.ticketing/tickets.md`, creating `.ticketing/` with a `.gitignore`
containing `*` before its first file, and file it:

```bash
wf obsidian --kind tickets --product "<Product>" --feature "<slug>" --file .ticketing/tickets.md \
  --title "<feature> — tickets" --ticket <epic id>
```

Comment on the epic with the vault path.

## 5. The dispatch gate — always stop here

Present the execution plan and **stop**. The gate is the last human question before execution, and
the one moment the `/ic` boundary surfaces in solo mode; team mode has it too, where humans
decide when to enter. It is Phase 5 of the bank (M1–M4): authorization to leave planning, the
delivery conventions that cannot be inferred, the mutation boundary, and the predefined
escalation. Present:

1. the **reconciliation** — which tickets were updated, related, created;
2. the **dependency DAG** — every ticket, its estimate, its recommended assignee, what blocks it;
3. the **waves** — a wave holds only mutually independent tickets, and everything a wave
   depends on is merged before it starts — and the **concurrency cap** of 3 lanes;
4. per ticket: the branch it will get (`<handle>/txe-<n>-<slug>`) and the tools `/readiness`
   will be asked for.

The user answers once:

| answer | it means |
|---|---|
| **go** | dispatch every wave in order, no further asks |
| **go wave N** | dispatch wave N only, then stop and present again |
| nothing / anything else | a **designer-only session**: tickets are filed with their recommendations; execution starts later, by the people named or anyone else, through `/ic` |

Saying nothing is a complete outcome. Report where things stand and end.

## 6. Dispatch (solo mode) — sub-agents running the `/ic` path

"Go" means: for each ticket in the current wave, start one sub-agent whose whole instruction
is `/ic` for that ticket — the same implementation a human IC runs. Each lane is seeded with
the brief, the plan's part and the ticket; it gets its **own worktree and branch**, cut fresh
after the previous wave's merges have landed, and its ownership is recorded before any work
happens in it. Each lane builds and tests locally and runs the review loop inside `/ic`; lane
state is tracked through Linear status and the PRs.

- no more lanes run at once than the cap the gate authorized;
- a **failed lane parks**: a comment on the ticket saying what happened and where the branch
  is; the lane stops; its siblings continue;
- **no asks between waves**: a question that arises mid-wave is parked on its ticket for the
  LFG;
- a wave is finished when every lane's PR is ready for review and merged, or parked. Then cut
  the next wave and report.

## Not this

- Deciding what to build → `/interview`, `/research`, `/plan`.
- Building one ticket → `/ic`.
- Handing a ticket to a person → `/handover`.
