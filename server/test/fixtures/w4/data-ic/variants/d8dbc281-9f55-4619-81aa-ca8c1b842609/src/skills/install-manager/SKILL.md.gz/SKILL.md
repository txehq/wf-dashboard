---
name: install-manager
description: Inspect, repair and roll back this machine's Capso workflow install — which release is active, which coding agents are carrying it, which components have drifted, what was backed up and how to restore it. Use when a skill or MCP server is missing or behaves like an old version, when history search or ctx is missing or `wf doctor` reports `capso.ctx.binary`, a `CTX-` finding or `WF-PATH`, when a session start reports something is out of date, after a machine or agent reinstall, or when someone asks what version of the workflow they are running.
---

# /install-manager — the workflow's own control surface

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/LFG Session.md` (WF-LFG).
Where this file and the spec disagree, the spec wins: update this file to match it.

`/lfg` is the architect's session entry point — scoping, planning, ticketing, the dispatch
gate — and installs nothing.

`wf` is the local manager for everything this organization ships into a coding agent:
skills, rules, subagents, the global prompt block, hooks, MCP servers, environment and the
readiness profiles — copied into every agent it manages (Claude Code, Codex, Cursor, Kiro,
ZCode, OpenClaw). It installs them, keeps them current, and can say exactly what it changed and
put it back.

| Command | What it does |
|---|---|
| `wf status` | what is active, what has drifted, what needs a reload |
| `wf doctor` | the same, plus everything that would block a repair |
| `wf repair` | put the organization's version back |
| `wf agents` | which agents are here, and which ones `wf` manages |
| `wf backup list` | every file `wf` has overwritten, newest first |
| `wf backup restore <id>` | put one of them back |
| `wf rollback --to <ver>` | return the whole machine to an earlier release |

Add `--json` to any of them for a stable envelope.

## Reading `wf status`

Each component reports exactly one state, and each state names what to do:

| state | what it means | what to do |
|---|---|---|
| `current` | matches the active release | nothing |
| `staged` | verified on disk and waiting for activation | inspect `wf status`; run `wf sync` to converge |
| `reload_required` | the files are new, this session loaded the old ones | start a new session |
| `update_pending` | a newer release exists; the updater is fetching it | nothing; it finishes on its own |
| `drifted` | the organization's copy was edited, deleted or disabled | `wf repair` |
| `conflict_replaced` | something of yours had the same name and was backed up first | `wf backup list` if you want it back |
| `credential_missing` | installed, and a credential it needs is unset | set the named variable in your shell configuration and reopen the terminal |
| `unverified` | installed; whether its browser login was ever completed was not observed | make one real read through the server |
| `stale` | the machine has not reached the release in a while | check the network; it keeps working meanwhile |
| `blocked` | a required component cannot be used, including an untrusted Codex hook | `wf doctor`; complete the named repair or `/hooks` trust step |
| `unsupported` | agent, version or platform is outside the release range | use a supported agent version or platform |

A component the person declined is not in this table, because it is not a state a component is
in — it is a decision about whether to have one. `wf doctor` lists those separately, under
没有检查，你要求不装的, with the date it was decided and `wf mcp unskip <component>` as the way
back. They never appear under 需要处理, raise no finding and print nothing at session start:
that is what being declined means.

```bash
wf mcp survey --json          # what this machine already reaches, and what was declined
wf mcp skip <component> --agent <agent> --reason "<why>"
wf mcp unskip <component>     # then `wf repair` to install it
```

`unskip` removes the decision and installs nothing by itself — `wf sync` on a version already
active never reaches the object check, so `wf repair` is the command that puts the server back.

`credential_missing` is a degraded capability, and a session still starts.

`unverified` is the absence of an observation, and a session starts on it too. It is the
answer for a `credentials.mode: agent-oauth` component
([#40](https://github.com/txehq/txe-workflow/issues/40)): the server logs in through a browser
and keeps the token in its own store, which `wf` does not open. Both shipped MCPs are that
shape, so two `unverified` components are expected on every machine.

`wf doctor` reports only on the two servers `wf` installed (WFR-016). A machine can hold three
connections to Linear — the bridge, one the person added, one their account carries — and the
report covers the bridge. When a Linear tool fails, first find out *which server answered*.

For OAuth login and service connectivity, probe from each agent with that server's own tools,
whatever state `wf doctor` shows.

The stored row is written by the last full sync, so it can be older than the machine. Session
start therefore asks the credential question again before it warns, using the same rule
`wf doctor` applies (`wf_agents::credentials::credential_status`). It keeps the warning only
for the answer "this named variable is unset", so a surviving warning names a real unset
variable. "Nothing here could be checked", which an `agent-oauth` component always answers,
drops it. **Do not read silence as a login found**: a stale `credential_missing` row can go
quiet without anything having been observed. `wf doctor` is where that machine reads
`unverified`.

## Doctor findings outside the table: `WF-PATH`, `MCP-ORPHAN` and ctx's

None of them means the workflow install failed or rolled back.

**`WF-PATH`** — the directory holding `wf` is not on `PATH`. Hooks and the `wf-history` MCP
server are written with `wf`'s absolute path and keep working. Skills tell a session to run
`wf …` in its shell, and those commands fail. Put `~/.local/bin` on `PATH`, backing the shell
configuration up first, then start a new session.

**`MCP-ORPHAN`** — an `mcp-remote` bridge of `capso-linear` or `capso-rackspace-spot` is still
running after the agent that started it went away, typically one that was waiting for its
browser sign-in when a `claude -p` or `claude mcp get` ended. Only bridges launched from the
entries `wf` wrote are reported: each carries `WF_MCP_COMPONENT=<component>` in its
environment, and a bridge to the same service without it is the person's (WFR-016). It holds that service's sign-in,
and every bridge started after it waits on it and prints no page, so the server never connects.
The finding names the processes; run the `kill` command it gives, then sign in again as
`/install` step 5 describes.

**`capso.ctx.binary`** (agent `wf`) — the last convergence of ctx recorded an error, and
`wf status` reads `blocked` until it is lifted. ctx converges as a step of its own, outside the
release apply, so a ctx problem leaves the workflow in place. The finding's text names the fix
for the recorded code. When `~/.local/bin/ctx` is missing, differs from the pinned bytes, or its
setup has not finished, it is a `NOTE` instead, and the fix is `wf install`.

| code | what happened | what to do |
|---|---|---|
| `CTX-HANDOFF` | the installed ctx has a daemon, and its handoff did not report a quiescent installation; it was left in place (a ctx before 1.0 has no daemon and is replaced without one) | the manual step below |
| `CTX-FOREIGN` | `~/.local/bin/ctx` is absent and another ctx is on `PATH`; `wf` does not install a second copy beside a live one | run that ctx's own `ctx daemon disable --prepare-uninstall --format=json`; once it exits 0 with every boolean in its receipt true, remove that ctx with the tool that installed it (Homebrew, mise, cargo), then `wf install` |
| `CTX-INTEGRITY` | a download did not match the lock and GitHub's digest for it; nothing ran, the file is deleted, the existing ctx is untouched | nothing: it is retried automatically, or `wf install` now; if it repeats, report it — ctx's releases are not immutable, and only a new `wf` release can pin different bytes |
| `CTX-SETUP` | a lifecycle command failed after the binary was in place | nothing: the first session start after the hourly throttle retries it, and `wf install` retries now; the command logs are under `ctx/` in `wf`'s state directory, and `wf history doctor --format json` shows ctx's own diagnosis |
| `CTX-RUNTIME` | the pinned ONNX Runtime archive could not be expanded beside ctx | nothing: retried like `CTX-SETUP`, or `wf install` now |

ctx's own verdict on itself, read live by `wf doctor`:

| code | what it means | what to do |
|---|---|---|
| `CTX-DAEMON` | ctx's daemon is disabled, not running, or its heartbeat is stale; searches fail with `start or recover daemon`, and the MCP tools answer `source_unavailable` | `wf history index mode auto`, then `wf doctor` again |
| `CTX-SEMANTIC` | `ctx semantic status` reports `failed` — `model_load_failed` means the ONNX Runtime is missing — and search is keyword-only | `wf install`, which puts the pinned runtime in place and enables semantic search again |
| `CTX-HEALTH` | `ctx doctor --format json` gave no answer | `wf install` |

A `CTX-HANDOFF` or `CTX-FOREIGN` recorded by an older `wf` is retried once by the next session
start after an update, so a machine an older `wf` could not converge gets another attempt
without anyone asking.

The manual step for `CTX-HANDOFF`, once per machine — stop the old daemon with the line for
this platform, move the binary and its marker aside, install again:

```bash
systemctl --user disable --now ctx.service # Linux
launchctl bootout gui/$(id -u)/rs.ctx.daemon # macOS
mv ~/.local/bin/ctx ~/.local/bin/ctx.bak-$(date +%Y%m%d%H%M%S)
mv ~/.local/bin/ctx.install.json ~/.local/bin/ctx.install.json.bak-$(date +%Y%m%d%H%M%S)   # when present
wf install
```

`wf repair` and `wf rollback` stay offline and never touch ctx. After either of them, the next session start converges ctx to whichever release is then active. `wf history`
itself failing with `CTX-MISSING` means there is no ctx to run at all: `wf install`.

## Setting a service up

First-time setup for a machine, an agent or a service is [`/install`](../install/SKILL.md):
Linear on each agent, Rackspace Spot, and the artifact-publishing credential file, each with
the commands and the login that completes it.

**What this workflow manages is two servers** (WFR-016). `capso-linear` and
`capso-rackspace-spot`, written into each managed agent's own MCP configuration and repaired
by `wf`. Anything else pointing at the
same service — a `linear` the person added, a connector on their Claude account, an entry
reading `Needs authentication` — belongs to them. Do not create it, log into it, repair it,
replace it or report on its state. If one is in the way, say what you saw and let them decide.
Never replace an unrelated server that happens to share a name.

Both shipped servers are `mcp-remote` bridges that log in through the browser on first use.
The token lives under `~/.mcp-auth`, keyed by service URL, **per machine and shared by both
agents** — so one completed page serves both, and two rows for one component usually describe
a single login. `wf` does not open that store, so it reports both servers as `unverified`.

After any login, verify it with a read through the server.

## When someone says "my skill is gone"

Run `wf doctor`. It reports the three things that actually cause this, in the order they
occur: `wf` does not manage that agent on this machine (`wf agents`; `wf agents register <id>`
fixes it), the release did not reach this machine, or the component drifted on disk — or
something of the same name that `wf` did not put there is in the way, which it reports as a
conflict and leaves in place. Each finding carries the command that fixes it.

Repair with `wf repair`, which records what it changed and can undo it. Do not hand-edit the
agent's config: the next sync overwrites a hand edit.

## Trying a change without a release

1. `wf release build-local --out ./dist` builds a release from this checkout.
2. `wf install --source local:./dist` installs it as if it had come from GitHub.
3. `wf sync --dry-run` previews managed changes.

`--dry-run` is available on `install`, `sync`, `repair`, `rollback` and `uninstall`.
It previews managed changes; install/sync may still fetch and expand releases in
temporary directories. Managed files and persistent state remain unchanged. Set disposable `WF_HOME`, `CLAUDE_CONFIG_DIR` and `CODEX_HOME` for a local
rehearsal; see [local development](https://github.com/txehq/txe-workflow/blob/main/docs/operations/local-development.md).
A build without `--ctx` pins no ctx, so installing it leaves ctx alone. A build with `--ctx`
manages the machine's real ctx daemon even under a disposable `WF_HOME`, because ctx
coordinates its daemon under the real `~/.ctx`.

## Pointing at a different repository or branch

```bash
wf sync --repo txehq/txe-workflow --branch main
```

`--repo` selects the release repository and `--channel` selects stable or canary.
`--branch` is recorded as source metadata only. For unpublished checkout changes, use
`--source local:<dir>`.
Install and sync remember the source; `repair` and `rollback` use verified local generations.

## What it will not do

It does not take ownership of your files. Inside `CLAUDE.md` and `AGENTS.md` it owns only the
bytes between its own markers; in a settings, hook or MCP file it owns named keys and its own
handlers; and every overwrite anywhere is backed up before it happens. `wf uninstall` and
`wf agents unregister <id>` remove only what `wf` has a record of.

It does not delete ctx. `wf uninstall` keeps `~/.local/bin/ctx` and `~/.local/bin/wf`. To remove
ctx, run `~/.local/bin/ctx daemon disable --prepare-uninstall --format=json` and delete the
binary only after it exits 0 with every boolean in its receipt true. ctx's index in `~/.ctx`
stays until someone deletes it deliberately.
