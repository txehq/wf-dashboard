---
name: obsidian
description: File a finished document into the Obsidian vault at its standard home — brief, research, design corpus, tickets record, handover, decision, spec or postmortem — with the folder index regenerated and the Linear ticket and published URL recorded. Use as the last step of any document-producing skill, after publishing, and whenever a document that belongs in the vault is currently sitting in a scratch file.
---

# /obsidian — put the document where it belongs, and leave the vault navigable

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Publishing/Obsidian Writer.md` (WF-OBS).
Where this file and the spec disagree, the spec wins: update this file to match it.

```bash
wf obsidian --kind brief \
  --product TXE --feature spot-bidding \
  --file .interview/brief.md \
  --ticket TXE-1504 --url https://engapp.dev/artifacts/page/ab12cd34
```

It prints the path it wrote. Hand that to Linear.

## Why this is a tool

"Write it to the vault" is where a standard quietly stops being followed: the folder gets
guessed, the index never gets updated, and the ticket id lives only in the conversation.
All three are mechanical, so the tool does all three.

## Where each kind goes

| kind | lands at | needs |
|---|---|---|
| `brief` | `Project <P>/Features/<slug>/Brief.md` | `--product --feature` |
| `research` | `Project <P>/Features/<slug>/Research.md` | `--product --feature` |
| `design` | `Project <P>/Features/<slug>/System Design.md` | `--product --feature` |
| `tickets` | `Project <P>/Features/<slug>/Tickets.md` | `--product --feature` |
| `handover` | `Project <P>/Features/<slug>/Handover.md` | `--product --feature` |
| `decision` | `Project <P>/Decisions/<Title>.md` | `--product --title` |
| `spec` | `Project <P>/Specs/<Title>.md` | `--product --title` |
| `postmortem` | `Postmortems/<date>-<slug>.md`, at the top level of the vault | `--slug` |

**The list is closed.** An unrecognised kind is refused: an invented location gives the vault
a second home for the same thing.

Use `--dry-run` to see the resolved path without writing anything.

## What it will not do

- **Overwrite silently.** An existing document is refused, and the refusal names the file.
  Pass `--replace` when you mean it.
- **Erase what you did not mention.** Frontmatter merges, so a later `--replace` that omits
  `--ticket` keeps the ticket somebody set two weeks ago.
- **Invent a product.** `Project <P>` must already exist. A typo would otherwise mint
  `Project Tokun2` and file the document into a product nobody has — which looks like
  success until someone goes looking.
- **Move your file.** The source is copied and left exactly where it was.

## The index is generated

Each feature folder's `+Index.md` is rendered from **what is actually in the folder**, on
every write, so a document removed from the folder leaves the index too. Hand edits are
overwritten.

## The vault

`$MAGI_VAULT`, defaulting to `~/Projects/Obsidian/TXE`. If it does not exist, the run fails
by name and creates nothing.

## When to reach for it

- The last step of `/interview`, `/research`, `/postmortem`, `/handover`.
- Any time a document that belongs in the vault is sitting in a scratch file — including
  one written earlier in the same session and forgotten about.

Publish first where a page is wanted (`/publish-artifacts`), so the URL can be recorded
here in the same pass.
