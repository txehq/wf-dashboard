---
name: open-pr
description: "Step 5 of /ic — turn a tested branch into a draft pull request whose body a reviewer can trust: push the branch, follow the repository's PR template when it has one and the six sections when it has none (why, what changed, before/after, progress, tests run, open items), put the acceptance screenshots in through gh image, carry `Closes TXE-N` for exactly one ticket, open as a draft, comment the PR URL on the ticket, and ask for the first review. Use when someone says \"open the PR\", \"create a PR for this\", \"draft the PR body\"; invoke it proactively, saying so in one line, when a ticket's branch is implemented and tested and no PR exists. Never marks ready and never merges."
---

# /open-pr — a draft PR whose body says why, what, and how it was proven

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/IC Session.md` (WF-IC — the
corpus has no separate node for this step), with the *PR* row of
`Project Magi/Workflow/System Design.md` §2 and WFR-007 (one ticket, one merge; the closing
trailer in the body). Where this file and those documents disagree, those documents win: update
this file to match them.

## Contract — what goes in, what comes out

| | |
|---|---|
| **In** | the branch from `/implement` with its head SHA and ticked checklist; the acceptance report URL and inspected screenshots from `/acceptance` when it ran; the ticket |
| **Out** | a **draft** PR against the development branch, body per the template or the six sections, screenshots embedded, `Closes TXE-<n>` for exactly one ticket; the PR URL commented on the ticket; the first review requested |
| **Next** | `/fix-pr`, invoked immediately — then `/ready-for-review` |

## When this skill starts

- **On request:** `/open-pr`, "open the PR", "create a PR for this", "draft the PR body".
- **From `/ic`:** as step 5, after `/implement` and `/acceptance`.
- **Proactively:** the branch is implemented and tested, the checklist is ticked, and no PR
  exists. Say "running /open-pr" and begin.
- **Not** with a red canonical verdict → back to `/implement`. Not with unticked checklist
  lines and no blocking comment on the ticket → back to `/implement`.

## 1. Push

```bash
git push -u origin "$(git rev-parse --abbrev-ref HEAD)"
```

The PR targets the repository's **development branch**, the same one `/implement` cut from:
the integration branch its contract or `CLAUDE.md` names, and when neither names one, the
repository's default branch.

## 2. The body — from the template, or in this order

Review arrives on the PR, CI runs on it and Auto Merge reads it, so its body is the one
document a reviewer, a gate and every later reader all read.

**If the repository has a PR template** (`.github/PULL_REQUEST_TEMPLATE.md`,
`.github/pull_request_template.md`, or a `PULL_REQUEST_TEMPLATE/` directory), follow it
first: fill every section it defines, in its order, and put screenshots in the section it
provides for them. Add the trailer and the acceptance report link where the template has no
home for them, at the end.

**Without a template**, assemble the body in this order — each section present, even when its
content is one line:

1. **Why** — the background, where the requirement came from (the ticket, the brief, the
   incident), how urgent it is, and the problem this solves.
2. **What changed** — the scope of the change and its content: which parts, what behaviour is
   different, what is deliberately untouched.
3. **Before / after** — when there is an end-to-end surface, stitch the before and after
   screenshots into one image with ImageMagick
   (`magick before.png after.png +append compare.png`) so the reviewer sees the difference in
   one look; for a new feature, screenshots that show it working *and* that the neighbouring
   features still do. These come from `/acceptance`. When `command -v magick` prints nothing,
   install ImageMagick 7, the release that provides `magick`, with the machine's package manager
   (`brew install imagemagick` on macOS), then stitch.
4. **Progress** — where the ticket stands after this PR: complete, or which criteria remain
   (from the checklist).
5. **Tests run** — what was executed and where: unit and integration suites, the canonical
   verdict with its command, the acceptance report with its URL.
6. **Open items** — what this PR does not include: the things left out on purpose, and the
   things inside the ticket's scope that were not done here with the follow-up ticket filed
   for each. Nothing is left implicit.

Then the trailer. It goes in the **body** — the surface that is observed to close and stamp
the ticket — and it names exactly one ticket; a bare id without a verb only links the ticket:

```
Closes TXE-<n>
```

## 3. Screenshots, through `gh image`

`gh image` uploads a file and prints the markdown for it; paste that markdown into the section
yourself. List the installed extensions first:

```bash
gh extension list
```

When `drogers0/gh-image` is not in the list, install it:

```bash
gh extension install drogers0/gh-image
```

Then upload each image:

```bash
gh image <compare.png> --repo <owner>/<repo>  # prints the markdown for the body
```

Check the exit status and every returned URL before pasting; a broken image in a PR body is a
reviewer's first impression. A failed upload stops this step with its error.

## 4. Open — as a draft

This skill's working directory is `.open-pr/` in the current directory. Before writing
anything into it, create `.open-pr/.gitignore` containing `*` with the file editing tool.
Then write the body to `.open-pr/body.md` with the file editing tool. Without a template, the
body has this shape:

```markdown
## Why
<background · where the requirement came from · urgency · the problem this solves>

## What changed
<scope and content of the change; what is deliberately untouched>

## Before / after
<markdown returned by gh image: the stitched comparison, or the feature working and its neighbours intact>

## Progress
<complete, or which criteria remain>

## Tests run
- <suite or command> — <result>
- Acceptance: <engapp.dev report URL>

## Open items
- Not in this PR on purpose: <item>
- In scope, not done here: <item — follow-up TXE-<m>>

Closes TXE-<n>
```

Then open the PR with that file as its body:

```bash
gh pr create --draft --base "<dev>" --title "<type>(<scope>): <what changed>" --body-file .open-pr/body.md
```

Open it as a **draft**: `/fix-pr` runs on the draft, and "ready for review" is
`/ready-for-review`'s verdict once every thread is resolved and CI is green. Read the created
PR back once — title, base, body, draft flag — before moving on.

## 5. Tell the ticket, ask for the first review, and go straight to `/fix-pr`

Comment the PR URL on the ticket. Then run `/review-pr` on the PR for its first review: the PR
is a draft, and the PR-polling review service skips drafts.

Then **invoke [fix-pr](../fix-pr/SKILL.md) in the same turn**, which arms the watcher over
this PR. The PR URL is this skill's artifact and the next step's input; it is not a hand-over
to the user, and the review has not arrived yet. Reporting the URL and stopping leaves an
unreviewed draft nobody is watching.

## Not this

- Producing the screenshots and the report → `/acceptance`.
- Waiting for the review, fixing what it finds, fixing a red check → `/fix-pr`.
- Marking ready for review → `/ready-for-review`. Merging → the repository's gate.
