# iOS Simulator surface

Use this surface when a criterion depends on native iOS rendering, navigation,
gestures, lifecycle, system sheets, or device-size layout. It requires macOS,
Xcode, and an installed Simulator runtime; it is not cloud-portable.

The required workflow is shell-only: every input and capture step must be
executable by a general agent through a documented CLI.

## Contents

- [Proof contract](#proof-contract)
- [Probe and choose a CLI driver](#probe-and-choose-a-cli-driver)
- [Establish the tested build](#establish-the-tested-build)
- [Inspect and interact](#inspect-before-acting)
- [Capture and review evidence](#capture-device-evidence)
- [Decide the case status](#decide-the-case-status)

## Proof contract

Separate the plan into observable claims before testing:

1. **Build/install/launch** — the current source produced the app now running.
2. **Static UI state** — the expected controls, content, and layout are visible.
3. **Behavior over time** — an animation, transition, or multi-step flow occurred.
4. **Touch semantics** — the intended tap, long press, swipe, or pan was actually
   delivered before judging the product response.
5. **Hardware-only behavior** — haptics, thermal behavior, camera input, and
   real-device performance require a physical device; Simulator cannot prove them.

Record the repository, branch, commit, dirty state, build command, Xcode version,
Simulator model/runtime/UDID, bundle identifier, and tested time. A screenshot
from an old install is not evidence for the current source.

## The driver: AXe

AXe talks to Simulator Accessibility and HID directly. Probe the host for the tools:

```bash
command -v axe
command -v ffmpeg
command -v ffprobe
xcrun simctl help io
```

| Tool      | Responsibility in this workflow                                                                               |
| --------- | ------------------------------------------------------------------------------------------------------------- |
| AXe       | Accessibility inspection; selector tap; touch, swipe, drag, and preset gesture injection                      |
| `simctl`  | Device discovery and lifecycle; app install/launch; logs; authoritative framebuffer screenshots and recording |
| `ffprobe` | Prove the recorded movie is readable and report its observed duration, dimensions, rate, and frame count      |
| `ffmpeg`  | Losslessly enumerate decoded frames, sample review frames, and generate contact sheets                        |

Install AXe when `command -v axe` prints nothing:

```bash
brew install cameroncooke/axe/axe
```

If AXe cannot express the planned gesture, mark the case `blocked`. Do not switch to
a private agent plugin or silently downgrade a long press to a tap.

The examples below target AXe. Run `axe --version`, `axe --help`, and
`axe help <subcommand>` first because capabilities may differ by installed
version.

## Establish the tested build

Resolve one explicit device and keep using its UDID. Avoid `booted` after device
selection when several Simulators may be running.

```bash
axe list-simulators
xcrun simctl list devices booted --json > "$REPORT_DIR/assets/simulator-devices.json"
xcodebuild -version > "$REPORT_DIR/assets/xcode-version.txt"

# Build with the repository's canonical command first, then install its product.
xcrun simctl install "$UDID" "$APP_PATH"
xcrun simctl launch --terminate-running-process "$UDID" "$BUNDLE_ID"
```

For a development client, also prove that its Metro/dev-server URL is reachable
and that the newly built native binary opened. Save the build product path and
modification time in the text evidence.

## Inspect before acting

Read the current Accessibility hierarchy before choosing selectors:

```bash
axe describe-ui --udid "$UDID" > "$REPORT_DIR/assets/before-ui.txt"
axe describe-ui --point 220,710 --udid "$UDID"
```

Tap by accessibility identifier (`--id`); for a control without one, use `--label`
with `--element-type`. Stable identifiers make the same flow reusable across device
sizes and reduce accidental actions on the wrong control. When selector resolution
reports multiple matches or an invalid/zero-size frame, mark the case `blocked` with
the `describe-ui` output attached: a control the selectors cannot identify is an
accessibility concern.

## Tap and run multi-step flows

```bash
# Selector tap with polling and a settle delay.
axe tap --id photo-info-button --wait-timeout 5 --post-delay 0.5 --udid "$UDID"

# Disambiguated label tap.
axe tap --label 'Exposure & Metering' --element-type Button --udid "$UDID"
```

Most AXe HID commands are fire-and-forget: successful dispatch does not prove the
app processed the event. Always re-read UI or capture the post-state.

Use `axe batch` for a fixed multi-step flow so one HID session executes all steps.
Use selector polling for transitions and refresh the AX cache when screens change:

```bash
axe batch --udid "$UDID" --wait-timeout 5 --ax-cache perStep \
  --step "tap --id first-photo" \
  --step "sleep 0.5" \
  --step "tap --id photo-info-button"
```

When the next selector or coordinate depends on runtime inspection of the previous
state, run discrete commands.

## Deliver long press, swipe, and drag precisely

AXe delivers long press, swipe, and drag as touch events:

```bash
# Long press: explicit touch down, hold, and touch up.
axe touch -x 220 -y 710 --down --up --delay 0.6 --udid "$UDID"

# Horizontal page swipe with controlled duration.
axe swipe --start-x 330 --start-y 430 --end-x 70 --end-y 430 \
  --duration 0.6 --post-delay 0.5 --udid "$UDID"

# Low-level drag with explicit move-event density.
axe drag --start-x 200 --start-y 350 --end-x 200 --end-y 760 \
  --duration 0.8 --steps 80 --post-delay 0.5 --udid "$UDID"

# Device-relative common pattern; provide the actual screen dimensions.
axe gesture scroll-left --screen-width 402 --screen-height 874 \
  --duration 0.6 --udid "$UDID"
```

Derive coordinates from `describe-ui` and the selected device. A dispatched
gesture is only the input half of the proof; verify the expected page identity,
count, disclosure, or visual state afterward.

## Capture device evidence

Capture clean device pixels with `simctl`:

```bash
xcrun simctl io "$UDID" screenshot --type=png "$REPORT_DIR/assets/after.png"
```

For transitions and multi-step behavior, record the Simulator framebuffer and
derive every-frame or sampled contact sheets using
[../references/recording-ios-simulator.md](../references/recording-ios-simulator.md).
Keep the original MP4 as the temporal evidence; a contact sheet is an index for
review. Treat requested recording FPS as a target only: Simulator movies may be
variable-frame-rate, so verify actual duration, rate, and frame count with
`ffprobe`.

After each material action, preserve a fresh UI hierarchy under `assets/` as
`type: "dom_snapshot"` evidence:

```bash
axe describe-ui --udid "$UDID" > "$REPORT_DIR/assets/after-ui.txt"
```

For diagnostics, capture a scoped log after the interaction:

```bash
xcrun simctl spawn "$UDID" log show --style compact --last 5m \
  --predicate 'process == "YourApp"' > "$REPORT_DIR/assets/runtime.log"
```

Treat runtime warnings precisely: report relevant crashes/assertions, distinguish
environment noise, and never use the absence of a visible crash as proof that all
logs are harmless.

## Review UI evidence

- **Static layout:** inspect a full-resolution device screenshot; check clipping,
  overlap, hierarchy, safe areas, text, selected state, and target identity.
- **Animation/transition:** inspect the raw MP4 plus extracted start/event/end
  frames. Extract every encoded frame when timing, flicker, or a one-frame flash
  is the claim; otherwise use a declared sampling rate and retain the video.
- **Gesture:** pair the exact AXe command with the postcondition. A final
  screenshot alone cannot prove which gesture caused it.
- **Accessibility:** compare the visual state with `describe-ui` before/after.
  A visually correct control that cannot be identified or activated is an
  accessibility concern.
- **Performance:** Simulator footage shows visible stalls; physical-device FPS,
  thermal, energy, and haptic quality need a physical device.

## Decide the case status

| Status    | Use when                                                                                              |
| --------- | ----------------------------------------------------------------------------------------------------- |
| `pass`    | The required input was delivered, the expected state was observed, and required evidence was captured |
| `fail`    | The required input was delivered and the product violated the expected behavior                       |
| `blocked` | The build/environment/driver could not execute or observe the required condition                      |

For a blocked case, attach the recording or screenshot, UI hierarchy before/after,
the attempted command, stderr/exit status, and the missing driver capability. A
close button, an ordinary tap, or a static frame cannot satisfy a different planned
gesture.

CLI interactions may mutate live data. Use a test fixture when possible. If an
exploratory command appends a reaction, message, or other irreversible record,
disclose the exact side effect in the report.

Place artifacts under the structured report's `assets/` directory and publish
the complete HTML report through `publish-artifacts` to engapp.dev. Tag direct
AXe/`simctl` captures as `by cli`, deterministic UI-test/media-transform output
as `by program`, and preserve the device identity in every artifact description.
