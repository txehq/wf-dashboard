-- 读取 app process 中一个 window 的 position 和 size；参数：process 名称、window 序号
on run argv
	set processName to item 1 of argv
	set windowIndex to (item 2 of argv) as integer
	tell application "System Events"
		tell process processName
			return {position of window windowIndex, size of window windowIndex}
		end tell
	end tell
end run
