---
name: postmortem
description: "Use when a severe incident is identified — a bug that reached prod/users, a data-correctness failure that got served, a security/financial exposure, a deploy/migration that corrupted or blocked prod, or a defect CLASS that recurred (≥2 instances). Runs a deterministic, blameless postmortem: ground-truth timeline, systemic root cause, detection-gap analysis, and owned action items that fix the CLASS (CI gate / skill / definition-of-done) — then files them and writes the doc."
---

# Postmortem

A severe incident is done when its *class* of failure cannot recur silently.

## When to trigger (severity bar)

Run a postmortem when ANY of these holds:
- A bug **reached users / prod** — wrong data served, outage, broken UX on a core surface.
- A **data-correctness** failure — a feed shipped wrong / empty / stale and was served as truth.
- A **security, permissions, or financial** exposure.
- A **deploy or migration** corrupted, dirtied, or blocked prod.
- **"Shipped but never actually worked"** — merged-green code that was never live or correct.
- **The same class recurred (≥2 instances).** The recurrence itself is the trigger: it signals that the problem is in the system.

Do NOT run one for: a bug caught in review before merge, a transient CI flake, a trivial typo, or a one-off with no class behind it. When genuinely unsure, ask the user "is this postmortem-worthy?"

## The process — do every step, in order

Create a `TodoWrite` with one item per step. Don't skip to action items.

Write every working file into `.postmortem/` in the current directory. Create that directory,
with a `.gitignore` in it containing `*`, before writing the first file into it.

1. **Scope + severity.** One sentence: what broke, for whom, how bad. Give the incident a name.
2. **Timeline — from ground truth.** Reconstruct from real artifacts: logs (Loki), `git log` / PRs, `gh run` CI history, prod queries, dashboards. Use memory to narrow the search, then ground-truth every entry: check the system's own source of truth before asserting, and again before claiming a fix. Use real timestamps. A timeline narrated from recollection is how postmortems become fiction.
3. **Impact.** User-facing and internal. Quantify it — rows, users, duration, dollars, requests.
4. **Proximate cause.** The immediate, mechanical bug.
5. **Root cause — 5 whys to the class.** Keep asking "why was that possible?" and "why wasn't it caught?" until you hit the systemic gap: a missing gate, a wrong shared assumption, a verification boundary that stopped too early.
6. **Detection gap.** Why didn't review / CI / tests catch it? Name the exact boundary verification stopped at (e.g. "merged-green", for a change nobody verified live against the real upstream).
7. **What went well / what didn't.** Blameless: write about systems, processes and incentives.
8. **Action items.** Each one: concrete, **owned**, dated, tagged fixes-the-**INSTANCE** or fixes-the-**CLASS** (bias hard toward class fixes — a CI gate, a new/updated skill, a definition-of-done change, an automated check, a contract amendment). **File each as a Linear issue** (`[CC<n>-<ws>]` prefix + its workstream label) **plus** a per-postmortem label `pm-<slug>` (the doc's filename minus the date — e.g. `pm-shipped-not-live`; create the label once via the Linear label API). **Render the items in the doc with a Dataview** filtered on `pm-<slug>`, so `linear_status` syncs from Linear automatically (the `_TEMPLATE.md` Action-items block already does this).
9. **Publish it, then file it, and let the tool resolve the location.**

   ```bash
   wf publish-artifact .postmortem/postmortem.html --title "<incident name>"
   wf obsidian --kind postmortem --slug <slug> \
     --file .postmortem/postmortem.md --ticket <TXE-N> --url <the published URL>
   ```

   `/obsidian` resolves the home (`Postmortems/YYYY-MM-DD-<slug>.md`, at the top level of
   the vault), honours `$MAGI_VAULT`, and refuses to overwrite an existing document.
   Follow that folder's `_TEMPLATE.md` for the body.

   Postmortems live in **Obsidian**, alongside the existing ones and the
   `[CC<n>-<ws>] POSTMORTEM-` Linear tickets that sync into the vault. Don't fork a second
   copy under `docs/`.

10. **Close the loop.** The action items that change the development process are the deliverable. Open their PRs / file their tickets in this same session.
