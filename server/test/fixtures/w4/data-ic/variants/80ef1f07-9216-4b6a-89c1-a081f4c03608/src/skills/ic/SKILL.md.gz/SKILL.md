---
name: ic
description: "The engineer's entry point into the Magi workflow — from an assigned Linear ticket to a PR marked ready for review, as an orchestration of step skills: /claim reads the ticket whole and posts the requirements checklist, /readiness verifies the machine, /implement builds every requirement on an isolated branch and proves it locally, /acceptance walks the surface with screenshots, /open-pr drafts the PR from the template with gh image screenshots, /fix-pr watches review and CI in the background and dispositions every finding until the PR is quiet, and /ready-for-review marks the PR and the ticket. After one confirmation of the goal it runs autonomously — invoking each step skill itself, asking nothing — until the PR is ready for review, and only then hands over to the user. Opening the PR is the middle of the run: /fix-pr follows it immediately. Invoke when someone types /ic, /ic TXE-N, says \"take a ticket\", \"pick up TXE-N\", \"implement this ticket\", pastes a Linear issue URL with an ask to build it, or when /ticketing dispatches a lane; invoke it proactively, saying so in one line, when a ticket id arrives with an instruction to build. Not for scoping or planning — those are /lfg's stages."
---

# /ic — take a ticket, and carry it to a PR that is ready for review

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/IC Session.md` (WF-IC),
with the stage table in `Project Magi/Workflow/System Design.md` §2. Where this file and the
spec disagree, the spec wins: update this file to match it.

`/ic` is an **orchestrator**: each step is a skill of its own with an In/Out that names a file
or a Linear object, and `/ic` hands each the previous one's output and reads the result back
from that file or object. Every step is a skill, including the loop.

```mermaid
flowchart LR
  claim["/claim<br/>ticket, checklist"] --> readiness["/readiness<br/>machine verified"]
  readiness --> implement["/implement<br/>branch, ticks"]
  implement --> acceptance["/acceptance<br/>report, screenshots"]
  implement -->|"no visible surface, no declared evidence"| openpr
  acceptance --> openpr["/open-pr<br/>draft PR"]
  openpr --> fixpr["/fix-pr<br/>threads resolved, CI green"]
  fixpr --> ready["/ready-for-review<br/>PR ready, ticket in review"]
```

**The session never re-scopes.** Criteria travel on the ticket. An open question about what to
build goes back to the LFG as a comment on the ticket. **It never merges.** Auto Merge is the
repository's gate.

## Autonomy — one confirmation, then run to the end

1. **Confirm the goal, once.** After `/claim` has read the ticket whole and posted the
   checklist, play the goal back — the ticket, the outcome in one sentence, how many
   requirements the checklist holds, the toolchains `/readiness` will be asked for, the
   authority ceiling — and ask whether that is the work. A correction is folded into the
   checklist and played back again; agreement starts the run. **A lane dispatched by
   `/ticketing` skips this** — the gate already authorized the plan, and lanes never ask.
2. **Then run every step without asking.** Invoke `/readiness`, `/implement`, `/acceptance`,
   `/open-pr`, `/fix-pr` and `/ready-for-review` yourself, at their station, as soon as the
   previous step's artifact is in place. No "shall I open the PR?", no "should I run the
   acceptance?", no confirmation before a push. Report progress, test results and CI status
   **in one line per step boundary**.
   **Opening the PR is the middle of the run.** The PR URL is step 5's artifact, and the next
   action on it is `/fix-pr`, immediately. A session that reports the PR URL and hands back
   to the user has stopped six steps in and called it seven.
3. **Hand over at ready-for-review.** When `/ready-for-review` has marked the PR, tell the
   user: the PR URL, what the reviewer should look at first, what was deferred and to which
   tickets. That is the moment the user takes over, and the first moment since the
   confirmation that they are needed.

These stop the run, each with its own comment on the ticket:

- a requirement that **cannot be met as written** (`/implement`'s M5), or a premise or duplicate
  work `/claim` found: the LFG decides; in solo mode that is the user, so the run pauses on the
  ticket comment;
- a **readiness failure outside the ceiling** — a credential or a profile edit `/readiness`
  prints and will not perform;
- an **attachment that cannot be read**: requirements material you do not have;
- an action **beyond the authority ceiling** — a migration, an external side effect, anything
  the brief reserved for a human;
- an **oscillating finding** in `/fix-pr`;
- an **empty or errored PR review** in `/fix-pr`: the run stops with the review's error. An
  implementation review in `/implement` that did not run is noted, and the run goes on.

Everything else — a red canonical verdict, a red check, an unresolved thread, a failed
`/ready-for-review` condition — routes back to the step that owns it and is fixed there; the
user hears about it as a status line.

## When this skill starts

- **On request:** `/ic TXE-N`, `/ic`, "take a ticket", "pick up TXE-N", "implement this
  ticket", a Linear issue URL with an ask to build it.
- **Proactively:** a ticket id or URL arrives together with an instruction to build it. Say
  "running /ic on TXE-N" and begin.
- **Dispatched by `/ticketing`** (the end of `/lfg`), in a sub-agent: the ticket, brief and
  plan arrive seeded; the claim is the first step regardless, and the goal confirmation is
  skipped.
- **Not** for an idea without a ticket → `/lfg`. Not for reviewing someone else's PR →
  `/review-pr`.

## Entry at any step

Look before running anything. A ticket already In Progress under your name with a checklist
comment means `/claim` is done; the ticket's checklist comment fully ticked and stamped with a
head means `/implement` is done; an open draft PR means `/open-pr` is done, and the run resumes
at `/fix-pr` — a draft PR is never the end of a run. Start at the first step whose output is
missing, and say which. Derive all of this from Linear, the worktree and GitHub on every entry: the claim
comment, the checklist comment, the worktree and the PR are the run's record. When the worktree
has `.ic/progress.md`, read it first: it holds what the record does not — decisions, dead ends,
what comes next.

## The steps, and what each hands to the next

| # | step | reads | leaves behind |
|---|---|---|---|
| 1 | **`/claim`** | the ticket id or the pool | ticket In Progress with a claim comment; the **requirements checklist** as a ticket comment (`<!-- ic:checklist -->`); the declared toolchains |
| 2 | **`/readiness`** | the declared toolchains and infrastructure | a verified machine, or a blocked ticket with the fix named |
| 3 | **`/implement`** | the checklist; the feature documents | an isolated worktree and branch; every line ticked with file and test; the canonical verdict green; the ticket's checklist comment updated with the head SHA |
| 4 | **`/acceptance`** | the branch; the ticket's declared evidence | the acceptance report URL and inspected screenshots — for any visible surface, or when evidence is declared |
| 5 | **`/open-pr`** | the branch, the checklist, the report and screenshots | a **draft** PR from the template or the six sections, `Closes TXE-<n>`, PR URL on the ticket, first review requested |
| 6 | **`/fix-pr`** | the draft PR | every finding dispositioned with its marker, every check green on the current head |
| 7 | **`/ready-for-review`** | the draft PR, the checklist comment | PR marked ready; ticket in the team's review state with the report and deferred tickets |

Between steps, `/ic` reads the artifact the step named and does not advance until it is there:
no checklist comment, no `/implement`; a red canonical verdict, no `/open-pr`; an open thread
or a red check, no `/ready-for-review`. A missing artifact sends the run back to the step that
owns it, automatically, with a status line.

## CI pipeline tasks — invoke `/ci-optimise`

For pipeline creation, optimisation or modification, have `/implement` invoke
[ci-optimise](../ci-optimise/SKILL.md) after workspace setup and before editing.
Re-evaluate on resumed work and review fixes. Keep the measured critical path, required
check semantics and validation evidence with the checklist for the current head.

## Frontend tasks — invoke `/ui-text-simplify`

When the task involves frontend work, have `/implement` invoke
[ui-text-simplify](../ui-text-simplify/SKILL.md) **after its worktree and checklist setup,
before frontend edits**, even when no copy edit was requested. Earlier scope classification
is read-only. Determine applicability from the
requirements and actual changes: pages, components, client-side behavior, layout,
styles, localization and accessibility. Backend-only work without a frontend effect
does not trigger it.

`/implement` persists the decisions and affected-state checks in the local and ticket
checklists; `/acceptance` consumes that handoff. Re-evaluate when entering mid-way or
when review fixes introduce or change frontend work. A scoped check may need no copy edits. It does not
expand the ticket into a whole-app audit or add a separate approval gate.

## Step 6 — invoke `/fix-pr`, and do not stop at the PR URL

The moment `/open-pr` has commented the PR URL on the ticket, invoke
[fix-pr](../fix-pr/SKILL.md). It arms a background watcher over the PR's review and CI state,
gives every finding that arrives one disposition, fixes every red check from its log, and
returns when the latest review on the current head has no Critical or High finding and every
check is green.

**The watch runs in the background and wakes the session.** `/fix-pr` ships `watch_pr.py` for
exactly this reason: an agent with nothing to call stops, and stopping looks like finishing.
Arm the watcher, keep working on whatever the ticket still needs, and act on each event as it
arrives. A run that reports "the PR is open, waiting for review" and hands back has failed
this step.

`/fix-pr` returns control here only twice: with the loop quiet, which goes straight to
`/ready-for-review`, or with an oscillating finding, which stops the run on its summary
comment.

## Leaving early

End of day, reassignment, a blocker only someone else can lift: run `/handover`. It derives the
branch state and refuses to lose uncommitted work. Never leave a claimed ticket silent.

## Not this

- Scoping, planning or breaking work into tickets → `/lfg`.
- A machine that cannot build → `/readiness` on its own, or `/install-manager` when the
  workflow itself is what is missing.
- Reviewing someone else's PR → `/review-pr`.
