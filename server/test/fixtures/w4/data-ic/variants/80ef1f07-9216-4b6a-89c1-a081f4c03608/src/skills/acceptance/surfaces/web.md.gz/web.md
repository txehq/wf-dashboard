# Web surface

Default surface for frontend and full-stack changes — the browser is the one place
network requests and rendered UI are observable together, so you can assert both
sides of a contract in one run. Driven by `agent-browser`
([../references/agent-browser.md](../references/agent-browser.md)).

Use web when the behavior is the same in a normal browser against the app's dev
server or a deployed URL. Return to the surface router if the criterion depends
on the desktop shell or is fully provable through backend/CLI output.

## Setup

1. Have the app reachable at a URL: a local dev server you started (e.g.
   `http://localhost:<port>`), or a deployed/preview URL the task targets.
2. If the state under test is behind login, authenticate the agent-browser
   session first — see
   [../references/auth-web.md](../references/auth-web.md). Use a named `--session`
   so cookies persist across commands.

```bash
SESSION=app
agent-browser --session $SESSION open "http://localhost:3000/"
agent-browser --session $SESSION snapshot -i
# interact via refs, then capture
agent-browser --session $SESSION screenshot "$REPORT_DIR/assets/state.png"
```

Use the authenticated session as the evidence source: its screenshots prove that
the automated session reached the state.

## Full-stack — assert both layers {#web-full-stack}

When the criterion spans a new/changed API and the UI consuming it, capture both
the network exchange and the rendered result:

```bash
SESSION=app
agent-browser --session $SESSION network har start
# ... drive the scenario that triggers the API ...
agent-browser --session $SESSION network requests type xhr,fetch # inspect calls
agent-browser --session $SESSION network har stop "$REPORT_DIR/assets/capture.har"
agent-browser --session $SESSION screenshot "$REPORT_DIR/assets/result.png"
```

Record the screenshot and network proof in the round (`type: "screenshot"` and
`type: "text"`); include the HAR as an escaped download or focused request data.
Asserting only one layer leaves the contract half-proven.

## Local frontend against a remote backend

When only the frontend runs locally and the backend is remote, drive the frontend
URL the same way. The remote backend does not run your branch, so the run proves
frontend behavior only.

## Time-based behavior & OS-level steps

- **Behavior over time** (streaming, a loading state becoming loaded, animation)
  needs a clip — record CDP frames:
  [../references/recording-cdp.md](../references/recording-cdp.md).
- **A native step the page can't script** (file picker, OS permission prompt, Save
  dialog) — drop to Computer Use for that step, then return:
  [../references/computer-use.md](../references/computer-use.md).

## Boundaries

- **Provenance:** tag artifacts captured by `agent-browser` as
  `by agent-browser`; use `by cdp` only for a direct CDP client capture.
- **Headless / cloud:** headless Chromium and CDP screenshots work without a
  display. Capture through CDP.
- **HMR breaks refs.** After a hot reload during dev, re-snapshot before interacting.
