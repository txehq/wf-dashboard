from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path

from markdown_it import MarkdownIt

spec = importlib.util.spec_from_file_location("watch_pr", Path(__file__).with_name("watch_pr.py"))
watch_pr = importlib.util.module_from_spec(spec)
spec.loader.exec_module(watch_pr)

MD = MarkdownIt("commonmark")
HEAD = "a" * 40
OLD = "0" * 40
MARKER = "<!-- OpenAI Codex via RPR -->"

WITH_FINDINGS = f"""## Codex Code Review
{MARKER}

### Critical [1]

#### 1. The head is never re-read

### Low [2]

#### 1. A name reads oddly
#### 2. A comment is stale
"""

ONLY_LOW = f"## Codex Code Review\n{MARKER}\n\n### Low [1]\n\n#### 1. A name reads oddly\n"
MISCOUNTED = f"## Codex Code Review\n{MARKER}\n\n### Critical [2]\n\n#### 1. Only one follows a declared two\n"
ZERO_ONLY = f"## Codex Code Review\n{MARKER}\n\n### Critical [0]\n"
DUPLICATED = f"## Codex Code Review\n{MARKER}\n\n### Low [1]\n\n#### 1. One\n\n### Low [1]\n\n#### 1. Two\n"
CLEAN = f"## Codex Code Review\n{MARKER}\n\nno actionable findings on this head.\n"

FENCED = f"## Codex Code Review\n{MARKER}\n\nno actionable findings on this head.\n\n```markdown\n### Critical [9]\n```\n"
QUOTED_VERDICT = f"## Codex Code Review\n{MARKER}\n\n> no actionable findings\n"
HEDGED = f"## Codex Code Review\n{MARKER}\n\n### Critical [2]\n\n#### 1. Unable to say whether there are no actionable findings\n"

HUMAN = "This reads fine apart from the retry count — can you widen it?\n"
APPROVED_WITH_ASK = "Approving, but please fix the typo in the header before merging.\n"

def check(name, conclusion, status="completed", url=None, identity=None):
    return {
        "name": name,
        "status": status,
        "conclusion": conclusion,
        "url": url,
        "identity": identity or f"{name}-{conclusion}-1",
    }


GREEN = [check("build", "success", url="https://x/1")]
RED = [check("build", "failure", url="https://x/2")]
RUNNING = [check("build", None, status="in_progress")]

# 下面这些行照 txehq/txe#2307 在 head 93bd8c1c 上 GET commits/{sha}/check-runs 和
# actions/runs?head_sha= 的真实返回抄出来，id、时间、suite 都是原值。
ACTIONS = 15368
ARTIFACTLINT = 279468269
CI = 278904053
REAL_HEAD = "93bd8c1c5af8a476f7d5e9425396566c368af14c"


def run(rid, name, conclusion, suite, started, completed, workflow_run, status="completed", app=ACTIONS):
    return {
        "id": rid,
        "name": name,
        "head_sha": REAL_HEAD,
        "status": status,
        "conclusion": conclusion,
        "started_at": started,
        "completed_at": completed,
        "html_url": f"https://github.com/txehq/txe/actions/runs/{workflow_run}/job/{rid}",
        "app": {"id": app, "slug": "github-actions" if app == ACTIONS else "other-app"},
        "check_suite": {"id": suite},
    }


def workflow_run(wid, suite, workflow, event="pull_request", path=".github/workflows/artifactlint.yml"):
    return {"id": wid, "check_suite_id": suite, "workflow_id": workflow, "event": event, "path": path, "head_sha": REAL_HEAD}


# artifactlint 在同一个 head 上执行了五次，每次一个 check suite；最早那次被 concurrency 取消。
ARTIFACTLINT_RUNS = [
    run(106138670027, "artifactlint", "cancelled", 96208738533, "2026-09-20T19:51:09Z", "2026-09-20T19:52:13Z", 35533645424),
    run(106138827706, "artifactlint", "success", 96208872097, "2026-09-20T19:54:41Z", "2026-09-20T19:55:50Z", 35533701019),
    run(106141056340, "artifactlint", "success", 96210966347, "2026-09-20T20:07:43Z", "2026-09-20T20:08:31Z", 35534533394),
    run(106141302466, "artifactlint", "success", 96211186255, "2026-09-20T20:09:23Z", "2026-09-20T20:10:12Z", 35534621131),
    run(106143348346, "artifactlint", "success", 96213052673, "2026-09-20T20:23:15Z", "2026-09-20T20:24:13Z", 35535379372),
]
ARTIFACTLINT_WORKFLOWS = [
    workflow_run(35533645424, 96208738533, ARTIFACTLINT),
    workflow_run(35533701019, 96208872097, ARTIFACTLINT),
    workflow_run(35534533394, 96210966347, ARTIFACTLINT),
    workflow_run(35534621131, 96211186255, ARTIFACTLINT),
    workflow_run(35535379372, 96213052673, ARTIFACTLINT),
]


def review(rid, body, commit=HEAD, state="COMMENTED", association="MEMBER", login="rpr"):
    return {
        "id": rid,
        "body": body,
        "commit_id": commit,
        "state": state,
        "author_association": association,
        "user": {"login": login},
        "submitted_at": "2026-09-20T00:00:00Z",
    }


def inline_comment(cid, body="fix this", updated="2026-09-20T01:00:00Z"):
    return {"id": cid, "body": body, "updated_at": updated}


def marker_for(rev, rid=42, head=HEAD, association="MEMBER"):
    return {"body": f"Fixed.\n<!-- fix-pr disposed review={rid} rev={rev} head={head} -->", "author_association": association}


def covering(reviews, rid=42, inline=None, **kwargs):
    target = next(r for r in reviews if r["id"] == rid)
    rev = watch_pr.revision(target, (inline or {}).get(str(rid), []))
    return marker_for(rev, rid=rid, **kwargs)


def events(reviews, checks=GREEN, comments=(), inline=None, unresolved=0, required=(), head=HEAD):
    return watch_pr.events(head, list(reviews), list(checks), list(comments), inline or {}, unresolved, list(required), "test", MD)


def names(reviews, **kwargs):
    return [e["event"] for e in events(reviews, **kwargs)]


class ParseReview(unittest.TestCase):
    def test_findings_come_from_the_severity_headings(self):
        self.assertEqual(watch_pr.parse_review(WITH_FINDINGS, MD), ("findings", {"Critical": 1, "Low": 2}))

    def test_an_explicit_clean_verdict_is_its_own_result(self):
        self.assertEqual(watch_pr.parse_review(CLEAN, MD), ("clean", {}))

    def test_a_heading_inside_a_code_fence_is_not_a_finding(self):
        self.assertEqual(watch_pr.parse_review(FENCED, MD), ("clean", {}))

    def test_a_declared_count_that_misses_its_findings_is_malformed(self):
        self.assertEqual(watch_pr.parse_review(MISCOUNTED, MD), ("malformed", {}))

    def test_a_repeated_severity_section_is_malformed(self):
        self.assertEqual(watch_pr.parse_review(DUPLICATED, MD), ("malformed", {}))

    def test_a_bare_zero_count_is_malformed(self):
        self.assertEqual(watch_pr.parse_review(ZERO_ONLY, MD), ("malformed", {}))

    def test_the_verdict_is_not_read_out_of_a_quotation(self):
        self.assertEqual(watch_pr.parse_review(QUOTED_VERDICT, MD), ("malformed", {}))

    def test_the_verdict_is_not_read_out_of_a_finding_title(self):
        # Medium 4：finding 标题里出现这句话，不能把一份截断的 review 洗成干净的。
        self.assertEqual(watch_pr.parse_review(HEDGED, MD), ("malformed", {}))

    def test_a_body_with_no_structure_at_all_is_malformed(self):
        self.assertEqual(watch_pr.parse_review(MARKER, MD), ("malformed", {}))

    def test_prose_that_merely_contains_the_phrase_is_malformed(self):
        # 含有这句话，说的却是相反的意思。
        body = f"## Codex Code Review\n{MARKER}\n\nNo actionable findings were established because the review was truncated.\n"
        self.assertEqual(watch_pr.parse_review(body, MD), ("malformed", {}))

    def test_a_short_qualifier_after_the_verdict_still_reads_as_clean(self):
        for tail in ("", " on this head", " in the changed files", "."):
            body = f"## Codex Code Review\n{MARKER}\n\nno actionable findings{tail}\n"
            self.assertEqual(watch_pr.parse_review(body, MD)[0], "clean", tail)

    def test_a_zero_count_section_beside_a_clean_verdict_is_malformed(self):
        body = f"## Codex Code Review\n{MARKER}\n\nno actionable findings\n\n### Critical [0]\n"
        self.assertEqual(watch_pr.parse_review(body, MD), ("malformed", {}))


class Disposition(unittest.TestCase):
    def test_a_marker_covers_the_revision_it_names(self):
        self.assertEqual(watch_pr.disposed_reviews([marker_for("abc123abc123")]), {("42", "abc123abc123")})

    def test_a_marker_from_outside_the_repository_is_ignored(self):
        self.assertEqual(watch_pr.disposed_reviews([marker_for("abc123abc123", association="NONE")]), set())

    def test_a_forged_marker_does_not_suppress_a_review(self):
        reviews = [review(42, HUMAN)]
        forged = covering(reviews, association="NONE")
        self.assertEqual(names(reviews, comments=[forged]), ["review"])

    def test_a_covered_review_stops_being_an_event(self):
        reviews = [review(42, WITH_FINDINGS)]
        self.assertEqual(names(reviews, comments=[covering(reviews)]), [])

    def test_an_edited_review_is_no_longer_covered(self):
        # High 3：id 不变、正文改了，旧的处置标记不能继续压住它。
        reviews = [review(42, WITH_FINDINGS)]
        stale = covering(reviews)
        edited = [review(42, WITH_FINDINGS + "\n### Medium [1]\n\n#### 1. More\n")]
        self.assertEqual(names(edited, comments=[stale]), ["review"])

    def test_a_new_inline_comment_uncovers_the_review(self):
        reviews = [review(42, HUMAN)]
        stale = covering(reviews, inline={"42": [inline_comment(1)]})
        grown = {"42": [inline_comment(1), inline_comment(2)]}
        self.assertEqual(names(reviews, comments=[stale], inline=grown), ["review"])

    def test_a_review_is_still_owed_after_the_head_moved(self):
        # High 2：修复推上去之后 head 变了，那条意见照样要处置。
        found = events([review(42, WITH_FINDINGS, commit=OLD)])
        self.assertEqual(found[0]["event"], "review")
        self.assertEqual(found[0]["reviewed_head"], OLD)

    def test_the_event_carries_the_marker_to_post(self):
        found = events([review(42, WITH_FINDINGS)])
        self.assertIn(f"review=42 rev={found[0]['revision']}", found[0]["marker"])


class Events(unittest.TestCase):
    def test_an_undisposed_review_is_an_event(self):
        found = events([review(42, WITH_FINDINGS)])
        self.assertEqual(found[0]["event"], "review")
        self.assertEqual(found[0]["blocking"], 1)

    def test_a_malformed_rpr_review_on_the_head_is_a_failure(self):
        self.assertEqual(names([review(42, MARKER)]), ["review-invalid"])

    def test_a_later_valid_review_supersedes_an_earlier_malformed_one(self):
        # Medium 2：一份坏掉的历史 review 不能让 watcher 从此永远报错。
        self.assertEqual(names([review(42, MARKER), review(43, CLEAN)]), ["quiet"])

    def test_a_malformed_review_on_an_older_head_does_not_poison_this_one(self):
        self.assertEqual(names([review(42, MARKER, commit=OLD), review(43, CLEAN)]), ["quiet"])

    def test_an_rpr_marker_from_outside_the_repository_is_not_an_rpr_review(self):
        found = events([review(42, CLEAN, association="NONE")])
        self.assertEqual(found[0]["event"], "review")
        self.assertFalse(found[0]["graded"])

    def test_a_human_review_is_dispositioned_rather_than_graded(self):
        found = events([review(42, HUMAN)])
        self.assertEqual(found[0]["event"], "review")
        self.assertFalse(found[0]["graded"])

    def test_an_approval_that_asks_for_something_is_an_event(self):
        # High 2：Approve 里附的要求也是意见。
        self.assertEqual(names([review(42, APPROVED_WITH_ASK, state="APPROVED")]), ["review"])

    def test_a_bare_approval_is_not(self):
        self.assertEqual(names([review(42, "", state="APPROVED")]), ["quiet"])

    def test_another_bots_format_is_not_a_failure(self):
        self.assertEqual(names([review(42, "### Codex Review\n\nsuggestions follow.\n")]), ["review"])

    def test_an_empty_review_carrying_inline_comments_is_an_event(self):
        found = events([review(42, "", state="CHANGES_REQUESTED")], inline={"42": [inline_comment(1), inline_comment(2)]})
        self.assertEqual(found[0]["event"], "review")
        self.assertEqual(found[0]["inline_comments"], 2)

    def test_a_review_and_a_red_check_are_both_reported(self):
        self.assertEqual(names([review(42, WITH_FINDINGS)], checks=RED), ["review", "ci-failed"])

    def test_a_failing_check_carries_a_url_to_open(self):
        # Medium 3：check run 的 id 不是 gh run view 认的 id，给能打开的地址。
        reviews = [review(42, CLEAN)]
        found = events(reviews, checks=RED)
        self.assertEqual(found[0]["urls"], ["https://x/2"])


class Quiet(unittest.TestCase):
    def test_quiet_needs_a_clean_review_and_green_checks(self):
        self.assertEqual(names([review(42, CLEAN)]), ["quiet"])

    def test_a_running_check_emits_nothing(self):
        self.assertEqual(names([review(42, CLEAN)], checks=RUNNING), [])

    def test_no_checks_observed_is_never_quiet(self):
        self.assertEqual(names([review(42, CLEAN)], checks=[]), [])

    def test_a_required_check_that_has_not_registered_is_never_quiet(self):
        # High 4：一条快的先绿，必需的那条还没有建出来。
        self.assertEqual(names([review(42, CLEAN)], required=["guard"]), [])

    def test_quiet_once_every_required_check_passed(self):
        both = GREEN + [check("guard", "success", url="https://x/4")]
        self.assertEqual(names([review(42, CLEAN)], checks=both, required=["guard"]), ["quiet"])

    def test_an_unresolved_thread_is_never_quiet(self):
        self.assertEqual(names([review(42, CLEAN)], unresolved=1), [])

    def test_a_blocking_finding_on_the_latest_review_is_never_quiet(self):
        reviews = [review(42, WITH_FINDINGS)]
        self.assertEqual(names(reviews, comments=[covering(reviews)]), [])

    def test_only_low_findings_leave_the_loop_once_dispositioned(self):
        reviews = [review(42, ONLY_LOW)]
        self.assertEqual(names(reviews, comments=[covering(reviews)]), ["quiet"])

    def test_a_head_with_no_review_is_never_quiet(self):
        self.assertEqual(names([]), [])

    def test_a_review_only_on_an_older_head_is_never_quiet(self):
        reviews = [review(42, CLEAN, commit=OLD)]
        self.assertEqual(names(reviews, comments=[covering(reviews)]), [])

    def test_a_skipping_check_does_not_block_quiet(self):
        skipped = [check("e2e", "skipped")]
        self.assertEqual(names([review(42, CLEAN)], checks=skipped), ["quiet"])

    def test_quiet_records_which_checks_were_required_and_where_that_came_from(self):
        both = GREEN + [check("guard", "success")]
        found = events([review(42, CLEAN)], checks=both, required=["guard"])[0]
        self.assertEqual(found["required_checks"], ["guard"])
        self.assertEqual(found["required_from"], "test")


class Supersession(unittest.TestCase):
    def test_a_cancelled_execution_replaced_by_a_later_success_is_not_a_failure(self):
        # issue #55：txehq/txe#2307 上被 concurrency 取消的 artifactlint，后面有四次成功。
        checks = watch_pr.latest_executions(ARTIFACTLINT_RUNS, ARTIFACTLINT_WORKFLOWS)
        self.assertEqual([c["identity"] for c in checks], ["106143348346@2026-09-20T20:24:13Z"])
        self.assertEqual(names([review(42, CLEAN)], checks=checks), ["quiet"])

    def test_a_cancellation_that_nothing_replaced_is_still_a_failure(self):
        checks = watch_pr.latest_executions(ARTIFACTLINT_RUNS[:1], ARTIFACTLINT_WORKFLOWS[:1])
        found = events([review(42, CLEAN)], checks=checks)
        self.assertEqual(found[0]["event"], "ci-failed")
        self.assertEqual(found[0]["runs"], ["106138670027@2026-09-20T19:52:13Z"])
        self.assertEqual(found[0]["urls"], ["https://github.com/txehq/txe/actions/runs/35533645424/job/106138670027"])

    def test_a_failure_newer_than_a_success_is_a_failure(self):
        newer = run(106150000001, "artifactlint", "failure", 96220000001, "2026-09-20T21:00:00Z", "2026-09-20T21:01:00Z", 35540000001)
        checks = watch_pr.latest_executions([*ARTIFACTLINT_RUNS, newer], [*ARTIFACTLINT_WORKFLOWS, workflow_run(35540000001, 96220000001, ARTIFACTLINT)])
        found = events([review(42, CLEAN)], checks=checks)
        self.assertEqual(found[0]["event"], "ci-failed")
        self.assertEqual(found[0]["runs"], ["106150000001@2026-09-20T21:01:00Z"])

    def test_a_replacement_still_running_holds_the_loop_without_a_failure(self):
        running = run(106150000001, "artifactlint", None, 96220000001, "2026-09-20T21:00:00Z", None, 35540000001, status="in_progress")
        checks = watch_pr.latest_executions([*ARTIFACTLINT_RUNS[:1], running], [*ARTIFACTLINT_WORKFLOWS[:1], workflow_run(35540000001, 96220000001, ARTIFACTLINT)])
        self.assertEqual(names([review(42, CLEAN)], checks=checks), [])

    def test_the_same_name_in_another_workflow_does_not_replace_a_failure(self):
        other = run(106150000001, "artifactlint", "success", 96220000001, "2026-09-20T21:00:00Z", "2026-09-20T21:01:00Z", 35540000001)
        checks = watch_pr.latest_executions([*ARTIFACTLINT_RUNS[:1], other], [*ARTIFACTLINT_WORKFLOWS[:1], workflow_run(35540000001, 96220000001, CI, path=".github/workflows/ci.yml")])
        self.assertEqual(names([review(42, CLEAN)], checks=checks), ["ci-failed"])

    def test_the_same_workflow_on_another_event_does_not_replace_a_failure(self):
        push = run(106150000001, "artifactlint", "success", 96220000001, "2026-09-20T21:00:00Z", "2026-09-20T21:01:00Z", 35540000001)
        checks = watch_pr.latest_executions([*ARTIFACTLINT_RUNS[:1], push], [*ARTIFACTLINT_WORKFLOWS[:1], workflow_run(35540000001, 96220000001, ARTIFACTLINT, event="push")])
        self.assertEqual(names([review(42, CLEAN)], checks=checks), ["ci-failed"])

    def test_the_same_name_from_another_app_does_not_replace_a_failure(self):
        foreign = run(106150000001, "artifactlint", "success", 96220000001, "2026-09-20T21:00:00Z", "2026-09-20T21:01:00Z", 35540000001, app=99999)
        checks = watch_pr.latest_executions([*ARTIFACTLINT_RUNS[:1], foreign], ARTIFACTLINT_WORKFLOWS[:1])
        self.assertEqual(names([review(42, CLEAN)], checks=checks), ["ci-failed"])

    def test_without_provenance_a_success_does_not_replace_a_failure_from_another_suite(self):
        # workflow run 列表为空（第三方 app，或者还没列出来）：来源不明的两次执行各自保留。
        later = run(106150000001, "artifactlint", "success", 96220000001, "2026-09-20T21:00:00Z", "2026-09-20T21:01:00Z", 35540000001)
        checks = watch_pr.latest_executions([*ARTIFACTLINT_RUNS[:1], later], [])
        self.assertEqual(len(checks), 2)
        self.assertEqual(names([review(42, CLEAN)], checks=checks), ["ci-failed"])

    def test_distinct_checks_are_all_kept(self):
        build = run(106138713116, "python-tests", "success", 96208738558, "2026-09-20T19:52:05Z", "2026-09-20T20:22:00Z", 35533645433)
        checks = watch_pr.latest_executions([*ARTIFACTLINT_RUNS, build], [*ARTIFACTLINT_WORKFLOWS, workflow_run(35533645433, 96208738558, CI, path=".github/workflows/ci.yml")])
        self.assertEqual(sorted(c["name"] for c in checks), ["artifactlint", "python-tests"])


class Stream(unittest.TestCase):
    def test_the_same_review_keeps_its_key(self):
        one = events([review(42, WITH_FINDINGS)])[0]
        two = events([review(42, WITH_FINDINGS)])[0]
        self.assertEqual(watch_pr.key(one), watch_pr.key(two))

    def test_an_edited_review_gets_a_new_key(self):
        one = events([review(42, WITH_FINDINGS)])[0]
        two = events([review(42, WITH_FINDINGS + "\n### Medium [1]\n\n#### 1. More\n")])[0]
        self.assertNotEqual(watch_pr.key(one), watch_pr.key(two))

    def test_a_new_inline_comment_gets_a_new_key(self):
        one = events([review(42, HUMAN)], inline={"42": [inline_comment(1)]})[0]
        two = events([review(42, HUMAN)], inline={"42": [inline_comment(1), inline_comment(2)]})[0]
        self.assertNotEqual(watch_pr.key(one), watch_pr.key(two))

    def test_a_rerun_of_the_same_check_gets_a_new_key(self):
        again = [check("build", "failure", url="https://x/2", identity="build-failure-2")]
        one = events([review(42, CLEAN)], checks=RED)[0]
        two = events([review(42, CLEAN)], checks=again)[0]
        self.assertNotEqual(watch_pr.key(one), watch_pr.key(two))


class Arguments(unittest.TestCase):
    def test_a_positive_integer_passes(self):
        self.assertEqual(watch_pr.positive("30"), 30)

    def test_zero_and_negative_are_refused(self):
        for value in ("0", "-1"):
            with self.assertRaises(Exception):
                watch_pr.positive(value)

    def test_a_repository_needs_exactly_two_components(self):
        self.assertEqual(watch_pr.repository("txehq/txe-workflow"), "txehq/txe-workflow")
        for value in ("notarepo", "a/b/c", "/b", "a/"):
            with self.assertRaises(Exception):
                watch_pr.repository(value)


class Contract(unittest.TestCase):
    def test_every_event_the_stream_emits_names_a_next_action(self):
        emitted = {"review", "ci-failed", "head-moved", "quiet", "review-invalid", "watch-expired"}
        self.assertEqual(emitted, set(watch_pr.NEXT))

    def test_every_outcome_has_its_own_exit_code(self):
        # High 6：崩溃退 1，review-invalid 和 expiry 各占一个码，三者分得开。
        codes = [*watch_pr.TERMINAL.values(), watch_pr.EXPIRED_EXIT, 1]
        self.assertEqual(len(codes), len(set(codes)))

    def test_quiet_is_the_only_event_that_leaves_the_loop(self):
        leaves = [name for name, text in watch_pr.NEXT.items() if "/ready-for-review" in text]
        self.assertEqual(leaves, ["quiet"])

    def test_an_expiry_is_not_terminal_and_asks_for_a_re_arm(self):
        self.assertNotIn("watch-expired", watch_pr.TERMINAL)
        self.assertIn("re-arm", watch_pr.NEXT["watch-expired"])

    def test_a_poll_never_starts_without_room_to_finish(self):
        self.assertGreater(watch_pr.POLL_BUDGET, 0)

    def test_a_read_is_retried_before_the_watch_gives_up(self):
        # 一次 `unexpected EOF` 让整个 watch 结束，PR 就又没有人看着了。
        self.assertGreater(watch_pr.ATTEMPTS, 1)
        self.assertGreater(watch_pr.RETRY_PAUSE, 0)


if __name__ == "__main__":
    unittest.main()
