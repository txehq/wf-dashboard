# Web and Electron recording via CDP

Use this reference only for Web or Electron criteria that assert behavior over
time: streaming output, loading-to-loaded transitions, timers, animations, or
multi-step flows. Capture renderer frames through `agent-browser`.

## Capture a frame sequence

Run `scripts/record_cdp_frames.py` in a persistent shell while driving the scenario
from another shell. It creates a new frame directory under the round directory and
writes `frame_000000.png`, `frame_000001.png`, and so on. `--target` is the
agent-browser session name for `--surface web` and the CDP port for
`--surface electron`:

```bash
FRAME_DIR="$REPORT_DIR/frames/flow"

# Web: 40 frames at 0.5 seconds cover about 20 seconds.
uv run "$SKILL_DIR/scripts/record_cdp_frames.py" --surface web --target app \
  --out "$FRAME_DIR" --frames 40 --interval 0.5

# Electron:
uv run "$SKILL_DIR/scripts/record_cdp_frames.py" --surface electron --target 9222 \
  --out "$FRAME_DIR" --frames 40 --interval 0.5
```

Use an interval of `0.25` seconds for quick transitions and `1` second for slow
flows, and set `-framerate` below to match it. Keep the capture scoped to the
behavior under review.

## Assemble and validate the clip

```bash
# MP4
ffmpeg -y -framerate 2 -i "$FRAME_DIR/frame_%06d.png" \
  -c:v libx264 -crf 23 -pix_fmt yuv420p "$REPORT_DIR/assets/flow.mp4"

# GIF with a generated palette
ffmpeg -y -framerate 2 -i "$FRAME_DIR/frame_%06d.png" \
  -vf "scale=900:-1:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse" \
  "$REPORT_DIR/assets/flow.gif"

ffprobe -v error \
  -show_entries format=duration:stream=codec_name,width,height,avg_frame_rate,nb_frames \
  -of json "$REPORT_DIR/assets/flow.mp4"
```

Inspect the first frame, action frame, transient state, and settled frame before
citing the artifact. The frame directory stays in the round directory for a
reviewer's question about a one-frame defect.

## Boundaries

- CDP frames are headless/cloud-safe and exclude browser or Electron window
  chrome.
- A native file picker, permission prompt, menu, or other OS-owned surface is not
  present in these frames. Follow the selected surface's conditional native-step
  guidance when that chrome is part of the criterion.
- Use `by agent-browser` for the captured frames and `by program` for the
  assembled media artifact.
- `agent-browser`, `uv` and `ffmpeg`/`ffprobe` are required. Probe them before the
  run.

Choose between `gif` and `video` and submit the artifact using the shared contract
in [evidence.md](./evidence.md).
