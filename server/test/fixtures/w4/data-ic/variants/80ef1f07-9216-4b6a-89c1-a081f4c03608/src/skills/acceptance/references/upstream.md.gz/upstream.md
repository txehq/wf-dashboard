# Upstream provenance and adaptation

Upstream source: LobeHub acceptance **0.3.0**, branch `canary`, checked 2026-09-06:

- Commit: `73c35f4c68593996159b1822e4e935f5a04395fa`.
- Source: https://github.com/lobehub/lobehub/tree/73c35f4c68593996159b1822e4e935f5a04395fa/packages/builtin-skills/src/acceptance
- License: [LICENSE.upstream](../LICENSE.upstream).

All 19 portable Markdown files are included: entrypoint, 13 references, and
five surface guides. Excluded upstream files: `index.ts`, `index.test.ts`.

Capso modifications, as of 2026-09-17:

- One complete static HTML report per delivery, published through
  `publish-artifacts` to engapp.dev and republished in place on each repair;
  all LobeHub server/CLI operations removed.
- Local plans, required evidence, stable ids, reviewer provenance, dual text
  evidence, and latest upstream living logs preserved.
- Mock and injected-failure patterns replaced by real failure conditions, and
  reusable probes, recorders and the report renderer shipped as scripts.
- Explicit evidence/data rendering; no claim that static storage implements
  upstream's ingest validator, visualization engine, or review backend.
- Automatic dependency installation with separate credential prerequisites.
- gh-image screenshots inserted in matching PR/Issue template body sections;
  full engapp.dev report linked in the associated PR body.
- Project bootstrap follows existing task authorization without unnecessary
  confirmation for verified, reversible environment mechanics.

The Magi release version comes from the repository's `Cargo.toml` and generated
manifests. `metadata.upstream-version` records the upstream baseline. Derivation
does not change upstream copyright or licensing terms.
