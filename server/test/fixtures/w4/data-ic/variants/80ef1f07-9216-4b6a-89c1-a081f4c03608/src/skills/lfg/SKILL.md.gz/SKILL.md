---
name: lfg
description: "Magi's complete path from a new idea to Linear tickets — interview the user to fix the boundaries, research locally (the repo, this machine's history, the corpus, Linear's past tickets) and on the web (current best practice), ask back about implementation details, then split the work into tickets with acceptance criteria, an estimate and a recommended assignee drawn from Linear history, and stop at the dispatch gate. Invoke when someone types /lfg or says \"lfg\", \"let's go\", \"start a feature\", \"plan this out\", \"break this into tickets\" — and invoke it proactively, saying so in one line, when a user describes a new idea, feature or change that has no ticket yet. Not an installation command: that is `wf` and /install-manager. A ticket that already exists goes to /ic."
---

# /lfg — from a new idea to tickets, and then a deliberate stop

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/LFG Session.md` (WF-LFG),
with the stage table in `Project Magi/Workflow/System Design.md` §2 and the dispatch gate in
its decision log #28. Where this file and the spec disagree, the spec wins: update this file
to match it.

"Let's f***ing go." This is Magi's umbrella session: it owns the stage transitions from an
intent to a filed set of Linear issues and calls the child skills at their stations. The CLI
that installs and maintains this machine is `wf`, and its skill is `/install-manager`.

```mermaid
flowchart LR
  idea["idea"] --> s1["1 interview<br/>/interview"]
  s1 --> s2["2 research, local then web<br/>/research"]
  s2 --> s3["3 plan<br/>/plan"]
  s3 --> s4["4 ticketing<br/>/ticketing"]
  s4 --> gate{"dispatch gate<br/>always stops"}
  gate -->|"go"| lanes["solo: /ic lanes, every wave"]
  gate -->|"go wave N"| wave["solo: /ic lanes, wave N"]
  wave --> gate
  gate -->|"nothing or anything else"| filed["designer-only: tickets filed"]
```

## When this skill starts

- **On request:** `/lfg`, or the words "lfg", "let's go", "start a feature", "plan this",
  "break this into tickets", a brief or spec handed over with "run the rest".
- **Proactively:** the user describes a new idea, feature or change and no ticket exists for
  it. Say so in one line — "this is a new piece of work, running /lfg" — and begin. Do not
  ask permission to start; the interview is where their say happens.
- **Not** when a ticket already exists → `/ic`. Not for a question, a bug whose fix is
  already clear, or two or more open decisions with enumerable options and nothing else →
  `/decide`.

**Solo** (one person is architect and IC) and **team** (an architect plans, ICs execute) run
the same stages, and the answer at the gate decides which one a run is. Do not ask which mode
it is.

## The do-not-ask contract

Scope and the **authority ceiling** — how far the session may act without a human — are
declared once, in the interview, and travel in the brief. Questions afterwards each have a
station: the research Q&A in stage 2, **implementation details** and the plan's approval in
stage 3, a conflicting ticket and **the dispatch gate** in stage 4. Do not re-open scope at
planning, do not ask "shall I file these?" at ticketing, do not ask between waves. A question
that would change *what gets built* belongs in the interview; several questions with
enumerable options belong in one `/decide` ballot; everything else is yours to decide and
record.

## Entry, at any stage

Take the intent in the user's words. Then **look before you run anything**: the vault
feature folder `Project <Product>/Features/<slug>/` and Linear may already hold earlier
stages.

The tickets end in `/ic` lanes, which need a GitHub repository to branch and open PRs in. When
the current directory is not a git checkout with a GitHub remote, ask once which repository the
work belongs to; the answer goes into the brief's *Where it lives*, and every later stage runs
from that repository's checkout.

| found | it means | do |
|---|---|---|
| nothing | a fresh start | begin at stage 1 |
| `Brief.md` | the interview is done | check it answers the six brief topics; begin at stage 2 |
| `Research.md` or `System Design.md` (+ `Decisions/`, `Specs/`) | research is done | check every part carries criteria; begin at stage 3 — or at stage 4 when the plan is already `locked` |
| `Tickets.md` and a Linear epic | ticketing is done | rebuild the DAG from Linear; go straight to the gate |

Validation on entry is a *read*: check the artifact is present and complete for the next
stage, record what you used, and move on. Redo a stage only when the user asks or the
artifact fails its own check.

## Stage 1 — Interview the user, and fix the boundaries → `/interview`

Run `/interview` with the intent. It owns this stage end to end: the conversation, the six
brief topics, the write and the filing. Its contract:

| | |
|---|---|
| In | the intent in the user's words; the product and feature slug when known |
| Out | `Project <Product>/Features/<slug>/Brief.md`, filed by `wf obsidian`, standing alone |

The boundaries are the part this stage exists for: a brief whose out-of-scope list is empty
is not finished, and `/interview` will not return one. When it returns, **read the brief
back from the vault path** and carry two things forward: the authority ceiling, which nothing
later re-asks, and the open questions, which are `/research`'s first work list.

## Stage 2 — Research: the current state locally, the state of the art on the web → `/research`

Run `/research` with the brief's path. It owns this stage end to end: the tier call, three
explorer sub-agents over the codebase (reuse, coverage, gaps), the targeted web lookups, the
Deep Research prompt handed to the user as a ChatGPT link and read back in full, the
referenced recommendations, the convergence and the filing. Its contract:

| | |
|---|---|
| In | `Project <Product>/Features/<slug>/Brief.md`; the repository checkout |
| Out | `Project <Product>/Features/<slug>/Research.md`: findings by lens, web findings with references, referenced recommendations, a spec split into parts, a plan with per-part test plan and acceptance criteria, open decisions, risks |

When it returns, **read the document back from the vault path** and carry forward the open
decisions (stage 3's agenda) and the parts with their criteria (stage 4's raw material).
Stage 4 additionally reads Linear's own history: who did what in this area and how long it
took.

## Stage 3 — Ask back about implementation details, and plan → `/plan`

Run `/plan` with the research's path. It owns this stage end to end — the draft taken down
to the change itself, the implementation-detail Q&A (Phase 4 of the interview bank, each
goal thought and never shown, `/decide` when options are enumerable), the Plan agent's review
and Codex's, the human's review, and the lock — without entering
any harness plan mode. Its contract:

| | |
|---|---|
| In | `Research.md` and `Brief.md`; the repository checkout |
| Out | the plan **locked** into the feature's master document, with a dated lock entry and the decision ledger updated |

A scope question raised here is routed back to the brief. When `/plan` returns, **read the
locked plan back from the vault path**: its parts, in order, with their criteria and
verification, are stage 4's raw material.

## Stage 4 — Reconcile with Linear, split, file, and stop at the gate → `/ticketing`

Run `/ticketing` with the master document's path. It owns the rest of the spine's pre-code
half end to end — connecting to Linear, searching what already exists and deciding per part
whether to update, relate or create, splitting new work so that dependent pieces share a
ticket and independent pieces get their own, writing each from the ticket template with an
estimate and a recommended assignee from Linear history, filing the epic and `Tickets.md`,
presenting the **dispatch gate**, and on "go" dispatching `/ic` lanes wave by wave. Its
contract:

| | |
|---|---|
| In | the locked plan and `Brief.md`; Linear through the agent's MCP |
| Out | the epic and its issues (updated, related or created); `Tickets.md`; the plan presented at the gate; on "go", dispatched lanes |

The gate is the last human question before execution, and it is `/ticketing`'s to ask; `/lfg`
adds none. The user's single answer — **go**, **go wave N**, or nothing — decides whether this
was a solo run or a designer-only session, and `/lfg` reports where things stand and ends.
Merging is the repository's Auto Merge gate, and a lane never merges its own PR.

## Parking and resuming

Any stage may park: file the artifact so far in the vault, leave a comment on the epic naming
the stage and the next action, end cleanly. A run's state is what the vault feature folder and
Linear hold, so resuming is the entry table above: derive the stage from them. `/history`
finds the transcript when the *why* is missing.

## Not this

- Installing or repairing the workflow on a machine → `wf`, and `/install-manager`.
- Taking a ticket that already exists and building it → `/ic`.
- Two or more open decisions with enumerable options and nothing else pending → `/decide`
  directly.
