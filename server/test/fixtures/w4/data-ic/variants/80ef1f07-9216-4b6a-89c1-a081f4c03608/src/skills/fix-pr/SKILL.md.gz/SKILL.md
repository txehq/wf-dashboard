---
name: fix-pr
description: "Step 6 of /ic — the loop between a draft PR and a PR worth a human's time: arm a background watcher that streams review and CI state changes as events and wakes the session when one lands, then give every finding one disposition (fix it with the test that would have caught it, resolve it as a false positive with the reason, or defer it to a ticket), fix every red check from its log, and keep going until the latest review on the current head has no Critical or High finding and every check is green. Use when someone says \"watch the PR\", \"poll the reviews\", \"run the PR loop\", \"fix the review findings\", \"the CI is red on my PR\"; invoke it proactively, saying so in one line, when a draft PR exists and its threads or checks are not yet quiet. The watcher runs in the background and the session keeps working; a session that reports \"waiting for review\" and hands back has failed this step. Never marks ready and never merges."
---

# /fix-pr — watch, disposition, fix, until the PR is quiet

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Review/Fix PR.md` (WF-FPR), with
ballot **S5** (2026-09-06) which settled the state model, and the *Review* row of
`Project Magi/Workflow/System Design.md` §2. Where this file and those documents disagree,
those documents win: update this file to match them.

## Contract — what goes in, what comes out

| | |
|---|---|
| **In** | the draft PR from `/open-pr` with its number and head SHA; the ticket with its `<!-- ic:checklist -->` comment |
| **Out** | every finding on the current head dispositioned — fixed with its test, resolved with a stated reason, or deferred to a ticket; every check green on that head; the checklist comment stamped with the head it was proven at |
| **Next** | `/ready-for-review` |

`/review-pr` produces the reviews this skill consumes. The two never overlap: `/review-pr`
changes no code, `/fix-pr` writes no review.

## The rule that this skill exists for

**The watcher runs in the background and wakes the session. Waiting is never a turn that
ends, and it is never a turn spent idle either.**

An agent has two ways to finish a turn: call a tool, or stop. "Wait for the review" names no
tool, so an agent that reads it stops — and stopping looks exactly like finishing. `watch_pr.py`
removes the choice: it is a resident process that polls the PR, prints one line per state
change, and exits when the PR is quiet. Each line wakes the session with the event and the
action it calls for. Between events the session is free, and should carry on with whatever
else the ticket needs.

A session that reports "the PR is open, waiting for review" and hands back to the user has
failed this step. So has one that says it will check later.

```mermaid
flowchart LR
  arm["arm watch_pr.py<br/>background, streams events"] --> work["the session keeps working"]
  arm -.->|review| disp["disposition<br/>every finding"]
  arm -.->|ci-failed| ci["read the log<br/>reproduce, fix"]
  arm -.->|watch-expired| arm
  disp --> push["push, re-request review"]
  ci --> push
  push --> arm
  arm -.->|quiet| ready["/ready-for-review"]
```

## When this skill starts

- **On request:** `/fix-pr`, "watch the PR", "poll the reviews", "run the PR loop", "fix the
  review findings", "the CI is red on my PR".
- **From `/ic`:** as step 6, the moment `/open-pr` has commented the PR URL on the ticket.
- **Proactively:** a draft PR exists on this branch and its threads or checks are not quiet.
  Say "running /fix-pr on #<n>" and begin.
- **Not** before the PR exists → `/open-pr`. Not to review someone else's PR → `/review-pr`.

## State — GitHub is authoritative

There is no durable local state. The PR is the record: the reviews, the commits, and the
disposition comments carrying the marker

```
<!-- fix-pr disposed review=<review-id> rev=<revision> head=<sha> -->
```

Job identity is `OWNER/REPO#PR@HEAD` plus the review id, the scheme `/review-pr` already uses.
**Coverage is by review id and revision, never by head**: a fix moves the head, so a marker
that only matched at the head it was written on would uncover every review the moment it did
its job. The `head=` field records where the fix landed, which is what separates "already
fixed, comment never posted" from "not started".

`rev` is the watcher's digest of the review's state, timestamp, body and every inline comment
on it — every `review` event prints the marker to post. A reviewer can edit a review body or
add an inline reply without changing the review id, and that is a new revision with new
findings; the old marker stops covering it, and the watcher says so.

Three ways a session dies, and what the next one does:

| died | next session |
|---|---|
| before reading the review | re-detects it from GitHub; nothing was lost |
| mid-fix, tree dirty or commits unpushed | **surfaces it** and stops — `/handover` derives exactly this state; never continue silently over it |
| pushed, disposition comment never posted | the review has no marker, so the watcher still reports it; check whether the fix is already in the pushed head before touching the code, and post the missing comment |

Any local cursor is a disposable cache. Deleting it changes nothing about what the next
session finds.

## 1. Arm the watcher, then carry on

`watch_pr.py` ships with this skill in `scripts/`. It polls the PR, prints one JSON line per
state change, and exits when the PR is quiet. Arm it as a **background monitor** whose stdout
is an event stream, so each line wakes the session:

```
Monitor(
  command: "uv run --script <this skill's directory>/scripts/watch_pr.py --repo <owner>/<repo> --pr <n>",
  description: "review and CI on <owner>/<repo>#<n>",
  timeout_ms: 1800000,
)
```

Then **go and do something useful**. The watcher holds no tokens and blocks nothing. Read the
diff again, write the test a finding will need, draft the PR body's open items, start the next
requirement. The event arrives on its own.

| event | what it means | what to do |
|---|---|---|
| `review` | a review no marker covers, on any head | §2 |
| `ci-failed` | the latest execution of a check on the current head failed or was cancelled | §3 |
| `head-moved` | the head changed; the watch follows it | nothing — the new head's review arrives as its own event |
| `watch-expired` | the monitor's deadline passed | **re-arm it, same command** |
| `quiet` | every review dispositioned, no thread open, nothing Critical or High on the current head, every check green | `/ready-for-review` |
| `review-invalid` | a review arrived empty or malformed | stop the run and report it |

Every line carries a `next` field naming the action. Each outcome has its own exit code, so a
caller reading only the process status can tell them apart: **0** quiet, **2** review-invalid,
**75** expired, **1** the watcher itself failed, with the traceback on stderr. Each event is
reported once, keyed by the review's revision or by the failing checks — an edited review, a
new inline comment and a re-run check are new events, and an unchanged PR is silent.

**A check is judged by its latest execution on the head.** One check can run several times on
the same head — every edit to the PR body re-triggers a `pull_request` workflow, and a
concurrency group cancels the older run. The watcher treats runs with the same app, workflow,
triggering event and name as one check and reads only the newest of them (the highest check
run id). A cancellation that a later run of the same check replaced is not reported; a
cancellation nothing replaced, and a failure newer than a success, are.

**A review is owed a disposition until a marker names it, whichever head it was written on.**
The watcher does not drop an old-head review when you push, because that is exactly the window
where the fix is in and the marker is not.

`quiet` is withheld on every one of these:

- an open review thread, or a review whose findings are inline;
- a check whose latest execution is still running, or whose conclusion is not a pass;
- **no checks observed at all** — right after a push GitHub has not registered the suite, and
  reading that as green declares a PR clean on a head CI never saw;
- **a required check that has not appeared yet.** The watcher reads the base branch's required
  contexts from its rulesets, or from classic branch protection, and every one of them must
  have passed on this head. Staggered registration is the case where one fast check is green
  while the required workflow has not been created. The `quiet` event records which contexts
  were required and where that list came from, `undeclared` included.

**Silence means nothing has changed, and it is never a reason to stop.** The watcher emits on
every terminal state it can reach, including its own expiry, so a quiet stream is a quiet PR.
An expiry is the one event that asks for a re-arm; missing it leaves a PR nobody is watching,
which is this skill's whole failure mode.

`--interval` defaults to 30 seconds, which is the floor for a remote API. `--max-runtime`
defaults to 1500 seconds, far enough inside a 30-minute monitor that a slow poll and a final
sleep still leave room for the script to emit its own expiry. `--repo` takes `OWNER/REPO` and
every number takes a positive integer, each refused as an argument error before any polling.
Every GitHub call carries a timeout bounded by the remaining deadline, and a poll that would
not have room to finish is not started — the watcher retires with `watch-expired` instead of
timing out halfway and leaving the agent nothing to act on.

**The head is re-read after the snapshot.** A push that lands while the watcher is collecting
would otherwise produce a clean-looking picture of a commit that is no longer the head, and a
terminal verdict on it. A snapshot whose head moved is discarded.

**A read is retried before the watch gives up.** Every request the watcher makes is a GET, and
a single `unexpected EOF` from GitHub is the line, never a verdict. Ending a 30-minute watch on
one of those leaves a PR nobody is looking at, which is the failure this skill exists to
remove. Three attempts, two seconds apart; after that the watcher exits with the error.

**The watcher reads inline review comments and review threads**, not just review bodies. A
`CHANGES_REQUESTED` with an empty body and every finding written inline is the common shape of
a human review, and an open thread holds the loop no matter how green everything else is.

**An empty or errored `/review-pr` review is a failure, never a clean pass.** A review
carrying RPR's marker with neither findings nor an explicit clean verdict means the reviewer
did not run; treating it as "nothing to fix" ships unreviewed code. The run stops with the
review's state. A truncated review is the same failure wearing a clean face, so a severity
heading whose declared count misses its findings, a repeated severity section and a bare
`### Critical [0]` are all read as malformed — and the clean verdict counts only as a paragraph
of its own, never inside a quotation, a code fence or a finding's title. Only the **latest**
RPR review on the current head is judged this way: an earlier broken one is history, and a
valid review posted after it is its replacement, so one bad review does not stop every later
session. A bare approval from a human is not a failure, and neither is another bot's format.

**An approval that asks for something is still a review to disposition.** Only an `APPROVED`
review with an empty body and no inline comments is nothing to answer.

**Markers count only from inside the repository.** A disposition marker is read from a comment
whose author association is `OWNER`, `MEMBER` or `COLLABORATOR`, and the same gate decides
whether a review carrying RPR's marker is treated as `/review-pr`'s own. Anyone can type those
strings; a marker from outside suppresses nothing.

**Where the harness has no background monitor, there is no wake-up, and the skill says so
rather than pretending otherwise.** Run the same script with the agent's own background
facility, appending to `.fix-pr/events.jsonl`, and read that file at every step boundary —
after each commit, each push, each test run — **and before ending any turn**. Nothing wakes
the session there, so the discipline is the agent's own: an unread event file with the PR
still open is the same failure as handing back at the PR URL. Of the agents `wf` manages,
Claude Code has the monitor; the others carry this path until they grow one.

## 2. Disposition — every finding, exactly one

Take the findings in severity order. **Do not downgrade a severity.** Confirm each one by
reading the diff yourself; the review's claim is where you start looking.

The event's `graded` field says which kind of review arrived. A `/review-pr` review carries
its severities in `### Critical [N]` headings, and those counts drive the exit condition. A
review from a human or from another bot carries `graded: false`: read its body, take each
point as a finding, and give it the same three-way disposition. It has no counts, so what
takes it out of the loop is its disposition.

- **Fix** — read the diff and confirm the finding holds; reproduce it and find its root cause
  before changing code; fix it, and the same defect wherever else the diff has it; add or extend
  the test that would have caught it; commit naming the finding. A defect class that has
  recurred is a [/postmortem](../postmortem/SKILL.md) trigger.
- **Resolve as a false positive** — when the diff shows the finding does not hold. Its one-line
  reason goes in the summary comment below; a finding resolved without a reason is a hidden
  finding.
- **Defer** — when it is real, outside this slice, and will not be fixed here: file a Linear
  ticket; its id goes in the summary comment below.

With every finding of the review dispositioned, and when any was fixed, run the repository's
canonical suite, check that the fixes brought no new problem, and push the fix commits together.
Once the fixes are on the PR, resolve each of that review's threads, where it has them, without
replying on it: a reply is an inline comment of its own, which the watcher reads as a new review
to disposition.

Resolve a thread with `resolveReviewThread`, against the thread `id` that
`/ready-for-review`'s `unresolved-threads.graphql` returns:

```bash
gh api graphql --paginate -F "query=@<ready-for-review's directory>/unresolved-threads.graphql" \
  -f o=<owner> -f r=<repo> -F n=<n> \
  --jq '.data.repository.pullRequest.reviewThreads.nodes[] | select(.isResolved|not) | "\(.path):\(.line) \(.id)"'

gh api graphql -f query='mutation($id: ID!) { resolveReviewThread(input: {threadId: $id}) { thread { isResolved } } }' -f id=<thread-id>
```

Then post one comment carrying the marker — the summary a reader sees, and the record the next
session reads:

```
Dispositioned review <id> at <sha>: <n> fixed, <n> resolved as false positives, <n> deferred.
- <finding> — fixed in <sha>, covered by <test>
- <finding> — false positive: <reason>
- <finding> — deferred to TXE-<m>

<!-- fix-pr disposed review=<review-id> rev=<revision> head=<sha> -->
```

Copy the marker from the `review` event's own `marker` field and fill in the head the fixes were
pushed at, or the current head when nothing was fixed; `rev` must be the revision the event
carried, because that is the revision you read. Then stamp the ticket's `<!-- ic:checklist -->`
comment and `.ic/checklist.md` with that head and its canonical verdict line.

**After a frontend fix**, update the checklist's UI text checks for the new head and run
`/acceptance` again. It republishes the complete report for the new head at the same URL, so
the PR body keeps its one report link; replace the affected screenshots in `.open-pr/body.md`
and apply them with `gh pr edit <n> --body-file .open-pr/body.md`. A green canonical suite
does not refresh the evidence for the pre-fix head.

When fixes were pushed, run `/review-pr` on the new head, as `/open-pr` did for the first: the
PR is still a draft, and the PR-polling review service skips drafts. The watcher is still armed
and picks the new head up on its own; a watcher that expired while you were fixing is re-armed
here.

## 3. A red check

Before a fix changes CI workflow definitions, dependencies, runners, caching, setup or
sharding, invoke [ci-optimise](../ci-optimise/SKILL.md). Apply the same routing to pipeline
review findings in §2 and refresh the checklist's CI evidence for the new head.

The `ci-failed` event carries each failure's name and the `urls` that open it. A GitHub Actions
failure is reachable from the command line by resolving the run from the branch; a check posted
by anything else has no Actions run at all, and its URL is the only place its log lives.

```bash
gh run list --branch <branch>        # the failing run's id, for an Actions check
gh run view <run-id> --log-failed
```

Read the failing step's log, reproduce it locally, fix it, run the canonical suite, push, and
stamp the checklist comment and `.ic/checklist.md` with the pushed head; then run `/review-pr`
on the new head, as §2 does after a fix push. **Do not re-run a red check hoping for a different
answer.** The push gives the watcher a new head to report on.

## 4. Leaving the loop

A round is one posted review answered by one fix push. Keep going until the watcher emits
`quiet` and exits: the latest review on the current head has no Critical or High finding, and
every check is green. Then disposition whatever Medium and Low remain in one pass — inside the
ticket's scope it is fixed, outside it is deferred to a ticket, a false positive is resolved
with its reason — request no further round, and invoke `/ready-for-review`.

**Fail closed** when a pass's findings all sit inside the previous pass's fix: that is the
reviewer circling its own change, and it is read as the loop failing to converge, never as a
clean pass.

**A finding that oscillates** — the same finding returning after two fix rounds — is a design
question and it stops the run. Stop the watcher, post one summary comment on the PR listing
each open finding and its state, mirror it on the ticket, and stop there. The LFG decides —
in solo mode that is the user — with the interview bank's R1 and R2: fix now, follow-up
ticket, or accepted risk, and which follow-ups block release. The PR stays a draft and
`/ready-for-review` is not reached until they answer.

Stopping the run is the only reason to stop the watcher early. A watcher left armed on a PR
nobody is working on costs one GitHub read every 30 seconds and expires by itself; a watcher
stopped on a PR still in the loop is the bug this skill exists for.

## What this watcher does not yet catch

Eight confirmed findings shipped open with v1, listed with their effects in
[`docs/product/features/fix-pr.md`](../../docs/product/features/fix-pr.md). The ones that
change how you read a `quiet`:

- a clean verdict **followed by other prose** parses as clean, so a request written after the
  verdict is never dispositioned;
- an **empty `CHANGES_REQUESTED`** — no body, no inline comments — is skipped;
- a **base branch whose name contains a slash** defeats the required-checks lookup, and the
  `quiet` event says `undeclared` where it should say which contexts are required.

Read the `quiet` event's `required_from` field before acting on it, and read the latest review
yourself when it is short. A `quiet` is the watcher's reading, not a proof.

## Not this

- Producing the review → `/review-pr`, which never fixes.
- Marking the PR ready → `/ready-for-review`. Merging → the repository's gate.
- Re-running the acceptance surface from scratch → `/acceptance`.
- Leaving the work to someone else → `/handover`.
