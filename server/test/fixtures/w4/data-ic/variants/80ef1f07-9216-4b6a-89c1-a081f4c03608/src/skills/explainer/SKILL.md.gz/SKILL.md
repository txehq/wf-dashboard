---
name: explainer
description: Render a complex idea, mechanism, investigation, or long document as a published HTML page with diagrams where they carry the mechanism. Use when someone asks for an explainer, a writeup, a one-pager, or "explain this properly", for a subject with several interacting parts, a reader who will need to re-find it later, or a shape terminal scrollback cannot hold. Not for status updates, short answers, or lists of findings.
---

# /explainer — explain something properly, on a page

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Publishing/Explainer.md` (WF-EXP).
Where this file and the spec disagree, the spec wins: update this file to match it.

Terminal scrollback is a bad home for anything with **shape**. It has no diagram, no
stable link, no structure a reader can skim twice, and it is gone by tomorrow.

**The deliverable is a page published with `/publish-artifacts`, with a URL.**

---

## 1. Should this be an explainer at all?

A page is built and published only when someone asks for one. A skill that renders its page
through this one has already decided: go to §4.

**Say yes to the request when at least two hold:**

- **It has parts that interact.** Three or more moving pieces where the *relationships*
  matter more than any single piece. A pipeline, a state machine, a failure chain, a
  decision with knock-ons.
- **You are about to write four or more headings into chat.** That is the tell. If the
  answer needs its own table of contents, it needs its own page.
- **The reader will come back to it.** A decision record, an architecture explanation, an
  incident writeup, a rule someone must follow next month.
- **A picture would do work prose cannot.** See §3.
- **More than one person will read it**, or one person will read it more than once.

**Say no — and just answer in chat — when:**

- It is a status update, a merge report, or a list of findings.
- The answer is one claim with evidence, however long the evidence.
- You are reaching for a page because the material feels substantial. **The trigger is
  structure.** A 2,000-word answer with no interacting parts is a long message, and a page
  makes it a long message with a URL.
- The user asked a question. Answer it in chat.

⚠️ **The failure mode is publishing a wall of text with a nice header.** It implies an
editorial care the content does not have.

---

## 2. Structure — what actually makes it explain

Order the page by what the reader needs next. An explainer ordered like the author's
discovery process is unreadable, however complete.

1. **The claim, first, in one or two sentences.** What is true that the reader does not
   currently believe? If you cannot state it in two sentences you do not yet understand it
   well enough to publish.
2. **The reorientation.** Most complex explanations exist because someone holds a wrong
   model. State the correct model and the fact that makes it hold. Do not skip this section.
3. **The mechanism, with the diagram.** One diagram, early, carrying the shape. See §3.
4. **The concrete case.** A real trace, a real number, a real failure — before any
   generalisation, so the generalisation reads as knowledge.
5. **What follows.** The decision, the action, the thing to watch. An explainer with no
   "so what" is a lecture.
6. **What this does NOT say.** Bound the claim. Which surface it applies to, what was
   measured versus inferred, where it would stop being true. Anything you assert past your
   evidence will be quoted back at you with more confidence than you had.

**Length discipline:** an explainer is as long as *the subject's parts* require. If a section
does not change what the reader believes or does, cut it.

---

## 3. Diagrams — where they earn their place

**A diagram is required wherever the subject has a mechanism, a sequence, or a state
change.** Prose is bad at those and readers know it, which is why they skim to the picture.

**Draw diagrams in mermaid.** Put each diagram in its own `<pre class="mermaid">` block, and
load mermaid once, from its ESM build on the jsDelivr CDN, with the theme that matches the
page's:

```html
<script type="module">
  import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";
  const chosen = document.documentElement.dataset.theme;
  const dark = chosen === "dark"
    || (chosen !== "light" && matchMedia("(prefers-color-scheme: dark)").matches);
  mermaid.initialize({ startOnLoad: true, theme: dark ? "dark" : "default" });
</script>
```

For anything with quantities, load `dataviz`: it owns charts, palettes and accessibility.

**What to draw:**

- what happens in what **order**;
- where **state changes**, and to what;
- the **path a value takes**, end to end;
- **where it breaks**, marked on the real path;
- the **before/after** of a change.

⚠️ **A boxes-and-arrows diagram that restates the section heading is decoration.** The test:
cover the prose. Can a reader still get the mechanism from the picture? If not, make the
picture carry the mechanism or drop it.

**One diagram carries the whole shape.** Add a second only for a separate mechanism.

---

## 4. Producing it

1. **Load `artifact-design` before writing a single line of the file.** It is mandatory for
   every artifact and it owns format choice (HTML or Markdown), typography and layout. This
   skill does not restate it.
2. Write a **self-contained** `.html` file into `.explainer/` in the current directory, or to
   the location the user or the calling skill names. Before writing anything into
   `.explainer/`, create `.explainer/.gitignore` containing `*` with the file editing tool.
   Inline the CSS; Google Fonts may be linked; mermaid is loaded from its CDN build (§3); every
   image must already be published and referenced by its `/artifacts/img/<id>` URL. There is
   no build step and no server-side rendering at the destination. **When another skill asked
   for the page, stop here and return its path**: that skill publishes it.
3. **Publish with `/publish-artifacts`:**

   ```bash
   wf publish-artifact <file> --title "<title>"
   ```

   It prints the URL and nothing else. **`--title` is required**; it is the only
   human-readable thing on the index at `https://engapp.dev/artifacts`. Prefix the call
   with `ARTIFACT_VIA=explainer` so the analytics can tell explainers apart from
   screenshots and one-off uploads.

   ⚠️ **Do not use the `Artifact` tool for this org's work.** It publishes to claude.ai,
   which is outside the org's access control and outside its domain. `/publish-artifacts`
   puts the page on `engapp.dev` behind Cloudflare Access, where a colleague authenticates
   once and stays signed in for 30 days. Read that skill for the credential setup, the
   failure modes, and how to add someone to the allowlist.

4. **Hand the user the URL.** Do not paste the page's content back into chat.
5. To revise, edit the file and re-run with **`--id <the same 8-char id>`**. That replaces
   the object and keeps the link you already gave out. **Never publish a revision to a new
   id** — a changed link is how one shared explainer becomes two.

---

## 4b. Layout — two deliberate overrides

`artifact-design` owns layout and this skill does not restate it. These two settings are
**overrides**: they are the reader's stated preference, and `artifact-design`'s own
precedence puts the user's words first.

**Measure: ~85ch.** These pages are read on a vertical display. Set the column near `86ch`
and lift body size to ~18px with a looser leading to match, so the text does not read as
cramped there.

**Figures and wide tables break out of the column entirely.** A diagram is only in the
page because it carries something prose cannot (§3) — capping it at the width of a
sentence throws that away. Full-bleed it:

```css
.wrap  { max-width: 86ch; margin-inline: auto; padding-inline: 28px }
.bleed { margin-inline: calc(50% - 50vw); width: 100vw; max-width: 100vw;
         padding-inline: clamp(1rem, 3vw, 3.5rem) }
body   { overflow-x: clip }          /* 100vw + a classic scrollbar can overflow */
.bleed svg { width: 100%; max-width: 1560px; min-width: 860px; margin-inline: auto }
```

`min-width` on the SVG mermaid renders keeps it legible on a narrow window: the figure
scrolls inside its own container. The caption stays near the reading measure (`~74ch`,
centred); only the picture goes wide.

---

## 5. Anti-patterns

- **The wall with headings.** Structure is order and omission.
- **The decorative diagram.** See §3's cover-the-prose test.
- **Publishing a page nobody asked for.** Answer the question in chat; a page is published
  when someone asks for one.
- **Burying the claim under background.** Background comes no earlier than section 2, and it
  usually fits in a sentence.
- **The complete-and-useless reference.** If it reads like documentation of everything, it
  explains nothing. An explainer has a thesis.
- **A second URL for the same subject.** Re-publish with the same `--id`.
- **Publishing to claude.ai via the `Artifact` tool.** Wrong destination for org work — see §4.
- **A diagram boxed into the text column.** See §4b — it is the one element that should be wide.
- **Restating `artifact-design` / `dataviz` here.** They own their craft.

---

## Self-improvement

After running this skill, update this file if: a trigger in §1 turned out to be wrong in
either direction, a structural section was consistently skipped or consistently missing, a
diagram type in §3's list needs adding or removing, or the hand-off in §4 drifted from what
`/publish-artifacts` actually requires.

⚠️ **Check the theme guard before publishing:** scan the stylesheet for any color declared
*only* inside a `@media` or `[data-theme]` block, and confirm the dark-theme guard is
`@media (prefers-color-scheme:dark){ :root:not([data-theme="light"]) }`. Nesting the two the
other way round renders one theme's text on the other theme's ground for every viewer on the
default system setting.
