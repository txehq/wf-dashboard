---
name: codebase-design
description: >-
  Shared vocabulary and principles for designing deep modules — a lot of behaviour behind a
  small interface, placed at a clean seam, testable through that interface. Use when designing
  or improving a module's interface, finding deepening opportunities, deciding where a seam
  goes, making code more testable or easier for an agent to navigate; /implement reads it before
  creating or reshaping a module, and its implementation review judges modules by it. It asks
  nothing; when someone asks for alternative interfaces, DESIGN-IT-TWICE.md starts design-only
  sub-agents.
---

# /codebase-design — deep modules

Design **deep modules**: a lot of behaviour behind a small interface, placed at a clean seam,
testable through that interface. Use this language and these principles wherever code is being
designed or restructured. The aim is leverage for callers, locality for maintainers, and
testability for everyone.

## Glossary

Use these terms exactly: don't substitute "component", "service", "API" or "boundary".
Consistent language is the whole point.

- **Module** — anything with an interface and an implementation. Deliberately scale-agnostic: a
  function, a type, a package, a slice spanning tiers. *Avoid:* unit, component, service.
- **Interface** — everything a caller must know to use the module correctly: the type
  signature, and also invariants, ordering constraints, error modes, required configuration and
  performance characteristics. *Avoid:* API, signature (both name only the type-level surface).
- **Implementation** — what is inside a module, its body of code. Distinct from **adapter**: a
  thing can be a small adapter with a large implementation (a Postgres repository) or a large
  adapter with a small implementation (an in-memory fake). Say "adapter" when the seam is the
  topic, "implementation" otherwise.
- **Depth** — leverage at the interface: how much behaviour a caller, or a test, can exercise per
  unit of interface it has to learn. **Deep**: a lot of behaviour behind a small interface.
  **Shallow**: an interface nearly as complicated as the implementation.
- **Seam** *(Michael Feathers)* — a place where behaviour can change without editing in that
  place; the *location* a module's interface lives at. Where to put the seam is its own design
  decision, separate from what goes behind it. *Avoid:* boundary.
- **Adapter** — a concrete thing that satisfies an interface at a seam. It names a role, the
  slot it fills.
- **Leverage** — what callers get from depth: more capability per unit of interface learned.
  One implementation pays back across every call site and every test.
- **Locality** — what maintainers get from depth: change, bugs, knowledge and verification
  concentrate in one place. Fix once, fixed everywhere.

## Deep vs shallow

A **deep module** is a small interface over a lot of implementation:

```mermaid
flowchart TB
  di["Small interface — few methods, simple parameters"]
  dd["Deep implementation — complex logic hidden"]
  di --- dd
```

A **shallow module** is a large interface over little implementation, and is the shape to
avoid:

```mermaid
flowchart TB
  si["Large interface — many methods, complex parameters"]
  sd["Thin implementation — just passes through"]
  si --- sd
```

When designing an interface, ask:

- Can I reduce the number of methods?
- Can I simplify the parameters?
- Can I hide more complexity inside?

## Principles

- **Depth is a property of the interface.** A deep module can be built inside from small,
  swappable parts; they stay out of its interface. A module can have **internal seams**, private
  to its implementation and used by its own tests, beside the **external seam** at its
  interface.
- **The deletion test.** Imagine deleting the module. If the complexity vanishes, it was a
  pass-through. If the complexity reappears across its callers, it was earning its keep.
- **The interface is the test surface.** Callers and tests cross the same seam. Wanting to test
  *past* the interface says the module is the wrong shape.
- **One adapter means a hypothetical seam; two adapters mean a real one.** Introduce a seam
  only where something actually varies across it. A network or process boundary is a real seam
  with its one production adapter.

## Designing for testability

Good interfaces make testing natural:

1. **Accept dependencies; leave creating them to the caller.**

   ```typescript
   // Testable
   function processOrder(order, paymentGateway) {}

   // Hard to test
   function processOrder(order) {
     const gateway = new StripeGateway();
   }
   ```

2. **Return results; leave applying them to the caller.**

   ```typescript
   // Testable
   function calculateDiscount(cart): Discount {}

   // Hard to test
   function applyDiscount(cart): void {
     cart.total -= discount;
   }
   ```

3. **Keep the surface small.** Fewer methods need fewer tests; fewer parameters need less test
   setup.

## Relationships

- A **module** has exactly one **interface**, the surface it presents to callers and tests.
- **Depth** is a property of a **module**, measured against its **interface**.
- A **seam** is where a **module**'s **interface** lives.
- An **adapter** sits at a **seam** and satisfies the **interface**.
- **Depth** produces **leverage** for callers and **locality** for maintainers.

## Rejected framings

- **Depth as the ratio of implementation lines to interface lines** (Ousterhout's own
  definition) rewards padding the implementation; depth here is leverage.
- **"Interface" as a language's `interface` keyword or a type's public methods** is too narrow:
  the interface is every fact a caller must know.
- **"Boundary"** carries other meanings; say **seam** or **interface**.

## Going deeper

- **Deepening a cluster of shallow modules, given its dependencies** — [DEEPENING.md](DEEPENING.md):
  dependency categories, seam discipline, and replacing the old tests with tests at the new
  interface.
- **Exploring alternative interfaces**, when someone asks for alternatives or an interface's
  shape is still open — [DESIGN-IT-TWICE.md](DESIGN-IT-TWICE.md): sub-agents design the
  interface in several very different ways, then the designs are compared on depth, locality and
  seam placement.
