---
name: implement
description: "Step 3 of /ic — from a claimed ticket with a requirements checklist to a branch where every requirement is implemented and tested locally: find out whether the session is already in an isolated worktree and create one from the remote's latest development branch only if not, mirror the checklist into the worktree, implement each line strictly and completely with the test that proves it, run the inner loop and then the repository's canonical verdict, tick the checklist and update it on the ticket. Use when someone says \"implement TXE-N\", \"build this ticket\", \"start coding on this\"; invoke it proactively, saying so in one line, when a ticket has a checklist and a verified machine and the next step is code. Never widens the ticket; a requirement that cannot be met becomes a comment on the ticket."
---

# /implement — every requirement, nothing else, proven locally

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Session/IC Session.md` (WF-IC — the
corpus has no separate node for this step), with the *Branch & Coding* and *Local Build &
Test* rows of `Project Magi/Workflow/System Design.md` §2. Where this file and the spec
disagree, the spec wins: update this file to match it.

## Contract — what goes in, what comes out

| | |
|---|---|
| **In** | the claimed ticket with its `<!-- ic:checklist -->` comment; the feature documents `/claim` read; a machine `/readiness` has verified |
| **Out** | a branch in an isolated worktree with the work committed; `.ic/checklist.md` in the worktree with every line ticked and its file and test named, and the **ticket's checklist comment updated** to match, with the head SHA; the canonical test verdict green locally |
| **Next** | `/acceptance` when the ticket has a visible surface or declares evidence; then `/open-pr` |

## When this skill starts

- **On request:** `/implement TXE-N`, "implement this ticket", "build TXE-N", "start coding".
- **From `/ic`:** as step 3, after `/claim` and `/readiness`.
- **Proactively:** the ticket has a checklist, the machine is verified, and the next step is
  code. Say "running /implement on TXE-N" and begin.
- **Not** without a checklist → `/claim` first. Not for a change with no ticket → `/lfg`.

## 1. Workspace — find out where you are before you make anything

A harness may already have put you in a linked worktree on a branch of its own, and a lane
dispatched by `/ticketing` always arrives in one. So look first, and resolve the repository's
**development branch**, which every later step reads as `$dev`: when its contract or `CLAUDE.md`
names the integration branch, `dev` is that name; when neither names one, `dev` is the
repository's default branch.

```bash
git rev-parse --show-toplevel
[ "$(git rev-parse --path-format=absolute --git-dir)" != "$(git rev-parse --path-format=absolute --git-common-dir)" ] \
  && echo "linked worktree" || echo "main checkout"
git status --porcelain
dev=$(gh repo view --json defaultBranchRef -q .defaultBranchRef.name)  # unless a contract names it
```

- **Already in a linked worktree** → start here, on this branch. Record its name; when it does
  not carry the ticket id, pass `--ticket TXE-<n>` to the tools that read it (`/handover`). Do
  not rename the branch: the harness may be tracking it. A worktree carrying someone else's
  uncommitted changes stops the run: name the changes and ask.
- **In the main checkout** → make one. Fetch the development branch, cut the ticket's branch
  from the remote's *latest* state of it, and create the worktree for that branch:

```bash
git fetch origin "$dev"
git worktree add "../<repo>-txe-<n>" -b "<handle>/txe-<n>-<slug>" "origin/$dev"
cd "../<repo>-txe-<n>"
```

- **No checkout at all** → `gh repo clone <owner>/<repo>` first, then the step above.

The branch is cut from what the remote has now. One ticket, one worktree, one branch; the
worktree and the claim comment are the ownership record. Never share a worktree between lanes.

## 2. Mirror the checklist into the worktree

`/ic`'s working directory is `.ic/` in the worktree root. Before writing anything into it,
create `.ic/.gitignore` containing `*` with the file editing tool, which keeps the directory
out of the commits. Then copy the ticket's checklist comment to
`.ic/checklist.md`.

This is the working copy; the ticket comment is the durable one. Tick here as you go, and
push the ticks back in §5.

Copy the feature folder's `Brief.md`, `Research.md` and `Tickets.md` into `.ic/` as well, when
the ticket has them. They are the reference this run works from.

Keep `.ic/progress.md` as the run's engineering log: after each requirement, each decision and
each dead end, append one line — what was done or decided, why, and what comes next. Record
what the code and the ticket do not already say: approaches tried and dropped, gotchas found,
open questions. After the context is compacted, and on every resumed entry, read the log, the
checklist and the copied documents from `.ic/` before doing anything else.

## 3. Implement — strictly, and completely

For CI pipeline creation, optimisation or modification, invoke
[ci-optimise](../ci-optimise/SKILL.md) before editing, including direct or resumed entry.
Keep its critical-path analysis and validation evidence with the checklist and current head.

For frontend work, after the workspace and checklist setup in §§1–2, invoke
[ui-text-simplify](../ui-text-simplify/SKILL.md) before editing, including direct or resumed
entry. Keep changes within the checklist and persist its affected-state checks as below.

The ticket governs; `Research.md` is earlier findings, and may be wrong or stale. Read it
Socratically — question each claim against the code as it is now — and where a better way to
deliver the ticket's requirements shows, take it: working functionality comes first.

Work the checklist, line by line. Every line becomes code **and** the test that proves it; a
requirement with no test is not done.

- **Omission.** Nothing in the checklist is skipped, deferred, stubbed with a TODO, or
  "covered by" a neighbouring change. Before §4 every box is ticked with the file and test
  that satisfies it — or the ticket has a comment saying exactly which requirement is blocked
  and why.
- **Drift.** Nothing outside the slice boundary is touched — no refactor of the neighbouring
  module, no "fix while you're in there", no widening the ticket because it would be tidier.

Follow the repository's conventions, so new code reads like the code around it; the reviewer
will. Commit in coherent steps, each message naming the requirement it satisfies (`R3: …`).
When the change needs the structure it touches reshaped first, make the change easy, then make
the easy change: the behaviour-preserving refactoring is a commit of its own, ahead of the behaviour.

Build it by software-engineering principles: high cohesion and low coupling, single
responsibility, separation of concerns, information hiding, DRY and YAGNI, honest names. Keep
these code smells out — the implementation review in §4 reads the change for them:
Mysterious Name, Duplicated Code, Feature Envy, Data Clumps, Primitive Obsession, Repeated
Switches, Shotgun Surgery, Divergent Change, Speculative Generality, Message Chains, Middle Man,
Refused Bequest. When the change creates a module or reshapes one's interface, read
[codebase-design](../codebase-design/SKILL.md) first.

If the criteria cannot be met as written, comment on the ticket with what you found and what
you propose, and wait for the LFG. That comment is the interview bank's M5 — the invalidated
assumption, its evidence and impact, and the three ways out: revise and continue, defer the
capability, or stop. It is never resolved by widening or narrowing the ticket yourself.

## 4. Test — locally

Keep the inner loop native and fast (`cargo check`, `go test ./...`, `pnpm test`); it is for
iteration only. Evidence is the repository's **canonical verdict**: its full test suite or
Bazel target set, run locally in this worktree before anything leaves it. End-to-end tests
run locally too. A red canonical verdict is fixed here, before `/open-pr`.

Before the canonical verdict, while the branch has never been pushed, rebase it onto the
development branch's latest state (`git fetch origin "$dev"`, then `git rebase "origin/$dev"`),
resolve any conflicts here, and check that what the development branch changed still fits this
change, so every later step reads the head that will merge.

With the canonical verdict green and the work committed, run the
[implementation review](references/implementation-review.md): Codex reads the change against the
ticket, for defects, and against the repository's standards, the code smells and the module
principles, each separately. Decide on its findings once, and run the canonical verdict again
after any fix.

## 5. Tick, and write the ticks back

Every checklist line now carries its file and its test. Edit the ticket's checklist comment,
the one `/claim` posted, to match, and stamp it with the head SHA:

```markdown
<!-- ic:checklist head=<sha> -->
## Requirements checklist · /ic · <ISO time>
- [x] R1 <requirement> — verify: test — file: src/x.rs — test: tests/x.rs::r1_…
- [x] R2 …
Canonical verdict: <command> · green · <ISO time>
```

For frontend tasks, also add a `## UI text checks` section to `.ic/checklist.md` and
mirror it in the **same ticket checklist comment**, stamped with the implementation head:

```markdown
## UI text checks
Head: <sha>
| Surface / state | Evidence or way to reach it | Decision / expected visible result |
| --- | --- | --- |
| <affected surface and state> | <source or reproduction steps> | <copy and presentation decision> |
Unresolved facts: <none, or what still needs verification>
```

Include the relevant empty, error, permission and partial-data states identified during
implementation, even when the decision is to keep their wording. Backend-only tasks do
not add this section. This section is the record `/acceptance` reads after a resume or a
checkout on another machine.

`/ready-for-review` reads this comment as one of its three conditions; a checklist ticked
only on one machine is a checklist nobody else can trust.

## Handing off

Echo, for the caller: the worktree path, the branch, the head SHA, the changed files, and the
canonical command that went green. `/acceptance` takes it from here when the ticket has a
surface a person can see or declares evidence; when it has neither, `/open-pr` does.
For frontend work, also identify the UI text checks section and its head in the local
checklist and ticket comment so the next step can retrieve it. The worktree, the commits and
the checklist comment are this step's record.

## Not this

- Reading the ticket and writing the checklist → `/claim`.
- Verifying the machine → `/readiness`.
- Screenshots and the acceptance report → `/acceptance`. The PR → `/open-pr`.
