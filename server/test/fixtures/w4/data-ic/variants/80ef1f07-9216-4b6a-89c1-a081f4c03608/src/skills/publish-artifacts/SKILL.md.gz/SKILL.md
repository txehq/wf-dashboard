---
name: publish-artifacts
description: Publish an HTML page or a screenshot to https://engapp.dev/artifacts and return a shareable URL. Use whenever a coding session produces something a human should look at in a browser — an explainer page, a local dev screenshot, a rendered report — and for any request to "publish", "upload", "share" or "give me a link to" such a thing. Anything published for this org's work is published with it; the claude.ai `Artifact` tool publishes outside the org's access control.
---

# /publish-artifacts — put it on engapp.dev and hand over the link

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Publishing/Publish Artifacts.md` (WF-PUB).
Where this file and the spec disagree, the spec wins: update this file to match it.

Artifacts from coding sessions go to **`https://engapp.dev/artifacts`**, an R2 bucket
behind Cloudflare Access. Colleagues open the link, authenticate once, and stay signed in
for 30 days.

**Anything published for this org is published with this skill.** The `Artifact` tool
publishes to claude.ai, outside the org's access control and outside its domain.

---

## Publishing

```bash
wf publish-artifact <file> --title "<title>"
```

On success it prints one line, the URL. Hand that to the user.

```
$ wf publish-artifact ./txe-workflow.html --title "Four Gates and a Retag"
https://engapp.dev/artifacts/page/k3m9q1xz
```

**Kind is inferred from the extension** and rarely needs `--kind`:

| extension | kind | served as |
|---|---|---|
| `.html` `.htm` | `page` | `text/html; charset=utf-8` |
| `.pdf` | `page` | `application/pdf` |
| `.png` `.jpg` `.jpeg` `.gif` `.webp` `.svg` | `img` | the matching image type |

**`--title` is required**: it is the only human-readable thing on the index at
`https://engapp.dev/artifacts`. Do not use the file name as the title.

**Ids are 8 characters of `[0-9a-z]`, generated for you.** The CLI checks candidate URLs
with HEAD and retries up to five times. Two concurrent publishers can still pick the same free
id. Pass `--id` only to deliberately **replace** an existing artifact — updating in place keeps
the link you already gave out.

---

## What to publish

- **Explainers** — see the `explainer` skill, which produces the page and then calls this.
- **Screenshots of local dev** — a page you rendered, a UI state worth a second opinion,
  a diff of before/after.
- **Terminal output meant for a human to read.**

Do **not** publish: secrets, `.env` contents, tokens, customer data, or a screenshot with
any of those in frame. Access decides *who can read it*, and the bucket has no expiry —
assume anything published stays.

---

## The setup, and its limits

| | |
|---|---|
| Bucket | R2 `engapp-artifacts`, Capso account |
| Worker | `engapp-artifacts`, route `engapp.dev/artifacts*` |
| Gate | Cloudflare Access app *Session Artifacts*, **720h (30-day)** session |
| Login | one-time PIN to an allowlisted email — no SSO configured |
| Uploads | Access **service token**, the only check |
| Credentials | `~/.config/engapp-artifacts/env`, mode 600, **deliberately outside every git repo** |

**One secret is required to write: the Access service token.** It gets the request past the
gate.

⚠️ **Reads and writes are gated, and writes carry no verified author.** Access decides who
gets in, and everyone it admits can publish. The index shows a session label the uploader
supplies, as self-reported provenance.

⚠️ **The artifact is a static object.** No server-side rendering, no build step, no
`fetch()` back to anything private. Pages must be self-contained — inline the CSS, or link
Google Fonts, which is permitted. Images referenced from a page must themselves be
published and referenced by their `/artifacts/img/<id>` URL.

### Setup — the credential file

`wf publish-artifact` reads `~/.config/engapp-artifacts/env` (override with
`ENGAPP_ARTIFACTS_CRED`). Create it once, mode 600, and keep it outside every repo:

```text
ENGAPP_ARTIFACTS_BASE=https://engapp.dev/artifacts
CF_ACCESS_CLIENT_ID=<Access service token id>
CF_ACCESS_CLIENT_SECRET=<Access service token secret>
```

Ask a Capso Cloudflare admin for a **service token** on the *Session Artifacts* app. All
three keys are required. `wf` reads the file without sourcing it, takes the three keys from
it and ignores shell exports of them. Keep secret values out of chat, logs and command
arguments.

To rehearse with an existing, non-sensitive file:

```bash
wf publish-artifact ./fixture.html --title "Publishing check" --dry-run
```

`--dry-run` validates the file path, extension, title and optional kind/id, and collects
metadata. Missing or incomplete credentials fall back to the default URL; **success does
not validate credentials or publishing access**. Metadata collection can call `gh pr list`,
so a dry run can reach the network. Add `--json` for the normal JSON envelope; without it,
success prints one line. A dry-run line starts with `(dry-run)`. Do not hand it out as a link.

Run the same command without `--dry-run` to publish the fixture. The CLI checks read-back
HTTP status before returning a URL; for acceptance, also fetch that URL through Access and
compare the body with the fixture, because a login page also answers HTTP 200. `wf doctor`
checks installation state, and an engapp readiness credential check detects the credential
material and reports it as opaque. The read-back and the body comparison prove a publish.

### Adding a colleague

For browser reading, they need an Access policy entry. Add their email to the *Humans — email
OTP* policy on the **Session Artifacts** app, found under Access, Applications in the Zero
Trust dashboard. They then sign in with a one-time PIN and are good for 30 days. To publish
through `wf`, they also need the service-token credential file above: the CLI authenticates
with that file alone.

---

## Provenance — captured automatically, for workflow analysis

Every publish records the context it happened in, and **`wf` gathers all of it**. It exists
so the team can later ask questions like *which tickets produce explainers*, *how often are
we publishing from a dirty tree*, or *which sessions never publish anything at all*.

| field | from | why it is worth having |
|---|---|---|
| `git_name` `git_email` | `git config user.name/.email` | **the per-developer key** |
| `session` `instance` `workspace` `session_id` | `CLAUDE_CONFIG_DIR`, `$TMUX`, `CLAUDE_CODE_SESSION_ID` | which session, and one you can still `tmux attach` to |
| `repo` `branch` `sha` `base_sha` | git, in the CWD | exactly what was checked out |
| `ticket` | parsed from the branch name | joins to Linear |
| `pr` | `gh pr list --head <branch>` | **joins to review and CI data** |
| `ahead` `behind` `dirty` `changed` | ahead vs upstream; behind vs `origin/main`; working-tree status | *published from a tree N commits behind main* is a workflow finding on its own |
| `worktree` `git_root` | is this a linked worktree, and where | worktree hygiene, and which pool tree was in use |
| `sha256` | first 16 hex of the file digest | makes a republish of identical bytes detectable — distinguishes a real revision from a re-run |
| `via` | `$ARTIFACT_VIA`, set by the calling skill | which skill produced it (`explainer`, a screenshot flow, manual) |
| `host` `user` `bytes` `kind` `tool` | the machine and the upload | — |

`pr` is fetched with a **6-second timeout and is non-fatal**: a failed probe omits that field,
and the publish goes on. Every other external metadata probe has its own 6-second timeout.

**Query it all at `https://engapp.dev/artifacts/_meta.json`** — one JSON document, every
artifact, every field, newest first. The index page shows the same data for people.

⚠️ **The remote URL is sanitised** before storage — an `https` remote can carry a token in
the userinfo, and this string is stored and displayed. Keep anything you would not want the
whole allowlist to read out of titles and filenames too.

⚠️ **`git_email` is a personal address, stored and visible to the whole allowlist.** It is
recorded because it is the per-developer key.

⚠️ **Provenance is self-reported.** The uploader supplies it, the Worker stores it, and
nothing verifies that a `sha` was ever real. Use it to analyse how work flows.

---

## Failure modes worth recognising

| symptom | what it is |
|---|---|
| `HTTP 403` / `PUBLISH-NETWORK` with status 403 | Access or another upstream policy rejected the request |
| `PUBLISH-HTTP` with HTTP 400 | the Worker refused the upload: a required header is missing, or `x-artifact-meta` is not valid JSON |
| An HTML login page, or `PUBLISH-ID-EXHAUSTED` despite unused IDs | Access may have redirected probes to login; check authentication before treating this as five real collisions |
| `bad kind/id` / `PUBLISH-ID` | kind must be `page` or `img`; id must be exactly 8 chars of `[0-9a-z]` |
| `PUBLISH-NOT-SERVABLE` | PUT succeeded and the read-back failed. **Do not hand out the URL** |
| `PUBLISH-PROXY-DOWN` / `PUBLISH-PROXY-REFUSED` / `PUBLISH-PROXY-CLOSED` | the request failed at the proxy; see §Behind a proxy |
| `PUBLISH-NETWORK` with an `io:` error | the connection failed somewhere other than at a proxy. When the request went through a proxy, the message names it |

The transport is Rust, in `crates/wf-publish-artifact/`. Read-back checks for HTTP 200 and
leaves the body unchecked; verify the content separately when proving a deployment or install.

### Behind a proxy

Every request goes through one proxy: the first of `ALL_PROXY`, `all_proxy`, `HTTPS_PROXY`,
`https_proxy`, `HTTP_PROXY`, `http_proxy` that holds a proxy URL (`http`, `https`, `socks4`,
`socks4a`, `socks5`, `socks5h`). `NO_PROXY` / `no_proxy` exempt hosts from it. While an earlier
variable in that list holds a proxy, a later one has no effect: with `ALL_PROXY` set, changing
`HTTPS_PROXY` changes nothing.

A failure at the proxy names the variable that was used and its URL, with any user name and
password shown as `***`, and says what the proxy did:

| class | what the proxy did | what to change |
|---|---|---|
| `PUBLISH-PROXY-DOWN` | the connection to its address was refused: nothing is listening there | start that proxy, point the named variable at one that is running, or unset it |
| `PUBLISH-PROXY-REFUSED` | it answered and refused engapp.dev, with an HTTP status to `CONNECT` or a SOCKS reply | the proxy runs and will not carry engapp.dev. Point the named variable at a proxy that will, or unset it |
| `PUBLISH-PROXY-CLOSED` | it accepted the connection and closed it before engapp.dev answered | the proxy does not carry engapp.dev. Point the named variable at a proxy that will, or unset it |

Each message ends with the variable that takes over once the named one is unset, or with
"connects to engapp.dev directly" when none does. `ALL_PROXY` and `all_proxy` often hold the
same URL, and unsetting one leaves the other in charge. Unset variables until the one you want
is in charge, for this one command:

```bash
env -u ALL_PROXY -u all_proxy HTTPS_PROXY=<a proxy that carries engapp.dev> wf publish-artifact <file> --title "<title>"
```

Use a proxy the person runs on this machine for its own traffic, such as the one their `gh`
and `git push` already go through. A proxy that an agent harness puts into the session
environment for its sandbox refuses hosts outside the sandbox's allowlist on purpose: when
the refusing proxy is that one, report the error to the person and ask them to allow
engapp.dev there. Do not route around it.

---

## Self-improvement

Update this file when: an extension needs adding to the type table, a failure mode appears
that is not listed, the Access session length or policy changes, or the credential path
moves. If the CLI grows a flag, document it here in the same edit — a flag nobody knows
about is a flag nobody uses.

Worker source lives at [`worker/worker.js`](worker/worker.js) — the deployed copy is
uploaded from there, so a behaviour change is an edit here plus a redeploy, and the two
must not drift.

Before deploying `worker.js`, every object in the `engapp-artifacts` bucket must carry custom
metadata with `title`, `session`, `uploaded` and a JSON `meta`: the index and `_meta.json` fail
on an object that lacks them. Republish such an object with
`wf publish-artifact <file> --title "<title>" --id <its id>`, which uploads it again with every
header the Worker requires.
