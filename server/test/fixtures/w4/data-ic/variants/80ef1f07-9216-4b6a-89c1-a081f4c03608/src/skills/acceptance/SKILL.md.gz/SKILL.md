---
name: acceptance
metadata:
  upstream-version: "0.3.0"
  upstream-commit: "73c35f4c68593996159b1822e4e935f5a04395fa"
  skill-version: "0.3.1"
description: >
  End-to-end verification and self-evidence for a delivery in any repository,
  with or without a preconfigured verify plan. Discover an existing plan when
  one was handed to this run; otherwise author checks and publish a standalone
  acceptance. Pick the proving surface (CLI / web / desktop / iOS Simulator),
  drive the real product, capture visually confirmed evidence, and publish one
  complete acceptance report per delivery to engapp.dev with publish-artifacts,
  republished in place on each repair. Embed screenshots in
  GitHub PR/Issue template sections with gh-image and link the full acceptance
  report in the PR body. Triggers on 'verify the task', 'collect evidence',
  'prove it works', 'upload evidence', 'verify plan', 'requiredEvidence',
  'local test', 'manual test', 'test report', 'test with cli', 'test in
  electron', 'test desktop', or any local end-to-end verification task. Needs no
  ambient ids. Automatically install missing required dependencies.
---

# Acceptance (Builder Self-Evidence)

This is the Capso adaptation of upstream acceptance 0.3.0; see
[upstream.md](references/upstream.md) for the source and changes.
Publish with the [publish-artifacts skill](https://github.com/txehq/txe-workflow/blob/main/skills/publish-artifacts/SKILL.md)
to **https://engapp.dev/artifacts**. Never contact LobeHub's server or use its
`lh` CLI for plans, evidence, authentication, history, or publication.

You are the **builder** for a delivery. A separate review step judges it against
a **plan** — checks you author, or a verify plan handed to this run. A check that
declares `requiredEvidence` **cannot pass on your text alone**: a missing artifact
marks it `uncertain` and holds the delivery.

For frontend deliveries, apply [ui-text-simplify](../ui-text-simplify/SKILL.md) to the affected
rendered states, including direct entry and review fixes. For `/ic`, read `UI text checks`
from `.ic/checklist.md` or the mirrored ticket checklist comment, compare its head with
the current diff, and include those states and decisions in this round's plan. If missing
or stale, reconstruct and persist the section from the criteria and current code before
verification. Standalone frontend acceptance records the checks in its own local plan.
Keep unrelated pages outside the task.

```mermaid
flowchart LR
  plan["Author or discover the plan"] --> surface["Pick the surface"]
  surface --> evidence["Capture evidence"]
  evidence --> publish["Publish the report"]
  publish --> coverage["Self-check coverage"]
```

## Read the project layer first

Before touching an environment, check for `.agents/acceptance/`:

| File                     | What it owns                                                 |
| ------------------------ | ------------------------------------------------------------ |
| `PROJECT.md`             | Start/stop commands, ports, services, auth, surfaces, probes |
| `PROCESS.md`             | The run process: approval gate, execution rules, teardown    |
| `common-mistakes.md`     | Project living log — what earlier rounds got wrong here      |
| `probe-mock-patterns.md` | Project living log — how to force state on this product      |

The project layer owns _how this repository is run_; this skill owns _what a
valid round is_ (plan, evidence, report and its publication, the hard rule). On
running, the project layer wins; on what may be published, this skill wins. Never
invent a start command, port, or auth flow `PROJECT.md` answers; fix a divergence
in the adapter during the run. When `.agents/acceptance/` is absent, bootstrap one
first: [project-adapter.md](references/project-adapter.md).

## Living logs — inject each by its own shape

Both layers (this skill's generic copies and the project's own) are loaded once
the target is known, silently:

- **[common-mistakes.md](references/common-mistakes.md)** — read its
  **Checklist** in full, now and again before marking any case `pass`. Pull an
  entry by id only when a checklist line applies to a case.
- **[probe-mock-patterns.md](references/probe-mock-patterns.md)** — read the
  heading index, pick the entries this round needs by meaning, and pull each one
  in full.

```bash
rg -n '^#{2,4} ' <file>          # the index, with line numbers
sed -n '<start>,<end>p' <file>   # one entry, in full
```

Record new project-specific learnings in the project layer only.

## Two paths — no id is required

Every evidence command targets a round. **The authored path is the default**; you
have an operation id only when the invocation names one. Never hunt the
environment for one, and never report this skill inapplicable — a round without
an operation is simply recorded as `standalone`.

| You have                        | Path                                                                                                                 |
| ------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| No plan - you author the checks | Write `result.json` + `assets/`, render a complete HTML report, publish with `wf publish-artifact` - [report.md](references/report.md) |
| A plan or operation id was given | Read the supplied local/exported plan and preserve its criteria - [plan-format.md](references/plan-format.md). An id alone is not a plan. |

Use the caller's subject or current repository/branch as the local grouping key.
Record the one-sentence `requirement` on the first round and retain it on repairs.
No remote session or operation lookup is needed.

## Dependencies - install missing tools automatically

Read [dependencies.md](references/dependencies.md) before executing. It contains
the installation and verification steps for **Agent Browser** (`agent-browser`
and Chromium, for Web/Electron), **gh-image** (`gh extension install
drogers0/gh-image`, for GitHub screenshots), **uv** (runs this skill's Python
scripts, including report rendering), and **publish-artifacts** (the skill and its
`wf publish-artifact` executable, for every published report).
Probe first; install missing dependencies in the current user's scope as part of
the task, then exercise them. Do not stop at installation advice. Credentials
are separate prerequisites: report a missing credential without exposing it or
switching to another publishing service. Install only drivers needed by the
selected surface; native macOS/iOS retain their platform prerequisites.

## HARD RULE — programmatic gates are NEVER acceptance checks

Every check MUST be an outcome a **person decides about the delivery**: what the
user sees, hears, reads, or receives. These MUST NOT appear as a check, under any
phrasing: unit / integration / regression / snapshot tests, coverage,
`type-check` / `tsc`, lint / `eslint`, format, "compiles", "build passes",
"CI is green". Run them, then report them as **one line of narrative**.

Before publishing, review title, category, AND `method`; "run `bun run test`"
under a product-sounding title is still a gate. Remove gate-only items and
recount `summary`; do not publish a report consisting only of gates. This is an
agent check: the static publisher does not filter or validate acceptance JSON.
The _subject_ of the check draws the line: a CLI behavior asserted by a command
is a check (`verifier: "program"`), and "the suite is green" is a gate. Before
writing any plan, ask of each draft check: _would the user click accept/reject on
this?_

## One report per delivery — a repair republishes it in place

Each delivery, identified by its subject key, has one published acceptance
report. The first publication records the returned URL and artifact id in
`acceptance.json`. **A repair after a code change runs as a new round** and
republishes the complete current report with
`wf publish-artifact "$REPORT_DIR/report.html" --title "<delivery> - acceptance" --id <artifact id>`,
which replaces it at the same URL. The PR or Issue body links that one URL.

Before a repair round, read `acceptance.json`, the previous round's `result.json` and
`publication.json`, and recorded reviewer decisions. Carry accepted unchanged checks
forward, copying their evidence into this round and keeping their date; rerun changed
or rejected checks under their
exact stable ids. The static page has no server-side review or aggregate: record
decisions with their source explicitly, and never treat an agent's pass as human
acceptance.

## Rules you will be tempted to skip

| Situation | Rule |
| --- | --- |
| The case needs an error state the happy path never reaches, and the unit tests already pass | The error state is the goal. Walk the probe ladder ([probe-mock-patterns.md](references/probe-mock-patterns.md) A) before calling it blocked. (M2) |
| The branch name suggests what to verify, or setup is about to be narrated ("Loading the living logs first…") | The task lives in the user's words. Recover it, or confirm a labeled guess with one structured question. Do not narrate setup. (M3, M21) |
| A capture is black, and display sleep or a missing permission looks like the cause | Measure first: pixel brightness, the permission bit, an A/B with one variable toggled. Publish the cause as "confirmed by X" or as "suspected". (M4) |
| Choosing how to run the environment, signing in, or deciding whether a user-facing change gets a screenshot | Environment mechanics are yours: a full isolated run, sign-in inside the automation session ([auth-web.md](references/auth-web.md)), and a screenshot for every user-facing change. Do not start a login that opens in the user's own browser. Ask only about the product decision. (M8) |
| The environment does not boot yet, a service it needs is not running, or a subagent died mid-run | Keep working until the environment runs: inventory running instances, start the real services the run needs, re-delegate a dead subagent's remaining steps, and remove each experimental edit that did not help with the file editing tool. (M17) |
| The fix is in and the tests pass | Reproduce the failure's precondition first, then verify with it held, through the real services it depends on. A run that cannot fail proves nothing; "reproduces sometimes" means an unnamed precondition. (M31) |

## Pick the surface by what you changed

Match what the change touches to its row below; move to another surface only when
that row's surface cannot prove the criterion.

| What your task changed                                      | Surface                                               | Guide                                                  |
| ----------------------------------------------------------- | ----------------------------------------------------- | ------------------------------------------------------ |
| Backend / CLI / library / data logic                        | **CLI** — stdout as `text`, zero UI flakiness         | [surfaces/cli.md](surfaces/cli.md)                     |
| Web app frontend / styles / interactions                    | **Web** (agent-browser driving the running web app)   | [surfaces/web.md](surfaces/web.md)                     |
| New/changed API **plus** the UI consuming it                | **Web**, full-stack (agent-browser + network capture) | [surfaces/web.md](surfaces/web.md#web-full-stack)      |
| Desktop-only behavior (native windows, IPC, packaged shell) | **Electron** (agent-browser `--cdp`)                  | [surfaces/electron.md](surfaces/electron.md)           |
| Native macOS app / OS chrome agent-browser can't reach      | **Native** (osascript + screencapture, local macOS)   | [surfaces/native.md](surfaces/native.md)               |
| Native iOS behavior, gestures, device-size layout           | **iOS Simulator** (AXe + `simctl`)                    | [surfaces/ios-simulator.md](surfaces/ios-simulator.md) |

- **Prove a backend change with command output as `text`.** Use **Electron** only
  when the criterion depends on desktop-only code. Drive iOS with AXe, and mark
  the case `blocked` if AXe cannot express the gesture.
- **Structured data keeps machine-readable datasets** (`cases[].datasets` +
  `cases[].visualizations`; raw CSV/JSON stays as `evidence`). Render accessible
  HTML tables or self-contained charts in the report -
  [report.md](references/report.md#structured-visualizations). **A deliverable
  the user hears needs `audio`** —
  [evidence.md](references/evidence.md#audio-deliverables).
- **Auth is a gate scoped to the surface**: authenticate that surface first or
  every capture lands on the sign-in page. Web:
  [auth-web.md](references/auth-web.md).
- **A UI round may price its interaction cost** by recording KLM operator counts
  into `interaction-trace.jsonl`; optional, never hand-written —
  [interaction-cost.md](references/interaction-cost.md).

Shared rules for every artifact — media types, provenance, files and inline
content, safety — are in [evidence.md](references/evidence.md).

## Final handoff (mandatory)

Before declaring the task done, prove coverage: for each check with
`requiredEvidence`, every declared `type` is present at least once. Report it
explicitly; a missing type holds the delivery at `uncertain` no matter how good
the work is.

The final response MUST include the verified **engapp.dev artifact URL for the
complete acceptance report** and coverage result. If publication is blocked, state
that explicitly, retain the local round, and never invent a URL.

For GitHub delivery, follow [github.md](references/github.md). Inspect the
selected PR/Issue template and current body. If a corresponding screenshot
section exists, upload relevant inspected screenshots with `gh image` and
insert its returned image Markdown directly into that section of the body.
For the current PR's acceptance report, always include the full engapp.dev
report link in the PR body, including when there is no screenshot section.
Preserve unrelated body content and verify the saved body after editing.

```text
Acceptance: https://engapp.dev/artifacts/page/<generated-id>
Coverage: 2/2 criteria, all required evidence uploaded
```

## Portability rules

- **Capture through the engine.** `agent-browser screenshot` / `snapshot` / `eval` run
  headless. On iOS, capture with `xcrun simctl io`. Rounds land under
  `.acceptances/`, which the agent keeps out of git with `.acceptances/.gitignore`
  containing `*`.
- **Paths in commands.** `$SKILL_DIR` is the directory holding this SKILL.md; its
  `scripts/` holds the scripts the references run. `$REPORT_DIR` is the current
  round directory ([report.md](references/report.md#directory-layout)). Every
  working file of a run stays in that round directory.
- **Capture as you go.** Save evidence and case observations locally during the
  run; publish the complete report after coverage and rendering checks.
- **Don't invent evidence.** Capture only the types a check declares.

## Reference map

| Need                                           | Reference                                                                                                                                                                               |
| ---------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| The project layer, bootstrapping an adapter    | [project-adapter.md](references/project-adapter.md)                                                                                                                                     |
| Mistakes checklist (read every round)          | [common-mistakes.md](references/common-mistakes.md)                                                                                                                                     |
| Forcing state, real error conditions, runtime probes | [probe-mock-patterns.md](references/probe-mock-patterns.md)                                                                                                                             |
| Required tools and automatic installation     | [dependencies.md](references/dependencies.md) |
| GitHub templates, screenshots, report links   | [github.md](references/github.md) |
| Authored rounds, `result.json`, HTML publishing | [report.md](references/report.md) |
| Supplied plans: schema, mapping, coverage     | [plan-format.md](references/plan-format.md) |
| Evidence media, provenance, submission, safety | [evidence.md](references/evidence.md)                                                                                                                                                   |
| Interaction cost overlay                       | [interaction-cost.md](references/interaction-cost.md)                                                                                                                                   |
| Web/Electron Chromium CLI commands             | [agent-browser.md](references/agent-browser.md)                                                                                                                                         |
| Authenticated Web session                      | [auth-web.md](references/auth-web.md)                                                                                                                                                   |
| Native macOS / OS-owned step                   | [computer-use.md](references/computer-use.md)                                                                                                                                           |
| Temporal evidence: Web/Electron, iOS, native   | [recording-cdp.md](references/recording-cdp.md), [recording-ios-simulator.md](references/recording-ios-simulator.md), [recording-native-macos.md](references/recording-native-macos.md) |
