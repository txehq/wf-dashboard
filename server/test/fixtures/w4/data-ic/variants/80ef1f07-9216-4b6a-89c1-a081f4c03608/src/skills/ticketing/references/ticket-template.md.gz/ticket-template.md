# Ticket template

The body of a ticket: a Linear issue's description, or a GitHub issue's body. `/ticketing`
writes every Linear ticket from it. A GitHub issue in a repository that has its own issue
template follows that template.

- **All sections, in this order**, each present even when it is one line; a section with
  nothing to say reads "None". *Constraints* is optional.
- **Replace every italic prompt.** A prompt left in a filed ticket is a question nobody
  answered.
- **One behaviour per acceptance criterion**, each naming the check that proves it.
- **To install it:** in Linear, paste the block into the team's issue template; on GitHub, save
  it as `.github/ISSUE_TEMPLATE/ticket.md` below `name:` and `about:` front matter.

```markdown
## Background

_What real-world problem are we trying to solve? Who hits it, what it costs them today, how urgent it is, and where it came from — link the report, incident, brief or epic._

## Goals

_What is the expected user story?_

- As a …, I want …, so that ….

## Scope

_What are we doing, and what aren't we doing?_

- **In scope:** …
- **Out of scope:** … — and where each item goes: a sibling ticket, a follow-up, or nowhere.

## Constraints

_Optional. What must hold while the work is done, and where it comes from._

- …

## Acceptance criteria

_What must be true when this is done, and what proves each one: an E2E, integration or unit test, a visual comparison, or a measurement?_

- [ ] … — verify: E2E test
- [ ] … — verify: unit test

## Expected artifacts

_What will exist when this is done? The pull request, the tests it adds, the evidence (acceptance report, screenshots, recordings), and any docs, migrations, flags or dashboards — list what applies._

- …
```
