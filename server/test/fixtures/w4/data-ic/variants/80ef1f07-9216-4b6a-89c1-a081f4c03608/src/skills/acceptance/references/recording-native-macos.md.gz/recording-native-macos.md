# Native macOS screen recording

Use this reference only when the criterion owns a native macOS window or OS
chrome that CDP cannot observe. It requires a local macOS display and is not
cloud-portable.

## Record the host screen

Record for a fixed duration so the recorder finalizes without an external kill:

```bash
screencapture -V 15 "$REPORT_DIR/assets/native-flow.mp4"
```

Convert a short clip to GIF when inline playback is important:

```bash
ffmpeg -y -i "$REPORT_DIR/assets/native-flow.mp4" \
  -vf "fps=8,scale=900:-1:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse" \
  "$REPORT_DIR/assets/native-flow.gif"
```

Inspect the resulting file before citing it and confirm that no unrelated window,
notification, or secret entered the host-screen capture. Tag direct
`screencapture` output as `by cli` and FFmpeg-derived media as `by program`.

For input and Accessibility commands, use
[computer-use.md](./computer-use.md). Choose between `gif` and `video` and submit
using the shared contract in [evidence.md](./evidence.md).
