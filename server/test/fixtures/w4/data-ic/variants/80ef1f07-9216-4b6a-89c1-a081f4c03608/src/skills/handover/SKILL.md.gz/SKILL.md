---
name: handover
description: Hand a ticket to another person at any stage of the work — before it starts, mid-development, at a review boundary, or because a session is ending. Derives the repository state, asks only what no command can answer, publishes the handover page, and records the transfer in Linear. Use whenever work changes owner, including at the end of a session.
---

# /handover — give someone else the work, and everything they need to take it

**Spec (authority):** Obsidian `Project Magi/Workflow/Specs/Publishing/Handover.md` (WF-HAND).
Where this file and the spec disagree, the spec wins: update this file to match it.

This transfers **ownership of a ticket to another person**, at whatever stage the work has
reached:

- **before any work** — "this was going to be mine, it should be yours";
- **mid-development** — a branch exists, partly done, someone else is finishing it;
- **at a review boundary** — a PR is open with findings outstanding;
- **end of session** — any of the above, plus the fact that time ran out.

## Run the tool first, always

```bash
wf handover --to "<person>" --why "<reason>"
```

It derives the state — branch, HEAD, pushed or not, divergence, uncommitted files, PR,
checks, review decision — infers the stage, and prints the skeleton with all of that filled
in. **Do not gather this yourself.** Running `git` and `gh` and transcribing the results is
where fabrication enters.

Add `--ticket TXE-N` when the branch name does not carry one, `--root <path>` for a
different work tree, `--json` for the state alone.

Write every working file into `.handover/` in the current directory. Create that directory,
with a `.gitignore` in it containing `*`, before writing the first file into it.

## Settle the blocking items before you send anything

The tool lists them. They are blocking because each one silently loses work:

- **Uncommitted files.** They exist on one machine, in one directory, and nothing else
  references them. Either commit and push, or state in the handover that this work is being
  abandoned. Never leave it implied.
- **Unpushed commits.** The receiver cannot fetch what only your disk has.
- **No ticket.** A handover with no ticket has nothing to hand over *to*.

## Then answer only what the tool could not

1. **Done, and verified how.** *What did you run or observe?* A green local build is not a
   verified claim, and the receiver cannot tell the difference from outside. The receiver
   plans around what you write: when you are unsure whether something is verified, say it is
   not, and name the parts nobody has checked.
2. **Tried and rejected.** Include *why* each was rejected: an alternative with no recorded
   reason gets re-attempted within a day.
3. **Decisions taken, and on what evidence.** Anything the receiver would otherwise reopen.

Then: the **next concrete step** (one specific action, such as "fix the failing case in TestX
then re-run the suite"), and the **traps** that will bite them.

**Ask the sender nothing the tool already answered.** If you find yourself asking which
branch it is on, the tool has already said.

## Publish, then record the transfer

```bash
# render the page with /explainer into .handover/handover.html, then:
wf publish-artifact .handover/handover.html --title "Handover — TXE-N to <person>"
```

Then in Linear, all three — this is the chain of custody, and a missing piece makes the
transfer invisible to everyone not in the conversation:

1. **reassign** the ticket to the receiver;
2. **update the `Instance` label** — replace it with the receiver's, or remove it when
   handing to someone with no instance identity;
3. **comment**, dated, linking the published page.

Leave the ticket status as it is: work in progress stays in progress.
