# Desktop (Electron) surface

Use this surface for **desktop-only behavior** — native windows, IPC / main-process
code, tray/menu, auto-update, OS integration, or a packaged-only path. Drive the
running app's renderer over CDP with `agent-browser`
([../references/agent-browser.md](../references/agent-browser.md)).

For a change that behaves identically in a browser, return to the router and use
the cloud-portable Web surface. Use Electron only when the criterion calls out the
desktop shell.

## Setup

1. Start the desktop app in dev/debug mode with a CDP port open (commonly 9222).
   How you start it is app-specific (its own dev command); the requirement is a
   reachable CDP endpoint.
2. Connect agent-browser to that port:

```bash
agent-browser --cdp 9222 snapshot -i
agent-browser --cdp 9222 get url # sanity-check you attached to the app
agent-browser --cdp 9222 screenshot "$REPORT_DIR/assets/desktop-state.png"
```

3. Auth: a desktop app usually keeps its own persistent login state in its
   user-data dir — log in once in the app and it survives restarts. Verify the
   signed-in state through the attached renderer before capturing evidence.

## Reading app state

If the app exposes a global state handle, eval it to assert behavior. Discover the
handle's actual name from the app: `scripts/electron-app-state.js` returns the
renderer's URL, pathname, hash and ready state, and the globals the app added to
`window`. Then read the handle you found:

```bash
agent-browser --cdp 9222 eval --stdin < "$SKILL_DIR/scripts/electron-app-state.js"
agent-browser --cdp 9222 eval 'JSON.stringify(window.<handle>)'
```

## Capturing console errors during a run

`scripts/console-error-capture.js` installs an interceptor that collects every
`console.error` call into `window.__ERRORS__`:

```bash
# install the interceptor before exercising the feature
agent-browser --cdp 9222 eval --stdin < "$SKILL_DIR/scripts/console-error-capture.js"
# ... drive the feature ...
agent-browser --cdp 9222 eval "JSON.stringify(window.__ERRORS__)" > "$REPORT_DIR/assets/console-errors.txt"
```

Record the saved errors as `text` evidence.

## Gotchas

- **Dev builds often auto-open DevTools, which hijacks the CDP target.** Symptom:
  `get url` returns a `devtools://…` URL. Fix: close the DevTools target and
  reconnect:

  ```bash
  curl -sS --fail --noproxy '*' "http://localhost:9222/json/close/$(curl -sS --fail --noproxy '*' http://localhost:9222/json/list | jq -r 'first(.[] | select(.type == "page" and (.url | startswith("devtools://")))) | .id')"
  agent-browser close --all && agent-browser --cdp 9222 get url
  ```

- **Clean up all processes when done** with the app's own stop command
  (`PROJECT.md` §4), which ends the helper processes (GPU, renderer, network) with
  the main process.

- **Don't resize the window after load** — many apps trigger a full reload on
  resize, invalidating refs and state.

## Time-based behavior & OS-level steps

- **Behavior over time** needs a clip — record CDP frames into MP4/GIF:
  [../references/recording-cdp.md](../references/recording-cdp.md).
- **Native chrome around the app** (file pickers, system dialogs, menu-bar/dock,
  permission prompts) lives outside the renderer — drive it with Computer Use:
  [../references/computer-use.md](../references/computer-use.md).

## Boundaries — headless / cloud

Tag renderer artifacts captured by `agent-browser` as `by agent-browser`; use
`by cdp` only for a direct CDP client capture.

Electron on Linux needs a display server. In a headless/cloud environment, wrap the
launch with `xvfb-run` (virtual framebuffer). Everything CDP-based keeps working
under Xvfb (connection, snapshots, eval, and `agent-browser screenshot`, which
captures from the renderer). OS-window capture (`screencapture`), osascript, and
native screen recording are macOS-only. Keep evidence CDP-based to stay
cloud-portable whenever the renderer owns the criterion.
