-- 激活 app 后全选并复制 focus 区域的文本，之后用 pbpaste 读取；参数：app 名称
on run argv
	set appName to item 1 of argv
	tell application appName to activate
	delay 0.5
	tell application "System Events"
		keystroke "a" using command down
		keystroke "c" using command down
	end tell
end run
