# The interview question bank

Source: the vault note `+Inbox/+++ Workflow WIP.md`. The node `Specs/Session/Interview.md` is
the authority for *what scoping is*; this file holds the bank of questions and the rules for
asking them.

**Runtime rule.** Every question has a **Goal**. The Goal is what the asker is trying to
learn and why; it is thought about before the question is chosen and **never shown to the
user**. Display only the Question, adapted to the case at hand; the wording below is a
template to adapt. Skip any question already answered by the request, the authoritative
specification, the repository, its documentation, tests, runtime evidence, project
conventions, or a prior confirmed decision.

## Which phase belongs to which skill

| Phase | Asked by | When |
|---|---|---|
| 1 — Initiation and discovery | `/interview` | before exploration, and only when the request is unclear |
| 2 — Post-exploration confirmation | `/interview` | after the agent has explored; every question carries evidence |
| 3 — Requirements and scope clarification | `/interview` | after exploration; only what materially changes behaviour, contracts, risk or acceptance |
| 4 — Architecture planning | `/plan` (`/lfg` stage 3), over `/research`'s output | after research, before ticketing |
| 4-ext — Ticket decomposition | `/ticketing` (`/lfg` stage 4) | while splitting into Linear tickets |
| 5 — Implementation approval and execution | `/ticketing`'s dispatch gate (the end of `/lfg`); `/implement` when it hits a planning assumption (M5) | leaving read-only planning; mid-implementation |
| 6 — Quality review and completion | `/ic`'s review loop (R1, R2) and `/ready-for-review` (R3, R4) | when review findings land; at completion |

## Deciding whether to ask at all

| the open point | treatment |
|---|---|
| can be found out — code, tests, config, history, runtime | **investigate it yourself** |
| changes the product outcome | **ask** |
| changes an irreversible risk — data, money, external effects, prod | **must ask**, and record the answer |
| a low-risk implementation detail | **decide yourself**, record it as a reversible default |

## Angles — where the decisions usually hide

When a request looks fully specified, one of these rows usually holds the decision it leaves
open. Each row is a decision type and the options that recur; they are prompts for the asker's
thinking.

| Decision type | Options that recur |
|---|---|
| Product scope | the whole request in scope / a named part moved out of scope |
| User experience on missing data | show Healthy / show Unknown / show "no data yet" |
| Deployment model | SaaS / self-hosted / both |
| Data semantics | native ids only / inferred / keep both and label the source |
| Data ownership | PostgreSQL / ClickHouse / split by authority and availability |
| Content permissions | owner only / team-wide / same as the log metadata permissions |
| Failure policy | fail closed / bounded degradation / fail open |
| Background scheduling | leader runner / read-path triggered |
| Unfinished endpoints | keep legacy / block release / explicitly approved degradation |
| Compatibility | keep an upgrade path / breaking change / defer the decision |
| Architecture evolution | foundational refactor first / direct fix first |
| Metric definition | pick one semantics / show several / drop the metric |
| Data retention | short retention / long raw retention / downsampled archive |
| Release strategy | one global atomic switch / per-endpoint activation |

## Phase 1 — Initiation and discovery

Ask before exploration only when the initial request is unclear. Otherwise explore first and
start at Phase 2.

| ID | Question | Goal |
|---|---|---|
| I1 | What problem are you trying to solve, and what prompted this request now? | Identify the underlying problem, trigger, urgency, and whether the request describes an outcome or only a proposed implementation. |
| I2 | Who experiences this problem, and what workflow are they performing when it occurs? | Identify primary actors, affected workflows, entry points, and the user context the feature must improve. |
| I3 | What should users be able to do after this feature exists that they cannot do reliably today? | Translate the request into observable capabilities and exclude implementation details that are not part of the intended outcome. |
| I4 | How will you determine that the feature is successful? | Gather measurable product outcomes, operational signals, and the minimum evidence required to call the feature complete. |
| I5 | What constraints or non-negotiable requirements must the solution honor? | Capture security, privacy, compliance, availability, compatibility, technology, deadline, and organizational constraints before exploration. |
| I6 | My current understanding is `[problem, users, expected outcome, constraints]`. What is incorrect or missing? | Establish the first confirmation gate and prevent exploration from proceeding from a misunderstood objective. |

## Phase 2 — Post-exploration confirmation

Primarily agent work. Before any of these is asked, trace entry points, control flow, data
flow, storage, integrations, conventions and similar features. Code, tests, configuration,
history and runtime evidence answer engineering facts.

| ID | Question | Goal |
|---|---|---|
| E1 | The current system behaves as follows: `[evidence-backed summary]`. Which part of this behavior is the actual gap you want changed? | Validate the problem against the existing implementation and remove assumptions disproven by exploration. |
| E2 | Which existing behaviors must remain unchanged, and which may intentionally change? | Define compatibility boundaries and prevent regression of adjacent workflows. |
| E3 | We found these existing components and extension points: `[summary]`. Which should be reused, replaced, or left untouched? | Confirm whether established abstractions are authoritative and identify replacements that would materially expand scope. |
| E4 | Which system or data source should be authoritative when the existing sources disagree? | Establish a single source of truth for state, identity, permissions, pricing, configuration, or derived metrics. |
| E5 | Are there production conditions, deployment variants, customer configurations, or real examples that are not represented in the repository? | Fill gaps that source inspection cannot resolve, including runtime topology, private integrations, representative samples, and operational exceptions. |

## Phase 3 — Requirements and scope clarification

Ask only questions whose answers materially change external behavior, contracts, risk or
acceptance. Do not ask the user to answer facts that can be established from code or runtime
inspection.

| ID | Question | Goal |
|---|---|---|
| S1 | Which actors, roles, tenants, plans, platforms, or environments must receive this behavior, and which must not? | Complete the actor, entitlement, tenancy, edition, and environment matrix. |
| S2 | Which workflows, entry points, APIs, protocols, clients, and downstream consumers are in scope? | Establish the complete externally visible surface and prevent silent omission of less obvious paths. |
| S3 | What is explicitly out of scope or safe to defer? | Create a no-work boundary and prevent adjacent improvements from being absorbed without authorization. |
| S4 | What user-visible states must the feature support, including loading, empty, partial, stale, invalid, unauthorized, failed, and retrying states? | Complete the behavioral state matrix needed for UI, API, state-machine, and test design. |
| S5 | For each important failure, should the operation retry, degrade, fail closed, fail open, or require operator action? | Define error classification, retry boundaries, recoverability, and acceptable residual risk. |
| S6 | What should happen after cancellation, timeout, partial output, duplicate delivery, or an unknown execution result? | Specify ambiguous terminal states, idempotency requirements, and whether replay could duplicate side effects. |
| S7 | What data must be created, preserved, migrated, backfilled, expired, exported, or deleted? | Define the complete data lifecycle, migration responsibilities, retention rules, and no-touch boundaries. |
| S8 | Who may create, view, modify, export, or delete the feature's data? | Produce the authorization, privacy, audit, and ownership matrix for every sensitive operation. |
| S9 | Must existing callers, stored data, deployments, and integrations remain compatible, or is a breaking change acceptable? | Decide the compatibility strategy and identify required migrations, versioning, deprecations, or explicit breakage. |
| S10 | What scale, latency, throughput, concurrency, availability, or cost envelope must the feature support? | Convert non-functional expectations into quantitative design constraints and release gates. |
| S11 | What logs, metrics, traces, audit events, alerts, and administrative controls are required to operate this safely? | Fill observability, diagnosis, governance, and production-support gaps in the plan. |
| S12 | Which capabilities make up the complete feature? | Establish the complete inventory of capabilities the design delivers. |
| S13 | Here are the remaining decisions and my recommendations: `[decision list]`. Which do you want to decide yourself, and which do you explicitly delegate to me? | Separate user-owned product decisions from delegated technical judgment and prevent silence from being interpreted as approval. |

## Phase 4 — Architecture planning *(asked by `/plan`, `/lfg` stage 3)*

Each user-facing option is a complete design, stated as its concrete differences, costs,
risks, affected contracts and acceptance implications.

| ID | Question | Goal |
|---|---|---|
| A1 | When choosing an approach, which trade-offs matter most: delivery speed, simplicity, maintainability, extensibility, consistency, performance, or operating cost? | Establish decision criteria before recommending an architecture. |
| A2 | I found these viable approaches: `[options and trade-offs]`. I recommend `[approach]` because `[reason]`. Which approach do you choose? | Obtain the architecture decision and record any intentional rejection of the recommendation. |
| A3 | Where should ownership of state, validation, authorization, orchestration, and side effects reside? | Resolve module, service, database, client/server, and trust-boundary ownership where multiple architectures remain viable. |
| A4 | What consistency, ordering, idempotency, durability, and visibility guarantees must the chosen design provide? | Turn product failure expectations into explicit architectural invariants. |
| A5 | How should the feature be introduced: immediate replacement, migration, shadow mode, feature flag, canary, or staged activation? | Define rollout sequencing, coexistence with legacy behavior, rollback capability, and cutover evidence. |
| A6 | The proposed architecture is `[summary]`, with these remaining risks: `[list]`. Do you approve this architecture? | Freeze the architecture before converting it into implementation tickets. |

## Phase 4-ext — Ticket decomposition *(asked by `/ticketing`, `/lfg` stage 4)*

Tickets are independently reviewable and preferably a user-visible vertical slice or a
necessary, testable foundation. Never split solely by directory or technical layer.

| ID | Question | Goal |
|---|---|---|
| T1 | What is the smallest end-to-end slice that provides independently useful or demonstrable value? | Identify the first vertical ticket and avoid a sequence where no value appears until every layer is complete. |
| T2 | Which shared contracts, migrations, abstractions, or infrastructure must exist before any vertical slice can be delivered? | Identify genuine foundation tickets and distinguish them from speculative refactoring. |
| T3 | Which work items depend on one another, and which can proceed independently? | Build the ticket dependency graph, critical path, and safe opportunities for parallel implementation. |
| T4 | For each ticket, what is its exact outcome, scope, and explicit out-of-scope boundary? | Make every description name behavior, and prevent overlap, hidden work and duplicate ownership. |
| T5 | What exact scenarios must pass for each ticket, including inputs, outputs, permissions, failures, and edge cases? | Create independently testable acceptance criteria and prevent completion from depending on subjective review. |
| T6 | Should migrations, backfills, observability, rollout controls, documentation, cleanup, and compatibility removal be included in feature tickets or tracked separately? | Make cross-cutting operational work visible and ensure it is neither forgotten nor bundled ambiguously. |
| T7 | Which tickets may be released independently, and which must share one release or activation gate? | Separate implementation order from production activation and define safe intermediate states. |
| T8 | What external dependencies, samples, credentials, environments, approvals, or other teams block each ticket? | Record non-code blockers, ownership, prerequisites, and stopping conditions before implementation begins. |
| T9 | Here is the proposed ticket map and dependency order: `[tickets]`. Which boundaries or priorities should change? | Obtain explicit confirmation that the decomposition represents the desired scope and delivery strategy. |

## Phase 5 — Implementation approval and execution *(`/ticketing`'s dispatch gate; `/implement` for M5)*

Implementation needs its own approval, given before leaving read-only planning.

| ID | Question | Goal |
|---|---|---|
| M1 | The requirements, architecture, ticket sequence, and acceptance criteria are ready. Do you authorize implementation, and what must change before I begin? | Obtain explicit authorization to leave planning and start modifying the repository. |
| M2 | Are there required branch, worktree, commit, PR target, review, deployment, or CI conventions for this implementation? | Capture delivery constraints that cannot be inferred reliably from code and prevent work from landing in the wrong workflow. |
| M3 | Which external changes are authorized as part of implementation, such as migrations, deployments, feature-flag changes, seeded data, or ticket transitions? | Establish the mutation boundary and prevent implementation approval from being interpreted as unlimited operational authority. |
| M4 | If implementation reveals a material scope or contract change, should I update the current ticket, create a follow-up ticket, defer it, or stop for a new decision? | Predefine escalation behavior while still requiring renewed confirmation for newly discovered critical uncertainty. |
| M5 | Implementation invalidated this planning assumption: `[evidence and impact]`. Should we revise the plan and continue, defer the affected capability, or stop? | Reopen planning only when new evidence changes external behavior, cost, compatibility, or risk. |

## Phase 6 — Quality review and completion *(R1–R2 by `/ic`'s review loop; R3–R4 by `/ready-for-review`)*

| ID | Question | Goal |
|---|---|---|
| R1 | Review found these high-confidence issues: `[findings]`. Should they be fixed now, moved to follow-up tickets, or accepted as known risk? | Apply the review disposition gate: fix now, fix later, or proceed as-is. |
| R2 | Which accepted follow-ups require tickets, owners, priorities, and release blockers before this feature can be considered complete? | Prevent "fix later" from becoming untracked work and distinguish release blockers from ordinary follow-ups. |
| R3 | The implementation and acceptance evidence are `[summary]`, with these remaining limitations: `[list]`. Do you accept the feature as complete? | Obtain final product acceptance after the agent has independently verified code, tests, runtime behavior, and known risks. |
| R4 | May the completed tickets be closed or transitioned, and should any remaining work be recorded separately? | Authorize external ticket-state changes when that authority was not already included in the implementation request. |

## Operating rules

- Include a question only when its answer is not already available from an authoritative
  source **and** different answers would materially change the work.
- Ask discovery questions before exploration only when the initial request is unclear.
- Ask detailed questions after exploration, using concrete evidence.
- Ask blocker questions first, normally in batches of three to five, ordered by dependency.
- When valid alternatives exist, offer two or three mutually exclusive options, explain their
  consequences, and mark one recommendation.
- If the user delegates a decision, state the selected default and obtain confirmation only
  when the choice changes product behaviour, risk, compatibility, or external effects.
- Do not start architecture design before material clarification answers are resolved.
- Before implementation, establish the authoritative issue or specification, the included
  prerequisites, the follow-up work, the delivery target and the definition of done.
- Require approval when leaving read-only planning, accepting a material contract choice,
  expanding scope, performing an irreversible or external action, or proceeding with a known
  blocking risk. Never ask users to reconfirm facts or already-authorized work.
- Progress, file changes, test results, CI status and other verifiable facts are status
  reports.
- Track verified facts, confirmed decisions, delegated decisions, reversible defaults,
  deferred work and unresolved blockers.
- Reopen a settled question only when new evidence invalidates its premise or materially
  changes its consequences.
- **Silence is not agreement.** Record every answer as `confirmed`, `delegated` (with its
  default stated) or `deferred`. An option label such as `A` means the first option listed.
